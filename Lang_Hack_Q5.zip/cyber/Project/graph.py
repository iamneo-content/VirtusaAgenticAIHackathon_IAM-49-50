#!/usr/bin/env python3
"""
Graph Interface for CyberSentinel Email Threat Detection
Programmatic entry point for running the threat detection workflow with Gemini 2.0 Flash
"""

from typing import Dict, Any
from workflow.workflow import run_threat_detection_workflow
from state import EmailThreatState
import json
import logging

logger = logging.getLogger(__name__)


def analyze_email(email_json: Dict[str, Any], llm_client=None) -> EmailThreatState:
    """
    Main entry point for email threat analysis

    Args:
    email_json: Email data as dictionary
    llm_client: Optional LLM client for agents (required for full analysis, can be mock for testing)

    Returns:
    Complete analysis state with all threat detection results

    Example:
    >>> import json
    >>> from tests import MockGeminiClient
    >>> with open("data/input/sample_emails/mail1.json") as f:
    ... email = json.load(f)
    >>> mock_client = MockGeminiClient()
    >>> result = analyze_email(email, llm_client=mock_client)
    >>> print(result["threat_category_predicted"])
    >>> print(result["predicted_severity_level"])
    """
    if llm_client is None:
        logger.warning("No LLM client provided - running in degraded mode")
        logger.warning("Pass a mock client or real Gemini client for full analysis")

    return run_threat_detection_workflow(email_json, llm_client=llm_client)


def analyze_email_from_file(file_path: str, llm_client=None) -> EmailThreatState:
    """
    Run threat detection on email from JSON file

    Args:
        file_path: Path to email JSON file
        llm_client: Optional Gemini API client for LLM agents (created automatically if not provided)

    Returns:
        Complete analysis state with all threat detection results
    """
    with open(file_path, 'r') as f:
        email_json = json.load(f)

    return analyze_email(email_json, llm_client=llm_client)


def get_threat_summary(result: EmailThreatState) -> Dict[str, Any]:
    """
    Extract key threat information from analysis result

    Args:
        result: Complete analysis state

    Returns:
        Dictionary with summary of key findings
    """
    return {
        "email_id": result.get("email_id"),
        "from": result.get("email_json", {}).get("from"),
        "subject": result.get("email_json", {}).get("subject"),
        "threat_category": result.get("threat_category_predicted"),
        "severity_level": result.get("predicted_severity_level"),
        "risk_score": result.get("risk_score"),
        "threat_indicators": result.get("threat_indicators", []),
        "detected_intent": result.get("detected_intent"),
        "confidence": result.get("threat_confidence_scores", {}),
        "recommended_actions": result.get("recommended_actions", []),
        "mitre_techniques": result.get("mitre_techniques", []),
        "threat_actor_attribution": result.get("threat_actor_attribution"),
        "quality_metrics": result.get("quality_metrics", {}),
    }


def print_threat_summary(result: EmailThreatState):
    """
    Print formatted threat analysis summary

    Args:
        result: Complete analysis state
    """
    summary = get_threat_summary(result)

    print("\n" + "=" * 70)
    print("EMAIL THREAT ANALYSIS SUMMARY")
    print("=" * 70)
    print(f"Email ID: {summary['email_id']}")
    print(f"From: {summary['from']}")
    print(f"Subject: {summary['subject']}")

    print(f"\nTHREAT CLASSIFICATION")
    print(f" Category: {summary['threat_category'].upper()}")
    print(f" Severity: {summary['severity_level'].upper()}")
    print(f" Risk Score: {summary['risk_score']:.1f}/100")

    if summary['threat_indicators']:
        print(f"\nDETECTED THREAT INDICATORS ({len(summary['threat_indicators'])}):")
        for indicator in summary['threat_indicators']:
            confidence = summary['confidence'].get(indicator, 0.0)
            print(f" {indicator} ({confidence:.0%})")

    print(f"\nINTENT ANALYSIS")
    print(f" Detected Intent: {summary['detected_intent']}")

    if summary['mitre_techniques']:
        print(f"\nMITRE ATT&CK TECHNIQUES ({len(summary['mitre_techniques'])}):")
        for technique in summary['mitre_techniques']:
            print(f" {technique}")

    if summary['threat_actor_attribution'] and summary['threat_actor_attribution'] != "unknown":
        print(f"\nTHREAT ACTOR ATTRIBUTION")
        print(f" {summary['threat_actor_attribution']}")

    if summary['recommended_actions']:
        print(f"\nRECOMMENDED ACTIONS ({len(summary['recommended_actions'])}):")
        for action in summary['recommended_actions']:
            print(f" {action}")

    quality = summary['quality_metrics']
    if quality:
        print(f"\nANALYSIS QUALITY")
        print(f" Overall Quality: {quality.get('overall_quality', 0):.0%}")
        print(f" Confidence: {quality.get('confidence', 0):.0%}")

    print("=" * 70 + "\n")


def get_risk_classification(result: EmailThreatState) -> Dict[str, Any]:
    """
    Get simplified risk classification for quick decision-making

    Args:
        result: Complete analysis state

    Returns:
        Simplified risk classification
    """
    severity_to_action = {
        "critical": "QUARANTINE_IMMEDIATELY",
        "high": "BLOCK_AND_INVESTIGATE",
        "medium": "FLAG_FOR_REVIEW",
        "low": "MONITOR",
        "info": "NO_ACTION"
    }

    severity = result.get("predicted_severity_level", "unknown")

    return {
        "threat_level": severity.upper(),
        "recommended_action": severity_to_action.get(severity, "REVIEW"),
        "risk_score": result.get("risk_score", 0),
        "is_critical": severity in ["critical", "high"],
        "requires_immediate_action": severity == "critical",
    }


def export_analysis_as_json(result: EmailThreatState, output_path: str = None) -> Dict[str, Any]:
    """
    Export complete analysis results as structured JSON

    Args:
        result: Complete analysis state
        output_path: Optional path to save JSON file

    Returns:
        JSON-serializable dictionary with all analysis results
    """
    export_data = {
        "email_id": result.get("email_id"),
        "analysis_results": {
            "threat_detection": {
                "category": result.get("threat_category_predicted"),
                "indicators": result.get("threat_indicators", []),
                "confidence_scores": result.get("threat_confidence_scores", {}),
            },
            "severity_assessment": {
                "level": result.get("predicted_severity_level"),
                "confidence": result.get("severity_confidence"),
                "risk_score": result.get("risk_score"),
            },
            "intent_analysis": {
                "detected_intent": result.get("detected_intent"),
                "confidence": result.get("intent_confidence"),
                "analysis": result.get("intent_analysis", {}),
            },
            "threat_intelligence": {
                "campaigns": result.get("correlated_campaigns", []),
                "mitre_techniques": result.get("mitre_techniques", []),
                "threat_actor": result.get("threat_actor_attribution"),
                "analysis": result.get("threat_intelligence", {}),
            },
            "recommendations": {
                "actions": result.get("recommended_actions", []),
                "remediation_steps": result.get("remediation_steps", []),
                "user_notification": result.get("user_notification_template"),
            },
        },
        "quality_metrics": result.get("quality_metrics", {}),
        "errors": result.get("error_messages", []),
    }

    if output_path:
        with open(output_path, 'w') as f:
            json.dump(export_data, f, indent=2, default=str)

    return export_data


if __name__ == "__main__":
    print("CyberSentinel Threat Detection Graph Interface")
    print("Use: analyze_email(email_json) or analyze_email_from_file(path)")
