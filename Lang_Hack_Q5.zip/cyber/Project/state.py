#!/usr/bin/env python3
"""
State Management for CyberSentinel Email Threat Detection

Defines the complete state schema for email analysis and threat detection
"""

from typing import TypedDict, List, Dict, Optional, Any
import re
from pathlib import Path


class EmailThreatState(TypedDict):
    """Complete state schema for email threat detection and analysis"""

    # Input
    email_json: Dict[str, Any]
    email_id: str

    # Email Parsing
    parsed_email: Dict[str, Any]
    email_headers_normalized: Dict[str, Any]
    parsing_complete: bool
    parsing_errors: List[str]

    # Email Analysis
    email_analysis: Dict[str, Any]
    extracted_features: Dict[str, float]
    analysis_complete: bool

    # ML Threat Detection (Parallel)
    threat_indicators: List[str]
    threat_confidence_scores: Dict[str, float]
    threat_category_predicted: str
    threat_detection_complete: bool

    # ML Severity Prediction (Parallel)
    predicted_severity_level: str
    severity_confidence: float
    risk_score: float
    severity_prediction_complete: bool

    # LLM Intent Classification
    intent_analysis: Dict[str, Any]
    detected_intent: str
    intent_confidence: float
    intent_classification_complete: bool

    # LLM Threat Intelligence Analysis
    threat_intelligence: Dict[str, Any]
    correlated_campaigns: List[str]
    mitre_techniques: List[str]
    threat_actor_attribution: str
    intelligence_analysis_complete: bool

    # LLM Recommendation Generation
    recommended_actions: List[str]
    remediation_steps: List[str]
    user_notification_template: str
    recommendation_generation_complete: bool

    # LLM Report Generation
    final_report: str
    report_json: Dict[str, Any]
    quality_metrics: Dict[str, float]
    saved_path: str
    output_dir: str
    report_generation_complete: bool

    # Error Tracking
    error_occurred: bool
    error_messages: List[str]


def get_initial_state(email_json: Dict[str, Any]) -> EmailThreatState:
    """
    Initialize complete state with defaults for email processing

    Args:
        email_json: Email data as dictionary

    Returns:
        Initialized EmailThreatState
    """
    email_id = email_json.get("email_id", "UNKNOWN")

    return {
        # Input
        "email_json": email_json,
        "email_id": email_id,

        # Email Parsing
        "parsed_email": {},
        "email_headers_normalized": {},
        "parsing_complete": False,
        "parsing_errors": [],

        # Email Analysis
        "email_analysis": {},
        "extracted_features": {},
        "analysis_complete": False,

        # ML Threat Detection
        "threat_indicators": [],
        "threat_confidence_scores": {},
        "threat_category_predicted": "unknown",
        "threat_detection_complete": False,

        # ML Severity Prediction
        "predicted_severity_level": "unknown",
        "severity_confidence": 0.0,
        "risk_score": 0.0,
        "severity_prediction_complete": False,

        # LLM Intent Classification
        "intent_analysis": {},
        "detected_intent": "unknown",
        "intent_confidence": 0.0,
        "intent_classification_complete": False,

        # LLM Threat Intelligence Analysis
        "threat_intelligence": {},
        "correlated_campaigns": [],
        "mitre_techniques": [],
        "threat_actor_attribution": "unknown",
        "intelligence_analysis_complete": False,

        # LLM Recommendation Generation
        "recommended_actions": [],
        "remediation_steps": [],
        "user_notification_template": "",
        "recommendation_generation_complete": False,

        # LLM Report Generation
        "final_report": "",
        "report_json": {},
        "quality_metrics": {},
        "saved_path": "",
        "output_dir": "",
        "report_generation_complete": False,

        # Error Tracking
        "error_occurred": False,
        "error_messages": [],
    }


def validate_state(state: EmailThreatState) -> tuple[bool, List[str]]:
    """
    Validate state completeness and consistency

    Args:
        state: EmailThreatState to validate

    Returns:
        Tuple of (is_valid, error_messages)
    """
    errors = []

    # Check critical fields
    if not state.get("email_id"):
        errors.append("Missing email_id")

    if not state.get("email_json"):
        errors.append("Missing email_json")

    # Check parsing
    if state.get("parsing_complete") and not state.get("parsed_email"):
        errors.append("Parsing marked complete but parsed_email is empty")

    # Check analysis
    if state.get("analysis_complete") and not state.get("extracted_features"):
        errors.append("Analysis marked complete but extracted_features is empty")

    # Check threat detection
    if state.get("threat_detection_complete") and not state.get("threat_indicators"):
        errors.append("Threat detection marked complete but no threat_indicators found")

    # Check severity prediction
    if state.get("severity_prediction_complete") and not state.get("predicted_severity_level"):
        errors.append("Severity prediction marked complete but no severity_level predicted")

    return len(errors) == 0, errors


def slugify(text: str, max_length: int = 50) -> str:
    """
    Convert text to URL-safe slug format
    Example: "Phishing Email Detected" -> "phishing_email_detected"
    """
    text = text.lower().strip()
    text = re.sub(r'[^\w\s-]', '', text)
    text = re.sub(r'[-\s]+', '_', text)
    text = re.sub(r'^_+|_+$', '', text)
    return text[:max_length]
