#!/usr/bin/env python3
"""
CyberSentinel Threat Detection Workflow
Builds LangGraph workflow with parallel execution for email threat detection
"""

from langgraph.graph import StateGraph, START, END
from state import EmailThreatState, get_initial_state
from nodes.email_parser_node import email_parser_node
from nodes.email_analyzer_node import email_analyzer_node
from nodes.threat_detection_node import threat_detection_node
from nodes.severity_prediction_node import severity_prediction_node
from nodes.intent_classifier_node import intent_classifier_node
from nodes.threat_intelligence_node import threat_intelligence_node
from nodes.recommendations_node import recommendations_node
from nodes.report_generator_node import report_generator_node
from typing import Dict, Any


def build_workflow(llm_client=None, api_delay: float = 2.0):
    """
    Build complete CyberSentinel threat detection workflow with LangGraph

    Workflow:
    1. Email Parser (entry point)
    2. Email Analyzer
    3. [Parallel] Threat Detector + Severity Predictor
    4. Intent Classifier (LLM - Gemini 2.0 Flash)
    5. Threat Intelligence Analyzer (LLM - Gemini 2.0 Flash)
    6. Recommendation Generator (LLM - Gemini 2.0 Flash)
    7. Report Generator (LLM - Gemini 2.0 Flash, exit point)

    Args:
        llm_client: Optional Gemini API client for LLM agents
        api_delay: Delay in seconds between API calls to avoid rate limiting (default: 2.0)

    Returns:
        Compiled LangGraph workflow
    """
    workflow = StateGraph(EmailThreatState)

    # Create node functions with LLM client and delay binding
    def _intent_classifier(state):
        return intent_classifier_node(state, client=llm_client, api_delay=api_delay)

    def _threat_intelligence(state):
        return threat_intelligence_node(state, client=llm_client, api_delay=api_delay)

    def _recommendations(state):
        return recommendations_node(state, client=llm_client, api_delay=api_delay)

    def _report_generator(state):
        return report_generator_node(state, client=llm_client, api_delay=api_delay)

    # Add all 8 nodes
    workflow.add_node("email_parser", email_parser_node)
    workflow.add_node("email_analyzer", email_analyzer_node)
    workflow.add_node("threat_detector", threat_detection_node)
    workflow.add_node("severity_predictor", severity_prediction_node)
    workflow.add_node("intent_classifier", _intent_classifier)
    workflow.add_node("threat_intelligence_analyzer", _threat_intelligence)
    workflow.add_node("recommendation_generator", _recommendations)
    workflow.add_node("report_generator", _report_generator)

    # Set entry point
    workflow.set_entry_point("email_parser")

    # Linear flow: parser analyzer
    workflow.add_edge("email_parser", "email_analyzer")

    # Parallel execution: analyzer to threat detection and severity prediction
    workflow.add_edge("email_analyzer", "threat_detector")
    workflow.add_edge("email_analyzer", "severity_predictor")

    # Convergence: all parallel nodes to intent classifier
    workflow.add_edge("threat_detector", "intent_classifier")
    workflow.add_edge("severity_predictor", "intent_classifier")

    # Linear flow: classifier threat intel recommendations report
    workflow.add_edge("intent_classifier", "threat_intelligence_analyzer")
    workflow.add_edge("threat_intelligence_analyzer", "recommendation_generator")
    workflow.add_edge("recommendation_generator", "report_generator")

    # Exit point
    workflow.add_edge("report_generator", END)

    # Compile workflow
    return workflow.compile()


def run_threat_detection_workflow(email_json: Dict[str, Any], llm_client=None, api_delay: float = 2.0) -> EmailThreatState:
    """
    Execute complete threat detection workflow on an email

    Args:
        email_json: Email data as dictionary
        llm_client: Optional Gemini API client for LLM agents
        api_delay: Delay in seconds between API calls to avoid rate limiting (default: 2.0)

    Returns:
        Complete analysis state with all results
    """
    # Initialize state
    initial_state = get_initial_state(email_json)

    # Build workflow
    graph = build_workflow(llm_client=llm_client, api_delay=api_delay)

    # Execute workflow
    result = graph.invoke(initial_state)

    return result
