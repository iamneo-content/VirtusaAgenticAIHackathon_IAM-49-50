#!/usr/bin/env python3
"""
Utility package for shared helpers (e.g., Gemini client factory).
"""

from utils.gemini_client import build_gemini_client

__all__ = ["build_gemini_client"]
