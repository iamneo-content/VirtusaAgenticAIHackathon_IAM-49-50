#!/usr/bin/env python3
"""
Gemini client builder used across the app.

Provides a minimal adapter that matches the agents' expected interface:
client.messages_create(max_tokens=..., messages=[{"role": "...", "content": "..."}])
"""

from __future__ import annotations

import os
from typing import Optional

# Patch importlib.metadata for older Python versions that lack packages_distributions
import importlib.metadata as _stdlib_metadata
try:
    import importlib_metadata as _backport_metadata  # type: ignore
except ImportError:  # pragma: no cover - optional dependency
    _backport_metadata = None

if not hasattr(_stdlib_metadata, "packages_distributions") and _backport_metadata:
    _stdlib_metadata.packages_distributions = _backport_metadata.packages_distributions  # type: ignore[attr-defined]

try:
    from google import generativeai as genai
    from google.api_core import gapic_v1
except ImportError:  # pragma: no cover - handled at runtime
    genai = None


class GeminiAdapter:
    """Thin wrapper to align google-generativeai responses with our agents."""

    def __init__(self, api_key: str, model_name: str, max_retries: int = 0, request_timeout: int = 30):
        if genai is None:
            raise ImportError("google-generativeai is not installed")

        genai.configure(api_key=api_key)

        # Configure retry and timeout settings to prevent quota exhaustion
        # max_retries=0 fails fast on rate limits instead of retrying
        self.max_retries = max_retries
        self.request_timeout = request_timeout

        # Create model with timeout configuration
        self.model = genai.GenerativeModel(model_name)
        self.model_name = model_name

    def messages_create(self, max_tokens: int = 500, messages=None):
        content = ""
        if messages and len(messages) > 0:
            content = messages[0].get("content", "")

        try:
            response = self.model.generate_content(
                content,
                generation_config={"max_output_tokens": max_tokens},
                request_options={
                    "timeout": self.request_timeout,
                    "retry": None  # Disable automatic retries to prevent quota exhaustion
                }
            )
        except Exception as e:
            # Log rate limit errors for monitoring
            if "429" in str(e) or "RESOURCE_EXHAUSTED" in str(e) or "quota" in str(e).lower():
                import logging
                logger = logging.getLogger(__name__)
                logger.warning(f"API rate limit or quota exceeded: {str(e)}")
            raise

        # google-generativeai returns a rich object; we just need .text
        text = getattr(response, "text", None)
        if text is None and getattr(response, "candidates", None):
            try:
                text = response.candidates[0].content.parts[0].text
            except Exception:
                text = ""
        text = text or ""

        class _Content:
            def __init__(self, text_value: str):
                self.text = text_value

        class _Response:
            def __init__(self, text_value: str):
                self.content = [_Content(text_value)]

        return _Response(text)


def _get_first_api_key() -> Optional[str]:
    """
    Return the first available Gemini API key.

    Looks for GEMINI_API_KEY_1, GEMINI_API_KEY_2, GEMINI_API_KEY_3, GEMINI_API_KEY_4
    in order. Returns the first one found.

    Can work with single or multiple keys:
    - Single key: GEMINI_API_KEY_1=your_key (others empty)
    - Multiple keys: GEMINI_API_KEY_1=key1, GEMINI_API_KEY_2=key2, etc.
    """
    for i in range(1, 5):
        key = os.getenv(f"GEMINI_API_KEY_{i}")
        if key:
            return key
    return None


def build_gemini_client() -> Optional[GeminiAdapter]:
    """
    Build and return a GeminiAdapter if API key and library are present.
    Returns None when not configured so callers can handle degraded mode.

    Configuration (from .env):
    - GEMINI_MODEL: Model to use (default: gemini-2.0-flash)
    - REQUEST_TIMEOUT: Timeout in seconds (default: 30)
    - MAX_RETRIES: Max retries on failure (default: 0 to prevent quota exhaustion)
    """
    api_key = _get_first_api_key()
    model_name = os.getenv("GEMINI_MODEL", "gemini-2.0-flash")
    request_timeout = int(os.getenv("REQUEST_TIMEOUT", "30"))
    max_retries = int(os.getenv("MAX_RETRIES", "0"))  # Default 0 to fail fast on rate limits

    if not api_key or genai is None:
        return None

    try:
        return GeminiAdapter(
            api_key=api_key,
            model_name=model_name,
            max_retries=max_retries,
            request_timeout=request_timeout
        )
    except Exception:
        return None
