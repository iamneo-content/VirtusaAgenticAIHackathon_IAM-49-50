#!/usr/bin/env python3
"""
Train Threat Detection Model
Trains a Random Forest classifier to predict threat indicators and categories

Feature inputs: 16 numeric email features
Output: Multi-label threat indicators + threat category (5 classes)
"""

import pickle
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.multioutput import MultiOutputClassifier
from sklearn.preprocessing import MultiLabelBinarizer, StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import precision_recall_fscore_support
import logging
from typing import Tuple, Dict, Any
import json

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

THREAT_INDICATORS = [
    'lbl_spoofed_sender',
    'lbl_malicious_url_pattern',
    'lbl_macro_enabled_document',
    'lbl_suspicious_attachment',
    'lbl_social_engineering',
    'lbl_credential_harvesting',
    'lbl_business_email_compromise',
    'lbl_ransomware_indicator',
    'lbl_phishing_attempt',
    'lbl_malware_vector',
    'lbl_obfuscation_detected',
    'lbl_urgency_tactic',
    'lbl_domain_mismatch',
    'lbl_suspicious_domain',
]

THREAT_CATEGORIES = ['phishing', 'malware', 'bec', 'spam', 'legitimate']

DESIRED_FEATURES = [
    'auth_failures', 'spf_fail', 'dkim_fail', 'dmarc_fail',
    'subject_length', 'body_length', 'urgency_signal_score',
    'language_anomaly_score', 'obfuscation_score',
    'url_count', 'malicious_url_ratio',
    'attachment_count', 'suspicious_attachment_ratio',
    'macro_enabled_attachment', 'sender_domain_suspicious',
    'url_domain_mismatch',
    # Alternative names that may exist
    'domain_reputation_score', 'domain_age_days',
    'sender_baseline_deviation', 'content_complexity_score'
]


def train_threat_detection_model(
    training_df: pd.DataFrame,
    eval_df: pd.DataFrame = None,
    test_size=0.2,
    random_state=42,
    model_save_dir='ml/model'
) -> Dict[str, Any]:
    """
    Train threat detection model using Random Forest

    Trains a multi-label classification model to predict threat indicators.
    Orchestrates complete training pipeline:
    1. Prepare and validate training data
    2. Scale features using StandardScaler
    3. Train MultiOutputClassifier with Random Forest
    4. Evaluate on test set
    5. Compute feature importance
    6. Generate classification reports
    7. Save model artifacts

    Args:
        training_df: Training dataset with features and labels
        eval_df: Optional evaluation dataset
        test_size: Train/test split ratio
        random_state: Random seed for reproducibility
        model_save_dir: Directory to save model artifacts

    Returns:
        Dictionary with training results and metrics
    """
    logger.info("Starting threat detection model training...")

    # 1. Prepare data - inline logic for _prepare_data
    # Select features - use only columns that exist in the data
    feature_cols = [col for col in DESIRED_FEATURES if col in training_df.columns]

    # If we don't have enough features, use all numeric columns
    if len(feature_cols) < 5:
        numeric_cols = training_df.select_dtypes(include=['number']).columns.tolist()
        feature_cols = [col for col in numeric_cols if 'lbl_' not in col and col not in ['threat_category']]

    X = training_df[feature_cols].copy()

    # Prepare threat indicators (multi-label)
    indicator_cols = [col for col in THREAT_INDICATORS if col in training_df.columns]
    mlb = None
    if indicator_cols:
        mlb = MultiLabelBinarizer()
        y_indicators = mlb.fit_transform(
            training_df[indicator_cols].apply(lambda x: [col for col in indicator_cols if x[col]], axis=1)
        )
    else:
        y_indicators = np.zeros((len(training_df), len(THREAT_INDICATORS)))

    # Prepare threat category (single-label)
    if 'threat_category' in training_df.columns:
        y_category = training_df['threat_category'].values
    else:
        y_category = np.array(['unknown'] * len(training_df))

    # 2. Split data (stratify by threat category for better distribution)
    X_train, X_test, y_ind_train, y_ind_test, y_cat_train, y_cat_test = train_test_split(
        X, y_indicators, y_category,
        test_size=test_size,
        random_state=random_state,
        stratify=y_category if y_category is not None else None
    )

    logger.info(f"Training set size: {len(X_train)}, Test set size: {len(X_test)}")

    # 3. Fit scaler
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    # 4. Train multi-label model for threat indicators
    # Hyperparameters tuned to reduce overfitting:
    # - max_depth: Reduced from 20 to 10 (prevents deep memorization)
    # - min_samples_split: Increased from 5 to 20 (more samples before split)
    # - min_samples_leaf: Increased from 2 to 10 (larger leaf nodes)
    # - class_weight: 'balanced' to handle imbalanced threat indicators
    base_rf = RandomForestClassifier(
        n_estimators=100,
        max_depth=10,
        min_samples_split=20,
        min_samples_leaf=10,
        class_weight='balanced',
        random_state=random_state,
        n_jobs=-1,
        verbose=1
    )
    model = MultiOutputClassifier(base_rf)

    logger.info("Training Multi-Label Random Forest model...")
    model.fit(X_train_scaled, y_ind_train)

    # 5. Evaluate
    train_score = model.score(X_train_scaled, y_ind_train)
    test_score = model.score(X_test_scaled, y_ind_test)

    logger.info(f"Training accuracy: {train_score:.4f}")
    logger.info(f"Test accuracy: {test_score:.4f}")

    # 6. Feature importance (average across all estimators)
    importances = np.array([est.feature_importances_ for est in model.estimators_])
    avg_importance = np.mean(importances, axis=0)
    feature_importance = {
        name: float(importance)
        for name, importance in zip(X.columns, avg_importance)
    }

    # 7. Classification report for multi-label
    y_pred = model.predict(X_test_scaled)

    # Convert to indicator format for reporting
    y_ind_test_labels = [mlb.classes_[i] for i in range(len(mlb.classes_))] if mlb else THREAT_INDICATORS
    y_test_df = pd.DataFrame(y_ind_test, columns=y_ind_test_labels)
    y_pred_df = pd.DataFrame(y_pred, columns=y_ind_test_labels)

    # Calculate per-indicator metrics
    report = {}
    for col in y_ind_test_labels:
        precision, recall, f1, support = precision_recall_fscore_support(
            y_test_df[col], y_pred_df[col], average='binary', zero_division=0
        )
        report[col] = {
            'precision': float(precision) if precision is not None else 0.0,
            'recall': float(recall) if recall is not None else 0.0,
            'f1-score': float(f1) if f1 is not None else 0.0,
            'support': float(support) if support is not None else 0.0
        }

    training_report = {
        'train_accuracy': float(train_score),
        'test_accuracy': float(test_score),
        'feature_importance': feature_importance,
        'classification_report': report,
        'threat_indicators': y_ind_test_labels,
        'model_type': 'multi-label',
    }

    # 8. Save model and artifacts - inline logic for save_model
    logger.info(f"Saving model to {model_save_dir}...")

    # Save model
    with open(f"{model_save_dir}/threat_detection_model.pkl", 'wb') as f:
        pickle.dump(model, f)

    # Save scaler
    with open(f"{model_save_dir}/threat_detection_scaler.pkl", 'wb') as f:
        pickle.dump(scaler, f)

    # Save multi-label binarizer
    if mlb:
        with open(f"{model_save_dir}/threat_indicators_mlb.pkl", 'wb') as f:
            pickle.dump(mlb, f)

    # Save training report
    with open(f"{model_save_dir}/threat_detection_report.json", 'w') as f:
        json.dump(training_report, f, indent=2)

    logger.info("Model saved successfully!")
    logger.info("Multi-label threat detection model training complete!")

    return training_report


if __name__ == "__main__":
    print("Threat Detection Model Trainer")
    print("Usage: python -m ml.train_model.train_threat_detection_model")
