#!/usr/bin/env python3
"""
Model Training Module
Scripts for training threat detection and severity prediction models

Functions:
- train_threat_detection_model: Trains Random Forest for threat detection
- train_severity_prediction_model: Trains Random Forest for severity prediction
"""

from ml.train_model.train_threat_detection_model import train_threat_detection_model
from ml.train_model.train_severity_prediction_model import train_severity_prediction_model

__all__ = [
    "train_threat_detection_model",
    "train_severity_prediction_model",
]
