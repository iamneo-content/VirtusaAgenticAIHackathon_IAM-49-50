#!/usr/bin/env python3
"""
Train Severity Prediction Model
Trains a Random Forest classifier to predict threat severity levels

Algorithm: Random Forest (100 trees, max_depth=10)
Feature inputs: 16 numeric email features + threat indicators
Output: Severity level (5 classes: critical, high, medium, low, info)
"""

import pickle
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
import logging
from typing import Tuple, Dict, Any
import json

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

SEVERITY_LEVELS = ['critical', 'high', 'medium', 'low', 'info']

DESIRED_FEATURES = [
    'auth_failures', 'spf_fail', 'dkim_fail', 'dmarc_fail',
    'subject_length', 'body_length', 'urgency_signal_score',
    'language_anomaly_score', 'obfuscation_score',
    'url_count', 'malicious_url_ratio',
    'attachment_count', 'suspicious_attachment_ratio',
    'macro_enabled_attachment', 'sender_domain_suspicious',
    'url_domain_mismatch',
    # Alternative names that may exist
    'domain_reputation_score', 'domain_age_days',
    'sender_baseline_deviation', 'content_complexity_score'
]


def train_severity_prediction_model(
    training_df: pd.DataFrame,
    eval_df: pd.DataFrame = None,
    test_size=0.2,
    random_state=42,
    model_save_dir='ml/model'
) -> Dict[str, Any]:
    """
    Train severity prediction model using Random Forest

    Trains a multi-class classification model to predict threat severity.
    Orchestrates complete training pipeline:
    1. Prepare and validate training data
    2. Scale features using StandardScaler
    3. Encode severity labels
    4. Train RandomForestClassifier
    5. Evaluate on test set
    6. Compute feature importance
    7. Generate classification reports
    8. Save model artifacts

    Args:
        training_df: Training dataset with features and labels
        eval_df: Optional evaluation dataset
        test_size: Train/test split ratio
        random_state: Random seed for reproducibility
        model_save_dir: Directory to save model artifacts

    Returns:
        Dictionary with training results and metrics
    """
    logger.info("Starting severity prediction model training...")

    # 1. Prepare data - inline logic for _prepare_data
    # Select features - use only columns that exist in the data
    feature_cols = [col for col in DESIRED_FEATURES if col in training_df.columns]

    # If we don't have enough features, use all numeric columns
    if len(feature_cols) < 5:
        numeric_cols = training_df.select_dtypes(include=['number']).columns.tolist()
        feature_cols = [col for col in numeric_cols if 'severity_level' not in col and 'risk_score' not in col]

    X = training_df[feature_cols].copy()

    # Prepare severity labels
    if 'severity_level' in training_df.columns:
        y_severity = training_df['severity_level'].values
    elif 'risk_score' in training_df.columns:
        # Convert risk score to severity level - inline logic
        scores = training_df['risk_score'].values
        severities = np.array(['info'] * len(scores))
        severities[scores >= 80] = 'critical'
        severities[(scores >= 60) & (scores < 80)] = 'high'
        severities[(scores >= 40) & (scores < 60)] = 'medium'
        severities[(scores >= 20) & (scores < 40)] = 'low'
        y_severity = severities
    else:
        y_severity = np.array(['medium'] * len(training_df))

    # 2. Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y_severity,
        test_size=test_size,
        random_state=random_state,
        stratify=y_severity
    )

    logger.info(f"Training set size: {len(X_train)}, Test set size: {len(X_test)}")

    # 3. Fit scaler
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    # 4. Encode labels
    severity_encoder = LabelEncoder()
    y_train_encoded = severity_encoder.fit_transform(y_train)
    y_test_encoded = severity_encoder.transform(y_test)

    # 5. Train model
    # Hyperparameters tuned to reduce overfitting:
    # - max_depth: Reduced from 20 to 10 (prevents deep memorization)
    # - min_samples_split: Increased from 5 to 20 (more samples before split)
    # - min_samples_leaf: Increased from 2 to 10 (larger leaf nodes)
    # - class_weight: 'balanced' to handle imbalanced severity classes
    model = RandomForestClassifier(
        n_estimators=100,
        max_depth=10,
        min_samples_split=20,
        min_samples_leaf=10,
        class_weight='balanced',
        random_state=random_state,
        n_jobs=-1,
        verbose=1
    )

    logger.info("Training Random Forest model...")
    model.fit(X_train_scaled, y_train_encoded)

    # 6. Evaluate
    train_score = model.score(X_train_scaled, y_train_encoded)
    test_score = model.score(X_test_scaled, y_test_encoded)

    logger.info(f"Training accuracy: {train_score:.4f}")
    logger.info(f"Test accuracy: {test_score:.4f}")

    # 7. Feature importance
    feature_importance = {
        name: float(importance)
        for name, importance in zip(X.columns, model.feature_importances_)
    }

    # 8. Classification report
    y_pred = model.predict(X_test_scaled)
    y_pred_labels = severity_encoder.inverse_transform(y_pred)
    report = classification_report(y_test, y_pred_labels, output_dict=True)

    training_report = {
        'train_accuracy': float(train_score),
        'test_accuracy': float(test_score),
        'feature_importance': feature_importance,
        'classification_report': report,
        'severity_levels': SEVERITY_LEVELS,
        'classes': {int(i): label for i, label in enumerate(severity_encoder.classes_)}
    }

    # 9. Save model and artifacts - inline logic for save_model
    logger.info(f"Saving model to {model_save_dir}...")

    # Save model
    with open(f"{model_save_dir}/severity_prediction_model.pkl", 'wb') as f:
        pickle.dump(model, f)

    # Save scaler
    with open(f"{model_save_dir}/severity_prediction_scaler.pkl", 'wb') as f:
        pickle.dump(scaler, f)

    # Save label encoder
    with open(f"{model_save_dir}/severity_level_encoder.pkl", 'wb') as f:
        pickle.dump(severity_encoder, f)

    # Save training report
    with open(f"{model_save_dir}/severity_prediction_report.json", 'w') as f:
        json.dump(training_report, f, indent=2)

    logger.info("Model saved successfully!")
    logger.info("Model training complete!")

    return training_report


if __name__ == "__main__":
    print("Severity Prediction Model Trainer")
    print("Usage: python -m ml.train_model.train_severity_prediction_model")
