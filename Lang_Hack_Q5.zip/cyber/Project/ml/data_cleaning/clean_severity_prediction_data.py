#!/usr/bin/env python3
"""
Clean Severity Prediction Data

Prepares raw email threat datasets for severity prediction model training

Handles:
- Removal of duplicates
- Handling missing values
- Removing outliers
- Validating severity labels
- Data integrity checks
"""

import pandas as pd
import numpy as np
from typing import Tuple, Dict, Any
import logging
import os

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

REQUIRED_FEATURE_COLUMNS = [
    'auth_failures', 'spf_fail', 'dkim_fail', 'dmarc_fail',
    'subject_length', 'body_length', 'urgency_signal_score',
    'language_anomaly_score', 'obfuscation_score',
    'url_count', 'malicious_url_ratio',
    'attachment_count', 'suspicious_attachment_ratio',
    'macro_enabled_attachment', 'sender_domain_suspicious',
    'url_domain_mismatch'
]

VALID_SEVERITY_LEVELS = {'critical', 'high', 'medium', 'low', 'info'}


def clean_severity_prediction_data(
    df: pd.DataFrame,
    is_training=True,
    save_processed=True,
    output_dir='data/processed',
    verbose=True
) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    """
    Clean data for severity prediction model training

    Orchestrates complete data cleaning pipeline:
    1. Remove duplicates
    2. Validate required columns
    3. Prepare/convert severity labels
    4. Handle missing values
    5. Remove outliers
    6. Validate numeric columns
    7. Validate severity levels
    8. Save processed data

    Args:
        df: Raw dataframe with email threat data
        is_training: Whether this is training data (compute stats) or evaluation data
        save_processed: Whether to save cleaned data to CSV
        output_dir: Directory to save processed data
        verbose: Print cleaning progress

    Returns:
        Tuple of (cleaned_df, cleaning_stats)
    """
    df = df.copy()
    stats = {'stage': 'severity_prediction', 'is_training': is_training}

    if verbose:
        logger.info(f"Starting severity prediction data cleaning (training={is_training})...")
        logger.info(f"Initial dataset size: {len(df)}")

    # 1. Remove duplicates
    initial_size = len(df)
    df = df.drop_duplicates(subset=['email_id'] if 'email_id' in df.columns else None)
    stats['duplicates_removed'] = initial_size - len(df)

    if verbose and stats['duplicates_removed'] > 0:
        logger.info(f"Removed {stats['duplicates_removed']} duplicate records")

    # 2. Validate required columns
    missing_feature_cols = [col for col in REQUIRED_FEATURE_COLUMNS if col not in df.columns]
    has_severity_label = ('severity_level' in df.columns or 'risk_score' in df.columns)

    if missing_feature_cols:
        logger.warning(f"Missing feature columns: {missing_feature_cols}")
        stats['missing_feature_columns'] = missing_feature_cols

    if not has_severity_label:
        logger.error("No severity_level or risk_score column found!")
        stats['missing_label_column'] = True

    # 3. Prepare severity labels - inline logic for score to severity conversion
    if 'risk_score' in df.columns and 'severity_level' not in df.columns:
        scores = df['risk_score'].values
        severities = np.array(['info'] * len(scores), dtype=object)
        severities[scores >= 80] = 'critical'
        severities[(scores >= 60) & (scores < 80)] = 'high'
        severities[(scores >= 40) & (scores < 60)] = 'medium'
        severities[(scores >= 20) & (scores < 40)] = 'low'
        df['severity_level'] = severities
        if verbose:
            logger.info("Converted risk_score to severity_level")

    # 4. Handle missing values - inline logic
    stats_missing = {}
    missing_initial_size = len(df)

    # Handle numeric columns (fill with median)
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    for col in numeric_cols:
        missing_count = df[col].isnull().sum()
        if missing_count > 0:
            df[col].fillna(df[col].median(), inplace=True)
            stats_missing[f'{col}_missing_filled'] = missing_count

    # Handle severity_level column (remove rows with missing labels)
    if 'severity_level' in df.columns:
        missing_labels = df['severity_level'].isnull().sum()
        if missing_labels > 0:
            df = df[df['severity_level'].notna()]
            stats_missing['severity_level_missing_rows_removed'] = missing_labels

    stats_missing['rows_removed_due_to_missing'] = missing_initial_size - len(df)
    stats.update(stats_missing)

    # 5. Remove outliers (IQR method) - inline logic
    stats_outliers = {}
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    outlier_initial_size = len(df)
    outlier_details = {}

    for col in numeric_cols:
        # Skip binary columns (only contain 0 and 1)
        unique_vals = df[col].unique()
        if set(unique_vals).issubset({0, 1}):
            continue

        Q1 = df[col].quantile(0.25)
        Q3 = df[col].quantile(0.75)
        IQR = Q3 - Q1

        # Skip if IQR is 0 (no variation)
        if IQR == 0:
            continue

        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR

        col_outliers = len(df[(df[col] < lower_bound) | (df[col] > upper_bound)])
        if col_outliers > 0:
            outlier_details[col] = col_outliers
            df = df[(df[col] >= lower_bound) & (df[col] <= upper_bound)]

    stats_outliers['outlier_details'] = outlier_details
    stats_outliers['total_outliers_removed'] = outlier_initial_size - len(df)
    stats.update(stats_outliers)

    # 6. Validate numeric columns - inline logic
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    for col in numeric_cols:
        # Replace infinite values
        df[col] = df[col].replace([np.inf, -np.inf], np.nan)
        # Fill remaining NaN with median
        if df[col].isnull().any():
            df[col] = df[col].fillna(df[col].median())

    # 7. Validate severity levels
    if 'severity_level' in df.columns:
        invalid_rows = ~df['severity_level'].isin(VALID_SEVERITY_LEVELS)
        if invalid_rows.any():
            if verbose:
                logger.warning(f"Found {invalid_rows.sum()} rows with invalid severity_level")
            df = df[~invalid_rows]

        stats['severity_distribution'] = df['severity_level'].value_counts().to_dict()
        if verbose:
            logger.info(f"Severity distribution: {stats['severity_distribution']}")

    stats['final_size'] = len(df)
    stats['records_removed'] = initial_size - len(df)

    # 8. Save processed data if requested - inline logic
    if save_processed:
        os.makedirs(output_dir, exist_ok=True)
        output_file = f"{output_dir}/severity_prediction_cleaned.csv"
        df.to_csv(output_file, index=False)

        if verbose:
            logger.info(f"Processed data saved: {output_file}")

        stats['saved_to'] = output_file

    if verbose:
        logger.info(f"Final dataset size: {stats['final_size']}")
        if save_processed:
            logger.info(f"Saved to: {stats['saved_to']}")
        logger.info("Severity prediction data cleaning complete!")

    return df, stats


if __name__ == "__main__":
    print("Severity Prediction Data Cleaner")
    print("Usage: from ml.data_cleaning.clean_severity_prediction_data import clean_severity_prediction_data")
