#!/usr/bin/env python3
"""
CyberSentinel ML Module
Model training and data cleaning utilities for threat detection

Submodules:
- data_cleaning: Clean raw datasets for model training
- train_model: Train threat detection and severity prediction models
- evaluation: Evaluate trained models on evaluation datasets
- model: Directory for storing trained model artifacts
"""

from ml.data_cleaning import clean_threat_detection_data, clean_severity_prediction_data
from ml.train_model import train_threat_detection_model, train_severity_prediction_model
from ml.evaluation import evaluate_models, run_evaluation

__version__ = "1.0.0"

__all__ = [
    # Data cleaning functions
    "clean_threat_detection_data",
    "clean_severity_prediction_data",
    # Model training functions
    "train_threat_detection_model",
    "train_severity_prediction_model",
    # Model evaluation functions
    "evaluate_models",
    "run_evaluation",  # Backward compatibility wrapper
]
