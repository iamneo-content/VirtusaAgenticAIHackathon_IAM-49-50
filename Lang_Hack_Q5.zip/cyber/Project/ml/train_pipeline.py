#!/usr/bin/env python3
"""
Complete Training Pipeline for CyberSentinel ML Models

This script orchestrates the entire ML workflow:
1. Load raw training data from data/training_dataset/
2. Clean both threat detection and severity prediction datasets
3. Train both models (threat detection and severity prediction)
4. Save all artifacts and processed data

Usage:
    python ml/train_pipeline.py
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pandas as pd
import logging
from pathlib import Path
from typing import Dict, Any

from ml.data_cleaning import clean_threat_detection_data, clean_severity_prediction_data
from ml.train_model import train_threat_detection_model, train_severity_prediction_model

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def run_training_pipeline(data_dir='data', processed_dir='data/processed', model_dir='ml/model') -> Dict[str, Any]:
    """
    Run complete ML training pipeline

    Orchestrates the entire ML workflow:
    1. Load raw training data from data/training_dataset/
    2. Clean both threat detection and severity prediction datasets
    3. Train both models
    4. Save all artifacts and processed data

    Args:
        data_dir: Root data directory
        processed_dir: Directory for cleaned/processed data
        model_dir: Directory for saving model artifacts

    Returns:
        Dictionary with pipeline execution stats
    """
    # Create directories if they don't exist
    Path(processed_dir).mkdir(parents=True, exist_ok=True)
    Path(model_dir).mkdir(parents=True, exist_ok=True)

    stats = {}

    logger.info("=" * 70)
    logger.info("CYBERSENTIMEL ML TRAINING PIPELINE")
    logger.info("=" * 70)

    # Step 1: Load raw data
    logger.info("\n[STEP 1] Loading raw training data...")
    training_dataset_dir = f"{data_dir}/training_dataset"

    threat_file = f"{training_dataset_dir}/threat_detection_training.csv"
    severity_file = f"{training_dataset_dir}/severity_training.csv"

    logger.info(f"  Loading threat detection training data from {threat_file}")
    threat_df = pd.read_csv(threat_file)
    logger.info(f"   Loaded {len(threat_df)} threat detection records")

    logger.info(f"  Loading severity prediction training data from {severity_file}")
    severity_df = pd.read_csv(severity_file)
    logger.info(f"   Loaded {len(severity_df)} severity prediction records")

    # Step 2: Clean threat detection data
    logger.info("\n[STEP 2] Cleaning threat detection data...")
    threat_clean_df, threat_clean_stats = clean_threat_detection_data(
        threat_df,
        is_training=True,
        save_processed=True,
        output_dir=processed_dir
    )
    stats['threat_detection_cleaning'] = threat_clean_stats
    logger.info(f"   Threat detection data cleaned: {len(threat_clean_df)} records")
    logger.info(f"   Saved to: {threat_clean_stats.get('saved_to')}")

    # Step 3: Clean severity prediction data
    logger.info("\n[STEP 3] Cleaning severity prediction data...")
    severity_clean_df, severity_clean_stats = clean_severity_prediction_data(
        severity_df,
        is_training=True,
        save_processed=True,
        output_dir=processed_dir
    )
    stats['severity_prediction_cleaning'] = severity_clean_stats
    logger.info(f"   Severity prediction data cleaned: {len(severity_clean_df)} records")
    logger.info(f"   Saved to: {severity_clean_stats.get('saved_to')}")

    # Step 4: Train threat detection model
    logger.info("\n[STEP 4] Training threat detection model...")
    threat_model_stats = train_threat_detection_model(threat_clean_df, model_save_dir=model_dir)
    stats['threat_detection_training'] = threat_model_stats
    logger.info(f"   Threat detection model trained")
    if 'accuracy' in threat_model_stats:
        logger.info(f"   Model accuracy: {threat_model_stats['accuracy']:.4f}")
    logger.info(f"   Artifacts saved to: {model_dir}")

    # Step 5: Train severity prediction model
    logger.info("\n[STEP 5] Training severity prediction model...")
    severity_model_stats = train_severity_prediction_model(severity_clean_df, model_save_dir=model_dir)
    stats['severity_prediction_training'] = severity_model_stats
    logger.info(f"   Severity prediction model trained")
    if 'accuracy' in severity_model_stats:
        logger.info(f"   Model accuracy: {severity_model_stats['accuracy']:.4f}")
    logger.info(f"   Artifacts saved to: {model_dir}")

    # Summary
    logger.info("\n" + "=" * 70)
    logger.info("PIPELINE EXECUTION COMPLETE")
    logger.info("=" * 70)

    logger.info("\n PIPELINE SUMMARY")
    logger.info("-" * 70)

    if 'threat_detection_cleaning' in stats:
        threat_stats = stats['threat_detection_cleaning']
        logger.info(f"\n Threat Detection Cleaning:")
        logger.info(f"  - Initial records: {threat_stats.get('duplicates_removed', 0) + threat_stats.get('final_size', 0)}")
        logger.info(f"  - Final records: {threat_stats.get('final_size', 0)}")
        logger.info(f"  - Records removed: {threat_stats.get('records_removed', 0)}")
        logger.info(f"  - Saved to: {threat_stats.get('saved_to', 'N/A')}")

    if 'severity_prediction_cleaning' in stats:
        severity_stats = stats['severity_prediction_cleaning']
        logger.info(f"\n Severity Prediction Cleaning:")
        logger.info(f"  - Initial records: {severity_stats.get('duplicates_removed', 0) + severity_stats.get('final_size', 0)}")
        logger.info(f"  - Final records: {severity_stats.get('final_size', 0)}")
        logger.info(f"  - Records removed: {severity_stats.get('records_removed', 0)}")
        logger.info(f"  - Saved to: {severity_stats.get('saved_to', 'N/A')}")

    if 'threat_detection_training' in stats:
        train_stats = stats['threat_detection_training']
        logger.info(f"\n Threat Detection Model Training:")
        logger.info(f"  - Model: RandomForest (n_estimators=100, max_depth=20)")
        logger.info(f"  - Accuracy: {train_stats.get('accuracy', 'N/A')}")
        logger.info(f"  - Classes: {train_stats.get('num_classes', 'N/A')}")

    if 'severity_prediction_training' in stats:
        train_stats = stats['severity_prediction_training']
        logger.info(f"\n Severity Prediction Model Training:")
        logger.info(f"  - Model: RandomForest (n_estimators=100, max_depth=20)")
        logger.info(f"  - Accuracy: {train_stats.get('accuracy', 'N/A')}")
        logger.info(f"  - Classes: {train_stats.get('num_classes', 'N/A')}")

    logger.info(f"\n Output Directories:")
    logger.info(f"  - Processed data: {processed_dir}/")
    logger.info(f"  - Model artifacts: {model_dir}/")
    logger.info("=" * 70)

    return stats


if __name__ == "__main__":
    stats = run_training_pipeline(
        data_dir='data',
        processed_dir='data/processed',
        model_dir='ml/model'
    )
