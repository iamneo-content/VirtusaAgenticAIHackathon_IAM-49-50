#!/usr/bin/env python3
"""
Model Evaluation Module
Evaluates trained ML models on the dedicated evaluation dataset
"""

import pickle
import pandas as pd
import numpy as np
from pathlib import Path
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    classification_report
)
import logging
from typing import Dict, Any
import json

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

THREAT_INDICATORS = [
    'lbl_spoofed_sender',
    'lbl_malicious_url_pattern',
    'lbl_macro_enabled_document',
    'lbl_suspicious_attachment',
    'lbl_social_engineering',
    'lbl_credential_harvesting',
    'lbl_business_email_compromise',
    'lbl_ransomware_indicator',
    'lbl_phishing_attempt',
    'lbl_malware_vector',
    'lbl_obfuscation_detected',
    'lbl_urgency_tactic',
    'lbl_domain_mismatch',
    'lbl_suspicious_domain',
]

SEVERITY_LEVELS = ['critical', 'high', 'medium', 'low', 'info']

DESIRED_FEATURES = [
    'auth_failures', 'spf_fail', 'dkim_fail', 'dmarc_fail',
    'subject_length', 'body_length', 'urgency_signal_score',
    'language_anomaly_score', 'obfuscation_score',
    'url_count', 'malicious_url_ratio',
    'attachment_count', 'suspicious_attachment_ratio',
    'macro_enabled_attachment', 'sender_domain_suspicious',
    'url_domain_mismatch',
    'domain_reputation_score', 'domain_age_days',
    'sender_baseline_deviation', 'content_complexity_score'
]


def evaluate_models(model_dir='ml/model', eval_data_dir='data/evaluation_dataset') -> Dict[str, Any]:
    """
    Evaluate both threat detection and severity prediction models

    Orchestrates complete evaluation pipeline:
    1. Load trained models and preprocessors
    2. Evaluate threat detection model on test dataset
    3. Evaluate severity prediction model on test dataset
    4. Return comprehensive evaluation metrics for both models

    Args:
        model_dir: Directory containing trained models and artifacts
        eval_data_dir: Directory containing evaluation datasets

    Returns:
        Dictionary with evaluation results for both models
    """
    # Load models - inline logic
    threat_model = None
    severity_model = None
    threat_scaler = None
    severity_scaler = None
    threat_mlb = None
    severity_encoder = None

    try:
        # Load threat detection model
        with open(f"{model_dir}/threat_detection_model.pkl", 'rb') as f:
            threat_model = pickle.load(f)
        with open(f"{model_dir}/threat_detection_scaler.pkl", 'rb') as f:
            threat_scaler = pickle.load(f)
        with open(f"{model_dir}/threat_indicators_mlb.pkl", 'rb') as f:
            threat_mlb = pickle.load(f)

        # Load severity prediction model
        with open(f"{model_dir}/severity_prediction_model.pkl", 'rb') as f:
            severity_model = pickle.load(f)
        with open(f"{model_dir}/severity_prediction_scaler.pkl", 'rb') as f:
            severity_scaler = pickle.load(f)
        with open(f"{model_dir}/severity_level_encoder.pkl", 'rb') as f:
            severity_encoder = pickle.load(f)

        logger.info("Models loaded successfully!")
    except Exception as e:
        logger.error(f"Failed to load models: {str(e)}")
        return {"error": "Failed to load models"}

    # Evaluate threat detection - inline logic
    threat_eval_results = {}
    try:
        logger.info("Evaluating threat detection model...")

        eval_path = Path(eval_data_dir) / "threat_detection_evaluation.csv"
        if not eval_path.exists():
            threat_eval_results = {"error": f"Evaluation dataset not found: {eval_path}"}
        else:
            eval_df = pd.read_csv(eval_path)
            logger.info(f"Loaded {len(eval_df)} evaluation samples for threat detection")

            # Prepare features
            feature_cols = [col for col in DESIRED_FEATURES if col in eval_df.columns]
            if len(feature_cols) < 5:
                numeric_cols = eval_df.select_dtypes(include=['number']).columns.tolist()
                feature_cols = [col for col in numeric_cols if 'lbl_' not in col and col not in ['threat_category']]

            X_eval = eval_df[feature_cols]

            # Prepare labels (multi-label)
            indicator_cols = [col for col in THREAT_INDICATORS if col in eval_df.columns]
            if indicator_cols:
                y_indicators = eval_df[indicator_cols].apply(
                    lambda x: [col for col in indicator_cols if x[col]], axis=1
                ).values
            else:
                y_indicators = np.array([[] for _ in range(len(eval_df))])

            # Scale features
            X_eval_scaled = threat_scaler.transform(X_eval)

            # Make predictions
            y_pred = threat_model.predict(X_eval_scaled)

            # Convert y_indicators to binary format for comparison
            y_indicators_binary = np.zeros((len(y_indicators), len(indicator_cols)), dtype=int)
            for i, indicators in enumerate(y_indicators):
                for j, indicator in enumerate(indicator_cols):
                    if indicator in indicators:
                        y_indicators_binary[i, j] = 1

            # Calculate metrics per indicator
            report = {}
            for i, indicator in enumerate(indicator_cols):
                y_true_indicator = y_indicators_binary[:, i]
                y_pred_indicator = y_pred[:, i]

                if len(np.unique(y_true_indicator)) > 1:
                    precision = precision_score(y_true_indicator, y_pred_indicator, zero_division=0)
                    recall = recall_score(y_true_indicator, y_pred_indicator, zero_division=0)
                    f1 = f1_score(y_true_indicator, y_pred_indicator, zero_division=0)
                else:
                    precision = recall = f1 = 0.0

                report[indicator] = {
                    'precision': float(precision),
                    'recall': float(recall),
                    'f1': float(f1),
                    'support': int(np.sum(y_true_indicator))
                }

            # Overall accuracy
            overall_accuracy = np.mean([
                np.array_equal(y_indicators_binary[i], y_pred[i])
                for i in range(len(y_indicators_binary))
            ])

            threat_eval_results = {
                "status": "success",
                "evaluation_samples": len(eval_df),
                "overall_accuracy": float(overall_accuracy),
                "per_indicator_metrics": report,
                "indicators_evaluated": len(indicator_cols)
            }

    except Exception as e:
        logger.error(f"Threat detection evaluation failed: {str(e)}")
        threat_eval_results = {"error": str(e)}

    # Evaluate severity prediction - inline logic
    severity_eval_results = {}
    try:
        logger.info("Evaluating severity prediction model...")

        eval_path = Path(eval_data_dir) / "severity_evaluation.csv"
        if not eval_path.exists():
            severity_eval_results = {"error": f"Evaluation dataset not found: {eval_path}"}
        else:
            eval_df = pd.read_csv(eval_path)
            logger.info(f"Loaded {len(eval_df)} evaluation samples for severity prediction")

            # Prepare features
            feature_cols = [col for col in DESIRED_FEATURES if col in eval_df.columns]
            if len(feature_cols) < 5:
                numeric_cols = eval_df.select_dtypes(include=['number']).columns.tolist()
                feature_cols = [col for col in numeric_cols if 'severity_level' not in col and 'risk_score' not in col]

            X_eval = eval_df[feature_cols]

            # Prepare labels
            if 'severity_level' in eval_df.columns:
                y_eval = eval_df['severity_level'].values
            elif 'risk_score' in eval_df.columns:
                # Convert risk score to severity level - inline logic
                scores = eval_df['risk_score'].values
                severities = np.array(['info'] * len(scores))
                severities[scores >= 80] = 'critical'
                severities[(scores >= 60) & (scores < 80)] = 'high'
                severities[(scores >= 40) & (scores < 60)] = 'medium'
                severities[(scores >= 20) & (scores < 40)] = 'low'
                y_eval = severities
            else:
                severity_eval_results = {"error": "No severity labels found in evaluation dataset"}
                y_eval = None

            if y_eval is not None:
                # Scale features
                X_eval_scaled = severity_scaler.transform(X_eval)

                # Make predictions
                y_pred_encoded = severity_model.predict(X_eval_scaled)
                y_pred = severity_encoder.inverse_transform(y_pred_encoded)

                # Calculate metrics
                accuracy = accuracy_score(y_eval, y_pred)
                report_dict = classification_report(y_eval, y_pred, output_dict=True)

                # Weighted metrics
                precision_weighted = precision_score(y_eval, y_pred, average='weighted', zero_division=0)
                recall_weighted = recall_score(y_eval, y_pred, average='weighted', zero_division=0)
                f1_weighted = f1_score(y_eval, y_pred, average='weighted', zero_division=0)

                # Per-class metrics
                per_class_metrics = {}
                for severity_level in SEVERITY_LEVELS:
                    if severity_level in report_dict:
                        per_class_metrics[severity_level] = report_dict[severity_level]

                severity_eval_results = {
                    "status": "success",
                    "evaluation_samples": len(eval_df),
                    "overall_accuracy": float(accuracy),
                    "weighted_metrics": {
                        "precision": float(precision_weighted),
                        "recall": float(recall_weighted),
                        "f1": float(f1_weighted)
                    },
                    "per_class_metrics": per_class_metrics
                }

    except Exception as e:
        logger.error(f"Severity prediction evaluation failed: {str(e)}")
        severity_eval_results = {"error": str(e)}

    results = {
        "threat_detection": threat_eval_results,
        "severity_prediction": severity_eval_results,
        "evaluation_timestamp": pd.Timestamp.now().isoformat()
    }

    return results


def run_evaluation() -> Dict[str, Any]:
    """
    Run complete model evaluation (backward compatibility wrapper)

    Returns:
        Dictionary with evaluation results for both models
    """
    return evaluate_models()


if __name__ == "__main__":
    results = evaluate_models()
    print(json.dumps(results, indent=2))
