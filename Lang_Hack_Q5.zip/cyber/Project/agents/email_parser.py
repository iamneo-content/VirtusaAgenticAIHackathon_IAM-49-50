#!/usr/bin/env python3
"""
Email Parser Agent
Parses and normalizes email JSON structure with validation
"""

from typing import Dict, Any, List, Tuple
import json
import re
from datetime import datetime


class EmailParserAgent:
    """Parse, validate, and normalize email JSON structure"""

    REQUIRED_FIELDS = {
        "email_id": str,
        "from": str,
        "to": list,
        "subject": str,
        "date": str,
        "headers": dict,
        "body_text": str,
        "attachments": list,
        "urls": list,
        "threat_category": str,
        "severity_level": str,
        "indicators": list,
    }

    VALID_THREAT_CATEGORIES = [
        "phishing",
        "malware",
        "bec",
        "spam",
        "legitimate"
    ]

    VALID_SEVERITY_LEVELS = [
        "critical",
        "high",
        "medium",
        "low",
        "info"
    ]

    def __init__(self):
        self.errors: List[str] = []
        self.warnings: List[str] = []

    def parse_and_validate(self, email_json: Dict[str, Any]) -> Tuple[bool, Dict[str, Any], List[str], List[str]]:
        """
        Parse and validate email JSON structure

        Args:
            email_json: Raw email JSON data

        Returns:
            Tuple of (is_valid, parsed_email, errors, warnings)
        """
        self.errors = []
        self.warnings = []
        parsed_email = {}

        # Check required fields
        for field, field_type in self.REQUIRED_FIELDS.items():
            if field not in email_json:
                self.errors.append(f"Missing required field: {field}")
            elif not isinstance(email_json.get(field), field_type):
                self.errors.append(f"Invalid type for {field}: expected {field_type.__name__}, got {type(email_json.get(field)).__name__}")
            else:
                parsed_email[field] = email_json[field]

        # Validate threat category
        if "threat_category" in email_json and email_json["threat_category"] not in self.VALID_THREAT_CATEGORIES:
            self.warnings.append(f"Unknown threat category: {email_json['threat_category']}")

        # Validate severity level
        if "severity_level" in email_json and email_json["severity_level"] not in self.VALID_SEVERITY_LEVELS:
            self.warnings.append(f"Unknown severity level: {email_json['severity_level']}")

        # Validate email format using inline regex
        email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        if "from" in email_json and not re.match(email_pattern, email_json["from"]):
            self.warnings.append(f"Invalid sender email format: {email_json['from']}")

        if "to" in email_json:
            for to_addr in email_json["to"]:
                if not re.match(email_pattern, to_addr):
                    self.warnings.append(f"Invalid recipient email format: {to_addr}")

        # Validate headers
        if "headers" in email_json:
            for hfield in ["spf", "dkim", "dmarc"]:
                if hfield not in email_json["headers"]:
                    self.warnings.append(f"Missing email header field: {hfield}")

        # Extract URLs from body using inline regex
        extracted_urls = []
        if "body_text" in email_json:
            text = email_json["body_text"]
            url_pattern = r'https?://(?:www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_\+.~#?&/=]*)'
            matches = re.findall(url_pattern, text)
            seen = set()
            for url in matches:
                if url not in seen:
                    seen.add(url)
                    extracted_urls.append(url)

        # Validate and merge URLs
        provided_urls = email_json.get("urls", [])
        for url in provided_urls:
            if not isinstance(url, str):
                self.errors.append(f"URL must be string, got {type(url).__name__}")
            elif not url.startswith(("http://", "https://")):
                self.warnings.append(f"URL missing protocol: {url}")

        all_urls = list(set(provided_urls + extracted_urls))
        parsed_email["urls"] = all_urls

        # Validate attachments
        if "attachments" in email_json:
            for att in email_json["attachments"]:
                if not isinstance(att, dict):
                    self.errors.append(f"Attachment must be dict, got {type(att).__name__}")
                elif "filename" not in att or "mime" not in att:
                    self.errors.append("Attachment missing filename or mime type")

        is_valid = len(self.errors) == 0
        return is_valid, parsed_email, self.errors, self.warnings

    def extract_headers(self, email_json: Dict[str, Any]) -> Dict[str, Any]:
        """
        Extract and normalize email headers

        Args:
            email_json: Email data

        Returns:
            Normalized headers dictionary
        """
        headers = email_json.get("headers", {})

        normalized = {
            "spf_result": headers.get("spf", "unknown"),
            "dkim_result": headers.get("dkim", "unknown"),
            "dmarc_result": headers.get("dmarc", "unknown"),
            "received_path": headers.get("received_path", "unknown"),
        }

        # Map results to binary auth failure indicators
        normalized["auth_failed"] = any(
            result in ["fail", "softfail", "none"]
            for result in [
                normalized["spf_result"],
                normalized["dkim_result"],
                normalized["dmarc_result"]
            ]
        )

        return normalized

    def extract_metadata(self, email_json: Dict[str, Any]) -> Dict[str, Any]:
        """
        Extract email metadata

        Args:
            email_json: Email data

        Returns:
            Metadata dictionary
        """
        return {
            "email_id": email_json.get("email_id"),
            "from": email_json.get("from"),
            "to": email_json.get("to", []),
            "subject": email_json.get("subject"),
            "date": email_json.get("date"),
            "filename": email_json.get("filename", "unknown"),
            "url_count": len(email_json.get("urls", [])),
            "attachment_count": len(email_json.get("attachments", [])),
        }

