#!/usr/bin/env python3
"""
Threat Intelligence LLM Agent
Analyzes threat intelligence, campaigns, MITRE techniques, and threat actors using Gemini 2.0 Flash
"""

from typing import Dict, Any, List, Tuple
import json


class ThreatIntelligenceLLMAgent:
    """
    Analyze threat intelligence: correlate campaigns, map MITRE techniques,
    identify threat actors. Uses Gemini 2.0 Flash for advanced analysis.
    """

    MITRE_TECHNIQUES = [
        "T1566.001",  # Phishing: Spearphishing Attachment
        "T1566.002",  # Phishing: Spearphishing Link
        "T1598.003",  # Phishing: Spearphishing Link
        "T1591",      # Gather Victim Org Info
        "T1598",      # Phishing for Information
        "T1195",      # Supply Chain Compromise
        "T1200",      # Hardware Additions
        "T1204.001",  # User Execution: Malicious Link
        "T1204.002",  # User Execution: Malicious File
    ]

    def __init__(self, client):
        """
        Initialize threat intelligence agent

        Args:
            client: Gemini API client (GeminiClient instance)
        """
        self.client = client
        self.threat_actor_db = {
            "Lazarus Group": ["North Korea", "APT38"],
            "APT28": ["Russia", "Fancy Bear"],
            "FIN7": ["Unknown", "Carbanak"],
            "Emotet": ["Botnet", "Banking Trojan"],
        }

    def analyze_threat_intelligence(
        self,
        email_data: Dict[str, Any],
        threat_indicators: List[str],
        intent: str
    ) -> Tuple[List[str], List[str], str, Dict[str, Any]]:
        """
        Analyze threat intelligence aspects

        Args:
            email_data: Email data
            threat_indicators: Detected threat indicators
            intent: Classified intent

        Returns:
            Tuple of (campaigns, mitre_techniques, actor_attribution, analysis)

        Raises:
            ValueError: If LLM client is not initialized
        """
        if self.client is None:
            raise ValueError("LLM client not initialized. Cannot analyze threat intelligence without Gemini API client.")

        prompt = f"""Analyze this email for threat intelligence indicators.

Email From: {email_data.get('from', 'unknown')}
Subject: {email_data.get('subject', '')}
Threat Category: {email_data.get('threat_category', '')}
Detected Intent: {intent}
Threat Indicators: {', '.join(threat_indicators)}

Provide:
1. Potential threat campaigns (known campaigns this matches)
2. MITRE ATT&CK techniques used
3. Possible threat actor attribution

Respond with JSON:
{{
    "campaigns": ["campaign1", "campaign2"],
    "mitre_techniques": ["T1566.001", "T1204.002"],
    "threat_actor": "actor_name or unknown",
    "confidence": 0.0-1.0
}}"""

        message = self.client.messages_create(
            max_tokens=500,
            messages=[{"role": "user", "content": prompt}]
        )
        response_text = message.content[0].text

        # Extract JSON from markdown code blocks if present
        if "```" in response_text:
            # Extract content between triple backticks
            parts = response_text.split("```")
            if len(parts) >= 2:
                response_text = parts[1]
                # Remove language identifier if present (e.g., ```json)
                if response_text.startswith("json"):
                    response_text = response_text[4:]
                response_text = response_text.strip()

        result = json.loads(response_text)

        return (
            result.get("campaigns", []),
            result.get("mitre_techniques", []),
            result.get("threat_actor", "unknown"),
            {"model": "gemini-2.0-flash", "confidence": result.get("confidence", 0.6)}
        )
