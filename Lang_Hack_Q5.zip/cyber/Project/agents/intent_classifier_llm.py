#!/usr/bin/env python3
"""
Intent Classifier LLM Agent for CyberSentinel
Classifies email intent using Gemini 2.0 Flash
"""

from typing import Dict, Any, Tuple
import json


class IntentClassifierLLMAgent:
    """
    Classify email intent: credential harvesting, malware distribution, financial fraud, etc.
    Uses Gemini 2.0 Flash to understand attacker motivation
    """

    KNOWN_INTENTS = [
        "credential_harvesting",
        "malware_distribution",
        "financial_fraud",
        "data_exfiltration",
        "account_takeover",
        "social_engineering",
        "business_email_compromise",
        "ransomware_deployment",
        "brand_impersonation",
        "tech_support_scam",
        "unknown"
    ]

    def __init__(self, client):
        """
        Initialize intent classifier

        Args:
            client: Gemini API client (GeminiClient instance)
        """
        self.client = client

    def classify_intent(self, email_data: Dict[str, Any]) -> Tuple[str, float, Dict[str, Any]]:
        """
        Classify the attacker's intent behind the email

        Args:
            email_data: Parsed email data

        Returns:
            Tuple of (detected_intent, confidence, analysis)

        Raises:
            ValueError: If LLM client is not initialized
        """
        if self.client is None:
            raise ValueError("LLM client not initialized. Cannot classify intent without Gemini API client.")

        subject = email_data.get("subject", "")
        body = email_data.get("body_text", "")
        threat_category = email_data.get("threat_category", "unknown")

        prompt = f"""Analyze the following email and determine the attacker's intent.

Email Subject: {subject}
Email Body: {body}
Threat Category: {threat_category}

Possible intents:
- credential_harvesting: Attempting to steal login credentials
- malware_distribution: Distributing malware or trojans
- financial_fraud: Attempting financial theft
- data_exfiltration: Attempting to steal data
- account_takeover: Attempting to compromise accounts
- social_engineering: Using manipulation tactics
- business_email_compromise: Impersonating executives
- ransomware_deployment: Deploying ransomware
- brand_impersonation: Impersonating legitimate brands
- tech_support_scam: Fake support request
- unknown: Unable to determine

Respond with JSON:
{{
    "intent": "detected_intent",
    "confidence": 0.0-1.0,
    "reasoning": "explanation"
}}"""

        try:
            message = self.client.messages_create(
                max_tokens=500,
                messages=[{"role": "user", "content": prompt}]
            )

            # Check if response has content
            if not message.content or len(message.content) == 0:
                raise ValueError("Empty response from API - likely blocked by safety filters")

            response_text = message.content[0].text

            # Check if response text is empty
            if not response_text or response_text.strip() == "":
                raise ValueError("Empty response text from API")

            # Extract JSON from markdown code blocks if present
            if "```" in response_text:
                # Extract content between triple backticks
                parts = response_text.split("```")
                if len(parts) >= 2:
                    response_text = parts[1]
                    # Remove language identifier if present (e.g., ```json)
                    if response_text.startswith("json"):
                        response_text = response_text[4:]
                    response_text = response_text.strip()

            result = json.loads(response_text)

            intent = result.get("intent", "unknown")
            if intent not in self.KNOWN_INTENTS:
                intent = "unknown"

            return intent, result.get("confidence", 0.5), {
                "reasoning": result.get("reasoning", ""),
                "model": "gemini-2.0-flash"
            }
        except (ValueError, KeyError, json.JSONDecodeError, AttributeError, IndexError) as e:
            # Return default response if API fails
            raise ValueError(f"Intent classification API error: {str(e)}")
