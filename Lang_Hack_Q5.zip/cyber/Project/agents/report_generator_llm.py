#!/usr/bin/env python3
"""
Report Generator LLM Agent
Generates comprehensive security reports and analysis using Gemini 2.0 Flash
"""

from typing import Dict, Any, Tuple
import json


class ReportGeneratorLLMAgent:
    """
    Generate comprehensive security report with findings and recommendations
    Uses Gemini 2.0 Flash for professional report generation
    """

    def __init__(self, client):
        """
        Initialize report generator

        Args:
            client: Gemini API client (GeminiClient instance)
        """
        self.client = client

    def generate_report(self, analysis_state: Dict[str, Any]) -> Tuple[str, Dict[str, Any], Dict[str, float]]:
        """
        Generate comprehensive threat analysis report

        Args:
            analysis_state: Complete analysis state

        Returns:
            Tuple of (report_text, report_json, quality_metrics)

        Raises:
            ValueError: If LLM client is not initialized
        """
        if self.client is None:
            raise ValueError("LLM client not initialized. Cannot generate report without Gemini API client.")

        prompt = f"""Generate a professional security report for this email threat analysis.

Email ID: {analysis_state.get('email_id', 'unknown')}
Sender: {analysis_state.get('email_json', {}).get('from', 'unknown')}
Subject: {analysis_state.get('email_json', {}).get('subject', 'unknown')}
Threat Category: {analysis_state.get('threat_category_predicted', 'unknown')}
Severity Level: {analysis_state.get('predicted_severity_level', 'unknown')}
Threat Indicators: {', '.join(analysis_state.get('threat_indicators', []))}
Detected Intent: {analysis_state.get('detected_intent', 'unknown')}
Risk Score: {analysis_state.get('risk_score', 0)}

Generate a professional report with:
1. Executive Summary
2. Threat Analysis
3. Risk Assessment
4. Recommended Actions

Keep the report concise but comprehensive."""

        message = self.client.messages_create(
            max_tokens=1000,
            messages=[{"role": "user", "content": prompt}]
        )
        report_text = message.content[0].text

        # Structure report as JSON
        report_json = {
            "email_id": analysis_state.get("email_id"),
            "threat_category": analysis_state.get("threat_category_predicted"),
            "severity_level": analysis_state.get("predicted_severity_level"),
            "risk_score": analysis_state.get("risk_score", 0),
            "threat_indicators": analysis_state.get("threat_indicators", []),
            "detected_intent": analysis_state.get("detected_intent"),
            "recommended_actions": analysis_state.get("recommended_actions", []),
            "report_text": report_text
        }

        # Compute quality metrics
        parsing_completeness = 1.0 if analysis_state.get("parsing_complete") else 0.5
        threat_confidence = analysis_state.get("threat_confidence_scores", {})
        threat_detection_accuracy = max(threat_confidence.values()) if threat_confidence else 0.0
        severity_confidence = analysis_state.get("severity_confidence", 0.0)
        intent_confidence = analysis_state.get("intent_confidence", 0.0)
        has_threat_intel = bool(analysis_state.get("threat_intelligence", {})) and bool(analysis_state.get("mitre_techniques", []))
        intelligence_quality = 0.9 if has_threat_intel else 0.6
        has_recommendations = bool(analysis_state.get("recommended_actions", []))
        recommendation_quality = 0.9 if has_recommendations else 0.6
        report_quality = min(1.0, len(report_text) / 500) if report_text else 0.5
        overall_rating = (
            parsing_completeness * 0.15 +
            threat_detection_accuracy * 0.20 +
            severity_confidence * 0.15 +
            intent_confidence * 0.15 +
            intelligence_quality * 0.15 +
            recommendation_quality * 0.10 +
            report_quality * 0.10
        )

        quality_metrics = {
            "parsing_completeness": parsing_completeness,
            "threat_detection_accuracy": threat_detection_accuracy,
            "severity_confidence": severity_confidence,
            "intent_clarity": intent_confidence,
            "intelligence_quality": intelligence_quality,
            "recommendation_quality": recommendation_quality,
            "report_quality": report_quality,
            "overall_security_rating": overall_rating
        }

        return report_text, report_json, quality_metrics
