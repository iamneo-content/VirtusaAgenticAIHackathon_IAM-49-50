#!/usr/bin/env python3
"""
Email Analyzer Agent
Extracts and computes threat-relevant features from parsed emails
"""

from typing import Dict, Any, List
import re
from urllib.parse import urlparse


class EmailAnalyzerAgent:
    """Extract and compute threat-relevant features from email"""

    def __init__(self):
        self.known_malware_patterns = [
            r"\.exe\b",
            r"\.bat\b",
            r"\.cmd\b",
            r"\.scr\b",
            r"\.pif\b",
            r"\.docm\b",
            r"\.xlsm\b",
            r"\.pptm\b",
        ]

        self.suspicious_keywords = [
            "verify", "confirm", "authenticate", "validate", "urgent",
            "immediate", "action required", "suspended", "locked",
            "click here", "update payment", "confirm identity",
            "malware", "ransomware", "attack", "breach", "hack"
        ]

    def analyze_email(self, parsed_email: Dict[str, Any], headers_normalized: Dict[str, Any]) -> Dict[str, Any]:
        """
        Comprehensive email analysis for threat detection

        Args:
            parsed_email: Parsed email dictionary
            headers_normalized: Normalized email headers

        Returns:
            Analysis results dictionary
        """
        # Analyze headers
        header_features = {
            "auth_failed": headers_normalized.get("auth_failed", False),
            "spf_fail": headers_normalized.get("spf_result") in ["fail", "softfail"],
            "dkim_fail": headers_normalized.get("dkim_result") in ["fail", "none"],
            "dmarc_fail": headers_normalized.get("dmarc_result") == "fail",
            "received_path_hops": len(headers_normalized.get("received_path", "").split("->"))
        }

        # Analyze content
        subject = parsed_email.get("subject", "").lower()
        body = parsed_email.get("body_text", "").lower()
        combined = f"{subject} {body}"
        urgent_keywords = ["urgent", "immediate", "action required", "suspend", "confirm", "verify"]
        urgency_count = sum(1 for kw in urgent_keywords if kw in combined)
        urgency_score = min(urgency_count / 3.0, 1.0)
        special_char_ratio = len(re.findall(r'[!@#$%^&*()_+=\[\]{};:\'",.<>?/\\|-]', combined)) / max(len(combined), 1)
        language_anomaly = min(special_char_ratio * 2, 1.0)
        multiple_spaces = len(re.findall(r'\s{2,}', combined))
        obfuscation_score = min(multiple_spaces / 10.0, 1.0)
        content_features = {
            "urgency_signal_score": urgency_score,
            "language_anomaly_score": language_anomaly,
            "obfuscation_score": obfuscation_score,
            "contains_links": "href=" in parsed_email.get("body_html", ""),
            "contains_images": "img" in parsed_email.get("body_html", "").lower(),
        }

        # Analyze URLs
        urls = parsed_email.get("urls", [])
        sender = parsed_email.get("from", "")
        sender_domain = ""
        if "@" in sender:
            sender_domain = sender.split("@")[1].lower()
        else:
            try:
                parsed = urlparse(sender)
                sender_domain = parsed.netloc.lower()
            except:
                sender_domain = ""

        suspicious_urls = []
        if urls:
            for url in urls:
                url_lower = url.lower()
                suspicious_patterns = [r"\.exe\b", r"\.zip\b", r"phishing", r"malware", r"trojan", r"ransomware", r"bit\.ly", r"short\.link", r"tinyurl", r"goo\.gl"]
                if any(re.search(pattern, url_lower) for pattern in suspicious_patterns):
                    suspicious_urls.append(url)

        url_features = {
            "total_urls": len(urls),
            "suspicious_urls": suspicious_urls,
            "malicious_url_ratio": len(suspicious_urls) / len(urls) if urls else 0.0,
            "url_domain_mismatch": any(
                (url.split("@")[1].lower() if "@" in url else (urlparse(url).netloc.lower() if url.startswith(("http://", "https://")) else "")) != sender_domain
                for url in urls
            ) if sender_domain else False,
        }

        # Analyze attachments
        attachments = parsed_email.get("attachments", [])
        suspicious_attachments = []
        suspicious_count = 0
        macro_enabled = False
        has_executable = False
        suspicious_extensions = [".exe", ".bat", ".cmd", ".scr", ".pif", ".docm", ".xlsm", ".pptm", ".vbs", ".js", ".ps1", ".dll"]
        suspicious_mimes = ["application/x-msdownload", "application/x-msdos-program", "application/x-executable", "application/octet-stream"]

        for att in attachments:
            filename = att.get("filename", "").lower()
            mime = att.get("mime", "").lower()
            if any(ext in filename for ext in suspicious_extensions) or any(mime_type in mime for mime_type in suspicious_mimes):
                suspicious_count += 1
                suspicious_attachments.append(att.get("filename", "unknown"))
                if any(pattern in filename for pattern in [".docm", ".xlsm", ".pptm"]):
                    macro_enabled = True
                if any(pattern in filename for pattern in [".exe", ".bat", ".cmd", ".scr", ".pif"]):
                    has_executable = True

        attachment_features = {
            "total_attachments": len(attachments),
            "suspicious_attachments": suspicious_attachments,
            "suspicious_attachment_ratio": suspicious_count / len(attachments) if attachments else 0.0,
            "has_macro_enabled": macro_enabled,
            "has_executable": has_executable,
        }

        # Analyze domains
        domain_suspicious_patterns = [r"^[a-z0-9]*\d[a-z]*\.com", r"^[a-z]*\d+[a-z]*\.", r"^(secure|verify|update|confirm)[-\.]"]
        domain_suspicious = any(re.match(pattern, sender_domain, re.IGNORECASE) for pattern in domain_suspicious_patterns) if sender_domain else False
        domain_features = {
            "sender_domain": sender_domain,
            "sender_domain_suspicious": domain_suspicious,
            "url_domain_mismatch": any(
                (url.split("@")[1].lower() if "@" in url else (urlparse(url).netloc.lower() if url.startswith(("http://", "https://")) else "")) != sender_domain
                for url in urls
            ) if sender_domain else False,
        }

        return {
            "header_features": header_features,
            "content_features": content_features,
            "url_features": url_features,
            "attachment_features": attachment_features,
            "domain_features": domain_features,
        }

    def extract_numeric_features(self, parsed_email: Dict[str, Any], analysis: Dict[str, Any]) -> Dict[str, float]:
        """
        Extract numeric features for ML models

        Args:
            parsed_email: Parsed email
            analysis: Analysis results

        Returns:
            Dictionary of numeric features
        """
        features = {}

        # Header features
        features["auth_failures"] = float(1 if analysis["header_features"]["auth_failed"] else 0)
        features["spf_fail"] = float(1 if analysis["header_features"]["spf_fail"] else 0)
        features["dkim_fail"] = float(1 if analysis["header_features"]["dkim_fail"] else 0)
        features["dmarc_fail"] = float(1 if analysis["header_features"]["dmarc_fail"] else 0)

        # Content features
        features["subject_length"] = float(len(parsed_email.get("subject", "")))
        features["body_length"] = float(len(parsed_email.get("body_text", "")))
        features["urgency_signal_score"] = float(analysis["content_features"]["urgency_signal_score"])
        features["language_anomaly_score"] = float(analysis["content_features"]["language_anomaly_score"])
        features["obfuscation_score"] = float(analysis["content_features"]["obfuscation_score"])

        # URL features
        features["url_count"] = float(len(parsed_email.get("urls", [])))
        features["malicious_url_ratio"] = float(analysis["url_features"]["malicious_url_ratio"])

        # Attachment features
        features["attachment_count"] = float(len(parsed_email.get("attachments", [])))
        features["suspicious_attachment_ratio"] = float(analysis["attachment_features"]["suspicious_attachment_ratio"])
        features["macro_enabled_attachment"] = float(
            1 if analysis["attachment_features"]["has_macro_enabled"] else 0
        )

        # Domain features
        features["sender_domain_suspicious"] = float(
            1 if analysis["domain_features"]["sender_domain_suspicious"] else 0
        )
        features["url_domain_mismatch"] = float(
            1 if analysis["domain_features"]["url_domain_mismatch"] else 0
        )

        return features

