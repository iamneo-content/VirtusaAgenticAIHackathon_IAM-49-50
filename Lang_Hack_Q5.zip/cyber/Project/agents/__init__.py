#!/usr/bin/env python3
"""
CyberSentinel Agents Module
Imports all agent classes for use in workflow
"""

from agents.email_parser import EmailParserAgent
from agents.email_analyzer import EmailAnalyzerAgent
from agents.threat_detection_ml import ThreatDetectionMLAgent
from agents.severity_prediction_ml import SeverityPredictionMLAgent
from agents.intent_classifier_llm import IntentClassifierLLMAgent
from agents.threat_intelligence_llm import ThreatIntelligenceLLMAgent
from agents.recommendation_generator_llm import RecommendationGeneratorLLMAgent
from agents.report_generator_llm import ReportGeneratorLLMAgent

__all__ = [
    "EmailParserAgent",
    "EmailAnalyzerAgent",
    "ThreatDetectionMLAgent",
    "SeverityPredictionMLAgent",
    "IntentClassifierLLMAgent",
    "ThreatIntelligenceLLMAgent",
    "RecommendationGeneratorLLMAgent",
    "ReportGeneratorLLMAgent",
]
