#!/usr/bin/env python3
"""
Recommendation Generator LLM Agent
Generates security recommendations and remediation steps using Gemini 2.0 Flash
"""

from typing import Dict, Any, List, Tuple
import json


class RecommendationGeneratorLLMAgent:
    """
    Generate security recommendations and remediation steps
    Uses Gemini 2.0 Flash for contextual advice
    """

    def __init__(self, client):
        """
        Initialize recommendation generator

        Args:
            client: Gemini API client (GeminiClient instance)
        """
        self.client = client

    def generate_recommendations(
        self,
        threat_category: str,
        severity_level: str,
        threat_indicators: List[str],
        intent: str
    ) -> Tuple[List[str], List[str], str, Dict[str, Any]]:
        """
        Generate security recommendations

        Args:
            threat_category: Email threat category
            severity_level: Predicted severity level
            threat_indicators: Detected threat indicators
            intent: Classified intent

        Returns:
            Tuple of (actions, remediation_steps, user_notification, analysis)

        Raises:
            ValueError: If LLM client is not initialized
        """
        if self.client is None:
            raise ValueError("LLM client not initialized. Cannot generate recommendations without Gemini API client.")

        prompt = f"""Generate security recommendations for this detected threat.

Threat Category: {threat_category}
Severity Level: {severity_level}
Threat Indicators: {', '.join(threat_indicators)}
Attacker Intent: {intent}

Provide:
1. Immediate actions to take
2. Remediation and investigation steps
3. User notification message (keep concise)

Respond with JSON:
{{
    "actions": ["action1", "action2"],
    "remediation": ["step1", "step2"],
    "user_message": "notification text"
}}"""

        message = self.client.messages_create(
            max_tokens=600,
            messages=[{"role": "user", "content": prompt}]
        )
        response_text = message.content[0].text

        # Extract JSON from markdown code blocks if present
        if "```" in response_text:
            # Extract content between triple backticks
            parts = response_text.split("```")
            if len(parts) >= 2:
                response_text = parts[1]
                # Remove language identifier if present (e.g., ```json)
                if response_text.startswith("json"):
                    response_text = response_text[4:]
                response_text = response_text.strip()

        result = json.loads(response_text)

        return (
            result.get("actions", []),
            result.get("remediation", []),
            result.get("user_message", ""),
            {"model": "gemini-2.0-flash"}
        )
