#!/usr/bin/env python3
"""
Severity Prediction ML Agent

Multi-class severity level prediction using trained ML model
Predicts severity level and risk score for detected threats
"""

from typing import Dict, Any, Tuple, List
import numpy as np
import pandas as pd
from pathlib import Path
import pickle


class SeverityPredictionMLAgent:
    """Multi-class severity prediction with confidence and risk assessment"""

    # Feature columns expected by the model
    FEATURE_COLUMNS = [
        "threat_category_encoded",
        "auth_failures", "spf_fail", "dkim_fail", "dmarc_fail",
        "subject_length", "body_length", "urgency_signal_score",
        "language_anomaly_score", "obfuscation_score",
        "url_count", "malicious_url_ratio",
        "attachment_count", "suspicious_attachment_ratio",
        "macro_enabled_attachment", "sender_domain_suspicious",
        "url_domain_mismatch", "threat_indicator_count"
    ]

    # Severity levels
    SEVERITY_LEVELS = ["info", "low", "medium", "high", "critical"]

    # Threat category encoding
    THREAT_CATEGORY_ENCODING = {
        "legitimate": 0,
        "spam": 1,
        "phishing": 2,
        "bec": 3,
        "malware": 4
    }

    def __init__(self, model_path: str = None):
        """
        Initialize severity prediction agent

        Args:
            model_path: Path to pre-trained model pickle file (optional for demo)
        """
        self.model = None
        self.model_path = model_path
        self.feature_scaler = None

        if model_path and Path(model_path).exists():
            try:
                with open(model_path, 'rb') as f:
                    model_data = pickle.load(f)
                    if isinstance(model_data, dict):
                        self.model = model_data.get('model')
                        self.feature_scaler = model_data.get('scaler')
                    else:
                        self.model = model_data
                        self.feature_scaler = None
            except Exception as e:
                raise ValueError(f"Failed to load model from {model_path}: {e}")

    def predict_severity(
        self,
        features: Dict[str, float],
        threat_indicators: List[str],
        threat_category: str
    ) -> Tuple[str, float, float]:
        """
        Predict severity level and compute risk score

        Args:
            features: Dictionary of numeric email features
            threat_indicators: List of detected threat indicators
            threat_category: Primary threat category

        Returns:
            Tuple of (severity_level, confidence_score, risk_score)

        Raises:
            ValueError: If ML model is not loaded or prediction fails
        """
        if self.model is None:
            raise ValueError("ML model not loaded. Cannot predict severity without trained model.")

        try:
            # Prepare features with threat category encoding
            feature_values = []
            category_code = self.THREAT_CATEGORY_ENCODING.get(threat_category.lower(), 0)
            feature_values.append(float(category_code))

            standard_features = ["auth_failures", "spf_fail", "dkim_fail", "dmarc_fail", "subject_length", "body_length", "urgency_signal_score", "language_anomaly_score", "obfuscation_score", "url_count", "malicious_url_ratio"]
            for col in standard_features:
                value = features.get(col, 0.0)
                if not isinstance(value, (int, float)):
                    value = 0.0
                feature_values.append(float(value))
            feature_array = np.array(feature_values)

            # Scale features if scaler available
            if self.feature_scaler:
                feature_array = self.feature_scaler.transform(feature_array.reshape(1, -1))
            else:
                feature_array = feature_array.reshape(1, -1)

            # Get predictions and probabilities
            prediction = self.model.predict(feature_array)[0]
            probabilities = self.model.predict_proba(feature_array)[0] if hasattr(self.model, 'predict_proba') else None

            # Map prediction to severity level
            severity_level = self.SEVERITY_LEVELS[int(prediction)]
            confidence = float(probabilities[int(prediction)]) if probabilities is not None else 0.75

            # Calculate risk score
            severity_scores = {"info": 10, "low": 25, "medium": 50, "high": 75, "critical": 95}
            base_score = severity_scores.get(severity_level, 50)
            auth_failure_weight = features.get("auth_failures", 0) * 15
            malicious_url_weight = features.get("malicious_url_ratio", 0) * 20
            suspicious_attachment_weight = features.get("suspicious_attachment_ratio", 0) * 25
            macro_enabled_weight = features.get("macro_enabled_attachment", 0) * 30
            urgency_weight = features.get("urgency_signal_score", 0) * 10
            adjustments = auth_failure_weight + malicious_url_weight + suspicious_attachment_weight + macro_enabled_weight + urgency_weight
            indicator_bonus = min(len(threat_indicators) * 3, 20)
            risk_score = min(base_score + adjustments + indicator_bonus, 100.0)

            return severity_level, confidence, risk_score

        except Exception as e:
            raise ValueError(f"Severity prediction failed: {e}")


    def validate_features(self, features: Dict[str, float]) -> Tuple[bool, List[str]]:
        """
        Validate required features for severity prediction

        Args:
            features: Feature dictionary

        Returns:
            Tuple of (is_valid, error_messages)
        """
        errors = []

        # Check numeric features
        numeric_features = self.FEATURE_COLUMNS[1:]  # Skip encoded category
        for col in numeric_features:
            if col not in features:
                errors.append(f"Missing required feature: {col}")
            elif not isinstance(features[col], (int, float)):
                errors.append(f"Feature {col} must be numeric")

        return len(errors) == 0, errors

    @staticmethod
    def encode_threat_category(category: str) -> int:
        """Encode threat category to integer"""
        encoding = {
            "legitimate": 0,
            "spam": 1,
            "phishing": 2,
            "bec": 3,
            "malware": 4
        }
        return encoding.get(category.lower(), 0)

    @staticmethod
    def decode_severity_index(index: int) -> str:
        """Decode severity index to level"""
        if 0 <= index < len(SeverityPredictionMLAgent.SEVERITY_LEVELS):
            return SeverityPredictionMLAgent.SEVERITY_LEVELS[int(index)]
        return "unknown"
