#!/usr/bin/env python3
"""
Threat Detection ML Agent
Multi-label threat classification using trained ML model
Predicts threat indicators and overall threat category
"""

from typing import Dict, List, Tuple
import numpy as np
from pathlib import Path
import pickle


class ThreatDetectionMLAgent:
    """Multi-label threat classification with confidence scores"""

    # Feature columns expected by the ML model (in order)
    FEATURE_COLUMNS = [
        "auth_failures", "spf_fail", "dkim_fail", "dmarc_fail",
        "subject_length", "body_length", "urgency_signal_score",
        "language_anomaly_score", "obfuscation_score",
        "url_count", "malicious_url_ratio",
        "attachment_count", "suspicious_attachment_ratio",
        "macro_enabled_attachment", "sender_domain_suspicious", "url_domain_mismatch"
    ]

    # Threat labels (multi-label) - must match the model's training labels
    THREAT_LABELS = [
        "lbl_malicious_url_pattern",
        "lbl_spoofed_sender"
    ]

    def __init__(self, model_path: str = None):
        """
        Initialize threat detection agent

        Args:
            model_path: Path to pre-trained model pickle file (optional for demo)
        """
        self.model = None
        self.model_path = model_path
        self.feature_scaler = None

        if model_path and Path(model_path).exists():
            try:
                with open(model_path, 'rb') as f:
                    model_data = pickle.load(f)
                    if isinstance(model_data, dict):
                        self.model = model_data.get('model')
                        self.feature_scaler = model_data.get('scaler')
                    else:
                        self.model = model_data
                        self.feature_scaler = None
            except Exception as e:
                raise ValueError(f"Failed to load model from {model_path}: {e}")

    def predict_threats(self, features: Dict[str, float]) -> Tuple[List[str], Dict[str, float], str]:
        """
        Predict threat indicators and category

        Args:
            features: Dictionary of numeric features from email analysis

        Returns:
            Tuple of (threat_indicators, confidence_scores, primary_threat_category)

        Raises:
            ValueError: If ML model is not loaded or prediction fails
        """
        if self.model is None:
            raise ValueError("ML model not loaded. Cannot predict threats without trained model.")

        try:
            # Prepare features in correct order (use first 13 features)
            feature_values = []
            model_features = self.FEATURE_COLUMNS[:13]
            for col in model_features:
                value = features.get(col, 0.0)
                if not isinstance(value, (int, float)):
                    value = 0.0
                feature_values.append(float(value))
            feature_array = np.array(feature_values)

            # Scale features if scaler available
            if self.feature_scaler:
                feature_array = self.feature_scaler.transform(feature_array.reshape(1, -1))
            else:
                feature_array = feature_array.reshape(1, -1)

            # Get multi-label threat indicator predictions
            predictions = self.model.predict(feature_array)[0]

            # Build threat indicators and confidence scores
            threat_indicators = []
            confidence_scores = {}
            for i, label in enumerate(self.THREAT_LABELS):
                if predictions[i] == 1:
                    threat_indicators.append(label)
                    confidence_scores[label] = 0.75

            # Determine threat category based on indicators
            if not threat_indicators:
                threat_category = "legitimate"
            elif any(ind in threat_indicators for ind in ["lbl_spoofed_sender", "lbl_malicious_url_pattern"]):
                threat_category = "phishing"
            else:
                threat_category = "spam"

            return threat_indicators, confidence_scores, threat_category

        except Exception as e:
            raise ValueError(f"Threat prediction failed: {e}")


    def validate_features(self, features: Dict[str, float]) -> Tuple[bool, List[str]]:
        """
        Validate that required features are present

        Args:
            features: Feature dictionary

        Returns:
            Tuple of (is_valid, error_messages)
        """
        errors = []

        for col in self.FEATURE_COLUMNS[:13]:
            if col not in features:
                errors.append(f"Missing required feature: {col}")
            elif not isinstance(features[col], (int, float)):
                errors.append(f"Feature {col} must be numeric, got {type(features[col])}")

        return len(errors) == 0, errors
