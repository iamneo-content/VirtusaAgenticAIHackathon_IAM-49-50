#!/usr/bin/env python3
"""
CyberSentinel - Email Threat Detection & Analysis
Streamlit web interface for email security analysis
"""

import streamlit as st
import json
from pathlib import Path
from graph import analyze_email, get_threat_summary, get_risk_classification
import pandas as pd
from dotenv import load_dotenv
from utils.gemini_client import build_gemini_client
from ml.evaluation import run_evaluation


def load_sample_emails():
    """Load available sample emails"""
    sample_dir = Path("data/input/sample_emails")
    if sample_dir.exists():
        files = sorted([f.name for f in sample_dir.glob("mail*.json")])
        return {f.replace('.json', ''): f for f in files}
    return {}


def load_email(filename):
    """Load email from file"""
    sample_dir = Path("data/input/sample_emails")
    filepath = sample_dir / filename
    with open(filepath, 'r') as f:
        return json.load(f)


def render_header():
    """Render page header"""
    st.set_page_config(
        page_title="CyberSentinel - Email Threat Detection",
        page_icon="",
        layout="wide"
    )

    col1, col2 = st.columns([3, 1])
    with col1:
        st.markdown("# CyberSentinel")
        st.markdown("### Email Threat Detection & Intelligence Analysis")
    with col2:
        st.markdown("**Status:** Active")


def render_sidebar():
    """Render sidebar with email selection and model evaluation"""
    with st.sidebar:
        st.header("Email Selection")

        emails = load_sample_emails()
        if emails:
            selected = st.selectbox(
                "Select Sample Email",
                list(emails.keys()),
                help="Choose an email to analyze"
            )
        else:
            st.error("No sample emails found")
            return None

        st.divider()

        # Model Evaluation Section
        st.header("Model Evaluation")
        st.write("Evaluate ML models on evaluation dataset")

        if st.button("Run Model Evaluation", use_container_width=True, type="secondary"):
            with st.spinner("Evaluating models on evaluation dataset..."):
                try:
                    eval_results = run_evaluation()
                    st.session_state.eval_results = eval_results
                    st.success("Model evaluation complete!")
                except Exception as e:
                    st.error(f"Evaluation failed: {str(e)}")

        return selected


def render_email_preview(email_data):
    """Render email preview section"""
    with st.expander("Email Preview", expanded=True):
        col1, col2 = st.columns(2)

        with col1:
            st.write(f"**From:** {email_data.get('from', 'N/A')}")
            st.write(f"**To:** {', '.join(email_data.get('to', []))}")
            st.write(f"**Subject:** {email_data.get('subject', 'N/A')}")

        with col2:
            st.write(f"**Date:** {email_data.get('date', 'N/A')}")
            st.write(f"**Attachments:** {len(email_data.get('attachments', []))}")
            st.write(f"**URLs:** {len(email_data.get('urls', []))}")


def render_overview_tab(result, summary):
    """Render overview tab"""
    st.header("Threat Analysis Overview")

    severity = summary["severity_level"]
    severity_colors = {
        "critical": "",
        "high": "",
        "medium": "",
        "low": "",
        "info": ""
    }

    col1, col2, col3 = st.columns(3)

    with col1:
        st.metric(
            f"{severity_colors.get(severity, '')} Severity",
            severity.upper(),
            f"Risk: {summary['risk_score']:.0f}/100"
        )

    with col2:
        st.metric(
            "Threat Category",
            summary["threat_category"].upper(),
            f"{max(summary['confidence'].values(), default=0):.0%}"
        )

    with col3:
        st.metric(
            "Intent",
            summary.get("detected_intent", "unknown").upper()
        )

    st.divider()

    # Key findings
    st.subheader("Key Findings")
    col1, col2 = st.columns(2)

    with col1:
        st.write(f"**Threat Indicators:** {len(summary['threat_indicators'])}")
        st.write(f"**Risk Score:** {summary['risk_score']:.0f}/100")

    with col2:
        st.write(f"**Confidence:** {max(summary['confidence'].values(), default=0):.0%}")
        st.write(f"**Quality:** {result.get('quality_metrics', {}).get('overall_security_rating', 0):.0%}")


def render_threats_tab(summary):
    """Render threats tab"""
    st.header("Detected Threat Indicators")

    if summary["threat_indicators"]:
        st.info(f"**{len(summary['threat_indicators'])} threat indicators identified**")

        for i, indicator in enumerate(summary["threat_indicators"], 1):
            confidence = summary["confidence"].get(indicator, 0.0)
            col1, col2 = st.columns([3, 1])

            with col1:
                st.write(f"{i}. `{indicator}`")
            with col2:
                st.metric("", f"{confidence:.0%}", label_visibility="collapsed")

    else:
        st.success("No threat indicators detected")


def render_intelligence_tab(result, summary):
    """Render threat intelligence tab"""
    st.header("Threat Intelligence Analysis")

    col1, col2 = st.columns(2)

    with col1:
        st.subheader("Threat Actors")
        actors = result.get("threat_actors", [])
        if actors:
            for actor in actors:
                st.write(f"- {actor}")
        else:
            st.write("No known threat actors identified")

    with col2:
        st.subheader("MITRE ATT&CK Techniques")
        techniques = result.get("mitre_techniques", [])
        if techniques:
            for tech in techniques:
                st.write(f"- {tech}")
        else:
            st.write("No techniques mapped")

    st.divider()

    col1, col2 = st.columns(2)

    with col1:
        st.subheader("Related Campaigns")
        campaigns = result.get("correlated_campaigns", [])
        if campaigns:
            for campaign in campaigns:
                st.write(f"- {campaign}")
        else:
            st.write("No campaigns matched")

    with col2:
        st.subheader("Attribution")
        st.write(f"**Actor:** {result.get('threat_actor_attribution', 'Unknown')}")
        st.write(f"**Sophistication:** {result.get('sophistication_level', 'Unknown')}")


def render_recommendations_tab(result):
    """Render recommendations tab"""
    st.header("Recommended Actions")

    actions = result.get("recommended_actions", [])
    if actions:
        st.warning(f"**{len(actions)} action(s) recommended**")

        for i, action in enumerate(actions, 1):
            st.write(f"{i}. **{action}**")

    st.divider()

    col1, col2 = st.columns(2)

    with col1:
        st.subheader("Priority")
        priority = result.get("action_priority", "Medium")
        st.markdown(f"### {priority.upper()}")

    with col2:
        st.subheader("Escalation Level")
        escalation = result.get("escalation_level", "L1")
        st.markdown(f"### {escalation}")

    st.divider()

    if result.get("user_notification_template"):
        st.subheader("User Notification")
        st.info(result.get("user_notification_template"))


def render_metrics_tab(result):
    """Render security metrics tab"""
    st.header("Analysis Quality Metrics")

    metrics = result.get("quality_metrics", {})

    col1, col2, col3 = st.columns(3)

    with col1:
        st.metric("Parsing", f"{metrics.get('parsing_completeness', 0):.0%}")

    with col2:
        st.metric("Threat Detection", f"{metrics.get('threat_detection_accuracy', 0):.0%}")

    with col3:
        st.metric("Severity", f"{metrics.get('severity_confidence', 0):.0%}")

    col1, col2 = st.columns(2)

    with col1:
        st.metric("Intent", f"{metrics.get('intent_clarity', 0):.0%}")

    with col2:
        st.metric("Intelligence", f"{metrics.get('intelligence_quality', 0):.0%}")

    st.divider()

    overall = metrics.get("overall_security_rating", 0)
    st.markdown(f"### Overall Security Rating: {overall:.0%}")

    if overall >= 0.9:
        st.success("Excellent analysis quality")
    elif overall >= 0.8:
        st.info("Good analysis quality")
    elif overall >= 0.7:
        st.warning("Acceptable analysis quality")
    else:
        st.error("Quality concerns")


def render_model_evaluation_results(eval_results):
    """Render model evaluation results"""
    st.header("Model Evaluation Results")

    if "error" in eval_results:
        st.error(f"Evaluation Error: {eval_results['error']}")
        return

    # Threat Detection Model
    st.subheader("Threat Detection Model Evaluation")
    threat_eval = eval_results.get("threat_detection", {})

    if "error" in threat_eval:
        st.error(f"Threat Detection Evaluation Failed: {threat_eval['error']}")
    else:
        col1, col2, col3 = st.columns(3)

        with col1:
            st.metric(
                "Evaluation Samples",
                threat_eval.get("evaluation_samples", 0),
                help="Number of emails evaluated"
            )

        with col2:
            st.metric(
                "Overall Accuracy",
                f"{threat_eval.get('overall_accuracy', 0):.1%}",
                help="Multi-label classification accuracy"
            )

        with col3:
            st.metric(
                "Indicators Evaluated",
                threat_eval.get("indicators_evaluated", 0),
                help="Number of threat indicators"
            )

        # Per-indicator metrics
        if "per_indicator_metrics" in threat_eval:
            st.write("**Per-Indicator Metrics:**")
            metrics_df = pd.DataFrame(threat_eval["per_indicator_metrics"]).T
            st.dataframe(metrics_df, use_container_width=True)

    st.divider()

    # Severity Prediction Model
    st.subheader("Severity Prediction Model Evaluation")
    severity_eval = eval_results.get("severity_prediction", {})

    if "error" in severity_eval:
        st.error(f"Severity Prediction Evaluation Failed: {severity_eval['error']}")
    else:
        col1, col2, col3 = st.columns(3)

        with col1:
            st.metric(
                "Evaluation Samples",
                severity_eval.get("evaluation_samples", 0),
                help="Number of emails evaluated"
            )

        with col2:
            st.metric(
                "Overall Accuracy",
                f"{severity_eval.get('overall_accuracy', 0):.1%}",
                help="Classification accuracy across all severity levels"
            )

        with col3:
            st.metric(
                "Weighted F1-Score",
                f"{severity_eval.get('weighted_metrics', {}).get('f1', 0):.3f}",
                help="Weighted F1-score across classes"
            )

        # Weighted Metrics
        if "weighted_metrics" in severity_eval:
            st.write("**Weighted Metrics:**")
            col1, col2, col3 = st.columns(3)

            with col1:
                st.metric("Precision", f"{severity_eval['weighted_metrics'].get('precision', 0):.3f}")

            with col2:
                st.metric("Recall", f"{severity_eval['weighted_metrics'].get('recall', 0):.3f}")

            with col3:
                st.metric("F1-Score", f"{severity_eval['weighted_metrics'].get('f1', 0):.3f}")

        # Per-class metrics
        if "per_class_metrics" in severity_eval:
            st.write("**Per-Class Metrics:**")
            per_class_data = {}

            for level, metrics in severity_eval["per_class_metrics"].items():
                if isinstance(metrics, dict):
                    per_class_data[level] = {
                        "Precision": metrics.get("precision", 0),
                        "Recall": metrics.get("recall", 0),
                        "F1-Score": metrics.get("f1-score", 0),
                        "Support": metrics.get("support", 0)
                    }

            if per_class_data:
                metrics_df = pd.DataFrame(per_class_data).T
                st.dataframe(metrics_df, use_container_width=True)


def render_report_tab(result):
    """Render report tab"""
    st.header("Security Report")

    col1, col2 = st.columns(2)

    with col1:
        st.subheader("Download Report")
        report_text = result.get("final_report", "Report not available")
        st.download_button(
            label="Download TXT",
            data=report_text,
            file_name=f"report_{result.get('email_id', 'unknown')}.txt",
            mime="text/plain",
            use_container_width=True
        )

    with col2:
        st.subheader("Download JSON")
        import json
        json_data = {
            "email_id": result.get("email_id"),
            "threat_category": result.get("threat_category_predicted"),
            "severity_level": result.get("predicted_severity_level"),
            "risk_score": result.get("risk_score"),
            "threat_indicators": result.get("threat_indicators"),
        }
        st.download_button(
            label="Download JSON",
            data=json.dumps(json_data, indent=2),
            file_name=f"analysis_{result.get('email_id', 'unknown')}.json",
            mime="application/json",
            use_container_width=True
        )

    st.divider()

    st.subheader("Full Report")
    st.text_area("Security Report", report_text, height=300, disabled=True)


def main():
    """Main application"""
    load_dotenv()
    render_header()
    llm_client = build_gemini_client()

    # Sidebar email selection and model evaluation
    selected_email = render_sidebar()

    if selected_email is None:
        st.stop()

    # Display evaluation results if available
    if "eval_results" in st.session_state and st.session_state.eval_results:
        st.divider()
        render_model_evaluation_results(st.session_state.eval_results)
        st.divider()

    st.divider()

    # Load email
    emails = load_sample_emails()
    email_data = load_email(emails[selected_email])

    # Email preview
    render_email_preview(email_data)

    # Analysis button
    if st.button("Analyze Email", use_container_width=True, type="primary"):
        with st.spinner("Analyzing email (20-30 seconds)..."):
            result = analyze_email(email_data, llm_client=llm_client)
            st.session_state.last_result = result

    # Display results if available
    if "last_result" in st.session_state and st.session_state.last_result:
        result = st.session_state.last_result

        if result.get("error_occurred"):
            st.error("Analysis Failed")
            for error in result.get("error_messages", []):
                st.error(f"  - {error}")
        else:
            st.divider()

            summary = get_threat_summary(result)

            # Create tabs
            tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs([
                "Overview",
                "Threats",
                "Intelligence",
                "Recommendations",
                "Metrics",
                "Report"
            ])

            with tab1:
                render_overview_tab(result, summary)

            with tab2:
                render_threats_tab(summary)

            with tab3:
                render_intelligence_tab(result, summary)

            with tab4:
                render_recommendations_tab(result)

            with tab5:
                render_metrics_tab(result)

            with tab6:
                render_report_tab(result)


if __name__ == "__main__":
    main()
