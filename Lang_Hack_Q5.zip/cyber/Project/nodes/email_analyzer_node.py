#!/usr/bin/env python3
"""
Email Analyzer Node
Second node in workflow: Extract threat-relevant features
"""

from state import EmailThreatState
from agents.email_analyzer import EmailAnalyzerAgent


def email_analyzer_node(state: EmailThreatState) -> EmailThreatState:
    """
    Analyze email and extract threat-relevant features

    Args:
        state: Current workflow state

    Returns:
        Updated state with analysis results
    """
    if not state.get("parsing_complete"):
        state["error_occurred"] = True
        state["error_messages"].append("Email parsing not completed before analysis")
        return state

    agent = EmailAnalyzerAgent()

    try:
        # Comprehensive email analysis
        analysis = agent.analyze_email(
            state["parsed_email"],
            state["email_headers_normalized"]
        )

        state["email_analysis"] = analysis

        # Extract numeric features for ML models
        extracted_features = agent.extract_numeric_features(
            state["parsed_email"],
            analysis
        )

        state["extracted_features"] = extracted_features
        state["analysis_complete"] = True

    except Exception as e:
        state["error_occurred"] = True
        state["error_messages"].append(f"Email analysis failed: {str(e)}")

    return state
