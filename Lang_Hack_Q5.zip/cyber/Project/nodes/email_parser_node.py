#!/usr/bin/env python3
"""
Email Parser Node
First node in workflow: Parse and validate email JSON
"""

from state import EmailThreatState
from agents.email_parser import EmailParserAgent


def email_parser_node(state: EmailThreatState) -> EmailThreatState:
    """
    Parse and validate email JSON input

    Args:
        state: Current workflow state

    Returns:
        Updated state with parsed email data
    """
    agent = EmailParserAgent()

    # Parse and validate email
    is_valid, parsed_email, errors, warnings = agent.parse_and_validate(state["email_json"])

    # Extract normalized headers
    if is_valid:
        headers_normalized = agent.extract_headers(state["email_json"])
        metadata = agent.extract_metadata(state["email_json"])

        state["parsed_email"] = parsed_email
        state["email_headers_normalized"] = headers_normalized
        state["parsing_complete"] = True
        state["parsing_errors"] = []

    else:
        state["parsing_errors"] = errors
        state["error_occurred"] = True
        state["error_messages"].extend(errors)

    # Log warnings
    if warnings:
        print(f"Parsing warnings for email {state['email_id']}: {warnings}")

    return state
