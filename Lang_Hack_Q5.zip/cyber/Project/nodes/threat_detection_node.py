#!/usr/bin/env python3
"""
Threat Detection Node
Third node in workflow (parallel execution): Predict threat indicators
"""

from state import EmailThreatState
from agents.threat_detection_ml import ThreatDetectionMLAgent
from typing import Dict, Any
from pathlib import Path


def threat_detection_node(state: EmailThreatState) -> Dict[str, Any]:
    """
    Predict threat indicators and category using ML model

    Args:
        state: Current workflow state

    Returns:
        Dictionary with only threat detection specific updates
    """
    if not state.get("analysis_complete"):
        return {
            "threat_indicators": [],
            "threat_confidence_scores": {},
            "threat_category_predicted": "unknown",
            "threat_detection_complete": True
        }

    model_path = Path("ml/model/threat_detection_model.pkl")
    agent = ThreatDetectionMLAgent(model_path=str(model_path)) if model_path.exists() else ThreatDetectionMLAgent()

    try:
        # Validate features
        is_valid, errors = agent.validate_features(state["extracted_features"])

        # Predict threats
        threat_indicators, confidence_scores, threat_category = agent.predict_threats(
            state["extracted_features"]
        )

        return {
            "threat_indicators": threat_indicators,
            "threat_confidence_scores": confidence_scores,
            "threat_category_predicted": threat_category,
            "threat_detection_complete": True
        }

    except Exception as e:
        return {
            "threat_indicators": [],
            "threat_confidence_scores": {},
            "threat_category_predicted": "unknown",
            "threat_detection_complete": True
        }
