#!/usr/bin/env python3
"""
Recommendations Node
Node for generating security recommendations using LLM
"""

import time
from state import EmailThreatState
from agents.recommendation_generator_llm import RecommendationGeneratorLLMAgent


def recommendations_node(state: EmailThreatState, client=None, api_delay: float = 3.0) -> EmailThreatState:
    """
    Generate security recommendations using LLM

    Args:
        state: Current workflow state
        client: Anthropic API client (required for LLM-based recommendations)
        api_delay: Delay in seconds between API calls to avoid rate limiting (default: 2.0)

    Returns:
        Updated state with recommendations
    """
    # Wait for threat detection and severity prediction
    if not (state.get("threat_detection_complete") and state.get("severity_prediction_complete")):
        state["error_occurred"] = True
        state["error_messages"].append("Threat detection or severity prediction not completed before recommendations")
        state["recommendation_generation_complete"] = True
        return state

    # Check if client is available
    if client is None:
        state["error_messages"].append("LLM client not provided: skipping recommendation generation")
        state["recommended_actions"] = []
        state["remediation_steps"] = []
        state["user_notification_template"] = "LLM recommendations not available without API client."
        state["recommendation_generation_complete"] = True
        return state

    try:
        # Add delay before API call to avoid rate limiting
        if api_delay > 0:
            time.sleep(api_delay)

        agent = RecommendationGeneratorLLMAgent(client=client)
        actions, remediation, notification, analysis = agent.generate_recommendations(
            state.get("threat_category_predicted", "unknown"),
            state.get("predicted_severity_level", "unknown"),
            state.get("threat_indicators", []),
            state.get("detected_intent", "unknown")
        )

        state["recommended_actions"] = actions
        state["remediation_steps"] = remediation
        state["user_notification_template"] = notification
        state["recommendation_generation_complete"] = True

    except Exception as e:
        state["error_occurred"] = True
        state["error_messages"].append(f"Recommendation generation failed: {str(e)}")
        state["recommendation_generation_complete"] = True

    return state
