#!/usr/bin/env python3
"""
Intent Classifier Node
Node for classifying email attacker intent using LLM
"""

import time
from state import EmailThreatState
from agents.intent_classifier_llm import IntentClassifierLLMAgent


def intent_classifier_node(state: EmailThreatState, client=None, api_delay: float = 3.0) -> EmailThreatState:
    """
    Classify email intent using LLM

    Args:
        state: Current workflow state
        client: Anthropic API client (required for LLM-based classification)
        api_delay: Delay in seconds between API calls to avoid rate limiting (default: 2.0)

    Returns:
        Updated state with intent classification
    """
    # Check if client is available
    if client is None:
        state["error_messages"].append("LLM client not provided: skipping intent classification")
        state["detected_intent"] = "unknown"
        state["intent_confidence"] = 0.0
        state["intent_analysis"] = {"method": "skipped", "reason": "no_llm_client"}
        state["intent_classification_complete"] = True
        return state

    try:
        # Add delay before API call to avoid rate limiting
        if api_delay > 0:
            time.sleep(api_delay)

        agent = IntentClassifierLLMAgent(client=client)
        detected_intent, confidence, analysis = agent.classify_intent(state["email_json"])

        state["detected_intent"] = detected_intent
        state["intent_confidence"] = confidence
        state["intent_analysis"] = analysis
        state["intent_classification_complete"] = True

    except Exception as e:
        state["error_occurred"] = True
        state["error_messages"].append(f"Intent classification failed: {str(e)}")
        state["detected_intent"] = "unknown"
        state["intent_confidence"] = 0.0
        state["intent_classification_complete"] = True

    return state
