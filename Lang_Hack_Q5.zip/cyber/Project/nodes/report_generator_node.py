#!/usr/bin/env python3
"""
Report Generator Node
Node for generating comprehensive threat analysis reports using LLM
"""

import time
from state import EmailThreatState
from agents.report_generator_llm import ReportGeneratorLLMAgent


def report_generator_node(state: EmailThreatState, client=None, output_dir: str = "output", api_delay: float = 3.0) -> EmailThreatState:
    """
    Generate comprehensive threat analysis report using LLM

    Args:
        state: Current workflow state
        client: Anthropic API client (required for LLM-based report generation)
        output_dir: Output directory for saved report
        api_delay: Delay in seconds between API calls to avoid rate limiting (default: 2.0)

    Returns:
        Updated state with generated report
    """
    # Wait for all analysis to complete
    required_completions = [
        "threat_detection_complete",
        "severity_prediction_complete",
        "intent_classification_complete",
        "intelligence_analysis_complete",
        "recommendation_generation_complete"
    ]

    if not all(state.get(field) for field in required_completions):
        state["error_occurred"] = True
        state["error_messages"].append("Not all analyses completed before report generation")
        state["report_generation_complete"] = True
        return state

    # Check if client is available
    if client is None:
        state["error_messages"].append("LLM client not provided: generating basic report without LLM analysis")
        state["final_report"] = _generate_basic_report(state)
        state["report_json"] = _generate_basic_report_json(state)
        state["quality_metrics"] = {"completeness": 0.5, "confidence": 0.3, "overall_quality": 0.4}
        state["output_dir"] = output_dir
        state["report_generation_complete"] = True
        state["saved_path"] = f"{output_dir}/report_{state['email_id']}.txt"
        return state

    try:
        # Add delay before API call to avoid rate limiting
        if api_delay > 0:
            time.sleep(api_delay)

        agent = ReportGeneratorLLMAgent(client=client)
        report_text, report_json, quality_metrics = agent.generate_report(state)

        state["final_report"] = report_text
        state["report_json"] = report_json
        state["quality_metrics"] = quality_metrics
        state["output_dir"] = output_dir
        state["report_generation_complete"] = True

        # In a real implementation, would save report to file
        # For now, just mark the path
        state["saved_path"] = f"{output_dir}/report_{state['email_id']}.txt"

    except Exception as e:
        state["error_occurred"] = True
        state["error_messages"].append(f"Report generation failed: {str(e)}")
        state["report_generation_complete"] = True

    return state


def _generate_basic_report(state: EmailThreatState) -> str:
    """Generate basic report without LLM when client not available"""
    email_data = state.get("email_json", {})
    threat_level = state.get("predicted_severity_level", "unknown")
    threat_category = state.get("threat_category_predicted", "unknown")

    return f"""CYBERSECURITY THREAT ANALYSIS REPORT (BASIC)

Email ID: {state.get('email_id', 'unknown')}
Analysis Date: 2025-12-05
Sender: {email_data.get('from', 'unknown')}
Subject: {email_data.get('subject', 'unknown')}

EXECUTIVE SUMMARY
This email has been classified as {threat_category} with {threat_level} severity.
Note: Full LLM analysis unavailable (no API client provided).

THREAT ANALYSIS
Detected Threat Indicators: {', '.join(state.get('threat_indicators', []))}
Risk Score: {state.get('risk_score', 0):.1f}/100

RISK ASSESSMENT
Severity Level: {threat_level}

RECOMMENDED ACTIONS
- Review email carefully before taking action
- Do not click suspicious links
- Do not download unknown attachments
- Contact security team if unsure

NOTE: This is a basic report. Full LLM-powered analysis requires an Anthropic API client."""


def _generate_basic_report_json(state: EmailThreatState) -> dict:
    """Generate basic report JSON without LLM when client not available"""
    return {
        "email_id": state.get("email_id"),
        "threat_category": state.get("threat_category_predicted"),
        "severity_level": state.get("predicted_severity_level"),
        "risk_score": state.get("risk_score", 0),
        "threat_indicators": state.get("threat_indicators", []),
        "detected_intent": state.get("detected_intent"),
        "recommended_actions": state.get("recommended_actions", []),
        "report_type": "basic",
        "note": "Generated without LLM analysis"
    }
