#!/usr/bin/env python3
"""
Threat Intelligence Node
Node for analyzing threat intelligence using LLM
"""

import time
from state import EmailThreatState
from agents.threat_intelligence_llm import ThreatIntelligenceLLMAgent


def threat_intelligence_node(state: EmailThreatState, client=None, api_delay: float = 3.0) -> EmailThreatState:
    """
    Analyze threat intelligence using LLM

    Args:
        state: Current workflow state
        client: Anthropic API client (required for LLM-based intelligence analysis)
        api_delay: Delay in seconds between API calls to avoid rate limiting (default: 2.0)

    Returns:
        Updated state with threat intelligence analysis
    """
    # Wait for threat detection to complete
    if not state.get("threat_detection_complete"):
        state["error_occurred"] = True
        state["error_messages"].append("Threat detection not completed before intelligence analysis")
        state["intelligence_analysis_complete"] = True
        return state

    # Check if client is available
    if client is None:
        state["error_messages"].append("LLM client not provided: skipping threat intelligence analysis")
        state["correlated_campaigns"] = []
        state["mitre_techniques"] = []
        state["threat_actor_attribution"] = "unknown"
        state["threat_intelligence"] = {"method": "skipped", "reason": "no_llm_client"}
        state["intelligence_analysis_complete"] = True
        return state

    try:
        # Add delay before API call to avoid rate limiting
        if api_delay > 0:
            time.sleep(api_delay)

        agent = ThreatIntelligenceLLMAgent(client=client)
        campaigns, mitre_techniques, threat_actor, analysis = agent.analyze_threat_intelligence(
            state["email_json"],
            state.get("threat_indicators", []),
            state.get("detected_intent", "unknown")
        )

        state["correlated_campaigns"] = campaigns
        state["mitre_techniques"] = mitre_techniques
        state["threat_actor_attribution"] = threat_actor
        state["threat_intelligence"] = analysis
        state["intelligence_analysis_complete"] = True

    except Exception as e:
        state["error_occurred"] = True
        state["error_messages"].append(f"Threat intelligence analysis failed: {str(e)}")
        state["intelligence_analysis_complete"] = True

    return state
