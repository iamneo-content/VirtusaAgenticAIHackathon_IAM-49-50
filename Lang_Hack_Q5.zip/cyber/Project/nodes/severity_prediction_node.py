#!/usr/bin/env python3
"""
Severity Prediction Node
Fourth node in workflow (parallel execution): Predict threat severity
"""

from state import EmailThreatState
from agents.severity_prediction_ml import SeverityPredictionMLAgent
from typing import Dict, Any
from pathlib import Path


def severity_prediction_node(state: EmailThreatState) -> Dict[str, Any]:
    """
    Predict threat severity level and compute risk score

    Args:
        state: Current workflow state

    Returns:
        Dictionary with only severity prediction specific updates
    """
    if not state.get("analysis_complete"):
        return {
            "predicted_severity_level": "unknown",
            "severity_confidence": 0.0,
            "risk_score": 0.0,
            "severity_prediction_complete": True
        }

    model_path = Path("ml/model/severity_prediction_model.pkl")
    agent = SeverityPredictionMLAgent(model_path=str(model_path)) if model_path.exists() else SeverityPredictionMLAgent()

    try:
        # Predict severity
        severity_level, confidence, risk_score = agent.predict_severity(
            state["extracted_features"],
            state.get("threat_indicators", []),
            state.get("threat_category_predicted", "legitimate")
        )

        return {
            "predicted_severity_level": severity_level,
            "severity_confidence": confidence,
            "risk_score": risk_score,
            "severity_prediction_complete": True
        }

    except Exception as e:
        return {
            "predicted_severity_level": "unknown",
            "severity_confidence": 0.0,
            "risk_score": 0.0,
            "severity_prediction_complete": True
        }
