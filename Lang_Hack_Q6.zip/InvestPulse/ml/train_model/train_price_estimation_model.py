#!/usr/bin/env python3

import pickle
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import os

FEATURE_COLUMNS = [
    "square_feet", "bedrooms", "bathrooms", "property_age", "condition_score",
    "garage_spaces", "has_pool", "lot_size", "neighborhood_score", "school_rating",
    "days_on_market", "price_per_sqft", "market_trend_pct", "employment_rate_pct",
    "property_type", "bed_bath_ratio", "sqft_per_bedroom", "market_age_index", "price_gap_pct"
]


def train_price_estimation_model(df, model_save_dir="ml/model", test_size=0.2, random_state=42):
    """
    Train price estimation model and save it.
    Returns stats dict with training metrics and feature importance.
    """
    os.makedirs(model_save_dir, exist_ok=True)

    # Prepare data
    X = df[FEATURE_COLUMNS].values.astype(np.float32)
    y = df["sale_price"].values.astype(np.float32)

    # Train/test split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state
    )

    # Scale features
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    # Train RandomForest model
    model = RandomForestRegressor(
        n_estimators=100,
        max_depth=10,
        min_samples_split=20,
        min_samples_leaf=10,
        random_state=random_state,
        n_jobs=-1
    )
    model.fit(X_train_scaled, y_train)

    # Evaluate
    y_train_pred = model.predict(X_train_scaled)
    y_test_pred = model.predict(X_test_scaled)

    train_r2 = r2_score(y_train, y_train_pred)
    test_r2 = r2_score(y_test, y_test_pred)
    test_mae = mean_absolute_error(y_test, y_test_pred)
    test_rmse = np.sqrt(mean_squared_error(y_test, y_test_pred))
    test_mape = np.mean(np.abs((y_test - y_test_pred) / y_test)) * 100

    # Save model and scaler
    with open(f"{model_save_dir}/price_estimation_model.pkl", "wb") as f:
        pickle.dump(model, f)
    with open(f"{model_save_dir}/price_estimation_scaler.pkl", "wb") as f:
        pickle.dump(scaler, f)

    stats = {
        "train_r2": float(train_r2),
        "test_r2": float(test_r2),
        "test_mae": float(test_mae),
        "test_rmse": float(test_rmse),
        "test_mape": float(test_mape),
        "overfitting_gap": float(train_r2 - test_r2),
        "feature_importance": dict(zip(FEATURE_COLUMNS, model.feature_importances_))
    }

    return stats
