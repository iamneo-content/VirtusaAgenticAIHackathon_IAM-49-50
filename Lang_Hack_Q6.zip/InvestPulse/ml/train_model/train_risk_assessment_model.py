#!/usr/bin/env python3

import pickle
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import os

FEATURE_COLUMNS = [
    "square_feet", "bedrooms", "bathrooms", "property_age", "condition_score",
    "garage_spaces", "has_pool", "lot_size", "neighborhood_score", "school_rating",
    "days_on_market", "price_per_sqft", "market_trend_pct", "employment_rate_pct",
    "property_type", "bed_bath_ratio", "sqft_per_bedroom", "market_age_index", "price_gap_pct"
]


def train_risk_assessment_model(df, model_save_dir="ml/model", test_size=0.2, random_state=42):
    """
    Train risk assessment model and save it.
    Returns stats dict with training metrics and feature importance.
    """
    os.makedirs(model_save_dir, exist_ok=True)

    # Prepare data
    X = df[FEATURE_COLUMNS].values.astype(np.float32)
    y = df["risk_level"].values

    # Encode labels
    label_encoder = LabelEncoder()
    y_encoded = label_encoder.fit_transform(y)

    # Train/test split with stratification
    X_train, X_test, y_train, y_test = train_test_split(
        X, y_encoded, test_size=test_size, random_state=random_state, stratify=y_encoded
    )

    # Scale features
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    # Train RandomForest classifier
    model = RandomForestClassifier(
        n_estimators=100,
        max_depth=10,
        min_samples_split=20,
        min_samples_leaf=10,
        class_weight="balanced",
        random_state=random_state,
        n_jobs=-1
    )
    model.fit(X_train_scaled, y_train)

    # Evaluate
    y_train_pred = model.predict(X_train_scaled)
    y_test_pred = model.predict(X_test_scaled)

    train_acc = accuracy_score(y_train, y_train_pred)
    test_acc = accuracy_score(y_test, y_test_pred)
    test_precision = precision_score(y_test, y_test_pred, average="weighted", zero_division=0)
    test_recall = recall_score(y_test, y_test_pred, average="weighted", zero_division=0)
    test_f1 = f1_score(y_test, y_test_pred, average="weighted", zero_division=0)

    # Save model, scaler, and encoder
    with open(f"{model_save_dir}/risk_assessment_model.pkl", "wb") as f:
        pickle.dump(model, f)
    with open(f"{model_save_dir}/risk_assessment_scaler.pkl", "wb") as f:
        pickle.dump(scaler, f)
    with open(f"{model_save_dir}/risk_level_encoder.pkl", "wb") as f:
        pickle.dump(label_encoder, f)

    stats = {
        "train_accuracy": float(train_acc),
        "test_accuracy": float(test_acc),
        "test_precision": float(test_precision),
        "test_recall": float(test_recall),
        "test_f1": float(test_f1),
        "overfitting_gap": float(train_acc - test_acc),
        "feature_importance": dict(zip(FEATURE_COLUMNS, model.feature_importances_))
    }

    return stats
