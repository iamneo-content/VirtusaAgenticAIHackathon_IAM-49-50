#!/usr/bin/env python3

import pandas as pd
import numpy as np

REQUIRED_FEATURES = [
    "square_feet", "bedrooms", "bathrooms", "property_age", "condition_score",
    "garage_spaces", "has_pool", "lot_size", "neighborhood_score", "school_rating",
    "days_on_market", "price_per_sqft", "market_trend_pct", "employment_rate_pct",
    "property_type", "bed_bath_ratio", "sqft_per_bedroom", "market_age_index", "price_gap_pct"
]

VALID_RISK_LEVELS = {"safe", "moderate", "risky", "very_risky"}


def clean_risk_assessment_data(df, save_processed=False, output_dir="data/processed"):
    """
    Clean risk assessment data: remove duplicates, handle missing values, remove outliers, validate risk levels, encode categorical.
    Returns (cleaned_df, stats_dict)
    """
    original_rows = len(df)
    df = df.drop_duplicates()

    # Handle missing numeric values
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    for col in numeric_cols:
        if df[col].isnull().any():
            median_val = df[col].median()
            df[col] = df[col].fillna(median_val)

    # Handle missing categorical values
    categorical_cols = df.select_dtypes(include=['object']).columns
    for col in categorical_cols:
        if df[col].isnull().any():
            mode_val = df[col].mode()[0] if len(df[col].mode()) > 0 else "unknown"
            df[col] = df[col].fillna(mode_val)

    # Encode property_type if present
    if "property_type" in df.columns:
        type_mapping = {
            "residential": 1.0, "condo": 2.0, "townhouse": 3.0,
            "commercial": 4.0, "multi_family": 5.0,
        }
        df["property_type"] = df["property_type"].map(lambda x: type_mapping.get(str(x).lower(), 1.0))

    # Remove outliers using IQR method
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    for col in numeric_cols:
        Q1 = df[col].quantile(0.25)
        Q3 = df[col].quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 3 * IQR
        upper_bound = Q3 + 3 * IQR
        df = df[(df[col] >= lower_bound) & (df[col] <= upper_bound)]

    # Validate risk levels
    if "risk_level" in df.columns:
        valid_mask = df["risk_level"].isin(VALID_RISK_LEVELS)
        df = df[valid_mask]

    cleaned_rows = len(df)
    stats = {
        "original_rows": original_rows,
        "cleaned_rows": cleaned_rows,
        "duplicates_removed": original_rows - cleaned_rows if original_rows > cleaned_rows else 0,
        "rows_removed_pct": (1 - cleaned_rows / original_rows) * 100 if original_rows > 0 else 0,
    }

    if save_processed:
        output_path = f"{output_dir}/risk_assessment_cleaned.csv"
        df.to_csv(output_path, index=False)
        stats["output_path"] = output_path

    return df, stats
