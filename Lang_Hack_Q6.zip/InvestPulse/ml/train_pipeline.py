#!/usr/bin/env python3

import sys
import os
import pandas as pd

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ml.data_cleaning.clean_price_valuation_data import clean_price_valuation_data
from ml.data_cleaning.clean_risk_assessment_data import clean_risk_assessment_data
from ml.train_model.train_price_estimation_model import train_price_estimation_model
from ml.train_model.train_risk_assessment_model import train_risk_assessment_model
from ml.evaluation.evaluate_models import evaluate_all_models


def run_training_pipeline(data_dir="data", processed_dir="data/processed", model_dir="ml/models"):
    """
    Run complete training pipeline: load data, clean & save, train models, evaluate.
    Returns stats dict with all metrics.
    """
    stats = {}

    # Load raw data
    price_train_path = f"{data_dir}/training_dataset/price_valuation_training.csv"
    risk_train_path = f"{data_dir}/training_dataset/risk_assessment_training.csv"

    price_train_df = pd.read_csv(price_train_path)
    risk_train_df = pd.read_csv(risk_train_path)

    # Clean data and save to processed directory
    price_train_df, price_clean_stats = clean_price_valuation_data(
        price_train_df, save_processed=True, output_dir=processed_dir
    )
    stats["price_cleaning"] = price_clean_stats

    risk_train_df, risk_clean_stats = clean_risk_assessment_data(
        risk_train_df, save_processed=True, output_dir=processed_dir
    )
    stats["risk_cleaning"] = risk_clean_stats

    # Load cleaned data from processed directory for training
    price_cleaned_path = f"{processed_dir}/price_valuation_cleaned.csv"
    risk_cleaned_path = f"{processed_dir}/risk_assessment_cleaned.csv"

    price_train_df = pd.read_csv(price_cleaned_path)
    risk_train_df = pd.read_csv(risk_cleaned_path)

    # Train models using cleaned data
    price_train_stats = train_price_estimation_model(price_train_df, model_dir)
    stats["price_training"] = price_train_stats

    risk_train_stats = train_risk_assessment_model(risk_train_df, model_dir)
    stats["risk_training"] = risk_train_stats

    # Evaluate models
    eval_results = evaluate_all_models(model_dir)
    stats["evaluation"] = eval_results

    return stats


if __name__ == "__main__":
    pipeline_stats = run_training_pipeline()
    print("\n" + "="*80)
    print("TRAINING PIPELINE SUMMARY")
    print("="*80)
    print(f"Price Cleaning: {pipeline_stats.get('price_cleaning', {})}")
    print(f"Risk Cleaning: {pipeline_stats.get('risk_cleaning', {})}")
    print(f"Price Training: {pipeline_stats.get('price_training', {})}")
    print(f"Risk Training: {pipeline_stats.get('risk_training', {})}")
    print(f"Evaluation: {pipeline_stats.get('evaluation', {})}")
    print("="*80 + "\n")
