#!/usr/bin/env python3

import pickle
import pandas as pd
import numpy as np
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import os
from datetime import datetime

FEATURE_COLUMNS = [
    "square_feet", "bedrooms", "bathrooms", "property_age", "condition_score",
    "garage_spaces", "has_pool", "lot_size", "neighborhood_score", "school_rating",
    "days_on_market", "price_per_sqft", "market_trend_pct", "employment_rate_pct",
    "property_type", "bed_bath_ratio", "sqft_per_bedroom", "market_age_index", "price_gap_pct"
]


def evaluate_price_model(model_dir="ml/model", eval_data_dir="data/evaluation_dataset"):
    """
    Evaluate price estimation model on evaluation dataset.
    Returns evaluation metrics dict.
    """
    eval_path = f"{eval_data_dir}/price_valuation_evaluation.csv"
    if not os.path.exists(eval_path):
        return {}

    # Load model and scaler
    with open(f"{model_dir}/price_estimation_model.pkl", "rb") as f:
        model = pickle.load(f)
    with open(f"{model_dir}/price_estimation_scaler.pkl", "rb") as f:
        scaler = pickle.load(f)

    # Load and prepare evaluation data
    df = pd.read_csv(eval_path)

    # Encode property_type if present
    if "property_type" in df.columns:
        type_mapping = {
            "residential": 1.0, "condo": 2.0, "townhouse": 3.0,
            "commercial": 4.0, "multi_family": 5.0,
        }
        df["property_type"] = df["property_type"].map(lambda x: type_mapping.get(str(x).lower(), 1.0))

    X = df[FEATURE_COLUMNS].values.astype(np.float32)
    y = df["sale_price"].values.astype(np.float32)

    # Evaluate
    X_scaled = scaler.transform(X)
    y_pred = model.predict(X_scaled)

    mae = mean_absolute_error(y, y_pred)
    rmse = np.sqrt(mean_squared_error(y, y_pred))
    r2 = r2_score(y, y_pred)
    mape = np.mean(np.abs((y - y_pred) / y)) * 100

    return {
        "mae": float(mae),
        "rmse": float(rmse),
        "r2": float(r2),
        "mape": float(mape),
        "samples": len(df)
    }


def evaluate_risk_model(model_dir="ml/model", eval_data_dir="data/evaluation_dataset"):
    """
    Evaluate risk assessment model on evaluation dataset.
    Returns evaluation metrics dict.
    """
    eval_path = f"{eval_data_dir}/risk_assessment_evaluation.csv"
    if not os.path.exists(eval_path):
        return {}

    # Load models and encoder
    with open(f"{model_dir}/risk_assessment_model.pkl", "rb") as f:
        model = pickle.load(f)
    with open(f"{model_dir}/risk_assessment_scaler.pkl", "rb") as f:
        scaler = pickle.load(f)
    with open(f"{model_dir}/risk_level_encoder.pkl", "rb") as f:
        encoder = pickle.load(f)

    # Load and prepare evaluation data
    df = pd.read_csv(eval_path)

    # Encode property_type if present
    if "property_type" in df.columns:
        type_mapping = {
            "residential": 1.0, "condo": 2.0, "townhouse": 3.0,
            "commercial": 4.0, "multi_family": 5.0,
        }
        df["property_type"] = df["property_type"].map(lambda x: type_mapping.get(str(x).lower(), 1.0))

    X = df[FEATURE_COLUMNS].values.astype(np.float32)
    y = df["risk_level"].values

    # Evaluate
    y_encoded = encoder.transform(y)
    X_scaled = scaler.transform(X)
    y_pred = model.predict(X_scaled)

    accuracy = accuracy_score(y_encoded, y_pred)
    precision = precision_score(y_encoded, y_pred, average="weighted", zero_division=0)
    recall = recall_score(y_encoded, y_pred, average="weighted", zero_division=0)
    f1 = f1_score(y_encoded, y_pred, average="weighted", zero_division=0)

    return {
        "accuracy": float(accuracy),
        "precision": float(precision),
        "recall": float(recall),
        "f1": float(f1),
        "samples": len(df)
    }


def evaluate_all_models(model_dir="ml/model", eval_data_dir="data/evaluation_dataset"):
    """
    Evaluate all models and return results.
    Returns dict with timestamp and evaluation results for both models.
    """
    return {
        "timestamp": datetime.now().isoformat(),
        "price_evaluation": evaluate_price_model(model_dir, eval_data_dir),
        "risk_evaluation": evaluate_risk_model(model_dir, eval_data_dir),
    }
