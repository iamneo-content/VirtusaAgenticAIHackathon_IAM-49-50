#!/usr/bin/env python3
"""
Gemini client adapter for InvestPulse
Provides interface matching agents' expected API
"""

from __future__ import annotations

import os
import logging
from typing import Optional
from pathlib import Path

logger = logging.getLogger(__name__)

# Try to load environment variables from .env file if it exists
try:
    from dotenv import load_dotenv
    env_file = Path.cwd() / ".env"
    if env_file.exists():
        load_dotenv(env_file)
        logger.debug(f"Loaded environment variables from {env_file}")
except ImportError:
    pass  # python-dotenv not installed, that's OK

try:
    from google import generativeai as genai
except ImportError:
    genai = None


class GeminiAdapter:
    def __init__(self, api_key: str, model_name: str = "gemini-2.0-flash"):
        if genai is None:
            raise ImportError("google-generativeai is not installed")

        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel(model_name)
        self.model_name = model_name

    def messages_create(self, max_tokens: int = 500, messages=None):
        content = ""
        if messages and len(messages) > 0:
            content = messages[0].get("content", "")

        response = self.model.generate_content(
            content,
            generation_config={"max_output_tokens": max_tokens},
        )

        text = getattr(response, "text", None)
        if text is None and getattr(response, "candidates", None):
            try:
                text = response.candidates[0].content.parts[0].text
            except Exception:
                text = ""
        text = text or ""

        class _Content:
            def __init__(self, text_value: str):
                self.text = text_value

        class _Response:
            def __init__(self, text_value: str):
                self.content = [_Content(text_value)]

        return _Response(text)


def _get_first_api_key() -> Optional[str]:
    """
    Return the first available Gemini API key.
    Checks Streamlit secrets first (if running in Streamlit), then environment variables.
    Looks for GEMINI_API_KEY_1, GEMINI_API_KEY_2, GEMINI_API_KEY_3, GEMINI_API_KEY_4 in order.
    Can work with single or multiple keys.
    """
    # First, try to get from Streamlit secrets (if running in Streamlit)
    try:
        import streamlit as st
        for i in range(1, 5):
            try:
                key = st.secrets.get(f"GEMINI_API_KEY_{i}")
                if key:
                    return key
            except:
                pass
    except ImportError:
        pass  # Not running in Streamlit context

    # Fall back to environment variables
    for i in range(1, 5):
        key = os.getenv(f"GEMINI_API_KEY_{i}")
        if key:
            return key

    return None


def build_gemini_client() -> Optional[GeminiAdapter]:
    """
    Build and return a GeminiAdapter if API key and library are present.
    Returns None when not configured.
    Logs diagnostic information about initialization failures.
    """
    api_key = _get_first_api_key()
    model_name = os.getenv("GEMINI_MODEL", "gemini-2.0-flash")

    if not api_key:
        logger.warning("No Gemini API key found. Please set GEMINI_API_KEY_1 (or 2-4) environment variable.")
        return None

    if genai is None:
        logger.warning("google-generativeai library not installed. Install with: pip install google-generativeai")
        return None

    try:
        client = GeminiAdapter(api_key=api_key, model_name=model_name)
        logger.info(f"Gemini client initialized successfully with model: {model_name}")
        return client
    except Exception as e:
        logger.error(f"Failed to initialize Gemini client: {str(e)}")
        return None
