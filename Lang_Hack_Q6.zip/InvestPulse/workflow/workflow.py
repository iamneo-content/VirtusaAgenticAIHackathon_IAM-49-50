#!/usr/bin/env python3

from typing import Dict, Any
from langgraph.graph import StateGraph
from state import PropertyValuationState, get_initial_state
from nodes import (
    property_parser_node,
    property_analyzer_node,
    price_estimation_node,
    risk_assessment_node,
    market_intent_node,
    market_intelligence_node,
    recommendation_node,
    report_generator_node,
)
import logging

logger = logging.getLogger(__name__)


def build_workflow(llm_client=None):
    workflow = StateGraph(PropertyValuationState)

    workflow.add_node("property_parser", lambda state: property_parser_node(state, llm_client))
    workflow.add_node("property_analyzer", lambda state: property_analyzer_node(state, llm_client))
    workflow.add_node("price_estimation", lambda state: price_estimation_node(state, llm_client))
    workflow.add_node("risk_assessment", lambda state: risk_assessment_node(state, llm_client))
    workflow.add_node("market_intent_classifier", lambda state: market_intent_node(state, llm_client))
    workflow.add_node("market_intelligence", lambda state: market_intelligence_node(state, llm_client))
    workflow.add_node("recommendation", lambda state: recommendation_node(state, llm_client))
    workflow.add_node("report_generator", lambda state: report_generator_node(state, llm_client))

    workflow.set_entry_point("property_parser")

    workflow.add_edge("property_parser", "property_analyzer")

    workflow.add_edge("property_analyzer", "price_estimation")
    workflow.add_edge("property_analyzer", "risk_assessment")

    workflow.add_edge("price_estimation", "market_intent_classifier")
    workflow.add_edge("risk_assessment", "market_intent_classifier")

    workflow.add_edge("market_intent_classifier", "market_intelligence")
    workflow.add_edge("market_intelligence", "recommendation")
    workflow.add_edge("recommendation", "report_generator")

    workflow.set_finish_point("report_generator")

    return workflow.compile()


def run_property_analysis_workflow(property_json: Dict[str, Any], llm_client=None) -> Dict[str, Any]:
    initial_state = get_initial_state(property_json)

    graph = build_workflow(llm_client)

    try:
        final_state = graph.invoke(initial_state)
        logger.info(f"Workflow completed for property {initial_state['property_id']}")
        return final_state

    except Exception as e:
        logger.error(f"Error running workflow: {str(e)}")
        initial_state["error_occurred"] = True
        initial_state["error_messages"].append(f"Workflow error: {str(e)}")
        return initial_state
