#!/usr/bin/env python3

import streamlit as st
import json
import os
import sys
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from graph import analyze_property, get_threat_summary
from utils.gemini_client import build_gemini_client
from ml.evaluation.evaluate_models import evaluate_all_models
import pandas as pd

st.set_page_config(page_title="InvestPulse", page_icon="📊", layout="wide")

# Custom CSS for professional styling
st.markdown("""
<style>
    .header-title {
        font-size: 2.5em;
        font-weight: bold;
        color: #1f77b4;
        margin-bottom: 0.5em;
    }
    .header-subtitle {
        font-size: 1.1em;
        color: #555;
        margin-bottom: 1.5em;
    }
    .metric-card {
        padding: 1.5em;
        border-radius: 0.5em;
        background-color: #f8f9fa;
        border-left: 4px solid #1f77b4;
    }
    .section-header {
        font-size: 1.3em;
        font-weight: bold;
        color: #1f77b4;
        margin-top: 1.5em;
        margin-bottom: 1em;
        border-bottom: 2px solid #1f77b4;
        padding-bottom: 0.5em;
    }
</style>
""", unsafe_allow_html=True)

def load_sample_properties():
    props_dir = Path("data/input/sample_properties")
    if not props_dir.exists():
        return {}

    properties = {}
    for json_file in sorted(props_dir.glob("*.json")):
        try:
            with open(json_file, "r") as f:
                prop_data = json.load(f)
                prop_id = prop_data.get("property_id", json_file.stem)
                address = prop_data.get("address", "Unknown")
                properties[f"{prop_id} - {address}"] = json_file
        except:
            pass

    return properties


def load_property(file_path):
    try:
        with open(file_path, "r") as f:
            return json.load(f)
    except:
        return None


def render_header():
    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        st.markdown('<div class="header-title">InvestPulse</div>', unsafe_allow_html=True)
        st.markdown('<div class="header-subtitle">Real Estate Investment Analysis & Risk Assessment Platform</div>',
                   unsafe_allow_html=True)
    st.divider()


def render_sidebar():
    with st.sidebar:
        st.header("Configuration")

        properties = load_sample_properties()
        if not properties:
            st.warning("No sample properties found")
            return None

        selected_property = st.selectbox(
            "Select a Property",
            options=list(properties.keys()),
            key="property_selector"
        )

        st.divider()
        st.subheader("Tools")

        if st.button("Run Model Evaluation", use_container_width=True, type="secondary"):
            st.session_state.run_evaluation = True

        return properties.get(selected_property) if selected_property else None


def render_property_preview(property_data):
    if not property_data:
        return

    with st.expander("Property Details", expanded=True):
        col1, col2, col3 = st.columns(3)

        with col1:
            st.write("**Address**")
            st.write(property_data.get('address', 'N/A'))
            st.write("")
            st.write("**City**")
            st.write(property_data.get('city', 'N/A'))

        with col2:
            st.write("**Property Type**")
            st.write(property_data.get('property_type', 'N/A'))
            st.write("")
            st.write("**Year Built**")
            st.write(str(property_data.get('year_built', 'N/A')))

        with col3:
            st.write("**Square Footage**")
            st.write(f"{property_data.get('square_footage', 'N/A'):,}")
            st.write("")
            st.write("**Bedrooms / Bathrooms**")
            st.write(f"{property_data.get('bedrooms', 'N/A')} / {property_data.get('bathrooms', 'N/A')}")


def render_overview_tab(result, summary):
    st.markdown('<div class="section-header">Financial Metrics</div>', unsafe_allow_html=True)

    col1, col2 = st.columns(2)

    with col1:
        st.metric(
            "Estimated Price",
            f"${result.get('predicted_price', 0):,.0f}",
            f"{result.get('price_confidence', 0):.0%} confidence"
        )

    with col2:
        st.metric(
            "Risk Level",
            result.get('risk_level', 'Unknown').upper(),
            f"Score: {result.get('risk_score', 0):.1f}/10"
        )

    col1, col2 = st.columns(2)

    with col1:
        st.metric(
            "Investment Viability",
            result.get('investment_viability', 'N/A'),
            ""
        )

    with col2:
        st.metric(
            "Intent Confidence",
            f"{result.get('intent_confidence', 0):.0%}",
            "Market Assessment"
        )

    st.divider()

    st.markdown('<div class="section-header">Market Intent Analysis</div>', unsafe_allow_html=True)
    st.info(result.get('market_intent', 'No market intent analysis available'))

    st.divider()
    st.markdown('<div class="section-header">Key Findings</div>', unsafe_allow_html=True)

    col1, col2, col3 = st.columns(3)

    with col1:
        risk_factors = result.get('risk_factors', [])
        st.write("**Risk Factors**")
        st.write(f"Count: {len(risk_factors)}")
        for factor in risk_factors[:3]:
            st.caption(f"• {factor}")

    with col2:
        actions = result.get('investment_actions', [])
        st.write("**Recommended Actions**")
        st.write(f"Count: {len(actions)}")
        for action in actions[:3]:
            st.caption(f"• {action}")

    with col3:
        st.write("**Opportunity Type**")
        st.write(result.get('opportunity_type', 'N/A'))


def render_risks_tab(result):
    st.markdown('<div class="section-header">Risk Analysis</div>', unsafe_allow_html=True)

    col1, col2 = st.columns([1, 3])

    with col1:
        risk_factors = result.get('risk_factors', [])
        st.metric("Risk Factors Identified", len(risk_factors))

    with col2:
        for factor in risk_factors:
            st.warning(f"{factor}")


def render_intelligence_tab(result):
    st.markdown('<div class="section-header">Market Analysis</div>', unsafe_allow_html=True)

    col1, col2 = st.columns(2)

    with col1:
        st.write("**Market Insights**")
        market_insights = result.get('market_insights', {})
        if market_insights:
            for key, value in market_insights.items():
                st.caption(f"**{key}:** {value}")
        else:
            st.info("No market insights available")

    with col2:
        st.write("**Market Trends**")
        market_trends = result.get('market_trends', {})
        if market_trends:
            for key, value in market_trends.items():
                st.caption(f"**{key}:** {value}")
        else:
            st.info("No market trends available")

    st.divider()
    st.write("**Comparable Properties**")
    comparables = result.get('comparable_properties', [])
    if comparables:
        comp_df = pd.DataFrame(comparables)
        st.dataframe(comp_df, use_container_width=True)
    else:
        st.info("No comparable properties data available")


def render_recommendations_tab(result):
    st.markdown('<div class="section-header">Investment Strategy</div>', unsafe_allow_html=True)

    # Main recommendation
    recommendation = result.get('investment_recommendation', 'No recommendation available')
    st.info(recommendation)

    st.divider()

    col1, col2 = st.columns(2)

    with col1:
        st.write("**Recommended Actions**")
        actions = result.get('investment_actions', [])
        if actions:
            for i, action in enumerate(actions, 1):
                st.write(f"{i}. {action}")
        else:
            st.write("No specific actions recommended")

    with col2:
        st.write("**Risk Mitigation Strategies**")
        strategies = result.get('risk_mitigation', [])
        if strategies:
            for i, strategy in enumerate(strategies, 1):
                st.write(f"{i}. {strategy}")
        else:
            st.write("No mitigation strategies needed")

    st.divider()

    col1, col2 = st.columns(2)
    with col1:
        st.metric("Priority Level", result.get('action_priority', 'Medium'))
    with col2:
        st.metric("Opportunity Type", result.get('opportunity_type', 'N/A'))


def render_metrics_tab(result):
    st.markdown('<div class="section-header">Quality Metrics</div>', unsafe_allow_html=True)

    quality_metrics = result.get('quality_metrics', {})

    if quality_metrics:
        cols = st.columns(3)
        metrics_list = list(quality_metrics.items())

        for idx, (metric_name, metric_value) in enumerate(metrics_list):
            with cols[idx % 3]:
                metric_label = metric_name.replace('_', ' ').title()
                st.metric(metric_label, f"{metric_value:.0%}")

        st.divider()

        overall_rating = sum(quality_metrics.values()) / len(quality_metrics)

        if overall_rating > 0.85:
            rating = "Excellent"
            color = "#28a745"
        elif overall_rating > 0.70:
            rating = "Good"
            color = "#007bff"
        elif overall_rating > 0.55:
            rating = "Fair"
            color = "#ffc107"
        else:
            rating = "Poor"
            color = "#dc3545"

        st.markdown(f"""
        <div style='text-align: center; padding: 1.5em; background-color: #f8f9fa; border-radius: 0.5em; border-left: 4px solid {color};'>
            <div style='font-size: 1.3em; color: {color}; font-weight: bold;'>Overall Assessment: {rating}</div>
            <div style='font-size: 2em; color: {color}; font-weight: bold;'>{overall_rating:.0%}</div>
        </div>
        """, unsafe_allow_html=True)
    else:
        st.info("No quality metrics available")


def render_model_evaluation_results(eval_results):
    st.markdown('<div class="section-header">Model Performance</div>', unsafe_allow_html=True)

    if not eval_results or "price_evaluation" not in eval_results:
        st.warning("No evaluation results available")
        return

    col1, col2 = st.columns(2)

    with col1:
        st.write("**Price Estimation Model**")
        price_eval = eval_results.get("price_evaluation", {})
        if price_eval:
            st.metric("R² Score", f"{price_eval.get('r2', 0):.4f}")
            st.metric("Mean Absolute Error (MAE)", f"${price_eval.get('mae', 0):,.0f}")
            st.metric("Root Mean Squared Error (RMSE)", f"${price_eval.get('rmse', 0):,.0f}")
            st.metric("Mean Absolute Percentage Error (MAPE)", f"{price_eval.get('mape', 0):.2f}%")

    with col2:
        st.write("**Risk Assessment Model**")
        risk_eval = eval_results.get("risk_evaluation", {})
        if risk_eval:
            st.metric("Accuracy", f"{risk_eval.get('accuracy', 0):.4f}")
            st.metric("Precision", f"{risk_eval.get('precision', 0):.4f}")
            st.metric("Recall", f"{risk_eval.get('recall', 0):.4f}")
            st.metric("F1 Score", f"{risk_eval.get('f1', 0):.4f}")


def render_report_tab(result):
    st.markdown('<div class="section-header">Investment Report</div>', unsafe_allow_html=True)

    col1, col2 = st.columns(2)

    with col1:
        report_text = result.get('investment_report', '')
        if st.button("Download Report (TXT)", use_container_width=True):
            st.download_button(
                label="Download as TXT",
                data=report_text,
                file_name=f"report_{result.get('property_id', 'report')}.txt"
            )

    with col2:
        report_json = result.get('report_json', {})
        if st.button("Download Report (JSON)", use_container_width=True):
            import json as json_lib
            st.download_button(
                label="Download as JSON",
                data=json_lib.dumps(report_json, indent=2),
                file_name=f"report_{result.get('property_id', 'report')}.json"
            )

    st.divider()
    st.text_area("Full Report", report_text, height=400, disabled=True)


def main():
    render_header()

    property_file = render_sidebar()

    # Model Evaluation Section
    if st.session_state.get("run_evaluation"):
        st.info("Evaluating models...")
        eval_results = evaluate_all_models()

        if eval_results:
            st.success("Model evaluation complete!")
            render_model_evaluation_results(eval_results)
        else:
            st.warning("Evaluation dataset not available. This is optional.")

        st.session_state.run_evaluation = False

    # Property Analysis Section
    if property_file:
        property_data = load_property(property_file)
        if property_data:
            render_property_preview(property_data)

            st.divider()

            if st.button("Analyze Property", use_container_width=True, type="primary"):
                with st.spinner("Analyzing property..."):
                    llm_client = build_gemini_client()

                    if llm_client is None:
                        st.error("LLM Client Not Configured")
                        st.info("""
To enable LLM-powered analysis, configure your Gemini API key:

**Method 1: Streamlit Secrets (Recommended)**
- Create `.streamlit/secrets.toml` with your API key
- The app will automatically detect it

**Method 2: .env File**
- Create or update `.env` file with: `GEMINI_API_KEY_1=your-key`
- Run: `streamlit run main.py`

**Method 3: Environment Variable**
- Run: `export GEMINI_API_KEY_1="your-key" && streamlit run main.py`

See `STREAMLIT_API_TROUBLESHOOTING.md` for detailed instructions.

Note: ML models (price and risk prediction) still work without LLM configuration.
                        """)
                    else:
                        result = analyze_property(property_data, llm_client)

                        if result and not result.get('error'):
                            st.session_state.analysis_result = result
                            st.success("Analysis complete!")
                        else:
                            st.error(f"Analysis failed: {result.get('error_message', 'Unknown error')}")

            # Display Analysis Results
            if "analysis_result" in st.session_state:
                result = st.session_state.analysis_result
                summary = get_threat_summary(result)

                st.divider()

                tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs(
                    ["Overview", "Risk Analysis", "Market Intelligence", "Recommendations", "Quality Metrics", "Report"]
                )

                with tab1:
                    render_overview_tab(result, summary)

                with tab2:
                    render_risks_tab(result)

                with tab3:
                    render_intelligence_tab(result)

                with tab4:
                    render_recommendations_tab(result)

                with tab5:
                    render_metrics_tab(result)

                with tab6:
                    render_report_tab(result)


if __name__ == "__main__":
    main()
