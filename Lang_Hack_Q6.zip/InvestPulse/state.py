#!/usr/bin/env python3

from typing import TypedDict, List, Dict, Any, Optional
import re


class PropertyValuationState(TypedDict):
    property_json: Dict[str, Any]
    property_id: str
    address: str
    city: str

    parsed_property: Dict[str, Any]
    property_headers_normalized: Dict[str, Any]
    parsing_complete: bool
    parsing_errors: List[str]

    property_analysis: Dict[str, Any]
    extracted_features: Dict[str, float]
    analysis_complete: bool

    predicted_price: float
    price_confidence: float
    price_model_metrics: Dict[str, float]
    price_estimation_complete: bool

    risk_level: str
    risk_score: float
    risk_confidence: float
    risk_factors: List[str]
    risk_assessment_complete: bool

    opportunity_type: str
    market_intent: str
    intent_confidence: float
    intent_analysis: Dict[str, Any]
    intent_classification_complete: bool

    market_insights: Dict[str, Any]
    comparable_properties: List[Dict[str, Any]]
    market_trends: Dict[str, Any]
    investment_viability: str
    intelligence_analysis_complete: bool

    recommended_action: str
    investment_recommendation: str
    investment_actions: List[str]
    risk_mitigation: List[str]
    action_priority: str
    recommendation_generation_complete: bool

    investment_report: str
    report_json: Dict[str, Any]
    quality_metrics: Dict[str, float]
    saved_path: str
    output_dir: str
    report_generation_complete: bool

    error_occurred: bool
    error_messages: List[str]


def get_initial_state(property_json: Dict[str, Any]) -> PropertyValuationState:
    property_id = property_json.get("property_id", "UNKNOWN")
    address = property_json.get("address", "")
    city = property_json.get("city", "")

    return PropertyValuationState(
        property_json=property_json,
        property_id=property_id,
        address=address,
        city=city,

        parsed_property={},
        property_headers_normalized={},
        parsing_complete=False,
        parsing_errors=[],

        property_analysis={},
        extracted_features={},
        analysis_complete=False,

        predicted_price=0.0,
        price_confidence=0.0,
        price_model_metrics={},
        price_estimation_complete=False,

        risk_level="unknown",
        risk_score=0.0,
        risk_confidence=0.0,
        risk_factors=[],
        risk_assessment_complete=False,

        opportunity_type="",
        market_intent="",
        intent_confidence=0.0,
        intent_analysis={},
        intent_classification_complete=False,

        market_insights={},
        comparable_properties=[],
        market_trends={},
        investment_viability="",
        intelligence_analysis_complete=False,

        recommended_action="",
        investment_recommendation="",
        investment_actions=[],
        risk_mitigation=[],
        action_priority="",
        recommendation_generation_complete=False,

        investment_report="",
        report_json={},
        quality_metrics={},
        saved_path="",
        output_dir="",
        report_generation_complete=False,

        error_occurred=False,
        error_messages=[],
    )


def validate_state(state: PropertyValuationState) -> bool:
    required_fields = [
        "property_json", "property_id", "address", "city",
        "parsed_property", "parsing_complete", "parsing_errors",
        "extracted_features", "analysis_complete",
        "predicted_price", "price_estimation_complete",
        "risk_level", "risk_assessment_complete",
        "intent_classification_complete",
        "intelligence_analysis_complete",
        "recommendation_generation_complete",
        "report_generation_complete",
        "error_occurred", "error_messages"
    ]

    for field in required_fields:
        if field not in state:
            return False

    return True


def slugify(text: str) -> str:
    text = text.lower().strip()
    text = re.sub(r'[^\w\s-]', '', text)
    text = re.sub(r'[-\s]+', '-', text)
    return text.strip('-')
