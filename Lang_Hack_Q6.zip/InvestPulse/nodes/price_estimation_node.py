#!/usr/bin/env python3

from state import PropertyValuationState
from agents import PriceEstimationMLAgent


def price_estimation_node(state: PropertyValuationState, client=None) -> dict:
    estimator = PriceEstimationMLAgent()
    extracted_features = state["extracted_features"]

    predicted_price, confidence = estimator.predict_price(extracted_features)

    return {
        "predicted_price": predicted_price,
        "price_confidence": confidence,
        "price_estimation_complete": True,
    }
