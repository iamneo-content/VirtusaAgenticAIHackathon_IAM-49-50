#!/usr/bin/env python3

from state import PropertyValuationState
from agents import MarketIntelligenceLLMAgent


def market_intelligence_node(state: PropertyValuationState, client=None) -> dict:
    intelligence = MarketIntelligenceLLMAgent(client=client)

    property_json = state["property_json"]
    analysis_results = {
        "predicted_price": state.get("predicted_price", 0),
        "risk_level": state.get("risk_level", "moderate"),
        "risk_score": state.get("risk_score", 5.0),
    }

    intelligence_result = intelligence.analyze_threat(property_json, analysis_results)

    return {
        "market_insights": intelligence_result.get("market_insights", {}),
        "comparable_properties": intelligence_result.get("comparable_properties", []),
        "market_trends": intelligence_result.get("market_trends", {}),
        "investment_viability": intelligence_result.get("investment_viability", ""),
        "intelligence_analysis_complete": True,
    }
