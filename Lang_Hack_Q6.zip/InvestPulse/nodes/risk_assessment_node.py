#!/usr/bin/env python3

from state import PropertyValuationState
from agents import RiskAssessmentMLAgent


def risk_assessment_node(state: PropertyValuationState, client=None) -> dict:
    assessor = RiskAssessmentMLAgent()
    extracted_features = state["extracted_features"]

    risk_level, risk_score, confidence, risk_factors = assessor.predict_risk(extracted_features)

    return {
        "risk_level": risk_level,
        "risk_score": risk_score,
        "risk_confidence": confidence,
        "risk_factors": risk_factors,
        "risk_assessment_complete": True,
    }
