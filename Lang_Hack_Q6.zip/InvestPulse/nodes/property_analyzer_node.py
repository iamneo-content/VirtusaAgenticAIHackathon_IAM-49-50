#!/usr/bin/env python3

from state import PropertyValuationState
from agents import PropertyAnalyzerAgent


def property_analyzer_node(state: PropertyValuationState, client=None) -> dict:
    analyzer = PropertyAnalyzerAgent()
    parsed_property = state["parsed_property"]

    extracted_features = analyzer.extract_numeric_features(parsed_property)

    return {
        "extracted_features": extracted_features,
        "analysis_complete": True,
    }
