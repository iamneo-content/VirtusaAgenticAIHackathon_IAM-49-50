#!/usr/bin/env python3

from state import PropertyValuationState
from agents import RecommendationGeneratorLLMAgent


def recommendation_node(state: PropertyValuationState, client=None) -> dict:
    generator = RecommendationGeneratorLLMAgent(client=client)

    property_json = state["property_json"]
    analysis_results = {
        "predicted_price": state.get("predicted_price", 0),
        "risk_level": state.get("risk_level", "moderate"),
        "risk_score": state.get("risk_score", 5.0),
        "opportunity_type": state.get("opportunity_type", ""),
        "risk_factors": state.get("risk_factors", []),
    }

    recommendation_result = generator.generate_recommendations(property_json, analysis_results)

    return {
        "recommended_action": recommendation_result.get("recommendation", ""),
        "investment_recommendation": recommendation_result.get("investment_recommendation", ""),
        "investment_actions": recommendation_result.get("investment_actions", []),
        "risk_mitigation": recommendation_result.get("risk_mitigation", []),
        "action_priority": recommendation_result.get("action_priority", "Medium"),
        "recommendation_generation_complete": True,
    }
