#!/usr/bin/env python3

from state import PropertyValuationState
from agents import PropertyParserAgent


def property_parser_node(state: PropertyValuationState, client=None) -> dict:
    parser = PropertyParserAgent()
    property_json = state["property_json"]

    parsed_property = parser.parse_and_validate(property_json)

    return {
        "parsed_property": parsed_property,
        "property_headers_normalized": {
            "property_id": parsed_property.get("property_id", ""),
            "address": parsed_property.get("address", ""),
            "city": parsed_property.get("city", ""),
            "state": parsed_property.get("state", ""),
            "zip_code": parsed_property.get("zip_code", ""),
            "country": parsed_property.get("country", "USA"),
        },
        "parsing_complete": True,
    }
