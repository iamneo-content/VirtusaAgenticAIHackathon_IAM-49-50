#!/usr/bin/env python3

from state import PropertyValuationState
from agents import MarketIntentClassifierLLMAgent


def market_intent_node(state: PropertyValuationState, client=None) -> dict:
    classifier = MarketIntentClassifierLLMAgent(client=client)

    property_json = state["property_json"]
    analysis_results = {
        "predicted_price": state.get("predicted_price", 0),
        "risk_level": state.get("risk_level", "moderate"),
        "risk_score": state.get("risk_score", 5.0),
    }

    intent_result = classifier.classify_intent(property_json, analysis_results)

    return {
        "opportunity_type": intent_result.get("opportunity_type", ""),
        "market_intent": intent_result.get("market_intent", ""),
        "intent_confidence": intent_result.get("intent_confidence", 0.0),
        "intent_analysis": intent_result,
        "intent_classification_complete": True,
    }
