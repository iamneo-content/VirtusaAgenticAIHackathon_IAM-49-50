#!/usr/bin/env python3

from state import PropertyValuationState
from agents import ReportGeneratorLLMAgent


def report_generator_node(state: PropertyValuationState, client=None) -> dict:
    generator = ReportGeneratorLLMAgent(client=client)

    property_json = state["property_json"]
    report_result = generator.generate_report(property_json, state)

    return {
        "investment_report": report_result.get("investment_report", ""),
        "report_json": report_result.get("report_json", {}),
        "quality_metrics": report_result.get("quality_metrics", {}),
        "saved_path": report_result.get("saved_path", ""),
        "output_dir": "output",
        "report_generation_complete": True,
    }
