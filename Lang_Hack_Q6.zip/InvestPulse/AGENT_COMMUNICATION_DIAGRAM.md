INVESTPULSE AGENT COMMUNICATION WORKFLOW DIAGRAM

The following Mermaid diagram shows the agent-to-agent communication flow in the 8-stage
InvestPulse pipeline:


graph TD
    Start([Property Analysis Start]) --> PPA[PropertyParserAgent]

    PPA -->|Property Parsed Successfully| PAA[PropertyAnalyzerAgent]
    PPA -->|Parsing Failed| ParsingError[Parsing Error - Stop]

    ParsingError --> End([Analysis Complete - ERROR])

    PAA -->|Features Extracted| PEMA[PriceEstimationMLAgent]
    PAA -->|Feature Extraction Failed| AnalysisError[Analysis Error - Stop]

    AnalysisError --> End

    PAA -->|Features Extracted| RAMA[RiskAssessmentMLAgent]

    PEMA -->|Price Prediction Complete| MICLA[MarketIntentClassifierLLMAgent]
    RAMA -->|Risk Assessment Complete| MICLA

    PEMA -->|Price Prediction Failed| PriceError[Price Model Error]
    RAMA -->|Risk Assessment Failed| RiskError[Risk Model Error]

    PriceError --> End
    RiskError --> End

    MICLA -->|Market Intent Classified| MILA[MarketIntelligenceLLMAgent]
    MICLA -->|Intent Classification Failed| IntentError[Intent Classification Error]

    IntentError --> End

    MILA -->|Market Intelligence Analyzed| RGA[RecommendationGeneratorLLMAgent]
    MILA -->|Intelligence Analysis Failed| IntelligenceError[Intelligence Analysis Error]

    IntelligenceError --> End

    RGA -->|Recommendations Generated| RPGA[ReportGeneratorLLMAgent]
    RGA -->|Recommendation Generation Failed| RecommendationError[Recommendation Error]

    RecommendationError --> End

    RPGA -->|Report Generated| SaveAndReturn[Save Results & Return State]
    RPGA -->|Report Generation Failed| ReportError[Report Generation Error]

    ReportError --> End
    SaveAndReturn --> End

    style Start fill:#c8e6c9,stroke:#1b5e20,stroke-width:3px
    style End fill:#ffcdd2,stroke:#c62828,stroke-width:3px

    style PPA fill:#bbdefb,stroke:#0d47a1,stroke-width:2px
    style PAA fill:#c5cae9,stroke:#283593,stroke-width:2px
    style PEMA fill:#f8bbd0,stroke:#880e4f,stroke-width:2px
    style RAMA fill:#b2dfdb,stroke:#00695c,stroke-width:2px
    style MICLA fill:#ffe0b2,stroke:#e65100,stroke-width:2px
    style MILA fill:#f0f4c3,stroke:#9e9d24,stroke-width:2px
    style RGA fill:#d1c4e9,stroke:#512da8,stroke-width:2px
    style RPGA fill:#c8e6c9,stroke:#1b5e20,stroke-width:2px

    style SaveAndReturn fill:#fff9c4,stroke:#f57f17,stroke-width:2px

    style ParsingError fill:#ffcdd2,stroke:#c62828,stroke-width:2px,stroke-dasharray: 5 5
    style AnalysisError fill:#ffcdd2,stroke:#c62828,stroke-width:2px,stroke-dasharray: 5 5
    style PriceError fill:#ffcdd2,stroke:#c62828,stroke-width:2px,stroke-dasharray: 5 5
    style RiskError fill:#ffcdd2,stroke:#c62828,stroke-width:2px,stroke-dasharray: 5 5
    style IntentError fill:#ffcdd2,stroke:#c62828,stroke-width:2px,stroke-dasharray: 5 5
    style IntelligenceError fill:#ffcdd2,stroke:#c62828,stroke-width:2px,stroke-dasharray: 5 5
    style RecommendationError fill:#ffcdd2,stroke:#c62828,stroke-width:2px,stroke-dasharray: 5 5
    style ReportError fill:#ffcdd2,stroke:#c62828,stroke-width:2px,stroke-dasharray: 5 5


DIAGRAM EXPLANATION:
====================

AGENT SEQUENCE (8 Agents in Pipeline):

Stage 1: PropertyParserAgent (Blue)
  Input: Raw property JSON
  Process: Validate and normalize property data
  Output: Parsed property data
  On Error: Parsing Error - Stop pipeline
  Next: PropertyAnalyzerAgent

Stage 2: PropertyAnalyzerAgent (Blue-Gray)
  Input: Parsed property data
  Process: Extract 19 numeric features for ML models
  Output: Feature vector dictionary
  On Error: Analysis Error - Stop pipeline
  Next: PriceEstimationMLAgent & RiskAssessmentMLAgent (PARALLEL)

Stage 3a: PriceEstimationMLAgent (Pink)
  Input: Feature vector
  Process: ML model predicts property market price
  Output: Predicted price + confidence score
  On Error: Price Model Error - Stop pipeline
  Next: MarketIntentClassifierLLMAgent (waits for Stage 3b)

Stage 3b: RiskAssessmentMLAgent (Teal)
  Input: Feature vector
  Process: ML model classifies risk level (4 classes)
  Output: Risk level + risk score + confidence
  On Error: Risk Model Error - Stop pipeline
  Next: MarketIntentClassifierLLMAgent (waits for Stage 3a)

Stage 4: MarketIntentClassifierLLMAgent (Orange)
  Input: Property data + Price prediction + Risk assessment
  Process: LLM classifies market investment opportunity type
  Output: Opportunity type + market intent + classification rationale
  On Error: Intent Classification Error - Stop pipeline
  Next: MarketIntelligenceLLMAgent

Stage 5: MarketIntelligenceLLMAgent (Yellow)
  Input: Property data + All prior analysis
  Process: LLM analyzes market conditions and viability
  Output: Market insights + comparable properties + market trends
  On Error: Intelligence Analysis Error - Stop pipeline
  Next: RecommendationGeneratorLLMAgent

Stage 6: RecommendationGeneratorLLMAgent (Purple)
  Input: Property data + All prior analysis results
  Process: LLM generates investment recommendations
  Output: Recommendation + action items + risk mitigation strategies
  On Error: Recommendation Error - Stop pipeline
  Next: ReportGeneratorLLMAgent

Stage 7: ReportGeneratorLLMAgent (Green)
  Input: Complete PropertyValuationState (60+ fields)
  Process: LLM generates professional investment report
  Output: Text report + JSON report + quality metrics
  On Error: Report Generation Error - Stop pipeline
  Next: Save Results & Return

Final Stage: Save Results & Return
  Saves generated reports to output directory
  Returns complete PropertyValuationState with all analysis results


DATA FLOW BETWEEN AGENTS:
=========================

PropertyParserAgent → PropertyAnalyzerAgent
  Data: Parsed and normalized property dictionary

PropertyAnalyzerAgent → PriceEstimationMLAgent & RiskAssessmentMLAgent
  Data: Feature vector (19 numeric features)

PriceEstimationMLAgent → MarketIntentClassifierLLMAgent
  Data: Predicted price + confidence score

RiskAssessmentMLAgent → MarketIntentClassifierLLMAgent
  Data: Risk level + risk score + risk factors

MarketIntentClassifierLLMAgent → MarketIntelligenceLLMAgent
  Data: Opportunity type + market intent + classification results

MarketIntelligenceLLMAgent → RecommendationGeneratorLLMAgent
  Data: Market insights + comparable properties + market trends + viability

RecommendationGeneratorLLMAgent → ReportGeneratorLLMAgent
  Data: Investment recommendations + action items + risk mitigation

All Prior Agents → ReportGeneratorLLMAgent
  Data: Complete PropertyValuationState with all 60+ accumulated fields


PARALLEL EXECUTION:
===================

After PropertyAnalyzerAgent completes:
  - PriceEstimationMLAgent and RiskAssessmentMLAgent run in PARALLEL
  - Both receive same feature vector
  - Both execute simultaneously for faster processing
  - MarketIntentClassifierLLMAgent waits for BOTH to complete before proceeding


ERROR HANDLING:
===============

Each agent has error paths:
  - Parsing Error: Stop if property validation fails
  - Analysis Error: Stop if feature extraction fails
  - Price Model Error: Stop if ML price prediction fails
  - Risk Model Error: Stop if ML risk assessment fails
  - Intent Classification Error: Stop if LLM intent classification fails
  - Intelligence Analysis Error: Stop if LLM market analysis fails
  - Recommendation Error: Stop if LLM recommendation generation fails
  - Report Generation Error: Stop if LLM report generation fails

All errors return to End node with ERROR status
State includes error messages for debugging


STATE ACCUMULATION:
===================

PropertyValuationState grows through pipeline:

After Parser: 10 fields (original + parsed + normalized)
After Analyzer: 13 fields (+ extracted features)
After ML Agents: 25 fields (+ price + risk predictions)
After Intent Agent: 32 fields (+ opportunity type + intent)
After Intelligence Agent: 40 fields (+ market insights + trends)
After Recommendation Agent: 50 fields (+ recommendations + actions)
After Report Agent: 60+ fields (+ reports + quality metrics)

Final state includes all intermediate results for complete analysis trail


AGENT COMMUNICATION TYPES:
==========================

Sequential Communication:
  Parser → Analyzer → Price/Risk → Intent → Intelligence → Recommendation → Report

Parallel Communication:
  Analyzer → (Price & Risk simultaneously)

Convergent Communication:
  Price & Risk → Intent (both must complete)

All agents use PropertyValuationState as central state object
State is immutable - each node returns updated fields only
LangGraph merges partial dicts from each node into unified state
