INVESTPULSE AGENT COMMUNICATION FLOW REFERENCE GUIDE

This document provides a detailed reference for understanding how agents communicate
and pass data through the InvestPulse pipeline.


SECTION 1: AGENT EXECUTION SEQUENCE
================================================================================

The agents execute in a specific sequence defined by LangGraph workflow:

SEQUENCE DIAGRAM:

Time    Agent                          Input                    Output
----    -----                          -----                    ------

T0      [START]
        Property Analysis Begins
        Raw property JSON provided

T1      PropertyParserAgent            Raw JSON (4-5 fields)     Parsed Property (15+ fields)
        Validate & Normalize
        - Check required fields
        - Calculate derived fields
        - Normalize field aliases
        - Set parsing_complete = True

T2      PropertyAnalyzerAgent          Parsed Property          Extracted Features (19 numeric)
        Extract Features
        - Calculate property_age
        - Encode property_type
        - Engineer features
        - Set analysis_complete = True

T3a     PriceEstimationMLAgent         Features (19 vector)     Price + Confidence
T3b     RiskAssessmentMLAgent          Features (19 vector)     Risk + Score + Factors
        [RUNS IN PARALLEL - Same Input, Different Models]
        Price Agent: RandomForest Regression
        Risk Agent: RandomForest Classification
        Both complete independently
        Both must finish before proceeding

T4      MarketIntentClassifierLLMAgent Property + Predictions   Opportunity Type + Intent
        Requires BOTH Price AND Risk complete
        - Analyze property characteristics
        - Consider price position
        - Consider risk level
        - LLM classifies market opportunity
        - Set intent_classification_complete = True

T5      MarketIntelligenceLLMAgent     Property + All Prior     Market Insights + Trends
        Requires Intent complete
        - Analyze market conditions
        - Find comparable properties
        - Assess investment viability
        - LLM provides market analysis
        - Set intelligence_analysis_complete = True

T6      RecommendationGeneratorLLMAgent Property + All Prior    Recommendations + Actions
        Requires Intelligence complete
        - Generate investment recommendation
        - Create action items list
        - Suggest risk mitigation
        - Set priority level
        - Set recommendation_generation_complete = True

T7      ReportGeneratorLLMAgent        Complete State (60+)     Reports + Metrics + Files
        Requires Recommendations complete
        - Generate text report (~1500+ words)
        - Generate JSON report (structured)
        - Calculate quality metrics
        - Save files to output directory
        - Set report_generation_complete = True

T8      [END]
        Return complete PropertyValuationState
        All 60+ fields populated


SECTION 2: DATA FLOW BETWEEN AGENTS
================================================================================

AGENT 1: PropertyParserAgent → AGENT 2: PropertyAnalyzerAgent

Incoming Data Structure:
{
  "property_json": {...},         Raw input from user
  "property_id": "PROP-001",
  "address": "123 Main St",
  "city": "Seattle",
  "state": "WA",
  "zip_code": "98101"
}

Processing:
  - Validates all required fields present
  - Normalizes field names (square_footage vs square_feet)
  - Calculates property_age from year_built
  - Converts property_type to numeric (1-5)
  - Ensures all numeric fields have values

Outgoing Data Structure:
{
  "parsed_property": {
    "property_id": "PROP-001",
    "address": "123 Main St",
    ... all normalized fields ...
    "property_age": 20,
    "year_built": 2005,
    ... all numeric fields validated ...
  },
  "property_headers_normalized": {
    "property_id": "PROP-001",
    "address": "123 Main St",
    "city": "Seattle",
    "state": "WA",
    "zip_code": "98101",
    "country": "USA"
  },
  "parsing_complete": true,
  "parsing_errors": []
}

State Update in PropertyValuationState:
  + parsed_property
  + property_headers_normalized
  + parsing_complete
  + parsing_errors
  (3-4 new fields added to state)


AGENT 2: PropertyAnalyzerAgent → AGENTS 3a & 3b (Parallel)

Incoming Data:
{
  "parsed_property": {...},
  ... all prior state fields ...
}

Processing:
  - Extracts 14 core features (square_feet, bedrooms, bathrooms, etc.)
  - Encodes property_type as numeric (1-5)
  - Calculates 4 engineered features:
    - bed_bath_ratio = bedrooms / bathrooms
    - sqft_per_bedroom = square_feet / bedrooms
    - market_age_index = market_trend * property_age
    - price_gap_pct = price variation percentage
  - Returns 19 features in order expected by ML models

Outgoing Data Structure:
{
  "extracted_features": {
    "square_feet": 2500,
    "bedrooms": 4,
    "bathrooms": 2.5,
    "property_age": 20,
    "condition_score": 8,
    "garage_spaces": 2,
    "has_pool": 0,
    "lot_size": 8000,
    "neighborhood_score": 85,
    "school_rating": 9,
    "days_on_market": 30,
    "price_per_sqft": 400,
    "market_trend_pct": 2.5,
    "employment_rate_pct": 95,
    "property_type": 1,                 Encoded: residential=1
    "bed_bath_ratio": 1.6,              Engineered
    "sqft_per_bedroom": 625,            Engineered
    "market_age_index": 50,             Engineered
    "price_gap_pct": 8.5                Engineered
  },
  "analysis_complete": true
}

State Update:
  + extracted_features (Dict with 19 numeric values)
  + analysis_complete (bool = True)
  (2 new fields)

Both Price and Risk agents receive SAME extracted_features


AGENT 3a: PriceEstimationMLAgent → AGENT 4: MarketIntentClassifierLLMAgent

Incoming Data:
{
  "extracted_features": {
    19 numeric features as feature vector
  }
}

Processing:
  1. Convert feature dict to numpy array in model's expected order
  2. Normalize array using StandardScaler (loaded from pickle)
  3. Pass to trained RandomForest regressor (100 trees, depth 10)
  4. Get prediction and calculate confidence

ML Model Details:
  Model Type: RandomForest Regressor
  Parameters: n_estimators=100, max_depth=10, random_state=42
  Training: Trained on 20,416 price samples (80% of 25,508 cleaned data)
  Testing: Tested on 5,092 samples (20% of cleaned data)
  Performance: Test R² = 0.8957 (89.57% accuracy)

Outgoing Data Structure:
{
  "predicted_price": 751943,              Float (market value in dollars)
  "price_confidence": 0.95,               Float (0-1 confidence score)
  "price_model_metrics": {
    "test_r2": 0.8957,
    "test_mae": 53869,
    "test_rmse": 70517,
    "test_mape": 11.05
  },
  "price_estimation_complete": true
}

State Update:
  + predicted_price (float)
  + price_confidence (float)
  + price_model_metrics (dict)
  + price_estimation_complete (bool = True)
  (4 new fields)

Data Passed to Next Agent:
  - predicted_price: $751,943
  - price_confidence: 95% confidence in this prediction


AGENT 3b: RiskAssessmentMLAgent → AGENT 4: MarketIntentClassifierLLMAgent

Incoming Data:
{
  "extracted_features": {
    19 numeric features as feature vector
  }
}

Processing:
  1. Convert feature dict to numpy array
  2. Normalize using StandardScaler (loaded from pickle)
  3. Pass to trained RandomForest classifier (100 trees, depth 10)
  4. Get prediction class and class probabilities
  5. Decode class to risk level using LabelEncoder
  6. Calculate risk_score from probabilities (0-10 scale)
  7. Identify applicable risk factors

ML Model Details:
  Model Type: RandomForest Classifier (4 classes)
  Classes: safe, moderate, risky, very_risky
  Parameters: n_estimators=100, max_depth=10, class_weight=balanced
  Training: Trained on 18,324 risk samples (80% of 22,905 cleaned data)
  Testing: Tested on 4,581 samples (20% of cleaned data)
  Performance: Test Accuracy = 0.8282 (82.82% accuracy)

Risk Score Calculation (0-10 scale):
  score = (prob[very_risky] * 10.0 +
           prob[risky] * 6.0 +
           prob[moderate] * 3.0 +
           prob[safe] * 0.0)

Risk Factors (detected if conditions met):
  - Property age > 50 years: "Old property requiring maintenance"
  - Condition score < 5: "Poor property condition"
  - Neighborhood score < 40: "Low neighborhood desirability"
  - Days on market > 100: "Property on market too long"

Outgoing Data Structure:
{
  "risk_level": "moderate",               String from [safe, moderate, risky, very_risky]
  "risk_score": 4.5,                      Float (0-10 scale)
  "risk_confidence": 0.87,                Float (0-1 confidence)
  "risk_factors": [                       List of identified risk factors
    "Fair property condition",
    "Market showing modest growth"
  ],
  "risk_assessment_complete": true
}

State Update:
  + risk_level (string)
  + risk_score (float)
  + risk_confidence (float)
  + risk_factors (list)
  + risk_assessment_complete (bool = True)
  (5 new fields)

Data Passed to Next Agent:
  - risk_level: "moderate" (one of 4 classes)
  - risk_score: 4.5/10
  - risk_confidence: 87% confidence


AGENTS 3a + 3b → AGENT 4: MarketIntentClassifierLLMAgent (Convergence Point)

WAIT CONDITION:
  Agent 4 waits for BOTH Agent 3a AND Agent 3b to complete
  - Price prediction must be complete
  - Risk assessment must be complete
  - Both data merged into single state
  - Then Agent 4 receives merged data

Incoming Data (Combined from both ML agents):
{
  "property_json": {...},                 Original property data
  "parsed_property": {...},               Normalized property data
  "extracted_features": {...},            19 features

  "predicted_price": 751943,              FROM Agent 3a
  "price_confidence": 0.95,               FROM Agent 3a

  "risk_level": "moderate",               FROM Agent 3b
  "risk_score": 4.5,                      FROM Agent 3b
  "risk_factors": [...]                   FROM Agent 3b
}

Processing:
  LLM Prompt includes:
    - Property address and location
    - Property specifications (type, size, condition)
    - Estimated market price from ML
    - Risk level classification
    - Current market conditions

  LLM Classification Task:
    Classify property into opportunity type category
    Options: primary_residence, investment_property, rental_income,
             fix_and_flip, commercial_opportunity, land_development,
             portfolio_diversification

Outgoing Data Structure:
{
  "opportunity_type": "investment_property",    LLM classified type
  "market_intent": "Long-term rental investment with strong fundamentals",
  "intent_confidence": 0.88,                    LLM confidence (0-1)
  "intent_analysis": {                          Full LLM analysis
    "classification_rationale": "...",
    "market_alignment": "...",
    "risk_factors": [...]
  },
  "intent_classification_complete": true
}

State Update:
  + opportunity_type (string)
  + market_intent (string)
  + intent_confidence (float)
  + intent_analysis (dict)
  + intent_classification_complete (bool = True)
  (5 new fields)

CUMULATIVE STATE AT THIS POINT: 30+ fields


AGENT 4: MarketIntentClassifierLLMAgent → AGENT 5: MarketIntelligenceLLMAgent

Incoming Data:
{
  Complete state with 30+ fields:
  - All property information
  - All ML predictions
  - Market opportunity classification
  - All confidence scores
  - All analysis results
}

Processing:
  LLM Prompt includes:
    - Property location and characteristics
    - Market price and risk assessment
    - Opportunity classification
    - Local market conditions

  LLM Analysis Task:
    1. Analyze market conditions at property location
    2. Research comparable properties
    3. Assess investment viability
    4. Identify market trends
    5. Evaluate employment and economic factors

Outgoing Data Structure:
{
  "market_insights": {
    "location_appeal": "Urban, growing tech hub",
    "market_momentum": "Steady growth",
    "economic_health": "Strong employment",
    "trends": "Consistent appreciation",
    "employment_rate": 95
  },

  "comparable_properties": [
    {
      "address": "456 Oak Ave",
      "price": 720000,
      "beds": 4,
      "baths": 2.5,
      "sqft": 2300,
      "similarity_score": 0.94
    },
    {
      "address": "789 Pine St",
      "price": 780000,
      "beds": 4,
      "baths": 2.5,
      "sqft": 2400,
      "similarity_score": 0.91
    }
  ],

  "market_trends": {
    "direction": "upward",
    "strength": "moderate",
    "appreciation_rate": 2.5,
    "forecast": "continued growth",
    "risk_alignment": "favorable"
  },

  "investment_viability": "Viable with conditions - Strong market fundamentals support investment",

  "intelligence_analysis_complete": true
}

State Update:
  + market_insights (dict)
  + comparable_properties (list of dicts)
  + market_trends (dict)
  + investment_viability (string)
  + intelligence_analysis_complete (bool = True)
  (5 new fields)

CUMULATIVE STATE AT THIS POINT: 35+ fields


AGENT 5: MarketIntelligenceLLMAgent → AGENT 6: RecommendationGeneratorLLMAgent

Incoming Data:
{
  Complete state with 35+ fields:
  - All property and market information
  - All predictions and assessments
  - Market intelligence and viability
  - Comparable properties data
}

Processing:
  LLM Prompt includes:
    - Complete property and market analysis
    - Price estimate and confidence
    - Risk level and factors
    - Opportunity classification
    - Market viability assessment

  LLM Recommendation Task:
    1. Generate investment recommendation (BUY/CONDITIONAL BUY/HOLD/PASS)
    2. Create action items list (4 items)
    3. Suggest risk mitigation strategies (3 items)
    4. Determine action priority (High/Medium/Low/Critical)
    5. Assess escalation level (L1/L2/L3)

Outgoing Data Structure:
{
  "recommended_action": "CONDITIONAL BUY",              Investment decision

  "investment_recommendation": "This property represents a solid investment
    opportunity with moderate risk. Recommend proceeding with thorough due diligence...",

  "investment_actions": [
    "Schedule comprehensive property inspection",
    "Research comparable rental rates in area",
    "Evaluate mortgage financing options",
    "Consult with real estate attorney for review"
  ],

  "risk_mitigation": [
    "Build 10% reserve fund for repairs and maintenance",
    "Diversify investment portfolio across multiple properties",
    "Maintain adequate property insurance coverage"
  ],

  "action_priority": "High",                            High/Medium/Low/Critical

  "escalation_level": "L2",                            L1/L2/L3 based on risk

  "recommendation_generation_complete": true
}

State Update:
  + recommended_action (string)
  + investment_recommendation (string)
  + investment_actions (list)
  + risk_mitigation (list)
  + action_priority (string)
  + escalation_level (string)
  + recommendation_generation_complete (bool = True)
  (7 new fields)

CUMULATIVE STATE AT THIS POINT: 42+ fields


AGENT 6: RecommendationGeneratorLLMAgent → AGENT 7: ReportGeneratorLLMAgent

Incoming Data:
{
  Complete state with 42+ fields:
  - All property information
  - All analysis results
  - All predictions and assessments
  - All recommendations and strategies
}

Processing:
  LLM Prompt includes:
    - Complete analysis summary
    - All metrics and assessments
    - Recommendations and action items

  Report Generation Task:
    1. Create executive summary (2-3 paragraphs)
    2. Property overview section
    3. Market analysis section
    4. Investment metrics section
    5. Risk analysis section
    6. Opportunity assessment section
    7. Recommendations section
    8. Conclusion and next steps
    9. Calculate quality metrics (6 metrics, 0-1 scale)

Outgoing Data Structure:
{
  "investment_report": "INVESTPULSE INVESTMENT ANALYSIS REPORT\n
    Generated: 2025-12-06 15:30:45 UTC\n\n
    EXECUTIVE SUMMARY\n
    This property at 123 Main St, Seattle represents a solid investment...",

  "report_json": {
    "metadata": {
      "report_id": "REPORT-001-2025-12-06",
      "property_id": "PROP-001",
      "generated_timestamp": "2025-12-06T15:30:45Z",
      "report_version": "1.0"
    },
    "property_info": {...},
    "analysis_results": {...},
    "market_analysis": {...},
    "recommendations": {...},
    "quality_metrics": {...}
  },

  "quality_metrics": {
    "parsing_quality": 0.95,                  95% quality
    "analysis_completeness": 1.0,             100% complete
    "price_confidence": 0.92,                 92% confidence
    "risk_assessment_confidence": 0.85,       85% confidence
    "recommendation_clarity": 0.90,           90% clarity
    "overall_report_quality": 0.92            92% overall
  },

  "saved_path": "output/PROP-001_2025-12-06T153045.txt",

  "output_dir": "output",

  "report_generation_complete": true
}

State Update:
  + investment_report (string, 1500+ words)
  + report_json (dict)
  + quality_metrics (dict)
  + saved_path (string)
  + output_dir (string)
  + report_generation_complete (bool = True)
  (6 new fields)

FINAL CUMULATIVE STATE: 60+ fields


SECTION 3: COMPLETE STATE AT EACH STAGE
================================================================================

Initial State (Input):
  Fields: 4-5
  Contain: property_json, property_id, address, city, etc.

After Parser:
  Fields: 8-10
  Added: parsed_property, property_headers_normalized, parsing_complete

After Analyzer:
  Fields: 10-12
  Added: extracted_features (19 features), analysis_complete

After Price Model:
  Fields: 14-16
  Added: predicted_price, price_confidence, price_model_metrics, price_estimation_complete

After Risk Model:
  Fields: 19-21
  Added: risk_level, risk_score, risk_confidence, risk_factors, risk_assessment_complete

After Intent Agent:
  Fields: 24-26
  Added: opportunity_type, market_intent, intent_confidence, intent_analysis, intent_classification_complete

After Intelligence Agent:
  Fields: 29-31
  Added: market_insights, comparable_properties, market_trends, investment_viability, intelligence_analysis_complete

After Recommendation Agent:
  Fields: 36-38
  Added: investment_recommendation, investment_actions, risk_mitigation, action_priority, escalation_level, recommendation_generation_complete

After Report Agent:
  Fields: 42-44
  Added: investment_report, report_json, quality_metrics, saved_path, report_generation_complete

FINAL STATE: 60+ accumulated fields tracking complete analysis


SECTION 4: ERROR HANDLING IN AGENT COMMUNICATION
================================================================================

Each agent has error handling:

Parser Error:
  If validation fails → Set parsing_complete = False, add error message → STOP

Analyzer Error:
  If feature extraction fails → Set analysis_complete = False, add error message → STOP

Price Model Error:
  If prediction fails → Set price_estimation_complete = False, add error message → STOP

Risk Model Error:
  If classification fails → Set risk_assessment_complete = False, add error message → STOP

Intent Error:
  If LLM fails → Set intent_classification_complete = False, add error message → STOP

Intelligence Error:
  If LLM fails → Set intelligence_analysis_complete = False, add error message → STOP

Recommendation Error:
  If LLM fails → Set recommendation_generation_complete = False, add error message → STOP

Report Error:
  If LLM fails → Set report_generation_complete = False, add error message → RETURN

All errors preserve partial state for debugging


SECTION 5: KEY COMMUNICATION PATTERNS
================================================================================

Pattern 1: SEQUENTIAL COMMUNICATION
  Agent A → Agent B → Agent C → ...
  Example: Parser → Analyzer → Price Agent
  One agent must complete before next starts
  Data flows linearly through pipeline

Pattern 2: PARALLEL COMMUNICATION
  Agent A → [Agent B + Agent C] (simultaneously)
  Example: Analyzer → [Price Agent + Risk Agent]
  Both receive same input
  Both execute independently
  Both must complete before next stage

Pattern 3: CONVERGENT COMMUNICATION
  [Agent A + Agent B] → Agent C
  Example: [Price Agent + Risk Agent] → Intent Agent
  Both prior agents must complete
  Both outputs merged into single state
  Single agent receives merged data

Pattern 4: BROADCAST COMMUNICATION
  Agent A → [Agent B, Agent C, Agent D, ...]
  Example: Parser → All downstream agents have access to parsed_property
  All agents can access all previous state
  Each agent extracts needed data from state
  No inter-agent direct communication

Pattern 5: STATE ACCUMULATION
  Each agent adds to state, never removes
  State grows from 4 fields to 60+ fields
  All prior analysis preserved
  Later agents can access all prior results


SUMMARY
================================================================================

InvestPulse uses a sophisticated agent communication pattern:

1. 8 agents execute in defined sequence
2. Data flows through PropertyValuationState (central state object)
3. Parallel execution where possible (Price + Risk models)
4. Convergence points where parallel paths merge
5. Error handling at each stage stops pipeline if needed
6. State accumulates analysis results throughout pipeline
7. LLM agents use complete prior context for decisions
8. Final state contains 60+ fields of complete analysis
9. Multiple output formats (UI, text report, JSON)
10. All agent communication is transparent and traceable

This architecture ensures:
  - Efficiency (parallel execution where possible)
  - Reliability (error handling at each stage)
  - Completeness (60+ field state covers all analysis)
  - Debuggability (all steps preserved in state)
  - Scalability (easy to add new agents)
