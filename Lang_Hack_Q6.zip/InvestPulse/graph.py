#!/usr/bin/env python3

import json
import logging
from typing import Dict, Any
from workflow.workflow import run_property_analysis_workflow

logger = logging.getLogger(__name__)


def analyze_property(property_json: Dict[str, Any], llm_client=None) -> Dict[str, Any]:
    return run_property_analysis_workflow(property_json, llm_client)


def analyze_property_from_file(file_path: str, llm_client=None) -> Dict[str, Any]:
    try:
        with open(file_path, "r") as f:
            property_json = json.load(f)
        return analyze_property(property_json, llm_client)

    except Exception as e:
        logger.error(f"Error loading property from file: {str(e)}")
        return {
            "error": True,
            "error_message": f"Failed to load property from {file_path}: {str(e)}"
        }


def get_threat_summary(result: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "property_id": result.get("property_id", "UNKNOWN"),
        "address": result.get("address", ""),
        "city": result.get("city", ""),
        "predicted_price": result.get("predicted_price", 0),
        "price_confidence": result.get("price_confidence", 0),
        "risk_level": result.get("risk_level", "unknown"),
        "risk_score": result.get("risk_score", 0),
        "risk_confidence": result.get("risk_confidence", 0),
        "opportunity_type": result.get("opportunity_type", ""),
        "market_intent": result.get("market_intent", ""),
        "investment_viability": result.get("investment_viability", ""),
        "investment_recommendation": result.get("investment_recommendation", ""),
        "quality_metrics": result.get("quality_metrics", {}),
    }


def print_threat_summary(result: Dict[str, Any]) -> None:
    summary = get_threat_summary(result)

    print("\n" + "="*80)
    print("PROPERTY INVESTMENT ANALYSIS SUMMARY")
    print("="*80)
    print(f"\nProperty: {summary['address']}, {summary['city']}")
    print(f"Property ID: {summary['property_id']}")
    print(f"\nPrice Analysis:")
    print(f"  Estimated Price: ${summary['predicted_price']:,.2f}")
    print(f"  Confidence: {summary['price_confidence']:.1%}")
    print(f"\nRisk Assessment:")
    print(f"  Risk Level: {summary['risk_level'].upper()}")
    print(f"  Risk Score: {summary['risk_score']:.1f}/10")
    print(f"  Risk Confidence: {summary['risk_confidence']:.1%}")
    print(f"\nMarket Analysis:")
    print(f"  Opportunity Type: {summary['opportunity_type']}")
    print(f"  Market Intent: {summary['market_intent']}")
    print(f"  Investment Viability: {summary['investment_viability']}")
    print(f"\nRecommendation:")
    print(f"  {summary['investment_recommendation']}")
    print(f"\nQuality Metrics:")
    for metric, value in summary['quality_metrics'].items():
        print(f"  {metric.replace('_', ' ').title()}: {value:.1%}")
    print("\n" + "="*80 + "\n")


def get_risk_classification(result: Dict[str, Any]) -> str:
    risk_level = result.get("risk_level", "moderate")
    risk_score = result.get("risk_score", 5.0)

    if risk_level == "safe" and risk_score < 3:
        return "LOW RISK"
    elif risk_level in ["safe", "moderate"] and risk_score < 6:
        return "MODERATE RISK"
    elif risk_level in ["moderate", "risky"] and risk_score < 8:
        return "HIGH RISK"
    else:
        return "CRITICAL RISK"
