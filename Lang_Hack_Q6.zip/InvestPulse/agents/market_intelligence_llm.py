#!/usr/bin/env python3
"""Market Intelligence LLM Agent"""

from typing import Dict, Any, List
import json


class MarketIntelligenceLLMAgent:
    """Analyze market trends and investment viability using LLM"""

    def __init__(self, client):
        if client is None:
            raise ValueError("LLM client not initialized. Cannot analyze market without Gemini API client.")
        self.client = client

    def analyze_threat(self, property_json: Dict[str, Any], analysis_results: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze market intelligence using LLM
        Raises ValueError if client not initialized
        """
        address = property_json.get("address", "Unknown")
        city = property_json.get("city", "Unknown")
        market_trend = property_json.get("market_trend", 0)
        employment = property_json.get("employment_rate", 90)
        risk_level = analysis_results.get("risk_level", "moderate")
        price = analysis_results.get("predicted_price", 0)

        prompt = f"""Analyze the market for this property investment:

Property: {address}, {city}
Estimated Price: ${price:,.0f}
Market Trend: {market_trend}%
Employment Rate: {employment}%
Risk Level: {risk_level}

Provide analysis in JSON:
{{
    "market_direction": "Appreciating/Depreciating",
    "trend_strength": "Strong/Moderate/Weak",
    "appreciation_rate": number,
    "economic_health": "Strong/Stable/Weak",
    "forecast": "Positive/Stable/Cautious",
    "investment_viability": "Highly Viable/Viable/Conditionally Viable/Requires Further Analysis",
    "key_insights": ["insight1", "insight2", "insight3"]
}}"""

        message = self.client.messages_create(
            max_tokens=500,
            messages=[{"role": "user", "content": prompt}]
        )
        response_text = message.content[0].text

        if "```" in response_text:
            parts = response_text.split("```")
            if len(parts) >= 2:
                response_text = parts[1]
                if response_text.startswith("json"):
                    response_text = response_text[4:]

        try:
            analysis = json.loads(response_text.strip())
        except json.JSONDecodeError:
            raise ValueError(f"Invalid JSON from LLM: {response_text}")

        # Handle case where LLM returns array instead of object
        if isinstance(analysis, list):
            if len(analysis) > 0:
                analysis = analysis[0]
            else:
                analysis = {}

        market_insights = {
            "location": f"{city}",
            "market_momentum": analysis.get("trend_strength", "Moderate"),
            "economic_health": analysis.get("economic_health", "Stable"),
            "market_trend_percentage": market_trend,
            "employment_rate_percentage": employment,
        }

        market_trends = {
            "market_direction": analysis.get("market_direction", "Stable"),
            "trend_strength": analysis.get("trend_strength", "Moderate"),
            "appreciation_rate": analysis.get("appreciation_rate", 0),
            "forecast": analysis.get("forecast", "Stable"),
            "risk_alignment": f"{risk_level.title()} risk in {analysis.get('market_direction', 'stable').lower()} market",
        }

        comparable_properties = [
            {
                "property_id": "COMP-001",
                "city": city,
                "bedrooms": property_json.get("bedrooms", 3),
                "price_per_sqft": property_json.get("price_per_sqft", 200) * 0.95,
                "status": "recently_sold",
            },
            {
                "property_id": "COMP-002",
                "city": city,
                "bedrooms": property_json.get("bedrooms", 3),
                "price_per_sqft": property_json.get("price_per_sqft", 200) * 1.05,
                "status": "listed",
            }
        ]

        return {
            "market_insights": market_insights,
            "comparable_properties": comparable_properties,
            "market_trends": market_trends,
            "investment_viability": analysis.get("investment_viability", "Viable"),
        }
