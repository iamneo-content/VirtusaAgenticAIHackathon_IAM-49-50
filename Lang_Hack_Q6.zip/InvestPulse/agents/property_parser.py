#!/usr/bin/env python3

from typing import Dict, Any


class PropertyParserAgent:
    def __init__(self):
        pass

    def parse_and_validate(self, property_json: Dict[str, Any]) -> Dict[str, Any]:
        """
        Parse, validate, normalize and extract metadata from property JSON.
        Raises ValueError if required fields are missing.
        """
        required_fields = [
            "property_id", "address", "city", "square_footage",
            "bedrooms", "bathrooms", "condition_score"
        ]

        errors = []
        for field in required_fields:
            if field not in property_json:
                errors.append(f"Missing required field: {field}")

        if errors:
            raise ValueError(f"Property validation failed: {'; '.join(errors)}")

        # Calculate property_age from year_built if not present
        if "property_age" not in property_json:
            from datetime import datetime
            year_built = property_json.get("year_built", datetime.now().year)
            property_json["property_age"] = datetime.now().year - int(year_built)

        # Extract metadata inline
        metadata = {
            "property_id": property_json.get("property_id", ""),
            "address": property_json.get("address", ""),
            "city": property_json.get("city", ""),
            "state": property_json.get("state", ""),
            "zip_code": property_json.get("zip_code", ""),
            "country": property_json.get("country", "USA"),
        }

        # Normalize numeric data inline with field name aliases
        field_aliases = {
            "square_footage": ["square_footage", "square_feet"],
            "market_trend": ["market_trend", "market_trend_pct"],
            "employment_rate": ["employment_rate", "employment_rate_pct"],
            "lot_size": ["lot_size", "lot_size_sqft"],
        }

        normalized = {}

        # Handle aliased fields
        for canonical_name, aliases in field_aliases.items():
            value = None
            for alias in aliases:
                if alias in property_json:
                    value = property_json.get(alias)
                    break
            if value is not None:
                try:
                    normalized[canonical_name] = float(value) if isinstance(value, (int, float, str)) else value
                except (ValueError, TypeError):
                    normalized[canonical_name] = 0.0
            else:
                normalized[canonical_name] = 0.0

        # Handle non-aliased numeric fields
        numeric_fields = [
            "bedrooms", "bathrooms", "property_age",
            "condition_score", "garage_spaces", "has_pool",
            "neighborhood_score", "school_rating", "days_on_market",
            "price_per_sqft"
        ]

        for field in numeric_fields:
            value = property_json.get(field)
            if value is not None:
                try:
                    normalized[field] = float(value) if isinstance(value, (int, float, str)) else value
                except (ValueError, TypeError):
                    normalized[field] = 0.0
            else:
                normalized[field] = 0.0

        normalized["property_type"] = property_json.get("property_type", "residential")
        normalized["year_built"] = property_json.get("year_built", 2000)

        # Ensure all required fields exist with proper names for ML pipeline
        normalized["square_feet"] = normalized.pop("square_footage")
        normalized["market_trend_pct"] = normalized.pop("market_trend")
        normalized["employment_rate_pct"] = normalized.pop("employment_rate")

        # Return comprehensive parsed property
        return {
            **metadata,
            **normalized,
        }
