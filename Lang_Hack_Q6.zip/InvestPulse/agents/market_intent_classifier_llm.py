#!/usr/bin/env python3
"""Market Intent Classifier LLM Agent"""

from typing import Dict, Any
import json


class MarketIntentClassifierLLMAgent:
    """Classify market opportunity and investment intent using LLM"""

    def __init__(self, client):
        if client is None:
            raise ValueError("LLM client not initialized. Cannot classify intent without Gemini API client.")
        self.client = client

    def classify_intent(self, property_json: Dict[str, Any], analysis_results: Dict[str, Any]) -> Dict[str, Any]:
        """
        Classify market intent using LLM analysis
        Raises ValueError if client not initialized
        """
        subject = f"{property_json.get('address', '')} in {property_json.get('city', '')}"
        price = analysis_results.get("predicted_price", 0)
        risk_level = analysis_results.get("risk_level", "moderate")
        bedrooms = property_json.get("bedrooms", 0)
        property_type = property_json.get("property_type", "residential")

        prompt = f"""Analyze this real estate investment opportunity and classify the market intent:

Property: {subject}
Type: {property_type}
Bedrooms: {bedrooms}
Estimated Price: ${price:,.0f}
Risk Level: {risk_level}

Possible opportunities:
- primary_residence: Owner-occupied family home
- investment_property: Rental/investment focused
- rental_income: Strong rental income potential
- fix_and_flip: Requires renovation before resale
- commercial_opportunity: Commercial use potential
- land_development: Development/subdivision potential
- portfolio_diversification: Mixed portfolio addition

Respond with JSON:
{{
    "opportunity_type": "one_of_above",
    "market_intent": "brief_intent_description",
    "confidence": 0.0-1.0,
    "reasoning": "explanation"
}}"""

        message = self.client.messages_create(
            max_tokens=500,
            messages=[{"role": "user", "content": prompt}]
        )
        response_text = message.content[0].text

        if "```" in response_text:
            parts = response_text.split("```")
            if len(parts) >= 2:
                response_text = parts[1]
                if response_text.startswith("json"):
                    response_text = response_text[4:]

        try:
            result = json.loads(response_text.strip())
        except json.JSONDecodeError:
            raise ValueError(f"Invalid JSON from LLM: {response_text}")

        # Handle case where LLM returns array instead of object
        if isinstance(result, list):
            if len(result) > 0:
                result = result[0]
            else:
                result = {}

        return {
            "opportunity_type": result.get("opportunity_type", "investment_property"),
            "market_intent": result.get("market_intent", ""),
            "intent_confidence": float(result.get("confidence", 0.5)),
            "classification_rationale": result.get("reasoning", "")
        }
