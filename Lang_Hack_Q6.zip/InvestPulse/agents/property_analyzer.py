#!/usr/bin/env python3

from typing import Dict


class PropertyAnalyzerAgent:
    def __init__(self):
        pass

    def extract_numeric_features(self, parsed_property: Dict) -> Dict[str, float]:
        """
        Extract and engineer all numeric features for ML models.
        Includes core features, encoded property type, and engineered features.
        """
        features = {}

        # Core features
        core_features = [
            "square_feet", "bedrooms", "bathrooms", "property_age",
            "condition_score", "garage_spaces", "has_pool", "lot_size",
            "neighborhood_score", "school_rating", "days_on_market",
            "price_per_sqft", "market_trend_pct", "employment_rate_pct"
        ]

        for feature in core_features:
            value = parsed_property.get(feature, 0.0)
            features[feature] = float(value) if value is not None else 0.0

        # Encode property type inline
        type_mapping = {
            "residential": 1.0, "condo": 2.0, "townhouse": 3.0,
            "commercial": 4.0, "multi_family": 5.0,
        }
        property_type = parsed_property.get("property_type", "residential")
        features["property_type"] = type_mapping.get(property_type.lower(), 1.0)

        # Engineered features
        bedrooms = parsed_property.get("bedrooms", 1)
        bathrooms = parsed_property.get("bathrooms", 1)
        bed_bath_ratio = float(bedrooms) / float(bathrooms) if bathrooms > 0 else 0.0
        features["bed_bath_ratio"] = bed_bath_ratio

        square_feet = parsed_property.get("square_feet", 1)
        sqft_per_bedroom = float(square_feet) / float(bedrooms) if bedrooms > 0 else 0.0
        features["sqft_per_bedroom"] = sqft_per_bedroom

        property_age = parsed_property.get("property_age", 0)
        days_on_market = parsed_property.get("days_on_market", 0)
        market_age_index = (float(property_age) * float(days_on_market)) / 100.0 if property_age > 0 else 0.0
        features["market_age_index"] = market_age_index

        sale_price = parsed_property.get("sale_price", 0)
        list_price = parsed_property.get("list_price", sale_price)
        price_gap_pct = 0.0
        if list_price > 0:
            price_gap_pct = ((sale_price - list_price) / list_price) * 100.0
        features["price_gap_pct"] = price_gap_pct

        return features
