#!/usr/bin/env python3
"""Price Estimation ML Agent"""

import pickle
import numpy as np
from typing import Dict, Tuple
import os


class PriceEstimationMLAgent:
    """Predict property market price using trained ML model"""

    FEATURE_NAMES = [
        "square_feet", "bedrooms", "bathrooms", "property_age", "condition_score",
        "garage_spaces", "has_pool", "lot_size", "neighborhood_score", "school_rating",
        "days_on_market", "price_per_sqft", "market_trend_pct", "employment_rate_pct",
        "property_type", "bed_bath_ratio", "sqft_per_bedroom", "market_age_index", "price_gap_pct"
    ]

    def __init__(self, model_dir: str = "ml/models"):
        self.model_dir = model_dir
        self.model = None
        self.scaler = None
        self._load_model()

    def _load_model(self):
        """Load model and scaler. Raises FileNotFoundError if not found."""
        model_path = os.path.join(self.model_dir, "price_estimation_model.pkl")
        scaler_path = os.path.join(self.model_dir, "price_estimation_scaler.pkl")

        if not os.path.exists(model_path):
            raise FileNotFoundError(f"Model not found at {model_path}. Run training pipeline first.")
        if not os.path.exists(scaler_path):
            raise FileNotFoundError(f"Scaler not found at {scaler_path}. Run training pipeline first.")

        with open(model_path, "rb") as f:
            self.model = pickle.load(f)
        with open(scaler_path, "rb") as f:
            self.scaler = pickle.load(f)

    def predict_price(self, extracted_features: Dict[str, float]) -> Tuple[float, float]:
        """
        Predict property price from features.
        Returns (predicted_price, confidence_score)
        Raises ValueError if model not initialized
        """
        if self.model is None or self.scaler is None:
            raise ValueError("ML model not initialized. Cannot predict price.")

        features = np.array([extracted_features.get(name, 0.0) for name in self.FEATURE_NAMES], dtype=np.float32)
        X_scaled = self.scaler.transform(features.reshape(1, -1))
        predicted_price = float(self.model.predict(X_scaled)[0])
        distance = np.linalg.norm(X_scaled)
        confidence = min(1.0, max(0.5, 1.0 - (distance / 100.0)))

        return predicted_price, confidence
