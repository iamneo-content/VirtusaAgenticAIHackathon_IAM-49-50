#!/usr/bin/env python3
"""Recommendation Generator LLM Agent"""

from typing import Dict, Any, List
import json


class RecommendationGeneratorLLMAgent:
    """Generate investment recommendations using LLM"""

    def __init__(self, client):
        if client is None:
            raise ValueError("LLM client not initialized. Cannot generate recommendations without Gemini API client.")
        self.client = client

    def generate_recommendations(self, property_json: Dict[str, Any], analysis_results: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate investment recommendations using LLM
        Raises ValueError if client not initialized
        """
        address = property_json.get("address", "")
        city = property_json.get("city", "")
        risk_level = analysis_results.get("risk_level", "moderate")
        risk_factors = analysis_results.get("risk_factors", [])
        price = analysis_results.get("predicted_price", 0)

        prompt = f"""Generate investment recommendations for this property:

Property: {address}, {city}
Price: ${price:,.0f}
Risk Level: {risk_level}
Risk Factors: {', '.join(risk_factors[:3])}

Provide recommendations in JSON:
{{
    "recommendation": "BUY/CONDITIONAL BUY/HOLD/PASS with explanation",
    "priority": "High/Medium/Low/Critical",
    "actions": ["action1", "action2", "action3", "action4"],
    "mitigation": ["strategy1", "strategy2", "strategy3"],
    "next_steps": "Immediate next steps"
}}"""

        message = self.client.messages_create(
            max_tokens=500,
            messages=[{"role": "user", "content": prompt}]
        )
        response_text = message.content[0].text

        if "```" in response_text:
            parts = response_text.split("```")
            if len(parts) >= 2:
                response_text = parts[1]
                if response_text.startswith("json"):
                    response_text = response_text[4:]

        try:
            result = json.loads(response_text.strip())
        except json.JSONDecodeError:
            raise ValueError(f"Invalid JSON from LLM: {response_text}")

        # Handle case where LLM returns array instead of object
        if isinstance(result, list):
            if len(result) > 0:
                result = result[0]
            else:
                result = {}

        return {
            "recommendation": result.get("recommendation", ""),
            "investment_recommendation": result.get("recommendation", ""),
            "investment_actions": result.get("actions", []),
            "risk_mitigation": result.get("mitigation", []),
            "action_priority": result.get("priority", "Medium"),
            "escalation_level": "L3" if risk_level == "very_risky" else "L2" if risk_level == "risky" else "L1",
        }
