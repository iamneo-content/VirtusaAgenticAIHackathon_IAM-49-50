================================================================================
                     INVESTPULSE: DOCUMENTATION
================================================================================


SECTION 1: PROBLEM STATEMENT & PROJECT OVERVIEW
================================================================================

PROBLEM STATEMENT:

Real estate investors face challenges in making informed property investment decisions
due to incomplete information and market complexity. Investors need:

1. Accurate property valuation based on multiple factors
2. Comprehensive risk assessment considering market and property conditions
3. Market opportunity analysis and intelligence
4. Data-driven investment recommendations
5. Professional analysis reports for decision-making

SOLUTION:

InvestPulse is an intelligent real estate investment analysis platform that combines
machine learning models with large language model insights to provide:

- Automated property valuation using trained regression models
- Risk assessment using classification (4-class: safe, moderate, risky, very_risky)
- Market opportunity classification via LLM analysis
- Market intelligence and trend analysis via LLM
- Personalized investment recommendations based on comprehensive analysis
- Professional investment reports in text and JSON formats

PROJECT OBJECTIVE:

Build an end-to-end property analysis system that processes raw property data through
an 8-stage pipeline, combining ML predictions with LLM insights to generate actionable
investment recommendations.


SECTION 2: SYSTEM ARCHITECTURE
================================================================================

ARCHITECTURE TYPE: Hybrid ML + LLM Pipeline with LangGraph Orchestration

EXECUTION FLOW (8-Stage Pipeline):

Stage 1: Property Parser Agent
  - Input: Raw property JSON
  - Process: Validate, normalize, handle field aliases
  - Output: Parsed and cleaned property data

Stage 2: Property Analyzer Agent
  - Input: Parsed property data
  - Process: Extract and engineer 19 features for ML models
  - Output: Feature vector with numeric features

Stage 3 & 4: Parallel ML Predictions
  - Price Estimation Agent: Predicts market price using regression
  - Risk Assessment Agent: Classifies risk level using classification (4 classes)
  - Both use same 19 features but different models

Stage 5: Market Intent Classifier (LLM)
  - Input: Property data + ML predictions
  - Process: Classify market opportunity type
  - Output: Opportunity type (primary_residence, investment_property, etc.)

Stage 6: Market Intelligence Analyzer (LLM)
  - Input: Property data + all predictions
  - Process: Analyze market trends, viability, comparable properties
  - Output: Market insights, comparable properties, trends analysis

Stage 7: Recommendation Generator (LLM)
  - Input: All prior analysis results
  - Process: Generate investment recommendations and action items
  - Output: Investment recommendation, actions, mitigation strategies

Stage 8: Report Generator (LLM)
  - Input: Complete analysis state (60 fields)
  - Process: Create professional investment report
  - Output: Text report + JSON structured report + quality metrics

WORKFLOW ORCHESTRATION:

- Uses LangGraph StateGraph for directed acyclic graph (DAG) execution
- Central state object: PropertyValuationState (60+ fields)
- State fields accumulate as pipeline progresses
- Input: 4 fields (property_json, property_id, address, etc.)
- Output: 60+ fields with complete analysis


SECTION 3: DIRECTORY STRUCTURE & FILE PURPOSES
================================================================================

PROJECT ROOT: /Users/balamurale/Downloads/LangHackthon/InvestPulse

DIRECTORY TREE:

InvestPulse/

  CONFIGURATION & EXECUTION
  ========================
  main.py                    (Streamlit web application - UI entry point)
  graph.py                   (High-level workflow orchestration functions)
  state.py                   (PropertyValuationState definition and utilities)
  tests.py                   (18 comprehensive unit tests with mock LLM client)

  AGENTS DIRECTORY (agents/)
  ==========================
  __init__.py                (Exports all 8 agent classes)
  property_parser.py         (PropertyParserAgent - data validation)
  property_analyzer.py       (PropertyAnalyzerAgent - feature engineering)
  price_estimation_ml.py     (PriceEstimationMLAgent - ML price prediction)
  risk_assessment_ml.py      (RiskAssessmentMLAgent - ML risk classification)
  market_intent_classifier_llm.py    (LLM-based opportunity classification)
  market_intelligence_llm.py         (LLM-based market analysis)
  recommendation_generator_llm.py    (LLM-based recommendations)
  report_generator_llm.py            (LLM-based report generation)

  NODES DIRECTORY (nodes/)
  =======================
  __init__.py                (Exports all 8 node functions)
  property_parser_node.py    (Orchestration wrapper for parser agent)
  property_analyzer_node.py  (Orchestration wrapper for analyzer agent)
  price_estimation_node.py   (Orchestration wrapper for price agent)
  risk_assessment_node.py    (Orchestration wrapper for risk agent)
  market_intent_node.py      (Orchestration wrapper for intent agent)
  market_intelligence_node.py (Orchestration wrapper for intelligence agent)
  recommendation_node.py     (Orchestration wrapper for recommendation agent)
  report_generator_node.py   (Orchestration wrapper for report agent)

  WORKFLOW DIRECTORY (workflow/)
  ===============================
  __init__.py                (Package initialization)
  workflow.py                (LangGraph workflow definition and execution)

  ML PIPELINE DIRECTORY (ml/)
  ==========================
  __init__.py                (Package initialization)
  train_pipeline.py          (Main training orchestration - runs all steps)

  DATA CLEANING SUBDIRECTORY (ml/data_cleaning/)
  ==============================================
  __init__.py                (Package initialization)
  clean_price_valuation_data.py    (Cleans price training data)
  clean_risk_assessment_data.py    (Cleans risk training data)

  MODEL TRAINING SUBDIRECTORY (ml/train_model/)
  =============================================
  __init__.py                (Package initialization)
  train_price_estimation_model.py  (Trains price RandomForest model)
  train_risk_assessment_model.py   (Trains risk RandomForest model)

  MODEL EVALUATION SUBDIRECTORY (ml/evaluation/)
  ==============================================
  __init__.py                (Package initialization)
  evaluate_models.py         (Evaluates both models on test data)

  MODELS DIRECTORY (ml/models/)
  =============================
  price_estimation_model.pkl (Trained price regression model)
  price_estimation_scaler.pkl (StandardScaler for price features)
  risk_assessment_model.pkl  (Trained risk classification model)
  risk_assessment_scaler.pkl (StandardScaler for risk features)
  risk_level_encoder.pkl     (Label encoder for risk classes)

  UTILITIES DIRECTORY (utils/)
  ============================
  __init__.py                (Package initialization)
  gemini_client.py           (Gemini API adapter and client builder)

  CONFIGURATION DIRECTORY (.streamlit/)
  ====================================
  secrets.toml               (Streamlit secrets for API keys)
  config.toml                (Streamlit theme and app configuration)

  DATA DIRECTORY (data/)
  =====================

  INPUT SUBDIRECTORY (data/input/)
  ===============================
  training_dataset/          (Raw training CSV files)
    price_valuation_training.csv (30,000 rows of price training data)
    risk_assessment_training.csv (30,000 rows of risk training data)

  sample_properties/         (50 JSON files for UI testing)
    PROP-1.json through PROP-50.json (Property samples)

  PROCESSED SUBDIRECTORY (data/processed/)
  =======================================
  price_valuation_cleaned.csv (25,508 rows - cleaned price data)
  risk_assessment_cleaned.csv (22,905 rows - cleaned risk data)

  OUTPUT DIRECTORY (output/)
  =========================
  PROP-*.txt                 (Generated text reports)
  PROP-*.json                (Generated JSON reports)


SECTION 4: CLASS STRUCTURES & METHODS
================================================================================

FILE: state.py
==============

TYPE ALIAS: PropertyValuationState

TypedDict containing 60+ fields for complete property analysis pipeline

KEY FIELDS IN ACCUMULATION ORDER:

Initial Fields (from input):
  property_json: Dict[str, Any]
  property_id: str
  address: str
  city: str
  state: str
  zip_code: str
  country: str

After Stage 1 (Parser):
  parsed_property: Dict[str, Any]
  property_headers_normalized: Dict[str, Any]
  parsing_complete: bool
  parsing_errors: List[str]

After Stage 2 (Analyzer):
  property_analysis: Dict[str, Any]
  extracted_features: Dict[str, float]
  analysis_complete: bool

After Stage 3 (Price Model):
  predicted_price: float
  price_confidence: float
  price_model_metrics: Dict[str, float]
  price_estimation_complete: bool

After Stage 4 (Risk Model):
  risk_level: str
  risk_score: float
  risk_confidence: float
  risk_factors: List[str]
  risk_assessment_complete: bool

After Stage 5 (Intent LLM):
  opportunity_type: str
  market_intent: str
  intent_confidence: float
  intent_analysis: Dict[str, Any]
  intent_classification_complete: bool

After Stage 6 (Intelligence LLM):
  market_insights: Dict[str, Any]
  comparable_properties: List[Dict[str, Any]]
  market_trends: Dict[str, Any]
  investment_viability: str
  intelligence_analysis_complete: bool

After Stage 7 (Recommendation LLM):
  recommended_action: str
  investment_recommendation: str
  investment_actions: List[str]
  risk_mitigation: List[str]
  action_priority: str
  recommendation_generation_complete: bool

After Stage 8 (Report LLM):
  investment_report: str
  report_json: Dict[str, Any]
  quality_metrics: Dict[str, float]
  saved_path: str
  output_dir: str
  report_generation_complete: bool

Error Fields:
  error_occurred: bool
  error_messages: List[str]


FUNCTION: get_initial_state(property_json: Dict[str, Any]) -> PropertyValuationState

Purpose: Initialize PropertyValuationState with default values from raw property JSON
Parameters:
  property_json: Raw property data dictionary
Returns: Fully initialized PropertyValuationState with all fields populated

FUNCTION: validate_state(state: PropertyValuationState) -> bool

Purpose: Validate that all required fields exist in state
Parameters:
  state: PropertyValuationState to validate
Returns: True if all required fields present, False otherwise

FUNCTION: slugify(text: str) -> str

Purpose: Convert text to URL-safe slug format
Parameters:
  text: Text to convert (e.g., "My Property Address")
Returns: Slug format string (e.g., "my-property-address")


FILE: agents/property_parser.py
===============================

CLASS: PropertyParserAgent

PURPOSE: Validate, normalize, and parse raw property JSON data

METHOD: __init__(self) -> None

Purpose: Initialize agent with validation rules
Parameters: None (no parameters)
Returns: None (initializes self)

METHOD: parse_and_validate(self, property_json: Dict[str, Any]) -> Dict[str, Any]

Purpose: Parse and validate property JSON, normalize field names, calculate derived fields
Parameters:
  property_json: Raw property data dictionary
Returns: Dictionary with normalized property data

Processing Steps:
  1. Validate required fields present: property_id, address, city, square_footage,
     bedrooms, bathrooms, condition_score
  2. Calculate property_age from year_built if missing
  3. Handle field aliases:
     - square_footage OR square_feet
     - market_trend OR market_trend_pct
     - employment_rate OR employment_rate_pct
     - lot_size OR lot_size_sqft
  4. Ensure all numeric fields have proper values
  5. Return normalized property dict


FILE: agents/property_analyzer.py
==================================

CLASS: PropertyAnalyzerAgent

PURPOSE: Extract and engineer numeric features for ML model input

METHOD: __init__(self) -> None

Purpose: Initialize agent
Parameters: None
Returns: None

METHOD: extract_numeric_features(self, parsed_property: Dict) -> Dict[str, float]

Purpose: Extract 19 numeric features for ML model input
Parameters:
  parsed_property: Normalized property data from parser
Returns: Dict[str, float] with all 19 engineered features

Features Extracted (19 total):

Core Features (14):
  1. square_feet: float (property size in square feet)
  2. bedrooms: float (number of bedrooms)
  3. bathrooms: float (number of bathrooms)
  4. property_age: float (current year - year_built)
  5. condition_score: float (1-10 property condition rating)
  6. garage_spaces: float (number of parking spaces)
  7. has_pool: float (0 or 1 boolean indicator)
  8. lot_size: float (lot size in square feet)
  9. neighborhood_score: float (1-100 neighborhood quality score)
  10. school_rating: float (1-10 school quality rating)
  11. days_on_market: float (days property has been listed)
  12. price_per_sqft: float (estimated price divided by square feet)
  13. market_trend_pct: float (market appreciation percentage)
  14. employment_rate_pct: float (local employment rate percentage)

Property Type (encoded as numeric):
  15. property_type: float (1=residential, 2=condo, 3=townhouse, 4=commercial, 5=multi_family)

Engineered Features (4):
  16. bed_bath_ratio: float (bedrooms / bathrooms)
  17. sqft_per_bedroom: float (square_feet / bedrooms)
  18. market_age_index: float (market_trend * property_age)
  19. price_gap_pct: float (market variance percentage)


FILE: agents/price_estimation_ml.py
===================================

CLASS: PriceEstimationMLAgent

PURPOSE: Predict property market price using trained RandomForest regression model

CLASS ATTRIBUTE: FEATURE_NAMES = List[str]

List of 19 feature names in order expected by model

METHOD: __init__(self, model_dir: str = "ml/models") -> None

Purpose: Initialize agent and load pre-trained model
Parameters:
  model_dir: Directory containing saved model files (default: "ml/models")
Returns: None (initializes self, loads model and scaler)
Raises: FileNotFoundError if model or scaler files not found

METHOD: _load_model(self) -> None

Purpose: Load pickle files containing trained model and scaler
Parameters: None
Returns: None (populates self.model and self.scaler)
Raises: FileNotFoundError if pickle files not found

Files Loaded:
  - price_estimation_model.pkl (RandomForestRegressor with 100 estimators)
  - price_estimation_scaler.pkl (StandardScaler for feature normalization)

METHOD: predict_price(self, extracted_features: Dict[str, float]) -> Tuple[float, float]

Purpose: Predict property market price from extracted features
Parameters:
  extracted_features: Dict[str, float] with all 19 features
Returns: Tuple of (predicted_price: float, confidence_score: float)
Raises: ValueError if model not initialized

Algorithm:
  1. Convert feature dict to numpy array in feature order
  2. Normalize features using loaded StandardScaler
  3. Pass normalized features to RandomForest model
  4. Get prediction and prediction variance
  5. Calculate confidence as: min(1.0, max(0.5, 1.0 - (distance / 100.0)))
  6. Return (predicted_price, confidence)


FILE: agents/risk_assessment_ml.py
==================================

CLASS: RiskAssessmentMLAgent

PURPOSE: Classify property investment risk level using trained RandomForest classifier

CLASS ATTRIBUTE: FEATURE_NAMES = List[str]

List of 19 feature names (same as price model)

METHOD: __init__(self, model_dir: str = "ml/models") -> None

Purpose: Initialize agent and load pre-trained model and encoders
Parameters:
  model_dir: Directory containing saved model files (default: "ml/models")
Returns: None (initializes self, loads model, scaler, encoder)
Raises: FileNotFoundError if any model file not found

METHOD: _load_model(self) -> None

Purpose: Load pickle files containing trained model, scaler, and label encoder
Parameters: None
Returns: None (populates self.model, self.scaler, self.label_encoder)
Raises: FileNotFoundError if pickle files not found

Files Loaded:
  - risk_assessment_model.pkl (RandomForestClassifier, 4 classes)
  - risk_assessment_scaler.pkl (StandardScaler for feature normalization)
  - risk_level_encoder.pkl (LabelEncoder for class labels)

METHOD: predict_risk(self, extracted_features: Dict[str, float]) -> Tuple[str, float, float, List[str]]

Purpose: Classify investment risk level from extracted features
Parameters:
  extracted_features: Dict[str, float] with all 19 features
Returns: Tuple of (risk_level: str, risk_score: float, confidence: float, risk_factors: List[str])
Raises: ValueError if model not initialized

Risk Levels (4 classes):
  - safe: Low risk investment
  - moderate: Acceptable risk with conditions
  - risky: High risk requiring careful consideration
  - very_risky: Very high risk, proceed with caution

Risk Score Calculation (0-10 scale):
  score = (probability[very_risky] * 10.0 +
           probability[risky] * 6.0 +
           probability[moderate] * 3.0 +
           probability[safe] * 0.0)

Risk Factors Identified:
  - Property age > 50 years: "Old property requiring maintenance"
  - Condition score < 5: "Poor property condition"
  - Neighborhood score < 40: "Low neighborhood desirability"
  - Days on market > 100: "Property on market too long"

Algorithm:
  1. Normalize features using StandardScaler
  2. Get prediction class and probabilities from RandomForest
  3. Decode class label using LabelEncoder
  4. Calculate risk_score from probabilities
  5. Calculate confidence as max probability
  6. Identify applicable risk_factors
  7. Return (risk_level, risk_score, confidence, risk_factors)


FILE: agents/market_intent_classifier_llm.py
============================================

CLASS: MarketIntentClassifierLLMAgent

PURPOSE: Classify market investment opportunity type using Gemini LLM

METHOD: __init__(self, client) -> None

Purpose: Initialize agent with Gemini LLM client
Parameters:
  client: GeminiAdapter instance for API calls
Returns: None (initializes self)
Raises: ValueError if client is None

METHOD: classify_intent(self, property_json: Dict[str, Any], analysis_results: Dict[str, Any]) -> Dict[str, Any]

Purpose: Classify property as investment opportunity type
Parameters:
  property_json: Original property data
  analysis_results: Results from prior analysis stages
Returns: Dict with keys:
  - opportunity_type: str (classification category)
  - market_intent: str (investment intent description)
  - intent_confidence: float (0-1 confidence score)
  - classification_rationale: str (explanation)

Opportunity Types:
  - primary_residence: Owner-occupied single family home
  - investment_property: Income-generating rental property
  - rental_income: Multi-unit rental investment
  - fix_and_flip: Value-add renovation opportunity
  - commercial_opportunity: Commercial property investment
  - land_development: Land for future development
  - portfolio_diversification: Portfolio expansion property

LLM Prompt Analysis:
  - Property address and location
  - Property type and size
  - Estimated price and market position
  - Risk level from ML prediction
  - Current market conditions

JSON Response Parsing:
  - Extracts JSON from markdown code blocks if present
  - Handles both array and object responses
  - Fallback to defaults if parsing fails


FILE: agents/market_intelligence_llm.py
=======================================

CLASS: MarketIntelligenceLLMAgent

PURPOSE: Analyze market trends and investment viability using Gemini LLM

METHOD: __init__(self, client) -> None

Purpose: Initialize agent with Gemini LLM client
Parameters:
  client: GeminiAdapter instance for API calls
Returns: None (initializes self)
Raises: ValueError if client is None

METHOD: analyze_threat(self, property_json: Dict[str, Any], analysis_results: Dict[str, Any]) -> Dict[str, Any]

Purpose: Analyze market conditions and provide investment intelligence
Parameters:
  property_json: Original property data
  analysis_results: Results from prior analysis stages
Returns: Dict with keys:
  - market_insights: Dict[str, Any]
    Contains: location_appeal, market_momentum, economic_health, trends, employment
  - comparable_properties: List[Dict[str, Any]]
    List of 2 comparable property records with price, features
  - market_trends: Dict[str, Any]
    Contains: direction, strength, appreciation_rate, forecast, risk_alignment
  - investment_viability: str
    Assessment statement on property investment viability

LLM Analysis Factors:
  - Geographic location and neighborhood quality
  - Market momentum (growing/declining/stable)
  - Economic indicators and employment
  - Historical price trends and future forecast
  - Comparable property benchmarks
  - Risk alignment with market conditions


FILE: agents/recommendation_generator_llm.py
==========================================

CLASS: RecommendationGeneratorLLMAgent

PURPOSE: Generate investment recommendations using Gemini LLM

METHOD: __init__(self, client) -> None

Purpose: Initialize agent with Gemini LLM client
Parameters:
  client: GeminiAdapter instance for API calls
Returns: None (initializes self)
Raises: ValueError if client is None

METHOD: generate_recommendations(self, property_json: Dict[str, Any], analysis_results: Dict[str, Any]) -> Dict[str, Any]

Purpose: Generate investment recommendation and action plan
Parameters:
  property_json: Original property data
  analysis_results: Results from all prior analysis stages
Returns: Dict with keys:
  - recommendation: str (BUY, CONDITIONAL BUY, HOLD, or PASS)
  - investment_recommendation: str (detailed recommendation text)
  - investment_actions: List[str] (4 specific action items)
  - risk_mitigation: List[str] (3 risk mitigation strategies)
  - action_priority: str (High, Medium, Low, or Critical)
  - escalation_level: str (L1, L2, or L3 based on risk)

Recommendation Types:
  BUY: Strong buy recommendation, proceed with confidence
  CONDITIONAL BUY: Buy with specific conditions or modifications
  HOLD: Wait for better conditions or more information
  PASS: Do not invest, risk exceeds potential returns

Priority Levels:
  Critical: Immediate action required, urgent opportunity/risk
  High: Act soon, significant implications
  Medium: Consider soon, moderate priority
  Low: Can wait, low urgency

LLM Factors Considered:
  - Property address and specifications
  - Estimated price and market comparables
  - ML-predicted risk level and score
  - Identified risk factors
  - Market opportunity classification
  - Market viability assessment


FILE: agents/report_generator_llm.py
===================================

CLASS: ReportGeneratorLLMAgent

PURPOSE: Generate professional investment report using Gemini LLM

CLASS ATTRIBUTE: output_dir: str = "output"

Default output directory for generated reports

METHOD: __init__(self, client) -> None

Purpose: Initialize agent with Gemini LLM client and create output directory
Parameters:
  client: GeminiAdapter instance for API calls
Returns: None (initializes self, creates output directory)
Raises: ValueError if client is None

METHOD: generate_report(self, property_json: Dict[str, Any], state: Dict[str, Any]) -> Dict[str, Any]

Purpose: Generate comprehensive investment report in text and JSON formats
Parameters:
  property_json: Original property data
  state: Complete PropertyValuationState after all analysis
Returns: Dict with keys:
  - investment_report: str (formatted text report 1000+ words)
  - report_json: Dict[str, Any] (structured JSON report)
  - quality_metrics: Dict[str, float] (report quality scores 0-1)
  - saved_path: str (path to saved .txt file)

Report Sections:
  - Executive Summary (2 paragraphs)
  - Property Overview (specifications, amenities, condition)
  - Market Analysis (location, trends, comparables)
  - Investment Metrics (price estimate, risk assessment)
  - Opportunity Assessment (type, viability, intent)
  - Risk Analysis (identified risks, mitigation strategies)
  - Recommendations (action items, timeline, considerations)
  - Conclusion and Next Steps

Quality Metrics (0-1 scale):
  - parsing_quality: Data input quality and completeness
  - analysis_completeness: All analysis stages completed
  - price_confidence: ML model confidence in price prediction
  - risk_assessment_confidence: ML model confidence in risk assessment
  - recommendation_clarity: Clarity of recommendations
  - overall_report_quality: Average of all metrics

Output Files:
  - {property_id}_{timestamp}.txt (plain text format)
  - {property_id}_{timestamp}.json (structured JSON format)
  Both saved in output/ directory


FILE: graph.py
==============

FUNCTION: analyze_property(property_json: Dict[str, Any], llm_client=None) -> Dict[str, Any]

Purpose: Execute complete property analysis workflow end-to-end
Parameters:
  property_json: Raw property data dictionary
  llm_client: Optional GeminiAdapter for LLM-based agents (default: None)
Returns: Final PropertyValuationState Dict with complete analysis (60+ fields)

Execution Steps:
  1. Invokes workflow.build_workflow(llm_client)
  2. Initializes PropertyValuationState from property_json
  3. Executes 8-node LangGraph DAG:
     - Parser → Analyzer → [Price, Risk parallel] → Intent → Intelligence
     → Recommendation → Report
  4. Returns final state with all 60+ fields populated
  5. Handles errors gracefully, returns state with error_occurred=True

Return Value Structure:
  - If success: Complete state with all analysis results
  - If error: State with error_occurred=True and error_messages List

FUNCTION: get_threat_summary(state: Dict[str, Any]) -> Dict[str, Any]

Purpose: Extract summary of investment findings from complete state
Parameters:
  state: Complete PropertyValuationState after analysis
Returns: Dict with summary keys:
  - property_id: str
  - address: str
  - predicted_price: float
  - price_confidence: float
  - risk_level: str
  - risk_score: float
  - opportunity_type: str
  - investment_recommendation: str (abbreviated)
  - key_risks: List[str] (top 3 risk factors)
  - recommended_actions: List[str] (top 2 actions)
  - priority_level: str


FILE: utils/gemini_client.py
============================

CLASS: GeminiAdapter

PURPOSE: Adapter class for Gemini API matching expected LLM interface

METHOD: __init__(self, api_key: str, model_name: str = "gemini-2.0-flash") -> None

Purpose: Initialize Gemini API client
Parameters:
  api_key: Gemini API authentication key
  model_name: Model to use (default: "gemini-2.0-flash")
Returns: None (initializes self)
Raises: ImportError if google-generativeai library not installed

METHOD: messages_create(self, max_tokens: int = 500, messages=None)

Purpose: Send prompt to Gemini and get response (matches LLM interface)
Parameters:
  max_tokens: Maximum tokens in response (default: 500)
  messages: List of message dicts with "content" key
Returns: Custom response object with .content[0].text attribute

Processing:
  1. Extracts content from first message in messages list
  2. Calls genai.GenerativeModel.generate_content()
  3. Extracts text from response
  4. Wraps in custom response object matching interface
  5. Returns response with .content[0].text format


FUNCTION: _get_first_api_key() -> Optional[str]

Purpose: Find first available Gemini API key from multiple sources
Parameters: None
Returns: API key string if found, None otherwise

Search Order:
  1. Streamlit secrets (st.secrets.get("GEMINI_API_KEY_1") through _4)
  2. Environment variables (os.getenv("GEMINI_API_KEY_1") through _4)

Returns first key found in order, supports 1-4 keys


FUNCTION: build_gemini_client() -> Optional[GeminiAdapter]

Purpose: Build and return configured Gemini client instance
Parameters: None
Returns: GeminiAdapter instance if configured, None if not available

Logic:
  1. Calls _get_first_api_key() to find API key
  2. Checks if google-generativeai is installed
  3. Attempts to create GeminiAdapter with key
  4. Logs warnings/info about initialization
  5. Returns client or None

Logging:
  - Warning if no API key found
  - Warning if google-generativeai not installed
  - Info on successful initialization
  - Error if initialization fails


FILE: workflow/workflow.py
==========================

FUNCTION: build_workflow(llm_client=None) -> StateGraph

Purpose: Build LangGraph StateGraph with 8 nodes in execution order
Parameters:
  llm_client: Optional GeminiAdapter for LLM-based agents
Returns: Compiled LangGraph StateGraph for workflow execution

Graph Structure:
  Entry Point: property_parser

  Node Sequence:
  1. property_parser → property_analyzer
  2. property_analyzer → price_estimation (parallel)
  3. property_analyzer → risk_assessment (parallel)
  4. price_estimation → market_intent_classifier (waits for both)
  5. risk_assessment → market_intent_classifier (waits for both)
  6. market_intent_classifier → market_intelligence
  7. market_intelligence → recommendation
  8. recommendation → report_generator

  Exit Point: report_generator

State Type: PropertyValuationState (60+ fields)

Parallel Execution: Price and Risk models run simultaneously after analyzer


FUNCTION: run_property_analysis_workflow(property_json: Dict[str, Any], llm_client=None) -> Dict[str, Any]

Purpose: Execute complete analysis workflow for single property
Parameters:
  property_json: Raw property data
  llm_client: Optional Gemini client for LLM agents
Returns: Final PropertyValuationState Dict (60+ fields)

Execution Flow:
  1. Initialize PropertyValuationState from property_json
  2. Build LangGraph workflow
  3. Execute graph.invoke(initial_state)
  4. Return final state

Error Handling:
  - Catches all exceptions
  - Sets error_occurred = True
  - Appends error message to error_messages List
  - Returns state (not raises exception)
  - Logs error for debugging


FILE: ml/train_pipeline.py
==========================

FUNCTION: run_training_pipeline(data_dir="data", processed_dir="data/processed", model_dir="ml/models") -> dict

Purpose: Execute complete ML training pipeline end-to-end
Parameters:
  data_dir: Root data directory (default: "data")
  processed_dir: Output directory for cleaned data (default: "data/processed")
  model_dir: Output directory for trained models (default: "ml/models")
Returns: Dict with stats from each pipeline stage

Pipeline Stages:
  1. Load raw price and risk CSV files from data/training_dataset/
  2. Clean price data, save to processed_dir
  3. Clean risk data, save to processed_dir
  4. Load cleaned data from processed_dir
  5. Train price estimation model
  6. Train risk assessment model
  7. Evaluate both models
  8. Return complete stats dict

Return Value Structure:
  stats = {
    "price_cleaning": {...},
    "risk_cleaning": {...},
    "price_training": {...},
    "risk_training": {...},
    "evaluation": {...}
  }

Each value contains detailed metrics from that stage


FILE: ml/data_cleaning/clean_price_valuation_data.py
====================================================

FUNCTION: clean_price_valuation_data(df, save_processed=False, output_dir="data/processed") -> Tuple[DataFrame, dict]

Purpose: Clean price training data (remove duplicates, nulls, outliers)
Parameters:
  df: Input pandas DataFrame with raw price training data
  save_processed: Whether to save cleaned data to CSV (default: False)
  output_dir: Directory to save cleaned CSV (default: "data/processed")
Returns: Tuple of (cleaned_dataframe, statistics_dict)

Cleaning Operations:
  1. Remove duplicate rows
  2. Fill missing numeric values with median
  3. Fill missing categorical values with mode
  4. Encode property_type to numeric (1-5):
     1=residential, 2=condo, 3=townhouse, 4=commercial, 5=multi_family
  5. Remove outliers using IQR method (3x interquartile range)
  6. Validate required columns present
  7. Save to CSV if save_processed=True

Return Statistics:
  {
    "original_rows": int,
    "cleaned_rows": int,
    "duplicates_removed": int,
    "rows_removed_pct": float,
    "output_path": str
  }


FILE: ml/data_cleaning/clean_risk_assessment_data.py
===================================================

FUNCTION: clean_risk_assessment_data(df, save_processed=False, output_dir="data/processed") -> Tuple[DataFrame, dict]

Purpose: Clean risk assessment training data with validation
Parameters:
  df: Input pandas DataFrame with raw risk training data
  save_processed: Whether to save cleaned data to CSV (default: False)
  output_dir: Directory to save cleaned CSV (default: "data/processed")
Returns: Tuple of (cleaned_dataframe, statistics_dict)

Cleaning Operations:
  1. Remove duplicate rows
  2. Fill missing numeric values with median
  3. Fill missing categorical values with mode
  4. Encode property_type to numeric (1-5)
  5. Validate risk_level in [safe, moderate, risky, very_risky]
  6. Remove rows with invalid risk levels
  7. Remove outliers using IQR method
  8. Validate required columns present
  9. Save to CSV if save_processed=True

Return Statistics:
  {
    "original_rows": int,
    "cleaned_rows": int,
    "duplicates_removed": int,
    "rows_removed_pct": float,
    "output_path": str
  }


FILE: ml/train_model/train_price_estimation_model.py
===================================================

FUNCTION: train_price_estimation_model(df, model_save_dir="ml/models", test_size=0.2, random_state=42) -> dict

Purpose: Train regression model for price prediction
Parameters:
  df: Cleaned pandas DataFrame with price training data
  model_save_dir: Directory to save model and scaler (default: "ml/models")
  test_size: Proportion of data for testing (default: 0.2 = 80/20 split)
  random_state: Seed for reproducibility (default: 42)
Returns: Dict with training metrics and feature importance

Model Configuration:
  RandomForestRegressor:
    - n_estimators: 100 decision trees
    - max_depth: 10 levels per tree
    - random_state: 42 (reproducible)
    - n_jobs: -1 (parallel processing)

Training Process:
  1. Extract features (19 features) and target (price) from DataFrame
  2. Split data: 80% train, 20% test
  3. Normalize features using StandardScaler
  4. Train RandomForest model
  5. Evaluate on train and test sets
  6. Save model and scaler to pickle files
  7. Calculate feature importance scores

Return Metrics:
  {
    "train_r2": float (coefficient of determination on train data),
    "test_r2": float (coefficient of determination on test data),
    "test_mae": float (mean absolute error),
    "test_rmse": float (root mean squared error),
    "test_mape": float (mean absolute percentage error),
    "overfitting_gap": float (train_r2 - test_r2),
    "feature_importance": Dict[str, float] (importance per feature)
  }

Files Saved:
  - price_estimation_model.pkl
  - price_estimation_scaler.pkl


FILE: ml/train_model/train_risk_assessment_model.py
=================================================

FUNCTION: train_risk_assessment_model(df, model_save_dir="ml/models", test_size=0.2, random_state=42) -> dict

Purpose: Train classification model for risk assessment
Parameters:
  df: Cleaned pandas DataFrame with risk training data
  model_save_dir: Directory to save model and scaler (default: "ml/models")
  test_size: Proportion of data for testing (default: 0.2 = 80/20 split)
  random_state: Seed for reproducibility (default: 42)
Returns: Dict with training metrics and feature importance

Model Configuration:
  RandomForestClassifier:
    - n_estimators: 100 decision trees
    - max_depth: 10 levels per tree
    - class_weight: "balanced" (handles imbalanced classes)
    - random_state: 42 (reproducible)
    - n_jobs: -1 (parallel processing)

Risk Classes (4 classes):
  1. safe
  2. moderate
  3. risky
  4. very_risky

Training Process:
  1. Extract features (19 features) and target (risk_level) from DataFrame
  2. Split data: 80% train, 20% test
  3. Normalize features using StandardScaler
  4. Encode risk_level labels using LabelEncoder
  5. Train RandomForest model
  6. Evaluate on train and test sets
  7. Save model, scaler, and label encoder to pickle files
  8. Calculate feature importance scores

Return Metrics:
  {
    "train_accuracy": float,
    "test_accuracy": float,
    "test_precision": float (weighted average),
    "test_recall": float (weighted average),
    "test_f1": float (F1 score),
    "overfitting_gap": float (train_accuracy - test_accuracy),
    "feature_importance": Dict[str, float]
  }

Files Saved:
  - risk_assessment_model.pkl
  - risk_assessment_scaler.pkl
  - risk_level_encoder.pkl


FILE: ml/evaluation/evaluate_models.py
======================================

FUNCTION: evaluate_price_model(model_dir="ml/models", eval_data_dir="data/evaluation_dataset") -> dict

Purpose: Evaluate price model on separate evaluation dataset
Parameters:
  model_dir: Directory containing saved price model (default: "ml/models")
  eval_data_dir: Directory containing evaluation CSV (default: "data/evaluation_dataset")
Returns: Dict with evaluation metrics, empty dict if data not available

Evaluation Metrics:
  {
    "mae": float (mean absolute error),
    "rmse": float (root mean squared error),
    "r2": float (R-squared score),
    "mape": float (mean absolute percentage error),
    "samples": int (number of samples evaluated)
  }


FUNCTION: evaluate_risk_model(model_dir="ml/models", eval_data_dir="data/evaluation_dataset") -> dict

Purpose: Evaluate risk model on separate evaluation dataset
Parameters:
  model_dir: Directory containing saved risk model (default: "ml/models")
  eval_data_dir: Directory containing evaluation CSV (default: "data/evaluation_dataset")
Returns: Dict with evaluation metrics, empty dict if data not available

Evaluation Metrics:
  {
    "accuracy": float,
    "precision": float,
    "recall": float,
    "f1": float,
    "samples": int
  }


FUNCTION: evaluate_all_models(model_dir="ml/models", eval_data_dir="data/evaluation_dataset") -> dict

Purpose: Evaluate both models and return combined results
Parameters:
  model_dir: Directory containing saved models (default: "ml/models")
  eval_data_dir: Directory containing evaluation data (default: "data/evaluation_dataset")
Returns: Dict with combined evaluation results

Return Structure:
  {
    "timestamp": str (ISO format),
    "price_evaluation": {...},
    "risk_evaluation": {...}
  }


SECTION 5: NODE FUNCTIONS (LangGraph Wrappers)
================================================================================

All node functions follow same pattern:

SIGNATURE: node_name(state: PropertyValuationState, client=None) -> dict

PURPOSE: Wrap agent logic for LangGraph execution

RETURN VALUE: Dict containing only keys modified by this node (not full state)

NODE FUNCTIONS (8 total):

1. property_parser_node(state, client) -> dict
   Returns: {parsed_property, property_headers_normalized, parsing_complete}

2. property_analyzer_node(state, client) -> dict
   Returns: {extracted_features, analysis_complete}

3. price_estimation_node(state, client) -> dict
   Returns: {predicted_price, price_confidence, price_estimation_complete}

4. risk_assessment_node(state, client) -> dict
   Returns: {risk_level, risk_score, risk_confidence, risk_factors, risk_assessment_complete}

5. market_intent_node(state, client) -> dict
   Returns: {opportunity_type, market_intent, intent_confidence, intent_analysis, intent_classification_complete}

6. market_intelligence_node(state, client) -> dict
   Returns: {market_insights, comparable_properties, market_trends, investment_viability, intelligence_analysis_complete}

7. recommendation_node(state, client) -> dict
   Returns: {investment_recommendation, investment_actions, risk_mitigation, action_priority, recommendation_generation_complete}

8. report_generator_node(state, client) -> dict
   Returns: {investment_report, report_json, quality_metrics, saved_path, output_dir, report_generation_complete}

All nodes:
  - Handle errors gracefully (try-catch)
  - Append errors to state.error_messages if failure
  - Return partial dict for state merging
  - Set completion flags


SECTION 6: DATA FLOW & FEATURE ENGINEERING
================================================================================

INPUT DATA STRUCTURE (Raw Property JSON):

{
  "property_id": "PROP-001",
  "address": "123 Main St",
  "city": "Seattle",
  "state": "WA",
  "zip_code": "98101",
  "country": "USA",
  "property_type": "residential",
  "year_built": 2005,
  "square_footage": 2500,
  "bedrooms": 4,
  "bathrooms": 2.5,
  "condition_score": 8,
  "garage_spaces": 2,
  "has_pool": false,
  "lot_size": 8000,
  "neighborhood_score": 85,
  "school_rating": 9,
  "days_on_market": 30,
  "price_per_sqft": 400,
  "market_trend_pct": 2.5,
  "employment_rate_pct": 95
}

FEATURE EXTRACTION (19 Features):

Core Features (14):
  square_feet: 2500
  bedrooms: 4
  bathrooms: 2.5
  property_age: 20 (2025 - 2005)
  condition_score: 8
  garage_spaces: 2
  has_pool: 0 (false)
  lot_size: 8000
  neighborhood_score: 85
  school_rating: 9
  days_on_market: 30
  price_per_sqft: 400
  market_trend_pct: 2.5
  employment_rate_pct: 95

Property Type (encoded):
  property_type: 1 (residential=1, condo=2, townhouse=3, commercial=4, multi_family=5)

Engineered Features (4):
  bed_bath_ratio: 4 / 2.5 = 1.6
  sqft_per_bedroom: 2500 / 4 = 625
  market_age_index: 2.5 * 20 = 50
  price_gap_pct: (400 - average_price) / average_price * 100

ML INPUT VECTOR:

[2500, 4, 2.5, 20, 8, 2, 0, 8000, 85, 9, 30, 400, 2.5, 95, 1, 1.6, 625, 50, price_gap_pct]

This vector passes through:
  1. StandardScaler normalization
  2. Price model (RandomForest regression) → predicted_price, confidence
  3. Risk model (RandomForest classification) → risk_level, risk_score, confidence

OUTPUT FROM ML MODELS:

Price Model Output:
  predicted_price: 1,000,000
  confidence_score: 0.95
  interpretation: 95 percent confident price is around 1,000,000

Risk Model Output:
  risk_level: "moderate"
  risk_score: 4.5 (out of 10)
  confidence_score: 0.87
  risk_factors: ["Moderate market risk", "Fair condition score"]
  interpretation: 87 percent confident risk is moderate, score 4.5/10


SECTION 7: STREAMLIT UI DESIGN
================================================================================

APPLICATION: Streamlit-based web interface at main.py

PAGE CONFIGURATION:

Title: InvestPulse
Icon: Chart ( emoji)
Layout: Wide (full-width content)
Theme: Professional blue (#1f77b4)

STYLING:

Color Scheme:
  Primary: #1f77b4 (professional blue)
  Background: #ffffff (white)
  Secondary: #f0f2f6 (light gray)
  Text: #262730 (dark gray)

Typography:
  Headers: Bold, blue color, 1.3em font size
  Body: Regular gray text
  Metrics: Large numbers with context labels

CSS Custom Styling:
  .header-title: 2.5em font, bold, blue
  .header-subtitle: 1.1em font, gray
  .metric-card: Padding, blue left border, light background
  .section-header: 1.3em font, blue, underlined divider

LAYOUT COMPONENTS:

Header Section:
  - Centered "InvestPulse" title (2.5em, blue)
  - Subtitle: "Real Estate Investment Analysis & Risk Assessment Platform"
  - Horizontal divider line

Sidebar Panel:
  - Configuration section
  - Property selector dropdown (loads 50 sample properties)
  - Tools section with "Run Model Evaluation" button

Main Content Area:
  - Property preview (expandable section)
  - Analysis button (prominent blue "Analyze Property" button)
  - Tabbed results interface

TABS (6 Tabs):

TAB 1: OVERVIEW
  Financial Metrics Section:
    Grid Layout (2 columns, 2 rows):
      Row 1: [Estimated Price] [Risk Level]
      Row 2: [Investment Viability] [Intent Confidence]

    Each metric displays:
      - Large number value
      - Label
      - Supporting value (e.g., confidence percentage)

  Market Intent Analysis Section:
    - Dedicated section below metrics
    - Full text visibility (no truncation)
    - Information box styling

  Key Findings Section:
    3-column layout:
      Column 1: Risk Factors (count + top 3)
      Column 2: Recommended Actions (count + top 2)
      Column 3: Opportunity Type

TAB 2: RISK ANALYSIS
  Risk Assessment Header

  Main Content:
    - Risk factors count metric
    - List of all identified risk factors as warnings
    - Color-coded severity indicators

TAB 3: MARKET INTELLIGENCE
  Market Analysis Header

  Market Insights Section:
    2-column layout:
      Column 1: Market insights bullets (location, momentum, etc.)
      Column 2: Market trends bullets (direction, strength, etc.)

  Comparable Properties Section:
    - Data table of 2 comparable properties
    - Columns: address, price, features, similarity score
    - Uses pandas DataFrame display

TAB 4: RECOMMENDATIONS
  Investment Strategy Header

  Main Recommendation:
    - Info box with full recommendation text
    - Decision statement (BUY/CONDITIONAL BUY/HOLD/PASS)

  Action Items Section:
    2-column layout:
      Column 1: Recommended Actions
        - Numbered list (1-4 items)
        - Specific action items with details

      Column 2: Risk Mitigation Strategies
        - Numbered list (1-3 items)
        - Specific mitigation approaches

  Metrics Section (bottom):
    2-column layout:
      Column 1: Priority Level (High/Medium/Low/Critical)
      Column 2: Opportunity Type (classification)

TAB 5: QUALITY METRICS
  Quality Metrics Header

  Individual Metrics Display:
    3-column grid layout
    Each metric shows:
      - Name (title case)
      - Value (percentage 0-100%)
      - Visual indicator

  Overall Assessment Section:
    - Overall rating text (Excellent/Good/Fair/Poor)
    - Overall percentage (0-100%)
    - Color-coded box (green/blue/yellow/red based on rating)

TAB 6: REPORT
  Investment Report Header

  Download Section:
    2 download buttons side-by-side:
      Button 1: "Download Report (TXT)" → Downloads as .txt file
      Button 2: "Download Report (JSON)" → Downloads as .json file

  Report Preview Section:
    - Full report text displayed in read-only text area
    - 400px minimum height
    - Scrollable if content exceeds height

MODEL EVALUATION SECTION (Sidebar Button):
  When "Run Model Evaluation" clicked:
    - "Evaluating models..." info message
    - Results displayed in two columns:

      Column 1: Price Estimation Model
        Metrics displayed:
          - R² Score: 0.8956
          - MAE: $53,869
          - RMSE: $70,517
          - MAPE: 11.05%

      Column 2: Risk Assessment Model
        Metrics displayed:
          - Accuracy: 0.8282
          - Precision: 0.8280
          - Recall: 0.8282
          - F1 Score: 0.8279

PROPERTY PREVIEW SECTION:
  Expandable details for selected property

  3-column layout:
    Column 1: Address, City
    Column 2: Property Type, Year Built
    Column 3: Square Footage, Bedrooms/Bathrooms

  Display format: Property-specific fields from JSON

USER INTERACTION FLOW:

1. User selects property from dropdown in sidebar
2. Property preview loads automatically
3. User clicks "Analyze Property" button
4. Loading spinner appears: "Analyzing property..."
5. On completion:
   - Success message: "Analysis complete!"
   - 6 tabs appear with results
   - User can navigate between tabs
   - User can download reports
6. API key error handling:
   - If no API key: Warning message shown
   - ML-only mode still works (price/risk)
   - Explains how to configure API key
   - Links to troubleshooting guide

ERROR HANDLING UI:

Missing API Key:
  st.error("LLM Client Not Configured")
  st.info("""
To enable LLM-powered analysis, configure your Gemini API key:

Method 1: Streamlit Secrets (Recommended)
  - Create .streamlit/secrets.toml with your API key

Method 2: .env File
  - Create or update .env file
  - Run: streamlit run main.py

Method 3: Environment Variable
  - Run: export GEMINI_API_KEY_1="your-key" && streamlit run main.py
""")

Analysis Failure:
  st.error("Analysis failed: {error_message}")
  - User can try different property
  - Suggests checking API configuration
  - Shows error details for debugging

No Properties Available:
  st.warning("No sample properties found")
  - Suggests adding sample properties to data/input/sample_properties/
  - Example property structure shown


SECTION 8: RUNNING COMMANDS & EXECUTION FLOW
================================================================================

PREREQUISITE SETUP:

Step 1: Environment Setup
  Command: pip install -r requirements.txt

  Key dependencies:
    - langgraph (workflow orchestration)
    - streamlit (web UI)
    - scikit-learn (ML models)
    - pandas (data processing)
    - numpy (numerical computing)
    - google-generativeai (Gemini API)
    - python-dotenv (optional, .env support)

Step 2: API Key Configuration

  Option A: Streamlit Secrets (Recommended)
    1. Create .streamlit/secrets.toml
    2. Add: GEMINI_API_KEY_1 = "your-key-here"
    3. Optionally add GEMINI_API_KEY_2 through _4

  Option B: Environment Variable
    1. export GEMINI_API_KEY_1="your-key-here"
    2. Export command before running app

  Option C: .env File
    1. Create .env file in project root
    2. Add: GEMINI_API_KEY_1=your-key-here
    3. Code auto-loads via load_dotenv()

Step 3: Verify Directory Structure
  Command: ls -la

  Verify existence of:
    - data/training_dataset/ (raw CSV files)
    - data/input/sample_properties/ (sample JSON files)
    - ml/data_cleaning/ (cleaning scripts)
    - ml/train_model/ (training scripts)
    - ml/models/ (will be created)


ML PIPELINE EXECUTION:

Complete Pipeline (Data Cleaning → Model Training → Evaluation):

Command: python3 ml/train_pipeline.py

Execution Steps:
  1. Load raw price training data (30,000 rows)
     File: data/training_dataset/price_valuation_training.csv

  2. Load raw risk training data (30,000 rows)
     File: data/training_dataset/risk_assessment_training.csv

  3. Clean price data
     - Remove duplicates: ~4,492 rows (14.97%)
     - Handle missing values
     - Encode categorical features
     - Remove outliers
     - Output: data/processed/price_valuation_cleaned.csv (25,508 rows)

  4. Clean risk data
     - Remove duplicates: ~7,095 rows (23.65%)
     - Handle missing values
     - Validate risk levels
     - Remove outliers
     - Output: data/processed/risk_assessment_cleaned.csv (22,905 rows)

  5. Train price estimation model
     - Load cleaned price data
     - 80% train, 20% test split
     - RandomForest regression (100 trees, depth 10)
     - StandardScaler normalization
     - Output: ml/models/price_estimation_model.pkl (7.5 MB)
     - Output: ml/models/price_estimation_scaler.pkl (905 B)
     - Metrics: train_r2=0.9248, test_r2=0.8957

  6. Train risk assessment model
     - Load cleaned risk data
     - 80% train, 20% test split
     - RandomForest classification (100 trees, depth 10)
     - StandardScaler normalization, LabelEncoder
     - Output: ml/models/risk_assessment_model.pkl (6.5 MB)
     - Output: ml/models/risk_assessment_scaler.pkl (905 B)
     - Output: ml/models/risk_level_encoder.pkl (281 B)
     - Metrics: train_accuracy=0.8713, test_accuracy=0.8282

  7. Evaluate both models
     - If evaluation dataset exists: data/evaluation_dataset/
     - Calculate metrics on separate test set
     - Output evaluation summary

  8. Print pipeline summary
     - Display all metrics and statistics
     - Confirm successful execution

Time Required: Approximately 30-60 seconds total
Output: Summary statistics printed to console


INDIVIDUAL COMPONENT EXECUTION:

Clean Price Data Only:
  Command: python3 -c "
from ml.data_cleaning.clean_price_valuation_data import clean_price_valuation_data
import pandas as pd
df = pd.read_csv('data/training_dataset/price_valuation_training.csv')
cleaned_df, stats = clean_price_valuation_data(df, save_processed=True)
print(stats)
"

Clean Risk Data Only:
  Command: python3 -c "
from ml.data_cleaning.clean_risk_assessment_data import clean_risk_assessment_data
import pandas as pd
df = pd.read_csv('data/training_dataset/risk_assessment_training.csv')
cleaned_df, stats = clean_risk_assessment_data(df, save_processed=True)
print(stats)
"

Train Price Model Only:
  Command: python3 -c "
from ml.train_model.train_price_estimation_model import train_price_estimation_model
import pandas as pd
df = pd.read_csv('data/processed/price_valuation_cleaned.csv')
stats = train_price_estimation_model(df)
print(stats)
"

Train Risk Model Only:
  Command: python3 -c "
from ml.train_model.train_risk_assessment_model import train_risk_assessment_model
import pandas as pd
df = pd.read_csv('data/processed/risk_assessment_cleaned.csv')
stats = train_risk_assessment_model(df)
print(stats)
"

Evaluate Models:
  Command: python3 -c "
from ml.evaluation.evaluate_models import evaluate_all_models
results = evaluate_all_models()
print(results)
"


TEST SUITE EXECUTION:

Run All Tests:
  Command: pytest tests.py -v

  Output: 18 tests with results
  Expected Time: ~1.5 seconds
  Expected Result: 18 passed

Run Specific Test Group:
  Command: pytest tests.py -k "ml" -v
  Description: Runs only ML-related tests

  Command: pytest tests.py -k "mock" -v
  Description: Runs only mock LLM tests

  Command: pytest tests.py -k "parse" -v
  Description: Runs only parser tests

Run with Coverage Report:
  Command: pytest tests.py --cov=agents --cov=nodes --cov-report=html

  Output: Coverage report in htmlcov/ directory
  Shows: Percentage of code covered by tests

Run Single Test:
  Command: pytest tests.py::test_price_estimation_ml -v
  Description: Runs single specific test


STREAMLIT WEB APPLICATION:

Start Web Application:
  Command: streamlit run main.py

  Output Console Message:
    You can now view your Streamlit app in your browser.
    Local URL: http://localhost:8501
    Network URL: http://YOUR-IP:8501

Application Actions:
  1. Open browser to http://localhost:8501
  2. Sidebar appears on left
  3. Select property from dropdown
  4. Click "Analyze Property" button
  5. Wait for analysis to complete
  6. View results in 6 tabs
  7. Download reports as needed

Configuration During Runtime:
  - Can change property selection anytime
  - Previous analysis cleared
  - Can re-run analysis on same property
  - Session persists analysis results

Stopping Application:
  Command: Press Ctrl+C in terminal

  Output: Streamlit server stops
  Browser: Page becomes unavailable


COMPLETE WORKFLOW EXECUTION (End-to-End):

Full Workflow Start to UI:

  Step 1: Setup Dependencies
    Command: pip install -r requirements.txt
    Duration: 1-2 minutes

  Step 2: Configure API Keys
    Command: Edit .streamlit/secrets.toml
    Add: GEMINI_API_KEY_1 = "your-key"
    Duration: 1 minute

  Step 3: Train ML Models (Optional, if not trained)
    Command: python3 ml/train_pipeline.py
    Duration: 30-60 seconds
    Output: Model files in ml/models/

  Step 4: Run Tests (Optional, verify setup)
    Command: pytest tests.py -v
    Duration: 1-2 seconds
    Expected: 18 tests passing

  Step 5: Start Web Application
    Command: streamlit run main.py
    Duration: ~5 seconds startup
    Output: Web app running at http://localhost:8501

  Step 6: Use Application
    - Select property from dropdown
    - Click "Analyze Property"
    - View results in tabs
    - Download reports

  Total Time: 5-10 minutes from start to first property analysis


TROUBLESHOOTING COMMANDS:

Check Python Version:
  Command: python3 --version
  Expected: Python 3.9.6 or higher

Check Installed Packages:
  Command: pip list | grep -E "langgraph|streamlit|scikit-learn"
  Expected: All three packages listed

Test Data Cleaning:
  Command: python3 ml/data_cleaning/clean_price_valuation_data.py
  Expected: Prints cleaning statistics

Test Model Training:
  Command: python3 ml/train_pipeline.py 2>&1 | tail -20
  Expected: Shows summary statistics

Test API Key Detection:
  Command: python3 -c "from utils.gemini_client import _get_first_api_key; print(_get_first_api_key())"
  Expected: Prints API key (masked) or None

Test Workflow Directly:
  Command: python3 -c "
from graph import analyze_property
import json
with open('data/input/sample_properties/PROP-1.json') as f:
    data = json.load(f)
result = analyze_property(data, llm_client=None)
print(f'Price: {result.get(\\\"predicted_price\\\")}')
print(f'Risk: {result.get(\\\"risk_level\\\")}')
"
  Expected: Prints price and risk level


SECTION 9: OUTPUT DESCRIPTION
================================================================================

WEB APPLICATION OUTPUT (Streamlit UI):

PROPERTY ANALYSIS OUTPUT:

Overview Tab Output:

  Financial Metrics Box (2x2 Grid):
    Estimated Price: $751,943 (95% confidence)
    Risk Level: MODERATE (Score: 4.5/10)
    Investment Viability: Viable
    Intent Confidence: 85%

  Market Intent Section:
    Full text describing investment opportunity classification
    Example: "This property represents a solid long-term rental
    investment opportunity. Located in a growing market with stable
    employment, it offers moderate appreciation potential with
    manageable risk."

  Key Findings Section (3 columns):
    Column 1 - Risk Factors (Count: 2):
      • Fair condition requires some updates
      • Market showing modest appreciation

    Column 2 - Recommended Actions (Count: 3):
      • Schedule property inspection
      • Research comparable rents
      • Evaluate financing options

    Column 3 - Opportunity Type:
      investment_property

Risk Analysis Tab Output:

  Risk Assessment Header
  Risk Factors Identified: 2

  Factor List (as warning boxes):
    • Fair condition requires some updates
    • Market showing modest appreciation

Market Intelligence Tab Output:

  Market Insights (Column 1):
    Location: Urban, growing tech hub
    Market Momentum: Steady growth
    Economic Health: Strong employment
    Trends: Consistent appreciation
    Employment Rate: 95%

  Market Trends (Column 2):
    Direction: Upward
    Strength: Moderate
    Appreciation Rate: 2.5% annually
    Forecast: Continued growth
    Risk Alignment: Favorable

  Comparable Properties Table:
    Property 1:
      Address: 456 Oak Ave
      Price: $720,000
      Features: 4bd, 2.5ba, 2300 sqft
      Similarity: 94%

    Property 2:
      Address: 789 Pine St
      Price: $780,000
      Features: 4bd, 2.5ba, 2400 sqft
      Similarity: 91%

Recommendations Tab Output:

  Investment Strategy Header

  Primary Recommendation (Info Box):
    "CONDITIONAL BUY: This property presents a good investment
    opportunity with moderate risk. Recommend proceeding with
    thorough due diligence and property inspection. Strong market
    fundamentals support long-term appreciation."

  Recommended Actions (Column 1):
    1. Schedule comprehensive property inspection
    2. Research comparable rental rates in area
    3. Evaluate mortgage financing options
    4. Consult with real estate attorney for review

  Risk Mitigation Strategies (Column 2):
    1. Build 10% reserve fund for repairs
    2. Diversify portfolio across locations
    3. Maintain adequate property insurance

  Metrics (2-column):
    Priority Level: High
    Opportunity Type: investment_property

Quality Metrics Tab Output:

  Individual Metrics (3-column grid):
    Parsing Quality: 95%
    Analysis Completeness: 100%
    Price Confidence: 92%
    Risk Assessment Confidence: 85%
    Recommendation Clarity: 90%
    Overall Quality: 92%

  Overall Assessment (Color-coded Box):
    Assessment: Excellent
    Percentage: 92%
    Color: Green (excellent rating)

Report Tab Output:

  Download Buttons:
    [Download Report (TXT)]  [Download Report (JSON)]

  Report Preview (Text Area, 400px+ height):

    INVESTPULSE INVESTMENT ANALYSIS REPORT
    Generated: 2025-12-06 15:30:45 UTC

    EXECUTIVE SUMMARY
    This property at 123 Main St, Seattle represents a solid
    investment opportunity with moderate risk profile. Market
    analysis indicates good appreciation potential with stable
    local employment. Recommended action: CONDITIONAL BUY pending
    property inspection and financing verification.

    PROPERTY OVERVIEW
    Address: 123 Main St, Seattle, WA 98101
    Type: Residential (Single Family)
    Year Built: 2005 (Age: 20 years)
    Size: 2,500 sq ft
    Bedrooms: 4 | Bathrooms: 2.5
    Condition: Good (8/10)
    Lot Size: 8,000 sq ft

    MARKET ANALYSIS
    [Full market analysis text...]

    INVESTMENT METRICS
    Estimated Market Price: $751,943
    Price Confidence: 95%
    Price Per Sq Ft: $301

    RISK ASSESSMENT
    Risk Level: MODERATE
    Risk Score: 4.5/10
    Risk Confidence: 85%
    Identified Risks:
      • Fair condition requires some updates
      • Market showing modest appreciation

    OPPORTUNITY ASSESSMENT
    Opportunity Type: investment_property
    Market Intent: Long-term rental investment
    Viability: Viable with conditions

    RECOMMENDATIONS
    Primary Recommendation: CONDITIONAL BUY

    Action Items:
      1. Schedule comprehensive property inspection
      2. Research comparable rental rates
      3. Evaluate financing options
      4. Consult with real estate attorney

    CONCLUSION
    [Final conclusion and next steps...]


TEXT REPORT FILE OUTPUT (Plain Text):

Filename Format: {property_id}_{timestamp}.txt
Example: PROP-001_2025-12-06T153045.txt
Location: output/

Content Structure:
  - Header with title and metadata
  - Executive summary (2-3 paragraphs)
  - Property details (address, specs, condition)
  - Market analysis (location, trends, comparables)
  - Investment metrics (price, risk, viability)
  - Risk analysis (identified risks, mitigation)
  - Recommendations (action items, timeline)
  - Conclusion (summary and next steps)
  - Footer with quality metrics

Format: Plain text, human-readable, ~1500-2000 words


JSON REPORT FILE OUTPUT (Structured Data):

Filename Format: {property_id}_{timestamp}.json
Example: PROP-001_2025-12-06T153045.json
Location: output/

JSON Structure:
{
  "metadata": {
    "report_id": "string",
    "property_id": "PROP-001",
    "generated_timestamp": "2025-12-06T15:30:45Z",
    "report_version": "1.0"
  },

  "property_info": {
    "address": "123 Main St",
    "city": "Seattle",
    "state": "WA",
    "zip_code": "98101",
    "property_type": "residential",
    "year_built": 2005,
    "square_footage": 2500,
    "bedrooms": 4,
    "bathrooms": 2.5
  },

  "analysis_results": {
    "estimated_price": 751943,
    "price_confidence": 0.95,
    "risk_level": "moderate",
    "risk_score": 4.5,
    "risk_confidence": 0.85,
    "opportunity_type": "investment_property",
    "market_intent": "Long-term rental investment",
    "investment_viability": "viable"
  },

  "market_analysis": {
    "market_insights": {
      "location_appeal": "Urban, growing tech hub",
      "market_momentum": "Steady growth",
      "employment_rate": 95
    },
    "comparable_properties": [
      {
        "address": "456 Oak Ave",
        "price": 720000,
        "similarity_score": 0.94
      }
    ],
    "market_trends": {
      "direction": "upward",
      "appreciation_rate": 2.5
    }
  },

  "recommendations": {
    "primary_recommendation": "CONDITIONAL BUY",
    "investment_actions": [
      "Schedule property inspection",
      "Research rental rates",
      "Evaluate financing"
    ],
    "risk_mitigation": [
      "Build 10% repair reserve",
      "Diversify portfolio"
    ],
    "action_priority": "high"
  },

  "quality_metrics": {
    "parsing_quality": 0.95,
    "analysis_completeness": 1.0,
    "price_confidence": 0.92,
    "risk_confidence": 0.85,
    "overall_quality": 0.92
  }
}


CONSOLE OUTPUT (Command Line Execution):

Training Pipeline Output:

================================================================================
TRAINING PIPELINE SUMMARY
================================================================================
Price Cleaning: {
  'original_rows': 30000,
  'cleaned_rows': 25508,
  'duplicates_removed': 4492,
  'rows_removed_pct': 14.97,
  'output_path': 'data/processed/price_valuation_cleaned.csv'
}
Risk Cleaning: {
  'original_rows': 30000,
  'cleaned_rows': 22905,
  'duplicates_removed': 7095,
  'rows_removed_pct': 23.65,
  'output_path': 'data/processed/risk_assessment_cleaned.csv'
}
Price Training: {
  'train_r2': 0.9248,
  'test_r2': 0.8957,
  'test_mae': 53869.85,
  'test_rmse': 70517.73,
  'test_mape': 11.05,
  'overfitting_gap': 0.0291
}
Risk Training: {
  'train_accuracy': 0.8713,
  'test_accuracy': 0.8282,
  'test_precision': 0.8280,
  'test_recall': 0.8282,
  'test_f1': 0.8279,
  'overfitting_gap': 0.0431
}
Evaluation: {
  'timestamp': '2025-12-06T21:59:00.324915',
  'price_evaluation': {'mae': 63996.62, 'rmse': 107113.54, 'r2': 0.8556},
  'risk_evaluation': {'accuracy': 0.9193, 'precision': 0.9201, 'f1': 0.9196}
}
================================================================================


Test Execution Output:

Command: pytest tests.py -v

============================= test session starts ==============================
collected 18 items

tests.py::test_parse_valid_property PASSED                               [  5%]
tests.py::test_property_age_calculation PASSED                           [ 11%]
tests.py::test_field_aliases PASSED                                      [ 16%]
tests.py::test_price_estimation_ml PASSED                                [ 22%]
tests.py::test_risk_assessment_ml PASSED                                 [ 27%]
tests.py::test_market_intent_classifier_mock PASSED                      [ 33%]
tests.py::test_market_intelligence_mock PASSED                           [ 38%]
tests.py::test_recommendation_generator_mock PASSED                       [ 44%]
tests.py::test_report_generator_mock PASSED                              [ 50%]
tests.py::test_initial_state_creation PASSED                             [ 55%]
tests.py::test_validate_state PASSED                                     [ 61%]
tests.py::test_price_prediction_safe_vs_risky PASSED                     [ 66%]
tests.py::test_risk_assessment_safe_vs_risky PASSED                      [ 72%]
tests.py::test_analyze_property_complete PASSED                          [ 77%]
tests.py::test_get_threat_summary PASSED                                 [ 83%]
tests.py::test_ml_models_exist PASSED                                    [ 88%]
tests.py::test_cleaned_datasets_exist PASSED                             [ 94%]
tests.py::test_model_evaluation PASSED                                   [100%]

======================== 18 passed in 1.32s =========================


PROPERTY ANALYSIS WORKFLOW OUTPUT (Python):

When running analyze_property():

Initial State:
{
  'property_json': {...},
  'property_id': 'PROP-001',
  'address': '123 Main St',
  'city': 'Seattle',
  'parsing_complete': False,
  'analysis_complete': False,
  ...
}

After Stage 1 (Parser):
{
  'parsed_property': {...normalized data...},
  'property_headers_normalized': {'address': '...', 'city': '...'},
  'parsing_complete': True
}

After Stage 2 (Analyzer):
{
  'extracted_features': {
    'square_feet': 2500,
    'bedrooms': 4,
    ...
    'price_gap_pct': 8.5
  },
  'analysis_complete': True
}

After Stages 3-4 (ML Models):
{
  'predicted_price': 751943,
  'price_confidence': 0.95,
  'risk_level': 'moderate',
  'risk_score': 4.5,
  'risk_confidence': 0.85,
  'risk_factors': ['Factor 1', 'Factor 2']
}

After Stages 5-8 (LLM Agents):
{
  'opportunity_type': 'investment_property',
  'market_intent': 'Long-term rental investment',
  'market_insights': {...},
  'investment_recommendation': 'CONDITIONAL BUY',
  'investment_actions': [...],
  'risk_mitigation': [...],
  'investment_report': '...full text report...',
  'report_json': {...},
  'quality_metrics': {...}
}

Final State: 60+ fields populated with complete analysis


SECTION 10: SUMMARY
================================================================================

INVESTPULSE PROJECT COMPONENTS:

CORE FILES:
  - main.py: Streamlit web application (UI)
  - graph.py: Workflow orchestration
  - state.py: State management TypedDict
  - tests.py: 18 unit tests with mocks
  - workflow/workflow.py: LangGraph DAG definition

AGENTS (8):
  - property_parser.py: Data validation
  - property_analyzer.py: Feature engineering
  - price_estimation_ml.py: Price regression
  - risk_assessment_ml.py: Risk classification
  - market_intent_classifier_llm.py: Opportunity classification
  - market_intelligence_llm.py: Market analysis
  - recommendation_generator_llm.py: Recommendations
  - report_generator_llm.py: Report generation

NODES (8):
  - Wrapper functions for LangGraph execution
  - Each returns partial dict for state merging

ML PIPELINE:
  - data_cleaning/: Data cleaning functions
  - train_model/: Model training functions
  - evaluation/: Model evaluation functions
  - models/: Trained model files (pkl)

UTILITIES:
  - gemini_client.py: Gemini API adapter

CONFIGURATION:
  - .streamlit/: Streamlit configuration

EXECUTION FLOW:
  1. Data Cleaning: 30K rows → 25.5K rows (price), 22.9K rows (risk)
  2. Model Training: RandomForest (100 trees, depth 10)
  3. Tests: 18 unit tests (1.32 seconds, 100% pass)
  4. Web UI: Streamlit with 6 analysis tabs
  5. API: Gemini LLM integration for insights
  6. Output: Text + JSON reports

KEY METRICS:
  - Price Model: R² = 0.8957 (89.57% accuracy)
  - Risk Model: Accuracy = 0.8282 (82.82% accuracy)
  - Tests: 18/18 passing
  - UI: 6 tabs, professional styling
  - Features: 19 engineered features
  - State: 60+ fields tracked

PROJECT STATUS: PRODUCTION READY

All components functional, tested, and documented.
Ready for deployment and real-world property analysis.

================================================================================
END OF COMPREHENSIVE DOCUMENTATION
================================================================================
