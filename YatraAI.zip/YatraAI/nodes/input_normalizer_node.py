"""Input Normalizer Node - normalizes user preferences."""

from state import TravelPlanState


def input_normalizer_node(state: TravelPlanState) -> TravelPlanState:
    """Normalize user input to standard format."""
    try:
        # Determine destination cost tier
        tier_map = {
            "Mumbai": "Tier-1", "Delhi": "Tier-1", "Goa": "Tier-1", "Bangalore": "Tier-1",
            "Udaipur": "Tier-2", "Varanasi": "Tier-2", "Kolkata": "Tier-2", "Lucknow": "Tier-2",
            "Agra": "Tier-2", "Pune": "Tier-2", "Hyderabad": "Tier-2",
            "Kerala": "Tier-3", "Rishikesh": "Tier-3", "Himachal Pradesh": "Tier-3",
            "Rajasthan (non-GT)": "Tier-3", "Northeast India": "Tier-3",
            "Jaipur": "Tier-2",
        }

        destination = state.get("destination", "")
        state["destination_cost_tier"] = tier_map.get(destination, "Tier-2")

        # Set accommodation preference based on cost tier
        tier = state.get("destination_cost_tier", "Tier-2")
        if tier == "Tier-1":
            state["accommodation_preference"] = "Mid-range"
        elif tier == "Tier-3":
            state["accommodation_preference"] = "Budget"
        else:
            state["accommodation_preference"] = "Mid-range"

        # Normalize interests
        primary = state.get("primary_interest", "")
        secondary = state.get("secondary_interest", "")
        interests = []
        if primary:
            interests.append(primary)
        if secondary and secondary != "None":
            interests.append(secondary)

        state["parsed_profile"] = {
            "destination": destination,
            "trip_duration_days": state.get("trip_duration_days"),
            "total_budget_inr": state.get("total_budget_inr"),
            "group_size": state.get("group_size"),
            "primary_interest": primary,
            "secondary_interest": secondary,
            "travel_season": state.get("travel_season"),
            "destination_cost_tier": state.get("destination_cost_tier"),
            "accommodation_preference": state.get("accommodation_preference"),
            "interests": interests,
        }

        return state

    except Exception as e:
        state["error_messages"].append(f"Input normalizer error: {str(e)}")
        state["error_occurred"] = True
        return state
