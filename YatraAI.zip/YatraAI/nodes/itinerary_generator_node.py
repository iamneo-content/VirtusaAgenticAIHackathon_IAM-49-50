"""Itinerary Generator Node - calls Itinerary Generator LLM agent."""

from state import TravelPlanState
from agents.itinerary_generator_llm import ItineraryGeneratorLLMAgent
from utils.gemini_client import build_gemini_client


def itinerary_generator_node(state: TravelPlanState) -> TravelPlanState:
    """Execute Itinerary Generator LLM agent."""
    try:
        client = build_gemini_client()
        agent = ItineraryGeneratorLLMAgent(client)

        trip_profile = {
            "destination": state.get("destination"),
            "trip_duration_days": state.get("trip_duration_days"),
            "total_budget_inr": state.get("total_budget_inr"),
            "group_size": state.get("group_size"),
            "primary_interest": state.get("primary_interest"),
            "secondary_interest": state.get("secondary_interest"),
            "travel_season": state.get("travel_season"),
            "accommodation_type": state.get("accommodation_type"),
            "accommodation_budget_pct": state.get("accommodation_budget_pct"),
            "food_dining_budget_pct": state.get("food_dining_budget_pct"),
            "activities_attractions_budget_pct": state.get("activities_attractions_budget_pct"),
            "local_transport_budget_pct": state.get("local_transport_budget_pct"),
            "shopping_misc_budget_pct": state.get("shopping_misc_budget_pct"),
            "contingency_budget_pct": state.get("contingency_budget_pct"),
            "daily_budget": state.get("daily_budget"),
        }

        result = agent.generate_itinerary(trip_profile)

        if result.get("status") == "success":
            state["itinerary"] = result.get("itinerary", {})
            state["trip_highlights"] = result.get("trip_highlights", [])
            state["contingency_plans"] = result.get("contingency_plans", [])
            state["itinerary_tips"] = result.get("tips_for_success", [])
            state["itinerary_analysis_complete"] = True
        else:
            state["error_messages"].append(f"Itinerary generation error: {result.get('error_message')}")
            state["error_occurred"] = True
            state["itinerary_analysis_complete"] = False

        return state

    except Exception as e:
        state["error_messages"].append(f"Itinerary generator node error: {str(e)}")
        state["error_occurred"] = True
        state["itinerary_analysis_complete"] = False
        return state
