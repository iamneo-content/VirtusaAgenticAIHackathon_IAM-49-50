"""Booking Strategy Node - calls Booking Strategy LLM agent."""

from state import TravelPlanState
from agents.booking_strategy_llm import BookingStrategyLLMAgent
from utils.gemini_client import build_gemini_client


def booking_strategy_node(state: TravelPlanState) -> TravelPlanState:
    """Execute Booking Strategy LLM agent."""
    try:
        client = build_gemini_client()
        agent = BookingStrategyLLMAgent(client)

        trip_profile = {
            "destination": state.get("destination"),
            "trip_duration_days": state.get("trip_duration_days"),
            "total_budget_inr": state.get("total_budget_inr"),
            "group_size": state.get("group_size"),
            "primary_interest": state.get("primary_interest"),
            "secondary_interest": state.get("secondary_interest"),
            "travel_season": state.get("travel_season"),
            "accommodation_type": state.get("accommodation_type"),
            "accommodation_budget_inr": state.get("budget_allocation", {}).get("accommodation", 30000),
        }

        result = agent.get_booking_strategy(trip_profile)

        if result.get("status") == "success":
            state["flight_booking_strategy"] = result.get("flight_booking_strategy", {})
            state["accommodation_booking_strategy"] = result.get("accommodation_booking_strategy", {})
            state["activity_booking_strategy"] = result.get("activity_booking_strategy", {})
            state["visa_requirements"] = result.get("logistics_planning", {}).get("visa_requirements", {})
            state["budget_optimization_tips"] = result.get("money_saving_tips_summary", [])
            state["booking_checklist"] = result.get("pre_departure_checklist", {}).get("one_week_before", [])
            state["packing_checklist"] = result.get("packing_checklist", {})
            state["emergency_contingency_plans"] = result.get("emergency_contingency_plans", {})
            state["booking_analysis_complete"] = True
        else:
            state["error_messages"].append(f"Booking strategy error: {result.get('error_message')}")
            state["error_occurred"] = True
            state["booking_analysis_complete"] = False

        return state

    except Exception as e:
        state["error_messages"].append(f"Booking strategy node error: {str(e)}")
        state["error_occurred"] = True
        state["booking_analysis_complete"] = False
        return state
