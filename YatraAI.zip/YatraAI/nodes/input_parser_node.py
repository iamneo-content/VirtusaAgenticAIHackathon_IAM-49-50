"""Input Parser Node - validates user input."""

from state import TravelPlanState


def input_parser_node(state: TravelPlanState) -> TravelPlanState:
    """Parse and validate user input."""
    try:
        valid_destinations = [
            "Jaipur", "Goa", "Delhi", "Mumbai", "Bangalore",
            "Udaipur", "Varanasi", "Kolkata", "Agra", "Kerala",
            "Pune", "Lucknow", "Rishikesh", "Rajasthan (non-GT)",
            "Himachal Pradesh", "Northeast India", "Hyderabad",
        ]

        errors = []

        # Validate destination
        if state.get("destination") not in valid_destinations:
            errors.append(f"Invalid destination: {state.get('destination')}")

        # Validate budget
        budget = state.get("total_budget_inr", 0)
        if budget < 5000 or budget > 500000:
            errors.append(f"Budget must be between Rs 5,000 and Rs 5,00,000")

        # Validate trip duration
        duration = state.get("trip_duration_days", 0)
        if duration < 2 or duration > 30:
            errors.append(f"Trip duration must be between 2 and 30 days")

        # Validate group size
        group_size = state.get("group_size", 0)
        if group_size < 1 or group_size > 10:
            errors.append(f"Group size must be between 1 and 10 people")

        # Update state
        state["validation_errors"] = errors
        state["parsing_complete"] = len(errors) == 0

        if errors:
            state["error_messages"].extend(errors)
            state["error_occurred"] = True

        return state

    except Exception as e:
        state["error_messages"].append(f"Input parser error: {str(e)}")
        state["error_occurred"] = True
        state["parsing_complete"] = False
        return state
