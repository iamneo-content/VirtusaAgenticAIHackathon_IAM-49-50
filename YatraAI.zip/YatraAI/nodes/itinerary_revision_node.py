"""Itinerary Revision Node - Validates and revises itinerary with max 2 attempts."""

from state import TravelPlanState
from utils.gemini_client import build_gemini_client


def itinerary_validator_and_reviser_node(state: TravelPlanState) -> TravelPlanState:
    """Validate itinerary and revise if needed (max 2 revisions for complex trips).

    Pure LLM validation and revision - analyzes itinerary quality and suggests improvements.
    For complex trips (complexity_score > 0.7), allows up to 2 revision attempts.
    """
    try:
        client = build_gemini_client()

        itinerary = state.get("itinerary", {})
        complexity_score = float(state.get("complexity_score") or 0.5)
        revision_count = int(state.get("itinerary_revision_count", 0) or 0)
        max_revisions = 2 if complexity_score > 0.7 else 1

        trip_profile = {
            "destination": state.get("destination"),
            "trip_duration_days": state.get("trip_duration_days"),
            "total_budget_inr": state.get("total_budget_inr"),
            "group_size": state.get("group_size"),
            "primary_interest": state.get("primary_interest"),
            "secondary_interest": state.get("secondary_interest"),
            "daily_budget": state.get("daily_budget"),
            "accommodation_type": state.get("accommodation_type"),
        }

        validation_prompt = f"""Review this itinerary for a {trip_profile.get('trip_duration_days', 7)}-day trip to {trip_profile.get('destination', 'Unknown')} and provide validation feedback.

Current Itinerary:
{itinerary}

Trip Details:
- Group Size: {trip_profile.get('group_size', 1)} person(s)
- Daily Budget: Rs {trip_profile.get('daily_budget', 7000)}
- Primary Interest: {trip_profile.get('primary_interest', 'General')}
- Accommodation Type: {trip_profile.get('accommodation_type', 'Mid-range')}
- Complexity Score: {complexity_score:.2f}

Provide validation as JSON with this structure:
{{
  "is_valid": true/false,
  "validation_score": 0.0-1.0,
  "issues": ["issue1", "issue2"],
  "improvement_suggestions": ["suggestion1", "suggestion2"],
  "revision_needed": true/false
}}

Only respond with valid JSON."""

        validation_response = client.generate_content(
            validation_prompt,
            temperature=0.5,
            max_tokens=1500
        )

        validation_data = client.extract_json_from_response(validation_response)

        state["itinerary_validation_score"] = validation_data.get("validation_score", 0.5)
        state["itinerary_validation_issues"] = validation_data.get("issues", [])

        revision_needed = validation_data.get("revision_needed", False)

        if revision_needed and revision_count < max_revisions:
            revision_prompt = f"""Revise this itinerary based on the issues identified.

Original Itinerary:
{itinerary}

Issues to Fix:
{', '.join(validation_data.get('issues', []))}

Trip Details:
- Destination: {trip_profile.get('destination', 'Unknown')}
- Duration: {trip_profile.get('trip_duration_days', 7)} days
- Daily Budget: Rs {trip_profile.get('daily_budget', 7000)}
- Primary Interest: {trip_profile.get('primary_interest', 'General')}
- Group Size: {trip_profile.get('group_size', 1)} person(s)

Provide the revised itinerary in this exact JSON format:
{{
  "itinerary": {{
    "day_1": {{"title": "...", "activities": [...], "estimated_cost": ...}},
    "day_2": {{"title": "...", "activities": [...], "estimated_cost": ...}}
  }},
  "trip_highlights": [...],
  "contingency_plans": [...],
  "tips_for_success": [...]
}}

Only respond with valid JSON."""

            revision_response = client.generate_content(
                revision_prompt,
                temperature=0.7,
                max_tokens=2500
            )

            revised_itinerary_data = client.extract_json_from_response(revision_response)

            state["itinerary"] = revised_itinerary_data.get("itinerary", state.get("itinerary", {}))
            state["trip_highlights"] = revised_itinerary_data.get("trip_highlights", state.get("trip_highlights", []))
            state["contingency_plans"] = revised_itinerary_data.get("contingency_plans", state.get("contingency_plans", []))
            state["itinerary_revision_count"] = revision_count + 1
            state["itinerary_revised"] = True

        state["itinerary_analysis_complete"] = True
        return state

    except Exception as e:
        state["error_messages"].append(f"Itinerary validator and reviser error: {str(e)}")
        state["error_occurred"] = True
        state["itinerary_analysis_complete"] = True
        return state
