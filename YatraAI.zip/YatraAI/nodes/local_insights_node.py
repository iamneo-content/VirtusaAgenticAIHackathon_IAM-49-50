"""Local Insights Node - calls Local Insights LLM agent."""

from state import TravelPlanState
from agents.local_insights_llm import LocalInsightsLLMAgent
from utils.gemini_client import build_gemini_client


def local_insights_node(state: TravelPlanState) -> TravelPlanState:
    """Execute Local Insights LLM agent."""
    try:
        client = build_gemini_client()
        agent = LocalInsightsLLMAgent(client)

        trip_profile = {
            "destination": state.get("destination"),
            "trip_duration_days": state.get("trip_duration_days"),
            "total_budget_inr": state.get("total_budget_inr"),
            "group_size": state.get("group_size"),
            "primary_interest": state.get("primary_interest"),
            "secondary_interest": state.get("secondary_interest"),
            "travel_season": state.get("travel_season"),
            "accommodation_type": state.get("accommodation_type"),
        }

        itinerary = state.get("itinerary", {})

        result = agent.get_local_insights(trip_profile, itinerary)

        if result.get("status") == "success":
            state["hidden_gems"] = result.get("hidden_gems", [])
            state["local_food_spots"] = result.get("local_food_spots", [])
            state["neighborhoods_to_explore"] = result.get("neighborhoods_to_explore", [])
            state["local_etiquette_tips"] = result.get("local_etiquette_tips", [])
            state["money_saving_hacks"] = result.get("money_saving_hacks", [])
            state["free_or_cheap_attractions"] = result.get("free_or_cheap_attractions", [])
            state["avoid_tourist_traps"] = result.get("avoid_tourist_traps", [])
            state["best_times_to_avoid_crowds"] = result.get("best_times_to_avoid_crowds", {})
            state["insights_analysis_complete"] = True
        else:
            state["error_messages"].append(f"Local insights error: {result.get('error_message')}")
            state["error_occurred"] = True
            state["insights_analysis_complete"] = False

        return state

    except Exception as e:
        state["error_messages"].append(f"Local insights node error: {str(e)}")
        state["error_occurred"] = True
        state["insights_analysis_complete"] = False
        return state
