"""Budget Allocator Node - calls Budget Allocator ML agent."""

from state import TravelPlanState
from agents.budget_allocator_ml import BudgetAllocatorMLAgent


def budget_allocator_node(state: TravelPlanState) -> TravelPlanState:
    """Execute Budget Allocator ML agent."""
    try:
        agent = BudgetAllocatorMLAgent()

        trip_profile = {
            "destination": state.get("destination"),
            "trip_duration_days": state.get("trip_duration_days"),
            "total_budget_inr": state.get("total_budget_inr"),
            "group_size": state.get("group_size"),
            "primary_interest": state.get("primary_interest"),
            "secondary_interest": state.get("secondary_interest"),
            "accommodation_preference": state.get("accommodation_preference"),
            "travel_season": state.get("travel_season"),
            "destination_cost_tier": state.get("destination_cost_tier"),
        }

        result = agent.allocate_budget(trip_profile)

        if result.get("status") == "success":
            state["accommodation_budget_pct"] = result.get("accommodation_budget_pct", 30.0)
            state["food_dining_budget_pct"] = result.get("food_dining_budget_pct", 25.0)
            state["activities_attractions_budget_pct"] = result.get("activities_attractions_budget_pct", 25.0)
            state["local_transport_budget_pct"] = result.get("local_transport_budget_pct", 10.0)
            state["shopping_misc_budget_pct"] = result.get("shopping_misc_budget_pct", 7.0)
            state["contingency_budget_pct"] = result.get("contingency_budget_pct", 3.0)
            state["daily_budget"] = result.get("daily_budget", 0)
            state["budget_allocation"] = result.get("budget_allocation", {})
        else:
            state["error_messages"].append(f"Budget allocation error: {result.get('error_message')}")
            state["error_occurred"] = True

        return state

    except Exception as e:
        state["error_messages"].append(f"Budget allocator node error: {str(e)}")
        state["error_occurred"] = True
        return state
