"""Accommodation Recommender Node - calls Accommodation Recommender ML agent."""

from state import TravelPlanState
from agents.accommodation_recommender_ml import AccommodationRecommenderMLAgent


def accommodation_recommender_node(state: TravelPlanState) -> TravelPlanState:
    """Execute Accommodation Recommender ML agent."""
    try:
        agent = AccommodationRecommenderMLAgent()

        user_profile = {
            "destination": state.get("destination"),
            "total_budget_inr": state.get("total_budget_inr"),
            "accommodation_budget_inr": state.get("budget_allocation", {}).get("accommodation", 30000),
            "trip_duration_days": state.get("trip_duration_days"),
            "group_size": state.get("group_size"),
            "primary_interest": state.get("primary_interest"),
            "secondary_interest": state.get("secondary_interest"),
            "travel_season": state.get("travel_season"),
            "destination_cost_tier": state.get("destination_cost_tier"),
            "interests": [state.get("primary_interest"), state.get("secondary_interest")],
        }

        result = agent.recommend_accommodation(user_profile)

        if result.get("status") == "success":
            state["accommodation_type"] = result.get("accommodation_type", "Mid-range")
            state["accommodation_class"] = result.get("accommodation_class", 1)
            state["accommodation_confidence"] = result.get("confidence", 0.0)
            state["estimated_cost_per_night"] = result.get("estimated_cost_per_night", 3500.0)
            state["accommodation_alternatives"] = result.get("alternatives", [])
        else:
            state["error_messages"].append(f"Accommodation recommendation error: {result.get('error_message')}")
            state["error_occurred"] = True

        return state

    except Exception as e:
        state["error_messages"].append(f"Accommodation recommender node error: {str(e)}")
        state["error_occurred"] = True
        return state


def accommodation_recommender_low_budget_node(state: TravelPlanState) -> TravelPlanState:
    """Execute Accommodation Recommender ML agent for low budget path."""
    try:
        agent = AccommodationRecommenderMLAgent()

        low_budget = state.get("total_budget_inr", 50000) * 0.3

        user_profile = {
            "destination": state.get("destination"),
            "total_budget_inr": state.get("total_budget_inr"),
            "accommodation_budget_inr": low_budget,
            "trip_duration_days": state.get("trip_duration_days"),
            "group_size": state.get("group_size"),
            "primary_interest": state.get("primary_interest"),
            "secondary_interest": state.get("secondary_interest"),
            "travel_season": state.get("travel_season"),
            "destination_cost_tier": state.get("destination_cost_tier"),
            "interests": [state.get("primary_interest"), state.get("secondary_interest")],
        }

        result = agent.recommend_accommodation(user_profile)

        if result.get("status") == "success":
            state["accommodation_type"] = result.get("accommodation_type", "Budget")
            state["accommodation_class"] = result.get("accommodation_class", 0)
            state["accommodation_confidence"] = result.get("confidence", 0.0)
            state["accommodation_comfort_score"] = result.get("comfort_score", 0.0)
            state["estimated_cost_per_night"] = result.get("estimated_cost_per_night", 1000.0)
            state["accommodation_alternatives"] = result.get("alternatives", [])
            state["accommodation_recommendations"] = {
                "recommendations_by_budget": {
                    "low": {
                        "accommodation_type": result.get("accommodation_type", "Budget"),
                        "accommodation_class": result.get("accommodation_class", 0),
                        "confidence": result.get("confidence", 0.0),
                        "comfort_score": result.get("comfort_score", 0.0),
                        "estimated_cost_per_night": result.get("estimated_cost_per_night", 1000.0),
                        "alternatives": result.get("alternatives", []),
                    }
                }
            }
        else:
            state["error_messages"].append(f"Low budget accommodation error: {result.get('error_message')}")
            state["error_occurred"] = True

        return state

    except Exception as e:
        state["error_messages"].append(f"Low budget accommodation recommender error: {str(e)}")
        state["error_occurred"] = True
        return state


def accommodation_recommender_mid_budget_node(state: TravelPlanState) -> TravelPlanState:
    """Execute Accommodation Recommender ML agent for mid budget path."""
    try:
        agent = AccommodationRecommenderMLAgent()

        mid_budget = state.get("total_budget_inr", 50000) * 0.35

        user_profile = {
            "destination": state.get("destination"),
            "total_budget_inr": state.get("total_budget_inr"),
            "accommodation_budget_inr": mid_budget,
            "trip_duration_days": state.get("trip_duration_days"),
            "group_size": state.get("group_size"),
            "primary_interest": state.get("primary_interest"),
            "secondary_interest": state.get("secondary_interest"),
            "travel_season": state.get("travel_season"),
            "destination_cost_tier": state.get("destination_cost_tier"),
            "interests": [state.get("primary_interest"), state.get("secondary_interest")],
        }

        result = agent.recommend_accommodation(user_profile)

        if result.get("status") == "success":
            state["accommodation_type"] = result.get("accommodation_type", "Mid-range")
            state["accommodation_class"] = result.get("accommodation_class", 1)
            state["accommodation_confidence"] = result.get("confidence", 0.0)
            state["accommodation_comfort_score"] = result.get("comfort_score", 0.0)
            state["estimated_cost_per_night"] = result.get("estimated_cost_per_night", 3500.0)
            state["accommodation_alternatives"] = result.get("alternatives", [])
            state["accommodation_recommendations"] = {
                "recommendations_by_budget": {
                    "mid": {
                        "accommodation_type": result.get("accommodation_type", "Mid-range"),
                        "accommodation_class": result.get("accommodation_class", 1),
                        "confidence": result.get("confidence", 0.0),
                        "comfort_score": result.get("comfort_score", 0.0),
                        "estimated_cost_per_night": result.get("estimated_cost_per_night", 3500.0),
                        "alternatives": result.get("alternatives", []),
                    }
                }
            }
        else:
            state["error_messages"].append(f"Mid budget accommodation error: {result.get('error_message')}")
            state["error_occurred"] = True

        return state

    except Exception as e:
        state["error_messages"].append(f"Mid budget accommodation recommender error: {str(e)}")
        state["error_occurred"] = True
        return state


def accommodation_recommender_high_budget_node(state: TravelPlanState) -> TravelPlanState:
    """Execute Accommodation Recommender ML agent for high budget path."""
    try:
        agent = AccommodationRecommenderMLAgent()

        high_budget = state.get("total_budget_inr", 50000) * 0.4

        user_profile = {
            "destination": state.get("destination"),
            "total_budget_inr": state.get("total_budget_inr"),
            "accommodation_budget_inr": high_budget,
            "trip_duration_days": state.get("trip_duration_days"),
            "group_size": state.get("group_size"),
            "primary_interest": state.get("primary_interest"),
            "secondary_interest": state.get("secondary_interest"),
            "travel_season": state.get("travel_season"),
            "destination_cost_tier": state.get("destination_cost_tier"),
            "interests": [state.get("primary_interest"), state.get("secondary_interest")],
        }

        result = agent.recommend_accommodation(user_profile)

        if result.get("status") == "success":
            state["accommodation_type"] = result.get("accommodation_type", "Luxury")
            state["accommodation_class"] = result.get("accommodation_class", 2)
            state["accommodation_confidence"] = result.get("confidence", 0.0)
            state["accommodation_comfort_score"] = result.get("comfort_score", 0.0)
            state["estimated_cost_per_night"] = result.get("estimated_cost_per_night", 15000.0)
            state["accommodation_alternatives"] = result.get("alternatives", [])
            state["accommodation_recommendations"] = {
                "recommendations_by_budget": {
                    "high": {
                        "accommodation_type": result.get("accommodation_type", "Luxury"),
                        "accommodation_class": result.get("accommodation_class", 2),
                        "confidence": result.get("confidence", 0.0),
                        "comfort_score": result.get("comfort_score", 0.0),
                        "estimated_cost_per_night": result.get("estimated_cost_per_night", 15000.0),
                        "alternatives": result.get("alternatives", []),
                    }
                }
            }
        else:
            state["error_messages"].append(f"High budget accommodation error: {result.get('error_message')}")
            state["error_occurred"] = True

        return state

    except Exception as e:
        state["error_messages"].append(f"High budget accommodation recommender error: {str(e)}")
        state["error_occurred"] = True
        return state
