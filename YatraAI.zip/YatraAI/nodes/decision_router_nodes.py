"""Decision Router Nodes - Pure logic nodes for routing workflow paths."""

from state import TravelPlanState


def budget_feasibility_router(state: TravelPlanState) -> TravelPlanState:
    """Route trip to appropriate budget tier path based on daily budget.

    Pure logic: Analyzes daily_budget and determines which accommodation path to take.
    Sets daily_budget_tier field in state and returns state for routing decision.

    Thresholds for daily budget per person (in INR):
    - Low: < 7,000
    - Mid: 7,000 - 15,000
    - High: > 15,000
    """
    try:
        daily_budget = state.get("daily_budget", 0)

        if daily_budget < 7000:
            state["daily_budget_tier"] = "low_budget_path"
        elif daily_budget < 15000:
            state["daily_budget_tier"] = "mid_budget_path"
        else:
            state["daily_budget_tier"] = "high_budget_path"

        return state

    except Exception as e:
        state["error_messages"].append(f"Budget feasibility router error: {str(e)}")
        state["error_occurred"] = True
        state["daily_budget_tier"] = "mid_budget_path"
        return state


def trip_complexity_analyzer(state: TravelPlanState) -> TravelPlanState:
    """Analyze trip complexity and route to appropriate itinerary generation path.

    Pure logic: Calculates complexity_score based on:
    - Trip duration (40% weight)
    - Group size (30% weight)
    - Number of interests (30% weight)

    Routes to detailed_itinerary_path if complexity_score > 0.7, else simple_itinerary_path.
    """
    try:
        trip_duration_days = state.get("trip_duration_days", 7)
        group_size = state.get("group_size", 1)

        interests_count = 0
        if state.get("primary_interest"):
            interests_count += 1
        if state.get("secondary_interest") and state.get("secondary_interest") != "None":
            interests_count += 1

        duration_normalized = min(trip_duration_days / 30.0, 1.0)
        group_normalized = min(group_size / 10.0, 1.0)
        interests_normalized = interests_count / 2.0

        complexity_score = (duration_normalized * 0.4) + (group_normalized * 0.3) + (interests_normalized * 0.3)

        state["complexity_score"] = complexity_score

        return state

    except Exception as e:
        state["error_messages"].append(f"Trip complexity analyzer error: {str(e)}")
        state["error_occurred"] = True
        state["complexity_score"] = 0.5
        return state
