# YatraAI - Agent-to-Agent Communication Flow Diagram

## Mermaid Diagram

```mermaid
graph TD
    Start([Travel Planning Flow Start]) --> IPNode[Input Parser Node]

    IPNode -->|Validation Success| INNode[Input Normalizer Node]
    IPNode -->|Validation Failed| ValidationFailed[Validation Failed]

    ValidationFailed --> End([Flow Complete])

    INNode --> BANode[Budget Allocator Node]

    BANode -->|Budget Allocation Success| BFRouter{Budget Feasibility<br/>Router}

    BANode -->|Allocation Failed| BudgetFailed[Budget Allocation Failed]
    BudgetFailed --> End

    BFRouter -->|Low Budget<br/>< 7K/day| LowAccomm[Accommodation Recommender<br/>Low Budget Node]
    BFRouter -->|Mid Budget<br/>7K-15K/day| MidAccomm[Accommodation Recommender<br/>Mid Budget Node]
    BFRouter -->|High Budget<br/>> 15K/day| HighAccomm[Accommodation Recommender<br/>High Budget Node]

    LowAccomm --> TCAnalyzer{Trip Complexity<br/>Analyzer}
    MidAccomm --> TCAnalyzer
    HighAccomm --> TCAnalyzer

    TCAnalyzer -->|Accommodation Success| ItinGen[Itinerary Generator<br/>LLM Agent]
    TCAnalyzer -->|Accommodation Failed| AccommFailed[Accommodation Selection Failed]

    AccommFailed --> End

    ItinGen -->|Itinerary Generated| ItinVal[Itinerary Validator<br/>& Reviser<br/>LLM Agent]

    ItinGen -->|Generation Failed| ItinFailed[Itinerary Generation Failed]
    ItinFailed --> End

    ItinVal -->|Validation Score >= 0.8| LocalInsights[Local Insights<br/>LLM Agent]
    ItinVal -->|Revision Needed &<br/>Count < Max| ItinRevised[Itinerary Revised<br/>LLM Agent]

    ItinRevised --> LocalInsights
    ItinVal -->|Validation Failed| ValidationError[Validation Error]

    ValidationError --> End

    LocalInsights -->|Insights Generated| BookingStrat[Booking Strategy<br/>LLM Agent]

    LocalInsights -->|Insights Failed| InsightsFailed[Insights Generation Failed]
    InsightsFailed --> End

    BookingStrat -->|Strategy Generated| CompileResults[Compile All Results]
    BookingStrat -->|Strategy Failed| StrategyFailed[Booking Strategy Failed]

    StrategyFailed --> End

    CompileResults --> FormatOutput[Format Travel Plan<br/>Output State]
    FormatOutput --> GenerateUI[Generate Streamlit<br/>UI Display]
    GenerateUI --> End

    style Start fill:#e1f5ff,stroke:#01579b,stroke-width:2px
    style IPNode fill:#e1f5ff,stroke:#01579b,stroke-width:2px
    style INNode fill:#e1f5ff,stroke:#01579b,stroke-width:2px

    style BANode fill:#f3e5f5,stroke:#4a148c,stroke-width:2px
    style BFRouter fill:#f3e5f5,stroke:#4a148c,stroke-width:2px
    style LowAccomm fill:#f3e5f5,stroke:#4a148c,stroke-width:2px
    style MidAccomm fill:#f3e5f5,stroke:#4a148c,stroke-width:2px
    style HighAccomm fill:#f3e5f5,stroke:#4a148c,stroke-width:2px

    style TCAnalyzer fill:#fff3e0,stroke:#e65100,stroke-width:2px

    style ItinGen fill:#e8f5e9,stroke:#1b5e20,stroke-width:2px
    style ItinVal fill:#e8f5e9,stroke:#1b5e20,stroke-width:2px
    style ItinRevised fill:#e8f5e9,stroke:#1b5e20,stroke-width:2px
    style LocalInsights fill:#e8f5e9,stroke:#1b5e20,stroke-width:2px
    style BookingStrat fill:#e8f5e9,stroke:#1b5e20,stroke-width:2px

    style CompileResults fill:#e1bee7,stroke:#6a1b9a,stroke-width:2px
    style FormatOutput fill:#b2dfdb,stroke:#00695c,stroke-width:2px
    style GenerateUI fill:#b2dfdb,stroke:#00695c,stroke-width:2px

    style ValidationFailed fill:#ffebee,stroke:#b71c1c,stroke-width:1px,stroke-dasharray: 5 5
    style BudgetFailed fill:#ffebee,stroke:#b71c1c,stroke-width:1px,stroke-dasharray: 5 5
    style AccommFailed fill:#ffebee,stroke:#b71c1c,stroke-width:1px,stroke-dasharray: 5 5
    style ItinFailed fill:#ffebee,stroke:#b71c1c,stroke-width:1px,stroke-dasharray: 5 5
    style ValidationError fill:#ffebee,stroke:#b71c1c,stroke-width:1px,stroke-dasharray: 5 5
    style InsightsFailed fill:#ffebee,stroke:#b71c1c,stroke-width:1px,stroke-dasharray: 5 5
    style StrategyFailed fill:#ffebee,stroke:#b71c1c,stroke-width:1px,stroke-dasharray: 5 5

    style End fill:#fce4ec,stroke:#880e4f,stroke-width:2px
```

---

## YatraAI Agent-to-Agent Communication Flow Explanation

### Flow Stages

#### Stage 1: Input Processing (Blue - Data Validation)

```
Input Parser Node (Validation)
         ↓
Input Normalizer Node (Data Preparation)
         ↓
Budget Allocator Node (ML Agent - RandomForest Regressor)
```

**Responsibilities:**
- Validates 7 user inputs against constraints:
  - Destination: must be in 17 valid cities
  - Budget: 5,000 - 500,000 INR
  - Duration: 2-30 days
  - Group Size: 1-10 people
- Normalizes destination to cost tier (Tier-1, Tier-2, Tier-3)
- Maps tier to accommodation preference
- Aggregates interests (primary + secondary)
- Executes ML model for budget allocation:
  - **Input:** 9 encoded features (destination, duration, budget, group, interests, season, tier)
  - **Model:** RandomForest Regressor (19 MB pre-trained)
  - **Output:** 6 budget percentages (accommodation, food, activities, transport, shopping, contingency)

---

#### Stage 2: Budget-Based Routing & ML Classification (Purple - ML Agents)

```
Budget Feasibility Router (Pure Logic - Conditional)
         ↓
    ┌────┼────┐
    ↓    ↓    ↓
 Low  Mid  High
 (3 Parallel Accommodation Recommender ML Agents)
    ↓    ↓    ↓
    └────┼────┘
         ↓
Trip Complexity Analyzer (Pure Logic)
```

**Budget Feasibility Router (Decision Node):**
- Calculates daily_budget: total_budget / trip_duration_days
- Routes to 3 parallel paths:
  - **Low Budget Path:** < 7,000 INR/day (30% accommodation allocation)
  - **Mid Budget Path:** 7,000 - 15,000 INR/day (35% accommodation allocation)
  - **High Budget Path:** > 15,000 INR/day (40% accommodation allocation)

**Accommodation Recommender (3 Parallel Paths):**
- Each path runs independently with budget-tier-specific parameters
- **Input:** 9 encoded features (destination, total budget, accommodation budget, duration, group, interests, season, tier, group_binary)
- **Model:** RandomForest Classifier (11 MB pre-trained)
- **Output per path:**
  - Accommodation type: Budget, Mid-range, Luxury, or Alternative
  - Accommodation class: 0-3
  - Confidence score: 0-100%
  - Comfort score: 0-100 (static mapping)
  - Estimated cost per night (INR)
  - Alternatives: classes with > 10% probability

**Trip Complexity Analyzer (Convergence Point):**
- Merges outputs from 3 parallel accommodation paths
- Uses merge_accommodations reducer to combine recommendations_by_budget
- Calculates complexity_score (0.0-1.0):
  ```
  complexity_score = (duration_norm * 0.4) + (group_norm * 0.3) + (interests_norm * 0.3)
  ```
  - Duration normalized: trip_duration_days / 30.0 (capped at 1.0)
  - Group size normalized: group_size / 10.0 (capped at 1.0)
  - Interests normalized: interests_count / 2.0
- **Impact:** If complexity_score > 0.7 → max itinerary revisions = 2, else = 1

---

#### Stage 3: Itinerary Generation & Validation (Green - LLM Agents)

```
Itinerary Generator LLM Agent (Gemini)
         ↓
Itinerary Validator & Reviser LLM Agent (Gemini)
         ↓
   [If revision needed]
   Itinerary Revised LLM Agent
         ↓
Local Insights LLM Agent (Adaptive prompting based on accommodation)
         ↓
Booking Strategy LLM Agent (Logistics & factual information)
```

##### **Node 9: Itinerary Generator LLM Agent**

**Agent Details:**
- **Model:** Google Gemini 2.5-flash-lite
- **Temperature:** 0.7 (balanced creativity + structure)
- **Max Tokens:** 2,500

**Input to Agent:**
```
trip_profile: {
  destination, trip_duration_days, total_budget_inr, group_size,
  primary_interest, secondary_interest, travel_season,
  accommodation_type, accommodation_budget_pct, food_dining_budget_pct,
  activities_attractions_budget_pct, local_transport_budget_pct,
  shopping_misc_budget_pct, contingency_budget_pct, daily_budget
}
```

**Output from Agent:**
```json
{
  "itinerary": {
    "day_1": {
      "title": "Arrival",
      "activities": ["activity1", "activity2"],
      "estimated_cost": 2000
    },
    "day_2": {...},
    ...
  },
  "trip_highlights": ["highlight1", "highlight2"],
  "contingency_plans": ["plan1", "plan2"],
  "tips_for_success": ["tip1", "tip2"]
}
```

---

##### **Node 10: Itinerary Validator & Reviser LLM Agent**

**Two-Phase Process:**

**Phase 1: Validation (Always)**
- **Temperature:** 0.5 (factual, deterministic)
- **Max Tokens:** 1,500
- Validates itinerary quality against trip profile
- Output: `{is_valid, validation_score, issues, improvement_suggestions, revision_needed}`
- Updates state: itinerary_validation_score, itinerary_validation_issues

**Phase 2: Conditional Revision (If needed)**
- **Condition:** `revision_needed AND revision_count < max_revisions`
- **Max Revisions:**
  - 2 if complexity_score > 0.7
  - 1 if complexity_score ≤ 0.7
- **Temperature:** 0.7 (creative improvement)
- **Max Tokens:** 2,500
- Revises based on identified issues
- Updates itinerary, trip_highlights, contingency_plans
- Increments itinerary_revision_count
- Sets itinerary_revised = True

---

##### **Node 11: Local Insights LLM Agent**

**Agent Details:**
- **Model:** Google Gemini 2.5-flash-lite
- **Temperature:** 0.8 (higher creativity for insights)
- **Max Tokens:** 2,000
- **Special Feature:** Adaptive prompting based on accommodation type

**Adaptive Prompting Logic:**
```python
if accommodation_type == "luxury":
    budget_guidance = "Focus on exclusive, premium, upscale, high-end"
elif accommodation_type == "budget":
    budget_guidance = "Emphasize money-saving, free/cheap, affordable"
else:
    budget_guidance = "Balance budget-conscious and mid-range"
```

**Input to Agent:**
```
trip_profile: {
  destination, group_size, primary_interest, secondary_interest,
  accommodation_type, travel_season, total_budget_inr
}
+ itinerary (for context)
```

**Output from Agent:**
```json
{
  "hidden_gems": [
    {
      "name": "Place Name",
      "description": "What makes it special",
      "estimated_cost": "Budget range",
      "tips": ["tip1", "tip2"]
    }
  ],
  "local_food_spots": [
    {
      "name": "Restaurant",
      "cuisine": "Type",
      "price_range": "Cost indication",
      "signature_dish": "Popular dish"
    }
  ],
  "neighborhoods_to_explore": [
    {
      "name": "Area Name",
      "vibe": "Atmosphere",
      "how_to_spend_time": ["activity1"]
    }
  ],
  "local_etiquette_tips": ["tip1", "tip2"],
  "money_saving_hacks": ["hack1", "hack2"],
  "free_or_cheap_attractions": ["place1", "place2"],
  "avoid_tourist_traps": ["trap1", "trap2"],
  "best_times_to_avoid_crowds": {
    "avoid": ["peak times"],
    "ideal": ["best times"]
  }
}
```

---

##### **Node 12: Booking Strategy LLM Agent**

**Agent Details:**
- **Model:** Google Gemini 2.5-flash-lite
- **Temperature:** 0.6 (factual logistics information)
- **Max Tokens:** 2,500

**Input to Agent:**
```
trip_profile: {
  destination, trip_duration_days, total_budget_inr, group_size,
  primary_interest, secondary_interest, travel_season,
  accommodation_type, accommodation_budget_inr
}
```

**Output from Agent:**
```json
{
  "flight_booking_strategy": {
    "recommended_platforms": ["platform1", "platform2"],
    "booking_window": "4-6 weeks in advance",
    "best_days_to_book": "Tuesday-Thursday",
    "estimated_cost_range": "5000-15000",
    "money_saving_tips": ["tip1", "tip2"]
  },
  "accommodation_booking_strategy": {
    "recommended_platforms": ["platform1"],
    "booking_window": "2-4 weeks in advance",
    "neighborhoods_recommended": ["neighborhood1"],
    "estimated_cost_per_night": "2000-5000",
    "money_saving_tips": ["tip1"]
  },
  "activity_booking_strategy": {
    "advance_booking_required": ["activity1"],
    "book_on_site": ["activity2"],
    "estimated_daily_activity_cost": "2000-3000"
  },
  "logistics_planning": {
    "visa_requirements": {
      "required": false,
      "processing_time": "N/A"
    },
    "travel_insurance": {
      "recommended": true,
      "estimated_cost": "500-1000"
    },
    "vaccinations": {
      "recommended": ["Routine vaccines"]
    }
  },
  "packing_checklist": {
    "essentials": ["item1"],
    "by_activity": {"activity": ["item1"]}
  },
  "pre_departure_checklist": {
    "one_month_before": ["Book flights"],
    "one_week_before": ["Arrange transport"]
  },
  "money_saving_tips_summary": ["tip1", "tip2"],
  "emergency_contingency_plans": {
    "missed_flight": "Contact airline immediately",
    "medical_emergency": "Contact local hospital"
  }
}
```

---

#### Stage 4: Result Compilation & Output (Purple & Teal - Formatting)

```
Compile All Results (Merge all outputs into final state)
         ↓
Format Travel Plan Output State (62 fields)
         ↓
Generate Streamlit UI Display (7 tabs)
         ↓
Flow Complete
```

**Final State Structure (62 Fields):**
- Input Fields (7)
- Derived Fields (5)
- Budget Allocation ML Outputs (8)
- Decision Node Outputs (2)
- Accommodation Recommender Outputs (7)
- Itinerary Generator Outputs (11)
- Local Insights Outputs (9)
- Booking Strategy Outputs (10)
- System Metadata (5)

**Streamlit UI Tabs:**
1. **Overview:** Trip metrics + accommodation summary
2. **Budget:** Bar chart + percentages + amounts
3. **Accommodation:** Primary recommendation + alternatives
4. **Itinerary:** Expandable days + highlights + tips + contingency
5. **Local Insights:** Hidden gems + food spots + neighborhoods
6. **Booking Strategy:** Flight/accommodation/activity strategies + visa + checklists
7. **Model Evaluation:** ML model performance metrics

---

## Key Communication Patterns

### 1. Sequential Flow
```
Input Parser → Input Normalizer → Budget Allocator → Router
```
Each node passes modified state to next node

### 2. Conditional Routing
```
Budget Feasibility Router (Pure Logic)
     ↓
[Selects ONE of 3 paths based on daily_budget_tier]
```

### 3. Parallel Merge
```
Low Accommodation Path    ┐
Mid Accommodation Path    ├─→ Trip Complexity Analyzer (Convergence)
High Accommodation Path   ┘
```
Uses merge_accommodations reducer to combine outputs

### 4. Validation Loop
```
Itinerary Generator → Validator → [If needed] Reviser
```
Max revisions determined by complexity_score

### 5. Adaptive Prompting
```
Local Insights Agent adjusts prompt based on accommodation_type:
├── Luxury → Premium focus
├── Budget → Cost-saving focus
└── Mid-range → Balanced approach
```

### 6. State Threading
```
Central TravelPlanState object flows through all 12 nodes
- Input nodes add: destination_cost_tier, accommodation_preference
- ML nodes add: budget percentages, accommodation details, complexity_score
- LLM nodes add: itinerary, insights, booking strategy
- Final state contains all 62 fields
```

### 7. Temperature Tuning
```
- Input/Normalizer: N/A (pure logic)
- Budget Allocator: N/A (ML model)
- Complexity Analyzer: N/A (pure logic)
- Itinerary Generator: 0.7 (balanced)
- Itinerary Validator: 0.5 (factual)
- Itinerary Reviser: 0.7 (creative)
- Local Insights: 0.8 (creative)
- Booking Strategy: 0.6 (factual)
```

---

## Error Handling Paths (Red Dashed Lines)

All errors are captured in `state.error_messages` and `state.error_occurred` flag:

| Error Path | Condition | Recovery |
|---|---|---|
| **Validation Failed** | Input validation fails | End flow, return errors |
| **Budget Failed** | Budget allocation fails | End flow, return errors |
| **Accommodation Failed** | Accommodation selection fails | End flow, return errors |
| **Itinerary Failed** | Itinerary generation fails | End flow, return errors |
| **Validation Error** | Itinerary validation fails critically | End flow, return errors |
| **Insights Failed** | Local insights generation fails | End flow, return errors |
| **Strategy Failed** | Booking strategy generation fails | End flow, return errors |

---

## Summary Statistics

### Agents & Nodes

| Component | Type | Technology | Count |
|---|---|---|---|
| **ML Agents** | Regression | RandomForest | 1 |
| **ML Agents** | Classification | RandomForest | 1 |
| **LLM Agents** | Generative | Gemini 2.5-flash | 3 |
| **Processing Nodes** | Logic | Python | 12 |
| **Parallel Paths** | Routing | LangGraph | 3 |
| **Decision Routers** | Conditional | Pure Logic | 2 |

### Data Flow

| Metric | Value |
|---|---|
| **Input Features (Budget)** | 9 |
| **Output Features (Budget)** | 6 percentages + 4 derived |
| **Input Features (Accommodation)** | 9 |
| **Output Classes (Accommodation)** | 4 (Budget, Mid-range, Luxury, Alternative) |
| **Final State Fields** | 62 |
| **LLM Temperature Range** | 0.5 - 0.8 |
| **Max Itinerary Revisions** | 1 or 2 (based on complexity) |
| **Accommodation Confidence Threshold** | > 10% (for alternatives) |

### Temperature Strategy

```
Validation Task:        0.5  ← Factual, scoring
Booking/Logistics:      0.6  ← Deterministic information
Itinerary Generation:   0.7  ← Balanced creativity + structure
Itinerary Revision:     0.7  ← Creative improvement with constraints
Local Insights:         0.8  ← Creative, exploratory content
```

---

## Workflow Execution Timeline

```
Total Typical Execution: 22-40 seconds

Input Processing:           0.05 seconds
Budget Allocation (ML):      0.3 seconds
Accommodation (3 paths):     0.75 seconds (parallel)
Trip Complexity Analysis:    0.05 seconds
Itinerary Generation (LLM):  8-12 seconds
Itinerary Validation (LLM):  3-5 seconds
Itinerary Revision (if needed): 3-5 seconds
Local Insights (LLM):        5-8 seconds
Booking Strategy (LLM):      5-8 seconds
─────────────────────────────────
Total:                      22-40 seconds
```

---

## Document Version

- **Created:** December 2024
- **YatraAI Version:** 1.0
- **Flow Type:** Agent-to-Agent Communication
- **Total Components:** 12 nodes + 5 agents
- **State Fields:** 62
- **Diagram Type:** Mermaid

