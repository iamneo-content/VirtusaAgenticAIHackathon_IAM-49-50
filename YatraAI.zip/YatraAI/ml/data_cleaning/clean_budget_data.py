"""Clean budget allocation training data."""

import pandas as pd
from typing import Dict, Any, Tuple


def clean_budget_data(input_file: str, output_file: str) -> Dict[str, Any]:
    """
    Clean budget allocation dataset and save processed version.

    Handles missing values, validates percentage constraints.
    """
    try:
        # Load raw data
        df = pd.read_csv(input_file)
        original_rows = len(df)

        # Handle missing values
        # Fill categorical columns with mode
        categorical_cols = ["destination", "primary_interest", "secondary_interest",
                          "accommodation_preference", "travel_season", "transport_mode"]
        for col in categorical_cols:
            if col in df.columns and df[col].isnull().any():
                mode_val = df[col].mode()[0] if not df[col].mode().empty else "Unknown"
                df = df.copy()
                df[col] = df[col].fillna(mode_val)

        # Validate percentage constraints
        percentage_cols = [
            "accommodation_budget_pct",
            "food_dining_budget_pct",
            "activities_attractions_budget_pct",
            "local_transport_budget_pct",
            "shopping_misc_budget_pct",
            "contingency_budget_pct",
        ]

        # Check percentage sum
        pct_sums = df[percentage_cols].sum(axis=1)
        valid_rows = (pct_sums >= 99.9) & (pct_sums <= 100.1)
        df_cleaned = df[valid_rows].copy()

        # Save cleaned data
        df_cleaned.to_csv(output_file, index=False)
        cleaned_rows = len(df_cleaned)

        return {
            "status": "success",
            "original_rows": original_rows,
            "cleaned_rows": cleaned_rows,
            "rows_removed": original_rows - cleaned_rows,
            "reason_for_removal": "Invalid percentage sums",
            "output_file": output_file,
        }

    except Exception as e:
        return {
            "status": "error",
            "error_message": str(e),
        }
