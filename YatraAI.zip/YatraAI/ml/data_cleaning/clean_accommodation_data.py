"""Clean accommodation recommender training data."""

import pandas as pd
from typing import Dict, Any


def clean_accommodation_data(input_file: str, output_file: str) -> Dict[str, Any]:
    """
    Clean accommodation recommender dataset and save processed version.

    Handles missing values, validates class distribution.
    """
    try:
        # Load raw data
        df = pd.read_csv(input_file)
        original_rows = len(df)

        # Handle missing values
        categorical_cols = ["destination", "primary_interest", "travel_season"]
        for col in categorical_cols:
            if col in df.columns and df[col].isnull().any():
                mode_val = df[col].mode()[0] if not df[col].mode().empty else "Unknown"
                df = df.copy()
                df[col] = df[col].fillna(mode_val)

        # Validate accommodation_type (0-3)
        if "accommodation_type" in df.columns:
            df_cleaned = df[df["accommodation_type"].isin([0, 1, 2, 3])].copy()
        else:
            df_cleaned = df.copy()

        # Save cleaned data
        df_cleaned.to_csv(output_file, index=False)
        cleaned_rows = len(df_cleaned)

        # Class distribution
        class_distribution = {}
        if "accommodation_type" in df_cleaned.columns:
            class_distribution = df_cleaned["accommodation_type"].value_counts().to_dict()

        return {
            "status": "success",
            "original_rows": original_rows,
            "cleaned_rows": cleaned_rows,
            "rows_removed": original_rows - cleaned_rows,
            "class_distribution": class_distribution,
            "output_file": output_file,
        }

    except Exception as e:
        return {
            "status": "error",
            "error_message": str(e),
        }
