"""Evaluate trained ML models."""

import pandas as pd
import numpy as np
import pickle
import os
import sys
from pathlib import Path
from typing import Dict, Any
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import (
    r2_score, mean_squared_error, mean_absolute_error,
    mean_absolute_percentage_error,
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report
)


def evaluate_all_models(project_root: str = None) -> Dict[str, Any]:
    """
    Evaluate all trained ML models on their respective evaluation datasets.

    This function is called from main.py to generate evaluation metrics for display.

    Args:
        project_root: Root directory of YatraAI project (default: current working directory)

    Returns:
        Dictionary with evaluation results for both models
    """
    if project_root is None:
        project_root = str(Path.cwd())

    project_path = Path(project_root)

    eval_data_dir = str(project_path / "data" / "evaluation_dataset")
    model_dir = str(project_path / "ml" / "models")

    return evaluate_models(eval_data_dir, model_dir)


def evaluate_models(eval_data_dir: str, model_dir: str) -> Dict[str, Any]:
    """
    Evaluate both trained models on evaluation dataset.

    Loads test data, loads models, generates metrics.
    """
    try:
        # Load evaluation datasets
        budget_eval_file = os.path.join(eval_data_dir, "budget_allocation_evaluation.csv")
        accommodation_eval_file = os.path.join(eval_data_dir, "accommodation_recommender_evaluation.csv")

        budget_df = pd.read_csv(budget_eval_file)
        accommodation_df = pd.read_csv(accommodation_eval_file)

        # Load Budget Allocator model
        with open(os.path.join(model_dir, "budget_allocator_model.pkl"), "rb") as f:
            budget_model = pickle.load(f)
        with open(os.path.join(model_dir, "budget_allocator_scaler.pkl"), "rb") as f:
            budget_scaler = pickle.load(f)

        # Load Accommodation Recommender model
        with open(os.path.join(model_dir, "accommodation_recommender_model.pkl"), "rb") as f:
            accommodation_model = pickle.load(f)
        with open(os.path.join(model_dir, "accommodation_recommender_scaler.pkl"), "rb") as f:
            accommodation_scaler = pickle.load(f)

        # Evaluate Budget Allocator
        feature_cols_budget = [
            "destination",
            "trip_duration_days",
            "total_budget_inr",
            "group_size",
            "primary_interest",
            "secondary_interest",
            "accommodation_preference",
            "travel_season",
            "destination_cost_tier",
        ]

        target_cols_budget = [
            "accommodation_budget_pct",
            "food_dining_budget_pct",
            "activities_attractions_budget_pct",
            "local_transport_budget_pct",
            "shopping_misc_budget_pct",
            "contingency_budget_pct",
        ]

        X_budget = budget_df[feature_cols_budget].copy()
        y_budget = budget_df[target_cols_budget].copy()

        # Encode categorical features
        categorical_features = ["destination", "primary_interest", "secondary_interest",
                               "accommodation_preference", "travel_season", "destination_cost_tier"]
        label_encoder = LabelEncoder()
        for col in categorical_features:
            if col in X_budget.columns:
                X_budget[col] = label_encoder.fit_transform(X_budget[col].astype(str))

        X_budget_scaled = budget_scaler.transform(X_budget)
        budget_predictions = budget_model.predict(X_budget_scaled)

        # Clip and normalize predictions to ensure valid percentages
        budget_predictions_clipped = np.clip(budget_predictions, 0, 100)
        budget_predictions_normalized = budget_predictions_clipped / budget_predictions_clipped.sum(axis=1, keepdims=True) * 100

        # Use MAPE (Mean Absolute Percentage Error) instead of R² for percentage predictions
        # R² is problematic for multi-output percentage regression, MAPE is more interpretable
        budget_mape = mean_absolute_percentage_error(y_budget, budget_predictions_normalized)
        budget_rmse = np.sqrt(mean_squared_error(y_budget, budget_predictions_normalized))
        budget_mae = mean_absolute_error(y_budget, budget_predictions_normalized)

        # Evaluate Accommodation Recommender
        feature_cols_accom = [
            "destination",
            "total_trip_budget_inr",
            "accommodation_budget_inr",
            "trip_duration_days",
            "group_size",
            "primary_interest",
            "travel_season",
            "destination_cost_tier",
            "is_group_trip",
        ]

        target_col_accom = "accommodation_type"

        X_accom = accommodation_df[feature_cols_accom].copy()
        y_accom = accommodation_df[target_col_accom].copy()

        # Encode categorical features
        for col in ["destination", "primary_interest", "travel_season", "destination_cost_tier"]:
            if col in X_accom.columns:
                X_accom[col] = label_encoder.fit_transform(X_accom[col].astype(str))

        if "is_group_trip" in X_accom.columns:
            X_accom["is_group_trip"] = X_accom["is_group_trip"].astype(int)

        X_accom_scaled = accommodation_scaler.transform(X_accom)
        accommodation_predictions = accommodation_model.predict(X_accom_scaled)

        accom_accuracy = accuracy_score(y_accom, accommodation_predictions)
        accom_precision = precision_score(y_accom, accommodation_predictions, average="weighted", zero_division=0)
        accom_recall = recall_score(y_accom, accommodation_predictions, average="weighted", zero_division=0)
        accom_f1 = f1_score(y_accom, accommodation_predictions, average="weighted", zero_division=0)

        return {
            "status": "success",
            "budget_allocator": {
                "mape": float(budget_mape),
                "rmse": float(budget_rmse),
                "mae": float(budget_mae),
                "samples": len(X_budget),
            },
            "accommodation_recommender": {
                "accuracy": float(accom_accuracy),
                "precision": float(accom_precision),
                "recall": float(accom_recall),
                "f1_score": float(accom_f1),
                "samples": len(X_accom),
            },
        }

    except Exception as e:
        return {
            "status": "error",
            "error_message": str(e),
        }
