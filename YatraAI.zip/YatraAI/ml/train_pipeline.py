"""Main ML training orchestrator."""

from typing import Dict, Any
import sys
from pathlib import Path

# Add parent directory to path when run as a script
if __name__ == "__main__":
    sys.path.insert(0, str(Path(__file__).parent.parent))

try:
    from ml.data_cleaning import clean_budget_data, clean_accommodation_data
    from ml.train_model import train_budget_allocator, train_accommodation_recommender
except ImportError:
    from .data_cleaning import clean_budget_data, clean_accommodation_data
    from .train_model import train_budget_allocator, train_accommodation_recommender


def train_pipeline(data_dir: str = "data", model_dir: str = "ml/models") -> Dict[str, Any]:
    """
    Execute complete ML training pipeline.

    Steps:
    1. Clean budget data
    2. Clean accommodation data
    3. Train budget allocator
    4. Train accommodation recommender

    Note: Model evaluation is handled separately in main.py via evaluate_all_models()
    """
    results = {}

    # Step 1: Clean budget data
    print("Cleaning budget allocation data...")
    clean_budget_result = clean_budget_data(
        f"{data_dir}/training_dataset/budget_allocation_training.csv",
        f"{data_dir}/processed/budget_allocation_clean.csv"
    )
    results["clean_budget"] = clean_budget_result

    # Step 2: Clean accommodation data
    print("Cleaning accommodation recommender data...")
    clean_accom_result = clean_accommodation_data(
        f"{data_dir}/training_dataset/accommodation_recommender_training.csv",
        f"{data_dir}/processed/accommodation_recommender_clean.csv"
    )
    results["clean_accommodation"] = clean_accom_result

    # Step 3: Train budget allocator
    print("Training budget allocator model...")
    train_budget_result = train_budget_allocator(
        f"{data_dir}/processed/budget_allocation_clean.csv",
        model_dir
    )
    results["train_budget"] = train_budget_result

    # Step 4: Train accommodation recommender
    print("Training accommodation recommender model...")
    train_accom_result = train_accommodation_recommender(
        f"{data_dir}/processed/accommodation_recommender_clean.csv",
        model_dir
    )
    results["train_accommodation"] = train_accom_result

    return {
        "status": "success" if all(r.get("status") == "success" for r in results.values() if isinstance(r, dict)) else "error",
        "steps": results,
    }


if __name__ == "__main__":
    import json
    result = train_pipeline()
    print(json.dumps(result, indent=2))
