"""Train Accommodation Recommender ML model."""

import pandas as pd
import numpy as np
import pickle
import os
from typing import Dict, Any
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report


def train_accommodation_recommender(data_file: str, model_dir: str) -> Dict[str, Any]:
    """
    Train Accommodation Recommender RandomForest Classifier model.

    Loads cleaned data, trains model, saves model + scaler + encoder.
    """
    try:
        # Load cleaned data
        df = pd.read_csv(data_file)

        # Define features and target
        feature_cols = [
            "destination",
            "total_trip_budget_inr",
            "accommodation_budget_inr",
            "trip_duration_days",
            "group_size",
            "primary_interest",
            "travel_season",
            "destination_cost_tier",
            "is_group_trip",
        ]

        target_col = "accommodation_type"

        # Separate features and target
        X = df[feature_cols].copy()
        y = df[target_col].copy()

        # Encode categorical features
        label_encoder = LabelEncoder()
        categorical_features = ["destination", "primary_interest", "travel_season", "destination_cost_tier"]

        for col in categorical_features:
            if col in X.columns:
                X[col] = label_encoder.fit_transform(X[col].astype(str))

        # Convert boolean columns to int
        if "is_group_trip" in X.columns:
            X["is_group_trip"] = X["is_group_trip"].astype(int)

        # Scale numerical features
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)

        # Train RandomForest Classifier
        model = RandomForestClassifier(
            n_estimators=100,
            max_depth=10,
            min_samples_split=5,
            min_samples_leaf=2,
            random_state=42,
            class_weight="balanced",
            n_jobs=-1,
        )

        model.fit(X_scaled, y)

        # Evaluate on training set
        train_predictions = model.predict(X_scaled)
        train_accuracy = accuracy_score(y, train_predictions)
        train_f1 = f1_score(y, train_predictions, average="weighted")

        # Create model directory if it doesn't exist
        os.makedirs(model_dir, exist_ok=True)

        # Save model and preprocessors
        with open(os.path.join(model_dir, "accommodation_recommender_model.pkl"), "wb") as f:
            pickle.dump(model, f)

        with open(os.path.join(model_dir, "accommodation_recommender_scaler.pkl"), "wb") as f:
            pickle.dump(scaler, f)

        with open(os.path.join(model_dir, "accommodation_recommender_encoder.pkl"), "wb") as f:
            pickle.dump(label_encoder, f)

        return {
            "status": "success",
            "model_type": "RandomForestClassifier",
            "n_estimators": 100,
            "training_samples": len(X),
            "features": len(feature_cols),
            "classes": len(np.unique(y)),
            "train_accuracy": float(train_accuracy),
            "train_f1": float(train_f1),
            "model_saved": os.path.join(model_dir, "accommodation_recommender_model.pkl"),
        }

    except Exception as e:
        return {
            "status": "error",
            "error_message": str(e),
        }
