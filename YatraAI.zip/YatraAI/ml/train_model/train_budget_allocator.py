"""Train Budget Allocator ML model."""

import pandas as pd
import numpy as np
import pickle
import os
from typing import Dict, Any
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error


def train_budget_allocator(data_file: str, model_dir: str) -> Dict[str, Any]:
    """
    Train Budget Allocator RandomForest Regressor model.

    Loads cleaned data, trains model, saves model + scaler + encoder.
    """
    try:
        # Load cleaned data
        df = pd.read_csv(data_file)

        # Define features and targets
        feature_cols = [
            "destination",
            "trip_duration_days",
            "total_budget_inr",
            "group_size",
            "primary_interest",
            "secondary_interest",
            "accommodation_preference",
            "travel_season",
            "destination_cost_tier",
        ]

        target_cols = [
            "accommodation_budget_pct",
            "food_dining_budget_pct",
            "activities_attractions_budget_pct",
            "local_transport_budget_pct",
            "shopping_misc_budget_pct",
            "contingency_budget_pct",
        ]

        # Separate features and targets
        X = df[feature_cols].copy()
        y = df[target_cols].copy()

        # Encode categorical features
        label_encoder = LabelEncoder()
        categorical_features = ["destination", "primary_interest", "secondary_interest",
                               "accommodation_preference", "travel_season", "destination_cost_tier"]

        for col in categorical_features:
            if col in X.columns:
                X[col] = label_encoder.fit_transform(X[col].astype(str))

        # Scale numerical features
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)

        # Train RandomForest Regressor
        model = RandomForestRegressor(
            n_estimators=100,
            max_depth=10,
            min_samples_split=5,
            min_samples_leaf=2,
            random_state=42,
            n_jobs=-1,
        )

        model.fit(X_scaled, y)

        # Evaluate on training set (for logging purposes)
        train_predictions = model.predict(X_scaled)
        train_r2 = r2_score(y, train_predictions)
        train_rmse = np.sqrt(mean_squared_error(y, train_predictions))

        # Create model directory if it doesn't exist
        os.makedirs(model_dir, exist_ok=True)

        # Save model and preprocessors
        with open(os.path.join(model_dir, "budget_allocator_model.pkl"), "wb") as f:
            pickle.dump(model, f)

        with open(os.path.join(model_dir, "budget_allocator_scaler.pkl"), "wb") as f:
            pickle.dump(scaler, f)

        with open(os.path.join(model_dir, "budget_allocator_encoder.pkl"), "wb") as f:
            pickle.dump(label_encoder, f)

        return {
            "status": "success",
            "model_type": "RandomForestRegressor",
            "n_estimators": 100,
            "training_samples": len(X),
            "features": len(feature_cols),
            "targets": len(target_cols),
            "train_r2": float(train_r2),
            "train_rmse": float(train_rmse),
            "model_saved": os.path.join(model_dir, "budget_allocator_model.pkl"),
        }

    except Exception as e:
        return {
            "status": "error",
            "error_message": str(e),
        }
