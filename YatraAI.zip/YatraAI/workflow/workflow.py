"""LangGraph workflow definition for YatraAI."""

from langgraph.graph import StateGraph
from state import TravelPlanState
from nodes.input_parser_node import input_parser_node
from nodes.input_normalizer_node import input_normalizer_node
from nodes.budget_allocator_node import budget_allocator_node
from nodes.decision_router_nodes import budget_feasibility_router, trip_complexity_analyzer
from nodes.accommodation_recommender_node import (
    accommodation_recommender_low_budget_node,
    accommodation_recommender_mid_budget_node,
    accommodation_recommender_high_budget_node,
)
from nodes.itinerary_generator_node import itinerary_generator_node
from nodes.itinerary_revision_node import itinerary_validator_and_reviser_node
from nodes.local_insights_node import local_insights_node
from nodes.booking_strategy_node import booking_strategy_node


def build_trip_planning_graph():
    """Build LangGraph state machine for trip planning with decision routers.

    Note: LangGraph's default state channel uses LastValue which only allows one
    update per step. Broadcasting to multiple nodes causes conflicts. Instead,
    we use conditional routing to select the appropriate path, preserving the
    decision-driven architecture while avoiding concurrent state updates.
    """
    graph = StateGraph(TravelPlanState)

    # Stage 1: Input Processing (Sequential)
    graph.add_node("input_parser", input_parser_node)
    graph.add_node("input_normalizer", input_normalizer_node)

    # Stage 2: Budget Allocation (Sequential)
    graph.add_node("budget_allocator", budget_allocator_node)

    # Stage 3: Decision Node 1 - Budget Feasibility Router (Pure Logic)
    graph.add_node("budget_feasibility_router", budget_feasibility_router)

    # Stage 4: Accommodation Paths (selected by router, executed sequentially)
    graph.add_node("accommodation_recommender_low_budget", accommodation_recommender_low_budget_node)
    graph.add_node("accommodation_recommender_mid_budget", accommodation_recommender_mid_budget_node)
    graph.add_node("accommodation_recommender_high_budget", accommodation_recommender_high_budget_node)

    # Stage 5: Decision Node 2 - Trip Complexity Analyzer (Pure Logic)
    graph.add_node("trip_complexity_analyzer", trip_complexity_analyzer)

    # Stage 6: Itinerary Generation and Validation
    graph.add_node("itinerary_generator", itinerary_generator_node)
    graph.add_node("itinerary_validator_and_reviser", itinerary_validator_and_reviser_node)

    # Stage 7: LLM Agents (executed sequentially but designed for parallel)
    graph.add_node("local_insights", local_insights_node)
    graph.add_node("booking_strategy", booking_strategy_node)

    # Set entry point
    graph.set_entry_point("input_parser")

    # Stage 1: Sequential input processing
    graph.add_edge("input_parser", "input_normalizer")
    graph.add_edge("input_normalizer", "budget_allocator")

    # Stage 2→3: Budget allocation to decision router
    graph.add_edge("budget_allocator", "budget_feasibility_router")

    # Stage 3→4: Conditional routing based on budget tier
    def route_by_budget(state: TravelPlanState) -> str:
        """Route to appropriate accommodation path based on budget tier label."""
        return state.get("daily_budget_tier", "mid_budget_path")

    graph.add_conditional_edges(
        "budget_feasibility_router",
        route_by_budget,
        {
            "low_budget_path": "accommodation_recommender_low_budget",
            "mid_budget_path": "accommodation_recommender_mid_budget",
            "high_budget_path": "accommodation_recommender_high_budget",
        }
    )

    # Stage 4→5: All accommodation paths converge to complexity analyzer
    graph.add_edge("accommodation_recommender_low_budget", "trip_complexity_analyzer")
    graph.add_edge("accommodation_recommender_mid_budget", "trip_complexity_analyzer")
    graph.add_edge("accommodation_recommender_high_budget", "trip_complexity_analyzer")

    # Stage 5→6: Complexity analyzer to itinerary generation
    graph.add_edge("trip_complexity_analyzer", "itinerary_generator")

    # Stage 6→6: Itinerary validation/revision
    graph.add_edge("itinerary_generator", "itinerary_validator_and_reviser")

    # Stage 6→7: Itinerary revision to LLM agents (sequential to avoid state conflicts)
    graph.add_edge("itinerary_validator_and_reviser", "local_insights")
    graph.add_edge("local_insights", "booking_strategy")

    # Set finish point
    graph.set_finish_point("booking_strategy")

    return graph.compile()


def get_workflow_structure():
    """Return workflow structure information."""
    return {
        "nodes": [
            "input_parser",
            "input_normalizer",
            "budget_allocator",
            "budget_feasibility_router",
            "accommodation_recommender_low_budget",
            "accommodation_recommender_mid_budget",
            "accommodation_recommender_high_budget",
            "trip_complexity_analyzer",
            "itinerary_generator",
            "itinerary_validator_and_reviser",
            "local_insights",
            "booking_strategy",
        ],
        "workflow": "Sequential -> Decision Router -> Parallel (3x Accommodation) -> Complexity Analyzer -> Itinerary -> Validate/Revise -> Parallel (2x LLM)",
        "description": "YatraAI travel planning workflow with decision nodes, parallel branches, ML and LLM agents",
    }
