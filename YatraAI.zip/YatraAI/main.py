"""Streamlit application for YatraAI - Professional UI."""

import streamlit as st
from datetime import datetime
from graph import plan_trip, get_trip_summary
from ml.evaluation.evaluate_models import evaluate_all_models
from utils.constants import (
    DESTINATIONS, INTERESTS, SECONDARY_INTERESTS, TRAVEL_SEASONS,
    BUDGET_MIN, BUDGET_MAX, BUDGET_STEP, BUDGET_DEFAULT,
    TRIP_DURATION_MIN, TRIP_DURATION_MAX, TRIP_DURATION_DEFAULT,
    GROUP_SIZE_MIN, GROUP_SIZE_MAX, GROUP_SIZE_DEFAULT,
)


def initialize_session_state():
    """Initialize Streamlit session state variables."""
    if "assessment_result" not in st.session_state:
        st.session_state.assessment_result = None
    if "eval_results" not in st.session_state:
        st.session_state.eval_results = None


def setup_page():
    """Configure page layout and styling."""
    st.set_page_config(
        page_title="YatraAI - Travel Itinerary Optimizer",
        page_icon="",
        layout="wide",
        initial_sidebar_state="expanded"
    )

    st.markdown("""
    <style>
        .main {
            padding: 2rem;
        }
        .stTabs [data-baseweb="tab-list"] button [data-testid="stMarkdownContainer"] p {
            font-size: 1.1rem;
        }
        .metric-box {
            background-color: #f0f2f6;
            padding: 1.5rem;
            border-radius: 0.5rem;
            border-left: 4px solid #0066cc;
        }
        h1 {
            color: #0066cc;
            padding-bottom: 1rem;
            border-bottom: 2px solid #0066cc;
        }
        h2 {
            color: #0066cc;
            margin-top: 2rem;
        }
    </style>
    """, unsafe_allow_html=True)


def display_input_form():
    """Display user input form in sidebar."""
    with st.sidebar:
        st.header("Trip Details")

        destination = st.selectbox(
            "Destination",
            DESTINATIONS,
            help="Select your travel destination"
        )

        trip_duration = st.slider(
            "Trip Duration (days)",
            min_value=TRIP_DURATION_MIN,
            max_value=TRIP_DURATION_MAX,
            value=TRIP_DURATION_DEFAULT,
            help="How many days do you plan to travel?"
        )

        total_budget = st.number_input(
            "Total Budget (Rs)",
            min_value=BUDGET_MIN,
            max_value=BUDGET_MAX,
            value=BUDGET_DEFAULT,
            step=BUDGET_STEP,
            help="Total budget in Indian Rupees"
        )

        group_size = st.slider(
            "Group Size",
            min_value=GROUP_SIZE_MIN,
            max_value=GROUP_SIZE_MAX,
            value=GROUP_SIZE_DEFAULT,
            help="How many people are traveling?"
        )

        primary_interest = st.selectbox(
            "Primary Interest",
            INTERESTS,
            help="What is your main interest?"
        )

        secondary_interest = st.selectbox(
            "Secondary Interest",
            SECONDARY_INTERESTS,
            help="Any secondary interests?"
        )

        travel_season = st.selectbox(
            "Travel Season",
            TRAVEL_SEASONS,
            help="When do you plan to travel?"
        )

        return {
            "destination": destination,
            "trip_duration_days": trip_duration,
            "total_budget_inr": total_budget,
            "group_size": group_size,
            "primary_interest": primary_interest,
            "secondary_interest": secondary_interest if secondary_interest != "None" else "",
            "travel_season": travel_season,
        }


def display_overview_tab(assessment):
    """Display overview tab with assessment summary."""
    st.header("Trip Overview")

    col1, col2, col3, col4 = st.columns(4)

    with col1:
        st.metric("Destination", assessment.get("destination", "N/A"))

    with col2:
        st.metric("Duration", f"{assessment.get('trip_duration_days', 0)} days")

    with col3:
        st.metric("Total Budget", f"Rs {assessment.get('total_budget_inr', 0):,}")

    with col4:
        st.metric("Group Size", f"{assessment.get('group_size', 0)} people")

    st.divider()

    col1, col2 = st.columns(2)

    with col1:
        st.subheader("Trip Preferences")
        st.write(f"Primary Interest: {assessment.get('primary_interest', 'N/A')}")
        st.write(f"Secondary Interest: {assessment.get('secondary_interest', 'N/A')}")
        st.write(f"Travel Season: {assessment.get('travel_season', 'N/A')}")

    with col2:
        st.subheader("Accommodation")
        st.write(f"Type: {assessment.get('accommodation_type', 'N/A')}")
        st.write(f"Confidence: {float(assessment.get('accommodation_confidence', 0) or 0):.1f}%")
        st.write(f"Est. Cost/Night: Rs {float(assessment.get('estimated_cost_per_night', 0) or 0):.0f}")


def display_budget_tab(assessment):
    """Display budget breakdown tab."""
    st.header("Budget Breakdown")

    budget_data = {
        "Accommodation": assessment.get("accommodation_budget_pct", 0),
        "Food & Dining": assessment.get("food_dining_budget_pct", 0),
        "Activities": assessment.get("activities_attractions_budget_pct", 0),
        "Transport": assessment.get("local_transport_budget_pct", 0),
        "Shopping": assessment.get("shopping_misc_budget_pct", 0),
        "Contingency": assessment.get("contingency_budget_pct", 0),
    }

    # Display as bar chart
    st.bar_chart(budget_data)

    st.divider()

    col1, col2 = st.columns(2)

    with col1:
        st.subheader("Budget Percentages")
        for category, percentage in budget_data.items():
            st.write(f"{category}: {percentage:.1f}%")

    with col2:
        st.subheader("Absolute Amounts")
        total_budget = assessment.get("total_budget_inr", 0)
        budget_allocation = assessment.get("budget_allocation", {})
        for category, amount in budget_allocation.items():
            st.write(f"{category.replace('_', ' ').title()}: Rs {amount:,.0f}")

    st.divider()
    st.info(f"Daily Budget: Rs {float(assessment.get('daily_budget', 0) or 0):.0f}")


def display_accommodation_tab(assessment):
    """Display accommodation details tab."""
    st.header("Accommodation Details")

    col1, col2 = st.columns(2)

    with col1:
        st.subheader("Recommended Accommodation")
        st.metric("Type", assessment.get("accommodation_type", "N/A"))
        st.metric("Confidence", f"{float(assessment.get('accommodation_confidence', 0) or 0):.1f}%")
        st.metric("Comfort Score", f"{float(assessment.get('accommodation_comfort_score', 0) or 0):.0f}/100")
        st.metric("Est. Cost/Night", f"Rs {float(assessment.get('estimated_cost_per_night', 0) or 0):.0f}")

    with col2:
        st.subheader("Recommendation Details")
        st.write("Based on your trip parameters (destination, budget, duration, interests, and travel season), the ML model recommends:")
        st.write(f"**{assessment.get('accommodation_type', 'N/A')}**")

    st.divider()

    alternatives = assessment.get("accommodation_alternatives", [])
    if alternatives:
        st.subheader("Alternative Options")
        for alt in alternatives:
            with st.expander(f"{alt.get('type', 'N/A')} - {float(alt.get('confidence', 0) or 0):.1f}% confidence"):
                st.write(f"Est. Cost/Night: Rs {float(alt.get('estimated_cost_per_night', 0) or 0):.0f}")


def display_itinerary_tab(assessment):
    """Display day-by-day itinerary tab."""
    st.header("Day-by-Day Itinerary")

    itinerary = assessment.get("itinerary", {})

    if not itinerary:
        st.info("Generating itinerary... Please wait.")
        return

    for day_key in sorted([k for k in itinerary.keys() if k.startswith("day_")]):
        day_data = itinerary[day_key]
        with st.expander(f"Day {day_key.split('_')[1]} - {day_data.get('title', 'Day')}"):
            activities = day_data.get("activities", [])
            if activities:
                for i, activity in enumerate(activities, 1):
                    st.write(f"{i}. {activity}")

            estimated_cost = day_data.get("estimated_cost", 0)
            st.divider()
            st.write(f"**Estimated Cost for Day: Rs {float(estimated_cost or 0):.0f}**")

    if assessment.get("trip_highlights"):
        st.subheader("Trip Highlights")
        for highlight in assessment.get("trip_highlights", []):
            st.write(f"- {highlight}")

    if assessment.get("itinerary_tips"):
        st.divider()
        st.subheader("Tips for Success")
        for tip in assessment.get("itinerary_tips", []):
            st.write(f"- {tip}")

    if assessment.get("contingency_plans"):
        st.divider()
        st.subheader("Contingency Plans")
        for plan in assessment.get("contingency_plans", []):
            st.write(f"- {plan}")


def display_insights_tab(assessment):
    """Display local insights tab."""
    st.header("Local Insights & Hidden Gems")

    col1, col2 = st.columns(2)

    with col1:
        st.subheader("Hidden Gems")
        gems = assessment.get("hidden_gems", [])
        for gem in gems[:5]:
            with st.expander(gem.get("name", "Gem")):
                st.write(f"Category: {gem.get('category', 'N/A')}")
                st.write(f"Neighborhood: {gem.get('neighborhood', 'N/A')}")
                st.write(gem.get("description", ""))
                st.caption(f"Why Hidden: {gem.get('why_hidden', '')}")

    with col2:
        st.subheader("Local Food Spots")
        food = assessment.get("local_food_spots", [])
        for spot in food[:5]:
            with st.expander(spot.get("name", "Restaurant")):
                st.write(f"Cuisine: {spot.get('cuisine', 'N/A')}")
                st.write(f"Price Range: {spot.get('price_range', 'N/A')}")
                st.write(f"Signature Dish: {spot.get('signature_dish', 'N/A')}")

    st.divider()

    col3, col4 = st.columns(2)

    with col3:
        st.subheader("Neighborhoods to Explore")
        neighborhoods = assessment.get("neighborhoods_to_explore", [])
        for neighborhood in neighborhoods:
            with st.expander(neighborhood.get("name", "Neighborhood")):
                st.write(f"Vibe: {neighborhood.get('vibe', 'N/A')}")
                st.write("Things to do:")
                for activity in neighborhood.get("how_to_spend_time", []):
                    st.write(f"- {activity}")

    with col4:
        st.subheader("Free or Cheap Attractions")
        free = assessment.get("free_or_cheap_attractions", [])
        for item in free:
            st.write(f"- {item}")

    st.divider()

    st.subheader("Money Saving Hacks")
    for hack in assessment.get("money_saving_hacks", []):
        st.write(f"- {hack}")

    st.subheader("Things to Avoid")
    for trap in assessment.get("avoid_tourist_traps", []):
        st.write(f"- {trap}")

    best_times = assessment.get("best_times_to_avoid_crowds", {})
    if best_times:
        st.divider()
        st.subheader("Crowd Management")
        if best_times.get("avoid"):
            st.write("**Times to Avoid:**")
            for time in best_times.get("avoid", []):
                st.write(f"- {time}")
        if best_times.get("ideal"):
            st.write("**Ideal Times to Visit:**")
            for time in best_times.get("ideal", []):
                st.write(f"- {time}")


def display_booking_tab(assessment):
    """Display booking strategy tab."""
    st.header("Booking Strategy & Logistics")

    col1, col2 = st.columns(2)

    with col1:
        st.subheader("Flight Booking")
        flight_strat = assessment.get("flight_booking_strategy", {})
        if flight_strat:
            st.write(f"**Booking Window:** {flight_strat.get('booking_window', 'N/A')}")
            st.write(f"**Best Days to Book:** {flight_strat.get('best_days_to_book', 'N/A')}")
            st.write(f"**Est. Cost Range:** {flight_strat.get('estimated_cost_range', 'N/A')}")
            st.write("**Recommended Platforms:**")
            for platform in flight_strat.get("recommended_platforms", []):
                st.write(f"- {platform}")
            st.write("**Money-Saving Tips:**")
            for tip in flight_strat.get("money_saving_tips", []):
                st.write(f"- {tip}")

    with col2:
        st.subheader("Accommodation Booking")
        accom_strat = assessment.get("accommodation_booking_strategy", {})
        if accom_strat:
            st.write(f"**Booking Window:** {accom_strat.get('booking_window', 'N/A')}")
            st.write(f"**Est. Cost/Night:** {accom_strat.get('estimated_cost_per_night', 'N/A')}")
            st.write("**Recommended Platforms:**")
            for platform in accom_strat.get("recommended_platforms", []):
                st.write(f"- {platform}")
            st.write("**Money-Saving Tips:**")
            for tip in accom_strat.get("money_saving_tips", []):
                st.write(f"- {tip}")

    st.divider()

    st.subheader("Activity Booking")
    activity_strat = assessment.get("activity_booking_strategy", {})
    if activity_strat:
        if activity_strat.get("advance_booking_required"):
            st.write("**Advance Booking Required:**")
            for activity in activity_strat.get("advance_booking_required", []):
                st.write(f"- {activity}")
        if activity_strat.get("book_on_site"):
            st.write("**Book On-Site:**")
            for activity in activity_strat.get("book_on_site", []):
                st.write(f"- {activity}")
        if activity_strat.get("estimated_daily_activity_cost"):
            st.info(f"Est. Daily Activity Cost: {activity_strat.get('estimated_daily_activity_cost')}")

    st.divider()

    st.subheader("Visa & Documentation")
    visa = assessment.get("visa_requirements", {})
    if visa:
        required = "Required" if visa.get("required") else "Not Required"
        st.write(f"**Visa:** {required}")
        if visa.get("processing_time"):
            st.write(f"**Processing Time:** {visa.get('processing_time')}")

    st.divider()

    st.subheader("Pre-Departure Checklist")
    for item in assessment.get("booking_checklist", []):
        st.write(f"- {item}")

    packing = assessment.get("packing_checklist", {})
    if packing and packing.get("essentials"):
        st.subheader("Packing Essentials")
        for item in packing.get("essentials", []):
            st.write(f"- {item}")

    st.divider()

    st.subheader("Budget Optimization Tips")
    for tip in assessment.get("budget_optimization_tips", []):
        st.write(f"- {tip}")

    emergency = assessment.get("emergency_contingency_plans", {})
    if emergency:
        st.divider()
        st.subheader("Emergency Contingency Plans")
        for scenario, action in emergency.items():
            with st.expander(scenario.replace("_", " ").title()):
                st.write(action)


def display_model_evaluation_tab():
    """Display pre-trained model evaluation metrics."""
    st.header("Model Evaluation Metrics")
    st.write("Performance metrics of pre-trained machine learning models on evaluation datasets")

    col1, col2 = st.columns([1, 4])

    with col1:
        if st.button("Load Evaluation", key="eval_button", use_container_width=True):
            with st.spinner("Loading evaluation metrics..."):
                eval_results = evaluate_all_models()
                st.session_state.eval_results = eval_results

    with col2:
        if st.session_state.get("eval_results"):
            results = st.session_state.eval_results

            if results.get("status") == "success":
                col1, col2 = st.columns(2)

                with col1:
                    st.subheader("Budget Allocator Model")
                    budget_eval = results.get("budget_allocator", {})
                    st.metric("MAPE (%)", f"{float(budget_eval.get('mape', 0) or 0):.2f}%")
                    st.metric("RMSE", f"{float(budget_eval.get('rmse', 0) or 0):.4f}")
                    st.metric("MAE", f"{float(budget_eval.get('mae', 0) or 0):.4f}")
                    st.write(f"**Test Samples:** {budget_eval.get('samples', 0)}")

                with col2:
                    st.subheader("Accommodation Recommender Model")
                    accom_eval = results.get("accommodation_recommender", {})
                    st.metric("Accuracy", f"{float(accom_eval.get('accuracy', 0) or 0):.4f}")
                    st.metric("Precision", f"{float(accom_eval.get('precision', 0) or 0):.4f}")
                    st.metric("Recall", f"{float(accom_eval.get('recall', 0) or 0):.4f}")
                    st.write(f"**Test Samples:** {accom_eval.get('samples', 0)}")
            else:
                st.error(f"Evaluation failed: {results.get('error_message', 'Unknown error')}")
        else:
            st.info("Click 'Load Evaluation' to view pre-trained model performance metrics.")


def main():
    """Main application."""
    setup_page()
    initialize_session_state()

    st.title("YatraAI: Travel Itinerary & Accommodation Optimizer")
    st.write("Generate personalized travel plans powered by AI and machine learning")

    # Get user input
    user_input = display_input_form()

    # Plan button
    col1, col2, col3 = st.columns([1, 1, 2])

    with col1:
        if st.button("Generate Plan", key="plan_button", use_container_width=True):
            with st.spinner("Generating your personalized travel plan..."):
                result = plan_trip(**user_input)
                st.session_state.assessment_result = result

    with col2:
        if st.button("Clear", key="clear_button", use_container_width=True):
            st.session_state.assessment_result = None
            st.rerun()

    if st.session_state.assessment_result:
        result = st.session_state.assessment_result

        if result.get("error_occurred"):
            st.error("Error generating plan. Please check your inputs and try again.")
            if result.get("error_messages"):
                st.write("Errors:")
                for error in result.get("error_messages"):
                    st.write(f"- {error}")
        else:
            # Create tabs for different views
            tab1, tab2, tab3, tab4, tab5, tab6, tab7 = st.tabs([
                "Overview",
                "Budget",
                "Accommodation",
                "Itinerary",
                "Local Insights",
                "Booking Strategy",
                "Model Evaluation"
            ])

            with tab1:
                display_overview_tab(result)

            with tab2:
                display_budget_tab(result)

            with tab3:
                display_accommodation_tab(result)

            with tab4:
                display_itinerary_tab(result)

            with tab5:
                display_insights_tab(result)

            with tab6:
                display_booking_tab(result)

            with tab7:
                display_model_evaluation_tab()


if __name__ == "__main__":
    main()
