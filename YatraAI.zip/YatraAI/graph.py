"""Main graph execution for YatraAI."""

from datetime import datetime
from typing import Dict, Any
from uuid import uuid4
from workflow.workflow import build_trip_planning_graph, get_workflow_structure
from state import TravelPlanState, get_initial_state


def plan_trip(
    destination: str,
    trip_duration_days: int,
    total_budget_inr: int,
    group_size: int,
    primary_interest: str,
    secondary_interest: str,
    travel_season: str,
) -> Dict[str, Any]:
    """
    Run complete trip planning workflow.

    This is the main entry point for the application.
    """
    # Prepare form data
    form_data = {
        "destination": destination,
        "trip_duration_days": trip_duration_days,
        "total_budget_inr": total_budget_inr,
        "group_size": group_size,
        "primary_interest": primary_interest,
        "secondary_interest": secondary_interest,
        "travel_season": travel_season,
    }

    # Initialize state with form data
    state = get_initial_state(form_data)

    # Add system metadata
    state["plan_id"] = str(uuid4())
    state["analysis_timestamp"] = datetime.now().isoformat()

    # Build and run graph
    graph = build_trip_planning_graph()

    try:
        # Execute workflow
        final_state = graph.invoke(state)
        final_state["plan_generated"] = True
        return final_state

    except Exception as e:
        # Handle workflow execution errors
        state["error_occurred"] = True
        state["error_messages"].append(f"Workflow execution error: {str(e)}")
        state["plan_generated"] = False
        return state


def get_trip_summary(assessment_result: Dict[str, Any]) -> Dict[str, Any]:
    """Extract summary from complete assessment result."""
    summary = {
        "user_profile": {
            "destination": assessment_result.get("destination"),
            "trip_duration": assessment_result.get("trip_duration_days"),
            "total_budget": assessment_result.get("total_budget_inr"),
            "group_size": assessment_result.get("group_size"),
            "primary_interest": assessment_result.get("primary_interest"),
            "secondary_interest": assessment_result.get("secondary_interest"),
            "travel_season": assessment_result.get("travel_season"),
        },
        "budget_summary": {
            "accommodation_pct": assessment_result.get("accommodation_budget_pct"),
            "food_pct": assessment_result.get("food_dining_budget_pct"),
            "activities_pct": assessment_result.get("activities_attractions_budget_pct"),
            "transport_pct": assessment_result.get("local_transport_budget_pct"),
            "shopping_pct": assessment_result.get("shopping_misc_budget_pct"),
            "contingency_pct": assessment_result.get("contingency_budget_pct"),
            "daily_budget": assessment_result.get("daily_budget"),
        },
        "accommodation": {
            "type": assessment_result.get("accommodation_type"),
            "confidence": assessment_result.get("accommodation_confidence"),
            "estimated_cost_per_night": assessment_result.get("estimated_cost_per_night"),
        },
        "itinerary_status": assessment_result.get("itinerary_analysis_complete"),
        "local_insights_status": assessment_result.get("insights_analysis_complete"),
        "booking_strategy_status": assessment_result.get("booking_analysis_complete"),
        "system": {
            "plan_id": assessment_result.get("plan_id"),
            "timestamp": assessment_result.get("analysis_timestamp"),
            "plan_generated": assessment_result.get("plan_generated"),
            "errors": assessment_result.get("error_messages", []),
        },
    }
    return summary


def get_workflow_info() -> Dict[str, Any]:
    """Get information about the workflow."""
    return get_workflow_structure()
