"""Budget Allocator ML Agent - Pure Prediction using RandomForest Regressor."""

import pickle
import os
from typing import Dict, Any
import numpy as np
from sklearn.preprocessing import LabelEncoder
from utils.constants import (
    DESTINATION_ENCODING,
    SEASON_ENCODING,
    ACCOMMODATION_PREFERENCE_ENCODING,
    COST_TIER_ENCODING,
    INTEREST_ENCODING,
)


class BudgetAllocatorMLAgent:
    """Allocates trip budget using trained RandomForest Regressor model."""

    def __init__(self, model_dir: str = "ml/models"):
        """Load trained model and preprocessors from disk."""
        model_path = os.path.join(model_dir, "budget_allocator_model.pkl")
        scaler_path = os.path.join(model_dir, "budget_allocator_scaler.pkl")
        encoder_path = os.path.join(model_dir, "budget_allocator_encoder.pkl")

        with open(model_path, "rb") as f:
            self.model = pickle.load(f)

        with open(scaler_path, "rb") as f:
            self.scaler = pickle.load(f)

        with open(encoder_path, "rb") as f:
            self.encoder = pickle.load(f)

    def allocate_budget(self, trip_profile: Dict[str, Any]) -> Dict[str, Any]:
        """
        Predict budget allocation percentages across 6 categories.

        Pure ML prediction - no heuristics, no fallbacks.
        """
        try:
            destination_encoded = DESTINATION_ENCODING.get(trip_profile.get("destination"), 0)
            season_encoded = SEASON_ENCODING.get(trip_profile.get("travel_season"), 1)
            accommodation_preference_encoded = ACCOMMODATION_PREFERENCE_ENCODING.get(trip_profile.get("accommodation_preference"), 1)
            destination_cost_tier = COST_TIER_ENCODING.get(trip_profile.get("destination_cost_tier"), 1)
            primary_interest_encoded = INTEREST_ENCODING.get(trip_profile.get("primary_interest"), 2)
            secondary_interest_encoded = INTEREST_ENCODING.get(trip_profile.get("secondary_interest", "None"), 0) if trip_profile.get("secondary_interest", "None") != "None" else 0

            # Prepare features for model
            features = np.array([
                [
                    destination_encoded,
                    trip_profile.get("trip_duration_days", 7),
                    trip_profile.get("total_budget_inr", 50000),
                    trip_profile.get("group_size", 2),
                    primary_interest_encoded,
                    secondary_interest_encoded,
                    accommodation_preference_encoded,
                    season_encoded,
                    destination_cost_tier,
                ]
            ])

            # Scale features
            features_scaled = self.scaler.transform(features)

            # Predict percentages
            percentages = self.model.predict(features_scaled)[0]

            # Ensure percentages are valid (between 0-100 and sum to 100)
            percentages = np.clip(percentages, 0, 100)
            percentages = percentages / percentages.sum() * 100

            # Calculate absolute amounts
            total_budget = trip_profile.get("total_budget_inr", 50000)
            accommodation_amount = (percentages[0] / 100) * total_budget
            food_amount = (percentages[1] / 100) * total_budget
            activities_amount = (percentages[2] / 100) * total_budget
            transport_amount = (percentages[3] / 100) * total_budget
            shopping_amount = (percentages[4] / 100) * total_budget
            contingency_amount = (percentages[5] / 100) * total_budget

            daily_budget = total_budget / max(1, trip_profile.get("trip_duration_days", 1))
            per_person_budget = total_budget / max(1, trip_profile.get("group_size", 1))
            per_person_daily = daily_budget / max(1, trip_profile.get("group_size", 1))

            return {
                "accommodation_budget_pct": float(percentages[0]),
                "food_dining_budget_pct": float(percentages[1]),
                "activities_attractions_budget_pct": float(percentages[2]),
                "local_transport_budget_pct": float(percentages[3]),
                "shopping_misc_budget_pct": float(percentages[4]),
                "contingency_budget_pct": float(percentages[5]),
                "budget_allocation": {
                    "accommodation": float(accommodation_amount),
                    "food_dining": float(food_amount),
                    "activities_attractions": float(activities_amount),
                    "local_transport": float(transport_amount),
                    "shopping_misc": float(shopping_amount),
                    "contingency": float(contingency_amount),
                },
                "daily_budget": float(daily_budget),
                "per_person_budget": float(per_person_budget),
                "per_person_daily": float(per_person_daily),
                "status": "success",
            }

        except Exception as e:
            return {
                "status": "error",
                "error_message": str(e),
                "accommodation_budget_pct": 30.0,
                "food_dining_budget_pct": 25.0,
                "activities_attractions_budget_pct": 25.0,
                "local_transport_budget_pct": 10.0,
                "shopping_misc_budget_pct": 7.0,
                "contingency_budget_pct": 3.0,
            }
