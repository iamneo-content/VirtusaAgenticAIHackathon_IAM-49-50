"""Local Insights & Hidden Gems LLM Agent - Pure Gemini API calls."""

import json
from typing import Dict, Any


class LocalInsightsLLMAgent:
    """Provides insider tips, hidden gems using Gemini API."""

    def __init__(self, client):
        """Initialize with Gemini API client."""
        self.client = client

    def get_local_insights(self, trip_profile: Dict[str, Any], itinerary: Dict) -> Dict[str, Any]:
        """
        Generate local insights and hidden gems using pure Gemini API.

        No heuristics, no fallbacks - 100% LLM output.
        """
        try:
            accommodation_type = trip_profile.get('accommodation_type', 'Mid-range')
            destination = trip_profile.get('destination', 'Unknown')

            # Adapt prompt based on accommodation type
            if accommodation_type.lower() == "luxury":
                budget_guidance = "For luxury travelers, focus on exclusive experiences, premium dining, upscale areas, and high-end attractions."
            elif accommodation_type.lower() == "budget":
                budget_guidance = "For budget-conscious travelers, emphasize money-saving tips, free/cheap attractions, and affordable dining options."
            else:
                budget_guidance = "Balance both budget-conscious tips and mid-range premium experiences."

            prompt = f"""You are a local expert for {destination}. Provide insider tips for travelers.

Trip Details:
- Destination: {destination}
- Group Size: {trip_profile.get('group_size', 1)} person(s)
- Primary Interest: {trip_profile.get('primary_interest', 'general')}
- Secondary Interest: {trip_profile.get('secondary_interest', 'None')}
- Accommodation Type: {accommodation_type}
- Travel Season: {trip_profile.get('travel_season', 'Unknown')}
- Total Budget: Rs {trip_profile.get('total_budget_inr', 0)}

{budget_guidance}

Provide comprehensive local insights tailored to this trip profile. Respond ONLY with valid JSON:
{{
  "hidden_gems": [
    {{"name": "Place Name", "description": "What makes it special", "estimated_cost": "Budget range", "tips": ["tip1", "tip2"]}}
  ],
  "local_food_spots": [
    {{"name": "Restaurant/Food Vendor", "cuisine": "Cuisine Type", "price_range": "Cost indication", "signature_dish": "Popular dish"}}
  ],
  "neighborhoods_to_explore": [
    {{"name": "Area Name", "vibe": "Atmosphere description", "how_to_spend_time": ["activity1", "activity2"]}}
  ],
  "local_etiquette_tips": ["tip1", "tip2", "tip3"],
  "money_saving_hacks": ["hack1", "hack2", "hack3"],
  "free_or_cheap_attractions": ["place1", "place2", "place3"],
  "avoid_tourist_traps": ["trap1", "trap2"],
  "best_times_to_avoid_crowds": {{"avoid": ["peak times"], "ideal": ["best times"]}}
}}"""

            response_text = self.client.generate_content(
                prompt,
                temperature=0.8,
                max_tokens=2000
            )

            insights_data = self.client.extract_json_from_response(response_text)

            return {
                "hidden_gems": insights_data.get("hidden_gems", []),
                "local_food_spots": insights_data.get("local_food_spots", []),
                "neighborhoods_to_explore": insights_data.get("neighborhoods_to_explore", []),
                "local_etiquette_tips": insights_data.get("local_etiquette_tips", []),
                "money_saving_hacks": insights_data.get("money_saving_hacks", []),
                "free_or_cheap_attractions": insights_data.get("free_or_cheap_attractions", []),
                "avoid_tourist_traps": insights_data.get("avoid_tourist_traps", []),
                "best_times_to_avoid_crowds": insights_data.get("best_times_to_avoid_crowds", {}),
                "status": "success",
            }

        except Exception as e:
            raise ValueError(f"Local insights generation failed: {str(e)}")
