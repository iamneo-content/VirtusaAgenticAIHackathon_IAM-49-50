"""YatraAI Agent Implementations.

This module contains all AI agents:
- Budget Allocator ML Agent (RandomForest Regressor)
- Accommodation Recommender ML Agent (RandomForest Classifier)
- Itinerary Generator LLM Agent (Gemini API)
- Local Insights LLM Agent (Gemini API)
- Booking Strategy LLM Agent (Gemini API)
"""

from .budget_allocator_ml import BudgetAllocatorMLAgent
from .accommodation_recommender_ml import AccommodationRecommenderMLAgent
from .itinerary_generator_llm import ItineraryGeneratorLLMAgent
from .local_insights_llm import LocalInsightsLLMAgent
from .booking_strategy_llm import BookingStrategyLLMAgent

__all__ = [
    "BudgetAllocatorMLAgent",
    "AccommodationRecommenderMLAgent",
    "ItineraryGeneratorLLMAgent",
    "LocalInsightsLLMAgent",
    "BookingStrategyLLMAgent",
]
