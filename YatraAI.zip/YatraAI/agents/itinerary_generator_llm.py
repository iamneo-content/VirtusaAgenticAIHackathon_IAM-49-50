"""Itinerary Generator LLM Agent - Pure Gemini API calls."""

import json
from typing import Dict, Any


class ItineraryGeneratorLLMAgent:
    """Generates day-by-day detailed itinerary using Gemini API."""

    def __init__(self, client):
        """Initialize with Gemini API client."""
        self.client = client

    def generate_itinerary(self, trip_profile: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate detailed day-by-day itinerary using pure Gemini API.

        No heuristics, no fallbacks - 100% LLM output.
        """
        try:
            prompt = f"""Create a travel itinerary for a {trip_profile.get('trip_duration_days', 7)}-day trip to {trip_profile.get('destination', 'Unknown')} for {trip_profile.get('group_size', 1)} person(s) with a total budget of Rs {trip_profile.get('total_budget_inr', 50000)}.

Respond ONLY with valid JSON (no other text). Use this exact structure:
{{
  "itinerary": {{
    "day_1": {{"title": "Arrival", "activities": ["activity1", "activity2"], "estimated_cost": 2000}},
    "day_2": {{"title": "Exploration", "activities": ["activity3", "activity4"], "estimated_cost": 1800}}
  }},
  "trip_highlights": ["highlight1", "highlight2", "highlight3"],
  "contingency_plans": ["plan1", "plan2"],
  "tips_for_success": ["tip1", "tip2", "tip3"]
}}

Requirements:
- Primary interest: {trip_profile.get('primary_interest', 'General')}
- Daily budget: Rs {int(trip_profile.get('daily_budget', 7000) or 7000)}
- Ensure activities match interests and stay within budget
"""

            response_text = self.client.generate_content(
                prompt,
                temperature=0.7,
                max_tokens=2500
            )

            itinerary_data = self.client.extract_json_from_response(response_text)

            return {
                "itinerary": itinerary_data.get("itinerary", {}),
                "trip_highlights": itinerary_data.get("trip_highlights", []),
                "contingency_plans": itinerary_data.get("contingency_plans", []),
                "tips_for_success": itinerary_data.get("tips_for_success", []),
                "status": "success",
            }

        except Exception as e:
            raise ValueError(f"Itinerary generation failed: {str(e)}")
