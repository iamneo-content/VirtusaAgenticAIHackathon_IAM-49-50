"""Accommodation Recommender ML Agent - Pure Classification using RandomForest."""

import pickle
import os
from typing import Dict, Any, List
import numpy as np
from utils.constants import (
    ACCOMMODATION_CLASS_NAMES,
    DESTINATION_ENCODING,
    SEASON_ENCODING,
    COST_TIER_ENCODING,
    INTEREST_ENCODING,
    ACCOMMODATION_COST_RANGES,
)


class AccommodationRecommenderMLAgent:
    """Recommends accommodation type using trained RandomForest Classifier model."""

    ACCOMMODATION_TYPES = [ACCOMMODATION_CLASS_NAMES[i] for i in range(4)]

    def __init__(self, model_dir: str = None):
        """Load trained model and preprocessors from disk."""
        if model_dir is None:
            model_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "ml", "models")
        model_path = os.path.join(model_dir, "accommodation_recommender_model.pkl")
        scaler_path = os.path.join(model_dir, "accommodation_recommender_scaler.pkl")
        encoder_path = os.path.join(model_dir, "accommodation_recommender_encoder.pkl")

        with open(model_path, "rb") as f:
            self.model = pickle.load(f)

        with open(scaler_path, "rb") as f:
            self.scaler = pickle.load(f)

        with open(encoder_path, "rb") as f:
            self.encoder = pickle.load(f)

    def recommend_accommodation(self, user_profile: Dict[str, Any]) -> Dict[str, Any]:
        """
        Predict accommodation type classification (0-3).

        Pure ML prediction - no heuristics, no fallbacks.
        """
        try:
            destination_encoded = DESTINATION_ENCODING.get(user_profile.get("destination"), 0)
            season_encoded = SEASON_ENCODING.get(user_profile.get("travel_season"), 1)
            destination_cost_tier = COST_TIER_ENCODING.get(user_profile.get("destination_cost_tier"), 1)

            # Interest encoding
            interests_encoded = 0
            for interest in user_profile.get("interests", []):
                interests_encoded += INTEREST_ENCODING.get(interest, 0)

            # Prepare features for model
            is_group_trip = 1 if user_profile.get("group_size", 1) > 1 else 0

            features = np.array([
                [
                    destination_encoded,
                    user_profile.get("total_budget_inr", 100000),
                    user_profile.get("accommodation_budget_inr", 30000),
                    user_profile.get("trip_duration_days", 5),
                    user_profile.get("group_size", 2),
                    interests_encoded,
                    season_encoded,
                    destination_cost_tier,
                    is_group_trip,
                ]
            ])

            # Scale features
            features_scaled = self.scaler.transform(features)

            # Predict class
            prediction = self.model.predict(features_scaled)[0]
            probabilities = self.model.predict_proba(features_scaled)[0]
            confidence = float(np.max(probabilities) * 100)

            # Get accommodation type name
            accommodation_type = self.ACCOMMODATION_TYPES[int(prediction)]

            # Estimated cost per night from constants
            cost_min, cost_max = ACCOMMODATION_COST_RANGES[int(prediction)]
            estimated_cost_per_night = (cost_min + cost_max) / 2

            # Get alternatives (other classes with good probabilities)
            alternatives = []
            for idx, prob in enumerate(probabilities):
                if idx != prediction and prob > 0.1:
                    alt_cost_min, alt_cost_max = ACCOMMODATION_COST_RANGES[idx]
                    alternatives.append({
                        "type": self.ACCOMMODATION_TYPES[idx],
                        "class": idx,
                        "confidence": float(prob * 100),
                        "estimated_cost_per_night": (alt_cost_min + alt_cost_max) / 2,
                    })

            # Calculate comfort score (0-100)
            comfort_scores = {0: 30, 1: 60, 2: 90, 3: 70}
            comfort_score = comfort_scores[int(prediction)]

            return {
                "accommodation_type": accommodation_type,
                "accommodation_class": int(prediction),
                "confidence": confidence,
                "comfort_score": float(comfort_score),
                "estimated_cost_per_night": float(estimated_cost_per_night),
                "alternatives": alternatives,
                "status": "success",
            }

        except Exception as e:
            return {
                "status": "error",
                "error_message": str(e),
                "accommodation_type": "Mid-range",
                "accommodation_class": 1,
                "confidence": 0.0,
                "comfort_score": 60.0,
                "estimated_cost_per_night": 3500.0,
                "alternatives": [],
            }
