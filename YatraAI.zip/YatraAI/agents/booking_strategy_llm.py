"""Booking Strategy & Logistics LLM Agent - Pure Gemini API calls."""

import json
from typing import Dict, Any


class BookingStrategyLLMAgent:
    """Provides booking advice and travel logistics using Gemini API."""

    def __init__(self, client):
        """Initialize with Gemini API client."""
        self.client = client

    def get_booking_strategy(self, trip_profile: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate booking strategy and logistics using pure Gemini API.

        No heuristics, no fallbacks - 100% LLM output.
        """
        try:
            accommodation_type = trip_profile.get('accommodation_type', 'Mid-range')
            destination = trip_profile.get('destination', 'Unknown')
            total_budget = trip_profile.get('total_budget_inr', 50000)
            accommodation_budget = trip_profile.get('accommodation_budget_inr', 30000)

            prompt = f"""You are a travel logistics expert. Provide booking strategy for a {trip_profile.get('trip_duration_days', 7)}-day trip to {destination} with Rs {total_budget} total budget.

Trip Details:
- Accommodation Type: {accommodation_type}
- Accommodation Budget: Rs {accommodation_budget}
- Total Budget: Rs {total_budget}
- Group Size: {trip_profile.get('group_size', 1)} person(s)

Respond ONLY with valid JSON:
{{
  "flight_booking_strategy": {{
    "recommended_platforms": ["platform1", "platform2"],
    "booking_window": "4-6 weeks in advance",
    "best_days_to_book": "Tuesday-Thursday",
    "estimated_cost_range": "Estimated cost range in rupees (e.g., 5000-15000)",
    "money_saving_tips": ["tip1", "tip2"]
  }},
  "accommodation_booking_strategy": {{
    "recommended_platforms": ["platform1", "platform2"],
    "booking_window": "2-4 weeks in advance",
    "neighborhoods_recommended": ["neighborhood1"],
    "estimated_cost_per_night": "Cost range per night (e.g., 2000-5000)",
    "money_saving_tips": ["tip1", "tip2"]
  }},
  "activity_booking_strategy": {{
    "advance_booking_required": ["activity1"],
    "book_on_site": ["activity2"],
    "estimated_daily_activity_cost": "Estimated cost (e.g., 2000-3000)"
  }},
  "logistics_planning": {{
    "visa_requirements": {{"required": false, "processing_time": "N/A"}},
    "travel_insurance": {{"recommended": true, "estimated_cost": "500-1000"}},
    "vaccinations": {{"recommended": ["Routine vaccines"]}}
  }},
  "packing_checklist": {{"essentials": ["item1"], "by_activity": {{"activity": ["item1"]}}}},
  "pre_departure_checklist": {{"one_month_before": ["Book flights"], "one_week_before": ["Arrange transport"]}},
  "money_saving_tips_summary": ["tip1", "tip2"],
  "emergency_contingency_plans": {{"missed_flight": "Contact airline immediately", "medical_emergency": "Contact local hospital"}}
}}"""

            response_text = self.client.generate_content(
                prompt,
                temperature=0.6,
                max_tokens=2500
            )

            strategy_data = self.client.extract_json_from_response(response_text)

            return {
                "flight_booking_strategy": strategy_data.get("flight_booking_strategy", {}),
                "accommodation_booking_strategy": strategy_data.get("accommodation_booking_strategy", {}),
                "activity_booking_strategy": strategy_data.get("activity_booking_strategy", {}),
                "logistics_planning": strategy_data.get("logistics_planning", {}),
                "packing_checklist": strategy_data.get("packing_checklist", {}),
                "pre_departure_checklist": strategy_data.get("pre_departure_checklist", {}),
                "money_saving_tips_summary": strategy_data.get("money_saving_tips_summary", []),
                "emergency_contingency_plans": strategy_data.get("emergency_contingency_plans", {}),
                "status": "success",
            }

        except Exception as e:
            raise ValueError(f"Booking strategy generation failed: {str(e)}")
