YATRAAI: INTELLIGENT TRAVEL PLANNING SYSTEM
Professional Project Documentation

========================================================================
SECTION 1: PROBLEM DESCRIPTION
========================================================================

1.1 PROBLEM STATEMENT

The travel industry faces significant challenges in providing personalized,
budget-optimized, and comprehensive travel planning solutions. Travelers
struggle with:

    a) Budget Allocation Complexity
       Traditional travel planners lack intelligent systems to optimally
       distribute budgets across multiple expense categories. Users manually
       estimate spending without data-driven insights, leading to poor budget
       utilization.

    b) Accommodation Mismatch
       Current platforms recommend accommodations based on simple filtering
       rather than analyzing travelers profile characteristics, travel context,
       and budget constraints.

    c) Itinerary Quality and Personalization
       Generic itineraries fail to consider individual preferences, interests,
       and budget constraints. Manual creation is time-consuming and lacks
       validation.

    d) Information Asymmetry
       Travelers lack access to local insights, hidden gems, money-saving tips,
       and cultural guidance specific to their trip profile.

    e) Booking Coordination Overhead
       Lack of integrated booking strategy guidance across flights,
       accommodations, activities, and logistics creates coordination burden
       on travelers.

1.2 SCENARIO-BASED PROBLEM DESCRIPTION

SCENARIO: Travel Planning User Journey

Step 1: User Input
    Amit (28-year-old professional) wants to plan a 5-day trip to Jaipur
    with his partner. He has a budget of INR 100,000 and interests in
    cultural heritage and local food experiences.

Step 2: Current Pain Points
    a) He manually searches 10+ travel websites to understand budget allocation
    b) Accommodation options shown are either too expensive or poor quality
    c) Generated itineraries don't match his interests or budget constraints
    d) He spends hours researching local markets, food spots, and cultural tips
    e) Booking flights, hotels, and activities requires coordination across
       multiple platforms

Step 3: Expected Solution
    A single intelligent system that:
    a) Analyzes his profile and optimally allocates budget (30% accommodation,
       25% food, 25% activities, 10% transport, 7% shopping, 3% contingency)
    b) Recommends "Luxury" accommodation based on his budget tier and preferences
    c) Generates a detailed 5-day itinerary matching his interests
    d) Validates and optionally revises the itinerary for quality assurance
    e) Provides insider tips, hidden gems, and money-saving hacks for Jaipur
    f) Offers integrated booking strategy with platforms, timings, and cost ranges

1.3 SOLUTION OVERVIEW

YatraAI is an AI-powered travel planning system that combines:
    - Machine Learning components: A regression model for budget allocation and
      a classifier model for accommodation type prediction
    - Large Language Models (Gemini API) for personalized content generation
    - LangGraph workflow orchestration for 12-step sequential-conditional processing
    - Streamlit UI for user interaction and result visualization
    - Comprehensive validation and error handling without fallbacks

1.4 CRITICAL NOTE: PRE-LOADED UTILITIES

The following utility components are PRE-LOADED and available for use:

    utils/gemini_client.py (ALREADY PROVIDED)
        - GeminiClient class with API communication capabilities
        - JSON extraction and cleaning utilities
        - API key rotation for redundancy
        - No implementation required: Use as-is

    utils/constants.py (ALREADY PROVIDED)
        - All enumeration lists (destinations, interests, seasons, etc.)
        - Numeric configuration (budget ranges, thresholds)
        - ML feature encoding maps
        - No implementation required: Use as-is

Students should focus on implementing:
    - agents/ directory (5 ML/LLM agents using pre-loaded utilities)
    - nodes/ directory (12 workflow nodes)
    - workflow/workflow.py (LangGraph orchestration)
    - graph.py (entry point)
    - main.py (Streamlit UI)

========================================================================
SECTION 2: FILE STRUCTURE
========================================================================

YatraAI/
    |
    +--- agents/
    |    |--- __init__.py
    |    |--- budget_allocator_ml.py
    |    |--- accommodation_recommender_ml.py
    |    |--- itinerary_generator_llm.py
    |    |--- local_insights_llm.py
    |    +--- booking_strategy_llm.py
    |
    +--- nodes/
    |    |--- __init__.py
    |    |--- input_parser_node.py
    |    |--- input_normalizer_node.py
    |    |--- budget_allocator_node.py
    |    |--- decision_router_nodes.py
    |    |--- accommodation_recommender_node.py
    |    |--- itinerary_generator_node.py
    |    |--- itinerary_revision_node.py
    |    |--- local_insights_node.py
    |    +--- booking_strategy_node.py
    |
    +--- workflow/
    |    |--- __init__.py
    |    +--- workflow.py
    |
    +--- ml/
    |    |--- __init__.py
    |    |--- train_pipeline.py
    |    |--- train_model/
    |    |    |--- __init__.py
    |    |    |--- train_budget_allocator.py
    |    |    +--- train_accommodation_recommender.py
    |    |--- evaluation/
    |    |    |--- __init__.py
    |    |    +--- evaluate_models.py
    |    |--- data_cleaning/
    |    |    |--- __init__.py
    |    |    |--- clean_budget_data.py
    |    |    +--- clean_accommodation_data.py
    |    +--- models/
    |         |--- budget_allocator_model.pkl
    |         |--- budget_allocator_scaler.pkl
    |         |--- budget_allocator_encoder.pkl
    |         |--- accommodation_recommender_model.pkl
    |         |--- accommodation_recommender_scaler.pkl
    |         +--- accommodation_recommender_encoder.pkl
    |
    +--- utils/
    |    |--- __init__.py
    |    |--- constants.py
    |    +--- gemini_client.py
    |
    +--- data/
    |    |--- training_dataset/
    |    |    |--- budget_allocation_training.csv
    |    |    +--- accommodation_recommender_training.csv
    |    |--- evaluation_dataset/
    |    |    |--- budget_allocation_evaluation.csv
    |    |    +--- accommodation_recommender_evaluation.csv
    |    +--- processed/
    |         |--- budget_allocation_clean.csv
    |         +--- accommodation_recommender_clean.csv
    |
    |--- state.py
    |--- graph.py
    |--- main.py
    |--- run_full_workflow.py
    |--- tests.py
    |--- TECHNICAL_REFERENCE.md
    |--- PROJECT_DOCUMENTATION.md
    +--- requirements.txt


========================================================================
SECTION 3: PURPOSE OF FILES
========================================================================

3.1 CORE STATE MANAGEMENT

state.py
    Purpose: Defines TravelPlanState TypedDict (62 fields) that serves as
             central data container for entire workflow
    Responsibility: State initialization, field definitions, state merging
                   for parallel paths
    Key Components:
        - TravelPlanState: Central state container with 62 typed fields
        - get_initial_state(): Initializes state from user form data
        - merge_accommodations(): Merges parallel accommodation recommendations

3.2 AGENTS (5 Specialized Components)

agents/budget_allocator_ml.py
    Purpose: ML-based budget allocation across 6 expense categories
    Type: Machine Learning Agent (Regression)
    Input Features: 9 (encoded categorical and numeric features)
    Output Targets: 6 (budget percentages for different expense categories)
    Responsibility: Pure budget prediction without heuristics
    Dependency: Pre-trained regression model artifacts (model, scaler, encoder)
    Feature Extraction (in order):
        1. destination_encoded (categorical)
        2. trip_duration_days (numeric)
        3. total_budget_inr (numeric)
        4. group_size (numeric)
        5. primary_interest_encoded (categorical)
        6. secondary_interest_encoded (categorical)
        7. accommodation_preference_encoded (categorical)
        8. season_encoded (categorical)
        9. destination_cost_tier (numeric)

agents/accommodation_recommender_ml.py
    Purpose: ML-based accommodation type classification
    Type: Machine Learning Agent (Classification)
    Input Features: 9 (encoded categorical and numeric features)
    Output Classes: 4 (Budget, Mid-range, Luxury, Alternative)
    Responsibility: Pure accommodation classification with confidence scores
    Dependency: Pre-trained classification model artifacts (model, scaler, encoder)
    Feature Extraction (in order):
        1. destination_encoded (categorical)
        2. total_budget_inr (numeric)
        3. accommodation_budget_inr (numeric, tier-specific: 0.3/0.35/0.4 of total)
        4. trip_duration_days (numeric)
        5. group_size (numeric)
        6. interests_encoded (numeric, aggregated from primary + secondary interests)
        7. season_encoded (categorical)
        8. destination_cost_tier (numeric)
        9. is_group_trip (binary: 1 if group_size > 1 else 0)

agents/itinerary_generator_llm.py
    Purpose: Day-by-day itinerary generation
    Type: Large Language Model Agent
    Model: Gemini 2.5-flash-lite (temperature 0.7)
    Responsibility: Pure LLM-based itinerary creation
    Dependency: Gemini API, JSON parsing

agents/local_insights_llm.py
    Purpose: Local knowledge generation (hidden gems, food spots, tips)
    Type: Large Language Model Agent with Adaptive Prompting
    Model: Gemini 2.5-flash-lite (temperature 0.8)
    Responsibility: Adaptive content based on accommodation type
    Dependency: Gemini API, JSON parsing

agents/booking_strategy_llm.py
    Purpose: Booking logistics and travel planning advice
    Type: Large Language Model Agent
    Model: Gemini 2.5-flash-lite (temperature 0.6)
    Responsibility: Booking platforms, timing, cost estimates
    Dependency: Gemini API, JSON parsing

3.3 WORKFLOW NODES (12 Sequential-Conditional Processing)

nodes/input_parser_node.py
    Purpose: Validate user input against constraints
    Stage: 1 (Input Validation)
    Responsibility: Ensure destination, budget, duration, group size are valid
    Next Node: input_normalizer

nodes/input_normalizer_node.py
    Purpose: Standardize and normalize input data
    Stage: 1 (Input Normalization)
    Responsibility: Assign cost tiers, preferences, aggregate interests
    Next Node: budget_allocator

nodes/budget_allocator_node.py
    Purpose: Call Budget Allocator ML agent
    Stage: 2 (ML Processing)
    Responsibility: Get 6 budget percentages and daily breakdown
    Next Node: budget_feasibility_router

nodes/decision_router_nodes.py
    Purpose: Pure logic routing decisions
    Stage: 3 (Decision Making)
    Components:
        a) budget_feasibility_router: Routes to low/mid/high accommodation path
        b) trip_complexity_analyzer: Calculates complexity score (0.0-1.0)
    Next Nodes: accommodation_recommender_* nodes

nodes/accommodation_recommender_node.py
    Purpose: Call Accommodation Recommender ML agent with budget-specific context
    Stage: 3 (ML Processing)
    Variants: 3 nodes for low (30%), mid (35%), high (40%) budget allocation
    Responsibility: Classify accommodation type with confidence
    Next Node: trip_complexity_analyzer (convergence point)

nodes/itinerary_generator_node.py
    Purpose: Call Itinerary Generator LLM agent
    Stage: 4 (LLM Processing)
    Responsibility: Generate day-by-day activities and costs
    Next Node: itinerary_revision_node

nodes/itinerary_revision_node.py
    Purpose: Validate and optionally revise itinerary
    Stage: 4 (LLM Validation/Revision)
    Responsibility: Validation (always), revision (if needed, max 2 times)
    Next Node: local_insights_node

nodes/local_insights_node.py
    Purpose: Call Local Insights LLM agent
    Stage: 5 (LLM Processing)
    Responsibility: Generate hidden gems, food spots, cultural tips
    Next Node: booking_strategy_node

nodes/booking_strategy_node.py
    Purpose: Call Booking Strategy LLM agent (Final node)
    Stage: 5 (LLM Processing)
    Responsibility: Booking platforms, logistics, checklists
    Next Node: None (Finish point)

3.4 WORKFLOW ORCHESTRATION

workflow/workflow.py
    Purpose: Build and configure LangGraph state machine
    Type: Graph Orchestration
    Responsibility: Define 12 nodes, edges, conditional routing
    Graph Type: StateGraph with TravelPlanState
    Entry Point: input_parser
    Finish Point: booking_strategy

3.5 ENTRY POINT

graph.py
    Purpose: Main API entry point for workflow execution
    Responsibility: Orchestrate complete trip planning workflow
    Key Functions:
        a) plan_trip(): Execute workflow with 7 user inputs
        b) get_trip_summary(): Extract condensed summary
        c) get_workflow_info(): Return workflow metadata

3.6 USER INTERFACE

main.py
    Purpose: Streamlit web application for user interaction
    Responsibility: Input form, 7-tab result display, visualizations
    Type: Web UI Framework
    Tabs: Overview, Budget, Accommodation, Itinerary, Local Insights,
          Booking Strategy, Model Evaluation

3.7 UTILITIES AND CONFIGURATION

utils/constants.py
    Purpose: Centralized configuration and encoding maps
    Responsibility: All enumeration lists, numeric ranges, ML encodings
    Components: 17 encoding maps, 5 numeric ranges, 3 thresholds

utils/gemini_client.py
    Purpose: Gemini API wrapper with key rotation
    Responsibility: API communication, JSON parsing, error handling
    Components: GeminiClient class with retry and key rotation logic

3.8 ML PIPELINE

ml/train_pipeline.py
    Purpose: Orchestrate complete training workflow
    Responsibility: Coordinate data cleaning and model training

ml/train_model/train_budget_allocator.py
    Purpose: Train RandomForest Regressor for budget allocation
    Responsibility: Feature engineering, model training, artifact persistence

ml/train_model/train_accommodation_recommender.py
    Purpose: Train RandomForest Classifier for accommodation
    Responsibility: Feature engineering, balanced training, artifact persistence

ml/data_cleaning/clean_budget_data.py
    Purpose: Clean and validate budget allocation dataset
    Responsibility: Handle missing values, validate percentage constraints

ml/data_cleaning/clean_accommodation_data.py
    Purpose: Clean and validate accommodation dataset
    Responsibility: Handle missing values, validate class distribution

ml/evaluation/evaluate_models.py
    Purpose: Evaluate trained models on test datasets
    Responsibility: Calculate metrics (MAPE, Accuracy, Precision, Recall)

3.9 TESTING AND DOCUMENTATION

tests.py
    Purpose: Comprehensive test suite following AetherFit patterns
    Type: pytest-based testing
    Count: 18 tests covering agents, nodes, state, routers, workflows, data

TECHNICAL_REFERENCE.md
    Purpose: Complete technical reference with signatures and logic
    Content: All class/function signatures, parameters, returns

PROJECT_DOCUMENTATION.md (This file)
    Purpose: Professional project documentation
    Content: Problem description, architecture, execution flow


========================================================================
SECTION 4: CLASS STRUCTURES AND METHODS
========================================================================

4.1 STATE MANAGEMENT

Class: TravelPlanState (TypedDict with 62 fields)

    Total Fields: 62 (all optional due to total=False)

    Input Fields (7):
        destination (str)
        trip_duration_days (int)
        total_budget_inr (int)
        group_size (int)
        primary_interest (str)
        secondary_interest (str)
        travel_season (str)

    Derived Fields (5):
        destination_cost_tier (str)
        accommodation_preference (str)
        parsed_profile (Dict)
        validation_errors (List of str)
        parsing_complete (bool)

    Budget Allocation ML Outputs (8):
        accommodation_budget_pct (float)
        food_dining_budget_pct (float)
        activities_attractions_budget_pct (float)
        local_transport_budget_pct (float)
        shopping_misc_budget_pct (float)
        contingency_budget_pct (float)
        daily_budget (float)
        budget_allocation (Dict with 6 categories)

    Decision Node Outputs (2):
        daily_budget_tier (str)
        complexity_score (float, 0.0-1.0)

    Accommodation ML Outputs (6 plus merged):
        accommodation_type (str)
        accommodation_class (int, 0-3)
        accommodation_confidence (float, 0-100)
        accommodation_comfort_score (float, 0-100)
        estimated_cost_per_night (float)
        accommodation_alternatives (List of Dict)
        accommodation_recommendations (Annotated Dict with merge reducer)

    Itinerary LLM Outputs (11):
        itinerary (Dict with day_1...day_N)
        trip_highlights (List of str)
        contingency_plans (List of str)
        itinerary_tips (List of str)
        daily_schedule (Dict)
        itinerary_analysis_complete (bool)
        itinerary_validation_score (float, 0.0-1.0)
        itinerary_validation_issues (List of str)
        itinerary_revision_count (int, 0-2)
        itinerary_revised (bool)

    Local Insights LLM Outputs (10):
        hidden_gems (List of Dict)
        local_food_spots (List of Dict)
        neighborhoods_to_explore (List of Dict)
        local_etiquette_tips (List of str)
        money_saving_hacks (List of str)
        free_or_cheap_attractions (List of str)
        avoid_tourist_traps (List of str)
        best_times_to_avoid_crowds (Dict)
        insights_analysis_complete (bool)

    Booking Strategy LLM Outputs (10):
        flight_booking_strategy (Dict)
        accommodation_booking_strategy (Dict)
        activity_booking_strategy (Dict)
        visa_requirements (Dict)
        budget_optimization_tips (List of str)
        booking_checklist (List of str)
        packing_checklist (Dict)
        emergency_contingency_plans (Dict)
        booking_analysis_complete (bool)

    System Metadata (5):
        plan_id (str, UUID)
        analysis_timestamp (str, ISO format)
        plan_generated (bool)
        error_occurred (bool)
        error_messages (List of str)

4.2 BUDGET ALLOCATOR ML AGENT

Class: BudgetAllocatorMLAgent

    Attributes:
        model: sklearn.ensemble.RandomForestRegressor
        scaler: sklearn.preprocessing.StandardScaler
        encoder: sklearn.preprocessing.LabelEncoder

    Method: __init__(model_dir: str = "ml/models")
        Purpose: Load pre-trained model artifacts from disk
        Parameters:
            model_dir (str): Directory path containing pickle files
        Returns: None (initializes instance attributes)
        Logic:
            1. Constructs paths to 3 pickle files
            2. Loads model, scaler, encoder from pickle format
            3. Stores in instance attributes
        Raises: FileNotFoundError if pickle files missing

    Method: allocate_budget(trip_profile: Dict) -> Dict
        Purpose: Predict budget allocation percentages (pure ML, no heuristics)
        Parameters:
            trip_profile (Dict): Contains destination, duration, budget, group,
                                interests, season, tier
        Returns: Dict with 6 percentages, absolute amounts, daily breakdown
        Logic:
            1. Encode categorical features using constant mappings
            2. Create feature array with 9 features
            3. Apply StandardScaler transformation
            4. RandomForest prediction yields 6 percentage values
            5. Clip percentages to 0-100 range
            6. Normalize percentages to sum exactly 100
            7. Calculate absolute amounts and derived metrics
            8. Return comprehensive dict with status indicator
        Raises: Returns error dict with fallback percentages on exception

4.3 ACCOMMODATION RECOMMENDER ML AGENT

Class: AccommodationRecommenderMLAgent

    Class Attributes:
        ACCOMMODATION_TYPES: List with 4 accommodation type names

    Attributes:
        model: sklearn.ensemble.RandomForestClassifier
        scaler: sklearn.preprocessing.StandardScaler
        encoder: sklearn.preprocessing.LabelEncoder

    Method: __init__(model_dir: str = None)
        Purpose: Load pre-trained classifier and preprocessors
        Parameters:
            model_dir (str, optional): Directory with model files.
                                      If None, derives from file path
        Returns: None (initializes instance attributes)
        Logic:
            1. If model_dir None, compute absolute path from __file__
            2. Construct paths to 3 pickle files
            3. Load model, scaler, encoder from pickle
            4. Store in instance attributes
        Raises: FileNotFoundError if files missing

    Method: recommend_accommodation(user_profile: Dict) -> Dict
        Purpose: Classify accommodation type (pure ML, no heuristics)
        Parameters:
            user_profile (Dict): Contains destination, budgets, duration,
                                group, interests, season, tier
        Returns: Dict with accommodation type, class, confidence, alternatives
        Logic:
            1. Encode categorical features using constant maps
            2. Aggregate interests by summing encoding values
            3. Calculate is_group_trip boolean
            4. Create feature array with 9 features
            5. StandardScale the features
            6. RandomForest predict yields class (0-3)
            7. RandomForest predict_proba yields 4 probability values
            8. Extract confidence as max probability times 100
            9. Look up accommodation type name from constant map
            10. Calculate estimated cost as midpoint of cost range
            11. Generate alternatives: classes with probability greater than 10%
            12. Return comprehensive dict with status
        Raises: Returns error dict with fallback "Mid-range" on exception

4.4 ITINERARY GENERATOR LLM AGENT

Class: ItineraryGeneratorLLMAgent

    Attributes:
        client: GeminiClient (Gemini API wrapper instance)

    Method: __init__(client: GeminiClient)
        Purpose: Initialize with Gemini API client
        Parameters:
            client (GeminiClient): Pre-configured Gemini client
        Returns: None (stores client in attribute)
        Logic: Direct assignment of client to instance attribute

    Method: generate_itinerary(trip_profile: Dict) -> Dict
        Purpose: Generate day-by-day itinerary using pure LLM
        Parameters:
            trip_profile (Dict): Contains destination, duration, budget, group,
                                interests, daily budget
        Returns: Dict with itinerary (day_1...day_N), highlights, plans
        Logic:
            1. Build structured prompt requesting JSON output
            2. Specify exact JSON schema in prompt
            3. Call client.generate_content() with temperature=0.7
            4. Extract JSON from response using client method
            5. Parse and return with status indicator
        Raises: Raises ValueError on failure (pure agent, no fallback)

4.5 LOCAL INSIGHTS LLM AGENT

Class: LocalInsightsLLMAgent

    Attributes:
        client: GeminiClient (Gemini API wrapper instance)

    Method: __init__(client: GeminiClient)
        Purpose: Initialize with Gemini API client
        Parameters:
            client (GeminiClient): Pre-configured Gemini client
        Returns: None (stores client in attribute)
        Logic: Direct assignment of client to instance attribute

    Method: get_local_insights(trip_profile: Dict, itinerary: Dict) -> Dict
        Purpose: Generate local insights with adaptive prompting
        Parameters:
            trip_profile (Dict): Destination, group, interests, accommodation type
            itinerary (Dict): Day-by-day itinerary for context
        Returns: Dict with hidden gems, food spots, neighborhoods, tips
        Logic:
            1. Extract accommodation_type for adaptive prompting
            2. Generate budget_guidance based on accommodation:
               - Luxury: Focus on premium, exclusive experiences
               - Budget: Emphasize money-saving, free attractions
               - Mid-range: Balance both approaches
            3. Build prompt with trip details and guidance
            4. Call client.generate_content() with temperature=0.8
            5. Extract JSON from response
            6. Return comprehensive insights dict
        Raises: Raises ValueError on failure (pure agent, no fallback)

4.6 BOOKING STRATEGY LLM AGENT

Class: BookingStrategyLLMAgent

    Attributes:
        client: GeminiClient (Gemini API wrapper instance)

    Method: __init__(client: GeminiClient)
        Purpose: Initialize with Gemini API client
        Parameters:
            client (GeminiClient): Pre-configured Gemini client
        Returns: None (stores client in attribute)
        Logic: Direct assignment of client to instance attribute

    Method: get_booking_strategy(trip_profile: Dict) -> Dict
        Purpose: Generate booking strategy and logistics
        Parameters:
            trip_profile (Dict): Trip details including accommodation type and budget
        Returns: Dict with flight, accommodation, activity strategies, logistics
        Logic:
            1. Extract accommodation type and budget for context
            2. Build detailed prompt with trip parameters
            3. Specify JSON schema with nested structures
            4. Call client.generate_content() with temperature=0.6
               (lower temp for factual logistics)
            5. Extract JSON response
            6. Return comprehensive strategy dict
        Raises: Raises ValueError on failure (pure agent, no fallback)

4.7 GEMINI CLIENT UTILITY

Class: GeminiClient

    Attributes:
        model (str): Gemini model name
        api_keys (List): All available API keys for rotation
        current_key_index (int): Index of currently active key
        client: google.generativeai.GenerativeModel instance

    Method: __init__(model: str = "gemini-2.5-flash-lite")
        Purpose: Initialize Gemini client with API key rotation support
        Parameters:
            model (str): Gemini model identifier
        Returns: None (initializes all attributes)
        Logic:
            1. Store model name
            2. Retrieve all available API keys
            3. Set current_key_index to 0
            4. Call _initialize_client() to set up first client

    Method: _initialize_client() -> None
        Purpose: Initialize genai client with current API key
        Parameters: None (uses self.current_key_index)
        Returns: None (modifies self.client)
        Logic:
            1. Check if current_key_index within bounds
            2. Retrieve current API key from list
            3. Configure google.generativeai with key
            4. Create GenerativeModel instance
            5. Log successful initialization

    Method: _rotate_api_key() -> None
        Purpose: Rotate to next available API key on quota exceeded
        Parameters: None
        Returns: None (updates current_key_index and reinitializes)
        Logic:
            1. Increment current_key_index
            2. Check if new index within bounds
            3. Call _initialize_client() with new key
            4. Log rotation event

    Method: generate_content(prompt: str, temperature: float = 0.7,
                            max_tokens: int = 2000,
                            response_mime_type: str = None) -> str
        Purpose: Generate content with automatic key rotation on quota exceeded
        Parameters:
            prompt (str): Input prompt for LLM
            temperature (float): Creativity control (0.0-2.0)
            max_tokens (int): Maximum output length
            response_mime_type (str, optional): Response format specification
        Returns: str (raw text response from Gemini)
        Logic:
            1. Initialize attempt counter and retry limit
            2. Build generation_config with temperature and max_tokens
            3. Call client.generate_content() with config
            4. Validate response has text content
            5. Return response text on success
            6. On error, check if quota-related (429, quota, rate limit, etc.)
            7. If quota: rotate key and retry (max retries = number of keys)
            8. If other error: raise immediately without retry

    Method: extract_json_from_response(response_text: str) -> Dict
        Purpose: Extract JSON from LLM response with multiple fallback strategies
        Parameters:
            response_text (str): Raw text from LLM
        Returns: Dict (parsed JSON object)
        Logic:
            1. Clean markdown: remove ```json and ``` wrappers
            2. Try parsing entire cleaned text as JSON
            3. If fails, search for first {...} pattern using regex
            4. Remove trailing commas (common LLM error) iteratively
            5. Try parsing again
            6. If still fails, find innermost {...} and attempt
            7. Return first successfully parsed dict
            8. Raise ValueError if all strategies fail

    Method: validate_response_fields(response: Dict,
                                    required_fields: List) -> None
        Purpose: Validate that response contains all required fields
        Parameters:
            response (Dict): Parsed JSON response
            required_fields (List): Expected field names
        Returns: None
        Logic:
            1. Identify missing fields (in required_fields but not in response)
            2. If any missing, raise ValueError with list

    Method: generate_structured_json(prompt: str,
                                    required_fields: List,
                                    temperature: float = 0.7,
                                    max_tokens: int = 2000) -> Dict
        Purpose: Generate and validate JSON response in single operation
        Parameters:
            prompt (str): Input prompt
            required_fields (List): Expected fields in response
            temperature (float): Creativity control
            max_tokens (int): Max output length
        Returns: Dict (validated JSON)
        Logic:
            1. Call generate_content() with parameters
            2. Call extract_json_from_response() on result
            3. Call validate_response_fields() to check required fields
            4. Return validated dict


========================================================================
SECTION 5: FUNCTION SIGNATURES AND LOGIC
========================================================================

5.1 STATE MANAGEMENT FUNCTIONS

Function: merge_accommodations(left: Dict, right: Dict) -> Dict
    Purpose: Merge accommodation recommendations from parallel execution paths
    Parameters:
        left (Dict): Left accommodation recommendations (may be None)
        right (Dict): Right accommodation recommendations (may be None)
    Returns: Dict (merged recommendations with combined budget tiers)
    Logic:
        1. If left is falsy, return right
        2. If right is falsy, return left
        3. Create merged = copy of left dict
        4. Initialize merged["recommendations_by_budget"] if missing
        5. Update recommendations_by_budget with right's data
        6. Return merged dict

Function: get_initial_state(form_data: Dict) -> TravelPlanState
    Purpose: Initialize TravelPlanState from user form input
    Parameters:
        form_data (Dict): Contains 7 user input fields
    Returns: TravelPlanState (initialized state dict)
    Logic:
        1. Extract user inputs with defaults from form_data
        2. Set flags: parsing_complete=False, error_occurred=False
        3. Initialize empty lists: error_messages, validation_errors
        4. Set defaults: complexity_score=0.5, itinerary_revision_count=0
        5. Return TravelPlanState dict

5.2 WORKFLOW NODES - Organized by Processing Stage

All nodes follow the same signature pattern:
    Function: node_name(state: TravelPlanState) -> TravelPlanState
    Parameters: state (TravelPlanState)
    Returns: TravelPlanState (modified state)
    Error Handling: Try/except wrapper, append to error_messages,
                   set error_occurred=True

═══════════════════════════════════════════════════════════════════════════════
STAGE 1: INPUT PROCESSING (Sequential: 2 nodes)
═══════════════════════════════════════════════════════════════════════════════

File: nodes/input_parser_node.py
────────────────────────────────

Function: input_parser_node(state: TravelPlanState) -> TravelPlanState
    Stage: 1 (Input Validation - FIRST node)
    File: nodes/input_parser_node.py
    Workflow Position: Entry point
    Next Node: input_normalizer_node

    Purpose: Validate user input against all constraints

    Parameters: state (TravelPlanState with raw input fields)
    Returns: TravelPlanState (with validation_errors, parsing_complete)

    Validation Rules:
        - destination: Must be in list of 17 valid cities
        - budget: 5000 <= total_budget_inr <= 500000
        - duration: 2 <= trip_duration_days <= 30
        - group_size: 1 <= group_size <= 10

    State Updates:
        - validation_errors: List of error messages (empty if all valid)
        - parsing_complete: Boolean (True if all valid, False if errors)

    Logic:
        1. Define valid destinations list (17 cities)
        2. Validate destination in valid list → if fail, add error
        3. Validate budget range → if fail, add error
        4. Validate duration range → if fail, add error
        5. Validate group size range → if fail, add error
        6. Accumulate all errors in validation_errors list
        7. Set parsing_complete = True only if validation_errors is empty
        8. Return modified state

File: nodes/input_normalizer_node.py
────────────────────────────────────

Function: input_normalizer_node(state: TravelPlanState) -> TravelPlanState
    Stage: 1 (Input Normalization - SECOND node)
    File: nodes/input_normalizer_node.py
    Workflow Position: After input_parser_node
    Next Node: budget_allocator_node

    Purpose: Standardize and normalize input for downstream processing

    Parameters: state (TravelPlanState with validated inputs)
    Returns: TravelPlanState (with derived fields: tier, preference, profile)

    State Updates:
        - destination_cost_tier: String (Tier-1, Tier-2, or Tier-3)
        - accommodation_preference: String (Mid-range or Budget)
        - parsed_profile: Dict with aggregated trip info

    Destination Tier Mapping:
        - Tier-1 (High cost): Mumbai, Delhi, Goa, Bangalore
        - Tier-2 (Medium cost): Jaipur, Udaipur, Varanasi, Kolkata, Agra,
                               Pune, Lucknow, Hyderabad
        - Tier-3 (Low cost): Kerala, Rishikesh, Himachal Pradesh, Rajasthan,
                            Northeast India

    Accommodation Preference Setting:
        - Tier-1, Tier-2 → "Mid-range"
        - Tier-3 → "Budget"

    Logic:
        1. Map destination to cost tier using tier mapping
        2. Set accommodation_preference based on tier:
           - If Tier-1 or Tier-2: "Mid-range"
           - If Tier-3: "Budget"
        3. Aggregate primary and secondary interests into list
        4. Create parsed_profile dict with all inputs
        5. Return modified state

═══════════════════════════════════════════════════════════════════════════════
STAGE 2: ML PROCESSING - BUDGET ALLOCATION (Sequential: 1 node)
═══════════════════════════════════════════════════════════════════════════════

File: nodes/budget_allocator_node.py
────────────────────────────────────

Function: budget_allocator_node(state: TravelPlanState) -> TravelPlanState
    Stage: 2 (Budget Allocation - ML Regression)
    File: nodes/budget_allocator_node.py
    Workflow Position: After input_normalizer_node
    Next Node: budget_feasibility_router (decision router)

    Purpose: Execute Budget Allocator ML agent (Regression model)

    Agent: BudgetAllocatorMLAgent (RandomForestRegressor)
    Model Type: Regression (predicts continuous percentage values)
    Input Features: 9 encoded features
    Output Targets: 6 budget percentages

    Parameters: state (TravelPlanState with input and derived fields)
    Returns: TravelPlanState (with budget percentages and calculations)

    State Updates:
        - accommodation_budget_pct: Float (e.g., 30.2)
        - food_dining_budget_pct: Float (e.g., 24.8)
        - activities_attractions_budget_pct: Float (e.g., 24.5)
        - local_transport_budget_pct: Float (e.g., 10.1)
        - shopping_misc_budget_pct: Float (e.g., 7.2)
        - contingency_budget_pct: Float (e.g., 3.2)
        - daily_budget: Float (total_budget / trip_duration_days)
        - budget_allocation: Dict with absolute amounts for each category

    Logic:
        1. Instantiate BudgetAllocatorMLAgent (loads pre-trained model)
        2. Build trip_profile from state fields
        3. Call agent.allocate_budget(trip_profile)
        4. If status="success":
           - Extract 6 percentages from result
           - Calculate daily_budget = total_budget / trip_duration_days
           - Calculate absolute amounts in budget_allocation dict
           - Update state with all budget fields
        5. If status="error":
           - Append error message to error_messages
           - Set error_occurred = True
        6. Return modified state

═══════════════════════════════════════════════════════════════════════════════
STAGE 3: DECISION ROUTING (2 nodes: decision router + complexity analyzer)
═══════════════════════════════════════════════════════════════════════════════

File: nodes/decision_router_nodes.py
────────────────────────────────────

Function: budget_feasibility_router(state: TravelPlanState) -> TravelPlanState
    Stage: 3 (Decision Routing - Pure Logic)
    File: nodes/decision_router_nodes.py
    Workflow Position: After budget_allocator_node
    Next Nodes: accommodation_recommender_low_budget_node
               accommodation_recommender_mid_budget_node
               accommodation_recommender_high_budget_node
               (Selected by conditional routing based on output)

    Purpose: Route to appropriate accommodation path based on daily budget

    Agent Type: Pure Logic Router (no ML, no LLM)
    Routing Decision: Based on daily_budget value

    Parameters: state (TravelPlanState with daily_budget)
    Returns: TravelPlanState (with daily_budget_tier set for routing)

    Budget Thresholds:
        - Low Budget: daily_budget < 7,000 INR
        - Mid Budget: 7,000 <= daily_budget < 15,000 INR
        - High Budget: daily_budget >= 15,000 INR

    State Updates:
        - daily_budget_tier: String that triggers conditional routing
            Values: "low_budget_path", "mid_budget_path", or "high_budget_path"

    Logic:
        1. Extract daily_budget from state
        2. Compare daily_budget against thresholds:
           - If < 7000: daily_budget_tier = "low_budget_path"
           - Elif < 15000: daily_budget_tier = "mid_budget_path"
           - Else: daily_budget_tier = "high_budget_path"
        3. Set daily_budget_tier in state
        4. Return modified state

    Note: Workflow uses this value for conditional routing (see workflow.py
          route_by_budget function)

Function: trip_complexity_analyzer(state: TravelPlanState) -> TravelPlanState
    Stage: 3B (Complexity Analysis - Pure Logic, Convergence Point)
    File: nodes/decision_router_nodes.py
    Workflow Position: After ALL accommodation nodes (convergence point)
    Next Node: itinerary_generator_node

    Previous Nodes That Converge Here:
        - accommodation_recommender_low_budget_node
        - accommodation_recommender_mid_budget_node
        - accommodation_recommender_high_budget_node

    Purpose: Calculate trip complexity score to determine itinerary revision limits

    Agent Type: Pure Logic Analyzer (no ML, no LLM)
    Decision Output: Complexity score (0.0-1.0 range)
    Impact: Determines max revisions allowed in itinerary_validator_and_reviser_node

    Parameters: state (TravelPlanState with duration, group_size, interests)
    Returns: TravelPlanState (with complexity_score)

    Complexity Score Formula:
        score = (duration_norm * 0.4) + (group_norm * 0.3) + (interests_norm * 0.3)

        Where:
        - duration_norm = min(trip_duration_days / 30.0, 1.0)  [40% weight]
        - group_norm = min(group_size / 10.0, 1.0)             [30% weight]
        - interests_norm = interest_count / 2.0                 [30% weight]
          (interest_count = 1 for primary + 1 for secondary if not "None")

    Complexity Thresholds:
        - Low complexity: score <= 0.7 → Max 1 itinerary revision allowed
        - High complexity: score > 0.7 → Max 2 itinerary revisions allowed

    State Updates:
        - complexity_score: Float (0.0-1.0)

    Logic:
        1. Extract trip_duration_days from state
        2. Extract group_size from state
        3. Count interests: primary_interest (1) + secondary_interest (1 if not "None")
        4. Normalize duration: min(duration / 30.0, 1.0)
        5. Normalize group: min(group_size / 10.0, 1.0)
        6. Normalize interests: count / 2.0
        7. Calculate complexity_score = (duration*0.4) + (group*0.3) + (interests*0.3)
        8. Set complexity_score in state
        9. Return modified state

    Note: This score is later checked by itinerary_validator_and_reviser_node
          to determine revision limits

═══════════════════════════════════════════════════════════════════════════════
STAGE 3B: ML PROCESSING - ACCOMMODATION RECOMMENDATION (3 Budget-Specific Paths)
═══════════════════════════════════════════════════════════════════════════════

File: nodes/accommodation_recommender_node.py
──────────────────────────────────────────────

Function: accommodation_recommender_node(state: TravelPlanState) -> TravelPlanState
    Stage: 3B (Accommodation Recommendation - ML Classification - Generic)
    File: nodes/accommodation_recommender_node.py
    Workflow Position: NOT USED IN MAIN WORKFLOW (standalone/testing function)
    Used For: Direct testing via tests.py

    Purpose: Generic Accommodation Recommender (flexible allocation percentage)

    Agent: AccommodationRecommenderMLAgent (RandomForestClassifier)
    Model Type: Classification (predicts accommodation type: 0-3)
    Input Features: 9 encoded features
    Output Classes: 4 (Budget, Mid-range, Luxury, Alternative)

    Budget Allocation: Uses whatever is in budget_allocation["accommodation"]

    Parameters: state (TravelPlanState with budget info)
    Returns: TravelPlanState (with accommodation recommendation)

    State Updates:
        - accommodation_type: String (Budget, Mid-range, Luxury, Alternative)
        - accommodation_class: Integer (0, 1, 2, or 3)
        - accommodation_confidence: Float (0-100 confidence percentage)
        - estimated_cost_per_night: Float (INR, based on class midpoint)
        - accommodation_alternatives: List of Dict (alternatives with >10% confidence)

    Logic:
        1. Instantiate AccommodationRecommenderMLAgent (loads pre-trained model)
        2. Extract accommodation_budget from budget_allocation["accommodation"]
        3. Build user_profile with all trip and budget parameters
        4. Call agent.recommend_accommodation(user_profile)
        5. If status="success":
           - Extract accommodation_type, accommodation_class, confidence
           - Extract alternatives list
           - Update state with all fields
        6. If status="error":
           - Append error message
           - Set error_occurred = True
        7. Return modified state

    Usage: Direct import and call for standalone testing

Function: accommodation_recommender_low_budget_node(state: TravelPlanState) -> TravelPlanState
    Stage: 3B (Accommodation Recommendation - ML Classification - Low Budget)
    File: nodes/accommodation_recommender_node.py
    Workflow Position: After budget_feasibility_router (if daily_budget < 7000)
    Converges To: trip_complexity_analyzer

    Purpose: Execute Accommodation Recommender for LOW budget path

    Agent: AccommodationRecommenderMLAgent (RandomForestClassifier)
    Budget Allocation: 30% of total_budget_inr

    Parameters: state (TravelPlanState with budget allocation)
    Returns: TravelPlanState (with accommodation recommendation)

    State Updates:
        - accommodation_type: String (typically "Budget" for this path)
        - accommodation_class: Integer (0 = Budget, cost ~500-1500/night)
        - accommodation_confidence: Float (0-100)
        - accommodation_comfort_score: Float (0-100)
        - estimated_cost_per_night: Float (typically 500-1500 INR)
        - accommodation_alternatives: List of alternatives
        - accommodation_recommendations["recommendations_by_budget"]["low"]: Full results

    Logic:
        1. Calculate accommodation_budget = total_budget_inr * 0.30
        2. Instantiate AccommodationRecommenderMLAgent
        3. Build user_profile with calculated low_budget
        4. Call agent.recommend_accommodation(user_profile)
        5. Update state with all recommendation fields
        6. Store in accommodation_recommendations["recommendations_by_budget"]["low"]
        7. Return modified state

Function: accommodation_recommender_mid_budget_node(state: TravelPlanState) -> TravelPlanState
    Stage: 3B (Accommodation Recommendation - ML Classification - Mid Budget)
    File: nodes/accommodation_recommender_node.py
    Workflow Position: After budget_feasibility_router (if 7000 <= daily_budget < 15000)
    Converges To: trip_complexity_analyzer

    Purpose: Execute Accommodation Recommender for MID budget path

    Agent: AccommodationRecommenderMLAgent (RandomForestClassifier)
    Budget Allocation: 35% of total_budget_inr

    Parameters: state (TravelPlanState with budget allocation)
    Returns: TravelPlanState (with accommodation recommendation)

    State Updates: Same as low_budget variant
        - accommodation_type: String (typically "Mid-range" for this path)
        - accommodation_class: Integer (1 = Mid-range, cost ~2000-5000/night)
        - Similar fields as low_budget
        - accommodation_recommendations["recommendations_by_budget"]["mid"]: Full results

    Logic: Identical to low_budget variant, except:
        - Calculate accommodation_budget = total_budget_inr * 0.35
        - Store results in ["recommendations_by_budget"]["mid"]

Function: accommodation_recommender_high_budget_node(state: TravelPlanState) -> TravelPlanState
    Stage: 3B (Accommodation Recommendation - ML Classification - High Budget)
    File: nodes/accommodation_recommender_node.py
    Workflow Position: After budget_feasibility_router (if daily_budget >= 15000)
    Converges To: trip_complexity_analyzer

    Purpose: Execute Accommodation Recommender for HIGH budget path

    Agent: AccommodationRecommenderMLAgent (RandomForestClassifier)
    Budget Allocation: 40% of total_budget_inr

    Parameters: state (TravelPlanState with budget allocation)
    Returns: TravelPlanState (with accommodation recommendation)

    State Updates: Same as low_budget variant
        - accommodation_type: String (typically "Luxury" for this path)
        - accommodation_class: Integer (2 = Luxury, cost ~8000-30000/night)
        - Similar fields as low_budget
        - accommodation_recommendations["recommendations_by_budget"]["high"]: Full results

    Logic: Identical to low_budget variant, except:
        - Calculate accommodation_budget = total_budget_inr * 0.40
        - Store results in ["recommendations_by_budget"]["high"]

═══════════════════════════════════════════════════════════════════════════════
STAGE 4: LLM PROCESSING - ITINERARY GENERATION & VALIDATION (2 nodes)
═══════════════════════════════════════════════════════════════════════════════

File: nodes/itinerary_generator_node.py
───────────────────────────────────────

Function: itinerary_generator_node(state: TravelPlanState) -> TravelPlanState
    Stage: 4A (Itinerary Generation - LLM)
    File: nodes/itinerary_generator_node.py
    Workflow Position: After trip_complexity_analyzer
    Next Node: itinerary_validator_and_reviser_node

    Purpose: Generate comprehensive day-by-day itinerary using LLM

    Agent: ItineraryGeneratorLLMAgent
    LLM Model: Gemini 2.5-flash-lite
    Temperature: 0.7 (balanced creativity and factuality)
    Max Tokens: 2000

    Parameters: state (TravelPlanState with all trip details)
    Returns: TravelPlanState (with itinerary and related fields)

    State Updates:
        - itinerary: Dict with day_1...day_N keys (activities, costs)
        - trip_highlights: List of key attractions and experiences
        - contingency_plans: List of backup plans
        - itinerary_tips: List of tips for trip execution
        - daily_schedule: Detailed schedule by day
        - itinerary_analysis_complete: Boolean (True)

    Logic:
        1. Build Gemini client
        2. Build trip_profile from state (destination, duration, interests, etc.)
        3. Instantiate ItineraryGeneratorLLMAgent
        4. Call agent.generate_itinerary(trip_profile)
        5. Extract JSON response with itinerary structure
        6. Update state with:
           - itinerary (day-by-day breakdown)
           - trip_highlights (key activities)
           - contingency_plans (backup options)
           - itinerary_tips (practical advice)
           - daily_schedule (organized schedule)
        7. Set itinerary_analysis_complete = True
        8. Return modified state

File: nodes/itinerary_revision_node.py
──────────────────────────────────────

Function: itinerary_validator_and_reviser_node(state: TravelPlanState) -> TravelPlanState
    Stage: 4B (Itinerary Validation & Revision - LLM)
    File: nodes/itinerary_revision_node.py
    Workflow Position: After itinerary_generator_node
    Next Node: local_insights_node

    Purpose: Validate itinerary quality and optionally revise if needed

    Agent: Uses LLM directly via GeminiClient (not a separate agent class)
    LLM Model: Gemini 2.5-flash-lite
    Two-step process: VALIDATION + OPTIONAL REVISION

    Parameters: state (TravelPlanState with itinerary and complexity_score)
    Returns: TravelPlanState (with validated/revised itinerary)

    State Updates:
        - itinerary: Updated if revision occurs
        - trip_highlights: Updated if revision occurs
        - contingency_plans: Updated if revision occurs
        - itinerary_validation_score: Float (0.0-1.0)
        - itinerary_validation_issues: List of issues found
        - itinerary_revision_count: Integer (0, 1, or 2)
        - itinerary_revised: Boolean (True if revised, False otherwise)
        - itinerary_analysis_complete: Boolean (True)

    STEP 1 - VALIDATION (Always executed):
        Purpose: Assess quality of itinerary
        Temperature: 0.5 (factual validation)

        Logic:
        1. Build validation prompt with itinerary details
        2. Call client.generate_content(prompt, temperature=0.5)
        3. Extract JSON: {is_valid, validation_score, issues, suggestions,
                         revision_needed}
        4. Update itinerary_validation_score and itinerary_validation_issues

    STEP 2 - CONDITIONAL REVISION (Only if needed AND within limit):
        Purpose: Improve itinerary if issues found and revisions allowed
        Temperature: 0.7 (creative improvements)

        Revision Limits (based on complexity_score):
        - If complexity_score > 0.7: max_revisions = 2
        - If complexity_score <= 0.7: max_revisions = 1

        Logic:
        1. Check if revision_needed = True (from validation)
        2. Check if revision_count < max_revisions
        3. If both true:
           a. Build revision prompt with issues from validation
           b. Call client.generate_content(prompt, temperature=0.7)
           c. Extract revised: {itinerary, highlights, contingency_plans}
           d. Update state with revised content
           e. Increment itinerary_revision_count
           f. Set itinerary_revised = True
        4. Set itinerary_analysis_complete = True
        5. Return modified state

═══════════════════════════════════════════════════════════════════════════════
STAGE 5: LLM PROCESSING - LOCAL INSIGHTS & BOOKING (2 Sequential Nodes)
═══════════════════════════════════════════════════════════════════════════════

File: nodes/local_insights_node.py
──────────────────────────────────

Function: local_insights_node(state: TravelPlanState) -> TravelPlanState
    Stage: 5A (Local Insights - LLM with Adaptive Prompting)
    File: nodes/local_insights_node.py
    Workflow Position: After itinerary_validator_and_reviser_node
    Next Node: booking_strategy_node

    Purpose: Generate local knowledge with adaptive content based on accommodation

    Agent: LocalInsightsLLMAgent
    LLM Model: Gemini 2.5-flash-lite
    Temperature: 0.8 (more creative exploration)
    Max Tokens: 2000

    Adaptive Prompting:
        - Adjusts guidance based on accommodation_type (Budget, Mid-range, Luxury)
        - Budget accommodations: Focus on money-saving, free attractions
        - Mid-range: Balanced approach
        - Luxury: Focus on premium experiences

    Parameters: state (TravelPlanState with trip and accommodation)
    Returns: TravelPlanState (with local insights)

    State Updates:
        - hidden_gems: List of Dict (lesser-known attractions)
        - local_food_spots: List of Dict (restaurants, food experiences)
        - neighborhoods_to_explore: List of Dict (interesting areas)
        - local_etiquette_tips: List of cultural guidelines
        - money_saving_hacks: List of cost-saving strategies
        - free_or_cheap_attractions: List of budget options
        - avoid_tourist_traps: List of things to avoid
        - best_times_to_avoid_crowds: Dict with timing guidance
        - insights_analysis_complete: Boolean (True)

    Logic:
        1. Build Gemini client
        2. Extract accommodation_type for adaptive prompting
        3. Build trip_profile with accommodation context
        4. Instantiate LocalInsightsLLMAgent
        5. Call agent.get_local_insights(trip_profile, itinerary)
        6. Extract JSON with all insight categories
        7. Update state with all insights fields
        8. Set insights_analysis_complete = True
        9. Return modified state

File: nodes/booking_strategy_node.py
────────────────────────────────────

Function: booking_strategy_node(state: TravelPlanState) -> TravelPlanState
    Stage: 5B (Booking Strategy - LLM - FINAL NODE)
    File: nodes/booking_strategy_node.py
    Workflow Position: After local_insights_node (LAST node in workflow)
    Next Node: None (workflow finish point)

    Purpose: Generate booking logistics and travel planning guidance

    Agent: BookingStrategyLLMAgent
    LLM Model: Gemini 2.5-flash-lite
    Temperature: 0.6 (lower - more factual/logical)
    Max Tokens: 2000

    Parameters: state (TravelPlanState with trip and accommodation)
    Returns: TravelPlanState (with booking strategy)

    State Updates:
        - flight_booking_strategy: Dict (platforms, timing, costs, tips)
        - accommodation_booking_strategy: Dict (platforms, neighborhoods, tips)
        - activity_booking_strategy: Dict (booking guidance)
        - visa_requirements: Dict (requirements, processing time, docs)
        - budget_optimization_tips: List of money-saving strategies
        - booking_checklist: List of pre-trip to-dos
        - packing_checklist: Dict (organized by category)
        - emergency_contingency_plans: Dict (contacts, backup arrangements)
        - booking_analysis_complete: Boolean (True)

    Logic:
        1. Build Gemini client
        2. Build trip_profile from state
        3. Instantiate BookingStrategyLLMAgent
        4. Call agent.get_booking_strategy(trip_profile)
        5. Extract JSON with all booking/strategy information
        6. Update state with all fields
        7. Set booking_analysis_complete = True
        8. Return modified state

    Note: This is the FINAL node - marks workflow completion

5.3 WORKFLOW ORCHESTRATION FUNCTIONS

Function: build_trip_planning_graph() -> CompiledGraph
    Purpose: Build 12-node LangGraph state machine with conditional routing
    Parameters: None
    Returns: CompiledGraph (ready for execution)
    Logic:
        1. Initialize StateGraph with TravelPlanState
        2. Add 12 nodes (input, normalizer, budget, routers, accommodations x3,
                        complexity, itinerary, revision, insights, booking)
        3. Set entry point: input_parser
        4. Add sequential edges: parser->normalizer->budget->router
        5. Add conditional edges: router->accommodations (based on tier)
        6. Add convergence edges: all accommodations->complexity
        7. Add sequential edges: complexity->itinerary->revision->insights->booking
        8. Set finish point: booking
        9. Compile graph and return

Function: route_by_budget(state: TravelPlanState) -> str
    Purpose: Conditional routing function to select accommodation node
    Parameters: state (TravelPlanState with daily_budget_tier)
    Returns: str (node name to route to)
    Logic:
        1. Extract daily_budget_tier from state
        2. If tier == "low_budget_path": return "accommodation_recommender_low_budget"
        3. Elif tier == "high_budget_path": return "accommodation_recommender_high_budget"
        4. Else: return "accommodation_recommender_mid_budget"

5.4 ENTRY POINT FUNCTIONS

Function: plan_trip(destination: str, trip_duration_days: int,
                   total_budget_inr: int, group_size: int,
                   primary_interest: str, secondary_interest: str,
                   travel_season: str) -> Dict
    Purpose: Main API entry point for complete trip planning workflow
    Parameters:
        destination (str): Selected from 17 valid cities
        trip_duration_days (int): 2-30
        total_budget_inr (int): 5000-500000
        group_size (int): 1-10
        primary_interest (str): From INTERESTS list
        secondary_interest (str): From SECONDARY_INTERESTS list or "None"
        travel_season (str): Peak, Moderate, or Off-season
    Returns: Dict (complete TravelPlanState with 62 fields)
    Logic:
        1. Construct form_data dict from parameters
        2. Call get_initial_state(form_data)
        3. Add metadata: plan_id (UUID), analysis_timestamp (ISO format)
        4. Build workflow graph
        5. Execute graph.invoke(state)
        6. Set plan_generated = True on success
        7. Return final state
        On exception: Set error_occurred=True, plan_generated=False, return partial state

Function: get_trip_summary(assessment_result: Dict) -> Dict
    Purpose: Extract condensed summary from complete assessment
    Parameters: assessment_result (Dict from plan_trip())
    Returns: Dict with user_profile, budget_summary, accommodation, statuses, system
    Logic:
        1. Extract and organize user input fields
        2. Extract and organize budget percentages
        3. Extract accommodation details
        4. Extract completion status flags
        5. Extract system information (plan_id, timestamp, errors)
        6. Return organized summary dict

Function: get_workflow_info() -> Dict
    Purpose: Return workflow structure metadata
    Parameters: None
    Returns: Dict with workflow information
    Logic: Delegate to workflow module function


========================================================================
SECTION 6: ML PIPELINE FUNCTIONS
========================================================================

Function: train_pipeline(data_dir: str = "data",
                        model_dir: str = "ml/models") -> Dict
    Purpose: Orchestrate complete ML training workflow
    Parameters:
        data_dir (str): Root data directory
        model_dir (str): Model artifact output directory
    Returns: Dict with status and step results
    Logic:
        1. Call clean_budget_data()
        2. Call clean_accommodation_data()
        3. Call train_budget_allocator()
        4. Call train_accommodation_recommender()
        5. Collect results and return status

Function: train_budget_allocator(data_file: str,
                                model_dir: str) -> Dict
    Purpose: Train RandomForest Regressor for budget allocation
    Parameters:
        data_file (str): Path to cleaned budget CSV
        model_dir (str): Output directory for artifacts
    Returns: Dict with model info and metrics
    Logic:
        1. Load CSV data
        2. Separate features (9) and targets (6 percentages)
        3. Label encode categorical features
        4. StandardScale all features
        5. Train RandomForestRegressor (n_estimators=100, max_depth=10)
        6. Evaluate on training set (R2, RMSE)
        7. Save 3 pickle artifacts (model, scaler, encoder)
        8. Return status and metrics

Function: train_accommodation_recommender(data_file: str,
                                         model_dir: str) -> Dict
    Purpose: Train RandomForest Classifier for accommodation
    Parameters:
        data_file (str): Path to cleaned accommodation CSV
        model_dir (str): Output directory for artifacts
    Returns: Dict with model info and metrics
    Logic:
        1. Load CSV data
        2. Separate features (9) and target (accommodation_type 0-3)
        3. Label encode categorical features
        4. StandardScale all features
        5. Train RandomForestClassifier (n_estimators=100, max_depth=10,
                                       class_weight="balanced")
        6. Evaluate on training set (Accuracy, F1 score)
        7. Save 3 pickle artifacts
        8. Return status and metrics

Function: clean_budget_data(input_file: str,
                           output_file: str) -> Dict
    Purpose: Clean and validate budget allocation dataset
    Parameters:
        input_file (str): Raw CSV path
        output_file (str): Cleaned CSV output path
    Returns: Dict with cleaning results
    Logic:
        1. Load CSV
        2. Fill missing values with mode
        3. Validate: sum of 6 budget percentages in [99.9, 100.1]
        4. Remove rows with invalid sums
        5. Save cleaned data to output path
        6. Return original count, cleaned count, rows removed

Function: clean_accommodation_data(input_file: str,
                                  output_file: str) -> Dict
    Purpose: Clean and validate accommodation dataset
    Parameters:
        input_file (str): Raw CSV path
        output_file (str): Cleaned CSV output path
    Returns: Dict with cleaning results and class distribution
    Logic:
        1. Load CSV
        2. Fill missing values with mode
        3. Validate target: accommodation_type in [0, 1, 2, 3]
        4. Remove invalid rows
        5. Calculate class distribution
        6. Save cleaned data
        7. Return statistics including class distribution

Function: evaluate_all_models(project_root: str = None) -> Dict
    Purpose: Evaluate models on evaluation datasets
    Parameters:
        project_root (str, optional): Project root directory
    Returns: Dict with metrics for both models
    Logic:
        Budget Allocator Evaluation:
            1. Load evaluation CSV
            2. Load model artifacts
            3. Extract features and targets
            4. Predict on test set
            5. Normalize predictions to sum to 100
            6. Calculate MAPE (Mean Absolute Percentage Error)
            7. Calculate RMSE and MAE

        Accommodation Recommender Evaluation:
            1. Load evaluation CSV
            2. Load model artifacts
            3. Extract features and target
            4. Predict on test set
            5. Calculate Accuracy
            6. Calculate Precision, Recall, F1 (weighted)

        Return: Dict with both model metrics and sample counts


========================================================================
SECTION 7: UTILITY FUNCTIONS
========================================================================

Function: _get_all_api_keys() -> List[str]
    Purpose: Retrieve all available Gemini API keys for rotation
    Parameters: None
    Returns: List of str (unique API keys)
    Logic:
        1. Try importing Streamlit
        2. Check Streamlit secrets for GEMINI_API_KEY_1..4
        3. Check environment variables for GEMINI_API_KEY
        4. Check environment variables for GEMINI_API_KEY_1..4
        5. Accumulate unique keys
        6. Return list

Function: _get_first_api_key() -> Optional[str]
    Purpose: Get first available API key (backwards compatibility)
    Parameters: None
    Returns: Optional[str]
    Logic:
        1. Call _get_all_api_keys()
        2. Return first element or None if empty

Function: _clean_json_text(text: str) -> str
    Purpose: Remove Markdown fences from LLM response
    Parameters: text (str)
    Returns: str (cleaned text)
    Logic:
        1. Strip whitespace from text
        2. Remove ```json and ``` wrappers using regex
        3. Return cleaned text

Function: _strip_trailing_commas(text: str) -> str
    Purpose: Remove trailing commas before } or ] (common LLM error)
    Parameters: text (str)
    Returns: str (corrected JSON text)
    Logic:
        1. Loop until no more changes
        2. Use regex to find and replace ,} or ,]
        3. Replace with just } or ]
        4. Return corrected text


========================================================================
SECTION 8: UI DESIGN
========================================================================

8.1 STREAMLIT APPLICATION OVERVIEW

Framework: Streamlit (Web UI framework)
Page Title: "YatraAI - Travel Itinerary & Accommodation Optimizer"
Layout: Wide (max width utilization)
Sidebar State: Expanded

8.2 INPUT SECTION (Sidebar)

Header: "Trip Details"

Input Fields (7 total):
    1. Destination
       Type: Selectbox
       Options: 17 valid cities
       Default: First city
       Help: "Select your travel destination"

    2. Trip Duration
       Type: Slider
       Range: 2-30 days
       Default: 7 days
       Step: 1
       Help: "How many days do you plan to travel?"

    3. Total Budget
       Type: Number Input
       Min: 5000
       Max: 500000
       Default: 50000
       Step: 5000
       Help: "Total budget in Indian Rupees"

    4. Group Size
       Type: Slider
       Range: 1-10 people
       Default: 2
       Step: 1
       Help: "How many people are traveling?"

    5. Primary Interest
       Type: Selectbox
       Options: [Adventure, Cultural, Beach, Spiritual, Food, Heritage]
       Help: "What is your main interest?"

    6. Secondary Interest
       Type: Selectbox
       Options: [None, Adventure, Cultural, Beach, Spiritual, Food, Heritage]
       Help: "Any secondary interests?"

    7. Travel Season
       Type: Selectbox
       Options: [Peak, Moderate, Off-season]
       Help: "When do you plan to travel?"

8.3 ACTION BUTTONS

Button Group: Main area below sidebar inputs

Generate Plan Button
    Location: Left column
    Action: Calls plan_trip() with form inputs
    Display: Shows spinner "Generating your personalized travel plan..."
    Result: Stores in session_state.assessment_result

Clear Button
    Location: Middle column
    Action: Clears assessment_result
    Display: Reruns application

Model Evaluation Button
    Location: Right column in Tab 7
    Action: Calls evaluate_all_models()
    Display: Shows spinner "Loading evaluation metrics..."

8.4 RESULT DISPLAY (7 Tabs)

Tab 1: Overview
    Content:
        - 4 metric cards: Destination, Duration, Total Budget, Group Size
        - 2-column layout:
            Left: Trip Preferences (interests, season)
            Right: Accommodation (type, confidence, cost/night)
    Visualization: Text metrics and cards

Tab 2: Budget
    Content:
        - Bar chart: 6 budget categories as percentages
        - 2-column layout:
            Left: Budget Percentages (text list, 1 decimal place)
            Right: Absolute Amounts (formatted currency)
        - Info box: Daily Budget
    Visualization: Bar chart, text, formatted currency

Tab 3: Accommodation
    Content:
        - 2-column layout:
            Left: Recommended Accommodation metrics (Type, Confidence %, Comfort Score, Cost/Night)
            Right: Recommendation Details text
        - Expandable section: Alternative Options (if alternatives exist)
            Each alternative: Type, Confidence %, Cost/Night
    Visualization: Metric cards, expanders

Tab 4: Itinerary
    Content:
        - Expandable section for each day (day_1...day_N)
            Each day expander contains:
                - Day title
                - Numbered activities list
                - Divider
                - Estimated cost for that day (formatted currency)
        - Trip Highlights section: Bulleted list
        - Tips for Success section: Bulleted list of tips for successful trip execution
        - Contingency Plans section: Bulleted list of backup plans for trip disruptions
    Visualization: Expanders, text, formatted currency

Tab 5: Local Insights
    Content:
        - 2-column layout:
            Left: Hidden Gems (expanders with name, category, neighborhood,
                  description, why hidden)
            Right: Local Food Spots (expanders with name, cuisine, price range,
                   signature dish)
        - Neighborhoods to Explore: Bulleted list with vibe and how to spend time
        - Money Saving Hacks: Bulleted list
        - Free or Cheap Attractions: Bulleted list of budget-friendly places
        - Best Times to Avoid Crowds: Information about peak hours and quiet times
        - Things to Avoid: Bulleted list
    Visualization: Expanders, bulleted lists

Tab 6: Booking Strategy
    Content:
        - 2-column layout:
            Left: Flight Booking Strategy
                  - Platforms list
                  - Booking window
                  - Best days
                  - Estimated cost range
                  - Money-saving tips list
            Right: Accommodation Booking Strategy
                   - Platforms list
                   - Booking window
                   - Neighborhoods recommended list
                   - Estimated cost/night
                   - Money-saving tips list
        - Activity Booking Strategy: Platforms, best booking times, estimated costs
        - Visa Requirements: Required/not required, processing times, documentation needed
        - Pre-Departure Checklist: Bulleted list
        - Budget Optimization Tips: Bulleted list
        - Packing Essentials: Organized by category (clothing, documents, tech, toiletries)
        - Emergency Contingency Plans: Contact numbers, alternative arrangements, support info
    Visualization: Text fields, lists

Tab 7: Model Evaluation
    Content:
        - Load Evaluation button
        - 2-column metric display (if loaded):
            Left: Budget Allocator Model
                  - MAPE (%) metric
                  - RMSE metric
                  - MAE metric
                  - Test sample count
            Right: Accommodation Recommender Model
                   - Accuracy metric
                   - Precision metric
                   - Recall metric
                   - Test sample count
        - Info box if not yet loaded
    Visualization: Metric cards

8.5 STYLING

CSS Applied:
    - Main padding: 2rem
    - Tab font size: 1.1rem
    - Metric boxes: Light background, left blue border, padding, rounded corners
    - Headings H1: Blue color, bottom border
    - Headings H2: Blue color, top margin

8.6 ERROR DISPLAY

Error Handling:
    - If error_occurred in result:
        Display: Red error box with message
        Content: "Error generating plan. Please check your inputs and try again."
        Details: List all error_messages

8.7 SESSION STATE MANAGEMENT

Streamlit Session Variables:
    - assessment_result: Stores plan_trip() output
    - eval_results: Stores evaluate_all_models() output


========================================================================
SECTION 9: EXECUTION FLOW AND COMMANDS
========================================================================

9.1 COMPLETE EXECUTION WORKFLOW

Step 1: Environment Setup
    Command: pip install -r requirements.txt
    Purpose: Install all dependencies
    Dependencies:
        - langgraph
        - langchain
        - streamlit
        - pandas
        - numpy
        - scikit-learn
        - google-generativeai
        - python-dotenv
        - pytest

Step 2: Configuration
    File: .env (create in project root)
    Contents:
        GEMINI_API_KEY=<your-api-key>
        GEMINI_API_KEY_1=<backup-key-1>
        GEMINI_API_KEY_2=<backup-key-2>
        GEMINI_API_KEY_3=<backup-key-3>
        GEMINI_API_KEY_4=<backup-key-4>
        GEMINI_MODEL=gemini-2.5-flash-lite

Step 3: Data Cleaning
    Command: python -m ml.data_cleaning.clean_budget_data
    Purpose: Clean budget allocation training data
    Input: data/training_dataset/budget_allocation_training.csv
    Output: data/processed/budget_allocation_clean.csv

    Command: python -m ml.data_cleaning.clean_accommodation_data
    Purpose: Clean accommodation training data
    Input: data/training_dataset/accommodation_recommender_training.csv
    Output: data/processed/accommodation_recommender_clean.csv

Step 4: Model Training
    Command: python -m ml.train_pipeline
    Purpose: Complete training workflow
    Steps:
        1. Clean budget data
        2. Clean accommodation data
        3. Train budget allocator model
        4. Train accommodation recommender model
    Outputs:
        - ml/models/budget_allocator_model.pkl
        - ml/models/budget_allocator_scaler.pkl
        - ml/models/budget_allocator_encoder.pkl
        - ml/models/accommodation_recommender_model.pkl
        - ml/models/accommodation_recommender_scaler.pkl
        - ml/models/accommodation_recommender_encoder.pkl

Step 5: Model Evaluation
    Command: python -c "from ml.evaluation.evaluate_models import evaluate_all_models; evaluate_all_models()"
    Purpose: Evaluate trained models on test data
    Output: Metrics (MAPE for budget, Accuracy/Precision/Recall for accommodation)

Step 6: Run Tests
    Command: pytest tests.py -v
    Purpose: Execute 18 test cases
    Coverage: ML agents, LLM agents, state, routers, workflows, data persistence
    Output: Pass/fail status for each test

Step 7: End-to-End Workflow Test
    Command: python run_full_workflow.py
    Purpose: Test complete workflow with sample data
    Output: Sample trip plan in console

Step 8: Launch Streamlit UI
    Command: streamlit run main.py
    Purpose: Launch web application
    Access: http://localhost:8501
    Interaction: Fill form, click "Generate Plan", view results in tabs

9.2 INDIVIDUAL COMPONENT EXECUTION

Direct Agent Usage:
    Python: from agents.budget_allocator_ml import BudgetAllocatorMLAgent
            agent = BudgetAllocatorMLAgent()
            result = agent.allocate_budget(trip_profile_dict)

Direct Workflow Execution:
    Python: from graph import plan_trip
            result = plan_trip(destination="Jaipur", trip_duration_days=5,
                             total_budget_inr=100000, group_size=2,
                             primary_interest="Cultural",
                             secondary_interest="Food",
                             travel_season="Peak")

9.3 TROUBLESHOOTING COMMANDS

Check Model Files:
    Command: ls -la ml/models/
    Purpose: Verify all 6 model files exist

Check Data Files:
    Command: ls -la data/processed/
    Purpose: Verify cleaned datasets exist

Verify API Key Setup:
    Command: python -c "from utils.gemini_client import _get_first_api_key; print(_get_first_api_key())"
    Purpose: Check if API key properly configured

Check Dependencies:
    Command: pip list | grep -E "langgraph|langchain|streamlit|scikit-learn"
    Purpose: Verify required packages installed


========================================================================
SECTION 10: OUTPUT AND RESULTS
========================================================================

10.1 PLAN_TRIP() OUTPUT STRUCTURE

Complete Return Dict (94 fields):

    INPUT FIELDS:
        destination: "Jaipur" (str)
        trip_duration_days: 5 (int)
        total_budget_inr: 100000 (int)
        group_size: 2 (int)
        primary_interest: "Cultural" (str)
        secondary_interest: "Food" (str)
        travel_season: "Peak" (str)

    DERIVED FIELDS:
        destination_cost_tier: "Tier-2" (str)
        accommodation_preference: "Mid-range" (str)
        parsed_profile: {...} (Dict)
        validation_errors: [] (List)
        parsing_complete: True (bool)

    BUDGET OUTPUTS:
        accommodation_budget_pct: 30.2 (float)
        food_dining_budget_pct: 24.8 (float)
        activities_attractions_budget_pct: 24.5 (float)
        local_transport_budget_pct: 10.1 (float)
        shopping_misc_budget_pct: 7.2 (float)
        contingency_budget_pct: 3.2 (float)
        daily_budget: 20000.0 (float)
        budget_allocation: {
            "accommodation": 30200.0,
            "food_dining": 24800.0,
            "activities_attractions": 24500.0,
            "local_transport": 10100.0,
            "shopping_misc": 7200.0,
            "contingency": 3200.0
        } (Dict)

    DECISION OUTPUTS:
        daily_budget_tier: "high_budget_path" (str)
        complexity_score: 0.427 (float)

    ACCOMMODATION OUTPUTS:
        accommodation_type: "Luxury" (str)
        accommodation_class: 2 (int)
        accommodation_confidence: 70.5 (float)
        estimated_cost_per_night: 19000.0 (float)
        accommodation_alternatives: [
            {
                "type": "Mid-range",
                "class": 1,
                "confidence": 20.3,
                "estimated_cost_per_night": 3500.0
            }
        ] (List)
        accommodation_recommendations: {
            "recommendations_by_budget": {
                "high": {...recommendation details...}
            }
        } (Dict)

    ITINERARY OUTPUTS:
        itinerary: {
            "day_1": {
                "title": "Arrival and Exploration",
                "activities": [
                    "Arrive at Jaipur",
                    "Check into luxury accommodation",
                    "Local market visit",
                    "Dinner at premium restaurant"
                ],
                "estimated_cost": 5000
            },
            "day_2": {...},
            "day_3": {...},
            "day_4": {...},
            "day_5": {
                "title": "Departure",
                "activities": [
                    "Final shopping",
                    "Checkout",
                    "Departure"
                ],
                "estimated_cost": 2000
            }
        } (Dict)
        trip_highlights: [
            "Hawa Mahal at sunrise",
            "City Palace heritage tour",
            "Local food festival experience",
            "Jaipur Old City bazaar exploration"
        ] (List)
        contingency_plans: [
            "Alternative accommodation available",
            "Backup transportation options",
            "Emergency contact numbers"
        ] (List)
        itinerary_analysis_complete: True (bool)
        itinerary_validation_score: 0.92 (float)
        itinerary_validation_issues: [] (List)
        itinerary_revision_count: 0 (int)
        itinerary_revised: False (bool)

    LOCAL INSIGHTS OUTPUTS:
        hidden_gems: [
            {
                "name": "Govind Dev Ji Temple",
                "description": "Lesser-known spiritual site",
                "estimated_cost": "Free",
                "tips": ["Visit early morning", "Respectful dress required"]
            },
            {...more gems...}
        ] (List)
        local_food_spots: [
            {
                "name": "Laxmi Mishthan Bhandar",
                "cuisine": "Rajasthani",
                "price_range": "Moderate",
                "signature_dish": "Ghoongri Aloo"
            },
            {...more spots...}
        ] (List)
        neighborhoods_to_explore: [
            {
                "name": "Old City",
                "vibe": "Historic and bustling",
                "how_to_spend_time": ["Shopping", "Photography", "Food tasting"]
            },
            {...more neighborhoods...}
        ] (List)
        local_etiquette_tips: [
            "Remove shoes before entering temples",
            "Respectful dress in religious sites",
            "Bargaining expected in markets"
        ] (List)
        money_saving_hacks: [
            "Use auto-rickshaws instead of taxis",
            "Eat at local food stalls",
            "Visit museums on free entry days"
        ] (List)
        insights_analysis_complete: True (bool)

    BOOKING STRATEGY OUTPUTS:
        flight_booking_strategy: {
            "recommended_platforms": ["MakeMyTrip", "Goibibo", "Cleartrip"],
            "booking_window": "2-4 weeks before travel",
            "best_days_to_book": "Tuesday-Thursday",
            "estimated_cost_range": "5000-8000",
            "money_saving_tips": [
                "Book early morning",
                "Use flight comparison tools",
                "Check budget airlines"
            ]
        } (Dict)
        accommodation_booking_strategy: {
            "recommended_platforms": ["Booking.com", "OYO", "Airbnb"],
            "booking_window": "2-3 weeks before travel",
            "neighborhoods_recommended": ["C-Scheme", "Tonk Road"],
            "estimated_cost_per_night": "2000-5000",
            "money_saving_tips": [
                "Book directly with hotel",
                "Check for discounts",
                "Use loyalty programs"
            ]
        } (Dict)
        transportation_tips: [
            "Pre-book transport from airport",
            "Use local transport apps",
            "Consider group rides"
        ] (List)
        visa_requirements: {
            "required": False,
            "processing_time": "N/A"
        } (Dict)
        budget_optimization_tips: [
            "Allocate 30% for accommodation as planned",
            "Focus on local food experiences",
            "Visit free attractions",
            "Negotiate activity prices"
        ] (List)
        booking_checklist: [
            "Book flights",
            "Book accommodation",
            "Arrange transport",
            "Book activities"
        ] (List)
        booking_analysis_complete: True (bool)

    SYSTEM METADATA:
        plan_id: "a1b2c3d4-e5f6-7890-abcd-ef1234567890" (str, UUID)
        analysis_timestamp: "2024-12-15T10:30:45.123456" (str, ISO format)
        plan_generated: True (bool)
        error_occurred: False (bool)
        error_messages: [] (List)

10.2 STREAMLIT UI OUTPUT DISPLAY

When user clicks "Generate Plan", Streamlit displays:

Tab 1 - Overview:
    Shows 4 metric cards with trip basics
    Shows preferences and accommodation recommendation

Tab 2 - Budget:
    Displays bar chart of 6 budget categories
    Shows percentages and absolute amounts
    Shows daily budget summary

Tab 3 - Accommodation:
    Displays primary recommendation with metrics
    Shows alternative options if available

Tab 4 - Itinerary:
    Shows expandable days with activities
    Shows estimated cost per day
    Shows trip highlights

Tab 5 - Local Insights:
    Shows hidden gems with details
    Shows food spots with recommendations
    Shows money-saving tips

Tab 6 - Booking Strategy:
    Shows flight booking guidance
    Shows accommodation booking guidance
    Shows pre-departure checklist
    Shows budget optimization tips

Tab 7 - Model Evaluation:
    Shows budget allocator: MAPE, RMSE, MAE
    Shows accommodation recommender: Accuracy, Precision, Recall

10.3 TEST OUTPUT

Command: pytest tests.py -v

Expected Output (18/18 passing):
    test_budget_allocator_output_structure PASSED [5%]
    test_budget_allocator_percentages_sum_to_100 PASSED [11%]
    test_accommodation_recommender_output_structure PASSED [16%]
    test_accommodation_recommender_different_budgets PASSED [22%]
    test_itinerary_generator_structure PASSED [27%]
    test_local_insights_structure PASSED [33%]
    test_booking_strategy_structure PASSED [38%]
    test_itinerary_revision_output PASSED [44%]
    test_initial_state_creation PASSED [50%]
    test_state_validation PASSED [55%]
    test_budget_feasibility_router_low_budget PASSED [61%]
    test_budget_feasibility_router_high_budget PASSED [66%]
    test_budget_allocation_complete_workflow PASSED [72%]
    test_accommodation_recommendation_workflow PASSED [77%]
    test_trip_complexity_analyzer_workflow PASSED [83%]
    test_accommodation_alternatives_available PASSED [88%]
    test_ml_models_exist PASSED [94%]
    test_evaluation_datasets_exist PASSED [100%]

    ====== 18 passed in 2.35s ======

10.4 ERROR HANDLING EXAMPLES

Example 1: Invalid Budget
    Input: total_budget_inr = 1000 (below 5000 minimum)
    Output:
        plan_generated: False
        error_occurred: True
        error_messages: ["Budget must be between Rs 5,000 and Rs 5,00,000"]
        parsing_complete: False

Example 2: API Quota Exceeded
    Situation: Gemini API quota exceeded
    Handling:
        1. GeminiClient detects quota error (429)
        2. Rotates to next API key
        3. Retries with new key
        4. If all keys exhausted, raises error

Example 3: Model File Missing
    Situation: accommodation_recommender_model.pkl not found
    Handling:
        accommodation_recommender_node catches exception
        Appends error message
        Sets error_occurred = True
        Returns partial state

10.5 PERFORMANCE METRICS

Typical Execution Times:
    Input parsing: 0.05 seconds
    Budget allocation: 0.3 seconds
    Accommodation recommendation: 0.25 seconds
    Itinerary generation (LLM): 8-12 seconds
    Itinerary validation (LLM): 3-5 seconds
    Local insights (LLM): 5-8 seconds
    Booking strategy (LLM): 5-8 seconds
    Total workflow: 22-40 seconds

Model Performance:
    Budget Allocator MAPE: ~0.12% (excellent)
    Budget Allocator RMSE: ~0.08
    Accommodation Recommender Accuracy: ~0.91 (91%)
    Accommodation Recommender Precision: ~0.90
    Accommodation Recommender Recall: ~0.91

10.6 SUCCESS CRITERIA VALIDATION

A successful YatraAI execution includes:

    a) Input Validation: All 7 inputs validated against constraints
    b) Budget Allocation: 6 percentages sum to 100 (+/- 1%)
    c) Accommodation Recommendation: Classification with >85% confidence
    d) Itinerary Generation: Valid day-by-day activities with costs
    e) Itinerary Validation: Validation score >0.8
    f) Local Insights: At least 5 gems, 5 food spots, 3+ tips
    g) Booking Strategy: Recommendations for flights, accommodation, logistics
    h) No Critical Errors: error_occurred = False
    i) Plan Generated: plan_generated = True
    j) All Output Fields: 90+ fields populated (excluding optional)


========================================================================
SECTION 11: APPENDIX
========================================================================

11.1 CONSTANTS AND THRESHOLDS

Numeric Ranges:
    Budget: 5,000 - 5,00,000 INR
    Duration: 2 - 30 days
    Group Size: 1 - 10 people
    Trip Complexity Score: 0.0 - 1.0

Daily Budget Tiers:
    Low: < 7,000 INR (30% accommodation allocation)
    Mid: 7,000 - 14,999 INR (35% allocation)
    High: >= 15,000 INR (40% allocation)

Itinerary Revisions:
    If complexity_score > 0.7: Maximum 2 revisions allowed
    If complexity_score <= 0.7: Maximum 1 revision allowed

ML Model Thresholds:
    Accommodation confidence > 10%: Show as alternative
    Interest encoding: Aggregative (Adventure=1, Cultural=2, Beach=4,
                                   Spiritual=8, Food=16, Heritage=32)

11.2 SUPPORTED DESTINATIONS (17)

    Jaipur, Goa, Delhi, Mumbai, Bangalore, Udaipur, Varanasi, Kolkata,
    Agra, Kerala, Pune, Lucknow, Rishikesh, Rajasthan (non-GT),
    Himachal Pradesh, Northeast India, Hyderabad

11.3 SUPPORTED INTERESTS (6)

    Adventure, Cultural, Beach, Spiritual, Food, Heritage

11.4 SUPPORTED TRAVEL SEASONS (3)

    Peak, Moderate, Off-season

11.5 ACCOMMODATION TYPES (4)

    Budget (Rs 500-1500/night)
    Mid-range (Rs 2000-5000/night)
    Luxury (Rs 8000-30000/night)
    Alternative (Rs 2500-6000/night)

11.6 DEPENDENCIES

Core Framework:
    langgraph >= 0.0.1
    langchain >= 0.1.0
    streamlit >= 1.28.0

Data Processing:
    pandas >= 2.0.0
    numpy >= 1.24.0

Machine Learning:
    scikit-learn >= 1.3.0

API Integration:
    google-generativeai >= 0.3.0

Environment:
    python-dotenv >= 1.0.0

Testing:
    pytest >= 7.4.0

11.7 SYSTEM REQUIREMENTS

Minimum:
    Python 3.9+
    4GB RAM
    Stable internet connection (for Gemini API)
    Gemini API key

Recommended:
    Python 3.11+
    8GB RAM
    High-speed internet (for LLM responsiveness)
    Multiple API keys (for redundancy)


========================================================================
END OF PROFESSIONAL DOCUMENTATION
========================================================================

Document Version: 1.0
Created: December 2024
Format: Professional Technical Documentation
Total Sections: 11
Total Pages: Comprehensive

This documentation provides complete understanding of YatraAI system
architecture, implementation details, execution flows, and operational
guidance without revealing actual code implementation.

