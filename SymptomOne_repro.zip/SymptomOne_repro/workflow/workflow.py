"""Workflow Orchestration - JSON-based assessment execution"""

import uuid
from typing import Dict, Any, Optional
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))

from graph import run_symptom_one_workflow


class SymptomOneWorkflow:
    """Orchestrator for LangGraph workflow execution with JSON input"""

    def __init__(self):
        """Initialize workflow orchestrator"""
        self.output_dir = Path("output")
        self.output_dir.mkdir(exist_ok=True)

    def run_workflow(self, patient_data: Dict[str, Any], session_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Execute LangGraph workflow with complete JSON patient data

        Args:
            patient_data: Complete patient data dictionary (all 11 clinical fields)
            session_id: Optional session ID (auto-generated if not provided)

        Returns:
            Complete assessment result from LangGraph workflow
        """
        try:
            if session_id is None:
                session_id = str(uuid.uuid4())

            print(f"[Workflow] Executing assessment for session: {session_id}")

            # Execute simplified 12-node LangGraph workflow
            result = run_symptom_one_workflow(patient_data, session_id)

            return result

        except Exception as e:
            print(f"[Workflow Error] {str(e)}")
            import traceback
            traceback.print_exc()
            return {
                "error": str(e),
                "status": "failed",
                "session_id": session_id
            }


# Global workflow instance for Streamlit
workflow_instance = SymptomOneWorkflow()
