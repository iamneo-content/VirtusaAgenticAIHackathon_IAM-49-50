"""SymptomOne - Medical Assessment System (Professional UI)"""
import streamlit as st
import json
import os
from pathlib import Path
import sys
from datetime import datetime

sys.path.insert(0, str(Path(__file__).parent))

from workflow import workflow_instance
from ml.evaluation import evaluate_all_models


# Page Configuration
st.set_page_config(
    page_title="SymptomOne",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for professional styling
st.markdown("""
<style>
    /* Main container styling */
    .main {
        padding: 2rem 1rem;
    }

    /* Header styling */
    .header-container {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 2rem;
        border-radius: 10px;
        color: white;
        margin-bottom: 2rem;
    }

    .header-container h1 {
        margin: 0;
        font-size: 2.5rem;
        font-weight: bold;
    }

    .header-container p {
        margin: 0.5rem 0 0 0;
        font-size: 1.1rem;
        opacity: 0.9;
    }

    /* Card styling */
    .metric-card {
        background: #f8f9fa;
        padding: 1.5rem;
        border-radius: 8px;
        border-left: 4px solid #667eea;
        margin-bottom: 1rem;
    }

    /* Status badges */
    .status-badge {
        display: inline-block;
        padding: 0.4rem 0.8rem;
        border-radius: 20px;
        font-size: 0.9rem;
        font-weight: bold;
        margin-right: 0.5rem;
    }

    .severity-critical {
        background-color: #fee;
        color: #c00;
    }

    .severity-high {
        background-color: #fef3cd;
        color: #856404;
    }

    .severity-moderate {
        background-color: #fff3cd;
        color: #997404;
    }

    .severity-low {
        background-color: #d4edda;
        color: #155724;
    }

    /* Red flag styling */
    .red-flag {
        background: #fff5f5;
        border-left: 4px solid #e53e3e;
        padding: 1rem;
        margin: 0.5rem 0;
        border-radius: 4px;
    }

    /* Data table styling */
    .data-table {
        font-size: 0.95rem;
    }

    /* Success/error messages */
    .success-box {
        background: #d4edda;
        border-left: 4px solid #28a745;
        padding: 1rem;
        border-radius: 4px;
        margin-bottom: 1rem;
    }

    .error-box {
        background: #f8d7da;
        border-left: 4px solid #dc3545;
        padding: 1rem;
        border-radius: 4px;
        margin-bottom: 1rem;
    }
</style>
""", unsafe_allow_html=True)


@st.cache_data
def load_model_evaluation():
    """Load model evaluation results"""
    return evaluate_all_models()


@st.cache_data
def get_available_json_files():
    """Get list of available JSON files"""
    data_dir = Path("data/input")
    if data_dir.exists():
        files = sorted([f for f in os.listdir(data_dir) if f.endswith('.json')])
        return files
    return []


def get_severity_color(severity):
    """Return color for severity level"""
    colors = {
        "Critical": "#dc3545",
        "High": "#fd7e14",
        "Moderate": "#ffc107",
        "Low": "#28a745"
    }
    return colors.get(severity, "#6c757d")


def format_clinical_field(key):
    """Format clinical field names for display"""
    field_map = {
        "patient_age_years": "Age (years)",
        "symptom_duration_hours": "Duration (hours)",
        "fever_present": "Fever Present",
        "neck_stiffness": "Neck Stiffness",
        "body_temperature_celsius": "Temperature (C)",
        "heart_rate_bpm": "Heart Rate (bpm)",
        "blood_pressure_systolic_mmhg": "BP Systolic (mmHg)",
        "blood_pressure_diastolic_mmhg": "BP Diastolic (mmHg)",
        "respiratory_rate_breaths_per_minute": "Respiratory Rate (breaths/min)",
        "oxygen_saturation_percent": "O2 Saturation (%)",
        "comorbidities_count": "Comorbidities",
        "symptom_description": "Symptom Description"
    }
    return field_map.get(key, key.replace("_", " ").title())


# Header Section
st.markdown("""
<div class="header-container">
    <h1>SymptomOne</h1>
    <p>Advanced Medical Assessment System | AI-Powered Clinical Analysis</p>
</div>
""", unsafe_allow_html=True)

# Sidebar - Model Metrics
with st.sidebar:
    st.markdown("## Model Performance Metrics")

    eval_results = load_model_evaluation()

    if eval_results.get("status") == "success":
        # Severity Classifier Metrics
        severity_metrics = eval_results["models"]["severity_classifier"].get("metrics", {})
        if severity_metrics:
            with st.expander("Severity Classifier", expanded=True):
                col1, col2 = st.columns(2)
                with col1:
                    st.metric("Accuracy", f"{severity_metrics.get('accuracy', 0):.1%}")
                    st.metric("Precision", f"{severity_metrics.get('precision', 0):.1%}")
                with col2:
                    st.metric("Recall", f"{severity_metrics.get('recall', 0):.1%}")
                    st.metric("F1 Score", f"{severity_metrics.get('f1_score', 0):.1%}")

        # Risk Regressor Metrics
        risk_metrics = eval_results["models"]["risk_score_regressor"].get("metrics", {})
        if risk_metrics:
            with st.expander("Risk Score Regressor"):
                col1, col2 = st.columns(2)
                with col1:
                    st.metric("R2 Score", f"{risk_metrics.get('r2_score', 0):.4f}")
                    st.metric("MAE", f"{risk_metrics.get('mae', 0):.4f}")
                with col2:
                    st.metric("RMSE", f"{risk_metrics.get('rmse', 0):.4f}")

    st.markdown("---")
    st.markdown("### About SymptomOne")
    st.info("""
    **SymptomOne** is an AI-powered clinical decision support system that:
    - Analyzes patient symptoms and vital signs
    - Provides differential diagnoses
    - Generates treatment recommendations
    - Assesses clinical risk levels
    - Supports medical professionals in decision-making
    """)


# Initialize session state
if "step" not in st.session_state:
    st.session_state.step = "INPUT"
if "result" not in st.session_state:
    st.session_state.result = None
if "selected_file" not in st.session_state:
    st.session_state.selected_file = None
if "patient_data" not in st.session_state:
    st.session_state.patient_data = None


# STEP 1: File Selection and Input
if st.session_state.step == "INPUT":
    # Case Selection Section
    col1, col2 = st.columns([2, 1])

    with col1:
        st.markdown("## Patient Case Selection")
        st.markdown("Select a patient case to begin the assessment")

    available_files = get_available_json_files()

    if not available_files:
        st.error("No JSON files found in data/input/ directory")
    else:
        st.markdown(f"**{len(available_files)} patient cases available**")

        # File selection dropdown
        selected_file = st.selectbox(
            "Choose a patient case:",
            options=available_files,
            format_func=lambda x: x.replace(".json", "").replace("_", " ").title(),
            key="case_selector"
        )

        # Auto-load and display patient data
        if selected_file:
            file_path = Path("data/input") / selected_file
            with open(file_path, 'r') as f:
                patient_data = json.load(f)
                st.session_state.patient_data = patient_data

            # Display Patient Data Section
            st.markdown("---")
            st.markdown("### Patient Clinical Data")

            # Create two columns for patient data
            col1, col2, col3, col4, col5 = st.columns(5)

            # Key vital signs in cards
            with col1:
                age = patient_data.get("patient_age_years", "N/A")
                st.metric("Age", f"{age} yrs")

            with col2:
                temp = patient_data.get("body_temperature_celsius", "N/A")
                st.metric("Temperature", f"{temp}C")

            with col3:
                hr = patient_data.get("heart_rate_bpm", "N/A")
                st.metric("Heart Rate", f"{hr} bpm")

            with col4:
                rr = patient_data.get("respiratory_rate_breaths_per_minute", "N/A")
                st.metric("Resp. Rate", f"{rr}/min")

            with col5:
                o2 = patient_data.get("oxygen_saturation_percent", "N/A")
                st.metric("O2 Sat.", f"{o2}%")

            # Symptom description if available
            if patient_data.get("symptom_description"):
                st.markdown("**Patient Description:**")
                st.info(patient_data.get("symptom_description"))

            # Additional clinical data in expander
            with st.expander("View All Clinical Data", expanded=False):
                data_cols = st.columns(2)
                col_idx = 0

                for key, value in patient_data.items():
                    if key != "symptom_description":
                        with data_cols[col_idx % 2]:
                            formatted_key = format_clinical_field(key)
                            if key == "fever_present" or key == "neck_stiffness":
                                status = "Yes" if value else "No"
                                st.write(f"**{formatted_key}:** {status}")
                            else:
                                st.write(f"**{formatted_key}:** {value}")
                            col_idx += 1

            # Assessment buttons
            st.markdown("---")
            col1, col2 = st.columns(2)

            with col1:
                if st.button("Run Assessment", key="run_btn", use_container_width=True):
                    st.session_state.selected_file = selected_file
                    with st.spinner("Analyzing patient data and generating assessment..."):
                        result = workflow_instance.run_workflow(patient_data)
                        st.session_state.result = result
                        st.session_state.step = "RESULTS"
                        st.rerun()

            with col2:
                if st.button("Download Data (JSON)", key="download_btn", use_container_width=True):
                    st.download_button(
                        label="Download",
                        data=json.dumps(patient_data, indent=2),
                        file_name=f"{selected_file}",
                        mime="application/json",
                        key="download_json"
                    )


# STEP 2: Results Display
elif st.session_state.step == "RESULTS":
    result = st.session_state.result

    if result and "error" not in result:
        ui_output = result.get("ui_output", {})
        severity = ui_output.get("severity", "Unknown")
        risk_score = ui_output.get("risk_score", 0)
        risk_level = ui_output.get("risk_level", "Unknown")

        # Success Header
        color = get_severity_color(severity)
        st.markdown(f"""
        <div class="success-box">
            <h2>Assessment Complete</h2>
            <p>Analysis completed at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
        </div>
        """, unsafe_allow_html=True)

        # Key Metrics Display
        st.markdown("### Assessment Results")
        metric_cols = st.columns(4)

        with metric_cols[0]:
            st.markdown(f"""
            <div class="metric-card">
                <div style="font-size: 0.9rem; color: #666;">Severity Level</div>
                <div style="font-size: 1.5rem; font-weight: bold;">{severity}</div>
            </div>
            """, unsafe_allow_html=True)

        with metric_cols[1]:
            st.markdown(f"""
            <div class="metric-card">
                <div style="font-size: 0.9rem; color: #666;">Risk Score</div>
                <div style="font-size: 1.5rem; font-weight: bold;">{risk_score:.2f}/1.0</div>
            </div>
            """, unsafe_allow_html=True)

        with metric_cols[2]:
            st.markdown(f"""
            <div class="metric-card">
                <div style="font-size: 0.9rem; color: #666;">Risk Level</div>
                <div style="font-size: 1.5rem; font-weight: bold;">{risk_level}</div>
            </div>
            """, unsafe_allow_html=True)

        with metric_cols[3]:
            session_id = ui_output.get("session_id", "N/A")[:8]
            st.markdown(f"""
            <div class="metric-card">
                <div style="font-size: 0.9rem; color: #666;">Session ID</div>
                <div style="font-size: 1.3rem; font-family: monospace; font-weight: bold; word-break: break-all;">{session_id}</div>
            </div>
            """, unsafe_allow_html=True)

        # Tabs for detailed information
        tab1, tab2, tab3, tab4 = st.tabs(["Symptom Analysis", "Clinical Data", "Diagnosis & Treatment", "Clinical Guidance"])

        # Tab 1: Symptom Analysis
        with tab1:
            symptom_class = result.get("symptom_classification", {})
            if symptom_class and symptom_class.get("status") != "skipped":
                st.markdown("### Symptom Classification Results")

                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("Primary Symptom", symptom_class.get("primary_symptom", "N/A"))
                with col2:
                    st.metric("Onset Pattern", symptom_class.get("onset_pattern", "N/A"))
                with col3:
                    character = symptom_class.get("character", "N/A")
                    st.metric("Pain Character", character)

                # Explain what Character means
                st.caption("Character describes the quality of pain/symptom: Sharp (sudden, stabbing), Dull (constant, aching), Throbbing (pulsating), Burning, Cramping, Pressure, or Tingling")

                # Associated symptoms
                if symptom_class.get("associated_symptoms"):
                    st.markdown("**Associated Symptoms:**")
                    for symptom in symptom_class.get("associated_symptoms", []):
                        st.write(f"- {symptom}")

                # Red flags alert
                if symptom_class.get("red_flags"):
                    st.markdown("**Red Flags Identified:**")
                    for flag in symptom_class.get("red_flags", []):
                        st.markdown(f'<div class="red-flag">[WARNING] {flag}</div>', unsafe_allow_html=True)
            else:
                st.info("No symptom description provided for classification")

        # Tab 2: Clinical Data
        with tab2:
            st.markdown("### Patient Clinical Parameters")
            extracted = result.get("extracted_data", {})

            if extracted:
                # Create a structured data display
                vital_signs = {}
                for key, value in extracted.items():
                    if key != "symptom_description" and key != "symptom_type":
                        vital_signs[format_clinical_field(key)] = value

                # Display in two columns
                col_data = st.columns(2)
                keys = list(vital_signs.keys())

                for idx, (key, value) in enumerate(vital_signs.items()):
                    with col_data[idx % 2]:
                        if isinstance(value, (int, float)):
                            st.metric(key, f"{value}")
                        else:
                            st.write(f"**{key}:** {value}")
            else:
                st.write("No clinical data available")

        # Tab 3: Diagnosis and Treatment
        with tab3:
            # Check if this is a low-risk case
            risk_level = ui_output.get("risk_level", "").upper()
            differential_diagnoses = ui_output.get("differential_diagnoses", {})
            is_low_risk_path = (
                differential_diagnoses.get("status") == "low_risk_path" or
                (risk_level == "LOW" and not differential_diagnoses.get("diagnoses"))
            )

            if is_low_risk_path:
                st.info(
                    "**Low-Risk Assessment**\n\n"
                    "Since your risk score is below the clinical threshold (0.6), "
                    "detailed differential diagnosis and treatment planning are not required. "
                    "Your symptoms appear manageable with self-care and monitoring. "
                    "If symptoms persist or worsen, consult a healthcare provider."
                )
            else:
                col1, col2 = st.columns(2)

                # Differential Diagnoses
                with col1:
                    if ui_output.get("differential_diagnoses"):
                        st.markdown("### Differential Diagnoses")
                        diagnoses_dict = ui_output.get("differential_diagnoses", {})
                        diagnoses = diagnoses_dict.get("diagnoses", [])

                        if diagnoses:
                            for i, diag in enumerate(diagnoses, 1):
                                prob = diag.get('probability', 'N/A')
                                prob_color = "#dc3545" if prob == "high" else "#ffc107" if prob == "medium" else "#28a745"

                                st.markdown(f"""
                                <div style="background: #f8f9fa; padding: 1rem; border-radius: 8px; margin-bottom: 0.5rem; border-left: 4px solid {prob_color};">
                                    <strong>{i}. {diag.get('diagnosis', 'Unknown')}</strong><br>
                                    <span style="color: {prob_color}; font-weight: bold;">Probability: {prob.upper()}</span>
                                </div>
                                """, unsafe_allow_html=True)

                # Treatment Plan
                with col2:
                    if ui_output.get("treatment_plan"):
                        st.markdown("### Treatment Plan")
                        treatment_dict = ui_output.get("treatment_plan", {})

                        if treatment_dict.get("immediate_interventions"):
                            st.markdown("**Immediate Interventions:**")
                            interventions = treatment_dict.get("immediate_interventions", [])
                            if isinstance(interventions, list):
                                for intervention in interventions:
                                    st.write(f"• {intervention}")
                            else:
                                st.write(interventions)

                        if treatment_dict.get("recommended_tests"):
                            st.markdown("**Recommended Tests:**")
                            tests = treatment_dict.get("recommended_tests", [])
                            if isinstance(tests, list):
                                for test in tests:
                                    st.write(f"• {test}")
                            else:
                                st.write(tests)

                        if treatment_dict.get("medications"):
                            st.markdown("**Medications:**")
                            medications = treatment_dict.get("medications", [])
                            if isinstance(medications, list):
                                for med in medications:
                                    if isinstance(med, dict):
                                        st.write(f"• {med.get('name', 'Unknown')}: {med.get('dosage', 'N/A')} - {med.get('purpose', '')}")
                                    else:
                                        st.write(f"• {med}")
                            else:
                                st.write(medications)

                        if treatment_dict.get("monitoring_plan"):
                            st.markdown("**Monitoring Plan:**")
                            st.write(treatment_dict.get("monitoring_plan", ""))

                        if treatment_dict.get("follow_up_timeline"):
                            st.markdown("**Follow-up Timeline:**")
                            st.write(treatment_dict.get("follow_up_timeline", ""))

                        if treatment_dict.get("specialist_referrals"):
                            st.markdown("**Specialist Referrals:**")
                            referrals = treatment_dict.get("specialist_referrals", [])
                            if isinstance(referrals, list):
                                for referral in referrals:
                                    st.write(f"• {referral}")
                            else:
                                st.write(referrals)

        # Tab 4: Clinical Guidance
        with tab4:
            st.markdown("### Clinical Guidance & Recommendations")

            # Debug: Check what's in ui_output
            if not ui_output:
                st.warning("UI output is empty. Trying to get from result directly...")
                if result.get("health_advice"):
                    advice = result.get("health_advice")
                else:
                    advice = "No guidance available"
            else:
                advice = ui_output.get("health_advice", "No guidance available")

            if ui_output.get("risk_level") == "HIGH" or (result.get("risk_score", 0) >= 0.6):
                st.error(f"HIGH RISK ALERT\n\n{advice}")
            else:
                st.success(f"LOW RISK\n\n{advice}")

        # Download and Navigation
        st.markdown("---")
        st.markdown("### Report & Navigation")

        col1, col2, col3 = st.columns(3)

        with col1:
            report_json = result.get("report_json", "{}")
            st.download_button(
                label="Download Full Report (JSON)",
                data=report_json,
                file_name=f"assessment_{ui_output.get('session_id', 'report')[:8]}.json",
                mime="application/json",
                use_container_width=True
            )

        with col2:
            if st.button("New Assessment", key="new_assess", use_container_width=True):
                st.session_state.step = "INPUT"
                st.session_state.result = None
                st.session_state.selected_file = None
                st.session_state.patient_data = None
                st.rerun()

        with col3:
            if st.button("View Selected Case", key="view_case", use_container_width=True):
                with st.expander("Patient Data (JSON)"):
                    st.json(st.session_state.patient_data)

    else:
        # Error Display
        error_msg = result.get('error', 'Unknown error') if result else 'No result'
        st.markdown(f"""
        <div class="error-box">
            <h3>Assessment Failed</h3>
            <p>Error: {error_msg}</p>
        </div>
        """, unsafe_allow_html=True)

        if st.button("Try Again", use_container_width=True):
            st.session_state.step = "INPUT"
            st.session_state.result = None
            st.rerun()
