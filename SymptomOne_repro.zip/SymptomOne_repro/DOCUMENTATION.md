SYMPTOMONE - COMPREHENSIVE PROJECT DOCUMENTATION
===============================================


SECTION 1: PROBLEM DESCRIPTION
==============================

Problem Statement
=================

The healthcare industry requires efficient clinical decision support systems that can rapidly assess patient symptoms and provide risk-stratified recommendations. Current systems either rely entirely on manual clinical assessment (time-consuming) or oversimplified heuristic approaches (lacking clinical nuance). SymptomOne addresses this gap by creating an AI-powered medical assessment system that combines machine learning for rapid quantitative assessment with large language models for nuanced clinical reasoning.

The specific problem SymptomOne solves:

1. Rapid symptom assessment from structured patient data (11 clinical parameters)
2. Intelligent risk stratification to determine appropriate clinical pathway
3. Context-aware differential diagnosis generation for high-risk cases
4. Personalized treatment planning and clinical guidance based on risk level
5. Professional medical interface for emergency/urgent care settings

Project Objective
=================

Build a web-based medical assessment system that:

1. Accepts JSON-formatted patient data (age, vitals, symptoms, comorbidities)
2. Classifies symptom severity using trained machine learning models
3. Calculates clinical risk score to determine patient acuity
4. Routes patients to appropriate clinical pathways (high-risk requiring full diagnostic workup vs low-risk requiring reassurance)
5. Generates AI-powered clinical recommendations through LLM agents
6. Provides professional Streamlit UI for visualization and report generation
7. Persists assessment results to disk for archival and audit trails

Core Innovation
===============

SymptomOne combines two complementary AI approaches:

1. Machine Learning (RandomForest) for fast, objective quantitative assessment:
   - Severity classification from vital signs
   - Risk score prediction from clinical parameters

2. Large Language Models (Google Gemini) for nuanced qualitative reasoning:
   - Symptom classification and categorization
   - Differential diagnosis generation
   - Treatment plan formulation
   - Risk-appropriate clinical guidance

The system uses conditional routing at risk score threshold 0.6 to branch into two distinct clinical pathways, optimizing resource allocation and clinical appropriateness.


SECTION 2: FILE STRUCTURE
=========================

Complete Directory Tree
=======================

SymptomOne_repro/
├── state.py                                   [TypedDict state schema]
├── graph.py                                   [LangGraph workflow orchestration]
├── main.py                                    [Streamlit web UI application]
├── tests.py                                   [Comprehensive test suite]
│
├── agents/                                    [AI Agent Implementations]
│   ├── __init__.py
│   ├── base_llm_agent.py                      [Base class for LLM agents]
│   ├── symptom_classifier_llm.py              [Symptom classification agent]
│   ├── differential_diagnosis_llm.py          [Differential diagnosis agent]
│   ├── treatment_plan_llm.py                  [Treatment planning agent]
│   ├── health_advice_llm.py                   [Clinical guidance agent]
│   ├── severity_assessment_ml.py              [ML-based severity classifier]
│   └── risk_score_ml.py                       [ML-based risk score regressor]
│
├── nodes/                                     [LangGraph Workflow Nodes (13 nodes)]
│   ├── __init__.py
│   ├── user_input_node.py                     [Node 1: Input validation]
│   ├── symptom_classifier_node.py             [Node 2: Symptom classification]
│   ├── severity_assessment_node.py            [Node 3: Severity assessment]
│   ├── risk_score_assessment_node.py          [Node 4: Risk score calculation]
│   ├── risk_path_router_node.py               [Node 5: Risk-based routing]
│   ├── differential_diagnosis_node.py         [Node 6: Diagnosis generation (high-risk)]
│   ├── treatment_plan_node.py                 [Node 7: Treatment planning (high-risk)]
│   ├── high_risk_advice_node.py               [Node 8: Urgent guidance (high-risk)]
│   ├── low_risk_advice_node.py                [Node 9: Reassurance (low-risk)]
│   ├── report_compilation_node.py             [Node 10: Report aggregation]
│   ├── validation_node.py                     [Node 11: Output validation]
│   ├── save_report_node.py                    [Node 12: Report persistence]
│   └── output_formatting_node.py              [Node 13: UI formatting]
│
├── workflow/                                  [Workflow Orchestration]
│   ├── __init__.py
│   └── workflow.py                            [Workflow executor & orchestrator]
│
├── ml/                                        [Machine Learning Pipeline]
│   ├── __init__.py
│   ├── train_pipeline.py                      [ML training orchestrator]
│   │
│   ├── train_model/                           [Model Training Scripts]
│   │   ├── __init__.py
│   │   ├── train_severity_model.py            [Severity classifier training]
│   │   └── train_risk_score_model.py          [Risk regressor training]
│   │
│   ├── cleaning/                              [Data Preprocessing Scripts]
│   │   ├── __init__.py
│   │   ├── clean_severity_data.py             [Severity data cleaning & balancing]
│   │   └── clean_risk_score_data.py           [Risk score data cleaning]
│   │
│   ├── evaluation/                            [Model Evaluation Scripts]
│   │   ├── __init__.py
│   │   └── evaluate_models.py                 [Model performance metrics]
│   │
│   └── models/                                [Trained Model Artifacts]
│       ├── severity_classifier.pkl            [Severity RandomForest model]
│       ├── severity_scaler.pkl                [Severity feature scaler]
│       ├── risk_score_regressor.pkl           [Risk score RandomForest model]
│       └── risk_score_scaler.pkl              [Risk score feature scaler]
│
├── utils/                                     [Utility Modules]
│   ├── __init__.py
│   └── gemini_client.py                       [Google Gemini API client]
│
├── data/                                      [Data Directory]
│   ├── training_dataset/                      [Raw Training Data]
│   │   ├── severity_training.csv              [Severity classification training data]
│   │   └── risk_score_training.csv            [Risk score regression training data]
│   │
│   ├── processed/                             [Cleaned & Preprocessed Data]
│   │   ├── severity_cleaned.csv               [Cleaned severity training data]
│   │   └── risk_score_cleaned.csv             [Cleaned risk score training data]
│   │
│   ├── evaluation_dataset/                    [Model Evaluation Data]
│   │   ├── severity_eval.csv                  [Severity model evaluation data]
│   │   └── risk_score_eval.csv                [Risk score model evaluation data]
│   │
│   └── input/                                 [Patient Test Cases]
│       ├── user_query_1.json                  [Sample patient case 1]
│       ├── user_query_2.json                  [Sample patient case 2]
│       └── ... (30 total patient cases)
│
├── output/                                    [Generated Assessment Reports]
│   ├── {session_id_1}.json                    [Assessment report 1]
│   ├── {session_id_2}.json                    [Assessment report 2]
│   └── ... (generated on workflow execution)
│
├── .env                                       [Environment variables & API keys]
└── installation.txt                           [Installation & dependency instructions]



SECTION 3: PURPOSE OF FILES
============================

ROOT LEVEL FILES
================

state.py
--------
Purpose: Define and manage workflow state schema using TypedDict

Responsibilities:
1. Define SymptomOneState with 15 fields tracking data flow through workflow
2. Specify types for all state fields (strings, dicts, lists, floats)
3. Provide create_initial_state function to instantiate state from JSON patient data
4. Ensure type safety across 13-node workflow execution

Key State Fields:
- session_id: Unique identifier for each assessment (UUID format)
- extracted_data: Patient's 11 clinical input fields
- severity_level: ML-predicted severity classification
- risk_score: ML-predicted numerical risk (0.0-1.0)
- differential_diagnoses: LLM-generated diagnoses list
- treatment_plan: LLM-generated treatment recommendations
- health_advice: LLM-generated clinical guidance
- ui_output: Formatted output for Streamlit display
- validation_status: Workflow validation result
- report_json: Complete assessment as JSON string


graph.py
--------
Purpose: Construct and orchestrate 13-node LangGraph workflow

Responsibilities:
1. Define conditional routing logic based on risk score threshold
2. Create complete workflow graph with three execution phases
3. Wire 13 nodes into connected directed acyclic graph (DAG)
4. Handle both high-risk and low-risk execution paths
5. Manage state propagation through workflow

Workflow Phases:
- Phase 1 (Common): Input validation → symptom classification → severity assessment → risk scoring → routing
- Phase 2 (Conditional): Either full diagnostic workup (high-risk) or reassurance path (low-risk)
- Phase 3 (Convergence): Report compilation → validation → persistence → formatting

Key Functions:
- route_based_on_risk: Returns routing decision based on risk_score >= 0.6 threshold
- create_symptom_one_graph: Constructs and compiles complete workflow
- run_symptom_one_workflow: Executes workflow with patient data


main.py
-------
Purpose: Provide professional Streamlit web interface for SymptomOne assessment

Responsibilities:
1. Display patient case selection and vital signs overview
2. Execute workflow on user request
3. Present assessment results in tabbed, professional format
4. Enable report download in JSON format
5. Implement caching for model evaluation metrics
6. Provide navigation between input and results views

UI Components:
- Case selector dropdown to choose sample patient
- Vital signs cards displaying key clinical parameters
- Assessment button to trigger workflow execution
- Results tabs: Symptom Analysis, Clinical Data, Diagnosis & Treatment, Clinical Guidance
- Report download button
- Model performance metrics sidebar

Features:
- Custom CSS styling with medical color scheme
- Professional badges for severity levels
- Red flag warning displays
- Risk-appropriate content (low-risk shows reassurance, high-risk shows urgent alert)


workflow/workflow.py
--------------------
Purpose: Orchestrate workflow execution with error handling wrapper

Responsibilities:
1. Wrap graph.py workflow execution with try-except error handling
2. Generate session ID if not provided
3. Persist output directory for report storage
4. Return structured result or error dictionary

Key Class:
- SymptomOneWorkflow: Manages workflow execution with error recovery


AGENTS DIRECTORY
================

agents/base_llm_agent.py
------------------------
Purpose: Provide base class for all LLM agents with common initialization

Responsibilities:
1. Encapsulate GeminiClient initialization
2. Provide inheritance foundation for all LLM agents
3. Handle client creation and management

Key Class:
- BaseLLMAgent: Base class for SymptomClassifierLLMAgent, DifferentialDiagnosisLLMAgent, etc.


agents/symptom_classifier_llm.py
--------------------------------
Purpose: Classify free-text symptom descriptions into structured medical categories using LLM

Responsibilities:
1. Accept patient symptom description and clinical context
2. Call Google Gemini LLM to classify symptoms
3. Extract structured classification (primary symptom, onset pattern, red flags, etc.)
4. Provide primary symptom for ML model feature engineering

Input Processing:
- Accepts free-text symptom_description from patient
- Supplements with vital signs context (temperature, heart rate, duration, etc.)
- Provides clinical context to guide LLM classification

Output Structure:
Dictionary containing:
- primary_symptom: Classified symptom type (Headache, Chest Pain, Abdominal Pain, etc.)
- severity_descriptor: Perceived severity (Mild, Moderate, Severe, Critical)
- associated_symptoms: List of related symptoms mentioned
- onset_pattern: How symptom started (Sudden, Gradual, Chronic)
- character: Description of pain/discomfort (Sharp, Dull, Throbbing, etc.)
- location: Anatomical location (if applicable)
- red_flags: List of concerning features requiring urgent attention
- confidence: Confidence level of classification (high, medium, low)


agents/differential_diagnosis_llm.py
------------------------------------
Purpose: Generate differential diagnoses ranked by likelihood using LLM

Responsibilities:
1. Accept clinical presentation (vitals, symptoms, severity)
2. Call Gemini LLM to generate potential diagnoses
3. Rank diagnoses by probability
4. Provide reasoning for each diagnosis

Input Processing:
- Extracts clinical presentation from 11 vital signs
- Includes symptom classification results if available
- Provides severity level for context
- Formats complete clinical picture for LLM

Output Structure:
Dictionary containing:
- diagnoses: List of diagnosis objects, each with:
  - diagnosis: Condition name
  - probability: Likelihood ranking (high, medium, low)
  - reasoning: Brief clinical explanation for diagnosis

Clinical Context:
- Typically generates 5-7 diagnoses
- Ordered by probability from high to low
- Considers patient age, vital signs, symptom pattern


agents/treatment_plan_llm.py
----------------------------
Purpose: Generate comprehensive treatment plans for high-risk cases using LLM

Responsibilities:
1. Accept clinical data and differential diagnoses
2. Call Gemini LLM to formulate treatment plan
3. Generate immediate interventions, tests, medications, monitoring
4. Provide specialist referral recommendations

Input Processing:
- Uses top diagnoses from differential diagnosis node
- Includes severity level and symptom type
- References vital signs for appropriate dosing context

Output Structure:
Dictionary containing:
- immediate_interventions: List of emergency actions
- recommended_tests: Diagnostic tests to order
- medications: List of medication objects with:
  - name: Drug name
  - dosage: Dosage instructions
  - purpose: Why medication prescribed
- monitoring_plan: Ongoing monitoring requirements
- follow_up_timeline: When to reassess patient
- specialist_referrals: Specialists to consult


agents/health_advice_llm.py
---------------------------
Purpose: Generate personalized clinical guidance appropriate to risk level using LLM

Responsibilities:
1. Generate context-aware health advice
2. Differentiate between high-risk and low-risk guidance
3. Provide patient-appropriate instructions
4. Include warning signs and follow-up guidance

Guidance Types:

For HIGH-RISK cases (risk_score >= 0.6):
- Urgent alerts and emergency instructions
- Hospitalization expectations
- Immediate action requirements
- Red flags requiring emergency return

For LOW-RISK cases (risk_score < 0.6):
- Reassuring tone and symptom normalization
- Self-care recommendations
- Over-the-counter options
- When to seek further care
- Typical symptom timeline


agents/severity_assessment_ml.py
--------------------------------
Purpose: Classify clinical symptom severity using trained RandomForest machine learning model

Responsibilities:
1. Load pre-trained severity classification model
2. Load feature scaling model (StandardScaler)
3. Accept 11 clinical parameters
4. Predict severity level from vital signs
5. Map numerical prediction to clinical category

Model Details:
- Algorithm: RandomForest Classifier with 100 estimators
- Features: 11 vital signs and demographics
- Target: 4-class classification (Critical, High, Moderate, Low)
- Preprocessing: StandardScaler normalization

Input Processing:
- Accepts dictionary with 11 clinical fields
- Handles missing values by converting to 0.0
- Scales features using pre-trained scaler
- Predicts using trained model

Output:
String severity level: Low, Moderate, High, or Critical


agents/risk_score_ml.py
-----------------------
Purpose: Predict numerical clinical risk score using trained RandomForest regression model

Responsibilities:
1. Load pre-trained risk score regression model
2. Load feature scaling model
3. Accept 11 clinical parameters
4. Predict numerical risk score (0.0-1.0)
5. Clip predictions to valid range

Model Details:
- Algorithm: RandomForest Regressor with 100 estimators
- Features: Same 11 vital signs as severity model
- Target: Continuous numerical value (0.0-1.0)
- Preprocessing: StandardScaler normalization

Input Processing:
- Accepts dictionary with 11 clinical fields
- Builds feature vector in consistent order
- Handles missing values via np.nan_to_num
- Scales using pre-trained scaler
- Predicts regression value
- Clips to [0.0, 1.0] range for probability interpretation

Output:
Float value representing risk (0.0=no risk, 1.0=maximum risk)

Risk Score Interpretation:
- >= 0.6: HIGH-RISK pathway (full diagnostic workup)
- < 0.6: LOW-RISK pathway (reassurance and monitoring)


NODES DIRECTORY
===============

nodes/user_input_node.py
------------------------
Purpose: Validate completeness of JSON patient input data

Node Position: Node 1 (Entry point)

Responsibilities:
1. Verify all 11 required clinical fields present
2. Record validation errors if fields missing
3. Pass state to next node regardless of validation

Required Fields Checked:
1. patient_age_years (integer, 0-120)
2. symptom_duration_hours (integer, 0-720)
3. fever_present (binary, 0 or 1)
4. neck_stiffness (binary, 0 or 1)
5. body_temperature_celsius (float, 35.0-42.0)
6. heart_rate_bpm (integer, 30-200)
7. blood_pressure_systolic_mmhg (integer, 60-200)
8. blood_pressure_diastolic_mmhg (integer, 40-120)
9. respiratory_rate_breaths_per_minute (integer, 8-40)
10. oxygen_saturation_percent (float, 70-100)
11. comorbidities_count (integer, 0-10)

Logic:
1. Extract extracted_data from state
2. Iterate through required field names
3. Check if each field exists in extracted_data
4. Accumulate missing fields
5. Append error message to validation_errors if any missing
6. Return state unchanged (errors recorded for later review)

Returns:
Modified state with validation_errors populated if any fields missing


nodes/symptom_classifier_node.py
--------------------------------
Purpose: Classify symptom description into structured medical categories using LLM

Node Position: Node 2

Responsibilities:
1. Extract symptom_description from patient input
2. Call SymptomClassifierLLMAgent for LLM-based classification
3. Store full classification result in state
4. Extract primary symptom for ML model feature engineering
5. Handle cases where symptom description not provided

Logic:
1. Get symptom_description from extracted_data (optional field)
2. If empty or not provided:
   - Set symptom_classification status to "skipped"
   - Return state unmodified
3. If provided:
   - Create SymptomClassifierLLMAgent instance
   - Call classify_symptoms with description and clinical context
   - Store full LLM response in symptom_classification
   - Extract primary_symptom from classification
   - Store primary_symptom in extracted_data as symptom_type (for ML models)
   - Log classification details

Returns:
State with:
- symptom_classification: Full LLM classification object
- extracted_data[symptom_type]: Primary symptom string for ML


nodes/severity_assessment_node.py
---------------------------------
Purpose: Assess symptom severity using machine learning model

Node Position: Node 3

Responsibilities:
1. Create SeverityAssessmentMLAgent instance
2. Call ML model to predict severity from vital signs
3. Store severity classification in state
4. Aggregate result in ml_results dictionary

Logic:
1. Instantiate SeverityAssessmentMLAgent (loads pre-trained model)
2. Call predict_severity_classification passing extracted_data
3. Receive severity_level string (Low, Moderate, High, or Critical)
4. Store severity_level in state
5. Update ml_results dictionary with severity value
6. Log prediction result

Returns:
State with:
- severity_level: Classification string
- ml_results[severity]: Same classification value


nodes/risk_score_assessment_node.py
-----------------------------------
Purpose: Calculate clinical risk score using machine learning model

Node Position: Node 4

Responsibilities:
1. Create RiskScoreMLAgent instance
2. Call ML model to predict risk score from vital signs
3. Store numerical risk score in state (0.0-1.0 range)
4. Aggregate result in ml_results dictionary

Logic:
1. Instantiate RiskScoreMLAgent (loads pre-trained regressor)
2. Call predict_clinical_risk_score passing extracted_data
3. Receive float risk_score (guaranteed in 0.0-1.0 range)
4. Store risk_score in state
5. Update ml_results with risk_score value
6. Log risk score with three decimal precision

Returns:
State with:
- risk_score: Float in range [0.0, 1.0]
- ml_results[risk_score]: Same value


nodes/risk_path_router_node.py
------------------------------
Purpose: Determine clinical pathway based on risk score threshold

Node Position: Node 5

Responsibilities:
1. Evaluate risk_score against 0.6 threshold
2. Determine appropriate clinical pathway
3. Record pathway decision in state
4. Prepare for conditional routing in graph

Logic:
1. Extract risk_score from state (default 0.5 if missing)
2. Compare against threshold 0.6:
   - If risk_score >= 0.6: Set path to "high_risk_path"
   - If risk_score < 0.6: Set path to "low_risk_path"
3. Store path decision in state[risk_path]
4. Log routing decision with rationale
5. Return state

Note: This node records the routing decision. The actual conditional branch in graph.py uses route_based_on_risk function to determine next node.

Returns:
State with:
- risk_path: String indicating selected pathway


nodes/differential_diagnosis_node.py
-----------------------------------
Purpose: Generate differential diagnoses for high-risk patients

Node Position: Node 6

Execution Condition: HIGH-RISK ONLY (risk_score >= 0.6)
- This node is only reached if risk score >= 0.6
- Bypassed entirely for low-risk patients

Responsibilities:
1. Create DifferentialDiagnosisLLMAgent instance
2. Call LLM to generate diagnoses based on clinical presentation
3. Include symptom classification context if available
4. Store ranked diagnosis list in state

Logic:
1. Instantiate DifferentialDiagnosisLLMAgent
2. Extract diagnoses list if symptom_classification available
3. Call assess_differential_diagnoses passing:
   - extracted_data: Clinical vitals
   - severity_level: ML-predicted severity
   - symptom_classification: LLM symptom analysis (optional)
4. Receive diagnoses list with probability rankings
5. Store in state[differential_diagnoses]
6. Log count of diagnoses generated

Returns:
State with:
- differential_diagnoses: Dictionary containing:
  - diagnoses: List of diagnosis objects with diagnosis name, probability, reasoning


nodes/treatment_plan_node.py
---------------------------
Purpose: Generate treatment plan for high-risk patients

Node Position: Node 7

Execution Condition: HIGH-RISK ONLY (risk_score >= 0.6)
- This node is only reached if risk score >= 0.6
- Bypassed entirely for low-risk patients

Responsibilities:
1. Create TreatmentPlanLLMAgent instance
2. Call LLM to generate comprehensive treatment plan
3. Use top diagnoses for clinical context
4. Store treatment plan in state

Logic:
1. Instantiate TreatmentPlanLLMAgent
2. Extract diagnoses list from differential_diagnoses (default empty if missing)
3. Call generate_comprehensive_treatment_plan passing:
   - extracted_data: Patient vitals
   - severity_level: Clinical severity
   - differential_diagnoses: List of top diagnoses (for LLM context)
4. Receive treatment plan object with interventions, tests, medications, monitoring
5. Store in state[treatment_plan]
6. Log treatment plan generation confirmation

Returns:
State with:
- treatment_plan: Dictionary containing:
  - immediate_interventions: List of urgent actions
  - recommended_tests: List of diagnostic tests
  - medications: List of medication objects (name, dosage, purpose)
  - monitoring_plan: Ongoing monitoring requirements
  - follow_up_timeline: Reassessment schedule
  - specialist_referrals: Specialist consultations needed


nodes/high_risk_advice_node.py
------------------------------
Purpose: Generate urgent clinical guidance for high-risk patients

Node Position: Node 8

Execution Condition: HIGH-RISK ONLY (risk_score >= 0.6)
- Executed after treatment planning on high-risk pathway
- Bypassed for low-risk patients

Responsibilities:
1. Create HealthAdviceLLMAgent instance
2. Call LLM with is_high_risk=True flag
3. Generate urgent, emergency-appropriate guidance
4. Store guidance text in state

Logic:
1. Instantiate HealthAdviceLLMAgent
2. Extract diagnoses list from differential_diagnoses
3. Call provide_clinical_guidance passing:
   - extracted_data: Patient vitals
   - risk_score: Numerical risk value
   - severity_level: Clinical severity
   - is_high_risk: Set to True (triggers urgent guidance)
   - diagnoses: Top diagnosis list for context
4. Receive urgent guidance text
5. Store in state[health_advice]
6. Log confirmation

Guidance Content for High-Risk:
- CRITICAL ALERT formatting
- Immediate action requirements
- Emergency department directions
- Hospital admission expectations
- Red flags requiring emergency return

Returns:
State with:
- health_advice: String containing urgent clinical guidance


nodes/low_risk_advice_node.py
-----------------------------
Purpose: Generate reassuring clinical guidance for low-risk patients

Node Position: Node 9

Execution Condition: LOW-RISK ONLY (risk_score < 0.6)
- Executed immediately after routing for low-risk patients
- Bypassed for high-risk patients

Responsibilities:
1. Create HealthAdviceLLMAgent instance
2. Call LLM with is_high_risk=False flag
3. Generate reassuring, patient-appropriate guidance
4. Explicitly mark diagnosis/treatment as low-risk pathway (not error)
5. Store guidance text in state

Logic:
1. Instantiate HealthAdviceLLMAgent
2. Call provide_clinical_guidance passing:
   - extracted_data: Patient vitals
   - risk_score: Numerical risk value
   - severity_level: Clinical severity
   - is_high_risk: Set to False (triggers reassuring guidance)
   - diagnoses: Omitted for low-risk
3. Receive reassuring guidance text
4. Store in state[health_advice]
5. Mark diagnosis/treatment as intentionally skipped:
   - If differential_diagnoses is None:
     Set to {"status": "low_risk_path", "diagnoses": []}
   - If treatment_plan is None:
     Set to {"status": "low_risk_path"}
6. Log confirmation

Guidance Content for Low-Risk:
- Reassuring tone normalizing symptoms
- Self-care recommendations
- Over-the-counter medication options
- Warning signs requiring doctor visit
- Typical symptom timeline and resolution

Status Markers:
- Distinguished from errors by "status": "low_risk_path"
- Allows UI to show "diagnosis not needed" vs "error occurred"

Returns:
State with:
- health_advice: String containing reassuring clinical guidance
- differential_diagnoses: Marked with low_risk_path status
- treatment_plan: Marked with low_risk_path status


nodes/report_compilation_node.py
--------------------------------
Purpose: Aggregate all assessment results into comprehensive report dictionary

Node Position: Node 10

Execution Condition: CONVERGENCE (both pathways)
- Reached by both high-risk and low-risk pathways
- Acts as convergence point for parallel execution paths

Responsibilities:
1. Aggregate assessment data from all prior nodes
2. Create comprehensive report object
3. Store report in state for persistence and display

Logic:
1. Extract all key assessment results:
   - severity_level
   - risk_score
   - differential_diagnoses (with status if low-risk)
   - treatment_plan (with status if low-risk)
   - health_advice
   - extracted_data (original vitals)
2. Create report dictionary containing all results
3. Store in state[report]
4. Log report creation confirmation

Report Contents:
- All clinical assessments (severity, risk)
- All clinical analysis (diagnoses, treatment, advice)
- Original patient data
- Ready for validation, persistence, and display

Returns:
State with:
- report: Dictionary aggregating all key assessment results


nodes/validation_node.py
-----------------------
Purpose: Validate completeness and quality of final assessment output

Node Position: Node 11

Execution Condition: Both pathways
- All assessments converge here for final validation

Responsibilities:
1. Check presence of critical assessment fields
2. Record validation status
3. Accumulate any validation errors or warnings
4. Allow workflow to complete with errors recorded (non-blocking)

Logic:
1. Define critical required fields:
   - severity_level
   - risk_score
   - health_advice
   - report
2. Check each field for presence and non-empty value
3. Identify missing_fields list
4. If missing_fields exist:
   - Set validation_status to "warning"
   - Append error message to validation_errors list
5. If all fields present:
   - Set validation_status to "valid"
6. Log validation result
7. Return state unchanged

Returns:
State with:
- validation_status: "valid" or "warning"
- validation_errors: Appended with any validation messages


nodes/save_report_node.py
------------------------
Purpose: Persist comprehensive assessment report to disk as JSON file

Node Position: Node 12

Execution Condition: Both pathways
- Executed after validation for both high and low-risk patients

Responsibilities:
1. Create output directory if not exists
2. Build comprehensive report dictionary
3. Write report to JSON file with session ID as filename
4. Store report as JSON string in state for download
5. Create audit trail for assessment archival

Logic:
1. Create output/ directory if not present
2. Get session_id from state
3. Get current timestamp
4. Build comprehensive report object containing:
   - session_id: Unique assessment identifier
   - timestamp: ISO format datetime
   - patient_data: Extracted vitals with completion percentage
   - assessment: Severity, risk score, risk level
   - clinical_analysis: Diagnoses, treatment, advice (with status if low-risk)
   - validation: Status and error list
5. Generate filename: output/{session_id}.json
6. Write report to file with indent=2 for readability
7. Store JSON string in state[report_json] for browser download
8. Store filepath in state[report_file_path]
9. Log success with filepath

Returns:
State with:
- report_file_path: String path to saved JSON file
- report_json: Complete report as JSON string (for download button)


nodes/output_formatting_node.py
------------------------------
Purpose: Format assessment results for Streamlit UI display

Node Position: Node 13 (Final node)

Execution Condition: Both pathways
- Final processing before returning to UI

Responsibilities:
1. Extract and format key metrics for UI display
2. Calculate risk level from risk score
3. Create UI-ready output dictionary
4. Prepare data for tabbed display interface

Logic:
1. Extract key values:
   - session_id
   - severity_level
   - risk_score
   - differential_diagnoses
   - treatment_plan
   - health_advice
   - validation_status
   - validation_errors
2. Calculate risk_level:
   - "HIGH" if risk_score >= 0.6
   - "LOW" if risk_score < 0.6
3. Create ui_output dictionary:
   - session_id: Assessment identifier
   - severity: Severity level string
   - risk_score: Numerical risk
   - risk_level: HIGH or LOW
   - completion_percentage: 100.0 (always complete in JSON mode)
   - health_advice: Guidance text
   - differential_diagnoses: Diagnosis list (or low_risk_path marker)
   - treatment_plan: Treatment recommendations (or low_risk_path marker)
   - validation_status: Validation result
   - validation_errors: Error list
   - status: "completed"
4. Store in state[ui_output]
5. Log confirmation

UI Display Features:
- Status markers ("low_risk_path") distinguish intentional skipping from errors
- Risk level determines UI color scheme in Streamlit
- Completion percentage always 100.0 (no progressive updates)

Returns:
State with:
- ui_output: Dictionary containing all fields formatted for web UI


UTILITIES DIRECTORY
===================

utils/gemini_client.py
----------------------
Purpose: Manage interaction with Google Gemini LLM API with robust error handling and key rotation

Responsibilities:
1. Load and manage multiple API keys for quota handling
2. Initialize Google Gemini client
3. Generate text and JSON responses from LLM
4. Automatically rotate API keys on quota exhaustion
5. Robustly extract JSON from LLM responses with fallback strategies

Class: GeminiClient

Constructor Parameters:
- model: Optional string specifying model name (default: "gemini-2.5-flash-lite")
  - Can also be set via GEMINI_MODEL environment variable
  - Used when calling Gemini API

Initialization Logic:
1. Load API keys from environment:
   - Checks for GEMINI_API_KEY_1, GEMINI_API_KEY_2, GEMINI_API_KEY_3, GEMINI_API_KEY_4
   - Falls back to GEMINI_API_KEY if numbered keys not found
   - Raises error if no API keys found
2. Set current_key_index = 0 (starts with first key)
3. Initialize genai client with first API key
4. Store model name for API calls

Important Methods:

Method 1: _generate_content
Purpose: Generate content from Gemini with automatic key rotation on quota
Parameters:
- prompt: String input prompt text
- temperature: Float between 0 and 1 (default 0.7) controlling response variability
- max_tokens: Integer maximum output length (default 2000)
Returns: String containing generated text response

Logic:
1. Set max_retries equal to number of available API keys
2. Loop with retry counter:
   a. Create generation_config with temperature and max_tokens
   b. Call appropriate API (new or legacy based on availability)
   c. Extract and return response text if successful
   d. If quota error (429, rate limit, per_minute, per_day):
      - Attempt to rotate to next API key
      - Retry with new key
   e. If non-quota error:
      - Raise error immediately without retry
3. After exhausting all keys:
   - Raise error indicating no keys available

Method 2: _extract_json_from_response
Purpose: Extract JSON object from LLM response with robust fallback parsing
Parameters:
- response_text: String containing raw LLM response (may include markdown, invalid JSON, etc.)
Returns: Dictionary containing parsed JSON

Logic:
1. Clean response text:
   - Strip whitespace
   - Remove markdown code fences (```json, ```)
2. Create list of candidate strings to attempt parsing:
   - Add cleaned text
   - Extract {...} pattern using regex
3. For each candidate string:
   a. Remove trailing commas before closing brackets/braces
   b. Attempt json.loads() parsing
   c. Validate result is dictionary (not list or string)
   d. If successful: return parsed dictionary
   e. If JSONDecodeError: try next candidate
4. If all candidates fail:
   - Try extracting nested {...} objects
   - Return last successfully extracted object
5. If all strategies fail:
   - Raise ValueError with detailed error message

Fallback Strategies Handle:
- Markdown-wrapped JSON (```json {...} ```)
- Trailing commas in JSON objects
- Nested JSON structures
- Partially valid JSON

Method 3: generate_json
Purpose: Generate and parse JSON response from Gemini
Parameters:
- prompt: String prompt requesting JSON output
Returns: Dictionary containing parsed JSON response

Logic:
1. Call _generate_content with prompt
2. Call _extract_json_from_response on returned text
3. Return parsed dictionary

Method 4: generate_text
Purpose: Generate plain text response from Gemini
Parameters:
- prompt: String input prompt
Returns: String containing generated text

Logic:
1. Call _generate_content with prompt
2. Return raw text response

Error Handling:
- API key rotation automatic on quota errors
- No immediate failure on single key exhaustion
- Detailed error messages for debugging
- Non-blocking: agents catch exceptions and set defaults


MACHINE LEARNING PIPELINE DIRECTORY
====================================

ml/train_pipeline.py
--------------------
Purpose: Orchestrate complete machine learning model training pipeline

Function: run_training_pipeline
Parameters: None
Returns: Boolean (True if both models train successfully, False otherwise)

Logic:
1. Print pipeline header message
2. Train severity classification model:
   a. Call train_severity_model()
   b. Store success result
3. Train risk score regression model:
   a. Call train_risk_score_model()
   b. Store success result
4. Evaluate both models:
   a. Call evaluate_all_models()
   b. Print evaluation results
5. If both models trained successfully:
   a. Print success message
   b. List output model files
   c. Return True
6. If either model failed:
   a. Print failure message
   b. Return False

Error Handling:
- Try-except wraps entire function
- Prints traceback on exception
- Returns False on any failure
- Non-fatal: does not raise exceptions


ml/cleaning/clean_severity_data.py
----------------------------------
Purpose: Clean and balance severity classification training dataset

Function: clean_severity_data
Parameters: None
Returns: Boolean (True on success)

Input File: data/training_dataset/severity_training.csv

Output File: data/processed/severity_cleaned.csv

Logic:
1. Load CSV file from training dataset
2. Handle missing values:
   a. For numeric columns: fill with column median
   b. For categorical columns: fill with column mode
   c. For all columns: replace empty strings with "unknown"
3. Validate and clip numeric ranges for all vital signs:
   a. age: 0-120 years
   b. duration: 0-720 hours
   c. temperature: 35.0-42.0 degrees
   d. heart_rate: 30-200 bpm
   e. blood pressure: systolic 60-200, diastolic 40-120
   f. respiratory_rate: 8-40 breaths/min
   g. oxygen_saturation: 70-100 percent
   h. comorbidities: 0-10 count
4. Convert boolean fields to 0/1 integer
5. Remove any remaining rows with NaN values
6. Balance classes (handle imbalanced target):
   a. Find minimum count across all severity classes
   b. Sample each class to exact minimum count
   c. Concatenate balanced samples
   d. Shuffle rows randomly
7. Save cleaned, balanced dataset to output file
8. Print statistics showing class distribution

Class Balancing:
- Addresses class imbalance by downsampling majority classes
- Critical for machine learning fairness
- Ensures all severity levels equally represented


ml/cleaning/clean_risk_score_data.py
-----------------------------------
Purpose: Clean risk score regression training dataset (no balancing for continuous target)

Function: clean_risk_score_data
Parameters: None
Returns: Boolean (True on success)

Input File: data/training_dataset/risk_score_training.csv

Output File: data/processed/risk_score_cleaned.csv

Logic:
1. Load CSV file from training dataset
2. Handle missing values (same as severity cleaning):
   a. Numeric: fill median
   b. Categorical: fill mode
   c. Empty strings: replace "unknown"
3. Validate and clip numeric ranges (same as severity):
   a. All vital signs clipped to valid ranges
   b. Risk_score target: clip to [0.0, 1.0] for safety
4. Convert boolean fields to 0/1
5. Remove remaining NaN rows
6. Maintain full distribution:
   a. Print risk_score statistics (min, max, mean, std)
   b. No class balancing (regression doesn't require balance)
   c. Variance in target is important for regression learning
7. Shuffle rows randomly
8. Save cleaned dataset to output file
9. Print row count and statistics

Difference from Severity Cleaning:
- No class balancing (continuous target, not discrete)
- Maintains full distribution of risk scores
- Handles outliers via clipping rather than removal


ml/train_model/train_severity_model.py
--------------------------------------
Purpose: Train RandomForest classification model for symptom severity prediction

Function: train_severity_model
Parameters: None
Returns: Boolean (True on success)

Input Data: data/processed/severity_cleaned.csv (balanced training data)

Output Files:
- ml/models/severity_classifier.pkl (trained model)
- ml/models/severity_scaler.pkl (feature scaling model)

Model Details:
- Algorithm: RandomForest with 100 decision trees
- Features: 11 vital signs and demographics
- Target: 4-class classification (Critical, High, Moderate, Low)
- Preprocessing: StandardScaler normalization

Training Logic:
1. Load cleaned CSV dataset
2. Define 11 feature column names
3. Extract feature matrix X and target vector y
4. Encode target variable:
   a. LabelEncoder on severity_level column
   b. Sorts classes alphabetically: [Critical, High, Low, Moderate]
   c. Maps to integers: 0, 1, 2, 3
5. Scale features:
   a. StandardScaler fit on X
   b. All features normalized to mean=0, std=1
6. Split data:
   a. 80% training, 20% test
   b. random_state=42 for reproducibility
   c. stratify=y to maintain class distribution in splits
7. Train RandomForest:
   a. 100 estimators (decision trees)
   b. max_depth=15 to prevent overfitting
   c. min_samples_split=5
   d. min_samples_leaf=2
   e. random_state=42 for reproducibility
   f. n_jobs=-1 to use all CPU cores (parallel)
8. Evaluate on test set:
   a. accuracy_score: overall correctness
   b. precision_score: weighted average for each class
   c. recall_score: weighted average for each class
   d. f1_score: weighted harmonic mean for each class
9. Feature importance analysis:
   a. Extract feature importances from model
   b. Rank by importance descending
   c. Print top 5 features
10. Save model and scaler:
    a. Pickle serialize model to severity_classifier.pkl
    b. Pickle serialize scaler to severity_scaler.pkl
11. Print complete metrics and file paths
12. Return True

Evaluation Metrics:
- Accuracy: Overall percentage correct
- Precision: For each class, correctness of positive predictions
- Recall: For each class, coverage of all positive instances
- F1: Harmonic mean of precision and recall
- Feature importance: Which vital signs most predictive


ml/train_model/train_risk_score_model.py
----------------------------------------
Purpose: Train RandomForest regression model for clinical risk score prediction

Function: train_risk_score_model
Parameters: None
Returns: Boolean (True on success)

Input Data: data/processed/risk_score_cleaned.csv (cleaned training data, no balancing)

Output Files:
- ml/models/risk_score_regressor.pkl (trained model)
- ml/models/risk_score_scaler.pkl (feature scaling model)

Model Details:
- Algorithm: RandomForest with 100 decision trees (regressor, not classifier)
- Features: 11 vital signs and demographics (same as severity model)
- Target: Continuous numerical value in range [0.0, 1.0]
- Preprocessing: StandardScaler normalization

Training Logic:
1. Load cleaned CSV dataset
2. Define 11 feature column names (identical to severity model)
3. Extract feature matrix X and target vector y (risk_score)
4. Print risk_score distribution:
   a. Minimum value
   b. Maximum value
   c. Mean value
   d. Standard deviation
5. Scale features:
   a. StandardScaler fit on X
   b. Same scaling as severity model
6. Split data:
   a. 80% training, 20% test
   b. random_state=42
   c. No stratification (regression, not classification)
7. Train RandomForest Regressor:
   a. 100 estimators
   b. max_depth=15
   c. min_samples_split=5
   d. min_samples_leaf=2
   e. random_state=42
   f. n_jobs=-1 (parallel)
8. Evaluate on test set:
   a. Clip predictions to [0.0, 1.0] before evaluation
   b. Mean Absolute Error (MAE): average prediction error magnitude
   c. Root Mean Squared Error (RMSE): penalizes larger errors more
   d. R2 Score: proportion of variance explained (0 to 1)
9. Feature importance analysis:
   a. Print top 5 most important features
10. Save model and scaler:
    a. Pickle serialize to risk_score_regressor.pkl
    b. Pickle serialize to risk_score_scaler.pkl
11. Print metrics and file paths
12. Return True

Regression Evaluation Metrics:
- MAE: Average absolute difference (same units as target)
- RMSE: Root of average squared error (penalizes outliers)
- R2: How well does model explain variance (higher=better, max=1.0)

Key Difference from Classification:
- Predicts continuous numerical value, not discrete class
- No accuracy/precision/recall (those are classification metrics)
- Uses regression-specific metrics (MAE, RMSE, R2)


ml/evaluation/evaluate_models.py
-------------------------------
Purpose: Evaluate both trained models on held-out evaluation datasets

Function: evaluate_all_models
Parameters:
- evaluation_dir: String path to evaluation dataset directory (default "data/evaluation_dataset")
- model_dir: String path to saved models directory (default "ml/models")
Returns: Dictionary containing evaluation results for both models

Return Dictionary Structure:
{
    "status": "success" or "error",
    "models": {
        "severity_classifier": {
            "model_name": "Severity Classifier",
            "metrics": {
                "accuracy": float (0.0-1.0),
                "precision": float (0.0-1.0),
                "recall": float (0.0-1.0),
                "f1_score": float (0.0-1.0),
                "num_samples": integer,
                "num_features": 11
            },
            "status": "success" or "model_not_found" or "error"
        },
        "risk_score_regressor": {
            "model_name": "Risk Score Regressor",
            "metrics": {
                "mae": float,
                "rmse": float,
                "r2_score": float (0.0-1.0),
                "num_samples": integer,
                "num_features": 11
            },
            "status": "success" or "model_not_found" or "error"
        }
    },
    "error": null or error message string
}

Evaluation Logic for Severity Classifier:
1. Load severity_classifier.pkl from model_dir
2. Load severity_scaler.pkl from model_dir
3. Load evaluation_dataset/severity_eval.csv
4. Extract feature matrix X and target y
5. Handle missing values with np.nan_to_num
6. Scale X using loaded scaler
7. Make predictions with loaded model
8. Decode predictions to class labels:
   a. Use LabelEncoder with classes [Critical, High, Low, Moderate]
   b. Convert numeric predictions to severity labels
9. Calculate metrics:
   a. accuracy_score: overall correctness percentage
   b. precision_score (weighted): precision for each class, weighted by support
   c. recall_score (weighted): recall for each class, weighted by support
   d. f1_score (weighted): F1 for each class, weighted by support
10. Store metrics in results dictionary with model name and sample count
11. Status = "success" if no errors, else "error" or "model_not_found"

Evaluation Logic for Risk Score Regressor:
1. Load risk_score_regressor.pkl from model_dir
2. Load risk_score_scaler.pkl from model_dir
3. Load evaluation_dataset/risk_score_eval.csv
4. Extract feature matrix X and target y
5. Handle missing values with np.nan_to_num
6. Scale X using loaded scaler
7. Make predictions with loaded model
8. Clip predictions to [0.0, 1.0] range
9. Calculate regression metrics:
   a. Mean Absolute Error: average absolute prediction error
   b. Root Mean Squared Error: square root of average squared error
   c. R2 Score: proportion of variance in data explained by model
10. Store metrics in results with model name and sample count
11. Status = "success" if no errors, else "error" or "model_not_found"

Error Handling:
- Missing models: Sets status to "model_not_found"
- Missing evaluation data: Sets status to "evaluation_data_not_found"
- Any exception: Sets status to "error" with error message
- Returns partial results even if one model fails


SECTION 4: UI DESIGN - STREAMLIT INTERFACE
============================================

Streamlit Application Architecture
===================================

File: main.py

Overall Design Philosophy
==========================

SymptomOne provides a professional, medical-grade web interface for clinical assessment. The design emphasizes:

1. Clarity: Clinical data presented in structured, easy-to-parse format
2. Safety: Color-coding for risk levels, prominent red flag warnings
3. Workflow: Two-step process (Select Case → View Results)
4. Accessibility: Responsive layout, mobile-friendly
5. Professional appearance: Medical color scheme, clean typography

Page Configuration
==================

Layout Setting: Wide layout (maximizes screen real estate)
Initial Sidebar: Expanded (model metrics visible by default)
Theme: Light theme with custom CSS styling
Page Title: SymptomOne

Custom CSS Styling
===================

Professional medical color scheme:
- Header gradient: Purple gradient (667eea to 764ba2)
- Success elements: Green backgrounds
- Warning elements: Yellow backgrounds
- Critical elements: Red backgrounds
- Neutral elements: Blue backgrounds

Custom styling includes:
- Card-based layouts for metrics
- Color-coded severity badges
- Professional typography
- Responsive spacing
- Medical alert formatting

Application State Management
============================

Streamlit Session State Variables:

1. step: Current workflow stage
   - "INPUT": Patient case selection and data viewing
   - "RESULTS": Assessment results and analysis

2. result: Full workflow output dictionary
   - Populated when assessment completes
   - Contains all assessment results

3. selected_file: Currently selected patient JSON filename
   - Used to load patient data on demand
   - Enables "View Selected Case" functionality

4. patient_data: Currently loaded patient data dictionary
   - 11 clinical fields plus optional symptom_description
   - Used to run assessment

INPUT PHASE WORKFLOW
====================

Purpose: Allow user to select patient case and review data before assessment

Components:

1. Header Section
   - Large title: "SymptomOne"
   - Subtitle: System description
   - Professional formatting

2. File Selection Dropdown
   - Lists all JSON files in data/input/ directory
   - Default: "Select a patient case"
   - On selection: Loads patient JSON data

3. Patient Vitals Summary
   - Displays 5 key metric cards:
     a. Age: Patient age in years
     b. Temperature: Body temperature in Celsius
     c. Heart Rate: Beats per minute
     d. O2 Saturation: Oxygen saturation percentage
     e. Risk Category: Predicted from vitals
   - Each card shows metric name and value
   - Color-coded for quick assessment

4. Symptom Description Display
   - Expandable section showing free-text symptoms (if provided)
   - Formatted as blockquote for clarity
   - Marked as optional

5. Complete Clinical Data Display
   - Expandable expander titled "View All Clinical Data"
   - Shows all 11 vital signs in 2-column layout
   - Field names formatted for readability
   - Values displayed with units where applicable

6. Assessment Controls
   - "Run Assessment" button (primary action)
     - Triggers workflow execution
     - Disabled while assessment running
     - Shows spinner during execution
     - Updates to RESULTS phase on completion

   - "Download Data (JSON)" button
     - Downloads current patient data as JSON file
     - Useful for record keeping
     - Filename: patient_case_{selected_file}

Sidebar Display
===============

Sidebar contains:

1. Section: Model Performance Metrics
   - Severity Classifier:
     - Accuracy: Percentage correct
     - Precision: Positive prediction accuracy
     - Recall: Coverage of positive cases
     - F1-Score: Harmonic mean

   - Risk Score Regressor:
     - R2 Score: Variance explained
     - MAE: Mean absolute error
     - RMSE: Root mean squared error

   - Model metrics cached using st.cache_data decorator
   - Loaded from evaluate_all_models() function
   - Provides transparency on model performance

2. Section: About SymptomOne
   - System description
   - Key features
   - Disclaimer about clinical use
   - Version information

RESULTS PHASE WORKFLOW
======================

Purpose: Display comprehensive assessment results in organized, professional format

Display Structure:

1. Success Header
   - Green success alert
   - Assessment completion message
   - Session ID for record tracking
   - Timestamp of assessment

2. Key Metrics Section
   - Four metric cards in horizontal layout:
     a. Severity Level: Low/Moderate/High/Critical (color-coded)
     b. Risk Score: Numerical 0.0-1.0 value (color-coded)
     c. Risk Level: HIGH/LOW determination (prominent styling)
     d. Session ID: Unique assessment identifier

   Color Coding:
   - Critical: Red
   - High: Orange
   - Moderate: Yellow
   - Low: Green
   - HIGH risk: Red background
   - LOW risk: Green background

3. Tabbed Analysis Section
   - Four tabs for different analysis perspectives:

   TAB 1: SYMPTOM ANALYSIS
   - Displays LLM classification results:
     - Primary Symptom: Classified symptom type
     - Onset Pattern: Sudden/Gradual/Chronic
     - Pain Character: Sharp/Dull/Throbbing/etc (if applicable)
     - Associated Symptoms: List of related symptoms
     - Red Flags: Separate warning section (if identified)
       - Displayed in red alert box
       - Lists concerning features requiring urgent attention
       - Only shown if red flags identified

   TAB 2: CLINICAL DATA
   - Displays all extracted vital signs:
     - Age, Temperature, Heart Rate, Blood Pressure
     - Respiratory Rate, Oxygen Saturation
     - Fever Status, Neck Stiffness Status
     - Symptom Duration, Comorbidities Count
     - Formatted in 2-column layout for readability
     - Field names human-readable
     - Values shown with units

   TAB 3: DIAGNOSIS & TREATMENT
   - Content varies by risk level:

     FOR LOW-RISK CASES:
     - Informational message box displayed:
       - Explains why detailed diagnosis not needed
       - Notes low-risk assessment below threshold
       - Provides reassurance on symptom manageability
       - Recommends monitoring and when to see doctor
     - Differential diagnoses section hidden/disabled
     - Treatment plan section hidden/disabled

     FOR HIGH-RISK CASES:
     - Differential Diagnoses section:
       - Lists 5-7 diagnoses with probabilities
       - Each diagnosis shows:
         a. Diagnosis name
         b. Probability badge (color-coded):
            - High probability: Red
            - Medium probability: Yellow
            - Low probability: Green
         c. Clinical reasoning
       - Ordered by probability (high to low)

     - Treatment Plan section:
       - Immediate Interventions: Bulleted list of urgent actions
       - Recommended Tests: Diagnostic tests to order
       - Medications: Each with name, dosage, purpose
       - Monitoring Plan: Ongoing monitoring requirements
       - Follow-up Timeline: When to reassess
       - Specialist Referrals: Specialties to consult

   TAB 4: CLINICAL GUIDANCE
   - Risk-appropriate clinical advice:

     FOR HIGH-RISK CASES:
     - Displayed in red error box (indicates urgency)
     - CRITICAL ALERT formatting
     - Content includes:
       - Urgent action requirements
       - Emergency department instructions
       - Hospital admission expectations
       - Red flags requiring emergency return
       - Contact information if available

     FOR LOW-RISK CASES:
     - Displayed in green success box (reassuring)
     - Reassuring tone and content
     - Content includes:
       - Symptom normalization
       - Self-care recommendations
       - Over-the-counter medication options
       - Warning signs requiring doctor visit
       - Typical symptom timeline

4. Bottom Action Buttons
   - "Download Full Report (JSON)" button
     - Downloads complete assessment as JSON file
     - Includes all results, timestamps, session ID
     - Filename: report_{session_id}.json
     - Enables record keeping and data sharing

   - "New Assessment" button
     - Resets application state
     - Returns to INPUT phase
     - Clears previous results
     - Ready for next patient

   - "View Selected Case" button
     - Shows raw JSON of selected patient case
     - Useful for verification and debugging
     - Displays in expandable section

Data Display Functions
======================

Function: get_available_json_files()
Purpose: Retrieve list of patient case files
Logic:
- Scans data/input/ directory
- Returns list of .json filenames
- Used to populate file selector dropdown
- Cached with st.cache_data for performance

Function: get_severity_color(severity)
Purpose: Map severity level to display color hex code
Parameters:
- severity: String severity level
Returns: Hex color code
Mappings:
- Critical: #dc3545 (red)
- High: #fd7e14 (orange)
- Moderate: #ffc107 (yellow)
- Low: #28a745 (green)

Function: format_clinical_field(key)
Purpose: Convert technical field names to user-friendly display labels
Parameters:
- key: String field name (snake_case format)
Returns: Formatted field label
Examples:
- patient_age_years → Age (years)
- body_temperature_celsius → Temperature (°C)
- heart_rate_bpm → Heart Rate (bpm)

Function: load_model_evaluation()
Purpose: Load cached model performance metrics
Logic:
- Decorated with st.cache_data for performance
- Calls evaluate_all_models()
- Returns dictionary with model metrics
- Cached indefinitely (no recompute unless code changes)

User Workflow in UI
===================

Step 1: Application Load
- User navigates to Streamlit URL
- INPUT phase displayed
- Sidebar shows model metrics
- File selector ready

Step 2: Case Selection
- User selects patient from dropdown
- Patient JSON data loaded
- Vitals cards display key values
- Clinical data section available for review

Step 3: Assessment Trigger
- User clicks "Run Assessment" button
- Button becomes disabled
- Loading spinner appears
- Workflow executes in background

Step 4: Workflow Execution
- 13-node LangGraph workflow runs
- All 13 nodes execute sequentially
- Conditional routing at risk score threshold
- State builds through each node

Step 5: Results Display
- Workflow completes
- Application transitions to RESULTS phase
- Assessment results loaded into state
- Tabs and metrics populate with results

Step 6: Results Review
- User reviews metrics cards
- User examines each analysis tab
- Risk-appropriate content displayed
- Download button available for report

Step 7: Next Action
- User can download report (JSON)
- User can view raw case data
- User can start new assessment
- Application resets for next patient


SECTION 5: RUNNING COMMANDS - ENTRY POINTS AND EXECUTION PATHS
===============================================================

Complete Execution Pathways
============================

PATHWAY 1: DATA CLEANING (Prerequisite)
========================================

Purpose: Clean and prepare raw training data for model training

Step 1: Prepare Environment
- Navigate to project root directory
- Ensure Python 3.9+ installed
- Install dependencies: pip install -r requirements.txt
- Set up .env file with API keys

Step 2: Verify Data Files
- Ensure raw training CSVs exist:
  - data/training_dataset/severity_training.csv
  - data/training_dataset/risk_score_training.csv
- Verify directory structure
- Check file permissions

Step 3: Run Severity Data Cleaning
Command: python -m ml.cleaning.clean_severity_data
Process:
1. Loads severity_training.csv
2. Handles missing values (median imputation)
3. Validates numeric ranges for all vitals
4. Balances 4 severity classes (downsampling)
5. Shuffles data
6. Outputs: data/processed/severity_cleaned.csv
Expected Output:
- Class distribution after balancing
- Sample counts per class
- Confirmation of successful cleaning

Step 4: Run Risk Score Data Cleaning
Command: python -m ml.cleaning.clean_risk_score_data
Process:
1. Loads risk_score_training.csv
2. Handles missing values
3. Validates ranges (especially risk_score 0.0-1.0)
4. Maintains full distribution (no balancing)
5. Shuffles data
6. Outputs: data/processed/risk_score_cleaned.csv
Expected Output:
- Risk score statistics (min, max, mean, std)
- Sample count
- Confirmation message

PATHWAY 2: MODEL TRAINING (Prerequisite)
==========================================

Purpose: Train machine learning models on cleaned data

Step 1: Run Complete Training Pipeline
Command: python -m ml.train_pipeline
Process:
1. Trains severity classifier model
2. Trains risk score regressor model
3. Evaluates both models
4. Reports all metrics
5. Saves models and scalers

Step 2: Severity Model Training Details
File Executed: ml/train_model/train_severity_model.py
Process:
1. Loads cleaned severity_cleaned.csv
2. Extracts 11 features and target
3. Encodes target to numeric (0-3 mapping)
4. Scales features with StandardScaler
5. Splits data 80/20 with stratification
6. Trains RandomForest with 100 trees
7. Evaluates on test set
8. Saves:
   - ml/models/severity_classifier.pkl
   - ml/models/severity_scaler.pkl

Training Output Includes:
- Accuracy, Precision, Recall, F1 scores
- Top 5 feature importances
- Class distribution
- File save confirmation

Step 3: Risk Score Model Training Details
File Executed: ml/train_model/train_risk_score_model.py
Process:
1. Loads cleaned risk_score_cleaned.csv
2. Extracts 11 features and target
3. Scales features with StandardScaler
4. Splits data 80/20 (no stratification)
5. Trains RandomForest regressor with 100 trees
6. Evaluates on test set
7. Saves:
   - ml/models/risk_score_regressor.pkl
   - ml/models/risk_score_scaler.pkl

Training Output Includes:
- MAE, RMSE, R2 scores
- Risk score distribution stats
- Top 5 feature importances
- File save confirmation

PATHWAY 3: MODEL EVALUATION
============================

Purpose: Assess model performance on held-out evaluation datasets

Command: python -c "from ml.evaluation.evaluate_models import evaluate_all_models; import json; print(json.dumps(evaluate_all_models(), indent=2))"

Process:
1. Loads evaluation datasets:
   - data/evaluation_dataset/severity_eval.csv
   - data/evaluation_dataset/risk_score_eval.csv
2. Loads saved models:
   - severity_classifier.pkl, severity_scaler.pkl
   - risk_score_regressor.pkl, risk_score_scaler.pkl
3. Evaluates severity classifier:
   - Accuracy, Precision, Recall, F1
   - Sample count and feature count
4. Evaluates risk regressor:
   - MAE, RMSE, R2
   - Sample count and feature count
5. Returns JSON with all metrics

Output Format:
{
    "status": "success",
    "models": {
        "severity_classifier": {
            "metrics": {
                "accuracy": 0.85,
                "precision": 0.84,
                "recall": 0.83,
                "f1_score": 0.83
            }
        },
        "risk_score_regressor": {
            "metrics": {
                "mae": 0.15,
                "rmse": 0.22,
                "r2_score": 0.78
            }
        }
    }
}

PATHWAY 4: STREAMLIT UI LAUNCH (Main Application)
===================================================

Purpose: Start professional web interface for clinical assessment

Prerequisites:
- Models trained (severity and risk models in ml/models/)
- Sample patient cases in data/input/
- .env file configured with GEMINI_API_KEYS
- All dependencies installed

Step 1: Launch Streamlit Application
Command: streamlit run main.py
Alternative Port: streamlit run main.py --server.port 8502

Process:
1. Initializes Streamlit session
2. Loads Gemini API keys from environment
3. Loads model evaluation metrics (cached)
4. Prepares Streamlit UI components
5. Displays INPUT phase
6. Ready for user interaction

Step 2: Application Initialization
Automatic Steps on Launch:
- Custom CSS styling applied
- Page configuration set to wide layout
- Session state initialized
- File selector populated from data/input/
- Model metrics loaded and cached
- Sidebar displayed with metrics

Step 3: User Interaction (INPUT Phase)
User Actions:
1. Selects patient case from dropdown
2. Reviews vital signs in cards
3. Optionally reviews symptom description
4. Clicks "Run Assessment" button
5. Optionally downloads patient data as JSON

Step 4: Assessment Execution
Application Actions:
1. Loads selected patient JSON
2. Creates initial state with 11 clinical fields
3. Invokes graph.run_symptom_one_workflow()
4. 13-node workflow executes:
   - Nodes 1-5: Common path
   - Nodes 6-8 OR Node 9: Conditional path
   - Nodes 10-13: Convergence path
5. Returns final_state with all results

Step 5: Results Display (RESULTS Phase)
Display Components:
1. Success alert with timestamp
2. Four metric cards
3. Four analysis tabs with results
4. Download report button
5. Navigation buttons (New Assessment, View Case)

Step 6: Report Download
User can click "Download Full Report (JSON)" to:
- Download complete assessment as JSON file
- Includes all results, timestamps, session ID
- Filename: report_{session_id}.json
- Contains:
  - Patient data
  - Severity level, risk score, risk level
  - Differential diagnoses (or low-risk marker)
  - Treatment plan (or low-risk marker)
  - Health advice
  - Validation status and errors
  - Timestamp and session tracking

Step 7: Next Assessment
User can click "New Assessment" to:
- Reset application state
- Clear previous results
- Return to INPUT phase
- Select new patient case

Browser Access:
- Default: http://localhost:8501
- Custom port: http://localhost:{specified_port}
- Application accessible from any browser on network

PATHWAY 5: TESTING (Quality Assurance)
========================================

Purpose: Verify system functionality without making API calls

Prerequisites:
- pytest installed
- All dependencies available

Command: pytest tests.py -v

Test Execution:
1. Loads mock infrastructure
2. Executes 16 test cases
3. Reports pass/fail status
4. Shows execution time

Test Coverage:
- ML agent initialization and prediction
- LLM agent initialization with mock client
- State schema and initial state creation
- Node execution with various patient profiles
- Full workflow execution (high-risk and low-risk)
- File and data integrity checks

Expected Output:
- List of 16 test cases with status
- Summary: 16 passed in X.XX seconds
- Any failures detailed with error messages

Testing Features:
- MockGeminiClient eliminates API calls
- Pattern-matched responses for agent testing
- No external dependencies required
- Fast execution (under 30 seconds)


SECTION 6: COMPLETE OUTPUT EXAMPLE
===================================

Assessment Report Example (HIGH-RISK Case)
===========================================

Case Input:
Patient: 65-year-old with fever, neck stiffness, and critical vitals

UI Display Output:

[SUCCESS ALERT]
Assessment Complete - Session: 550e8400-e29b-41d4-a716-446655440000
Timestamp: 2024-12-24 14:30:45

[METRIC CARDS]
Severity Level: HIGH (Orange badge)
Risk Score: 0.78 / 1.0
Risk Level: HIGH (Red background)
Session ID: 550e8400-e29b-41d4-a716-446655440000

[TAB 1: SYMPTOM ANALYSIS]
Primary Symptom: Fever/Infection
Onset Pattern: Sudden
Associated Symptoms: Neck stiffness, headache, photophobia
Red Flags:
- Neck stiffness (meningitis indicator)
- Sudden onset
- Critical temperature elevation

[TAB 2: CLINICAL DATA]
Age: 65 years
Temperature: 39.5 degrees Celsius
Heart Rate: 110 bpm
Blood Pressure: 145/92 mmHg
Respiratory Rate: 22 breaths/min
Oxygen Saturation: 94 percent
Fever Present: Yes
Neck Stiffness: Yes
Symptom Duration: 24 hours
Comorbidities: 2

[TAB 3: DIAGNOSIS & TREATMENT]

DIFFERENTIAL DIAGNOSES:
1. Bacterial Meningitis
   Probability: HIGH
   Reasoning: Neck stiffness, fever, altered mental status, critical vitals

2. Viral Meningitis
   Probability: HIGH
   Reasoning: Similar presentation but typically less severe

3. Sepsis
   Probability: MEDIUM
   Reasoning: Fever, tachycardia, respiratory changes, elevated risk

TREATMENT PLAN:

Immediate Interventions:
- Initiate empiric antibiotic therapy
- Establish IV access for fluid administration
- Obtain blood cultures before antibiotics
- Lumbar puncture for CSF analysis
- CT head if signs of increased ICP

Recommended Tests:
- Blood cultures (before antibiotics)
- CBC with differential
- Comprehensive metabolic panel
- Lumbar puncture with CSF analysis
- Procalcitonin level
- Imaging: CT head, chest X-ray

Medications:
- Ceftriaxone 2g IV every 12 hours (meningitis coverage)
- Vancomycin 15-20 mg/kg IV every 8-12 hours (resistant organisms)
- Dexamethasone 10 mg IV every 6 hours (inflammation reduction)
- Acyclovir 10 mg/kg IV every 8 hours (HSV coverage)

Monitoring Plan:
- Continuous cardiac monitoring
- Hourly neurological assessments
- Fluid intake and output monitoring
- Temperature monitoring every 2 hours
- Intracranial pressure monitoring if available

Follow-up Timeline:
- Initial CSF results: 48 hours
- Clinical reassessment: 6-12 hours
- Repeat cultures if not improving: 24-48 hours
- Follow-up neuroimaging: 48-72 hours as clinically indicated

Specialist Referrals:
- Infectious Disease
- Neurology
- Critical Care Medicine

[TAB 4: CLINICAL GUIDANCE]

[RED ALERT BOX]
CRITICAL ALERT: URGENT MEDICAL ATTENTION REQUIRED

You are experiencing symptoms consistent with MENINGITIS, a serious medical emergency requiring immediate hospitalization.

IMMEDIATE ACTIONS:
1. Call emergency services (911) immediately
2. Do NOT wait for office appointments
3. Go to nearest emergency department
4. Inform ambulance of neck stiffness and fever

WHAT TO EXPECT AT HOSPITAL:
- Rapid triage and assessment
- Lumbar puncture (spinal tap) for diagnosis
- IV antibiotics started within 1 hour
- Admission to ICU or hospital bed

WARNING SIGNS REQUIRING IMMEDIATE EMERGENCY RETURN:
- Worsening neck stiffness
- Confusion or altered consciousness
- Severe headache with vision changes
- Rapid deterioration of condition
- Difficulty breathing

Contact: Call 911 or go to nearest Emergency Department immediately.

[DOWNLOAD BUTTONS]
Download Full Report (JSON)
New Assessment
View Selected Case

---

Assessment Report Example (LOW-RISK Case)
==========================================

Case Input:
Patient: 35-year-old with mild headache, normal vitals

UI Display Output:

[SUCCESS ALERT]
Assessment Complete - Session: 660e8400-f29b-41d4-b716-557655440000
Timestamp: 2024-12-24 14:35:22

[METRIC CARDS]
Severity Level: LOW (Green badge)
Risk Score: 0.32 / 1.0
Risk Level: LOW (Green background)
Session ID: 660e8400-f29b-41d4-b716-557655440000

[TAB 1: SYMPTOM ANALYSIS]
Primary Symptom: Headache
Onset Pattern: Gradual
Associated Symptoms: Mild fatigue
Red Flags: None identified

[TAB 2: CLINICAL DATA]
Age: 35 years
Temperature: 37.2 degrees Celsius
Heart Rate: 72 bpm
Blood Pressure: 120/80 mmHg
Respiratory Rate: 16 breaths/min
Oxygen Saturation: 98 percent
Fever Present: No
Neck Stiffness: No
Symptom Duration: 6 hours
Comorbidities: 0

[TAB 3: DIAGNOSIS & TREATMENT]

[INFO BOX - Light Blue Background]
LOW-RISK ASSESSMENT

Since your risk score is below the clinical threshold (0.6), detailed differential diagnosis and treatment planning are not required. Your symptoms appear manageable with self-care and monitoring.

If symptoms persist or worsen, consult a healthcare provider. Most headaches resolve within 24-48 hours with conservative management.

[TAB 4: CLINICAL GUIDANCE]

[GREEN SUCCESS BOX]
Your Symptoms Are Manageable

Based on your assessment, your symptoms do not indicate a serious medical condition. Here is recommended care:

SELF-CARE RECOMMENDATIONS:
1. Rest in a quiet, dark room
2. Stay hydrated with water or electrolyte beverages
3. Apply warm or cold compress to head as tolerated
4. Avoid stressful activities temporarily

OVER-THE-COUNTER MEDICATION:
- Ibuprofen 400-600 mg every 6-8 hours (maximum 1200 mg daily)
  Or
- Acetaminophen 500-1000 mg every 6-8 hours (maximum 4000 mg daily)

WHEN TO SEE A DOCTOR:
Seek immediate medical care if you develop:
- Severe sudden headache (worst of life)
- Fever above 103°F (39.4°C)
- Stiff neck or rash
- Confusion or difficulty thinking
- Vision changes or eye pain
- Weakness or numbness

TYPICAL TIMELINE:
Most headaches improve within 24-48 hours with rest and hydration. If symptoms persist beyond 72 hours, contact your healthcare provider.

FOLLOW-UP:
- Monitor symptoms for next 48 hours
- Maintain hydration and rest
- Call doctor if worsening or no improvement in 2-3 days

[DOWNLOAD BUTTONS]
Download Full Report (JSON)
New Assessment
View Selected Case

---

JSON Report File Format
=======================

Sample output/{session_id}.json contains:

{
  "session_id": "550e8400-e29b-41d4-a716-446655440000",
  "timestamp": "2024-12-24T14:30:45.123456",
  "patient_data": {
    "extracted_fields": {
      "patient_age_years": 65,
      "symptom_duration_hours": 24,
      "fever_present": 1,
      "neck_stiffness": 1,
      "body_temperature_celsius": 39.5,
      "heart_rate_bpm": 110,
      "blood_pressure_systolic_mmhg": 145,
      "blood_pressure_diastolic_mmhg": 92,
      "respiratory_rate_breaths_per_minute": 22,
      "oxygen_saturation_percent": 94,
      "comorbidities_count": 2
    },
    "completion_percentage": 100.0
  },
  "assessment": {
    "severity_level": "High",
    "risk_score": 0.78,
    "risk_level": "HIGH"
  },
  "clinical_analysis": {
    "differential_diagnoses": {
      "diagnoses": [
        {
          "diagnosis": "Bacterial Meningitis",
          "probability": "high",
          "reasoning": "Neck stiffness, fever, critical vitals indicate meningeal involvement"
        },
        {
          "diagnosis": "Viral Meningitis",
          "probability": "high",
          "reasoning": "Similar presentation but typically self-limited"
        }
      ]
    },
    "treatment_plan": {
      "immediate_interventions": [
        "Initiate empiric antibiotic therapy",
        "Establish IV access",
        "Obtain blood cultures"
      ],
      "medications": [
        {
          "name": "Ceftriaxone",
          "dosage": "2g IV every 12 hours",
          "purpose": "Broad-spectrum meningitis coverage"
        }
      ]
    },
    "health_advice": "CRITICAL ALERT: Call 911 immediately. You require emergency evaluation..."
  },
  "validation": {
    "validation_status": "valid",
    "validation_errors": []
  }
}


END OF DOCUMENTATION
====================

This comprehensive documentation covers all aspects of the SymptomOne medical assessment system, from problem statement through complete execution pathways and sample outputs. All 13 nodes, 7 agents, ML pipeline, and Streamlit UI are thoroughly documented without code listings, following professional standards and formatting constraints.
