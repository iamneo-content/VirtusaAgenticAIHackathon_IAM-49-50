"""State schema for SymptomOne LangGraph workflow (JSON Input Mode)"""
from typing import TypedDict, Dict, Any, List, Optional
import uuid


class SymptomOneState(TypedDict, total=False):
    """
    Complete state schema for SymptomOne LangGraph workflow.
    All fields are optional (total=False) to allow gradual state building.

    Simplified for JSON input mode - no Q&A loop or interactive data collection.
    """

    # Session Management
    session_id: str

    # Phase 1: Patient Data (from JSON input)
    extracted_data: Dict[str, Any]
    symptom_classification: Optional[Dict[str, Any]]  # LLM-based symptom classification

    # Phase 2: ML Assessment
    severity_level: str
    risk_score: float
    ml_results: Dict[str, Any]

    # Phase 3: Risk Routing
    risk_path: str

    # Phase 4: Clinical Analysis
    differential_diagnoses: Optional[Dict[str, Any]]
    treatment_plan: Optional[Dict[str, Any]]
    health_advice: Optional[str]

    # Phase 5: Report & Output
    validation_status: str
    validation_errors: List[str]
    ui_output: Dict[str, Any]
    report_file_path: str
    report_json: str


def create_initial_state(patient_data: Dict[str, Any], session_id: str = None) -> SymptomOneState:
    """
    Create initial state from JSON patient data

    Args:
        patient_data: Complete patient data dictionary (all 11 clinical fields)
        session_id: Unique session identifier (auto-generated if not provided)

    Returns:
        Initial SymptomOneState
    """
    if session_id is None:
        session_id = str(uuid.uuid4())

    return SymptomOneState(
        session_id=session_id,
        extracted_data=patient_data,
        symptom_classification=None,
        severity_level="",
        risk_score=0.0,
        ml_results={},
        risk_path="",
        differential_diagnoses=None,
        treatment_plan=None,
        health_advice=None,
        validation_status="pending",
        validation_errors=[],
        ui_output={},
        report_file_path="",
        report_json=""
    )
