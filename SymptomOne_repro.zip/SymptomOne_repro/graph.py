"""SymptomOne LangGraph Workflow - Graph construction and orchestration (JSON Input Mode)"""

import uuid
from typing import Dict, Any, Literal
from langgraph.graph import StateGraph, END

from state import SymptomOneState, create_initial_state
from nodes import (
    user_input_node,
    symptom_classifier_node,
    severity_assessment_node,
    risk_score_assessment_node,
    risk_path_router_node,
    differential_diagnosis_node,
    treatment_plan_node,
    high_risk_advice_node,
    low_risk_advice_node,
    report_compilation_node,
    validation_node,
    save_report_node,
    output_formatting_node,
)


def route_based_on_risk(state: SymptomOneState) -> Literal["diagnose", "advise_low_risk"]:
    """
    Route patient to appropriate clinical pathway based on risk score.

    High-risk path (>= 0.6): Full differential diagnosis and treatment planning
    Low-risk path (< 0.6): Reassuring advice and self-care recommendations

    Args:
        state: Current workflow state containing risk_score

    Returns:
        Routing decision: "diagnose" for high-risk, "advise_low_risk" for low-risk
    """
    risk_score = state.get("risk_score", 0.5)
    return "diagnose" if risk_score >= 0.6 else "advise_low_risk"


def create_symptom_one_graph() -> StateGraph:
    """Create the simplified SymptomOne LangGraph workflow (13 nodes, JSON input + Symptom Classifier)"""
    workflow = StateGraph(SymptomOneState)

    # Add 13 nodes (12 core + 1 symptom classifier)
    workflow.add_node("input_handler", user_input_node)
    workflow.add_node("classify_symptom", symptom_classifier_node)
    workflow.add_node("assess_severity", severity_assessment_node)
    workflow.add_node("assess_risk", risk_score_assessment_node)
    workflow.add_node("route_risk", risk_path_router_node)
    workflow.add_node("diagnose", differential_diagnosis_node)
    workflow.add_node("plan_treatment", treatment_plan_node)
    workflow.add_node("advise_high_risk", high_risk_advice_node)
    workflow.add_node("advise_low_risk", low_risk_advice_node)
    workflow.add_node("compile_report", report_compilation_node)
    workflow.add_node("validate_report", validation_node)
    workflow.add_node("save_report", save_report_node)
    workflow.add_node("format_output", output_formatting_node)

    # Set entry point
    workflow.set_entry_point("input_handler")

    # PHASE 1: Common flow for all patients (input → classify → assess)
    workflow.add_edge("input_handler", "classify_symptom")
    workflow.add_edge("classify_symptom", "assess_severity")
    workflow.add_edge("assess_severity", "assess_risk")
    workflow.add_edge("assess_risk", "route_risk")

    # PHASE 2: Risk-based conditional routing from route_risk node
    # This is the critical fix: properly route to either high-risk or low-risk path
    workflow.add_conditional_edges(
        "route_risk",
        route_based_on_risk,
        {
            "diagnose": "diagnose",           # HIGH-RISK path: risk_score >= 0.6
            "advise_low_risk": "advise_low_risk",  # LOW-RISK path: risk_score < 0.6
        }
    )

    # PHASE 2a: HIGH-RISK path (only for risk_score >= 0.6)
    workflow.add_edge("diagnose", "plan_treatment")
    workflow.add_edge("plan_treatment", "advise_high_risk")
    workflow.add_edge("advise_high_risk", "compile_report")

    # PHASE 2b: LOW-RISK path (only for risk_score < 0.6)
    workflow.add_edge("advise_low_risk", "compile_report")

    # PHASE 3: Convergence point - both paths merge at compile_report
    workflow.add_edge("compile_report", "validate_report")
    workflow.add_edge("validate_report", "save_report")
    workflow.add_edge("save_report", "format_output")
    workflow.add_edge("format_output", END)

    compiled_graph = workflow.compile()
    print("[Graph] SymptomOne workflow compiled successfully (JSON Input Mode + Symptom Classifier)")
    print("[Graph] Total nodes: 13")
    print("[Graph] Entry point: input_handler")

    return compiled_graph


def run_symptom_one_workflow(patient_data: Dict[str, Any], session_id: str = None) -> Dict[str, Any]:
    """
    Run the SymptomOne workflow with JSON patient data

    Args:
        patient_data: Complete patient data dictionary (all 11 clinical fields)
        session_id: Optional session ID (auto-generated if not provided)

    Returns:
        Final workflow state with UI output
    """
    if session_id is None:
        session_id = str(uuid.uuid4())

    # Create initial state directly from JSON data
    initial_state = create_initial_state(patient_data, session_id)

    print(f"\n{'='*80}")
    print(f"Starting SymptomOne Assessment - Session: {session_id}")
    print(f"{'='*80}\n")

    graph = create_symptom_one_graph()
    final_state = graph.invoke(initial_state)

    print(f"\n{'='*80}")
    print(f"Assessment Complete - Session: {session_id}")
    print(f"{'='*80}\n")

    return final_state


if __name__ == "__main__":
    # Test with sample JSON data
    test_data = {
        "patient_age_years": 45,
        "symptom_duration_hours": 48,
        "fever_present": 1,
        "neck_stiffness": 0,
        "body_temperature_celsius": 38.5,
        "heart_rate_bpm": 95,
        "blood_pressure_systolic_mmhg": 130,
        "blood_pressure_diastolic_mmhg": 85,
        "respiratory_rate_breaths_per_minute": 18,
        "oxygen_saturation_percent": 96,
        "comorbidities_count": 1
    }

    print("Testing SymptomOne Graph with JSON input...\n")
    result = run_symptom_one_workflow(test_data)
