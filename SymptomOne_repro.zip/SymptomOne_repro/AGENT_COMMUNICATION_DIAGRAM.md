# SymptomOne Agent-to-Agent Communication Diagram

## Overview
This document contains the Mermaid diagram visualization of agent-to-agent communication in the SymptomOne clinical assessment system. The diagram illustrates the complete workflow showing how data flows between agents, conditional routing logic, and the final output generation.

## Mermaid Diagram Code

```mermaid
graph TD
    START([Patient Input Start])

    NODE1["Node 1: User Input Validation<br/>Validates 11 Required Clinical Fields"]
    NODE2["Node 2: Symptom Classifier LLM Agent<br/>Classifies symptoms and extracts features"]
    NODE3["Node 3: Severity Assessment ML Agent<br/>Predicts severity classification"]
    NODE4["Node 4: Risk Score ML Agent<br/>Predicts clinical risk score 0-1"]
    NODE5{{"Risk Threshold Check<br/>risk_score >= 0.6?"}}

    HIGHPATH["HIGH-RISK PATH<br/>Full Diagnostic Workup"]
    NODE6["Node 6: Differential Diagnosis LLM Agent<br/>Generates diagnosis candidates with probabilities"]
    NODE7["Node 7: Treatment Plan LLM Agent<br/>Creates comprehensive treatment strategy"]
    NODE8["Node 8: Health Advice LLM Agent<br/>Urgent clinical guidance"]

    LOWPATH["LOW-RISK PATH<br/>Reassurance Focus"]
    NODE9["Node 9: Health Advice LLM Agent<br/>Reassuring guidance with monitoring advice"]

    NODE10["Node 10: Report Compilation<br/>Aggregates all assessment data"]
    NODE11["Node 11: Validation Node<br/>Validates required output fields"]
    NODE12["Node 12: Save Report Node<br/>Persists JSON report to storage"]
    NODE13["Node 13: Output Formatting<br/>Prepares data for UI display"]

    END([Clinical Assessment Report Output])

    START -->|extracted_data| NODE1
    NODE1 -->|validation_errors| NODE2
    NODE2 -->|symptom_classification| NODE3
    NODE3 -->|severity_level| NODE4
    NODE4 -->|risk_score, ml_results| NODE5

    NODE5 -->|score >= 0.6| HIGHPATH
    NODE5 -->|score < 0.6| LOWPATH

    HIGHPATH --> NODE6
    NODE6 -->|differential_diagnoses| NODE7
    NODE7 -->|treatment_plan| NODE8
    NODE8 -->|health_advice| NODE10

    LOWPATH --> NODE9
    NODE9 -->|health_advice<br/>status=low_risk_path| NODE10

    NODE10 -->|report dict| NODE11
    NODE11 -->|validation_status| NODE12
    NODE12 -->|report_file_path| NODE13
    NODE13 -->|ui_output formatted| END

    style START fill:#e1f5e1
    style END fill:#e1f5e1
    style NODE2 fill:#fff4e1
    style NODE6 fill:#fff4e1
    style NODE7 fill:#fff4e1
    style NODE8 fill:#fff4e1
    style NODE9 fill:#fff4e1
    style NODE3 fill:#e1f0ff
    style NODE4 fill:#e1f0ff
    style HIGHPATH fill:#ffe1e1
    style LOWPATH fill:#e1ffe1
    style NODE5 fill:#fff0cc
```

## Diagram Elements

### Node Categories

**Start/End (Green):**
- Patient Input Start: Initial entry point with clinical data
- Clinical Assessment Report Output: Final report with all assessment results

**LLM Agents (Yellow):**
- Node 2: Symptom Classifier - Analyzes and classifies symptoms
- Node 6: Differential Diagnosis - Generates diagnosis candidates
- Node 7: Treatment Plan - Creates treatment recommendations
- Node 8 & 9: Health Advice - Provides clinical guidance (tone varies by risk level)

**ML Agents (Blue):**
- Node 3: Severity Assessment - Classifies severity into 4 levels
- Node 4: Risk Score Prediction - Generates risk score between 0.0 and 1.0

**Processing Nodes (White):**
- Node 1: Input Validation - Ensures all required clinical fields present
- Node 5: Risk Router - Conditional decision point (risk_score >= 0.6)
- Node 10: Report Compilation - Aggregates all assessment data
- Node 11: Validation - Validates output fields
- Node 12: Save Report - Persists results to JSON file
- Node 13: Output Formatting - Prepares data for Streamlit UI

### Workflow Paths

**High-Risk Path (Red):**
- Triggered when risk_score >= 0.6
- Includes complete diagnostic workup:
  - Node 6: Differential diagnosis generation
  - Node 7: Comprehensive treatment plan
  - Node 8: Urgent clinical guidance

**Low-Risk Path (Light Green):**
- Triggered when risk_score < 0.6
- Focuses on reassurance:
  - Node 9: Reassuring guidance with monitoring advice
  - Explicitly skips detailed diagnosis/treatment with status="low_risk_path"

### Data Flow

Each arrow represents state field transitions:
- extracted_data: Raw clinical input fields
- validation_errors: Accumulates errors across workflow
- symptom_classification: Structured symptom analysis output
- severity_level: Clinical severity determination
- risk_score: Numeric risk prediction (0.0-1.0)
- differential_diagnoses: List of diagnosis candidates with probabilities
- treatment_plan: Comprehensive treatment strategy
- health_advice: Clinical guidance appropriate to risk level
- report dict: Aggregated assessment report
- validation_status: "valid" or "warning" based on field checks
- report_file_path: Path to persisted JSON file
- ui_output: Formatted data ready for Streamlit display

### Risk Threshold

The critical decision point occurs at Node 5 with threshold: **risk_score >= 0.6 (60%)**
- Scores 0.6 and above: Route to high-risk pathway for full diagnostic workup
- Scores below 0.6: Route to low-risk pathway for reassurance-focused guidance
- Both pathways converge at Node 10 for report compilation

## Color Legend

| Color | Purpose |
|-------|---------|
| Green (#e1f5e1) | Start/End nodes |
| Yellow (#fff4e1) | LLM Agents |
| Blue (#e1f0ff) | ML Agents |
| Red (#ffe1e1) | High-risk pathway |
| Light Green (#e1ffe1) | Low-risk pathway |
| Orange (#fff0cc) | Decision/Router node |

## State Management

The diagram illustrates SymptomOne's 15-field TypedDict state that flows through all 13 nodes:
- session_id: Unique session identifier
- extracted_data: Raw clinical input (11 required fields)
- symptom_classification: Structured symptom analysis
- severity_level: Classification result (Critical, High, Low, Moderate)
- risk_score: Numeric prediction (0.0-1.0)
- ml_results: Container for ML predictions
- risk_path: "high_risk_path" or "low_risk_path"
- differential_diagnoses: List of candidates with probabilities
- treatment_plan: Comprehensive treatment recommendations
- health_advice: Clinically appropriate guidance
- validation_status: Output validation result
- validation_errors: Accumulated error list
- ui_output: Formatted data for Streamlit UI
- report_file_path: Path to JSON report file
- report_json: Complete assessment report
