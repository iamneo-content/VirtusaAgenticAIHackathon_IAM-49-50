"""Train severity classification model"""
import pandas as pd
import pickle
import numpy as np
from pathlib import Path
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix


def train_severity_model():
    """Train RandomForest classifier for severity classification"""
    print("Training Severity Classification Model...")

    # Load cleaned data
    data_path = Path(__file__).parent.parent.parent / "data" / "processed" / "severity_cleaned.csv"
    df = pd.read_csv(data_path)
    print(f"  Loaded {len(df)} training samples")

    # Define features and target
    feature_cols = [
        "patient_age_years", "symptom_duration_hours", "fever_present",
        "neck_stiffness", "body_temperature_celsius", "heart_rate_bpm",
        "blood_pressure_systolic_mmhg", "blood_pressure_diastolic_mmhg",
        "respiratory_rate_breaths_per_minute", "oxygen_saturation_percent",
        "comorbidities_count"
    ]

    X = df[feature_cols].values
    y = df["severity_level"].values

    # Encode target
    label_encoder = LabelEncoder()
    y_encoded = label_encoder.fit_transform(y)
    severity_map = {i: label for i, label in enumerate(label_encoder.classes_)}
    print(f"  Classes: {severity_map}")

    # Scale features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X_scaled, y_encoded, test_size=0.2, random_state=42, stratify=y_encoded
    )

    print(f"  Training set: {len(X_train)}, Test set: {len(X_test)}")

    # Train RandomForest
    print("  Training RandomForest classifier...")
    model = RandomForestClassifier(
        n_estimators=100,
        max_depth=15,
        min_samples_split=5,
        min_samples_leaf=2,
        random_state=42,
        n_jobs=-1
    )
    model.fit(X_train, y_train)

    # Evaluate
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred, average="weighted")
    recall = recall_score(y_test, y_pred, average="weighted")
    f1 = f1_score(y_test, y_pred, average="weighted")

    print(f"\n  Model Performance:")
    print(f"    Accuracy:  {accuracy:.4f}")
    print(f"    Precision: {precision:.4f}")
    print(f"    Recall:    {recall:.4f}")
    print(f"    F1-Score:  {f1:.4f}")

    # Feature importance
    feature_importance = sorted(
        zip(feature_cols, model.feature_importances_),
        key=lambda x: x[1],
        reverse=True
    )
    print(f"\n  Top 5 Important Features:")
    for feat, imp in feature_importance[:5]:
        print(f"    {feat}: {imp:.4f}")

    # Save model and scaler
    model_dir = Path(__file__).parent.parent / "models"
    model_dir.mkdir(exist_ok=True)

    model_path = model_dir / "severity_classifier.pkl"
    scaler_path = model_dir / "severity_scaler.pkl"

    with open(model_path, "wb") as f:
        pickle.dump(model, f)
    print(f"\n  [SUCCESS] Model saved: {model_path}")

    with open(scaler_path, "wb") as f:
        pickle.dump(scaler, f)
    print(f"  [SUCCESS] Scaler saved: {scaler_path}")

    return True


if __name__ == "__main__":
    try:
        success = train_severity_model()
        if success:
            print("\n[SUCCESS] Severity model training complete!")
    except Exception as e:
        print(f"\n[ERROR] Error: {str(e)}")
        import traceback
        traceback.print_exc()
