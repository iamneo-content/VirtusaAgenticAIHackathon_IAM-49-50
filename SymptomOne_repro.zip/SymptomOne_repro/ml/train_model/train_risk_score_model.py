"""Train risk score regression model"""
import pandas as pd
import pickle
import numpy as np
from pathlib import Path
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score


def train_risk_score_model():
    """Train RandomForest regressor for risk score prediction"""
    print("Training Risk Score Regression Model...")

    # Load cleaned data
    data_path = Path(__file__).parent.parent.parent / "data" / "processed" / "risk_score_cleaned.csv"
    df = pd.read_csv(data_path)
    print(f"  Loaded {len(df)} training samples")

    # Define features and target
    feature_cols = [
        "patient_age_years", "symptom_duration_hours", "fever_present",
        "neck_stiffness", "body_temperature_celsius", "heart_rate_bpm",
        "blood_pressure_systolic_mmhg", "blood_pressure_diastolic_mmhg",
        "respiratory_rate_breaths_per_minute", "oxygen_saturation_percent",
        "comorbidities_count"
    ]

    X = df[feature_cols].values
    y = df["risk_score"].values

    print(f"  Risk score range: {y.min():.2f} - {y.max():.2f}, Mean: {y.mean():.2f}")

    # Scale features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X_scaled, y, test_size=0.2, random_state=42
    )

    print(f"  Training set: {len(X_train)}, Test set: {len(X_test)}")

    # Train RandomForest Regressor
    print("  Training RandomForest regressor...")
    model = RandomForestRegressor(
        n_estimators=100,
        max_depth=15,
        min_samples_split=5,
        min_samples_leaf=2,
        random_state=42,
        n_jobs=-1
    )
    model.fit(X_train, y_train)

    # Evaluate
    y_pred = model.predict(X_test)
    y_pred_clipped = np.clip(y_pred, 0.0, 1.0)

    mae = mean_absolute_error(y_test, y_pred_clipped)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred_clipped))
    r2 = r2_score(y_test, y_pred_clipped)

    print(f"\n  Model Performance:")
    print(f"    MAE (Mean Absolute Error): {mae:.4f}")
    print(f"    RMSE (Root Mean Squared Error): {rmse:.4f}")
    print(f"    R² Score: {r2:.4f}")

    # Feature importance
    feature_importance = sorted(
        zip(feature_cols, model.feature_importances_),
        key=lambda x: x[1],
        reverse=True
    )
    print(f"\n  Top 5 Important Features:")
    for feat, imp in feature_importance[:5]:
        print(f"    {feat}: {imp:.4f}")

    # Save model and scaler
    model_dir = Path(__file__).parent.parent / "models"
    model_dir.mkdir(exist_ok=True)

    model_path = model_dir / "risk_score_regressor.pkl"
    scaler_path = model_dir / "risk_score_scaler.pkl"

    with open(model_path, "wb") as f:
        pickle.dump(model, f)
    print(f"\n  [SUCCESS] Model saved: {model_path}")

    with open(scaler_path, "wb") as f:
        pickle.dump(scaler, f)
    print(f"  [SUCCESS] Scaler saved: {scaler_path}")

    return True


if __name__ == "__main__":
    try:
        success = train_risk_score_model()
        if success:
            print("\n[SUCCESS] Risk score model training complete!")
    except Exception as e:
        print(f"\n[ERROR] Error: {str(e)}")
        import traceback
        traceback.print_exc()
