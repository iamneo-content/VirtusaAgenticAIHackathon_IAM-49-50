"""ML Training Pipeline - Orchestrate model training"""
import sys
from pathlib import Path

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from ml.train_model.train_severity_model import train_severity_model
from ml.train_model.train_risk_score_model import train_risk_score_model


def run_training_pipeline():
    """Run complete ML training pipeline"""
    print("=" * 60)
    print("SYMPTOMONE ML TRAINING PIPELINE")
    print("=" * 60)

    try:
        # Train severity classifier
        print("\n[1/2] SEVERITY CLASSIFICATION MODEL")
        print("-" * 60)
        success_severity = train_severity_model()

        # Train risk score regressor
        print("\n[2/2] RISK SCORE REGRESSION MODEL")
        print("-" * 60)
        success_risk = train_risk_score_model()

        if success_severity and success_risk:
            print("\n" + "=" * 60)
            print("[SUCCESS] ALL MODELS TRAINED SUCCESSFULLY!")
            print("=" * 60)
            print("\nModels saved to: ml/models/")
            print("Ready for deployment!")
            return True
        else:
            print("\n[ERROR] Some models failed to train")
            return False

    except Exception as e:
        print(f"\n[ERROR] Pipeline error: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = run_training_pipeline()
    sys.exit(0 if success else 1)
