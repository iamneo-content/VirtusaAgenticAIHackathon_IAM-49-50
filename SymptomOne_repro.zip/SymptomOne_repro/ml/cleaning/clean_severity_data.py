"""Data cleaning script for severity training data"""
import pandas as pd
import numpy as np
from pathlib import Path


def clean_severity_data():
    """Clean severity training dataset"""
    print("Cleaning severity training data...")

    # Load data
    input_file = Path(__file__).parent.parent.parent / "data" / "training_dataset" / "severity_training.csv"
    output_file = Path(__file__).parent.parent.parent / "data" / "processed" / "severity_cleaned.csv"

    df = pd.read_csv(input_file)
    print(f"  Loaded: {len(df)} rows")

    # Handle NAN values
    print("  Handling NAN values...")
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    string_cols = df.select_dtypes(include=["object"]).columns

    # Numeric columns: impute with median
    for col in numeric_cols:
        if col not in ["severity_level", "risk_score"]:
            median_val = df[col].median()
            df[col].fillna(median_val, inplace=True)

    # String columns: impute with mode
    for col in string_cols:
        if col not in ["severity_level"]:
            mode_val = df[col].mode()
            if len(mode_val) > 0:
                df[col].fillna(mode_val[0], inplace=True)
            else:
                df[col].fillna("unknown", inplace=True)

    # Handle empty strings
    print("  Handling empty strings...")
    for col in string_cols:
        if col not in ["severity_level"]:
            df[col] = df[col].replace("", "unknown")

    # Validate and clip numeric ranges
    print("  Validating numeric ranges...")
    df["patient_age_years"] = df["patient_age_years"].clip(0, 120)
    df["symptom_duration_hours"] = df["symptom_duration_hours"].clip(0, 720)
    df["body_temperature_celsius"] = df["body_temperature_celsius"].clip(35.0, 42.0)
    df["heart_rate_bpm"] = df["heart_rate_bpm"].clip(30, 200)
    df["blood_pressure_systolic_mmhg"] = df["blood_pressure_systolic_mmhg"].clip(60, 200)
    df["blood_pressure_diastolic_mmhg"] = df["blood_pressure_diastolic_mmhg"].clip(40, 120)
    df["respiratory_rate_breaths_per_minute"] = df["respiratory_rate_breaths_per_minute"].clip(8, 40)
    df["oxygen_saturation_percent"] = df["oxygen_saturation_percent"].clip(70, 100)
    df["comorbidities_count"] = df["comorbidities_count"].clip(0, 10)

    # Ensure bool columns are 0 or 1
    df["fever_present"] = df["fever_present"].astype(int)
    df["neck_stiffness"] = df["neck_stiffness"].astype(int)

    # Remove any remaining NAN rows
    df = df.dropna()

    # Class balancing
    print("  Balancing classes...")
    severity_counts = df["severity_level"].value_counts()
    min_count = severity_counts.min()

    balanced_dfs = []
    for severity_class in ["Low", "Moderate", "High", "Critical"]:
        class_df = df[df["severity_level"] == severity_class]
        class_df = class_df.sample(n=min_count, random_state=42)
        balanced_dfs.append(class_df)

    df_balanced = pd.concat(balanced_dfs, ignore_index=True)
    df_balanced = df_balanced.sample(frac=1).reset_index(drop=True)

    # Save cleaned data
    df_balanced.to_csv(output_file, index=False)
    print(f"  [SUCCESS] Cleaned and saved: {output_file}")
    print(f"    Final dataset: {len(df_balanced)} rows")
    print(f"    Class distribution:")
    for severity_class in ["Low", "Moderate", "High", "Critical"]:
        count = len(df_balanced[df_balanced["severity_level"] == severity_class])
        print(f"      {severity_class}: {count} rows")

    return True


if __name__ == "__main__":
    try:
        success = clean_severity_data()
        if success:
            print("\n[SUCCESS] Severity data cleaning complete!")
    except Exception as e:
        print(f"\n[ERROR] Error: {str(e)}")
        import traceback
        traceback.print_exc()
