"""Model Evaluation - Evaluate severity and risk score models"""

import pickle
import numpy as np
import pandas as pd
from pathlib import Path
from typing import Dict, Any
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    mean_absolute_error, mean_squared_error, r2_score,
)


def evaluate_all_models(
    evaluation_dir: str = "data/evaluation_dataset",
    model_dir: str = "ml/models"
) -> Dict[str, Any]:
    """Evaluate both severity classifier and risk score regressor models"""

    results = {
        "status": "success",
        "models": {
            "severity_classifier": {},
            "risk_score_regressor": {}
        },
        "error": None
    }

    try:
        feature_names = [
            "patient_age_years", "symptom_duration_hours", "fever_present",
            "neck_stiffness", "body_temperature_celsius", "heart_rate_bpm",
            "blood_pressure_systolic_mmhg", "blood_pressure_diastolic_mmhg",
            "respiratory_rate_breaths_per_minute", "oxygen_saturation_percent",
            "comorbidities_count"
        ]

        # EVALUATE SEVERITY CLASSIFIER
        try:
            severity_model_path = Path(model_dir) / "severity_classifier.pkl"
            severity_scaler_path = Path(model_dir) / "severity_scaler.pkl"

            if severity_model_path.exists() and severity_scaler_path.exists():
                with open(severity_model_path, "rb") as f:
                    severity_model = pickle.load(f)
                with open(severity_scaler_path, "rb") as f:
                    severity_scaler = pickle.load(f)

                severity_eval_path = Path(evaluation_dir) / "severity_eval.csv"
                if severity_eval_path.exists():
                    df = pd.read_csv(severity_eval_path)
                    X = df[feature_names].values
                    y = df["severity_level"].values

                    X = np.nan_to_num(X, 0.0)
                    X_scaled = severity_scaler.transform(X)
                    y_pred_numeric = severity_model.predict(X_scaled)

                    label_encoder = LabelEncoder()
                    label_encoder.fit(['Critical', 'High', 'Low', 'Moderate'])
                    y_encoded = label_encoder.transform(y)
                    y_pred_encoded = y_pred_numeric

                    results["models"]["severity_classifier"] = {
                        "model_name": "Severity Classifier",
                        "metrics": {
                            "accuracy": float(accuracy_score(y_encoded, y_pred_encoded)),
                            "precision": float(precision_score(y_encoded, y_pred_encoded, average="weighted", zero_division=0)),
                            "recall": float(recall_score(y_encoded, y_pred_encoded, average="weighted", zero_division=0)),
                            "f1_score": float(f1_score(y_encoded, y_pred_encoded, average="weighted", zero_division=0)),
                            "num_samples": int(len(df)),
                            "num_features": len(feature_names)
                        },
                        "status": "success"
                    }
                else:
                    results["models"]["severity_classifier"] = {
                        "model_name": "Severity Classifier",
                        "metrics": {},
                        "status": "evaluation_data_not_found"
                    }
            else:
                results["models"]["severity_classifier"] = {
                    "model_name": "Severity Classifier",
                    "metrics": {},
                    "status": "model_not_found"
                }

        except Exception as e:
            results["models"]["severity_classifier"] = {
                "model_name": "Severity Classifier",
                "metrics": {},
                "status": "error",
                "error": str(e)
            }

        # EVALUATE RISK SCORE REGRESSOR
        try:
            risk_model_path = Path(model_dir) / "risk_score_regressor.pkl"
            risk_scaler_path = Path(model_dir) / "risk_score_scaler.pkl"

            if risk_model_path.exists() and risk_scaler_path.exists():
                with open(risk_model_path, "rb") as f:
                    risk_model = pickle.load(f)
                with open(risk_scaler_path, "rb") as f:
                    risk_scaler = pickle.load(f)

                risk_eval_path = Path(evaluation_dir) / "risk_score_eval.csv"
                if risk_eval_path.exists():
                    df = pd.read_csv(risk_eval_path)
                    X = df[feature_names].values
                    y = df["risk_score"].values

                    X = np.nan_to_num(X, 0.0)
                    X_scaled = risk_scaler.transform(X)
                    y_pred = np.clip(risk_model.predict(X_scaled), 0.0, 1.0)

                    results["models"]["risk_score_regressor"] = {
                        "model_name": "Risk Score Regressor",
                        "metrics": {
                            "mae": float(mean_absolute_error(y, y_pred)),
                            "rmse": float(np.sqrt(mean_squared_error(y, y_pred))),
                            "r2_score": float(r2_score(y, y_pred)),
                            "num_samples": int(len(df)),
                            "num_features": len(feature_names)
                        },
                        "status": "success"
                    }
                else:
                    results["models"]["risk_score_regressor"] = {
                        "model_name": "Risk Score Regressor",
                        "metrics": {},
                        "status": "evaluation_data_not_found"
                    }
            else:
                results["models"]["risk_score_regressor"] = {
                    "model_name": "Risk Score Regressor",
                    "metrics": {},
                    "status": "model_not_found"
                }

        except Exception as e:
            results["models"]["risk_score_regressor"] = {
                "model_name": "Risk Score Regressor",
                "metrics": {},
                "status": "error",
                "error": str(e)
            }

    except Exception as e:
        results["status"] = "error"
        results["error"] = str(e)

    return results
