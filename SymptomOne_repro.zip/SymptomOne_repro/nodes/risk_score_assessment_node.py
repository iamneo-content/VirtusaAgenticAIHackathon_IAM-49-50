"""Node 4: Risk Score Assessment - Calculate risk score using ML"""
from state import SymptomOneState
from agents.risk_score_ml import RiskScoreMLAgent


def risk_score_assessment_node(state: SymptomOneState) -> SymptomOneState:
    """Node 4: Calculate clinical risk score using ML regressor"""
    try:
        print("[Node 4] Calculating risk score with ML regressor...")
        agent = RiskScoreMLAgent()
        risk_score = agent.predict_clinical_risk_score(state.get("extracted_data", {}))

        state["risk_score"] = risk_score
        state["ml_results"] = state.get("ml_results", {})
        state["ml_results"]["risk_score"] = risk_score

        print(f"[Node 4] Risk score calculated: {risk_score:.3f}")
        return state
    except Exception as e:
        print(f"[Node 4] Error: {str(e)}")
        state["risk_score"] = 0.5
        state["validation_errors"] = state.get("validation_errors", [])
        state["validation_errors"].append(f"Risk score assessment error: {str(e)}")
        return state
