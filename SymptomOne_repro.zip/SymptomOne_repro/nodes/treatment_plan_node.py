"""Node 7: Treatment Plan - Generate treatment plan (high-risk path)"""
from state import SymptomOneState
from agents.treatment_plan_llm import TreatmentPlanLLMAgent


def treatment_plan_node(state: SymptomOneState) -> SymptomOneState:
    """Node 7: Generate comprehensive treatment plan (high-risk path only)"""
    try:
        print("[Node 7] Generating treatment plan...")
        agent = TreatmentPlanLLMAgent()
        result = agent.generate_comprehensive_treatment_plan(
            state.get("extracted_data", {}),
            state.get("severity_level", "Unknown"),
            state.get("differential_diagnoses", {}).get("diagnoses", [])
        )
        state["treatment_plan"] = result
        print("[Node 7] Treatment plan generated")
        return state
    except Exception as e:
        print(f"[Node 7] Error: {str(e)}")
        state["treatment_plan"] = {}
        state["validation_errors"] = state.get("validation_errors", [])
        state["validation_errors"].append(f"Treatment plan error: {str(e)}")
        return state
