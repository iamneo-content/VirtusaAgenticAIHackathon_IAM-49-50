"""Node 13: Output Formatting - Format final output for UI"""
from state import SymptomOneState


def output_formatting_node(state: SymptomOneState) -> SymptomOneState:
    """Node 13: Format final output for Streamlit UI display"""
    try:
        print("[Node 13] Formatting output...")

        # Note: For LOW-RISK cases (risk_score < 0.6), differential_diagnoses and
        # treatment_plan will have status="low_risk_path" explicitly set by low_risk_advice_node
        # This allows UI to distinguish between "low-risk so skipped" vs "error/missing"

        state["ui_output"] = {
            "session_id": state.get("session_id", "unknown"),
            "severity": state.get("severity_level", "Unknown"),
            "risk_score": state.get("risk_score", 0.5),
            "risk_level": "HIGH" if state.get("risk_score", 0.5) >= 0.6 else "LOW",
            "completion_percentage": 100.0,  # All data provided upfront in JSON mode
            "health_advice": state.get("health_advice", ""),
            "differential_diagnoses": state.get("differential_diagnoses", {}),
            "treatment_plan": state.get("treatment_plan", {}),
            "validation_status": state.get("validation_status", "unknown"),
            "validation_errors": state.get("validation_errors", []),
            "status": "completed"
        }

        print("[Node 13] Output formatted for UI")
        return state
    except Exception as e:
        print(f"[Node 13] Error: {str(e)}")
        state["ui_output"] = {"error": str(e), "status": "failed"}
        state["validation_errors"] = state.get("validation_errors", [])
        state["validation_errors"].append(f"Output formatting error: {str(e)}")
        return state
