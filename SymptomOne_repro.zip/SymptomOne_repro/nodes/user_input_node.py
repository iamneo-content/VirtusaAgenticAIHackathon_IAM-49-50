"""Node 1: Validate JSON Input - Entry point for workflow"""
from state import SymptomOneState


def user_input_node(state: SymptomOneState) -> SymptomOneState:
    """Node 1: Entry point - Validate JSON patient data completeness"""
    try:
        print("[Node 1] Validating JSON input...")

        patient_data = state.get("extracted_data", {})

        # Define 11 required clinical fields
        required_fields = [
            "patient_age_years",
            "symptom_duration_hours",
            "fever_present",
            "neck_stiffness",
            "body_temperature_celsius",
            "heart_rate_bpm",
            "blood_pressure_systolic_mmhg",
            "blood_pressure_diastolic_mmhg",
            "respiratory_rate_breaths_per_minute",
            "oxygen_saturation_percent",
            "comorbidities_count"
        ]

        # Check for missing fields
        missing_fields = [f for f in required_fields if f not in patient_data]

        if missing_fields:
            error_msg = f"Missing required fields: {', '.join(missing_fields)}"
            state["validation_errors"] = state.get("validation_errors", [])
            state["validation_errors"].append(error_msg)
            print(f"  [WARNING] Validation failed: {error_msg}")
        else:
            print(f"  [SUCCESS] All 11 clinical fields validated successfully")

        return state
    except Exception as e:
        print(f"[Node 1] Error: {str(e)}")
        state["validation_errors"] = state.get("validation_errors", [])
        state["validation_errors"].append(f"Validation error: {str(e)}")
        return state
