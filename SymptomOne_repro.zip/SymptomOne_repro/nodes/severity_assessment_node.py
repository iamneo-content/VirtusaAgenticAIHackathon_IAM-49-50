"""Node 3: Severity Assessment - Assess symptom severity using ML"""
from state import SymptomOneState
from agents.severity_assessment_ml import SeverityAssessmentMLAgent


def severity_assessment_node(state: SymptomOneState) -> SymptomOneState:
    """Node 3: Assess symptom severity using ML classifier"""
    try:
        print("[Node 3] Assessing severity with ML classifier...")
        agent = SeverityAssessmentMLAgent()
        severity_level = agent.predict_severity_classification(state.get("extracted_data", {}))

        state["severity_level"] = severity_level
        state["ml_results"] = state.get("ml_results", {})
        state["ml_results"]["severity"] = severity_level

        print(f"[Node 3] Severity assessed: {severity_level}")
        return state
    except Exception as e:
        print(f"[Node 3] Error: {str(e)}")
        state["severity_level"] = "Moderate"
        state["validation_errors"] = state.get("validation_errors", [])
        state["validation_errors"].append(f"Severity assessment error: {str(e)}")
        return state
