"""Node 9: Low Risk Advice - Generate reassuring health advice (low-risk path)"""
from state import SymptomOneState
from agents.health_advice_llm import HealthAdviceLLMAgent


def low_risk_advice_node(state: SymptomOneState) -> SymptomOneState:
    """Node 9: Generate reassuring health advice for low-risk cases"""
    try:
        print("[Node 9] Generating low-risk health advice...")
        agent = HealthAdviceLLMAgent()
        advice = agent.provide_clinical_guidance(
            state.get("extracted_data", {}),
            state.get("risk_score", 0.5),
            state.get("severity_level", "Unknown"),
            is_high_risk=False
        )
        state["health_advice"] = advice

        # For low-risk cases, explicitly mark diagnosis/treatment as not applicable
        # This distinguishes "low-risk path" from "error/missing data"
        if state.get("differential_diagnoses") is None:
            state["differential_diagnoses"] = {"status": "low_risk_path", "diagnoses": []}
        if state.get("treatment_plan") is None:
            state["treatment_plan"] = {"status": "low_risk_path"}

        print("[Node 9] Low-risk advice generated")
        return state
    except Exception as e:
        print(f"[Node 9] Error: {str(e)}")
        state["health_advice"] = "Monitor your symptoms. If they persist, consult a healthcare provider."
        # Explicitly set diagnosis/treatment for error case too
        if state.get("differential_diagnoses") is None:
            state["differential_diagnoses"] = {"status": "low_risk_path", "diagnoses": []}
        if state.get("treatment_plan") is None:
            state["treatment_plan"] = {"status": "low_risk_path"}
        state["validation_errors"] = state.get("validation_errors", [])
        state["validation_errors"].append(f"Low-risk advice error: {str(e)}")
        return state
