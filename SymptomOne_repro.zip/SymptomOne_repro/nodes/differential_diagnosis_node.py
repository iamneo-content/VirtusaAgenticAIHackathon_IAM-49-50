"""Node 6: Differential Diagnosis - Generate differential diagnoses (high-risk path)"""
from state import SymptomOneState
from agents.differential_diagnosis_llm import DifferentialDiagnosisLLMAgent


def differential_diagnosis_node(state: SymptomOneState) -> SymptomOneState:
    """Node 6: Generate differential diagnoses (high-risk path only)"""
    try:
        print("[Node 6] Generating differential diagnoses...")
        agent = DifferentialDiagnosisLLMAgent()
        result = agent.assess_differential_diagnoses(
            state.get("extracted_data", {}),
            state.get("severity_level", "Unknown"),
            state.get("symptom_classification")  # Pass symptom classification for enhanced diagnosis
        )
        state["differential_diagnoses"] = result
        print(f"[Node 6] Generated {len(result.get('diagnoses', []))} differential diagnoses")
        return state
    except Exception as e:
        print(f"[Node 6] Error: {str(e)}")
        state["differential_diagnoses"] = {"diagnoses": []}
        state["validation_errors"] = state.get("validation_errors", [])
        state["validation_errors"].append(f"Differential diagnosis error: {str(e)}")
        return state
