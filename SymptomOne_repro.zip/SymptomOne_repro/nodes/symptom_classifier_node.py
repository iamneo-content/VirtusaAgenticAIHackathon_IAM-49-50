"""Symptom Classifier Node - Classify symptom descriptions in the workflow"""

from state import SymptomOneState
from agents.symptom_classifier_llm import SymptomClassifierLLMAgent


def symptom_classifier_node(state: SymptomOneState) -> SymptomOneState:
    """Node 2: Classify symptom description into structured medical categories"""
    try:
        print("[Symptom Classifier] Classifying symptoms...")

        # Get symptom description from extracted_data
        extracted_data = state.get("extracted_data", {})
        symptom_description = extracted_data.get("symptom_description", "")

        # If no symptom description provided, skip classification
        if not symptom_description or symptom_description.strip() == "":
            print("[Symptom Classifier] No symptom description provided, skipping classification")
            state["symptom_classification"] = {
                "primary_symptom": "Not Provided",
                "status": "skipped"
            }
            return state

        # Run classification
        agent = SymptomClassifierLLMAgent()
        result = agent.classify_symptoms(symptom_description, extracted_data)

        # Store classification in state
        state["symptom_classification"] = result

        # Add primary symptom to extracted_data for ML models and downstream nodes
        state["extracted_data"]["symptom_type"] = result.get("primary_symptom", "Unknown")

        print(f"[Symptom Classifier] Primary symptom: {result.get('primary_symptom', 'Unknown')}")
        print(f"[Symptom Classifier] Severity descriptor: {result.get('severity_descriptor', 'Unknown')}")
        print(f"[Symptom Classifier] Onset pattern: {result.get('onset_pattern', 'Unknown')}")

        if result.get("red_flags") and len(result.get("red_flags", [])) > 0:
            print(f"[Symptom Classifier] [WARNING] Red flags identified: {len(result.get('red_flags', []))}")
            for flag in result.get("red_flags", [])[:3]:  # Show first 3
                print(f"  - {flag}")

        return state

    except Exception as e:
        print(f"[Symptom Classifier] Error: {str(e)}")
        state["symptom_classification"] = {
            "primary_symptom": "Classification Error",
            "status": "error"
        }
        state["extracted_data"]["symptom_type"] = "Unknown"
        state["validation_errors"] = state.get("validation_errors", [])
        state["validation_errors"].append(f"Symptom classification error: {str(e)}")
        return state
