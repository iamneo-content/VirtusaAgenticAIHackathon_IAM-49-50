"""Node 12: Save Report - Persist final report to output directory"""
import json
from pathlib import Path
from datetime import datetime
from state import SymptomOneState


def save_report_node(state: SymptomOneState) -> SymptomOneState:
    """Node 12: Save final report to output directory as JSON"""
    try:
        print("[Node 12] Saving report...")

        # Create output directory if it doesn't exist
        output_dir = Path("output")
        output_dir.mkdir(exist_ok=True)

        # Get session ID
        session_id = state.get("session_id", "unknown")

        # Build comprehensive report
        report = {
            "session_id": session_id,
            "timestamp": datetime.now().isoformat(),
            "patient_data": {
                "extracted_fields": state.get("extracted_data", {}),
                "completion_percentage": 100.0,  # All data provided upfront in JSON mode
            },
            "assessment": {
                "severity_level": state.get("severity_level", "Unknown"),
                "risk_score": state.get("risk_score", 0.0),
                "risk_level": "HIGH" if state.get("risk_score", 0.5) >= 0.6 else "LOW",
            },
            "clinical_analysis": {
                "differential_diagnoses": state.get("differential_diagnoses", {}),
                "treatment_plan": state.get("treatment_plan", {}),
                "health_advice": state.get("health_advice", ""),
            },
            "validation": {
                "validation_status": state.get("validation_status", "unknown"),
                "validation_errors": state.get("validation_errors", []),
            }
        }

        # Save report as JSON
        report_file = output_dir / f"{session_id}.json"
        with open(report_file, "w") as f:
            json.dump(report, f, indent=2)

        print(f"[Node 12] Report saved: {report_file}")

        # Store report file path in state for download functionality
        state["report_file_path"] = str(report_file)
        state["report_json"] = json.dumps(report, indent=2)

        return state
    except Exception as e:
        print(f"[Node 12] Error saving report: {str(e)}")
        state["validation_errors"] = state.get("validation_errors", [])
        state["validation_errors"].append(f"Report save error: {str(e)}")
        return state
