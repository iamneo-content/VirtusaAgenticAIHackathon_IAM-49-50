"""Node 10: Report Compilation - Compile final assessment report"""
from state import SymptomOneState


def report_compilation_node(state: SymptomOneState) -> SymptomOneState:
    """Node 10: Compile final assessment report"""
    try:
        print("[Node 10] Compiling final report...")

        state["report"] = {
            "severity_level": state.get("severity_level", "Unknown"),
            "risk_score": state.get("risk_score", 0.5),
            "differential_diagnoses": state.get("differential_diagnoses", {}),
            "treatment_plan": state.get("treatment_plan", {}),
            "health_advice": state.get("health_advice", ""),
            "extracted_fields": state.get("extracted_data", {})
        }

        print("[Node 10] Report compiled")
        return state
    except Exception as e:
        print(f"[Node 10] Error: {str(e)}")
        state["report"] = {}
        state["validation_errors"] = state.get("validation_errors", [])
        state["validation_errors"].append(f"Report compilation error: {str(e)}")
        return state
