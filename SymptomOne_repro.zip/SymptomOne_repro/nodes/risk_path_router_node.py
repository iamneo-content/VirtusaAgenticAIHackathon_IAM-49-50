"""Node 5: Risk Path Router - Route based on risk score"""
from state import SymptomOneState


def risk_path_router_node(state: SymptomOneState) -> SymptomOneState:
    """Node 5: Route based on risk score - decision node for high/low risk paths"""
    try:
        risk_score = state.get("risk_score", 0.5)
        risk_path = "high_risk_path" if risk_score >= 0.6 else "low_risk_path"
        state["risk_path"] = risk_path
        print(f"[Node 5] Risk routing: {risk_path} (score: {risk_score:.3f})")
        return state
    except Exception as e:
        print(f"[Node 5] Error: {str(e)}")
        state["risk_path"] = "low_risk_path"
        state["validation_errors"] = state.get("validation_errors", [])
        state["validation_errors"].append(f"Risk routing error: {str(e)}")
        return state
