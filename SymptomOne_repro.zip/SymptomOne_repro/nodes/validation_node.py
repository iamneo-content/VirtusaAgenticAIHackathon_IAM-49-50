"""Node 11: Validation - Validate final output"""
from state import SymptomOneState


def validation_node(state: SymptomOneState) -> SymptomOneState:
    """Node 11: Validate final assessment output"""
    try:
        print("[Node 11] Validating output...")

        required_fields = ["severity_level", "risk_score", "health_advice", "report"]
        missing = [f for f in required_fields if not state.get(f)]

        if missing:
            state["validation_status"] = "warning"
            state["validation_errors"].append(f"Missing fields: {missing}")
        else:
            state["validation_status"] = "valid"

        print(f"[Node 11] Validation complete: {state['validation_status']}")
        return state
    except Exception as e:
        print(f"[Node 11] Error: {str(e)}")
        state["validation_status"] = "error"
        state["validation_errors"] = state.get("validation_errors", [])
        state["validation_errors"].append(f"Validation error: {str(e)}")
        return state
