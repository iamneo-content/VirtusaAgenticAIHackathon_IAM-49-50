"""Node 8: High Risk Advice - Generate urgent health advice (high-risk path)"""
from state import SymptomOneState
from agents.health_advice_llm import HealthAdviceLLMAgent


def high_risk_advice_node(state: SymptomOneState) -> SymptomOneState:
    """Node 8: Generate urgent health advice for high-risk cases"""
    try:
        print("[Node 8] Generating high-risk health advice...")
        agent = HealthAdviceLLMAgent()
        advice = agent.provide_clinical_guidance(
            state.get("extracted_data", {}),
            state.get("risk_score", 0.5),
            state.get("severity_level", "Unknown"),
            is_high_risk=True,
            diagnoses=state.get("differential_diagnoses", {}).get("diagnoses", [])
        )
        state["health_advice"] = advice
        print("[Node 8] High-risk advice generated")
        return state
    except Exception as e:
        print(f"[Node 8] Error: {str(e)}")
        state["health_advice"] = "Please seek immediate medical attention."
        state["validation_errors"] = state.get("validation_errors", [])
        state["validation_errors"].append(f"High-risk advice error: {str(e)}")
        return state
