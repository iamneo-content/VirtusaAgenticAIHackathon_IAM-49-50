"""Symptom Classifier LLM Agent - Classify symptom descriptions into structured categories"""

from typing import Dict, Any
from agents.base_llm_agent import BaseLLMAgent


class SymptomClassifierLLMAgent(BaseLLMAgent):
    """Classify free-text symptom descriptions into structured medical categories"""

    def classify_symptoms(self, symptom_description: str, extracted_fields: Dict[str, Any]) -> Dict[str, Any]:
        """
        Classify free-text symptom description with clinical context

        Args:
            symptom_description: Free-text patient symptom description
            extracted_fields: Clinical vitals for context (age, vitals, etc.)

        Returns:
            Dict with symptom classification including type, severity, onset, character, red flags
        """
        # Extract context from clinical data
        age = extracted_fields.get("patient_age_years", "unknown")
        duration = extracted_fields.get("symptom_duration_hours", "unknown")
        fever = extracted_fields.get("fever_present", 0)

        # Format vital signs for context
        temp = extracted_fields.get("body_temperature_celsius", "N/A")
        hr = extracted_fields.get("heart_rate_bpm", "N/A")
        bp_sys = extracted_fields.get("blood_pressure_systolic_mmhg", "N/A")
        bp_dia = extracted_fields.get("blood_pressure_diastolic_mmhg", "N/A")
        rr = extracted_fields.get("respiratory_rate_breaths_per_minute", "N/A")
        o2 = extracted_fields.get("oxygen_saturation_percent", "N/A")
        vitals = f"Temp={temp}°C, HR={hr} bpm, BP={bp_sys}/{bp_dia} mmHg, RR={rr} breaths/min, O2Sat={o2}%"

        prompt = f"""
        Classify the following patient symptom description into structured medical categories:

        SYMPTOM DESCRIPTION:
        {symptom_description}

        CLINICAL CONTEXT:
        - Patient Age: {age} years
        - Duration: {duration} hours
        - Fever Present: {'Yes' if fever else 'No'}
        - Vitals: {vitals}

        Analyze the symptom description and return a JSON with the following structure:
        {{
          "primary_symptom": "Select from: Headache, Chest Pain, Abdominal Pain, Respiratory Distress, Fever/Infection, Neurological Symptoms, Musculoskeletal, Cardiovascular, Gastrointestinal, or Other",
          "severity_descriptor": "Mild, Moderate, Severe, or Critical",
          "associated_symptoms": ["symptom1", "symptom2", "symptom3"],
          "onset_pattern": "Sudden, Gradual, or Chronic",
          "character": "Describe as Sharp, Dull, Throbbing, Cramping, Burning, Pressure, or Other",
          "location": "anatomical location if mentioned",
          "red_flags": ["concerning feature 1", "concerning feature 2"],
          "confidence": "high, medium, or low"
        }}

        IMPORTANT INSTRUCTIONS:
        1. Focus on medically significant details from the symptom description
        2. Red flags are concerning features that require immediate medical attention
        3. Identify red flags even if the patient doesn't mention them explicitly (e.g., "worst headache of my life" + high fever + stiff neck = meningitis red flags)
        4. Be thorough in identifying associated symptoms
        5. Set confidence based on how clearly the symptoms are described
        """

        return self.client.generate_json(prompt)
