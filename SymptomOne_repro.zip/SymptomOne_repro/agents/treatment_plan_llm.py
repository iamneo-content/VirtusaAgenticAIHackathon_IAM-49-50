"""Treatment Plan LLM Agent - Generate comprehensive clinical treatment plans"""
from typing import Dict, List, Any, Optional
from agents.base_llm_agent import BaseLLMAgent


class TreatmentPlanLLMAgent(BaseLLMAgent):
    """Generate comprehensive treatment plans for high-risk clinical cases"""

    def generate_comprehensive_treatment_plan(
        self,
        extracted_fields: Dict[str, Any],
        severity_level: str,
        differential_diagnoses: Optional[List[Dict]] = None
    ) -> Dict[str, Any]:
        """
        Generate detailed clinical treatment plan based on diagnoses and severity

        Args:
            extracted_fields: Extracted clinical data
            severity_level: Clinical severity classification
            differential_diagnoses: List of differential diagnoses

        Returns:
            Comprehensive treatment plan with interventions, tests, and medications
        """
        # Format clinical presentation from extracted fields
        age = extracted_fields.get("patient_age_years", "unknown")
        symptom_type = extracted_fields.get("symptom_type", "unknown")
        duration = extracted_fields.get("symptom_duration_hours", "unknown")
        fever = extracted_fields.get("fever_present", "unknown")
        temp = extracted_fields.get("body_temperature_celsius", "unknown")
        hr = extracted_fields.get("heart_rate_bpm", "unknown")
        symptoms = extracted_fields.get("associated_symptoms", "none")

        presentation = f"{age}-year-old patient with {duration}-hour {symptom_type}"
        if fever:
            presentation += f", fever (temp {temp}°C)"
        if hr != "NOT_PROVIDED":
            presentation += f", heart rate {hr} bpm"
        if symptoms and symptoms != "NOT_PROVIDED":
            presentation += f", associated symptoms: {symptoms}"

        # Format top differential diagnoses
        diagnoses_text = ""
        if differential_diagnoses:
            diagnoses_text = "\n".join([
                f"- {d.get('diagnosis', 'Unknown')}: {d.get('probability', 'unknown')} probability"
                for d in differential_diagnoses[:3]
            ])

        prompt = f"""
        Generate a comprehensive treatment plan for this HIGH-RISK patient.

        Clinical Presentation: {presentation}
        Severity: {severity_level}

        Top Differential Diagnoses:
        {diagnoses_text}

        Return JSON with this structure:
        {{
          "immediate_interventions": ["action 1", "action 2", ...],
          "recommended_tests": ["test 1", "test 2", ...],
          "medications": [
            {{"name": "drug name", "dosage": "dosage", "purpose": "why prescribed"}},
            ...
          ],
          "monitoring_plan": "description of ongoing monitoring",
          "follow_up_timeline": "when to follow up",
          "specialist_referrals": ["specialist 1", "specialist 2", ...]
        }}

        Be specific and medically appropriate for emergency/urgent care settings.
        """

        return self.client.generate_json(prompt)
