"""Health Advice LLM Agent - Generate personalized clinical guidance"""
from typing import Dict, List, Any
from agents.base_llm_agent import BaseLLMAgent


class HealthAdviceLLMAgent(BaseLLMAgent):
    """Generate personalized health advice for high and low risk clinical scenarios"""

    def provide_clinical_guidance(
        self,
        extracted_fields: Dict[str, Any],
        risk_score: float,
        severity_level: str,
        is_high_risk: bool,
        diagnoses: Any = None
    ) -> str:
        """
        Generate clinical guidance based on risk level and patient data

        Args:
            extracted_fields: Extracted clinical data
            risk_score: Risk score (0.0-1.0)
            severity_level: Severity classification
            is_high_risk: True for urgent guidance, False for reassuring guidance
            diagnoses: List of differential diagnoses (for high-risk cases)

        Returns:
            Personalized clinical guidance text
        """
        # Format clinical presentation from extracted fields
        age = extracted_fields.get("patient_age_years", "unknown")
        symptom_type = extracted_fields.get("symptom_type", "unknown")
        duration = extracted_fields.get("symptom_duration_hours", "unknown")
        fever = extracted_fields.get("fever_present", "unknown")
        temp = extracted_fields.get("body_temperature_celsius", "unknown")

        presentation = f"{age}y {symptom_type} x{duration}h"
        if fever:
            presentation += f", fever {temp}°C"

        # Get top diagnosis if available
        if diagnoses and len(diagnoses) > 0:
            top_diagnosis = diagnoses[0].get("diagnosis", "Unknown")
        else:
            top_diagnosis = "Unknown"

        if is_high_risk:
            prompt = f"""
            Generate URGENT health advice for HIGH-RISK patient:

            Clinical: {presentation}
            Severity: {severity_level}, Risk: {risk_score:.2f}
            Top Diagnosis: {top_diagnosis}

            Provide:
            1. CRITICAL ALERT
            2. IMMEDIATE ACTIONS (emergency services)
            3. Why this is urgent
            4. What to expect at hospital
            5. Warning signs
            """
        else:
            prompt = f"""
            Generate reassuring health advice for LOW-RISK patient:

            Clinical: {presentation}
            Severity: {severity_level}, Risk: {risk_score:.2f}

            Provide:
            1. Reassurance (symptoms manageable)
            2. Self-care recommendations
            3. OTC options
            4. When to see doctor (warning signs)
            5. Follow-up timeline
            """

        return self.client.generate_text(prompt)
