"""Base LLM Agent class"""
import json
from typing import Dict, Any, Optional
from utils import GeminiClient


class BaseLLMAgent:
    """Base class for all LLM agents"""

    def __init__(self, client: Optional[GeminiClient] = None):
        """
        Initialize base LLM agent

        Args:
            client: GeminiClient instance (creates new if None)
        """
        self.client = client or GeminiClient()
