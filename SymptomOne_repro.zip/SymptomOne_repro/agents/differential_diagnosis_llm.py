"""Differential Diagnosis LLM Agent - Generate differential diagnoses from clinical data"""
from typing import Dict, Any, Optional
from agents.base_llm_agent import BaseLLMAgent


class DifferentialDiagnosisLLMAgent(BaseLLMAgent):
    """Generate differential diagnoses from clinical presentation and severity"""

    def assess_differential_diagnoses(
        self,
        extracted_fields: Dict[str, Any],
        severity_level: str,
        symptom_classification: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Generate differential diagnoses based on clinical presentation and severity

        Args:
            extracted_fields: Extracted clinical data from patient
            severity_level: Severity classification (Low/Moderate/High/Critical)
            symptom_classification: Optional LLM-based symptom classification with red flags

        Returns:
            Dictionary with list of differential diagnoses with probabilities
        """
        # Format clinical presentation from extracted fields
        age = extracted_fields.get("patient_age_years", "unknown")
        symptom_type = extracted_fields.get("symptom_type", "unknown")
        duration = extracted_fields.get("symptom_duration_hours", "unknown")
        fever = extracted_fields.get("fever_present", "unknown")
        temp = extracted_fields.get("body_temperature_celsius", "unknown")
        hr = extracted_fields.get("heart_rate_bpm", "unknown")
        bp_sys = extracted_fields.get("blood_pressure_systolic_mmhg", "unknown")
        bp_dia = extracted_fields.get("blood_pressure_diastolic_mmhg", "unknown")
        rr = extracted_fields.get("respiratory_rate_breaths_per_minute", "unknown")
        o2_sat = extracted_fields.get("oxygen_saturation_percent", "unknown")

        presentation = f"{age}y {symptom_type} x{duration}h"
        if fever:
            presentation += f", fever {temp}°C"
        if hr != "NOT_PROVIDED":
            presentation += f", HR {hr}"

        # Build vitals summary
        vitals = f"BP {bp_sys}/{bp_dia}, RR {rr}, O2 {o2_sat}%"

        # Enhance with symptom classification if available
        symptom_details = ""
        if symptom_classification and symptom_classification.get("status") != "skipped":
            primary = symptom_classification.get("primary_symptom", "unknown")
            character = symptom_classification.get("character", "")
            onset = symptom_classification.get("onset_pattern", "")
            associated = symptom_classification.get("associated_symptoms", [])
            red_flags = symptom_classification.get("red_flags", [])

            symptom_details = f"\nSYMPTOM CLASSIFICATION:\n"
            symptom_details += f"- Primary Symptom: {primary}\n"
            if character:
                symptom_details += f"- Character: {character}\n"
            if onset:
                symptom_details += f"- Onset: {onset}\n"
            if associated:
                symptom_details += f"- Associated Symptoms: {', '.join(associated[:3])}\n"
            if red_flags:
                symptom_details += f"- [WARNING] RED FLAGS: {', '.join(red_flags)}\n"

        prompt = f"""
        Generate 5-7 differential diagnoses for this clinical presentation:

        PATIENT DEMOGRAPHICS & PRESENTATION:
        Age: {age} years
        Chief Complaint: {symptom_type} (duration {duration} hours)
        {symptom_details}
        VITALS: {vitals}
        Fever: {'Yes, ' + str(temp) + '°C' if fever else 'No'}
        Severity Level: {severity_level}

        Generate differential diagnoses ranked by likelihood. Consider the severity level and any red flags.

        Return JSON:
        {{
          "diagnoses": [
            {{"diagnosis": "condition name", "probability": "high/medium/low", "reasoning": "brief explanation"}}
          ]
        }}
        """

        return self.client.generate_json(prompt)
