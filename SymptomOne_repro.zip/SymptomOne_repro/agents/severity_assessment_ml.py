"""Severity Assessment ML Agent - Classify clinical symptom severity level"""
import pickle
import numpy as np
from pathlib import Path
from typing import Dict, Any


class SeverityAssessmentMLAgent:
    """ML agent for classifying symptom severity using trained RandomForest model"""

    def __init__(self):
        """Initialize severity assessment agent with pre-trained model"""
        self.model_path = Path("ml/models/severity_classifier.pkl")
        self.scaler_path = Path("ml/models/severity_scaler.pkl")
        self.model = None
        self.scaler = None
        # FIXED: LabelEncoder sorts classes alphabetically during training
        # Training uses: LabelEncoder().classes_ = ['Critical', 'High', 'Low', 'Moderate']
        self.severity_map = {0: "Critical", 1: "High", 2: "Low", 3: "Moderate"}
        self.feature_names = [
            "patient_age_years", "symptom_duration_hours", "fever_present",
            "neck_stiffness", "body_temperature_celsius", "heart_rate_bpm",
            "blood_pressure_systolic_mmhg", "blood_pressure_diastolic_mmhg",
            "respiratory_rate_breaths_per_minute", "oxygen_saturation_percent",
            "comorbidities_count"
        ]
        if self.model_path.exists():
            with open(self.model_path, "rb") as f:
                self.model = pickle.load(f)
        if self.scaler_path.exists():
            with open(self.scaler_path, "rb") as f:
                self.scaler = pickle.load(f)

    def predict_severity_classification(self, extracted_fields: Dict[str, Any]) -> str:
        """
        Predict clinical severity classification from extracted clinical fields

        Args:
            extracted_fields: Extracted clinical data dictionary

        Returns:
            Severity level: Low, Moderate, High, or Critical
        """
        # Build feature vector from extracted fields
        features = []
        for feature_name in self.feature_names:
            value = extracted_fields.get(feature_name, "NOT_PROVIDED")
            if value == "NOT_PROVIDED":
                features.append(np.nan)
            else:
                features.append(float(value))

        feature_vector = np.array(features, dtype=float)
        feature_vector = np.nan_to_num(feature_vector, 0.0)
        feature_vector = self.scaler.transform([feature_vector])[0]

        prediction = self.model.predict([feature_vector])[0]
        return self.severity_map[int(prediction)]
