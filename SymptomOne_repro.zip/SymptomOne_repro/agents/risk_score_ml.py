"""Risk Score ML Agent - Calculate clinical risk score for patient prioritization"""
import pickle
import numpy as np
from pathlib import Path
from typing import Dict, Any


class RiskScoreMLAgent:
    """ML agent for risk score prediction using trained RandomForest regressor"""

    def __init__(self):
        """Initialize risk score agent with pre-trained model"""
        self.model_path = Path("ml/models/risk_score_regressor.pkl")
        self.scaler_path = Path("ml/models/risk_score_scaler.pkl")
        self.model = None
        self.scaler = None
        self.feature_names = [
            "patient_age_years", "symptom_duration_hours", "fever_present",
            "neck_stiffness", "body_temperature_celsius", "heart_rate_bpm",
            "blood_pressure_systolic_mmhg", "blood_pressure_diastolic_mmhg",
            "respiratory_rate_breaths_per_minute", "oxygen_saturation_percent",
            "comorbidities_count"
        ]
        if self.model_path.exists():
            with open(self.model_path, "rb") as f:
                self.model = pickle.load(f)
        if self.scaler_path.exists():
            with open(self.scaler_path, "rb") as f:
                self.scaler = pickle.load(f)

    def predict_clinical_risk_score(self, extracted_fields: Dict[str, Any]) -> float:
        """
        Predict clinical risk score from extracted clinical fields

        Args:
            extracted_fields: Extracted clinical data dictionary

        Returns:
            Risk score as float between 0.0 and 1.0
        """
        # Build feature vector from extracted fields
        features = []
        for feature_name in self.feature_names:
            value = extracted_fields.get(feature_name, "NOT_PROVIDED")
            if value == "NOT_PROVIDED":
                features.append(np.nan)
            else:
                features.append(float(value))

        feature_vector = np.array(features, dtype=float)
        feature_vector = np.nan_to_num(feature_vector, 0.0)
        feature_vector = self.scaler.transform([feature_vector])[0]

        risk_score = self.model.predict([feature_vector])[0]
        return float(np.clip(risk_score, 0.0, 1.0))
