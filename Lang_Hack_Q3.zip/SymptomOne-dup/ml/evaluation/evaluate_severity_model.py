"""
Evaluation scaffold for severity assessment model using evaluation_dataset.
Loads the cleaned eval set from processed/ and applies a saved model/vectorizer.
"""

import os
import joblib
import pandas as pd
from sklearn.metrics import classification_report, accuracy_score

EVAL_PATH = "processed/severity_eval_clean.csv"
MODEL_PATHS = ["ml/model/severity_model.pkl", "ml/model/severity_model.joblib"]         # expected classifier
VECT_PATHS = ["ml/model/severity_vectorizer.pkl", "ml/model/severity_vectorizer.joblib"]     # expected vectorizer


def load_data(path=EVAL_PATH):
    return pd.read_csv(path)


def _load_first(paths):
    for p in paths:
        if os.path.exists(p):
            return joblib.load(p)
    return None


def evaluate_severity_model():
    """Return metrics and text report for severity model; raises FileNotFoundError if artifacts missing."""
    model = _load_first(MODEL_PATHS)
    vectorizer = _load_first(VECT_PATHS)
    if not (model and vectorizer):
        raise FileNotFoundError("Model/vectorizer missing. Train and save them under ml/model/ before evaluating.")

    df = load_data()
    X = vectorizer.transform(df["clean_text"].fillna(""))
    y = df["severity_label"]

    preds = model.predict(X)

    metrics = {
        "accuracy": accuracy_score(y, preds),
        "num_samples": len(df),
    }
    report = classification_report(y, preds)
    return metrics, report


if __name__ == "__main__":
    try:
        metrics, report = evaluate_severity_model()
        print("Accuracy:", metrics["accuracy"])
        print("Classification report:\n", report)
    except FileNotFoundError as e:
        print(e)
