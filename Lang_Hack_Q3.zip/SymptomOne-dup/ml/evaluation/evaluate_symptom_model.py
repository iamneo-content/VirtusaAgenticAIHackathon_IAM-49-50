"""
Evaluation scaffold for symptom classification model using evaluation_dataset.
Loads the cleaned eval set from processed/ and applies a saved model/vectorizer.
"""

import os
import ast
import joblib
import pandas as pd
from sklearn.metrics import classification_report, hamming_loss

EVAL_PATH = "processed/symptom_eval_clean.csv"
MODEL_PATHS = ["ml/model/symptom_model.pkl", "ml/model/symptom_model.joblib"]
VECT_PATHS = ["ml/model/symptom_vectorizer.pkl", "ml/model/symptom_vectorizer.joblib"]
MLB_PATHS = ["ml/model/symptom_mlb.pkl", "ml/model/symptom_mlb.joblib"]


def load_data(path=EVAL_PATH):
    df = pd.read_csv(path)
    # labels column stored as list string -> convert back
    df["labels"] = df["labels"].apply(lambda x: ast.literal_eval(x) if isinstance(x, str) else [])
    return df


def _load_first(paths):
    for p in paths:
        if os.path.exists(p):
            return joblib.load(p)
    return None


def evaluate_symptom_model():
    """Return metrics and text report for symptom model; raises FileNotFoundError if artifacts missing."""
    model = _load_first(MODEL_PATHS)
    vectorizer = _load_first(VECT_PATHS)
    mlb = _load_first(MLB_PATHS)
    if not (model and vectorizer and mlb):
        raise FileNotFoundError("Model/vectorizer/label binarizer missing. Train and save them under ml/model/ before evaluating.")

    df = load_data()
    X = vectorizer.transform(df["clean_text"].fillna(""))
    y = df["labels"]
    y_bin = mlb.transform(y)

    preds = model.predict(X)
    if hasattr(preds, "toarray"):
        preds = preds.toarray()

    metrics = {
        "hamming_loss": hamming_loss(y_bin, preds),
        "num_samples": len(df),
    }
    report = classification_report(y_bin, preds, target_names=mlb.classes_)
    return metrics, report


if __name__ == "__main__":
    try:
        metrics, report = evaluate_symptom_model()
        print("Hamming loss:", metrics["hamming_loss"])
        print("Classification report:\n", report)
    except FileNotFoundError as e:
        print(e)
