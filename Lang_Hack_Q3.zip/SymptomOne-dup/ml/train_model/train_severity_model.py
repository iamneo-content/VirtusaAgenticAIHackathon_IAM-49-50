"""
Training scaffold for the severity assessment model.
Loads cleaned severity data, prepares features and labels.
Model implementation is left to the user to plug in.
"""

import os
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
import joblib

CLEAN_PATH = "processed/severity_train_clean.csv"
MODEL_DIR = "ml/model"


def load_data(path=CLEAN_PATH):
    return pd.read_csv(path)


def build_features(df: pd.DataFrame):
    vectorizer = TfidfVectorizer(max_features=5000, ngram_range=(1, 2))
    X = vectorizer.fit_transform(df["clean_text"].fillna(""))
    y = df["severity_label"]
    return X, y, vectorizer


def train():
    df = load_data()
    X, y, vectorizer = build_features(df)

    model = LogisticRegression(max_iter=1000)
    model.fit(X, y)

    os.makedirs(MODEL_DIR, exist_ok=True)
    joblib.dump(vectorizer, os.path.join(MODEL_DIR, "severity_vectorizer.pkl"))
    joblib.dump(model, os.path.join(MODEL_DIR, "severity_model.pkl"))
    print("Saved severity model and vectorizer to ml/model/ (.pkl)")


if __name__ == "__main__":
    train()
