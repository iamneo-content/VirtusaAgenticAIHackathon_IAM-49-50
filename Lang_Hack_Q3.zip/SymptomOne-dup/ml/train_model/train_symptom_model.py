"""
Training scaffold for the symptom classification model.
Loads cleaned symptom data and prepares features/labels.
Model implementation is left to the user to plug in.
"""

import os
import ast
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.multiclass import OneVsRestClassifier
from sklearn.svm import LinearSVC
from sklearn.preprocessing import MultiLabelBinarizer
import joblib

CLEAN_PATH = "processed/symptom_train_clean.csv"
MODEL_DIR = "ml/model"


def load_data(path=CLEAN_PATH):
    df = pd.read_csv(path)
    # labels column is a stringified list; convert back
    df["labels"] = df["labels"].apply(lambda x: ast.literal_eval(x) if isinstance(x, str) else [])
    return df


def build_features(df: pd.DataFrame):
    vectorizer = TfidfVectorizer(max_features=5000, ngram_range=(1, 2))
    X = vectorizer.fit_transform(df["clean_text"].fillna(""))
    labels = df["labels"]
    mlb = MultiLabelBinarizer()
    y = mlb.fit_transform(labels)
    return X, y, vectorizer, mlb


def train():
    df = load_data()
    X, y, vectorizer, mlb = build_features(df)

    model = OneVsRestClassifier(LinearSVC())
    model.fit(X, y)

    os.makedirs(MODEL_DIR, exist_ok=True)
    joblib.dump(vectorizer, os.path.join(MODEL_DIR, "symptom_vectorizer.pkl"))
    joblib.dump(model, os.path.join(MODEL_DIR, "symptom_model.pkl"))
    joblib.dump(mlb, os.path.join(MODEL_DIR, "symptom_mlb.pkl"))
    print("Saved symptom model, vectorizer, and label binarizer to ml/model/ (.pkl)")


if __name__ == "__main__":
    train()
