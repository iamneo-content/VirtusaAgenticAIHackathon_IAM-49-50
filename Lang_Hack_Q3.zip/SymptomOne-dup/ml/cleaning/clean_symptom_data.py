"""
Cleaning script for symptom classification dataset.
Prepares text and labels for downstream ML training.
"""

import os
import re
import pandas as pd

RAW_TRAIN_PATH = "data/training_dataset/symptom_training.csv"
RAW_EVAL_PATH = "data/evaluation_dataset/symptom_eval.csv"
OUTPUT_DIR = "processed"


def _normalize_text(text: str) -> str:
    if not isinstance(text, str):
        return ""
    text = text.strip()
    text = re.sub(r"\s+", " ", text)
    return text


def _split_labels(label_str: str):
    if not isinstance(label_str, str):
        return []
    return [lbl.strip() for lbl in label_str.split(",") if lbl.strip()]


def clean_symptom_df(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["clean_text"] = df["case_text"].apply(_normalize_text)
    df["labels"] = df["symptom_labels"].apply(_split_labels)
    return df[["case_id", "clean_text", "labels", "age_years", "sex", "duration_days", "comorbidity_list", "negation_terms", "language_code", "source_channel"]]


def run():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    train_df = pd.read_csv(RAW_TRAIN_PATH)
    eval_df = pd.read_csv(RAW_EVAL_PATH)

    train_clean = clean_symptom_df(train_df)
    eval_clean = clean_symptom_df(eval_df)

    train_out = os.path.join(OUTPUT_DIR, "symptom_train_clean.csv")
    eval_out = os.path.join(OUTPUT_DIR, "symptom_eval_clean.csv")

    train_clean.to_csv(train_out, index=False)
    eval_clean.to_csv(eval_out, index=False)

    print(f"Saved symptom train -> {train_out} ({len(train_clean)})")
    print(f"Saved symptom eval  -> {eval_out} ({len(eval_clean)})")


if __name__ == "__main__":
    run()
