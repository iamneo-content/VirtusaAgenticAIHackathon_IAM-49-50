================================================================================
SYMPTOMONE AI - AGENT TO AGENT COMMUNICATION FLOW DIAGRAM
================================================================================

MERMAID DIAGRAM CODE:
--------------------------------------------------------------------------------

graph TD
    Start([Patient Input]) --> DCA[Data Collection Agent]

    DCA -->|Text Cleaned & Metadata Extracted| ParallelSplit{Parallel Execution}

    ParallelSplit -->|Branch A| SCA[Symptom Classification Agent ML]
    ParallelSplit -->|Branch B| SAA[Severity Assessment Agent ML]

    SCA -->|Primary Symptoms Identified| RiskMerge{Risk Router Wait}
    SAA -->|Severity Level & Risk Score Computed| RiskMerge

    RiskMerge --> RRN[Risk Router Node]

    RRN -->|Risk Score >= 0.6| HighRiskPath{HIGH RISK PATH}
    RRN -->|Risk Score < 0.6| LowRiskPath{LOW RISK PATH}

    HighRiskPath --> DDA[Differential Diagnosis Agent LLM]
    DDA -->|Top 5 Diagnoses Generated| TPA[Treatment Planning Agent LLM]
    TPA -->|Treatment Plan Created| MEA[Medication Evidence Agent LLM]
    MEA -->|Medications Validated| SafetyMerge{Convergence Point}

    LowRiskPath --> ADA[Advisory Agent LLM]
    ADA -->|General Advice Generated| SafetyMerge

    SafetyMerge --> SVN[Safety Validator Node]
    SVN -->|Safety Check Failed| AutoReject[Auto-Reject & Log Error]
    SVN -->|Safety Check Passed| PEA[Patient Explainer Agent LLM]

    AutoReject --> ErrorEnd([Flow Complete with Errors])

    PEA -->|Plain Language Summary Created| RGN[Report Generator Node]
    RGN -->|Report Formatted| ESN[Evaluation Saver Node]
    ESN -->|Report Saved to Output Directory| End([Flow Complete])

    style DCA fill:#e1f5ff,stroke:#01579b,stroke-width:2px
    style SCA fill:#f3e5f5,stroke:#4a148c,stroke-width:2px
    style SAA fill:#f3e5f5,stroke:#4a148c,stroke-width:2px
    style RRN fill:#fff3e0,stroke:#e65100,stroke-width:3px
    style DDA fill:#e8f5e9,stroke:#1b5e20,stroke-width:2px
    style TPA fill:#e8f5e9,stroke:#1b5e20,stroke-width:2px
    style MEA fill:#e8f5e9,stroke:#1b5e20,stroke-width:2px
    style ADA fill:#fff9c4,stroke:#f57f17,stroke-width:2px
    style SVN fill:#ffebee,stroke:#c62828,stroke-width:2px
    style PEA fill:#e1bee7,stroke:#6a1b9a,stroke-width:2px
    style RGN fill:#e0f2f1,stroke:#004d40,stroke-width:2px
    style ESN fill:#e0f2f1,stroke:#004d40,stroke-width:2px
    style Start fill:#fce4ec,stroke:#880e4f,stroke-width:3px
    style End fill:#c8e6c9,stroke:#2e7d32,stroke-width:3px
    style ErrorEnd fill:#ffcdd2,stroke:#b71c1c,stroke-width:3px
    style ParallelSplit fill:#bbdefb,stroke:#0d47a1,stroke-width:2px,stroke-dasharray: 5 5
    style RiskMerge fill:#bbdefb,stroke:#0d47a1,stroke-width:2px,stroke-dasharray: 5 5
    style HighRiskPath fill:#ffccbc,stroke:#d84315,stroke-width:2px,stroke-dasharray: 5 5
    style LowRiskPath fill:#fff9c4,stroke:#f9a825,stroke-width:2px,stroke-dasharray: 5 5
    style SafetyMerge fill:#bbdefb,stroke:#0d47a1,stroke-width:2px,stroke-dasharray: 5 5
    style AutoReject fill:#ffcdd2,stroke:#c62828,stroke-width:2px


================================================================================
AGENT COMMUNICATION DETAILS
================================================================================

PHASE 1: DATA INGESTION
--------------------------------------------------------------------------------
Agent: Data Collection Agent
Input: Raw symptom paragraph (string)
Output: Cleaned text + metadata (duration, age, negations)
Next: Triggers parallel execution of classification agents


PHASE 2: PARALLEL CLASSIFICATION
--------------------------------------------------------------------------------
Branch A - Symptom Classification Agent (ML)
Input: Cleaned text
Processing: ML model prediction (TF-IDF + MultiLabel Classifier)
Output: Primary symptoms, secondary symptoms, body systems
Waits at: Risk Router merge point

Branch B - Severity Assessment Agent (ML)
Input: Cleaned text + classification results
Processing: ML model prediction (TF-IDF + Multiclass Classifier)
Output: Severity level (Critical/High/Moderate/Low), urgency, risk score
Waits at: Risk Router merge point

Synchronization: Both agents must complete before Risk Router proceeds


PHASE 3: RISK ASSESSMENT AND ROUTING
--------------------------------------------------------------------------------
Node: Risk Router Node
Input: Results from both parallel agents
Processing:
  - Evaluates risk score from severity assessment
  - Applies red flag boost (+0.2 if red flags present)
  - Calculates final risk score
Decision Logic:
  - IF risk_score >= 0.6 THEN route to HIGH RISK PATH
  - IF risk_score < 0.6 THEN route to LOW RISK PATH
Output: Risk level (HIGH/LOW) + routing decision


PHASE 4A: HIGH RISK PATH (Critical Cases)
--------------------------------------------------------------------------------
Sequential Agent Chain:

Agent 1: Differential Diagnosis Agent (LLM)
Input: Symptoms + classification + severity
Processing: Gemini LLM generates differential diagnoses
Output: Top 5 diagnoses with confidence levels and rationale
Next: Treatment Planning Agent

Agent 2: Treatment Planning Agent (LLM)
Input: Symptoms + diagnoses + severity
Processing: Gemini LLM creates comprehensive treatment plan
Output: Immediate actions, medications, lifestyle, follow-up
Next: Medication Evidence Agent

Agent 3: Medication Evidence Agent (LLM)
Input: Treatment plan with medications
Processing: Gemini LLM validates medications and adds safety info
Output: Validated medications with warnings and monitoring
Next: Converges to Safety Validator


PHASE 4B: LOW RISK PATH (Minor Cases)
--------------------------------------------------------------------------------
Agent: Advisory Agent (LLM)
Input: Symptoms + classification
Processing: Gemini LLM generates general health advice
Output: General advice and reasoning
Next: Converges to Safety Validator


PHASE 5: SAFETY VALIDATION
--------------------------------------------------------------------------------
Node: Safety Validator Node
Input: All recommendations (from HIGH or LOW path)
Processing: Validates safety of all recommendations
Decision Logic:
  - IF safety issues detected THEN auto-reject with error log
  - IF safety passed THEN proceed to patient explainer
Output: Safety status + warnings (if any)


PHASE 6: PATIENT COMMUNICATION
--------------------------------------------------------------------------------
Agent: Patient Explainer Agent (LLM)
Input: Complete triage results
Processing: Gemini LLM converts medical jargon to plain language
Output: Patient-friendly summary
Next: Report Generator


PHASE 7: REPORT GENERATION
--------------------------------------------------------------------------------
Node: Report Generator Node
Input: Complete workflow state
Processing: Formats structured report using format_output_report()
Output: Formatted text report
Next: Evaluation Saver


PHASE 8: OUTPUT PERSISTENCE
--------------------------------------------------------------------------------
Node: Evaluation Saver Node
Input: Complete state + formatted report
Processing:
  - Creates timestamped output directory
  - Saves report to file
  - Logs evaluation metrics
Output: File path + metrics
End: Workflow complete


================================================================================
DECISION POINTS AND CONDITIONAL LOGIC
================================================================================

DECISION POINT 1: Parallel Execution Split
Location: After Data Collection Agent
Condition: Always splits into 2 parallel branches
Branches:
  - Branch A: Symptom Classification
  - Branch B: Severity Assessment
Synchronization: Both must complete before merging


DECISION POINT 2: Risk Router Decision
Location: After parallel branches merge
Condition: risk_score >= 0.6
Outcomes:
  - TRUE: Route to HIGH RISK PATH (differential diagnosis chain)
  - FALSE: Route to LOW RISK PATH (advisory only)
Impact: Determines depth of medical analysis


DECISION POINT 3: Safety Validation Gate
Location: After HIGH/LOW path convergence
Condition: Safety checks pass
Outcomes:
  - PASS: Continue to patient explainer
  - FAIL: Auto-reject and log error (emergency stop)
Impact: Ensures no unsafe recommendations reach output


================================================================================
DATA FLOW SUMMARY
================================================================================

INPUT:
  Patient symptom paragraph (string)

PROCESSING STAGES:
  Stage 1: Text normalization and metadata extraction
  Stage 2: Parallel ML classification (symptoms + severity)
  Stage 3: Risk assessment and routing decision
  Stage 4: Conditional analysis (HIGH: full medical analysis, LOW: advice)
  Stage 5: Safety validation gate
  Stage 6: Patient-friendly translation
  Stage 7: Report formatting
  Stage 8: File persistence

OUTPUT:
  - Structured triage report (text file)
  - Risk level classification
  - Medical recommendations
  - Patient summary
  - Evaluation metrics


================================================================================
ERROR HANDLING AND FALLBACKS
================================================================================

Data Collection Agent Failure:
  - Returns empty metadata
  - Uses raw text as cleaned text
  - Workflow continues

Classification Agent Failure:
  - Sets classification_error in state
  - Marks symptom_classifier_complete as False
  - May block risk router (raises ValueError)

Severity Assessment Agent Failure:
  - Sets classification_error in state
  - Risk router will raise ValueError
  - Workflow stops (cannot proceed without severity)

Risk Router Requirements:
  - MUST have severity_assessor_complete = True
  - Otherwise raises ValueError: "Severity assessment incomplete"

LLM Agent Failures:
  - Caught by try/except in nodes
  - Error message stored in state
  - Completion flag set to False
  - Report includes error section

Safety Validator Failure:
  - Marks safety_passed = False
  - Routes to auto-reject path
  - Generates error report
  - Workflow terminates early


================================================================================
PERFORMANCE CHARACTERISTICS
================================================================================

Parallel Execution Benefit:
  - Symptom Classification and Severity Assessment run simultaneously
  - Reduces total latency by ~40-50%
  - Independent processing with no data dependencies

Conditional Path Optimization:
  - LOW risk cases skip expensive LLM calls
  - Saves 3 Gemini API calls per low-risk case
  - ~60% faster for minor symptoms

Agent Execution Times (Approximate):
  - Data Collection: 50ms (pure Python)
  - ML Agents: 100-200ms each (joblib model inference)
  - LLM Agents: 2-5 seconds each (Gemini API calls)
  - Report Generation: 100ms (string formatting)

Total Workflow Time:
  - LOW risk path: 3-5 seconds
  - HIGH risk path: 10-20 seconds


================================================================================
AGENT TECHNOLOGY STACK
================================================================================

ML-Based Agents:
  - Symptom Classification Agent: scikit-learn MultiLabelBinarizer + Classifier
  - Severity Assessment Agent: scikit-learn TF-IDF + Multiclass Classifier
  - Technology: Trained on synthetic medical data

LLM-Based Agents:
  - Differential Diagnosis Agent: Google Gemini 2.0 Flash
  - Treatment Planning Agent: Google Gemini 2.0 Flash
  - Medication Evidence Agent: Google Gemini 2.0 Flash
  - Advisory Agent: Google Gemini 2.0 Flash
  - Patient Explainer Agent: Google Gemini 2.0 Flash
  - Configuration: Temperature 0.2-0.3 for consistency

Rule-Based Agents:
  - Data Collection Agent: Python regex and text processing
  - Risk Router Node: Threshold-based decision logic
  - Safety Validator Node: Rule-based safety checks

Orchestration:
  - Framework: LangGraph (state management + workflow)
  - State: TypedDict with 30+ fields
  - Execution: Compiled state graph with conditional edges


================================================================================
END OF AGENT FLOW DIAGRAM
================================================================================
