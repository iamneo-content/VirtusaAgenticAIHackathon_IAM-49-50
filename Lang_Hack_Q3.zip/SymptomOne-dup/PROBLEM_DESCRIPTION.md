================================================================================
SYMPTOMONE AI - MEDICAL TRIAGE AUTOMATION SYSTEM
PROBLEM DESCRIPTION DOCUMENT
================================================================================

--------------------------------------------------------------------------------
PROBLEM STATEMENT
--------------------------------------------------------------------------------

In modern healthcare, the initial triage process is critical for determining
the urgency and severity of patient conditions. However, this process is often:

1. Time-consuming - Medical professionals must manually assess each patient
2. Resource-intensive - Requires trained healthcare workers for initial screening
3. Inconsistent - Human assessment can vary based on experience and workload
4. Delayed - Patients may wait hours for initial assessment in busy facilities
5. Limited access - Rural or underserved areas lack immediate triage capabilities

SymptomOne addresses these challenges by providing an AI-powered medical triage
system that can:

- Instantly analyze patient symptom descriptions
- Classify symptoms and assess severity automatically
- Generate differential diagnoses with confidence levels
- Create comprehensive treatment plans and recommendations
- Provide risk assessment and urgency classification
- Generate detailed medical reports for healthcare providers

This system aims to serve as an educational tool and proof-of-concept for
automated medical triage using modern AI technologies, specifically multi-agent
architectures with LangGraph and Google Gemini language models.


--------------------------------------------------------------------------------
SOLUTION ARCHITECTURE
--------------------------------------------------------------------------------

SymptomOne uses a multi-agent workflow architecture with the following flow:

1. DATA COLLECTION PHASE
   Input: Raw symptom paragraph from patient
   Output: Cleaned text with extracted metadata

2. PARALLEL CLASSIFICATION PHASE
   Branch A: Symptom Classification (ML-based)
   Branch B: Severity Assessment (ML-based)
   Both branches execute simultaneously

3. RISK ROUTING PHASE
   Decision: HIGH risk or LOW risk
   Threshold: Risk score >= 0.6 = HIGH risk

4. CONDITIONAL PROCESSING
   HIGH Risk Path:
   - Differential Diagnosis (LLM-based)
   - Treatment Planning (LLM-based)
   - Medication Evidence (LLM-based)

   LOW Risk Path:
   - General Advisory (LLM-based)

5. VALIDATION AND REPORTING
   - Safety Validator
   - Patient-Friendly Explainer
   - Report Generator
   - Evaluation Saver


--------------------------------------------------------------------------------
PROJECT FILE STRUCTURE
--------------------------------------------------------------------------------

SymptomOne-dup/
│
├── main.py
├── graph.py
├── state.py
├── tests.py
├── requirements.txt
├── .env
│
├── agents/
│   ├── __init__.py
│   ├── data_collection.py
│   ├── symptom_classification_ml.py
│   ├── severity_assessment_ml.py
│   ├── differential_llm.py
│   ├── treatment_llm.py
│   ├── advisory_llm.py
│   ├── med_evidence_llm.py
│   └── patient_explainer_llm.py
│
├── nodes/
│   ├── __init__.py
│   ├── data_collection_node.py
│   ├── symptom_classifier_node.py
│   ├── severity_assessor_node.py
│   ├── risk_router_node.py
│   ├── differential_node.py
│   ├── treatment_planner_node.py
│   ├── med_evidence_node.py
│   ├── advice_generator_node.py
│   ├── safety_validator_node.py
│   ├── patient_explainer_node.py
│   ├── report_generator_node.py
│   └── evaluation_saver_node.py
│
├── workflow/
│   ├── __init__.py
│   └── workflow.py
│
├── ml/
│   ├── __init__.py
│   ├── model/
│   │   └── (trained model files)
│   ├── train_model/
│   │   ├── train_symptom_model.py
│   │   └── train_severity_model.py
│   ├── cleaning/
│   │   ├── clean_symptom_data.py
│   │   └── clean_severity_data.py
│   └── evaluation/
│       ├── evaluate_symptom_model.py
│       └── evaluate_severity_model.py
│
├── data/
│   └── (training datasets)
│
├── processed/
│   └── (cleaned datasets)
│
└── output/
    └── (generated triage reports)


--------------------------------------------------------------------------------
FILE PURPOSES AND KEY METHODS
--------------------------------------------------------------------------------

=== CORE APPLICATION FILES ===

FILE: main.py
PURPOSE: Streamlit web interface for user interaction
KEY COMPONENTS:
- Streamlit UI setup with page configuration
- Input form for symptom paragraph collection
- Display tabs for results (Classification, Diagnosis, Treatment, Report)
- Model evaluation buttons for offline testing
- Medical disclaimer and warnings


FILE: graph.py
PURPOSE: Entry point for triage workflow execution
KEY FUNCTION:
  Function: run_triage
  Parameters:
    - symptom_paragraph (str): Patient's symptom description
  Returns:
    - Dict: Complete state with all analysis results
  Description: Initializes state, builds workflow, executes graph


FILE: state.py
PURPOSE: Defines the state schema for the entire workflow
KEY COMPONENTS:
  TypedDict: SymptomOneState
  Fields:
    - symptom_paragraph: str
    - cleaned_text: str
    - metadata: Dict
    - symptom_classification: Dict
    - severity_assessment: Dict
    - risk_level: str (HIGH/LOW)
    - risk_score: float
    - differential_diagnosis: List[Dict]
    - treatment_plan: Dict
    - advice: str
    - patient_friendly_summary: str
    - Various completion flags (bool)
    - Error tracking fields

  Function: slugify
  Parameters:
    - text (str): Text to convert to filename-safe slug
  Returns:
    - str: Slugified text (max 50 chars)
  Description: Converts text to safe filename format

  Function: save_file
  Parameters:
    - path (str): File path to save
    - content (str): Content to write
  Returns: None
  Description: Saves content to file, creates directories if needed

  Function: format_output_report
  Parameters:
    - state (SymptomOneState): Complete workflow state
  Returns:
    - str: Formatted report text
  Description: Generates human-readable triage report


FILE: tests.py
PURPOSE: Comprehensive test suite with 15 test cases
KEY TEST CLASSES:
  - TestSlugifyReturns: Tests for slugify function
  - TestDataCollectionAgentReturns: Tests for data collection methods
  - TestRiskRouterNodeReturns: Tests for risk routing logic
  - TestConditionalRouting: Tests for workflow conditional branching
  - TestParallelExecution: Tests for parallel node execution


=== AGENT FILES ===

FILE: agents/data_collection.py
PURPOSE: Text normalization and metadata extraction
KEY CLASS: DataCollectionAgent
  Method: process
  Parameters:
    - symptom_text (str): Raw symptom description
  Returns:
    - Dict with keys: cleaned_text, metadata
  Description: Cleans text and extracts duration, age, negations

  Method: _clean_text
  Parameters:
    - text (str): Text to clean
  Returns:
    - str: Normalized text
  Description: Removes extra whitespace, normalizes punctuation

  Method: _extract_metadata
  Parameters:
    - text (str): Text to analyze
  Returns:
    - Dict: Extracted metadata (duration, age, negations)
  Description: Uses regex to extract temporal and demographic info

Function: run_data_collection
Parameters:
  - state (SymptomOneState): Current workflow state
Returns:
  - SymptomOneState: Updated state with cleaned data
Description: Executes data collection agent on state


FILE: agents/symptom_classification_ml.py
PURPOSE: ML-based symptom classification
KEY CLASS: SymptomClassificationAgent
  Method: classify
  Parameters:
    - cleaned_text (str): Normalized symptom text
  Returns:
    - Dict: primary_symptoms, secondary_symptoms, body_systems
  Description: Uses trained ML model to classify symptoms

Function: run_symptom_classification
Parameters:
  - state (SymptomOneState): Current state
Returns:
  - SymptomOneState: State with symptom_classification populated
Description: Executes symptom classifier, handles errors


FILE: agents/severity_assessment_ml.py
PURPOSE: ML-based severity assessment
KEY CLASS: SeverityAssessmentAgent
  Method: assess
  Parameters:
    - cleaned_text (str): Normalized text
    - classification (Dict): Symptom classification results
  Returns:
    - Dict: severity_level, urgency, red_flags, risk_score
  Description: Predicts severity (Critical/High/Moderate/Low)

Function: run_severity_assessment
Parameters:
  - state (SymptomOneState): Current state
Returns:
  - SymptomOneState: State with severity_assessment and risk_score
Description: Executes severity assessor


FILE: agents/differential_llm.py
PURPOSE: LLM-based differential diagnosis generation
KEY CLASS: DifferentialDiagnosisAgent
  Method: generate_diagnoses
  Parameters:
    - symptoms (str): Patient symptoms
    - classification (Dict): Classification results
    - severity (Dict): Severity assessment
  Returns:
    - Dict: differential_diagnosis list, reasoning text
  Description: Uses Gemini LLM to generate top 5 diagnoses

Function: run_differential_diagnosis
Parameters:
  - state (SymptomOneState): Current state
Returns:
  - SymptomOneState: State with differential_diagnosis populated
Description: Executes differential diagnosis agent


FILE: agents/treatment_llm.py
PURPOSE: LLM-based treatment plan generation
KEY CLASS: TreatmentPlanningAgent
  Method: create_treatment_plan
  Parameters:
    - symptoms (str): Patient symptoms
    - diagnoses (List[Dict]): Differential diagnoses
    - severity (Dict): Severity assessment
  Returns:
    - Dict: immediate_actions, medications, lifestyle, follow_up
  Description: Creates comprehensive treatment recommendations

Function: run_treatment_planning
Parameters:
  - state (SymptomOneState): Current state
Returns:
  - SymptomOneState: State with treatment_plan populated
Description: Executes treatment planner


FILE: agents/advisory_llm.py
PURPOSE: General health advice for low-risk cases
KEY CLASS: AdvisoryAgent
  Method: generate_advice
  Parameters:
    - symptoms (str): Patient symptoms
    - classification (Dict): Symptom classification
  Returns:
    - Dict: advice text, reasoning
  Description: Provides general wellness recommendations

Function: run_advisory
Parameters:
  - state (SymptomOneState): Current state
Returns:
  - SymptomOneState: State with advice populated
Description: Executes advisory agent for low-risk path


FILE: agents/med_evidence_llm.py
PURPOSE: Medication evidence and safety validation
KEY CLASS: MedicationEvidenceAgent
  Method: validate_medications
  Parameters:
    - treatment_plan (Dict): Proposed treatment
  Returns:
    - Dict: validated_medications with safety notes
  Description: Validates medications and adds safety information

Function: run_med_evidence
Parameters:
  - state (SymptomOneState): Current state
Returns:
  - SymptomOneState: State with med_evidence populated
Description: Executes medication evidence agent


FILE: agents/patient_explainer_llm.py
PURPOSE: Patient-friendly explanation generation
KEY CLASS: PatientExplainerAgent
  Method: generate_explanation
  Parameters:
    - state (SymptomOneState): Complete triage state
  Returns:
    - str: Patient-friendly summary
  Description: Converts medical jargon to plain language

Function: run_patient_explainer
Parameters:
  - state (SymptomOneState): Current state
Returns:
  - SymptomOneState: State with patient_friendly_summary
Description: Executes patient explainer agent


=== NODE FILES ===

FILE: nodes/data_collection_node.py
PURPOSE: Workflow node wrapper for data collection
KEY FUNCTION:
  Function: data_collection_node
  Parameters:
    - state (SymptomOneState): Input state
  Returns:
    - SymptomOneState: Updated state
  Description: LangGraph node that runs data collection agent


FILE: nodes/symptom_classifier_node.py
PURPOSE: Workflow node for symptom classification
KEY FUNCTION:
  Function: symptom_classifier_node
  Parameters:
    - state (SymptomOneState): Input state
  Returns:
    - Dict: Partial state update with classification
  Description: Runs classifier, handles errors, sets completion flag


FILE: nodes/severity_assessor_node.py
PURPOSE: Workflow node for severity assessment
KEY FUNCTION:
  Function: severity_assessor_node
  Parameters:
    - state (SymptomOneState): Input state
  Returns:
    - Dict: Partial state with severity assessment
  Description: Runs severity assessor in parallel with classifier


FILE: nodes/risk_router_node.py
PURPOSE: Risk assessment and routing decision
KEY FUNCTION:
  Function: risk_router_node
  Parameters:
    - state (SymptomOneState): Input state (requires severity complete)
  Returns:
    - Dict: risk_level, risk_score, risk_router_complete
  Description: Calculates risk score, applies threshold, sets route
  LOGIC:
    - Risk score >= 0.6 → HIGH risk (differential path)
    - Risk score < 0.6 → LOW risk (advisory path)
    - Red flags add +0.2 to risk score


FILE: nodes/differential_node.py
PURPOSE: Workflow node for differential diagnosis
KEY FUNCTION:
  Function: differential_node
  Parameters:
    - state (SymptomOneState): Input state
  Returns:
    - Dict: differential_diagnosis, diagnosis_reasoning
  Description: Only executes on HIGH risk path


FILE: nodes/treatment_planner_node.py
PURPOSE: Workflow node for treatment planning
KEY FUNCTION:
  Function: treatment_planner_node
  Parameters:
    - state (SymptomOneState): Input state
  Returns:
    - Dict: treatment_plan, plan_reasoning
  Description: Creates comprehensive treatment recommendations


FILE: nodes/med_evidence_node.py
PURPOSE: Workflow node for medication evidence
KEY FUNCTION:
  Function: med_evidence_node
  Parameters:
    - state (SymptomOneState): Input state
  Returns:
    - Dict: med_evidence, completion flag
  Description: Validates and adds evidence for medications


FILE: nodes/advice_generator_node.py
PURPOSE: Workflow node for low-risk advice
KEY FUNCTION:
  Function: advice_generator_node
  Parameters:
    - state (SymptomOneState): Input state
  Returns:
    - Dict: advice, advice_reasoning
  Description: Only executes on LOW risk path


FILE: nodes/safety_validator_node.py
PURPOSE: Safety validation of all recommendations
KEY FUNCTION:
  Function: safety_validator_node
  Parameters:
    - state (SymptomOneState): Input state
  Returns:
    - Dict: safety_passed, safety_warnings, modified_output
  Description: Validates safety of all recommendations


FILE: nodes/patient_explainer_node.py
PURPOSE: Patient-friendly explanation generation
KEY FUNCTION:
  Function: patient_explainer_node
  Parameters:
    - state (SymptomOneState): Input state
  Returns:
    - Dict: patient_friendly_summary
  Description: Creates plain-language summary


FILE: nodes/report_generator_node.py
PURPOSE: Final report generation
KEY FUNCTION:
  Function: report_generator_node
  Parameters:
    - state (SymptomOneState): Complete state
  Returns:
    - Dict: final_report
  Description: Formats complete triage report using format_output_report


FILE: nodes/evaluation_saver_node.py
PURPOSE: Saves results and evaluation metrics
KEY FUNCTION:
  Function: evaluation_saver_node
  Parameters:
    - state (SymptomOneState): Complete state
  Returns:
    - Dict: saved_path, eval_metrics, output_dir
  Description: Saves report to output directory with timestamped folder


=== WORKFLOW FILES ===

FILE: workflow/workflow.py
PURPOSE: LangGraph workflow assembly
KEY FUNCTION:
  Function: build_workflow
  Parameters: None
  Returns:
    - StateGraph: Compiled LangGraph workflow
  Description: Assembles all nodes and edges into executable graph

  Function: risk_router_decision
  Parameters:
    - state (SymptomOneState): Current state
  Returns:
    - Literal["high_risk_path", "low_risk_path"]
  Description: Conditional edge function for routing

WORKFLOW STRUCTURE:
  1. Entry Point: data_collection_node

  2. Parallel Edges:
     - data_collection → symptom_classifier_node
     - data_collection → severity_assessor_node

  3. Convergence:
     - symptom_classifier → risk_router_node
     - severity_assessor → risk_router_node

  4. Conditional Branch:
     - HIGH risk → differential_node → treatment_planner_node → med_evidence_node
     - LOW risk → advice_generator_node

  5. Convergence at safety_validator_node

  6. Sequential:
     - safety_validator → patient_explainer → report_generator → evaluation_saver

  7. End


=== MACHINE LEARNING FILES ===

FILE: ml/train_model/train_symptom_model.py
PURPOSE: Trains symptom classification model
KEY FUNCTION:
  Function: train_symptom_model
  Parameters:
    - data_path (str): Path to training data CSV
  Returns:
    - Tuple: (model, vectorizer, mlb)
  Description: Trains multi-label classifier for symptoms


FILE: ml/train_model/train_severity_model.py
PURPOSE: Trains severity assessment model
KEY FUNCTION:
  Function: train_severity_model
  Parameters:
    - data_path (str): Path to training data CSV
  Returns:
    - Tuple: (model, vectorizer)
  Description: Trains multi-class classifier for severity


FILE: ml/evaluation/evaluate_symptom_model.py
PURPOSE: Evaluates symptom model performance
KEY FUNCTION:
  Function: evaluate_symptom_model
  Parameters: None (loads from ml/model/)
  Returns:
    - Tuple: (metrics_dict, classification_report)
  Description: Computes Hamming loss and classification metrics


FILE: ml/evaluation/evaluate_severity_model.py
PURPOSE: Evaluates severity model performance
KEY FUNCTION:
  Function: evaluate_severity_model
  Parameters: None (loads from ml/model/)
  Returns:
    - Tuple: (metrics_dict, classification_report)
  Description: Computes accuracy and classification metrics


--------------------------------------------------------------------------------
RUNNING COMMANDS
--------------------------------------------------------------------------------

=== INSTALLATION ===

Command: pip install -r requirements.txt
Purpose: Installs all Python dependencies
Requirements:
  - streamlit
  - langgraph
  - langchain
  - langchain-google-genai
  - google-generativeai
  - scikit-learn
  - pandas
  - numpy
  - joblib
  - pytest
  - python-dotenv


=== CONFIGURATION ===

Step 1: Create environment file
Command: cp .env.example .env
Purpose: Copy template environment file

Step 2: Edit .env file with API keys
Required Variables:
  GEMINI_API_KEY_1=your_primary_api_key
  GEMINI_API_KEY_2=your_secondary_api_key
  GEMINI_API_KEY_3=your_tertiary_api_key
  GEMINI_API_KEY_4=your_quaternary_api_key


=== RUNNING THE APPLICATION ===

Command:python3 -m streamlit run main.py
Purpose: Launches web interface
Port: 8501 (default)
Access: http://localhost:8501

Alternative Command: python3 main.py
Purpose: Runs Streamlit application


=== TESTING ===

Command: python3 -m pytest tests.py -v
Purpose: Runs all 15 test cases with verbose output
Expected: All tests pass


=== TRAINING MODELS (Optional) ===

Command: python3 ml/train_model/train_symptom_model.py
Purpose: Trains symptom classification model
Output: Saves model files to ml/model/

Command: python3 ml/train_model/train_severity_model.py
Purpose: Trains severity assessment model
Output: Saves model files to ml/model/


=== EVALUATING MODELS ===

Command: python3 ml/evaluation/evaluate_symptom_model.py
Purpose: Evaluates symptom model performance
Output: Prints Hamming loss and classification report

Command: python3 ml/evaluation/evaluate_severity_model.py
Purpose: Evaluates severity model performance
Output: Prints accuracy and classification report


--------------------------------------------------------------------------------
SYSTEM OUTPUT
--------------------------------------------------------------------------------

=== CONSOLE OUTPUT DURING EXECUTION ===

When running the triage workflow, the console displays:

================================================================================
STARTING SYMPTOMONE TRIAGE ANALYSIS
================================================================================

[DATA COLLECTION] Normalizing input text and extracting metadata...
[DATA COLLECTION] Complete

[SYMPTOM CLASSIFIER] Analyzing symptom patterns...
[SYMPTOM CLASSIFIER] Identified 3 primary symptoms

[SEVERITY ASSESSOR] Assessing severity and urgency...
[SEVERITY ASSESSOR] Severity: High, Risk Score: 0.75

[RISK ROUTER] Determining risk level and routing path...
[RISK ROUTER] Risk Level: HIGH (score: 0.75)
[RISK ROUTER] Routing to: Differential Analysis Path

[DIFFERENTIAL DIAGNOSIS] Generating possible diagnoses...
[DIFFERENTIAL DIAGNOSIS] Generated 5 differential diagnoses

[TREATMENT PLANNER] Creating treatment plan...
[TREATMENT PLANNER] Treatment plan created with 3 immediate actions

[MEDICATION EVIDENCE] Validating medications...
[MEDICATION EVIDENCE] Validated 2 medications with safety notes

[SAFETY VALIDATOR] Performing safety checks...
[SAFETY VALIDATOR] Safety validation passed

[PATIENT EXPLAINER] Creating patient-friendly explanation...
[PATIENT EXPLAINER] Explanation generated

[REPORT GENERATOR] Generating final report...
[REPORT GENERATOR] Report saved to: output/severe_chest_pain_radiating/triage_report.txt

[EVALUATION SAVER] Saving evaluation metrics...
[EVALUATION SAVER] Metrics saved

================================================================================
TRIAGE ANALYSIS COMPLETE
================================================================================
Report saved to: output/severe_chest_pain_radiating/triage_report.txt
Risk Level: HIGH


=== STREAMLIT WEB INTERFACE OUTPUT ===

The web interface displays:

1. HEADER SECTION:
   - Application title: "SymptomOne - AI Medical Triage"
   - Medical disclaimer warning box

2. INPUT SECTION:
   - Text area for symptom description
   - "Analyze Symptoms" button
   - Example placeholder text

3. RESULTS TABS:

   Tab 1: Classification & Severity
   - Risk level pill (color-coded: red=HIGH, green=LOW)
   - Severity level pill (Critical/High/Moderate/Low)
   - Urgency pill (Emergency/Urgent/Non-urgent/Monitor)
   - Primary symptoms (tagged)
   - Secondary symptoms (tagged)
   - Body systems affected (tagged)
   - Red flags (tagged)

   Tab 2: Differential Diagnosis
   - List of 5 diagnoses with expandable details
   - Each diagnosis shows:
     - Condition name
     - Confidence level
     - Rationale
   - Clinical reasoning section

   Tab 3: Treatment Plan
   - Immediate actions (highlighted cards)
   - Recommended medications (bulleted list)
   - Lifestyle recommendations (bulleted list)
   - Follow-up care instructions (bulleted list)
   - Treatment rationale

   Tab 4: Full Report
   - Complete text report in text area
   - Download button for report file
   - Report filename: symptomone_triage_report.txt

4. FOOTER SECTION:
   - Model evaluation buttons
   - Button: "Run Symptom Model Evaluation"
   - Button: "Run Severity Model Evaluation"
   - Results display metrics and classification reports


=== GENERATED REPORT FILE OUTPUT ===

Location: output/[symptom_slug]/triage_report.txt

Sample Report Content:

================================================================================
SYMPTOMONE MEDICAL TRIAGE REPORT
================================================================================

PATIENT SYMPTOMS:
--------------------------------------------------------------------------------
I have been experiencing severe chest pain for the past 2 hours. The pain
radiates to my left arm and jaw. I feel short of breath and nauseous.

SYMPTOM CLASSIFICATION:
--------------------------------------------------------------------------------
Primary Symptoms: chest pain, radiating pain, shortness of breath
Secondary Symptoms: nausea, sweating
Body Systems Affected: cardiovascular, respiratory

SEVERITY ASSESSMENT:
--------------------------------------------------------------------------------
Severity Level: Critical
Urgency: Emergency
Red Flags: chest pain, radiating pain, dyspnea
Risk Score: 0.95

DIFFERENTIAL DIAGNOSIS:
--------------------------------------------------------------------------------
1. Acute Myocardial Infarction
   Confidence: High
   Rationale: Classic presentation of MI with chest pain radiating to arm
   and jaw, accompanied by dyspnea and nausea. Requires immediate intervention.

2. Unstable Angina
   Confidence: Moderate
   Rationale: Similar presentation to MI but may be less severe. Still requires
   urgent evaluation and treatment.

3. Aortic Dissection
   Confidence: Moderate
   Rationale: Severe chest pain with radiation can indicate dissection.
   Life-threatening condition requiring emergency care.

4. Pulmonary Embolism
   Confidence: Low-Moderate
   Rationale: Dyspnea and chest pain are consistent, though radiation to
   arm is less typical. Should be ruled out.

5. Acute Pericarditis
   Confidence: Low
   Rationale: Can present with chest pain but typically positional and
   without radiation to extremities.

Clinical Reasoning:
The constellation of symptoms - severe chest pain with radiation to left arm
and jaw, dyspnea, and associated symptoms - is highly suggestive of acute
coronary syndrome. Immediate emergency evaluation is critical.

TREATMENT PLAN:
--------------------------------------------------------------------------------
Immediate Actions:
  - Call 911 or go to emergency department immediately
  - Chew 325mg aspirin if not allergic
  - Rest in seated or semi-reclined position
  - Do not drive yourself
  - Avoid any physical exertion

Recommended Medications:
  - Aspirin 325mg (immediate)
  - Nitroglycerin (if prescribed, follow emergency protocols)
  - Oxygen therapy (administered by EMS)

Lifestyle Recommendations:
  - Complete bed rest until evaluated
  - No food or drink (in case of procedure)

Follow-up Care:
  - Emergency department evaluation within minutes
  - ECG and cardiac biomarkers
  - Cardiology consultation
  - Possible cardiac catheterization

Treatment Rationale:
Immediate emergency care is essential. Time is muscle in cardiac events.
Early aspirin and emergency transport maximize survival chances.

MEDICATION EVIDENCE & SAFETY NOTES:
--------------------------------------------------------------------------------
- Aspirin 325mg
  Indication: Acute coronary syndrome
  Warnings: Contraindicated if allergic, active bleeding, or on anticoagulants
  Monitoring: Watch for bleeding, allergic reaction

PATIENT-FRIENDLY SUMMARY:
--------------------------------------------------------------------------------
Your symptoms suggest a possible heart attack, which is a medical emergency.
The chest pain spreading to your arm and jaw, combined with shortness of
breath, are serious warning signs. You need to call 911 right now. While
waiting for the ambulance, chew an aspirin if you have one and are not
allergic. Try to stay calm and avoid moving around. Do not drive yourself
to the hospital. Time is critical in treating heart problems, so immediate
medical care is essential.

================================================================================
END OF REPORT
================================================================================


=== TEST OUTPUT ===

When running pytest, the output shows:

============================= test session starts ==============================
platform darwin -- Python 3.9.6, pytest-8.4.2, pluggy-1.6.0
cachedir: .pytest_cache
rootdir: /Users/balamurale/Downloads/LangHackthon/SymptomOne-dup
plugins: anyio-4.12.0
collecting ... collected 15 items

tests.py::TestSlugifyReturns::test_slugify_returns_lowercase_string PASSED [  6%]
tests.py::TestSlugifyReturns::test_slugify_returns_underscore_separated PASSED [ 13%]
tests.py::TestSlugifyReturns::test_slugify_returns_default_for_empty PASSED [ 20%]
tests.py::TestDataCollectionAgentReturns::test_clean_text_returns_normalized_string PASSED [ 26%]
tests.py::TestDataCollectionAgentReturns::test_extract_metadata_returns_duration_dict PASSED [ 33%]
tests.py::TestDataCollectionAgentReturns::test_extract_metadata_returns_age_mentioned PASSED [ 40%]
tests.py::TestDataCollectionAgentReturns::test_process_returns_dict_with_cleaned_and_metadata PASSED [ 46%]
tests.py::TestRiskRouterNodeReturns::test_risk_router_returns_high_risk_dict PASSED [ 53%]
tests.py::TestRiskRouterNodeReturns::test_risk_router_returns_low_risk_dict PASSED [ 60%]
tests.py::TestConditionalRouting::test_conditional_routing_selects_high_risk_path PASSED [ 66%]
tests.py::TestConditionalRouting::test_conditional_routing_selects_low_risk_path PASSED [ 73%]
tests.py::TestConditionalRouting::test_conditional_routing_boundary_case_at_threshold PASSED [ 80%]
tests.py::TestParallelExecution::test_workflow_has_parallel_edges_from_data_collection PASSED [ 86%]
tests.py::TestParallelExecution::test_parallel_nodes_can_execute_independently PASSED [ 93%]
tests.py::TestParallelExecution::test_risk_router_waits_for_both_parallel_nodes PASSED [100%]

======================== 15 passed in 0.92s ========================


=== MODEL EVALUATION OUTPUT ===

When evaluating the symptom classification model:

Evaluating symptom model...
Loaded 500 test samples
Hamming loss: 0.0234
Accuracy: 0.8756

Classification Report:
                    precision    recall  f1-score   support
chest_pain              0.92      0.89      0.91       120
fever                   0.88      0.91      0.89       145
cough                   0.85      0.83      0.84       132
headache                0.91      0.88      0.89       108
nausea                  0.87      0.85      0.86        95


When evaluating the severity assessment model:

Evaluating severity model...
Loaded 500 test samples
Accuracy: 0.8920

Classification Report:
              precision    recall  f1-score   support
Critical          0.94      0.91      0.92        65
High              0.89      0.88      0.88       135
Moderate          0.86      0.89      0.87       185
Low               0.92      0.93      0.92       115


--------------------------------------------------------------------------------
END OF PROBLEM DESCRIPTION
--------------------------------------------------------------------------------
