import os

# Compatibility shim for Python < 3.10 where importlib.metadata may lack packages_distributions
try:
    import importlib.metadata as _metadata
    if not hasattr(_metadata, "packages_distributions"):
        import importlib_metadata as _metadata_back  # type: ignore
        if hasattr(_metadata_back, "packages_distributions"):
            _metadata.packages_distributions = _metadata_back.packages_distributions  # type: ignore
except Exception:
    pass

import streamlit as st
from graph import run_triage
from ml.evaluation.evaluate_symptom_model import evaluate_symptom_model
from ml.evaluation.evaluate_severity_model import evaluate_severity_model

# === STREAMLIT UI ===
st.set_page_config(
    page_title="SymptomOne - Medical Triage AI",
    page_icon="🏥",
    layout="wide"
)

primary_color = "#1f3c88"
accent_color = "#ff7043"
success_color = "#2e7d32"
warn_color = "#f9a825"
error_color = "#d32f2f"

# Custom CSS
st.markdown(f"""
<style>
    .main-header {{
        text-align: center;
        color: {primary_color};
        padding: 20px 0 10px 0;
        font-weight: 700;
    }}
    .card {{
        background: #ffffff;
        border: 1px solid #e6e8ed;
        border-radius: 12px;
        padding: 16px 18px;
        box-shadow: 0 6px 18px rgba(17,24,39,0.06);
        margin-bottom: 16px;
    }}
    .pill {{
        display: inline-block;
        padding: 6px 12px;
        border-radius: 999px;
        font-size: 0.9em;
        font-weight: 600;
        color: #fff;
    }}
    .pill-high {{ background: {error_color}; }}
    .pill-critical {{ background: {error_color}; }}
    .pill-moderate {{ background: {warn_color}; color: #111; }}
    .pill-low {{ background: {success_color}; }}
    .pill-risk-high {{ background: {error_color}; }}
    .pill-risk-low {{ background: {success_color}; }}
    .pill-urgency {{ background: {accent_color}; }}
    .tag {{
        display: inline-block;
        background: #eef2ff;
        color: {primary_color};
        padding: 6px 10px;
        border-radius: 8px;
        margin: 4px 4px 0 0;
        font-weight: 600;
    }}
    .disclaimer {{
        background-color: #fff7e6;
        border: 1px solid #ffe0b2;
        padding: 15px;
        border-radius: 8px;
        margin: 16px 0;
    }}
</style>
""", unsafe_allow_html=True)

st.markdown('<h1 class="main-header">SymptomOne - AI Medical Triage</h1>', unsafe_allow_html=True)

# Disclaimer
st.markdown("""
<div class="disclaimer">
    <strong>⚠️ MEDICAL DISCLAIMER:</strong> This tool is for educational and informational purposes only.
    It is NOT a substitute for professional medical advice, diagnosis, or treatment. Always seek the advice
    of your physician or other qualified health provider with any questions you may have regarding a medical condition.
    In case of emergency, call 911 or your local emergency number immediately.
</div>
""", unsafe_allow_html=True)

# Description
st.markdown("""
### About SymptomOne

SymptomOne uses advanced AI to perform single-case medical triage analysis:
- **Symptom Classification**: Identifies and categorizes symptoms
- **Severity Assessment**: Evaluates urgency and identifies red flags
- **Differential Diagnosis**: Generates possible diagnoses with confidence levels
- **Treatment Plan**: Provides comprehensive care recommendations

Simply enter a paragraph describing symptoms and let the AI agents analyze the case.
""")

st.markdown("---")

# Input form
with st.form("symptom_form"):
    symptom_paragraph = st.text_area(
        "Enter Patient Symptom Description",
        height=200,
        placeholder="Example: I have been experiencing severe chest pain for the past 2 hours. The pain radiates to my left arm and jaw. I feel short of breath and nauseous. I'm also sweating profusely. The pain started suddenly while I was resting and hasn't improved.",
        help="Provide a detailed description of symptoms including duration, severity, location, and any associated symptoms"
    )

    submit = st.form_submit_button("🔍 Analyze Symptoms", use_container_width=True)

def pill(text, cls):
    return f'<span class="pill {cls}">{text}</span>'

def render_tags(items):
    if not items:
        return "—"
    return " ".join([f'<span class="tag">{t}</span>' for t in items])

if submit and symptom_paragraph.strip():
    with st.spinner("🤖 AI agents are analyzing the symptoms..."):
        try:
            result = run_triage(symptom_paragraph)

            folder_name = os.path.relpath(result.get("output_dir", "output"), start=".")
            st.success(f"✅ Analysis complete! Report saved to: `{folder_name}`")

            # Display results in tabs
            tab1, tab2, tab3, tab4 = st.tabs([
                "Classification & Severity",
                "Differential Diagnosis",
                "Treatment Plan",
                "Full Report"
            ])

            with tab1:
                classification_ok = result.get("symptom_classifier_complete")
                severity_ok = result.get("severity_assessor_complete")
                if classification_ok and severity_ok:
                    classification = result.get("symptom_classification", {})
                    severity = result.get("severity_assessment", {})
                    risk_level = result.get("risk_level", "Unknown")
                    risk_pill = pill(f"Risk: {risk_level}", f"pill-risk-{risk_level.lower()}")
                    severity_level = severity.get("severity_level", "Unknown")
                    severity_pill = pill(f"Severity: {severity_level}", f"pill-{severity_level.lower()}")
                    urgency_pill = pill(f"Urgency: {severity.get('urgency', 'Unknown')}", "pill-urgency")

                    st.markdown(f'<div class="card">{risk_pill} {severity_pill} {urgency_pill}</div>', unsafe_allow_html=True)

                    col1, col2 = st.columns(2)
                    with col1:
                        st.markdown("#### Primary Symptoms")
                        st.markdown(render_tags(classification.get("primary_symptoms", [])), unsafe_allow_html=True)
                        st.markdown("#### Secondary Symptoms")
                        st.markdown(render_tags(classification.get("secondary_symptoms", [])), unsafe_allow_html=True)
                    with col2:
                        st.markdown("#### Body Systems Affected")
                        st.markdown(render_tags(classification.get("body_systems", [])), unsafe_allow_html=True)
                        st.markdown("#### Red Flags")
                        st.markdown(render_tags(severity.get("red_flags", [])), unsafe_allow_html=True)
                else:
                    st.error(f"Classification/Severity failed: {result.get('classification_error', 'Unknown error')}")

            with tab2:
                if result.get("risk_level") == "LOW":
                    st.info("Skipped (LOW risk path).")
                elif result.get("differential_complete"):
                    st.markdown("#### Possible Diagnoses")
                    diagnoses = result.get("differential_diagnosis", [])
                    for idx, dx in enumerate(diagnoses, 1):
                        confidence = dx.get("confidence", "Unknown")
                        with st.expander(f"{idx}. {dx.get('condition', 'Unknown')}  |  Confidence: {confidence}"):
                            st.markdown(f"**Rationale:** {dx.get('rationale', 'N/A')}")
                    st.markdown("#### Clinical Reasoning")
                    st.info(result.get("diagnosis_reasoning", "No reasoning provided"))
                else:
                    st.error(f"Differential diagnosis failed: {result.get('differential_error', 'Unknown error')}")

            with tab3:
                if result.get("risk_level") == "LOW":
                    st.info("Low-risk path - showing basic advice-based plan.")
                if result.get("treatment_complete"):
                    plan = result["treatment_plan"]
                    st.markdown("#### Immediate Actions")
                    if plan.get("immediate_actions"):
                        for action in plan["immediate_actions"]:
                            st.markdown(f'<div class="card">{action}</div>', unsafe_allow_html=True)
                    col1, col2 = st.columns(2)
                    with col1:
                        if plan.get("medications"):
                            st.markdown("#### Recommended Medications")
                            for med in plan["medications"]:
                                st.markdown(f"- {med}")
                        if plan.get("lifestyle"):
                            st.markdown("#### Lifestyle Recommendations")
                            for rec in plan["lifestyle"]:
                                st.markdown(f"- {rec}")
                    with col2:
                        if plan.get("follow_up"):
                            st.markdown("#### Follow-up Care")
                            for followup in plan["follow_up"]:
                                st.markdown(f"- {followup}")
                    st.markdown("#### Treatment Rationale")
                    st.info(result.get("plan_reasoning", "No reasoning provided"))
                else:
                    st.error(f"Treatment planning failed: {result.get('treatment_error', 'Unknown error')}")

            with tab4:
                st.markdown("#### Complete Triage Report")
                report_path = os.path.join(result.get("output_dir", "output"), "triage_report.txt")
                if os.path.exists(report_path):
                    with open(report_path, "r") as f:
                        report_content = f.read()
                    st.text_area("Full Report", report_content, height=600)
                    st.download_button(
                        label="📥 Download Report",
                        data=report_content,
                        file_name="symptomone_triage_report.txt",
                        mime="text/plain"
                    )
                else:
                    st.warning("Report file not found")

        except Exception as e:
            st.error(f"An error occurred during analysis: {str(e)}")
            st.exception(e)

# Footer
st.markdown("---")
st.subheader("Model Evaluation (offline)")
col_eval1, col_eval2 = st.columns(2)

with col_eval1:
    if st.button("Run Symptom Model Evaluation"):
        with st.spinner("Evaluating symptom model..."):
            try:
                metrics, report = evaluate_symptom_model()
                st.success(f"Hamming loss: {metrics['hamming_loss']:.4f} on {metrics['num_samples']} samples")
                st.text_area("Classification report (symptom)", report, height=200)
            except FileNotFoundError as e:
                st.error(str(e))
            except Exception as e:
                st.error(f"Evaluation failed: {e}")

with col_eval2:
    if st.button("Run Severity Model Evaluation"):
        with st.spinner("Evaluating severity model..."):
            try:
                metrics, report = evaluate_severity_model()
                st.success(f"Accuracy: {metrics['accuracy']:.4f} on {metrics['num_samples']} samples")
                st.text_area("Classification report (severity)", report, height=200)
            except FileNotFoundError as e:
                st.error(str(e))
            except Exception as e:
                st.error(f"Evaluation failed: {e}")

st.markdown("""
<div style="text-align: center; color: #666; padding: 20px;">
    <p>SymptomOne - AI-Powered Medical Triage System</p>
    <p style="font-size: 0.8em;">Built with LangGraph and Google Gemini</p>
</div>
""", unsafe_allow_html=True)
