# SymptomOne AI: Medical Triage Automation

[![Python](https://img.shields.io/badge/Python-3.8+-blue.svg)](https://python.org)
[![Streamlit](https://img.shields.io/badge/Streamlit-1.0+-red.svg)](https://streamlit.io)
[![LangGraph](https://img.shields.io/badge/LangGraph-Multi--Agent-green.svg)](https://langchain.com)
[![Gemini](https://img.shields.io/badge/Google-Gemini--2.0--Flash-orange.svg)](https://ai.google.dev)

SymptomOne is an intelligent medical triage automation system that transforms patient symptom descriptions into comprehensive clinical assessments using a sophisticated multi-agent AI architecture powered by Google Gemini and LangGraph.

## 🚀 Features

### 🤖 Multi-Agent Architecture
- **Classification Agent**: Analyzes symptoms and assesses severity with red flag identification
- **Differential Diagnosis Agent**: Generates top 5 possible diagnoses with confidence levels
- **Treatment Planning Agent**: Creates comprehensive treatment plans and care recommendations

### 🏥 Clinical Capabilities
- **Symptom Classification** - Primary/secondary symptom identification
- **Body System Mapping** - Identifies affected physiological systems
- **Severity Assessment** - Critical, High, Moderate, Low classification
- **Urgency Evaluation** - Emergency, Urgent, Non-urgent, Monitor
- **Red Flag Detection** - Identifies life-threatening conditions
- **Differential Diagnosis** - AI-powered diagnostic reasoning
- **Treatment Planning** - Evidence-based care recommendations

### 🔐 Privacy & Safety
- **Educational Tool** - Not FDA-approved medical device
- **No Data Storage** - Patient information not permanently stored
- **Local Processing** - Reports saved locally only
- **Medical Disclaimer** - Clear warnings and limitations

## 📋 Table of Contents

- [Installation](#installation)
- [Quick Start](#quick-start)
- [Architecture](#architecture)
- [Usage](#usage)
- [Configuration](#configuration)
- [Output Structure](#output-structure)
- [Examples](#examples)
- [Testing](#testing)
- [Contributing](#contributing)
- [Disclaimer](#disclaimer)

## 🔧 Installation

### Prerequisites
- Python 3.8 or higher
- Google Gemini API key ([Get one here](https://ai.google.dev))

### Setup

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd SymptomOne
   ```

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Configure environment variables**
   ```bash
   cp .env.example .env
   # Edit .env and add your Gemini API keys
   ```

4. **Run the application**
   ```bash
   streamlit run main.py
   ```

## ⚡ Quick Start

1. **Launch the application**
   ```bash
   streamlit run main.py
   ```

2. **Enter patient symptoms**
   ```
   I have been experiencing severe chest pain for the past 2 hours. The pain
   radiates to my left arm and jaw. I feel short of breath and nauseous.
   ```

3. **Analyze symptoms**
   - Click "Analyze Symptoms" and watch the magic happen!

4. **Review results**
   - Classification & Severity Assessment
   - Differential Diagnoses (Top 5)
   - Comprehensive Treatment Plan
   - Complete Triage Report

## 🏛️ Architecture

### Multi-Agent Workflow

```mermaid
graph TD
    A[Symptom Paragraph Input] --> B[Classification Agent]
    B --> C[Differential Diagnosis Agent]
    C --> D[Treatment Planning Agent]
    D --> E[Complete Triage Report]

    B --> F[Severity Assessment]
    B --> G[Symptom Classification]
    C --> H[Top 5 Diagnoses]
    D --> I[Treatment Plan]
```

### State Management

The system uses a centralized state management approach with `SymptomOneState`:

```python
class SymptomOneState(TypedDict):
    # Input
    symptom_paragraph: str

    # Classification Results
    symptom_classification: Dict[str, any]
    severity_assessment: Dict[str, any]

    # Differential Diagnosis
    differential_diagnosis: List[Dict[str, str]]
    diagnosis_reasoning: str

    # Treatment Plan
    treatment_plan: Dict[str, any]
    plan_reasoning: str

    # Advisory (LOW) / Med evidence (HIGH)
    advice: str
    med_evidence: Dict[str, any]
    patient_friendly_summary: str

    # Status Tracking
    symptom_classifier_complete: bool
    severity_assessor_complete: bool
    differential_complete: bool
    treatment_complete: bool
    med_evidence_complete: bool
    advice_generator_complete: bool
    patient_explainer_complete: bool
```

## 📖 Usage

### Web Interface

1. **Access the Streamlit interface** at `http://localhost:8501`
2. **Enter patient symptom description** in the text area
3. **Click "Analyze Symptoms"** to start the triage process
4. **Review the results** including:
   - Symptom classification and severity
   - Top 5 differential diagnoses
   - Comprehensive treatment plan
   - Complete triage report

### Programmatic Usage

```python
from graph import run_triage

# Generate triage analysis programmatically
result = run_triage(
    symptom_paragraph="Patient experiencing severe headache with vision changes"
)

# Access results
classification = result["symptom_classification"]
severity = result["severity_assessment"]
diagnoses = result["differential_diagnosis"]
treatment = result["treatment_plan"]
```

## ⚙️ Configuration

### Environment Variables

Create a `.env` file with your Gemini API keys:

```env
GEMINI_API_KEY_1=your_primary_api_key
GEMINI_API_KEY_2=your_secondary_api_key
GEMINI_API_KEY_3=your_tertiary_api_key
GEMINI_API_KEY_4=your_quaternary_api_key
```

> **⚠️ Security Note**: Never commit your `.env` file to version control. Add it to `.gitignore`.

### Agent Configuration

Each agent can be configured with different Gemini models and parameters:

```python
model = ChatGoogleGenerativeAI(
    model="gemini-2.0-flash-exp",
    google_api_key=os.getenv("GEMINI_API_KEY_1"),
    temperature=0.2  # Lower temperature for more consistent analysis
)
```

## 📁 Project Structure

```
SymptomOne/
├── agents/                    # Agents (utility, ML, LLM)
│   ├── data_collection.py
│   ├── symptom_classification_ml.py
│   ├── severity_assessment_ml.py
│   ├── differential_llm.py
│   ├── treatment_llm.py
│   ├── advisory_llm.py
│   ├── med_evidence_llm.py
│   └── patient_explainer_llm.py
├── nodes/                     # LangGraph node implementations
│   ├── data_collection_node.py
│   ├── symptom_classifier_node.py
│   ├── severity_assessor_node.py
│   ├── differential_node.py
│   ├── treatment_planner_node.py
│   ├── med_evidence_node.py
│   ├── advice_generator_node.py
│   ├── patient_explainer_node.py
│   ├── risk_router_node.py
│   ├── safety_validator_node.py
│   ├── report_generator_node.py
│   └── evaluation_saver_node.py
├── workflow/                  # Workflow exports
│   └── workflow.py
├── data/                      # Training/eval datasets
├── ml/                        # Cleaning, train_model, model, evaluation
├── processed/                 # Cleaned datasets
├── main.py                    # Streamlit application
├── graph.py                   # LangGraph workflow
├── state.py                   # State schema (TypedDict)
├── tests.py                   # Integration tests
├── requirements.txt           # Python dependencies
└── .env                       # Environment variables (API keys)
```

## 📁 Output Structure

Generated reports follow this structure:

```
output/
└── [symptom_description_slug]/
    └── triage_report.txt
```

## 💡 Examples

### Emergency Cardiac Event

**Input:**
```
I have severe crushing chest pain that started 30 minutes ago. The pain radiates
to my left arm and jaw. I'm sweating heavily, feel nauseous, and short of breath.
```

**Output:**
- **Severity**: Critical
- **Urgency**: Emergency - Call 911 immediately
- **Top Diagnosis**: Acute Myocardial Infarction (High confidence)
- **Immediate Actions**: Call 911, chew aspirin, rest in seated position

### Respiratory Infection

**Input:**
```
For the past 3 days, I've had a fever of 101°F, persistent cough with yellow mucus,
fatigue, and body aches. The cough is worse at night.
```

**Output:**
- **Severity**: Moderate
- **Urgency**: Urgent - See doctor within 24 hours
- **Top Diagnoses**: Bacterial pneumonia, Acute bronchitis, Influenza
- **Treatment Plan**: Consider antibiotics, rest, hydration, fever management

### Gastrointestinal Issues

**Input:**
```
I've been experiencing intermittent abdominal cramping for 2 weeks, along with
bloating and diarrhea. Symptoms worse after eating dairy products.
```

**Output:**
- **Severity**: Low
- **Urgency**: Non-urgent - Schedule appointment
- **Top Diagnoses**: Lactose intolerance, IBS, Food sensitivity
- **Treatment Plan**: Dietary modifications, elimination diet, food diary

## 🔍 Agent Details

### Classification Agent
- **Purpose**: Analyzes symptoms and assesses severity
- **Input**: Patient symptom description
- **Output**: Classification, severity level, urgency, red flags
- **Model**: Gemini-2.0-Flash-Exp with temperature 0.2

### Differential Diagnosis Agent
- **Purpose**: Generates possible diagnoses
- **Input**: Classification results and symptoms
- **Output**: Top 5 diagnoses with confidence levels and reasoning
- **Model**: Gemini-2.0-Flash-Exp with temperature 0.3

### Treatment Planning Agent
- **Purpose**: Creates comprehensive treatment plans
- **Input**: Symptoms, severity, and diagnoses
- **Output**: Immediate actions, medications, lifestyle changes, follow-up
- **Model**: Gemini-2.0-Flash-Exp with temperature 0.2

## 🧪 Testing

### Running Tests

The project includes 10 integration tests (2 with real Gemini API, 8 mocked):

```bash
pytest tests.py -v
```

**Test Coverage:**
- Test 1: Classification Agent (Real API call)
- Test 2: Full Workflow (Real API call)
- Test 3-10: State Management, Error Handling, Report Generation, Various Scenarios (Mocked)

All tests designed to save API quota while ensuring functionality.

## 🚀 Advanced Features

### Multiple Severity Levels

The system evaluates 4 severity levels:
- **Critical**: Life-threatening, requires immediate emergency care
- **High**: Serious condition, needs urgent medical attention
- **Moderate**: Concerning symptoms, schedule doctor visit soon
- **Low**: Minor symptoms, monitor and home care

### Urgency Classification

4 urgency levels guide patient actions:
- **Emergency**: Call 911 or go to ER immediately
- **Urgent**: See doctor within 24 hours
- **Non-urgent**: Schedule appointment within days
- **Monitor**: Track symptoms and seek care if worsening

### Red Flag Detection

AI automatically identifies life-threatening conditions:
- Chest pain with radiation
- Severe dyspnea
- Altered mental status
- Severe bleeding
- Signs of stroke

## 🤝 Contributing

We welcome contributions! Please see our [Contributing Guidelines](CONTRIBUTING.md) for details.

### Development Setup

1. Fork the repository
2. Create a feature branch
3. Install development dependencies
4. Make your changes
5. Run tests
6. Submit a pull request

## ⚠️ Disclaimer

**MEDICAL DISCLAIMER**

This tool is for **educational and informational purposes only**. It is NOT a substitute for professional medical advice, diagnosis, or treatment.

**Important:**
- Always seek the advice of your physician or other qualified health provider
- Never disregard professional medical advice or delay seeking it
- In case of emergency, call 911 or your local emergency number immediately
- This system is not FDA-approved and should not be used for actual clinical decisions

## 📝 License

This project is provided for educational purposes. See LICENSE file for details.

## 🙏 Acknowledgments

- Built on LangGraph multi-agent architecture
- Powered by Google Gemini 2.0 Flash
- Inspired by clinical decision support systems
- Medical guidelines from standard clinical protocols

## 📧 Contact

For questions, issues, or contributions, please open an issue on the project repository.

---

**Remember**: This is an educational tool. Always consult healthcare professionals for medical advice.

---

Built with ❤️ using LangGraph and Google Gemini
