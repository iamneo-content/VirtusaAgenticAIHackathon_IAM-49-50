from typing import Dict
from state import SymptomOneState
from workflow.workflow import build_workflow


def run_triage(symptom_paragraph: str) -> Dict:
    initial_state = SymptomOneState(
        symptom_paragraph=symptom_paragraph,
        loaded_text="",
        cleaned_text="",
        metadata={},
        data_collection_complete=False,
        symptom_classification={},
        symptom_classifier_complete=False,
        severity_assessment={},
        severity_assessor_complete=False,
        risk_level="LOW",
        risk_score=0.0,
        risk_router_complete=False,
        differential_diagnosis=[],
        diagnosis_reasoning="",
        differential_complete=False,
        treatment_plan={},
        plan_reasoning="",
        treatment_complete=False,
        med_evidence={},
        med_evidence_complete=False,
        advice="",
        advice_reasoning="",
        advice_generator_complete=False,
        patient_friendly_summary="",
        patient_explainer_complete=False,
        safety_passed=False,
        safety_warnings=[],
        safety_modified_output={},
        safety_validator_complete=False,
        final_report="",
        report_generator_complete=False,
        eval_metrics={},
        saved_path="",
        evaluation_saver_complete=False,
        output_base="output",
        output_dir="",
        classification_error="",
        differential_error="",
        treatment_error="",
        error_occurred=False,
    )

    app = build_workflow().compile()

    print("\n" + "=" * 80)
    print("STARTING SYMPTOMONE TRIAGE ANALYSIS")
    print("=" * 80 + "\n")

    result = app.invoke(initial_state)

    print("\n" + "=" * 80)
    print("TRIAGE ANALYSIS COMPLETE")
    print("=" * 80)
    print(f"Report saved to: {result.get('saved_path', 'Unknown')}")
    print(f"Risk Level: {result.get('risk_level', 'Unknown')}")

    return result
