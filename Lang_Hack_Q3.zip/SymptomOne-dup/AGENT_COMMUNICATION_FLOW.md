SYMPTOMONE AI - AGENT TO AGENT COMMUNICATION FLOW
================================================================================

HOW TO VIEW THE DIAGRAM
--------------------------------------------------------------------------------

Option 1: Mermaid Live Editor
  1. Open https://mermaid.live/
  2. Copy content from agent_flow.mmd file
  3. Paste into the editor
  4. Diagram renders automatically

Option 2: GitHub Markdown
  - GitHub automatically renders Mermaid diagrams in .md files
  - View this file on GitHub to see the diagram

Option 3: VS Code
  - Install "Markdown Preview Mermaid Support" extension
  - Open this file and use Markdown preview

Option 4: Documentation Tools
  - Most modern documentation tools support Mermaid
  - Examples: GitBook, Docusaurus, MkDocs Material


MERMAID DIAGRAM
--------------------------------------------------------------------------------

```mermaid
graph TD
    Start([Patient Input]) --> DCA[Data Collection Agent]

    DCA -->|Text Cleaned & Metadata Extracted| ParallelSplit{Parallel Execution}

    ParallelSplit -->|Branch A| SCA[Symptom Classification Agent ML]
    ParallelSplit -->|Branch B| SAA[Severity Assessment Agent ML]

    SCA -->|Primary Symptoms Identified| RiskMerge{Risk Router Wait}
    SAA -->|Severity Level & Risk Score Computed| RiskMerge

    RiskMerge --> RRN[Risk Router Node]

    RRN -->|Risk Score >= 0.6| HighRiskPath{HIGH RISK PATH}
    RRN -->|Risk Score < 0.6| LowRiskPath{LOW RISK PATH}

    HighRiskPath --> DDA[Differential Diagnosis Agent LLM]
    DDA -->|Top 5 Diagnoses Generated| TPA[Treatment Planning Agent LLM]
    TPA -->|Treatment Plan Created| MEA[Medication Evidence Agent LLM]
    MEA -->|Medications Validated| SafetyMerge{Convergence Point}

    LowRiskPath --> ADA[Advisory Agent LLM]
    ADA -->|General Advice Generated| SafetyMerge

    SafetyMerge --> SVN[Safety Validator Node]
    SVN -->|Safety Check Failed| AutoReject[Auto-Reject & Log Error]
    SVN -->|Safety Check Passed| PEA[Patient Explainer Agent LLM]

    AutoReject --> ErrorEnd([Flow Complete with Errors])

    PEA -->|Plain Language Summary Created| RGN[Report Generator Node]
    RGN -->|Report Formatted| ESN[Evaluation Saver Node]
    ESN -->|Report Saved to Output Directory| End([Flow Complete])

    style DCA fill:#e1f5ff,stroke:#01579b,stroke-width:2px
    style SCA fill:#f3e5f5,stroke:#4a148c,stroke-width:2px
    style SAA fill:#f3e5f5,stroke:#4a148c,stroke-width:2px
    style RRN fill:#fff3e0,stroke:#e65100,stroke-width:3px
    style DDA fill:#e8f5e9,stroke:#1b5e20,stroke-width:2px
    style TPA fill:#e8f5e9,stroke:#1b5e20,stroke-width:2px
    style MEA fill:#e8f5e9,stroke:#1b5e20,stroke-width:2px
    style ADA fill:#fff9c4,stroke:#f57f17,stroke-width:2px
    style SVN fill:#ffebee,stroke:#c62828,stroke-width:2px
    style PEA fill:#e1bee7,stroke:#6a1b9a,stroke-width:2px
    style RGN fill:#e0f2f1,stroke:#004d40,stroke-width:2px
    style ESN fill:#e0f2f1,stroke:#004d40,stroke-width:2px
    style Start fill:#fce4ec,stroke:#880e4f,stroke-width:3px
    style End fill:#c8e6c9,stroke:#2e7d32,stroke-width:3px
    style ErrorEnd fill:#ffcdd2,stroke:#b71c1c,stroke-width:3px
    style ParallelSplit fill:#bbdefb,stroke:#0d47a1,stroke-width:2px,stroke-dasharray: 5 5
    style RiskMerge fill:#bbdefb,stroke:#0d47a1,stroke-width:2px,stroke-dasharray: 5 5
    style HighRiskPath fill:#ffccbc,stroke:#d84315,stroke-width:2px,stroke-dasharray: 5 5
    style LowRiskPath fill:#fff9c4,stroke:#f9a825,stroke-width:2px,stroke-dasharray: 5 5
    style SafetyMerge fill:#bbdefb,stroke:#0d47a1,stroke-width:2px,stroke-dasharray: 5 5
    style AutoReject fill:#ffcdd2,stroke:#c62828,stroke-width:2px
```


AGENT LEGEND
--------------------------------------------------------------------------------

BLUE - Data Processing Agents
  - Data Collection Agent: Text normalization and metadata extraction

PURPLE - ML Classification Agents
  - Symptom Classification Agent: ML-based symptom identification
  - Severity Assessment Agent: ML-based severity prediction

ORANGE - Risk Assessment
  - Risk Router Node: Decision point for routing (HIGH vs LOW risk)

GREEN - High-Risk Medical Analysis (LLM)
  - Differential Diagnosis Agent: Generates possible diagnoses
  - Treatment Planning Agent: Creates treatment plans
  - Medication Evidence Agent: Validates medications

YELLOW - Low-Risk Advisory (LLM)
  - Advisory Agent: General health advice for minor cases

RED - Safety & Validation
  - Safety Validator Node: Validates all recommendations

PURPLE - Patient Communication (LLM)
  - Patient Explainer Agent: Translates to plain language

TEAL - Output & Persistence
  - Report Generator Node: Formats final report
  - Evaluation Saver Node: Saves to file system


WORKFLOW STAGES
--------------------------------------------------------------------------------

STAGE 1: DATA INGESTION
  Agent: Data Collection Agent
  Input: Raw symptom text
  Output: Cleaned text + metadata
  Duration: ~50ms

STAGE 2: PARALLEL CLASSIFICATION (Concurrent Execution)
  Agent A: Symptom Classification Agent
    Input: Cleaned text
    Output: Primary/secondary symptoms, body systems
    Duration: ~100-200ms

  Agent B: Severity Assessment Agent
    Input: Cleaned text
    Output: Severity level, urgency, risk score
    Duration: ~100-200ms

  Note: Both execute simultaneously, reducing total latency

STAGE 3: RISK ROUTING
  Node: Risk Router Node
  Input: Results from both classification agents
  Decision: Route to HIGH or LOW risk path
  Threshold: risk_score >= 0.6 = HIGH
  Duration: ~10ms

STAGE 4A: HIGH RISK PATH (Sequential Chain)
  Agent 1: Differential Diagnosis Agent
    Duration: ~2-5 seconds (LLM call)

  Agent 2: Treatment Planning Agent
    Duration: ~2-5 seconds (LLM call)

  Agent 3: Medication Evidence Agent
    Duration: ~2-5 seconds (LLM call)

  Total HIGH path duration: ~6-15 seconds

STAGE 4B: LOW RISK PATH
  Agent: Advisory Agent
    Duration: ~2-5 seconds (LLM call)

  Total LOW path duration: ~2-5 seconds

STAGE 5: SAFETY VALIDATION
  Node: Safety Validator Node
  Input: All recommendations
  Output: Safety pass/fail + warnings
  Duration: ~50ms

STAGE 6: PATIENT COMMUNICATION
  Agent: Patient Explainer Agent
  Input: Complete analysis
  Output: Plain language summary
  Duration: ~2-5 seconds (LLM call)

STAGE 7: REPORT GENERATION
  Node: Report Generator Node
  Input: All workflow data
  Output: Formatted text report
  Duration: ~100ms

STAGE 8: PERSISTENCE
  Node: Evaluation Saver Node
  Input: Report + metrics
  Output: Saved file
  Duration: ~50ms


TOTAL WORKFLOW TIME
--------------------------------------------------------------------------------

Low Risk Path:
  Data Collection: 50ms
  Parallel Classification: 200ms (concurrent)
  Risk Router: 10ms
  Advisory: 3s
  Safety Validator: 50ms
  Patient Explainer: 3s
  Report Generator: 100ms
  Evaluation Saver: 50ms
  -------------------
  Total: ~6-7 seconds

High Risk Path:
  Data Collection: 50ms
  Parallel Classification: 200ms (concurrent)
  Risk Router: 10ms
  Differential: 4s
  Treatment: 4s
  Med Evidence: 4s
  Safety Validator: 50ms
  Patient Explainer: 3s
  Report Generator: 100ms
  Evaluation Saver: 50ms
  -------------------
  Total: ~15-20 seconds


KEY DECISION POINTS
--------------------------------------------------------------------------------

Decision 1: Parallel Split
  Location: After Data Collection
  Type: Unconditional parallel execution
  Branches: 2 (Symptom + Severity)
  Synchronization: Both must complete before Risk Router

Decision 2: Risk Routing (Node)
  Location: After parallel branches merge
  Type: Conditional branch based on risk score
  Condition: risk_score >= 0.6
  Outcomes:
    - TRUE → HIGH risk path (3 LLM agents)
    - FALSE → LOW risk path (1 LLM agent)
  Impact: 60% faster execution for low-risk cases

Decision 3: Safety Gate (Node)
  Location: After HIGH/LOW path convergence
  Type: Validation gate with rejection path
  Condition: Safety checks pass
  Outcomes:
    - PASS → Continue to patient explainer
    - FAIL → Auto-reject and error logging
  Impact: Prevents unsafe recommendations


COMMUNICATION PATTERNS
--------------------------------------------------------------------------------

Pattern 1: Sequential Communication
  Example: DDA → TPA → MEA (HIGH risk path)
  Characteristic: Output of one agent is input to next
  Use case: When agents build on previous results

Pattern 2: Parallel Communication
  Example: SCA || SAA (Classification stage)
  Characteristic: Agents run simultaneously with same input
  Use case: Independent analyses that can run concurrently

Pattern 3: Conditional Communication
  Example: RRN → (DDA or ADA)
  Characteristic: Routing based on criteria
  Use case: Different processing paths based on severity

Pattern 4: Merge Communication
  Example: (DDA + MEA) or ADA → SVN
  Characteristic: Multiple paths converge to single node
  Use case: Centralized validation point


AGENT DEPENDENCIES
--------------------------------------------------------------------------------

Data Collection Agent
  Dependencies: None
  Dependents: SCA, SAA

Symptom Classification Agent
  Dependencies: DCA
  Dependents: RRN, DDA (if HIGH risk)

Severity Assessment Agent
  Dependencies: DCA
  Dependents: RRN

Risk Router Node
  Dependencies: SCA, SAA (both must complete)
  Dependents: DDA (if HIGH) or ADA (if LOW)

Differential Diagnosis Agent
  Dependencies: RRN (HIGH path only)
  Dependents: TPA

Treatment Planning Agent
  Dependencies: DDA
  Dependents: MEA

Medication Evidence Agent
  Dependencies: TPA
  Dependents: SVN

Advisory Agent
  Dependencies: RRN (LOW path only)
  Dependents: SVN

Safety Validator Node
  Dependencies: MEA (HIGH) or ADA (LOW)
  Dependents: PEA or AutoReject

Patient Explainer Agent
  Dependencies: SVN (must pass)
  Dependents: RGN

Report Generator Node
  Dependencies: PEA
  Dependents: ESN

Evaluation Saver Node
  Dependencies: RGN
  Dependents: None (terminal)


ERROR PROPAGATION
--------------------------------------------------------------------------------

Fail-Fast Errors (Workflow Stops):
  - Severity Assessment Agent failure
    Reason: Risk Router Node requires severity to route
    Effect: ValueError raised, workflow terminates

  - Safety Validator Node failure
    Reason: Cannot proceed with unsafe recommendations
    Effect: Routes to error path, generates error report

Fail-Soft Errors (Workflow Continues):
  - Data Collection Agent partial failure
    Reason: Can use raw text as fallback
    Effect: Missing metadata, but workflow continues

  - Classification Agent failure
    Reason: Captured in error tracking
    Effect: Error logged in final report

  - LLM Agent failures
    Reason: Caught by try/except blocks
    Effect: Error stored in state, included in report


PERFORMANCE OPTIMIZATIONS
--------------------------------------------------------------------------------

1. Parallel Execution
   Optimization: SCA and SAA run concurrently
   Benefit: 40-50% latency reduction
   Trade-off: Higher resource usage during classification

2. Conditional Routing
   Optimization: LOW risk skips expensive LLM chain
   Benefit: 60% faster for minor cases (3 fewer LLM calls)
   Trade-off: Less detailed analysis for low severity

3. API Key Rotation
   Optimization: Multiple Gemini API keys rotate
   Benefit: Higher rate limits, better availability
   Trade-off: More complex configuration

4. Model Caching
   Optimization: ML models loaded once at startup
   Benefit: No repeated model loading overhead
   Trade-off: Higher memory footprint


STATE SHARING
--------------------------------------------------------------------------------

All agents share a single SymptomOneState TypedDict containing:

Shared Input Data:
  - symptom_paragraph (original input)
  - cleaned_text (normalized)
  - metadata (extracted info)

Agent Outputs:
  - symptom_classification (from SCA)
  - severity_assessment (from SAA)
  - risk_level, risk_score (from RRA)
  - differential_diagnosis (from DDA)
  - treatment_plan (from TPA)
  - med_evidence (from MEA)
  - advice (from ADA)
  - patient_friendly_summary (from PEA)
  - final_report (from RGA)

Completion Flags:
  - symptom_classifier_complete
  - severity_assessor_complete
  - risk_router_complete
  - differential_complete
  - treatment_complete
  - med_evidence_complete
  - advice_generator_complete
  - patient_explainer_complete
  - report_generator_complete
  - evaluation_saver_complete

Error Tracking:
  - classification_error
  - differential_error
  - treatment_error
  - error_occurred

Output Info:
  - output_dir
  - saved_path


================================================================================
END OF AGENT COMMUNICATION FLOW DOCUMENT
================================================================================
