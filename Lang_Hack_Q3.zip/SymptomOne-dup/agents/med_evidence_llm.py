"""
Medication Evidence Agent
Uses Gemini-2.0-Flash to add safety notes to medication recommendations.
"""

import os
import json
from typing import Dict, Any, List
from dotenv import load_dotenv
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.messages import HumanMessage
from state import SymptomOneState

load_dotenv()


class MedicationEvidenceAgent:
    """Adds safety context to medication recommendations."""

    def __init__(self):
        self.model = ChatGoogleGenerativeAI(
            model="gemini-2.0-flash",
            google_api_key=os.getenv("GEMINI_API_KEY_4"),
            temperature=0.2,
        )

    def validate(self, state: SymptomOneState) -> Dict[str, Any]:
        plan = state.get("treatment_plan", {})
        meds_raw: List[str] = plan.get("medications", [])
        severity = state.get("severity_assessment", {})
        diagnoses = state.get("differential_diagnosis", [])

        prompt = f"""You are a clinical pharmacist. Add safety context to the medication list.

SEVERITY: {severity.get('severity_level', 'Unknown')} | Red flags: {', '.join(severity.get('red_flags', ['None']))}
DIAGNOSES: {diagnoses}
MEDICATIONS: {meds_raw}

Return JSON:
{{
  "validated_medications": [
    {{"name": "med", "indication": "why", "warnings": "key warnings", "monitoring": "what to monitor"}}
  ],
  "disclaimer": "educational disclaimer"
}}
"""
        response = self.model.invoke([HumanMessage(content=prompt)])
        content = response.content.strip()
        if content.startswith("```"):
            content = content.strip("`").replace("json", "", 1).strip()
        return json.loads(content)


def run_med_evidence(state: SymptomOneState) -> SymptomOneState:
    agent = MedicationEvidenceAgent()
    result = agent.validate(state)
    state["med_evidence"] = result
    state["med_evidence_complete"] = True
    return state
