"""
Treatment Planning Agent
Uses Gemini-2.0-Flash to produce structured treatment guidance.
"""

import os
import json
from typing import Dict, Any
from dotenv import load_dotenv
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.messages import HumanMessage
from state import SymptomOneState

load_dotenv()


class TreatmentPlanningAgent:
    """Creates immediate actions, meds, lifestyle, and follow-up steps."""

    def __init__(self):
        self.model = ChatGoogleGenerativeAI(
            model="gemini-2.0-flash",
            google_api_key=os.getenv("GEMINI_API_KEY_2"),
            temperature=0.2,
        )

    def create_plan(self, state: SymptomOneState) -> Dict[str, Any]:
        severity = state.get("severity_assessment", {})
        diagnoses = state.get("differential_diagnosis", [])
        symptom_text = state.get("cleaned_text", state.get("symptom_paragraph", ""))

        diagnoses_str = "\n".join(
            f"- {dx.get('condition', 'Condition')} ({dx.get('confidence', 'Unknown')})"
            for dx in diagnoses[:5]
        )

        prompt = f"""You are an expert clinician. Create a treatment plan for educational purposes.

SYMPTOMS:
{symptom_text}

SEVERITY:
- Level: {severity.get('severity_level', 'Unknown')}
- Urgency: {severity.get('urgency', 'Unknown')}
- Red flags: {', '.join(severity.get('red_flags', ['None']))}

DIFFERENTIAL:
{diagnoses_str or 'None provided'}

Return JSON:
{{
  "treatment_plan": {{
    "immediate_actions": ["action1", "action2"],
    "medications": ["med1 - note", "med2 - note"],
    "lifestyle": ["recommendation1"],
    "follow_up": ["follow up guidance"]
  }},
  "plan_reasoning": "brief rationale"
}}

Include explicit emergency actions if severity is Critical/High. Keep it concise and educational."""

        response = self.model.invoke([HumanMessage(content=prompt)])
        content = response.content.strip()
        if content.startswith("```"):
            content = content.strip("`").replace("json", "", 1).strip()
        parsed = json.loads(content)
        return parsed


def run_treatment_planning(state: SymptomOneState) -> SymptomOneState:
    agent = TreatmentPlanningAgent()
    result = agent.create_plan(state)
    state["treatment_plan"] = result.get("treatment_plan", {})
    state["plan_reasoning"] = result.get("plan_reasoning", "")
    state["treatment_complete"] = True
    state["treatment_error"] = ""
    return state
