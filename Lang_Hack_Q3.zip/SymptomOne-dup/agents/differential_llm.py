"""
Differential Diagnosis Agent
Uses Gemini-2.0-Flash to produce a ranked differential with reasoning.
"""

import os
import json
from typing import Dict, Any
from dotenv import load_dotenv
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.messages import HumanMessage
from state import SymptomOneState

load_dotenv()


class DifferentialDiagnosisAgent:
    """Generates top diagnoses and clinical reasoning."""

    def __init__(self):
        self.model = ChatGoogleGenerativeAI(
            model="gemini-2.0-flash",
            google_api_key=os.getenv("GEMINI_API_KEY_1"),
            temperature=0.2,
        )

    def generate(self, state: SymptomOneState) -> Dict[str, Any]:
        classification = state.get("symptom_classification", {})
        severity = state.get("severity_assessment", {})
        symptom_text = state.get("cleaned_text", state.get("symptom_paragraph", ""))

        prompt = f"""You are an expert clinician. Create a differential diagnosis for this case.

PATIENT SYMPTOMS:
{symptom_text}

CLASSIFICATION:
- Primary: {', '.join(classification.get('primary_symptoms', []))}
- Secondary: {', '.join(classification.get('secondary_symptoms', []))}
- Systems: {', '.join(classification.get('body_systems', []))}

SEVERITY:
- Level: {severity.get('severity_level', 'Unknown')}
- Urgency: {severity.get('urgency', 'Unknown')}
- Red flags: {', '.join(severity.get('red_flags', ['None']))}

Return JSON:
{{
  "differential_diagnosis": [
    {{"condition": "Condition 1", "confidence": "High|Moderate|Low", "rationale": "why"}}
  ],
  "diagnosis_reasoning": "overall reasoning"
}}
"""
        message = HumanMessage(content=prompt)
        response = self.model.invoke([message])
        content = response.content.strip()
        if content.startswith("```"):
            content = content.strip("`")
            content = content.replace("json", "", 1).strip()
        parsed = json.loads(content)
        return parsed


def run_differential(state: SymptomOneState) -> SymptomOneState:
    agent = DifferentialDiagnosisAgent()
    result = agent.generate(state)
    state["differential_diagnosis"] = result.get("differential_diagnosis", [])
    state["diagnosis_reasoning"] = result.get("diagnosis_reasoning", "")
    state["differential_complete"] = True
    state["differential_error"] = ""
    return state
