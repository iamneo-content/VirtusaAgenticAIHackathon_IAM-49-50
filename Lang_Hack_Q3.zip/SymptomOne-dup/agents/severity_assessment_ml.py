"""
Severity Assessment Agent (ML-backed)
Uses a trained model/vectorizer from ml/model/.
Falls back to heuristic if artifacts are missing.
"""

import os
import joblib
from typing import Dict, Any, Optional
from state import SymptomOneState

MODEL_PATHS = ["ml/model/severity_model.pkl", "ml/model/severity_model.joblib"]
VECT_PATHS = ["ml/model/severity_vectorizer.pkl", "ml/model/severity_vectorizer.joblib"]


class SeverityAssessmentAgent:
    """Assigns severity level, urgency, red flags, and a risk score."""

    def __init__(self):
        self.model = self._load_first(MODEL_PATHS)
        self.vectorizer = self._load_first(VECT_PATHS)

    def _load_first(self, paths):
        for p in paths:
            if os.path.exists(p):
                return joblib.load(p)
        return None

    def assess(self, cleaned_text: str, classification: Dict[str, Any]) -> Dict[str, Any]:
        if not (self.model and self.vectorizer):
            raise FileNotFoundError(
                "Severity model artifacts missing. Expected model/vectorizer under ml/model/."
            )
        X = self.vectorizer.transform([cleaned_text])
        severity_raw = str(self.model.predict(X)[0]).strip().lower()

        # Normalize to canonical labels
        if severity_raw in {"critical"}:
            severity_level = "Critical"
        elif severity_raw in {"high"}:
            severity_level = "High"
        elif severity_raw in {"moderate", "mod"}:
            severity_level = "Moderate"
        elif severity_raw in {"low"}:
            severity_level = "Low"
        else:
            severity_level = "Unknown"

        # Map severity to urgency and risk score
        if severity_level == "Critical":
            urgency = "Emergency"
            risk_score = 0.9
        elif severity_level == "High":
            urgency = "Urgent"
            risk_score = 0.7
        elif severity_level == "Moderate":
            urgency = "Non-urgent"
            risk_score = 0.5
        else:
            urgency = "Monitor"
            risk_score = 0.3

        red_flags = ["None"]
        return {
            "severity_level": severity_level,
            "urgency": urgency,
            "red_flags": red_flags,
            "risk_score": risk_score,
        }


def run_severity_assessment(state: SymptomOneState) -> SymptomOneState:
    try:
        agent = SeverityAssessmentAgent()
        severity = agent.assess(
            state.get("cleaned_text", state.get("symptom_paragraph", "")),
            state.get("symptom_classification", {}),
        )
        state["severity_assessment"] = severity
        state["severity_assessor_complete"] = True
        state["risk_score"] = severity.get("risk_score", 0.0)
        state["risk_level"] = "HIGH" if state["risk_score"] >= 0.6 else "LOW"
    except Exception as e:
        state["severity_assessor_complete"] = False
        state["classification_error"] = str(e)
        state["severity_assessment"] = {}
    return state
