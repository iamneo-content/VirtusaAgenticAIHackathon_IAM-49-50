"""
Data Collection Agent
Utility agent that loads and normalizes the incoming symptom paragraph and extracts basic metadata.
"""

import re
from typing import Dict, Any
from state import SymptomOneState


class DataCollectionAgent:
    """Lightweight text normalizer and metadata extractor."""

    def process(self, symptom_text: str) -> Dict[str, Any]:
        cleaned = self._clean_text(symptom_text)
        metadata = self._extract_metadata(symptom_text)
        return {"cleaned_text": cleaned, "metadata": metadata}

    def _clean_text(self, text: str) -> str:
        text = text.strip()
        text = re.sub(r"\s+", " ", text)
        text = re.sub(r"([.!?])\s*", r"\1 ", text)
        return text

    def _extract_metadata(self, text: str) -> Dict[str, Any]:
        metadata: Dict[str, Any] = {}
        lower = text.lower()

        # Simple duration heuristic
        duration_match = re.search(r"(\d+)\s*(day|days|week|weeks|hour|hours|hr|hrs)", lower)
        if duration_match:
            metadata["duration_text"] = duration_match.group(0)

        # Negation hints
        negations = re.findall(r"no ([a-z ]+?)(?:[,.;]|$)", lower)
        if negations:
            metadata["negation_terms"] = [n.strip() for n in negations if n.strip()]

        # Age hints
        age_match = re.search(r"(\d+)\s*(year|years|yo|y/o)", lower)
        if age_match:
            metadata["age_mentioned"] = age_match.group(1)

        return metadata


def run_data_collection(state: SymptomOneState) -> SymptomOneState:
    agent = DataCollectionAgent()
    result = agent.process(state["symptom_paragraph"])

    state["loaded_text"] = state["symptom_paragraph"]
    state["cleaned_text"] = result.get("cleaned_text", state["symptom_paragraph"])
    state["metadata"] = result.get("metadata", {})
    state["data_collection_complete"] = True

    return state
