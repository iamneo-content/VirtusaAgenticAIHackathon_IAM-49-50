"""
Symptom Classification Agent (ML-backed)
Uses a trained model/vectorizer/label binarizer from ml/model/.
Falls back to heuristic if artifacts are missing.
"""

import os
import joblib
from typing import Dict, Any, List, Optional
from state import SymptomOneState

MODEL_PATHS = ["ml/model/symptom_model.pkl", "ml/model/symptom_model.joblib"]
VECT_PATHS = ["ml/model/symptom_vectorizer.pkl", "ml/model/symptom_vectorizer.joblib"]
MLB_PATHS = ["ml/model/symptom_mlb.pkl", "ml/model/symptom_mlb.joblib"]


class SymptomClassificationAgent:
    """Identifies primary/secondary symptoms and body systems using ML model."""

    def __init__(self):
        self.model = self._load_first(MODEL_PATHS)
        self.vectorizer = self._load_first(VECT_PATHS)
        self.mlb = self._load_first(MLB_PATHS)

    def _load_first(self, paths: List[str]) -> Optional[Any]:
        for p in paths:
            if os.path.exists(p):
                return joblib.load(p)
        return None

    def classify(self, cleaned_text: str) -> Dict[str, Any]:
        if not (self.model and self.vectorizer and self.mlb):
            raise FileNotFoundError(
                "Symptom model artifacts missing. Expected model/vectorizer/mlb under ml/model/."
            )

        X = self.vectorizer.transform([cleaned_text])
        preds = self.model.predict(X)
        if hasattr(preds, "toarray"):
            preds = preds.toarray()
        labels = self.mlb.inverse_transform(preds)[0] if len(preds) else []
        primary = list(labels)

        return {
            "primary_symptoms": primary,
            "secondary_symptoms": [],
            "body_systems": [],
            "confidence_scores": {},
        }


def run_symptom_classification(state: SymptomOneState) -> SymptomOneState:
    try:
        agent = SymptomClassificationAgent()
        classification = agent.classify(state.get("cleaned_text", state.get("symptom_paragraph", "")))
        state["symptom_classification"] = classification
        state["symptom_classifier_complete"] = True
        state["classification_error"] = ""
    except Exception as e:
        state["symptom_classifier_complete"] = False
        state["classification_error"] = str(e)
        state["symptom_classification"] = {}
    return state
