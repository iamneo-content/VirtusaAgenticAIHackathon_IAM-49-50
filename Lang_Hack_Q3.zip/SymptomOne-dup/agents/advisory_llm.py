"""
Advisory Agent
Uses Gemini-2.0-Flash to generate self-care advice for LOW-risk cases.
"""

import os
import json
from typing import Dict, Any
from dotenv import load_dotenv
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.messages import HumanMessage
from state import SymptomOneState

load_dotenv()


class AdvisoryAgent:
    """Produces practical advice for low-risk scenarios."""

    def __init__(self):
        self.model = ChatGoogleGenerativeAI(
            model="gemini-2.0-flash",
            google_api_key=os.getenv("GEMINI_API_KEY_3"),
            temperature=0.3,
        )

    def generate(self, state: SymptomOneState) -> Dict[str, Any]:
        severity = state.get("severity_assessment", {})
        classification = state.get("symptom_classification", {})
        symptom_text = state.get("cleaned_text", state.get("symptom_paragraph", ""))

        prompt = f"""You are a healthcare advisor for low-risk symptoms. Provide concise, practical guidance.

SYMPTOMS:
{symptom_text}

CLASSIFICATION:
- Primary: {', '.join(classification.get('primary_symptoms', []))}
- Secondary: {', '.join(classification.get('secondary_symptoms', []))}

SEVERITY:
- Level: {severity.get('severity_level', 'Low')}
- Red flags: {', '.join(severity.get('red_flags', ['None']))}

Return JSON:
{{
  "advice": "plain text advice",
  "monitoring_instructions": ["item1", "item2"],
  "seek_care_if": ["item1", "item2"],
  "advice_reasoning": "brief rationale"
}}
"""
        response = self.model.invoke([HumanMessage(content=prompt)])
        content = response.content.strip()
        if content.startswith("```"):
            content = content.strip("`").replace("json", "", 1).strip()
        return json.loads(content)


def run_advisory(state: SymptomOneState) -> SymptomOneState:
    agent = AdvisoryAgent()
    result = agent.generate(state)
    state["advice"] = result.get("advice", "")
    state["advice_reasoning"] = result.get("advice_reasoning", "")
    state["advice_generator_complete"] = True

    # Populate a light treatment plan for compatibility
    state["treatment_plan"] = {
        "immediate_actions": ["Follow self-care guidance", "Monitor symptoms"],
        "medications": ["Over-the-counter options if appropriate"],
        "lifestyle": ["See advice for lifestyle recommendations"],
        "follow_up": ["Contact a clinician if symptoms persist or worsen"],
    }
    state["plan_reasoning"] = state["advice"]
    state["treatment_complete"] = True
    return state
