"""
Patient-Friendly Explainer Agent
Uses Gemini-2.0-Flash to turn clinical outputs into plain-language guidance.
"""

import os
import json
from typing import Dict, Any
from dotenv import load_dotenv
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.messages import HumanMessage
from state import SymptomOneState

load_dotenv()


class PatientExplainerAgent:
    """Summarizes the case and next steps in patient-friendly language."""

    def __init__(self):
        self.model = ChatGoogleGenerativeAI(
            model="gemini-2.0-flash",
            google_api_key=os.getenv("GEMINI_API_KEY_2"),
            temperature=0.2,
        )

    def summarize(self, state: SymptomOneState) -> str:
        severity = state.get("severity_assessment", {})
        risk_level = state.get("risk_level", "LOW")
        plan = state.get("treatment_plan", {})
        advice = state.get("advice", "")
        differential = state.get("differential_diagnosis", [])

        prompt = f"""Rewrite the clinical outputs for a patient audience. Be concise and reassuring.

SEVERITY: {severity}
RISK LEVEL: {risk_level}
DIFFERENTIAL (if any): {differential}
PLAN: {plan}
ADVICE: {advice}

Return plain text (no JSON) with:
- What we found
- What to do now
- When to seek help
"""
        response = self.model.invoke([HumanMessage(content=prompt)])
        return response.content.strip()


def run_patient_explainer(state: SymptomOneState) -> SymptomOneState:
    agent = PatientExplainerAgent()
    summary = agent.summarize(state)
    state["patient_friendly_summary"] = summary
    state["patient_explainer_complete"] = True
    return state
