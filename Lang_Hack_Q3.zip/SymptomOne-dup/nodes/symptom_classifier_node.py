"""
Symptom Classification Node
Wraps the SymptomClassificationAgent.
"""

from state import SymptomOneState
from agents.symptom_classification_ml import run_symptom_classification


def symptom_classifier_node(state: SymptomOneState) -> SymptomOneState:
    print("\n[SYMPTOM CLASSIFIER] Analyzing symptom patterns...")

    try:
        state = run_symptom_classification(state)
        primary = state["symptom_classification"].get("primary_symptoms", [])
        print(f"[SYMPTOM CLASSIFIER] Identified {len(primary)} primary symptoms")
        return {
            "symptom_classification": state.get("symptom_classification", {}),
            "symptom_classifier_complete": True,
            "classification_error": "",
        }
    except Exception as e:
        print(f"[SYMPTOM CLASSIFIER] Error: {e}")
        return {
            "classification_error": str(e),
            "symptom_classifier_complete": False,
            "symptom_classification": {},
        }
