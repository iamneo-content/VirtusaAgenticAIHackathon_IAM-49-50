"""
Patient-Friendly Explainer Node
Runs the PatientExplainerAgent to produce a plain-language summary.
"""

from state import SymptomOneState
from agents.patient_explainer_llm import run_patient_explainer


def patient_explainer_node(state: SymptomOneState) -> SymptomOneState:
    print("\n[PATIENT EXPLAINER] Creating patient-friendly summary...")
    try:
        state = run_patient_explainer(state)
        print(f"[PATIENT EXPLAINER] Summary length: {len(state.get('patient_friendly_summary', ''))} characters")
    except Exception as e:
        print(f"[PATIENT EXPLAINER] Error: {e}")
        state["patient_explainer_complete"] = False
        state["patient_friendly_summary"] = ""
    return state
