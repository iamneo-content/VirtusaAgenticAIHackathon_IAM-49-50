"""
Advice Generator Node
Wraps the AdvisoryAgent for LOW-risk path.
"""

from state import SymptomOneState
from agents.advisory_llm import run_advisory


def advice_generator_node(state: SymptomOneState) -> SymptomOneState:
    print("\n[ADVICE GENERATOR] Generating health advice for low-risk symptoms...")

    try:
        state = run_advisory(state)
        print(f"[ADVICE GENERATOR] Generated advice ({len(state.get('advice', ''))} characters)")
    except Exception as e:
        print(f"[ADVICE GENERATOR] Error: {e}")
        state["advice"] = "Please consult with a healthcare provider for personalized advice."
        state["advice_reasoning"] = f"Error: {str(e)}"
        state["advice_generator_complete"] = False
        state["treatment_plan"] = {}

    return state
