"""
Data Collection Node
Runs the DataCollectionAgent to normalize text and extract basic metadata.
"""

from state import SymptomOneState
from agents.data_collection import run_data_collection


def data_collection_node(state: SymptomOneState) -> SymptomOneState:
    print("\n[DATA COLLECTION] Normalizing input text and extracting metadata...")
    state = run_data_collection(state)
    print("[DATA COLLECTION] Complete")
    return state
