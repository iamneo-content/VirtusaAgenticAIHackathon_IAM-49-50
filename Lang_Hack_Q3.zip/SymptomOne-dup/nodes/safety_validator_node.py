"""
Safety Validator Node
Validates outputs for safety, appropriateness, and medical accuracy.
Filters out unsafe recommendations and adds necessary warnings.
"""

from state import SymptomOneState


def safety_validator_node(state: SymptomOneState) -> SymptomOneState:
    """
    Safety Validator Node - validates all outputs for safety and appropriateness.

    Checks for:
    - Dangerous recommendations
    - Missing critical warnings
    - Inappropriate urgency levels
    - Medication safety issues
    """
    print("\n[SAFETY VALIDATOR] Validating outputs for safety...")

    warnings = []
    safety_passed = True

    # Validate severity matches red flags
    severity = state.get("severity_assessment", {})
    severity_level = severity.get("severity_level", "Unknown")
    red_flags = severity.get("red_flags", [])

    if red_flags and red_flags != ["None"] and len(red_flags) > 0:
        if severity_level not in ["Critical", "High"]:
            warnings.append("Red flags detected but severity not elevated - adjusting to High")
            state["severity_assessment"]["severity_level"] = "High"
            severity_level = "High"

    # Validate emergency criteria
    urgency = severity.get("urgency", "")
    if severity_level == "Critical" and "Emergency" not in urgency:
        warnings.append("Critical severity requires emergency urgency - adding emergency notice")
        state["severity_assessment"]["urgency"] = "Emergency - Call 911 immediately"

    # Validate medication safety (HIGH risk path)
    if state.get("risk_level") == "HIGH":
        medications = state.get("treatment_plan", {}).get("medications", [])
        if medications:
            med_evidence = state.get("med_evidence", {})
            disclaimer = med_evidence.get("disclaimer", "")
            if disclaimer:
                state["med_evidence"]["disclaimer"] = disclaimer
            else:
                warnings.append("Adding medication disclaimer")
                state.setdefault("med_evidence", {})["disclaimer"] = (
                    "DISCLAIMER: This is educational information only. Always consult with a healthcare provider before taking any medication."
                )

    # Validate differential diagnosis exists for HIGH risk
    if state.get("risk_level") == "HIGH":
        differential = state.get("differential_diagnosis", [])
        if not differential or len(differential) == 0:
            warnings.append("HIGH risk case missing differential diagnosis - flagging for review")
            safety_passed = False

    # Add general medical disclaimer to any outputs
    general_disclaimer = "\n\n⚠️ MEDICAL DISCLAIMER: This analysis is for educational purposes only and is not a substitute for professional medical advice, diagnosis, or treatment. Always seek the advice of your physician or other qualified health provider with any questions you may have regarding a medical condition. In case of emergency, call 911 immediately."

    # Add disclaimer to advice or plan reasoning
    if state.get("advice_reasoning"):
        if "DISCLAIMER" not in state["advice_reasoning"]:
            state["advice_reasoning"] += general_disclaimer

    if state.get("plan_reasoning"):
        if "DISCLAIMER" not in state["plan_reasoning"]:
            state["plan_reasoning"] += general_disclaimer

    # Store validation results
    state["safety_passed"] = safety_passed
    state["safety_warnings"] = warnings
    state["safety_modified_output"] = {
        "warnings_added": len(warnings),
        "passed": safety_passed
    }
    state["safety_validator_complete"] = True

    if warnings:
        print(f"[SAFETY VALIDATOR] {len(warnings)} safety warnings/modifications:")
        for w in warnings:
            print(f"  - {w}")
    else:
        print("[SAFETY VALIDATOR] All safety checks passed")

    return state
