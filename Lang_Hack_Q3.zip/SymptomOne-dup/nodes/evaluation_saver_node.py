"""
Evaluation Saver Node
Evaluates the analysis quality and saves all outputs.
"""

import os
from state import SymptomOneState, slugify, save_file


def evaluation_saver_node(state: SymptomOneState) -> SymptomOneState:
    """
    Evaluation Saver Node - evaluates quality and saves results.

    Performs:
    - Quality assessment of analysis
    - Completeness checks
    - Saves report to file
    - Records evaluation metrics
    """
    print("\n[EVALUATION SAVER] Evaluating analysis quality and saving results...")

    # Calculate evaluation metrics
    eval_metrics = {}

    # Completeness score
    completeness_checks = {
        "data_collection_complete": state.get("data_collection_complete", False),
        "symptom_classifier_complete": state.get("symptom_classifier_complete", False),
        "severity_assessor_complete": state.get("severity_assessor_complete", False),
        "risk_router_complete": state.get("risk_router_complete", False),
        "safety_validator_complete": state.get("safety_validator_complete", False),
        "patient_explainer_complete": state.get("patient_explainer_complete", False),
        "report_generator_complete": state.get("report_generator_complete", False),
    }

    # Add path-specific checks
    if state.get("risk_level") == "HIGH":
        completeness_checks.update({
            "differential_complete": state.get("differential_complete", False),
            "treatment_complete": state.get("treatment_complete", False),
            "med_evidence_complete": state.get("med_evidence_complete", False),
        })
    else:
        completeness_checks["advice_generator_complete"] = state.get("advice_generator_complete", False)

    completed = sum(1 for v in completeness_checks.values() if v)
    total = len(completeness_checks)
    completeness_score = completed / total if total > 0 else 0

    eval_metrics["completeness_score"] = completeness_score
    eval_metrics["completed_nodes"] = completed
    eval_metrics["total_nodes"] = total
    eval_metrics["risk_level"] = state.get("risk_level", "Unknown")
    eval_metrics["safety_passed"] = state.get("safety_passed", False)
    eval_metrics["safety_warnings_count"] = len(state.get("safety_warnings", []))

    # Quality indicators
    eval_metrics["has_differential"] = len(state.get("differential_diagnosis", [])) > 0
    eval_metrics["has_medications"] = len(state.get("treatment_plan", {}).get("medications", [])) > 0
    eval_metrics["has_treatment_plan"] = bool(state.get("treatment_plan", {}))
    eval_metrics["has_advice"] = bool(state.get("advice", ""))

    # Overall quality score
    quality_score = 0.0
    if completeness_score >= 0.9:
        quality_score += 0.4
    elif completeness_score >= 0.7:
        quality_score += 0.2

    if state.get("safety_passed"):
        quality_score += 0.3

    if eval_metrics["risk_level"] == "HIGH":
        if eval_metrics["has_differential"]:
            quality_score += 0.15
        if eval_metrics["has_treatment_plan"]:
            quality_score += 0.15
    else:
        if eval_metrics["has_advice"]:
            quality_score += 0.3

    eval_metrics["quality_score"] = min(1.0, quality_score)

    # Save the report
    folder_name = slugify(state.get("symptom_paragraph", "symptom"))
    output_dir = os.path.join(state.get("output_base", "output"), folder_name)
    report_path = os.path.join(output_dir, "triage_report.txt")

    save_file(report_path, state.get("final_report", ""))

    # Save evaluation metrics
    metrics_path = os.path.join(output_dir, "evaluation_metrics.txt")
    metrics_content = "EVALUATION METRICS\n" + "=" * 50 + "\n"
    for key, value in eval_metrics.items():
        metrics_content += f"{key}: {value}\n"

    save_file(metrics_path, metrics_content)

    # Update state
    state["eval_metrics"] = eval_metrics
    state["saved_path"] = report_path
    state["output_dir"] = output_dir
    state["evaluation_saver_complete"] = True

    print(f"[EVALUATION SAVER] Quality Score: {quality_score:.2f}")
    print(f"[EVALUATION SAVER] Completeness: {completeness_score:.1%} ({completed}/{total} nodes)")
    print(f"[EVALUATION SAVER] Report saved to: {report_path}")

    return state
