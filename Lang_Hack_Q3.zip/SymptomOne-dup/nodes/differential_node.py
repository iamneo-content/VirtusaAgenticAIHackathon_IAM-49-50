"""
Differential Diagnosis Node
Wraps the DifferentialDiagnosisAgent.
"""

from state import SymptomOneState
from agents.differential_llm import run_differential


def differential_node(state: SymptomOneState) -> SymptomOneState:
    print("\n[DIFFERENTIAL] Generating possible diagnoses...")
    try:
        state = run_differential(state)
        print(f"[DIFFERENTIAL] Generated {len(state.get('differential_diagnosis', []))} diagnoses")
    except Exception as e:
        print(f"[DIFFERENTIAL] Error: {e}")
        state["differential_error"] = str(e)
        state["differential_complete"] = False
    return state
