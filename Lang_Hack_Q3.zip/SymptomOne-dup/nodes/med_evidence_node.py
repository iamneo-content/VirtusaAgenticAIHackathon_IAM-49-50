"""
Medication Evidence Node
Runs the MedicationEvidenceAgent to annotate medication recommendations with safety context.
"""

from state import SymptomOneState
from agents.med_evidence_llm import run_med_evidence


def med_evidence_node(state: SymptomOneState) -> SymptomOneState:
    print("\n[MED EVIDENCE] Validating medication recommendations...")
    try:
        state = run_med_evidence(state)
        validated = len(state.get("med_evidence", {}).get("validated_medications", []))
        print(f"[MED EVIDENCE] Annotated {validated} medications")
    except Exception as e:
        print(f"[MED EVIDENCE] Error: {e}")
        state["med_evidence_complete"] = False
        state["med_evidence"] = {}
    return state
