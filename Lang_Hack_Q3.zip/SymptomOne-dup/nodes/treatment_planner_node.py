"""
Treatment Planner Node
Wraps the TreatmentPlanningAgent.
"""

from state import SymptomOneState
from agents.treatment_llm import run_treatment_planning


def treatment_planner_node(state: SymptomOneState) -> SymptomOneState:
    print("\n[TREATMENT PLANNER] Generating comprehensive treatment plan...")

    try:
        state = run_treatment_planning(state)
        immediate_actions = len(state.get("treatment_plan", {}).get("immediate_actions", []))
        print(f"[TREATMENT PLANNER] Plan generated with {immediate_actions} immediate actions")
    except Exception as e:
        print(f"[TREATMENT PLANNER] Error: {e}")
        state["treatment_error"] = str(e)
        state["treatment_complete"] = False
        state["treatment_plan"] = {}
        state["plan_reasoning"] = ""

    return state
