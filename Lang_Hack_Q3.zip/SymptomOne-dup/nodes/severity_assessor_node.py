"""
Severity Assessor Node
Wraps the SeverityAssessmentAgent.
"""

from state import SymptomOneState
from agents.severity_assessment_ml import run_severity_assessment


def severity_assessor_node(state: SymptomOneState) -> SymptomOneState:
    print("\n[SEVERITY ASSESSOR] Assessing severity and urgency...")

    try:
        state = run_severity_assessment(state)
        severity_level = state["severity_assessment"].get("severity_level", "Unknown")
        print(f"[SEVERITY ASSESSOR] Severity: {severity_level}")
        return {
            "severity_assessment": state.get("severity_assessment", {}),
            "severity_assessor_complete": True,
            "risk_score": state.get("risk_score", 0.0),
            "risk_level": state.get("risk_level", "LOW"),
        }
    except Exception as e:
        print(f"[SEVERITY ASSESSOR] Error: {e}")
        return {
            "classification_error": str(e),
            "severity_assessor_complete": False,
            "severity_assessment": {},
        }
