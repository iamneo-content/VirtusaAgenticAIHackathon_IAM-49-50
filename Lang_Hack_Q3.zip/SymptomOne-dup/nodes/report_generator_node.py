"""
Report Generator Node
Generates the final comprehensive medical triage report.
"""

from state import SymptomOneState


def report_generator_node(state: SymptomOneState) -> SymptomOneState:
    """
    Report Generator Node - creates the final comprehensive report.

    Compiles all analysis results into a structured report including:
    - Patient symptoms
    - Classification and severity
    - Risk assessment
    - Differential diagnosis or advice
    - Treatment plan or recommendations
    - Safety warnings
    """
    print("\n[REPORT GENERATOR] Generating final comprehensive report...")

    report = []
    report.append("=" * 80)
    report.append("SYMPTOMONE MEDICAL TRIAGE REPORT")
    report.append("=" * 80)
    report.append("")

    # Original Symptom
    report.append("PATIENT SYMPTOMS:")
    report.append("-" * 80)
    report.append(state.get("symptom_paragraph", ""))
    report.append("")

    # Classification
    if state.get("symptom_classifier_complete"):
        report.append("SYMPTOM CLASSIFICATION:")
        report.append("-" * 80)
        classification = state.get("symptom_classification", {})

        primary = classification.get("primary_symptoms", [])
        secondary = classification.get("secondary_symptoms", [])
        systems = classification.get("body_systems", [])

        report.append(f"Primary Symptoms: {', '.join(primary) if primary else 'None identified'}")
        report.append(f"Secondary Symptoms: {', '.join(secondary) if secondary else 'None identified'}")
        report.append(f"Body Systems Affected: {', '.join(systems) if systems else 'None identified'}")
        report.append("")

    # Severity Assessment
    if state.get("severity_assessor_complete"):
        report.append("SEVERITY ASSESSMENT:")
        report.append("-" * 80)
        severity = state.get("severity_assessment", {})
        report.append(f"Severity Level: {severity.get('severity_level', 'Unknown')}")
        report.append(f"Urgency: {severity.get('urgency', 'Unknown')}")
        red_flags = severity.get("red_flags", ["None"])
        report.append(f"Red Flags: {', '.join(red_flags)}")
        report.append("")

    # Risk Assessment
    if state.get("risk_router_complete"):
        report.append("RISK ASSESSMENT:")
        report.append("-" * 80)
        report.append(f"Risk Level: {state.get('risk_level', 'Unknown')}")
        report.append(f"Risk Score: {state.get('risk_score', 0.0):.2f}")
        report.append(f"Care Path: {'Comprehensive Analysis' if state.get('risk_level') == 'HIGH' else 'General Advice'}")
        report.append("")

    # Differential Diagnosis (HIGH risk only)
    if state.get("risk_level") == "HIGH" and state.get("differential_complete"):
        report.append("DIFFERENTIAL DIAGNOSIS:")
        report.append("-" * 80)
        for idx, diagnosis in enumerate(state.get("differential_diagnosis", []), 1):
            report.append(f"{idx}. {diagnosis.get('condition', 'Unknown')}")
            report.append(f"   Confidence: {diagnosis.get('confidence', 'Unknown')}")
            report.append(f"   Rationale: {diagnosis.get('rationale', 'N/A')}")
            report.append("")

        if state.get("diagnosis_reasoning"):
            report.append("Clinical Reasoning:")
            report.append(state["diagnosis_reasoning"])
            report.append("")

    # Medications (HIGH risk only)
    if state.get("risk_level") == "HIGH" and state.get("med_evidence_complete"):
        meds = state.get("med_evidence", {}).get("validated_medications", [])
        if meds:
            report.append("MEDICATION RECOMMENDATIONS:")
            report.append("-" * 80)
            for med in meds:
                report.append(f"• {med.get('name', 'Unknown')}")
                if med.get("indication"):
                    report.append(f"  Indication: {med['indication']}")
                if med.get("warnings"):
                    report.append(f"  Warnings: {med['warnings']}")
                if med.get("monitoring"):
                    report.append(f"  Monitoring: {med['monitoring']}")
                report.append("")
        elif state.get("treatment_plan", {}).get("medications"):
            report.append("MEDICATION RECOMMENDATIONS:")
            report.append("-" * 80)
            for med in state["treatment_plan"]["medications"]:
                report.append(f"• {med}")
            report.append("")

    # Treatment Plan (HIGH risk)
    if state.get("risk_level") == "HIGH" and state.get("treatment_complete"):
        report.append("TREATMENT PLAN:")
        report.append("-" * 80)
        plan = state.get("treatment_plan", {})

        if plan.get("immediate_actions"):
            report.append("Immediate Actions:")
            for action in plan["immediate_actions"]:
                report.append(f"  • {action}")
            report.append("")

        if plan.get("lifestyle"):
            report.append("Lifestyle Recommendations:")
            for rec in plan["lifestyle"]:
                report.append(f"  • {rec}")
            report.append("")

        if plan.get("follow_up"):
            report.append("Follow-up Care:")
            for followup in plan["follow_up"]:
                report.append(f"  • {followup}")
            report.append("")

    # Health Advice (LOW risk)
    if state.get("risk_level") == "LOW" and state.get("advice_generator_complete"):
        report.append("HEALTH ADVICE:")
        report.append("-" * 80)
        report.append(state.get("advice", ""))
        report.append("")

    # Patient-friendly summary
    if state.get("patient_explainer_complete"):
        report.append("PATIENT-FRIENDLY SUMMARY:")
        report.append("-" * 80)
        report.append(state.get("patient_friendly_summary", ""))
        report.append("")

    # Safety Warnings
    if state.get("safety_warnings"):
        report.append("SAFETY VALIDATION:")
        report.append("-" * 80)
        for warning in state["safety_warnings"]:
            report.append(f"⚠️  {warning}")
        report.append("")

    # Medical Disclaimer
    report.append("=" * 80)
    report.append("MEDICAL DISCLAIMER")
    report.append("=" * 80)
    report.append("This analysis is for educational and informational purposes only.")
    report.append("It is NOT a substitute for professional medical advice, diagnosis, or treatment.")
    report.append("Always seek the advice of your physician or other qualified health provider.")
    report.append("In case of emergency, call 911 or your local emergency number immediately.")
    report.append("=" * 80)

    final_report = "\n".join(report)
    state["final_report"] = final_report
    state["report_generator_complete"] = True

    print(f"[REPORT GENERATOR] Report generated ({len(final_report)} characters)")

    return state
