"""
Risk Router Node
Determines the risk level based on symptom and severity analysis.
Routes to HIGH risk path (differential → medications → plan) or LOW risk path (advice only).
"""

from state import SymptomOneState


def risk_router_node(state: SymptomOneState) -> SymptomOneState:
    """
    Risk Router Node - determines risk level and routing path.

    Routes to:
    - HIGH: elevated risk → differential, treatment, medication evidence
    - LOW: general advice
    """
    print("\n[RISK ROUTER] Determining risk level and routing path...")

    severity = state.get("severity_assessment", {})
    severity_level = severity.get("severity_level", "Unknown")
    red_flags = severity.get("red_flags", [])
    risk_score = severity.get("risk_score", state.get("risk_score", 0.0))

    if not state.get("severity_assessor_complete"):
        raise ValueError("Severity assessment incomplete; cannot route risk without model outputs.")

    # Fallback heuristic if risk_score not set
    if not risk_score:
        if severity_level == "Critical":
            risk_score = 1.0
        elif severity_level == "High":
            risk_score = 0.75
        elif severity_level == "Moderate":
            risk_score = 0.5
        elif severity_level == "Low":
            risk_score = 0.25
        else:
            risk_score = 0.5

    # Adjust for red flags
    if red_flags and red_flags != ["None"]:
        risk_score = min(1.0, risk_score + 0.2)

    risk_level = "HIGH" if risk_score >= 0.6 else "LOW"

    updates = {
        "risk_level": risk_level,
        "risk_score": risk_score,
        "risk_router_complete": True,
    }

    print(f"[RISK ROUTER] Risk Level: {risk_level} (score: {risk_score:.2f})")
    print(f"[RISK ROUTER] Routing to: {'Differential Analysis Path' if risk_level == 'HIGH' else 'Advice Path'}")

    return updates
