"""
Workflow assembly module.
Builds the SymptomOne LangGraph workflow by adding nodes and edges.
"""

from langgraph.graph import StateGraph, END
from typing import Literal
from state import SymptomOneState

# Node imports
from nodes.data_collection_node import data_collection_node
from nodes.symptom_classifier_node import symptom_classifier_node
from nodes.severity_assessor_node import severity_assessor_node
from nodes.risk_router_node import risk_router_node
from nodes.differential_node import differential_node
from nodes.treatment_planner_node import treatment_planner_node
from nodes.med_evidence_node import med_evidence_node
from nodes.advice_generator_node import advice_generator_node
from nodes.safety_validator_node import safety_validator_node
from nodes.patient_explainer_node import patient_explainer_node
from nodes.report_generator_node import report_generator_node
from nodes.evaluation_saver_node import evaluation_saver_node


def risk_router_decision(state: SymptomOneState) -> Literal["high_risk_path", "low_risk_path"]:
    return "high_risk_path" if state.get("risk_level") == "HIGH" else "low_risk_path"


def build_workflow():
    """
    Assemble the SymptomOne workflow:
        data_collection →
        (symptom_classification || severity_assessment) →
        risk_router →
            HIGH: differential → treatment_planner → med_evidence
            LOW: advice_generator
        → safety_validator → patient_explainer → report_generator → evaluation_saver
    """
    workflow = StateGraph(SymptomOneState)

    # Nodes
    workflow.add_node("data_collection_node", data_collection_node)
    workflow.add_node("symptom_classifier_node", symptom_classifier_node)
    workflow.add_node("severity_assessor_node", severity_assessor_node)
    workflow.add_node("risk_router_node", risk_router_node)
    workflow.add_node("differential_node", differential_node)
    workflow.add_node("treatment_planner_node", treatment_planner_node)
    workflow.add_node("med_evidence_node", med_evidence_node)
    workflow.add_node("advice_generator_node", advice_generator_node)
    workflow.add_node("safety_validator_node", safety_validator_node)
    workflow.add_node("patient_explainer_node", patient_explainer_node)
    workflow.add_node("report_generator_node", report_generator_node)
    workflow.add_node("evaluation_saver_node", evaluation_saver_node)

    # Entry
    workflow.set_entry_point("data_collection_node")

    # Parallel classification and severity
    workflow.add_edge("data_collection_node", "symptom_classifier_node")
    workflow.add_edge("data_collection_node", "severity_assessor_node")

    # Join at risk router
    workflow.add_edge("symptom_classifier_node", "risk_router_node")
    workflow.add_edge("severity_assessor_node", "risk_router_node")

    # Conditional branch
    workflow.add_conditional_edges(
        "risk_router_node",
        risk_router_decision,
        {"high_risk_path": "differential_node", "low_risk_path": "advice_generator_node"},
    )

    # High risk path
    workflow.add_edge("differential_node", "treatment_planner_node")
    workflow.add_edge("treatment_planner_node", "med_evidence_node")
    workflow.add_edge("med_evidence_node", "safety_validator_node")

    # Low risk path
    workflow.add_edge("advice_generator_node", "safety_validator_node")

    # Common path
    workflow.add_edge("safety_validator_node", "patient_explainer_node")
    workflow.add_edge("patient_explainer_node", "report_generator_node")
    workflow.add_edge("report_generator_node", "evaluation_saver_node")
    workflow.add_edge("evaluation_saver_node", END)

    return workflow
