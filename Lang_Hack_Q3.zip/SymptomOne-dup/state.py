from typing import Dict, List, TypedDict, Optional
import os
import re


class SymptomOneState(TypedDict):
    """
    State schema for the SymptomOne workflow.

    Planned workflow:
        data_collection → (symptom_classification || severity_assessment) → risk_router →
            HIGH: differential → treatment_planner → med_evidence
            LOW: advisory
        → safety_validator → patient_explainer → report_generator → evaluation_saver
    """
    # Input from user
    symptom_paragraph: str

    # Data Collection
    loaded_text: str
    cleaned_text: str
    metadata: Dict[str, any]  # duration, negations, age hint, etc.
    data_collection_complete: bool

    # Symptom Classification (runs in parallel with severity_assessment)
    symptom_classification: Dict[str, any]
    symptom_classifier_complete: bool

    # Severity Assessment (runs in parallel with symptom_classification)
    severity_assessment: Dict[str, any]
    severity_assessor_complete: bool

    # Risk Router Node
    risk_level: str  # "HIGH" or "LOW"
    risk_score: float
    risk_router_complete: bool

    # Differential Diagnosis (HIGH risk)
    differential_diagnosis: List[Dict[str, str]]
    diagnosis_reasoning: str
    differential_complete: bool

    # Treatment Planning (HIGH risk)
    treatment_plan: Dict[str, any]
    plan_reasoning: str
    treatment_complete: bool

    # Medication evidence (HIGH risk)
    med_evidence: Dict[str, any]
    med_evidence_complete: bool

    # Advisory (LOW risk)
    advice: str
    advice_reasoning: str
    advice_generator_complete: bool

    # Patient explainer (post-safety)
    patient_friendly_summary: str
    patient_explainer_complete: bool

    # Safety Validator Node
    safety_passed: bool
    safety_warnings: List[str]
    safety_modified_output: Dict[str, any]
    safety_validator_complete: bool

    # Report Generator Node
    final_report: str
    report_generator_complete: bool

    # Evaluation Saver Node
    eval_metrics: Dict[str, any]
    saved_path: str
    evaluation_saver_complete: bool

    # Output directory information
    output_base: str
    output_dir: str

    # Error tracking
    classification_error: str
    differential_error: str
    treatment_error: str
    error_occurred: bool


def slugify(text: str) -> str:
    """Convert text to a safe filename slug."""
    text = re.sub(r"[^a-zA-Z0-9]+", "_", text.strip().lower())
    return text[:50].strip("_") or "symptom"


def save_file(path: str, content: str):
    """Save content to file, creating directories as needed."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)


def format_output_report(state: SymptomOneState) -> str:
    """Format the complete medical triage report."""
    report = []
    report.append("=" * 80)
    report.append("SYMPTOMONE MEDICAL TRIAGE REPORT")
    report.append("=" * 80)
    report.append("")

    # Original Symptom
    report.append("PATIENT SYMPTOMS:")
    report.append("-" * 80)
    report.append(state["symptom_paragraph"])
    report.append("")

    # Classification
    if state.get("symptom_classifier_complete"):
        report.append("SYMPTOM CLASSIFICATION:")
        report.append("-" * 80)
        classification = state["symptom_classification"]

        report.append(f"Primary Symptoms: {', '.join(classification.get('primary_symptoms', []))}")
        report.append(f"Secondary Symptoms: {', '.join(classification.get('secondary_symptoms', []))}")
        report.append(f"Body Systems Affected: {', '.join(classification.get('body_systems', []))}")
        report.append("")

    # Severity
    if state.get("severity_assessor_complete"):
        report.append("SEVERITY ASSESSMENT:")
        report.append("-" * 80)
        severity = state["severity_assessment"]
        report.append(f"Severity Level: {severity.get('severity_level', 'Unknown')}")
        report.append(f"Urgency: {severity.get('urgency', 'Unknown')}")
        report.append(f"Red Flags: {', '.join(severity.get('red_flags', ['None']))}")
        report.append(f"Risk Score: {severity.get('risk_score', state.get('risk_score', 0.0)):.2f}")
        report.append("")

    # Differential Diagnosis
    if state.get("differential_complete"):
        report.append("DIFFERENTIAL DIAGNOSIS:")
        report.append("-" * 80)
        for idx, diagnosis in enumerate(state.get("differential_diagnosis", []), 1):
            report.append(f"{idx}. {diagnosis.get('condition', 'Unknown')}")
            report.append(f"   Confidence: {diagnosis.get('confidence', 'Unknown')}")
            report.append(f"   Rationale: {diagnosis.get('rationale', 'N/A')}")
            report.append("")

        if state.get("diagnosis_reasoning"):
            report.append("Clinical Reasoning:")
            report.append(state["diagnosis_reasoning"])
            report.append("")

    # Treatment Plan
    if state.get("treatment_complete"):
        report.append("TREATMENT PLAN:")
        report.append("-" * 80)
        plan = state["treatment_plan"]

        if plan.get("immediate_actions"):
            report.append("Immediate Actions:")
            for action in plan["immediate_actions"]:
                report.append(f"  - {action}")
            report.append("")

        if plan.get("medications"):
            report.append("Recommended Medications:")
            for med in plan["medications"]:
                report.append(f"  - {med}")
            report.append("")

        if plan.get("lifestyle"):
            report.append("Lifestyle Recommendations:")
            for rec in plan["lifestyle"]:
                report.append(f"  - {rec}")
            report.append("")

        if plan.get("follow_up"):
            report.append("Follow-up Care:")
            for followup in plan["follow_up"]:
                report.append(f"  - {followup}")
            report.append("")

        if state.get("plan_reasoning"):
            report.append("Treatment Rationale:")
            report.append(state["plan_reasoning"])
            report.append("")

    # Medication Evidence (HIGH risk)
    if state.get("med_evidence_complete"):
        med_evidence = state.get("med_evidence", {})
        meds = med_evidence.get("validated_medications", [])
        if meds:
            report.append("MEDICATION EVIDENCE & SAFETY NOTES:")
            report.append("-" * 80)
            for med in meds:
                report.append(f"• {med.get('name', 'Medication')}")
                if med.get("indication"):
                    report.append(f"  Indication: {med['indication']}")
                if med.get("warnings"):
                    report.append(f"  Warnings: {med['warnings']}")
                if med.get("monitoring"):
                    report.append(f"  Monitoring: {med['monitoring']}")
                report.append("")
        if med_evidence.get("disclaimer"):
            report.append(med_evidence["disclaimer"])
            report.append("")

    # Patient-friendly summary
    if state.get("patient_explainer_complete"):
        report.append("PATIENT-FRIENDLY SUMMARY:")
        report.append("-" * 80)
        report.append(state.get("patient_friendly_summary", ""))
        report.append("")

    # Errors
    errors = []
    if state.get("classification_error"):
        errors.append(f"Classification Error: {state['classification_error']}")
    if state.get("differential_error"):
        errors.append(f"Differential Error: {state['differential_error']}")
    if state.get("treatment_error"):
        errors.append(f"Treatment Error: {state['treatment_error']}")

    if errors:
        report.append("ERRORS ENCOUNTERED:")
        report.append("-" * 80)
        for error in errors:
            report.append(error)
        report.append("")

    report.append("=" * 80)
    report.append("END OF REPORT")
    report.append("=" * 80)

    return "\n".join(report)
