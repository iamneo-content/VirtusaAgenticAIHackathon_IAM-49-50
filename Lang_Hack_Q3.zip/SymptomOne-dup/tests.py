"""
Comprehensive test suite for SymptomOne Medical Triage System
Tests focused on function return values, conditional routing, and parallel execution
"""

import pytest
import os
import tempfile
from unittest.mock import Mock, patch, MagicMock
from typing import Dict

from state import (
    SymptomOneState,
    slugify,
    save_file,
    format_output_report
)
from agents.data_collection import DataCollectionAgent, run_data_collection
from nodes.risk_router_node import risk_router_node
from workflow.workflow import build_workflow, risk_router_decision


class TestSlugifyReturns:
    """Test suite for slugify function return values"""

    def test_slugify_returns_lowercase_string(self):
        """Test 1: slugify returns lowercase alphanumeric string"""
        result = slugify("Chest Pain and Fever")
        assert isinstance(result, str)
        assert result == "chest_pain_and_fever"
        assert result.islower()

    def test_slugify_returns_underscore_separated(self):
        """Test 2: slugify returns underscore-separated words"""
        result = slugify("Multiple Word Test Case")
        assert "_" in result
        assert " " not in result
        assert result == "multiple_word_test_case"

    def test_slugify_returns_default_for_empty(self):
        """Test 3: slugify returns 'symptom' for empty/invalid input"""
        assert slugify("") == "symptom"
        assert slugify("!!!") == "symptom"
        assert slugify("   ") == "symptom"


class TestDataCollectionAgentReturns:
    """Test suite for DataCollectionAgent method return values"""

    def test_clean_text_returns_normalized_string(self):
        """Test 4: _clean_text returns normalized text with single spaces"""
        agent = DataCollectionAgent()
        input_text = "Multiple    spaces   and\n\nnewlines"
        result = agent._clean_text(input_text)

        assert isinstance(result, str)
        assert "    " not in result
        assert "\n\n" not in result
        assert result == "Multiple spaces and newlines"

    def test_extract_metadata_returns_duration_dict(self):
        """Test 5: _extract_metadata returns dict with duration_text"""
        agent = DataCollectionAgent()
        text = "I have had pain for 3 days"
        result = agent._extract_metadata(text)

        assert isinstance(result, dict)
        assert "duration_text" in result
        assert "3 day" in result["duration_text"]  # Regex captures "3 day" from "3 days"

    def test_extract_metadata_returns_age_mentioned(self):
        """Test 6: _extract_metadata returns dict with age_mentioned"""
        agent = DataCollectionAgent()
        text = "I am 45 years old with chest pain"
        result = agent._extract_metadata(text)

        assert isinstance(result, dict)
        assert "age_mentioned" in result
        assert result["age_mentioned"] == "45"

    def test_process_returns_dict_with_cleaned_and_metadata(self):
        """Test 7: process returns dict with cleaned_text and metadata keys"""
        agent = DataCollectionAgent()
        text = "Patient has pain for 2 hours, no fever"
        result = agent.process(text)

        assert isinstance(result, dict)
        assert "cleaned_text" in result
        assert "metadata" in result
        assert isinstance(result["cleaned_text"], str)
        assert isinstance(result["metadata"], dict)


class TestRiskRouterNodeReturns:
    """Test suite for risk_router_node return values"""

    def test_risk_router_returns_high_risk_dict(self):
        """Test 8: risk_router_node returns dict with HIGH risk_level"""
        state = SymptomOneState(
            symptom_paragraph="",
            loaded_text="",
            cleaned_text="",
            metadata={},
            data_collection_complete=True,
            symptom_classification={},
            symptom_classifier_complete=True,
            severity_assessment={
                "severity_level": "Critical",
                "red_flags": ["chest pain"],
                "risk_score": 0.9
            },
            severity_assessor_complete=True,
            risk_level="LOW",
            risk_score=0.0,
            risk_router_complete=False,
            differential_diagnosis=[],
            diagnosis_reasoning="",
            differential_complete=False,
            treatment_plan={},
            plan_reasoning="",
            treatment_complete=False,
            med_evidence={},
            med_evidence_complete=False,
            advice="",
            advice_reasoning="",
            advice_generator_complete=False,
            patient_friendly_summary="",
            patient_explainer_complete=False,
            safety_passed=False,
            safety_warnings=[],
            safety_modified_output={},
            safety_validator_complete=False,
            final_report="",
            report_generator_complete=False,
            eval_metrics={},
            saved_path="",
            evaluation_saver_complete=False,
            output_base="output",
            output_dir="",
            classification_error="",
            differential_error="",
            treatment_error="",
            error_occurred=False
        )

        result = risk_router_node(state)

        assert isinstance(result, dict)
        assert result["risk_level"] == "HIGH"
        assert result["risk_score"] >= 0.6
        assert result["risk_router_complete"] is True

    def test_risk_router_returns_low_risk_dict(self):
        """Test 9: risk_router_node returns dict with LOW risk_level"""
        state = SymptomOneState(
            symptom_paragraph="",
            loaded_text="",
            cleaned_text="",
            metadata={},
            data_collection_complete=True,
            symptom_classification={},
            symptom_classifier_complete=True,
            severity_assessment={
                "severity_level": "Low",
                "red_flags": ["None"],
                "risk_score": 0.25
            },
            severity_assessor_complete=True,
            risk_level="LOW",
            risk_score=0.0,
            risk_router_complete=False,
            differential_diagnosis=[],
            diagnosis_reasoning="",
            differential_complete=False,
            treatment_plan={},
            plan_reasoning="",
            treatment_complete=False,
            med_evidence={},
            med_evidence_complete=False,
            advice="",
            advice_reasoning="",
            advice_generator_complete=False,
            patient_friendly_summary="",
            patient_explainer_complete=False,
            safety_passed=False,
            safety_warnings=[],
            safety_modified_output={},
            safety_validator_complete=False,
            final_report="",
            report_generator_complete=False,
            eval_metrics={},
            saved_path="",
            evaluation_saver_complete=False,
            output_base="output",
            output_dir="",
            classification_error="",
            differential_error="",
            treatment_error="",
            error_occurred=False
        )

        result = risk_router_node(state)

        assert isinstance(result, dict)
        assert result["risk_level"] == "LOW"
        assert result["risk_score"] < 0.6
        assert result["risk_router_complete"] is True


class TestConditionalRouting:
    """Test suite for conditional routing logic"""

    def test_conditional_routing_selects_high_risk_path(self):
        """Test 10: Conditional routing returns high_risk_path for HIGH risk state"""
        state = SymptomOneState(
            symptom_paragraph="Severe chest pain",
            loaded_text="",
            cleaned_text="",
            metadata={},
            data_collection_complete=True,
            symptom_classification={},
            symptom_classifier_complete=True,
            severity_assessment={},
            severity_assessor_complete=True,
            risk_level="HIGH",
            risk_score=0.85,
            risk_router_complete=True,
            differential_diagnosis=[],
            diagnosis_reasoning="",
            differential_complete=False,
            treatment_plan={},
            plan_reasoning="",
            treatment_complete=False,
            med_evidence={},
            med_evidence_complete=False,
            advice="",
            advice_reasoning="",
            advice_generator_complete=False,
            patient_friendly_summary="",
            patient_explainer_complete=False,
            safety_passed=False,
            safety_warnings=[],
            safety_modified_output={},
            safety_validator_complete=False,
            final_report="",
            report_generator_complete=False,
            eval_metrics={},
            saved_path="",
            evaluation_saver_complete=False,
            output_base="output",
            output_dir="",
            classification_error="",
            differential_error="",
            treatment_error="",
            error_occurred=False
        )

        path = risk_router_decision(state)

        assert path == "high_risk_path"
        assert state["risk_level"] == "HIGH"

    def test_conditional_routing_selects_low_risk_path(self):
        """Test 11: Conditional routing returns low_risk_path for LOW risk state"""
        state = SymptomOneState(
            symptom_paragraph="Mild headache",
            loaded_text="",
            cleaned_text="",
            metadata={},
            data_collection_complete=True,
            symptom_classification={},
            symptom_classifier_complete=True,
            severity_assessment={},
            severity_assessor_complete=True,
            risk_level="LOW",
            risk_score=0.2,
            risk_router_complete=True,
            differential_diagnosis=[],
            diagnosis_reasoning="",
            differential_complete=False,
            treatment_plan={},
            plan_reasoning="",
            treatment_complete=False,
            med_evidence={},
            med_evidence_complete=False,
            advice="",
            advice_reasoning="",
            advice_generator_complete=False,
            patient_friendly_summary="",
            patient_explainer_complete=False,
            safety_passed=False,
            safety_warnings=[],
            safety_modified_output={},
            safety_validator_complete=False,
            final_report="",
            report_generator_complete=False,
            eval_metrics={},
            saved_path="",
            evaluation_saver_complete=False,
            output_base="output",
            output_dir="",
            classification_error="",
            differential_error="",
            treatment_error="",
            error_occurred=False
        )

        path = risk_router_decision(state)

        assert path == "low_risk_path"
        assert state["risk_level"] == "LOW"

    def test_conditional_routing_boundary_case_at_threshold(self):
        """Test 12: Conditional routing at exact 0.6 threshold routes to HIGH"""
        state = SymptomOneState(
            symptom_paragraph="",
            loaded_text="",
            cleaned_text="",
            metadata={},
            data_collection_complete=True,
            symptom_classification={},
            symptom_classifier_complete=True,
            severity_assessment={
                "severity_level": "Moderate",
                "red_flags": ["None"],
                "risk_score": 0.6
            },
            severity_assessor_complete=True,
            risk_level="LOW",
            risk_score=0.0,
            risk_router_complete=False,
            differential_diagnosis=[],
            diagnosis_reasoning="",
            differential_complete=False,
            treatment_plan={},
            plan_reasoning="",
            treatment_complete=False,
            med_evidence={},
            med_evidence_complete=False,
            advice="",
            advice_reasoning="",
            advice_generator_complete=False,
            patient_friendly_summary="",
            patient_explainer_complete=False,
            safety_passed=False,
            safety_warnings=[],
            safety_modified_output={},
            safety_validator_complete=False,
            final_report="",
            report_generator_complete=False,
            eval_metrics={},
            saved_path="",
            evaluation_saver_complete=False,
            output_base="output",
            output_dir="",
            classification_error="",
            differential_error="",
            treatment_error="",
            error_occurred=False
        )

        updated_state = risk_router_node(state)
        path = risk_router_decision(updated_state)

        assert updated_state["risk_score"] == 0.6
        assert updated_state["risk_level"] == "HIGH"
        assert path == "high_risk_path"


class TestParallelExecution:
    """Test suite for parallel node execution"""

    def test_workflow_has_parallel_edges_from_data_collection(self):
        """Test 13: Workflow graph has parallel edges to symptom_classifier and severity_assessor"""
        workflow = build_workflow()
        compiled = workflow.compile()

        # Check that workflow compiled successfully
        assert compiled is not None

        # Verify the workflow structure includes the parallel nodes
        graph_dict = workflow.nodes
        assert "symptom_classifier_node" in graph_dict
        assert "severity_assessor_node" in graph_dict
        assert "risk_router_node" in graph_dict

    @patch('nodes.symptom_classifier_node.run_symptom_classification')
    @patch('nodes.severity_assessor_node.run_severity_assessment')
    def test_parallel_nodes_can_execute_independently(self, mock_severity, mock_symptom):
        """Test 14: Parallel nodes (symptom & severity) execute with same input state"""
        # Setup mocks
        mock_symptom.return_value = {
            "symptom_classification": {"primary_symptoms": ["pain"]},
            "symptom_classifier_complete": True,
            "classification_error": ""
        }

        mock_severity.return_value = {
            "severity_assessment": {"severity_level": "High", "risk_score": 0.7},
            "severity_assessor_complete": True,
            "risk_score": 0.7
        }

        initial_state = SymptomOneState(
            symptom_paragraph="Test symptoms",
            loaded_text="Test symptoms",
            cleaned_text="Test symptoms",
            metadata={},
            data_collection_complete=True,
            symptom_classification={},
            symptom_classifier_complete=False,
            severity_assessment={},
            severity_assessor_complete=False,
            risk_level="LOW",
            risk_score=0.0,
            risk_router_complete=False,
            differential_diagnosis=[],
            diagnosis_reasoning="",
            differential_complete=False,
            treatment_plan={},
            plan_reasoning="",
            treatment_complete=False,
            med_evidence={},
            med_evidence_complete=False,
            advice="",
            advice_reasoning="",
            advice_generator_complete=False,
            patient_friendly_summary="",
            patient_explainer_complete=False,
            safety_passed=False,
            safety_warnings=[],
            safety_modified_output={},
            safety_validator_complete=False,
            final_report="",
            report_generator_complete=False,
            eval_metrics={},
            saved_path="",
            evaluation_saver_complete=False,
            output_base="output",
            output_dir="",
            classification_error="",
            differential_error="",
            treatment_error="",
            error_occurred=False
        )

        # Execute parallel nodes with mocked agents
        symptom_result = mock_symptom(initial_state)
        severity_result = mock_severity(initial_state)

        # Both should execute successfully with same input
        assert symptom_result["symptom_classifier_complete"] is True
        assert severity_result["severity_assessor_complete"] is True

        # Verify both were called with state
        mock_symptom.assert_called_once()
        mock_severity.assert_called_once()

    def test_risk_router_waits_for_both_parallel_nodes(self):
        """Test 15: Risk router requires both parallel nodes to complete"""
        # State with only symptom classification complete
        incomplete_state = SymptomOneState(
            symptom_paragraph="",
            loaded_text="",
            cleaned_text="",
            metadata={},
            data_collection_complete=True,
            symptom_classification={"primary_symptoms": ["pain"]},
            symptom_classifier_complete=True,
            severity_assessment={},
            severity_assessor_complete=False,  # Not complete
            risk_level="LOW",
            risk_score=0.0,
            risk_router_complete=False,
            differential_diagnosis=[],
            diagnosis_reasoning="",
            differential_complete=False,
            treatment_plan={},
            plan_reasoning="",
            treatment_complete=False,
            med_evidence={},
            med_evidence_complete=False,
            advice="",
            advice_reasoning="",
            advice_generator_complete=False,
            patient_friendly_summary="",
            patient_explainer_complete=False,
            safety_passed=False,
            safety_warnings=[],
            safety_modified_output={},
            safety_validator_complete=False,
            final_report="",
            report_generator_complete=False,
            eval_metrics={},
            saved_path="",
            evaluation_saver_complete=False,
            output_base="output",
            output_dir="",
            classification_error="",
            differential_error="",
            treatment_error="",
            error_occurred=False
        )

        # Should raise error since severity assessment not complete
        with pytest.raises(ValueError, match="Severity assessment incomplete"):
            risk_router_node(incomplete_state)

        # State with both complete
        complete_state = incomplete_state.copy()
        complete_state["severity_assessment"] = {
            "severity_level": "Low",
            "risk_score": 0.3,
            "red_flags": ["None"]
        }
        complete_state["severity_assessor_complete"] = True

        # Should work now
        result = risk_router_node(complete_state)
        assert result["risk_router_complete"] is True


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
