# CREDITWISE — AI Loan Eligibility & Risk Scoring (LangGraph + Streamlit)

CPU-only, Python 3.11 workflow using local ML + rules with optional Gemini summaries.

## Setup
```
python -m venv .venv
source .venv/bin/activate  # or .venv\\Scripts\\activate on Windows
pip install -r requirements.txt
```

## Train the model
```
python ml/train_model.py
```
Saves `ml/models/credit_risk_model.pkl`.

## Run the app
```
streamlit run main.py
```

## Data
- Training: `data/training_dataset/creditwise_applicants.csv`
- Products: `data/product_catalog/loan_products.csv`

## Optional Gemini summaries
Set `GEMINI_API_KEY` in `.env` (or environment) to enable customer-friendly explanations. The workflow runs fully offline otherwise.
