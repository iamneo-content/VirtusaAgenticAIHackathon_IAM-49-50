import json
import os
import random
import tempfile
import unittest
from copy import deepcopy
from pathlib import Path
from unittest import mock
import numpy as np
import pandas as pd

import agents.applicant_parser as applicant_parser
import agents.llm_policy_checker as policy_checker
import agents.ml_risk_predictor as risk_predictor
import agents.risk_explainer as risk_explainer
import agents.loan_recommender as loan_recommender
import graph
import ml.train_model as train_model
import ml.evaluate as eval_model
import ml.cleaning as cleaning


class TestPipeline(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        random.seed(42)
        np.random.seed(42)
        cls.tmpdir = tempfile.TemporaryDirectory()

    @classmethod
    def tearDownClass(cls):
        cls.tmpdir.cleanup()

    def setUp(self):
        self.base_applicant = {
            "applicant": {
                "age_years": 32,
                "employment_type": "salaried",
                "industry_sector": "IT",
                "monthly_income": 120000,
                "total_existing_emi": 3000,
                "credit_score": 780,
                "requested_loan_amount": 400000,
                "requested_tenure_months": 36,
                "loan_purpose": "personal",
                "city_tier": 1,
                "guarantor_available": False,
            }
        }

    def test_parse_creates_features_and_ratios(self):
        state = deepcopy(self.base_applicant)
        out = applicant_parser.parse_applicant(state)
        feats = out.get("features", {})
        for key in ["dti_ratio", "loan_to_income_ratio"]:
            with self.subTest(key=key):
                self.assertIn(key, feats, f"{key} should be derived")
        self.assertGreater(feats["dti_ratio"], 0)
        self.assertGreater(feats["loan_to_income_ratio"], 0)

    def test_training_writes_artifact(self):
        # Run cleaning and training with real pipeline, ensure artifact exists
        cleaning.run_cleaning()
        train_model.train()
        model_path = Path("ml/models/credit_risk_model.pkl")
        self.assertTrue(model_path.exists(), "Model artifact should be written")

    def test_prediction_sets_risk(self):
        risk_predictor._MODEL = None  # reset cache
        features_state = {"features": applicant_parser.parse_applicant(deepcopy(self.base_applicant))["features"]}
        # ensure model is trained
        if not Path("ml/models/credit_risk_model.pkl").exists():
            train_model.train()
        out = risk_predictor.predict_risk(features_state)
        self.assertGreaterEqual(out["risk_score"], 0.0)
        self.assertLessEqual(out["risk_score"], 1.0)
        self.assertIn(out["risk_band"], ["Low", "Medium", "High"])

    def test_policy_checker_sets_flags_and_decision(self):
        state = applicant_parser.parse_applicant(deepcopy(self.base_applicant))
        state["features"]["loan_to_income_ratio"] = 0.01  # force LTI_HIGH
        state["risk_score"] = 0.2
        out = policy_checker.check_policy(state)
        self.assertIn("LTI_HIGH", out["policy_flags"])
        self.assertEqual(out["decision"], "Manual Review")

    def test_explainer_with_mocked_gemini(self):
        fake_resp = mock.Mock()
        fake_resp.text = "Canned explanation"
        with mock.patch.dict(os.environ, {"GEMINI_API_KEY": "fake"}), mock.patch(
            "google.generativeai.GenerativeModel.generate_content",
            return_value=fake_resp,
        ), mock.patch(
            "google.generativeai.configure"
        ):
            state = {"risk_score": 0.2, "risk_band": "Low", "decision": "Approve", "policy_flags": []}
            out = risk_explainer.generate_explanation(state)
        self.assertEqual(out["explanation"], "Canned explanation")

    def test_recommender_with_mocked_gemini(self):
        # Build small catalog
        catalog = pd.DataFrame(
            [
                {
                    "product_id": "P1",
                    "product_name": "Loan 1",
                    "category": "personal",
                    "purpose_allowed": "personal",
                    "min_amount": 100000,
                    "max_amount": 500000,
                    "min_tenure_months": 12,
                    "max_tenure_months": 60,
                    "base_apr_percent": 10.0,
                    "risk_spread_low_percent": 0.5,
                    "risk_spread_med_percent": 1.0,
                    "risk_spread_high_percent": 2.0,
                    "processing_fee_percent": 1.0,
                    "max_dti_ratio": 0.5,
                    "min_credit_score": 650,
                },
                {
                    "product_id": "P2",
                    "product_name": "Loan 2",
                    "category": "personal",
                    "purpose_allowed": "personal",
                    "min_amount": 100000,
                    "max_amount": 500000,
                    "min_tenure_months": 12,
                    "max_tenure_months": 60,
                    "base_apr_percent": 11.0,
                    "risk_spread_low_percent": 0.6,
                    "risk_spread_med_percent": 1.1,
                    "risk_spread_high_percent": 2.1,
                    "processing_fee_percent": 0.5,
                    "max_dti_ratio": 0.6,
                    "min_credit_score": 650,
                },
            ]
        )
        fake_resp = mock.Mock()
        fake_resp.text = json.dumps(
            [
                {"product_id": "P2", "reason": "Better fee", "score": 0.9},
                {"product_id": "P1", "reason": "Alt", "score": 0.7},
            ]
        )
        state = {
            "features": {
                "requested_loan_amount": 400000,
                "requested_tenure_months": 36,
                "loan_purpose": "personal",
                "monthly_income": 120000,
                "total_existing_emi": 3000,
                "credit_score": 700,
                "dti_ratio": 0.2,
                "loan_to_income_ratio": 0.009,
            },
            "risk_band": "Low",
            "risk_score": 0.2,
            "errors": [],
        }
        with mock.patch.dict(os.environ, {"GEMINI_API_KEY_2": "fake"}), mock.patch.object(
            loan_recommender.pd, "read_csv", return_value=catalog
        ), mock.patch(
            "google.generativeai.GenerativeModel.generate_content",
            return_value=fake_resp,
        ), mock.patch(
            "google.generativeai.configure"
        ):
            out = loan_recommender.recommend_products(state)
        recs = out.get("recommendations", [])
        self.assertGreater(len(recs), 0, "Recommender should return products")
        self.assertEqual(recs[0]["product_id"], "P2")

    def test_graph_invocation_with_stubs(self):
        # Use real nodes but mock Gemini calls
        fake_resp = mock.Mock()
        fake_resp.text = json.dumps([{"product_id": "PE-101", "reason": "ok", "score": 0.9}])
        with mock.patch.dict(os.environ, {"GEMINI_API_KEY": "fake", "GEMINI_API_KEY_2": "fake"}), \
            mock.patch("google.generativeai.GenerativeModel.generate_content", return_value=fake_resp), \
            mock.patch("google.generativeai.configure"):
            if not Path("ml/models/credit_risk_model.pkl").exists():
                cleaning.run_cleaning()
                train_model.train()
            app = graph.create_app()
            state = app.invoke({"applicant": deepcopy(self.base_applicant["applicant"])})
        self.assertIsInstance(state, dict)
        self.assertIn("risk_score", state)

    def test_evaluate_metrics_with_mock_model(self):
        if not Path("ml/models/credit_risk_model.pkl").exists():
            cleaning.run_cleaning()
            train_model.train()
        metrics = eval_model.evaluate()
        for key in ["roc_auc", "pr_auc", "accuracy@0.5", "precision@0.5", "recall@0.5", "f1@0.5", "confusion_matrix@0.5"]:
            with self.subTest(key=key):
                self.assertIn(key, metrics)

    def _make_fake_training_df(self):
        rows = []
        for i in range(30):
            rows.append(
                {
                    "application_id": f"A{i}",
                    "monthly_income": 100000 + i * 100,
                    "requested_loan_amount": 400000 + i * 1000,
                    "requested_tenure_months": 36,
                    "total_existing_emi": 5000,
                    "credit_score": 700 + (i % 10),
                    "age_years": 30 + (i % 5),
                    "city_tier": 1,
                    "default_flag": 0 if i % 2 == 0 else 1,
                }
            )
        return pd.DataFrame(rows)

    def test_evaluation_with_mocked_predictions(self):
        if not Path("ml/models/credit_risk_model.pkl").exists():
            cleaning.run_cleaning()
            train_model.train()
        metrics = eval_model.evaluate()
        self.assertIn("roc_auc", metrics)
        self.assertIn("pr_auc", metrics)


if __name__ == "__main__":
    unittest.main(verbosity=2)
