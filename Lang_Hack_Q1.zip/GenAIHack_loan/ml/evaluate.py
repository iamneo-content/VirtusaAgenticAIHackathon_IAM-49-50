import pandas as pd, numpy as np, joblib, json
from sklearn.metrics import roc_auc_score, average_precision_score, f1_score, accuracy_score, precision_score, recall_score, confusion_matrix
from pathlib import Path

def evaluate(eval_csv="data/evaluation_dataset/creditwise_eval_holdout.csv", model_path="ml/models/credit_risk_model.pkl"):
    df = pd.read_csv(eval_csv)
    y = df["default_flag"].astype(int)
    X = df[
        [
            "monthly_income",
            "requested_loan_amount",
            "requested_tenure_months",
            "total_existing_emi",
            "credit_score",
            "age_years",
            "city_tier",
        ]
    ].astype(float)
    X["dti_ratio"] = (X["total_existing_emi"] + 0.012 * X["requested_loan_amount"] / (1 - (1 + 0.012) ** (-X["requested_tenure_months"].clip(lower=1)))) / X["monthly_income"].clip(lower=1)
    X["loan_to_income_ratio"] = X["requested_loan_amount"] / (X["monthly_income"] * X["requested_tenure_months"]).clip(lower=1)
    m = joblib.load(model_path)
    p = m.predict_proba(X)[:, 1]
    pred = (p >= 0.5).astype(int)
    metrics = {
        "roc_auc": float(roc_auc_score(y, p)),
        "pr_auc": float(average_precision_score(y, p)),
        "accuracy@0.5": float(accuracy_score(y, pred)),
        "precision@0.5": float(precision_score(y, pred)),
        "recall@0.5": float(recall_score(y, pred)),
        "f1@0.5": float(f1_score(y, pred)),
        "confusion_matrix@0.5": confusion_matrix(y, pred).tolist(),
    }
    od = Path("data/evaluation_dataset")
    od.mkdir(parents=True, exist_ok=True)
    pd.DataFrame({"application_id": df["application_id"], "y_true": y, "y_prob": p, "y_pred": pred}).to_csv(od / "predictions_eval_holdout.csv", index=False)
    (od / "metrics_eval_holdout.json").write_text(json.dumps(metrics, indent=2))
    return metrics

if __name__ == "__main__":
    print(evaluate())
