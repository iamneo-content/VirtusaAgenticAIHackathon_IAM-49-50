import pandas as pd
from pathlib import Path

def run_cleaning():
    src = Path("data/training_dataset/creditwise_applicants.csv")
    dst = Path("data/processed/cleaned_applicants.csv")
    dst.parent.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(src)

    for c in ["employment_type", "loan_purpose", "application_channel", "residence_type"]:
        if c in df:
            df[c] = df[c].astype(str).str.strip().str.lower().replace({"self employed": "self_employed"})

    nums = [
        "age_years",
        "monthly_income",
        "employment_stability_years",
        "active_loans_count",
        "total_existing_emi",
        "credit_score",
        "requested_loan_amount",
        "requested_tenure_months",
        "collateral_value",
        "city_tier",
    ]
    for c in nums:
        if c in df:
            df[c] = pd.to_numeric(df[c], errors="coerce")

    df["application_date"] = pd.to_datetime(df["application_date"], errors="coerce")
    df = df.dropna(subset=["application_date", "age_years", "credit_score", "monthly_income", "requested_tenure_months"])
    df = df[
        (df["age_years"].between(21, 70))
        & (df["credit_score"].between(300, 900))
        & (df["monthly_income"] >= 5000)
        & (df["requested_tenure_months"].between(6, 360))
    ]
    df = df.drop_duplicates(subset=["application_id"], keep="first")
    df.to_csv(dst, index=False)
    print(f"Saved {dst} ({len(df)})")

if __name__ == "__main__":
    run_cleaning()
