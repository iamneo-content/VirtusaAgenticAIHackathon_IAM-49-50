import pandas as pd, joblib
from sklearn.experimental import enable_hist_gradient_boosting  # noqa: F401
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score
from pathlib import Path

def train():
    df = pd.read_csv("data/processed/cleaned_applicants.csv")
    y = df["default_flag"].astype(int)
    X = df[
        [
            "monthly_income",
            "requested_loan_amount",
            "requested_tenure_months",
            "total_existing_emi",
            "credit_score",
            "age_years",
            "city_tier",
        ]
    ].astype(float)
    X["dti_ratio"] = (X["total_existing_emi"] + 0.012 * X["requested_loan_amount"] / (1 - (1 + 0.012) ** (-X["requested_tenure_months"].clip(lower=1)))) / X["monthly_income"].clip(lower=1)
    X["loan_to_income_ratio"] = X["requested_loan_amount"] / (X["monthly_income"] * X["requested_tenure_months"]).clip(lower=1)
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    clf = HistGradientBoostingClassifier(max_depth=6, learning_rate=0.08, max_iter=300, random_state=42)
    clf.fit(Xtr, ytr)
    auc = roc_auc_score(yte, clf.predict_proba(Xte)[:, 1])
    Path("ml/models").mkdir(parents=True, exist_ok=True)
    joblib.dump(clf, "ml/models/credit_risk_model.pkl")
    print(f"AUC={auc:.3f}")

if __name__ == "__main__":
    train()
