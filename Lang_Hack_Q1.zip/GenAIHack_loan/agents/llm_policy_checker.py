"""
Apply numeric policy thresholds.
"""
import json

def check_policy(state, policy_path="config/policy.json"):
    pol = json.load(open(policy_path))
    f = state["features"]
    flags = []
    if f["age_years"] < pol["min_age"]:
        flags.append("AGE_MIN")
    if f["credit_score"] < pol["min_credit_score"]:
        flags.append("CREDIT_MIN")
    if f["dti_ratio"] > pol["max_dti"]:
        flags.append("DTI_MAX")
    if f["loan_to_income_ratio"] > pol["max_lti"]:
        flags.append("LTI_HIGH")
    if f["monthly_income"] < pol["min_income"]:
        flags.append("INCOME_LOW")
    r = state["risk_score"]
    if any(x in flags for x in pol["hard_block_flags"]) or r >= pol["auto_reject_risk"]:
        d = "Reject"
    elif r <= pol["auto_approve_risk"] and not flags:
        d = "Approve"
    else:
        d = "Manual Review"
    state["policy_flags"] = flags
    state["decision"] = d
    return state
