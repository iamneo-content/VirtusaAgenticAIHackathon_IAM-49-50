"""
Recommend products by filtering locally and using Gemini to rank the eligible set.
"""
import os
import json
import re
import pandas as pd
from dotenv import load_dotenv


def recommend_products(state, catalog="data/product_catalog/loan_products.csv", top_k=5):
    load_dotenv()
    f = state["features"]
    state.setdefault("errors", [])
    if state.get("decision") == "Reject":
        state["recommendations"] = []
        return state
    try:
        df = pd.read_csv(catalog)
    except Exception as exc:
        state["errors"].append(f"Catalog load failed: {exc}")
        state["recommendations"] = []
        return state

    required_cols = [
        "min_amount",
        "max_amount",
        "min_tenure_months",
        "max_tenure_months",
        "base_apr_percent",
        "risk_spread_low_percent",
        "risk_spread_med_percent",
        "risk_spread_high_percent",
        "processing_fee_percent",
        "max_dti_ratio",
        "min_credit_score",
        "purpose_allowed",
        "product_id",
        "product_name",
    ]
    missing = [c for c in required_cols if c not in df.columns]
    if missing:
        state["errors"].append(f"Catalog missing columns: {', '.join(missing)}")
        state["recommendations"] = []
        return state

    df["purpose"] = df["purpose_allowed"].astype(str).str.lower()
    amt = float(f["requested_loan_amount"])
    ten = int(f["requested_tenure_months"])
    purpose = f["loan_purpose"]

    elig = df[
        (df["purpose"] == purpose)
        & (df["min_amount"] <= amt)
        & (df["max_amount"] >= amt)
        & (df["min_tenure_months"] <= ten)
        & (df["max_tenure_months"] >= ten)
    ].copy()

    if elig.empty:
        state["recommendations"] = []
        state["errors"].append("No eligible products for the requested amount, tenure, and purpose.")
        return state

    band = state.get("risk_band", "High")
    spread_map = {
        "Low": "risk_spread_low_percent",
        "Medium": "risk_spread_med_percent",
        "High": "risk_spread_high_percent",
    }
    spread_col = spread_map.get(band, "risk_spread_high_percent")
    elig["priced_apr_percent"] = elig["base_apr_percent"] + elig[spread_col].fillna(0)

    api_key = os.getenv("GEMINI_API_KEY_2") or os.getenv("GEMINI_API_KEY")
    if not api_key:
        state["errors"].append("GEMINI_API_KEY_2 or GEMINI_API_KEY is required for product ranking.")
        state["recommendations"] = []
        return state

    def _fallback_rank(df_subset):
        # Compute simple fit score locally if Gemini fails
        monthly_rate = df_subset["priced_apr_percent"] / 12 / 100
        emi = (monthly_rate * amt) / (1 - (1 + monthly_rate) ** (-ten))
        income = max(float(f.get("monthly_income") or 1.0), 1.0)
        new_dti = (float(f.get("total_existing_emi") or 0.0) + emi) / income
        df_subset = df_subset.copy()
        df_subset["emi"] = emi
        df_subset["new_dti"] = new_dti
        denom_apr = max(float(df_subset["priced_apr_percent"].max()), 1e-9)
        denom_fee = max(float(df_subset["processing_fee_percent"].max()), 1e-9)
        df_subset["fit_score"] = (
            (1 - df_subset["priced_apr_percent"] / denom_apr) * 0.4
            + (1 - df_subset["processing_fee_percent"] / denom_fee) * 0.2
            + (1 - df_subset["new_dti"].clip(0, 1)) * 0.4
        )
        cols = [
            "product_id",
            "product_name",
            "category",
            "priced_apr_percent",
            "processing_fee_percent",
            "emi",
            "new_dti",
            "fit_score",
            "promo_tag",
        ]
        return df_subset.sort_values("fit_score", ascending=False).head(top_k)[cols].round(4).to_dict("records")

    try:
        import google.generativeai as genai

        genai.configure(api_key=api_key)
        payload = elig.head(20).to_dict("records")
        applicant_summary = {
            "risk_score": state.get("risk_score"),
            "risk_band": band,
            "dti_ratio": f.get("dti_ratio"),
            "loan_to_income_ratio": f.get("loan_to_income_ratio"),
            "requested_loan_amount": amt,
            "requested_tenure_months": ten,
            "loan_purpose": purpose,
            "credit_score": f.get("credit_score"),
        }
        prompt = (
            "Rank these loan products for the applicant. "
            "Return ONLY a JSON array of objects: [{\"product_id\": str, \"reason\": str, \"score\": float}]. "
            f"Applicant: {json.dumps(applicant_summary)}\n"
            f"Products: {json.dumps(payload)}"
        )
        model = genai.GenerativeModel("gemini-2.0-flash")
        resp = model.generate_content(prompt)
        ranking = []
        if resp and resp.text:
            raw = resp.text
            try:
                ranking = json.loads(raw)
            except Exception:
                # Try to strip code fences and parse again
                cleaned = re.sub(r"^```[a-zA-Z]*\\s*|\\s*```$", "", raw.strip(), flags=re.MULTILINE)
                try:
                    ranking = json.loads(cleaned)
                except Exception:
                    ranking = []

        if not isinstance(ranking, list) or not ranking:
            state["errors"].append("Gemini did not return a valid ranking; using fallback ranking.")
            state["recommendations"] = _fallback_rank(elig)
            return state

        rank_map = {item.get("product_id"): idx for idx, item in enumerate(ranking) if item.get("product_id")}
        reason_map = {item.get("product_id"): item.get("reason") for item in ranking if item.get("product_id")}
        score_map = {item.get("product_id"): item.get("score") for item in ranking if item.get("product_id") is not None}

        elig["rank"] = elig["product_id"].map(rank_map)
        elig = elig[elig["rank"].notna()].sort_values("rank")
        recommendations = []
        for _, row in elig.head(top_k).iterrows():
            pid = row["product_id"]
            rec = row.to_dict()
            rec["gemini_score"] = score_map.get(pid)
            rec["gemini_reason"] = reason_map.get(pid)
            recommendations.append(rec)

        if not recommendations:
            state["errors"].append("Gemini returned no matching product_ids; using fallback ranking.")
            state["recommendations"] = _fallback_rank(elig)
        else:
            state["recommendations"] = recommendations
        return state
    except Exception as exc:
        state["errors"].append(f"Gemini ranking failed: {exc}")
        state["recommendations"] = _fallback_rank(elig)
        return state
