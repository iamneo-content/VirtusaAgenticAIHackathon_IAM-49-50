"""
Parse applicant and derive basic affordability features.
"""

def parse_applicant(state):
    a = state.get("applicant", {})
    income = float(a.get("monthly_income") or 0)
    amt = float(a.get("requested_loan_amount") or 0)
    ten = int(a.get("requested_tenure_months") or 1)
    emi0 = float(a.get("total_existing_emi") or 0)
    cs = int(a.get("credit_score") or 0)
    r = 0.012
    emi_new = (r * amt) / (1 - (1 + r) ** (-max(1, ten)))
    dti = (emi0 + emi_new) / max(1.0, income)
    lti = amt / max(1.0, income * ten)
    state["features"] = {
        "monthly_income": income,
        "requested_loan_amount": amt,
        "requested_tenure_months": ten,
        "total_existing_emi": emi0,
        "credit_score": cs,
        "dti_ratio": float(dti),
        "loan_to_income_ratio": float(lti),
        "age_years": int(a.get("age_years") or 0),
        "employment_type": (a.get("employment_type") or "").lower(),
        "industry_sector": (a.get("industry_sector") or ""),
        "city_tier": int(a.get("city_tier") or 2),
        "loan_purpose": (a.get("loan_purpose") or "").lower(),
        "guarantor_available": bool(a.get("guarantor_available") or False),
    }
    return state
