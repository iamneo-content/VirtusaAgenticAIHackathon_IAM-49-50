"""
Gemini optional explanation.
"""
import os

def generate_explanation(state):
    base = (
        f"Risk={state.get('risk_score',0):.2f} | Band={state.get('risk_band')} | "
        f"Decision={state.get('decision')} | Flags={', '.join(state.get('policy_flags',[])) or 'none'}"
    )
    key = os.getenv("GEMINI_API_KEY")
    if not key:
        state["explanation"] = base
        return state
    try:
        import google.generativeai as genai

        genai.configure(api_key=key)
        out = genai.GenerativeModel("gemini-2.0-flash").generate_content(
            "Write a concise, neutral decision rationale for a loan application based ONLY on: " + base
        )
        state["explanation"] = (out.text or "").strip() or base
    except Exception:
        state["explanation"] = base
    return state
