"""
Predict default probability (risk_score) with saved sklearn pipeline.
"""
import joblib, os, numpy as np

_MODEL = None

def predict_risk(state):
    global _MODEL
    if _MODEL is None:
        path = "ml/models/credit_risk_model.pkl"
        if not os.path.exists(path):
            raise FileNotFoundError("Train model first")
        _MODEL = joblib.load(path)
    f = state["features"]
    cols = [
        "monthly_income",
        "requested_loan_amount",
        "requested_tenure_months",
        "total_existing_emi",
        "credit_score",
        "dti_ratio",
        "loan_to_income_ratio",
        "age_years",
        "city_tier",
    ]
    X = np.array([[f.get(c, 0) for c in cols]], dtype=float)
    p = float(_MODEL.predict_proba(X)[0, 1])
    state["risk_score"] = p
    state["risk_band"] = "Low" if p < 0.25 else "Medium" if p < 0.5 else "High"
    return state
