from agents.applicant_parser import parse_applicant

def parse_applicant_node(state):
    return parse_applicant(state)
