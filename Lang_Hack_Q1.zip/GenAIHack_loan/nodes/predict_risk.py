from agents.ml_risk_predictor import predict_risk

def predict_risk_node(state):
    return predict_risk(state)
