from agents.llm_policy_checker import check_policy

def check_policy_node(state):
    return check_policy(state)
