from agents.loan_recommender import recommend_products

def recommend_products_node(state):
    return recommend_products(state)
