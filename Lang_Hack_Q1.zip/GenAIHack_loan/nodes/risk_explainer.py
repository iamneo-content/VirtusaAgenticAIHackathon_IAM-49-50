from agents.risk_explainer import generate_explanation

def risk_explainer_node(state):
    return generate_explanation(state)
