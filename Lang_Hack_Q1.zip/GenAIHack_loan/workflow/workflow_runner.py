"""
Run the workflow with basic error capture.
"""
from typing import Dict
from graph import app


def run_flow(applicant_dict: Dict) -> Dict:
    return app.invoke({"applicant": applicant_dict})
