from langgraph.graph import StateGraph, END
from state import CreditWiseState
from nodes.parse_applicant import parse_applicant_node
from nodes.predict_risk import predict_risk_node
from nodes.check_policy import check_policy_node
from nodes.risk_explainer import risk_explainer_node
from nodes.recommend_products import recommend_products_node

def create_app():
    g = StateGraph(CreditWiseState)
    g.add_node("parse_applicant", parse_applicant_node)
    g.add_node("predict_risk", predict_risk_node)
    g.add_node("check_policy", check_policy_node)
    g.add_node("risk_explainer", risk_explainer_node)
    g.add_node("recommend_products", recommend_products_node)
    g.set_entry_point("parse_applicant")
    g.add_edge("parse_applicant", "predict_risk")
    g.add_edge("predict_risk", "check_policy")
    g.add_edge("check_policy", "risk_explainer")
    g.add_edge("risk_explainer", "recommend_products")
    g.add_edge("recommend_products", END)
    return g.compile()

app = create_app()
