import streamlit as st, json, os, pandas as pd
from dotenv import load_dotenv
from workflow.workflow_runner import run_flow
from ml.evaluate import evaluate

load_dotenv()
st.set_page_config(page_title="CreditWise", layout="wide")
st.title("CreditWise — AI Loan Eligibility & Risk Scoring")
st.caption("Enter the essentials, review the decision, and inspect model metrics.")

t1, t2, t3 = st.tabs(["Submit Application", "Decision & Offers", "Model Metrics"])

with t1:
    st.subheader("Applicant Details")
    a = {}
    col_a, col_b = st.columns(2)
    with col_a:
        a["applicant_name"] = st.text_input("Applicant Name", placeholder="Jane Doe")
        a["phone_number"] = st.text_input("Phone Number", placeholder="+1 555 123 4567")
        a["age_years"] = st.number_input("Age (years)", min_value=18, max_value=80, value=30, step=1)
        a["employment_type"] = st.selectbox(
            "Employment Type", ["", "salaried", "self_employed", "contract"], help="Primary employment status"
        )
        a["industry_sector"] = st.selectbox(
            "Industry Sector", ["", "IT", "Finance", "Healthcare", "Retail", "Manufacturing"]
        )
        a["city_tier"] = st.selectbox("City Tier", [1, 2, 3], help="1=metro, 2=urban, 3=non-metro")
    with col_b:
        a["monthly_income"] = st.number_input("Monthly Income", min_value=0, max_value=10_000_000, value=0, step=1000)
        a["total_existing_emi"] = st.number_input(
            "Total Existing EMI", min_value=0, max_value=1_000_000, value=0, step=500
        )
        a["credit_score"] = st.number_input("Credit Score", min_value=300, max_value=900, value=700, step=1)
        a["requested_loan_amount"] = st.number_input(
            "Requested Loan Amount", min_value=0, max_value=100_000_000, value=0, step=10000
        )
        a["requested_tenure_months"] = st.number_input(
            "Requested Tenure (months)", min_value=6, max_value=360, value=12, step=1
        )
        a["loan_purpose"] = st.selectbox(
            "Loan Purpose", ["", "personal", "auto", "education", "business", "home"], help="Match product purpose"
        )
        a["guarantor_available"] = st.checkbox("Guarantor Available", False)

    required_keys = [
        "applicant_name",
        "phone_number",
        "age_years",
        "employment_type",
        "industry_sector",
        "monthly_income",
        "total_existing_emi",
        "credit_score",
        "requested_loan_amount",
        "requested_tenure_months",
        "city_tier",
        "loan_purpose",
    ]
    missing = [k for k in required_keys if a.get(k) in ("", None)]
    st.markdown("---")
    if missing:
        st.info("Fill all required fields to enable evaluation.")
    if st.button("Evaluate Application", type="primary", disabled=bool(missing)):
        st.session_state["last"] = run_flow(a)
        st.success("Done. See Decision & Offers tab.")

with t2:
    r = st.session_state.get("last", {})
    if not r:
        st.info("Submit an application first.")
    else:
        c1, c2, c3 = st.columns(3)
        c1.metric("Risk Score", f"{r.get('risk_score', 0):.2f}")
        c2.metric("Risk Band", r.get("risk_band", "-"))
        c3.metric("Decision", r.get("decision", "-"))
        st.write("**Policy Flags:**", ", ".join(r.get("policy_flags", [])) or "none")
        st.write("**Explanation:**", r.get("explanation", ""))
        st.write("**Recommended Products:**")
        recs = r.get("recommendations", [])
        if recs:
            st.table(pd.DataFrame(recs))
        else:
            st.info("No recommendations available.")
        if r.get("errors"):
            st.warning("Errors: " + "; ".join(r.get("errors")))

with t3:
    st.subheader("Model Metrics (Holdout)")
    st.caption("Evaluate the trained model on the evaluation holdout set.")
    col_run, col_status = st.columns([1, 2])
    if col_run.button("Run Evaluation Now", type="primary"):
        st.session_state["metrics"] = evaluate(
            "data/evaluation_dataset/creditwise_eval_holdout.csv", "ml/models/credit_risk_model.pkl"
        )
    metrics = st.session_state.get("metrics")
    if not metrics:
        path = "data/evaluation_dataset/metrics_eval_holdout.json"
        if os.path.exists(path):
            metrics = json.loads(open(path).read())
    if not metrics:
        st.info("Click 'Run Evaluation Now' to compute and display metrics.")
    else:
        st.success("Latest evaluation loaded.")
        top, bottom = st.columns([2, 1])
        with top:
            summary_rows = [
                ("ROC AUC", metrics.get("roc_auc", 0.0)),
                ("PR AUC", metrics.get("pr_auc", 0.0)),
                ("Accuracy @0.5", metrics.get("accuracy@0.5", 0.0)),
                ("Precision @0.5", metrics.get("precision@0.5", 0.0)),
                ("Recall @0.5", metrics.get("recall@0.5", 0.0)),
                ("F1 @0.5", metrics.get("f1@0.5", 0.0)),
            ]
            st.table(pd.DataFrame(summary_rows, columns=["Metric", "Value"]).style.format({"Value": "{:.3f}"}))
        with bottom:
            st.write("Confusion Matrix @0.5")
            cm = metrics.get("confusion_matrix@0.5", [[0, 0], [0, 0]])
            st.table(pd.DataFrame(cm, index=["True 0", "True 1"], columns=["Pred 0", "Pred 1"]))
