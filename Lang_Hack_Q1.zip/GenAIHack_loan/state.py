from typing import TypedDict, List, Dict, Any


class CreditWiseState(TypedDict, total=False):
    applicant: Dict[str, Any]
    features: Dict[str, Any]
    risk_score: float
    risk_band: str
    decision: str
    policy_flags: List[str]
    explanation: str
    recommendations: List[Dict[str, Any]]
