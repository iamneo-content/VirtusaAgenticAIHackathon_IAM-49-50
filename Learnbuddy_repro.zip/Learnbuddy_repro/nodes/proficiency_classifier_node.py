"""Proficiency Classifier Node - Classify learner proficiency level"""

from state import LearnerPlanState
from agents.proficiency_assessor_llm import ProficiencyAssessorLLMAgent


def proficiency_classifier_node(state: LearnerPlanState) -> dict:
    """
    Classify learner into proficiency level based on analyzed profile.

    Reads from state: analyzed_profile
    Writes to state: learner_proficiency_level, proficiency_confidence

    Args:
        state: Current LearnerPlanState

    Returns:
        Dictionary with proficiency classification results
    """
    try:
        analyzed_profile = state.get("analyzed_profile", {})

        classifier = ProficiencyAssessorLLMAgent()
        level, confidence = classifier.assess_proficiency(analyzed_profile)

        return {
            "learner_proficiency_level": level,
            "proficiency_confidence": confidence,
        }

    except Exception as e:
        # Update error_messages via Annotated add operator
        return {
            "learner_proficiency_level": "Intermediate",
            "proficiency_confidence": 0.0,
            "error_messages": [f"Proficiency classification failed: {str(e)}"],
        }
