"""Beginner Plan Generator Node - Generate beginner-focused learning plan"""

from state import LearnerPlanState
from agents.beginner_plan_generator_llm import BeginnerPlanGeneratorLLMAgent


def beginner_plan_generator_node(state: LearnerPlanState) -> dict:
    """
    Generate beginner-focused personalized learning plan via LLM.

    Reads from state: analyzed_profile
    Writes to state: generated_plan

    Args:
        state: Current LearnerPlanState

    Returns:
        Dictionary with generated beginner plan
    """
    try:
        analyzed_profile = state.get("analyzed_profile", {})

        generator = BeginnerPlanGeneratorLLMAgent()
        plan = generator.create_beginner_plan(analyzed_profile)

        return {
            "generated_plan": plan,
        }

    except Exception as e:
        return {
            "generated_plan": {},
            "error_messages": [f"Beginner plan generation failed: {str(e)}"],
        }
