#!/usr/bin/env python3
"""Profile Analyzer Node - Extracts metrics and ML features from parsed profile"""

from state import LearnerPlanState
from agents.profile_analyzer import ProfileAnalyzerAgent


def profile_analyzer_node(state: LearnerPlanState) -> dict:
    """Extract metrics and ML features from parsed profile"""
    try:
        analyzer = ProfileAnalyzerAgent()
        analyzed = analyzer.extract_metrics(state["parsed_learner"])

        return {"analyzed_profile": analyzed}

    except Exception as e:
        return {
            "error_messages": [f"Analyzer error: {str(e)}"],
        }
