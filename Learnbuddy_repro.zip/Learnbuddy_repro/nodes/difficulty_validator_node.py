"""Difficulty Validator Node - Validate plan difficulty alignment"""

from state import LearnerPlanState
from agents.difficulty_alignment_llm import DifficultyAlignmentLLMAgent


def difficulty_validator_node(state: LearnerPlanState) -> dict:
    """
    Validate if plan difficulty aligns with learner's proficiency level.

    Reads from state: generated_plan, learner_proficiency_level
    Writes to state: difficulty_validation_passed, difficulty_validation_issues

    Args:
        state: Current LearnerPlanState

    Returns:
        Dictionary with difficulty validation results
    """
    try:
        plan = state.get("generated_plan", {})
        proficiency_level = state.get("learner_proficiency_level", "Intermediate")

        validator = DifficultyAlignmentLLMAgent()
        passed, issues = validator.validate_alignment(plan, proficiency_level)

        return {
            "difficulty_validation_passed": passed,
            "difficulty_validation_issues": issues,
        }

    except Exception as e:
        # For parallel validators, don't update error_occurred - just log the issue
        return {
            "difficulty_validation_passed": False,
            "difficulty_validation_issues": [f"Validation error: {str(e)}"],
        }
