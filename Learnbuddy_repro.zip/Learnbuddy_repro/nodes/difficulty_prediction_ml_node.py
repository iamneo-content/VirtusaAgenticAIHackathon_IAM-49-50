#!/usr/bin/env python3
"""Difficulty Prediction ML Node - Predicts optimal difficulty using trained ML model"""

from state import LearnerPlanState
from agents.difficulty_prediction_ml import DifficultyPredictionMLAgent


def difficulty_prediction_ml_node(state: LearnerPlanState) -> dict:
    """Predict optimal difficulty level using trained RandomForest classifier"""
    try:
        agent = DifficultyPredictionMLAgent()
        difficulty, confidence = agent.predict_difficulty(state["analyzed_profile"])

        return {
            "recommended_difficulty": difficulty,
            "difficulty_confidence": confidence,
        }
    except Exception as e:
        return {
            "error_messages": [f"Difficulty Prediction Error: {str(e)}"],
        }
