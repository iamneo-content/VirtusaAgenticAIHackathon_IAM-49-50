"""Personal Coach Node - Personalizes learning plan with adaptive coaching tone"""

from state import LearnerPlanState
from agents.coach_rewriter_llm import CoachRewriterLLMAgent


def personal_coach_node(state: LearnerPlanState) -> dict:
    """
    Personalize single learning plan with adaptive coaching tone (Phase 2).

    Reads from state: generated_plan, analyzed_profile
    Writes to state: plan_friendly

    Args:
        state: Current LearnerPlanState

    Returns:
        Dictionary with personalized coaching text for single plan
    """
    try:
        plan = state.get("generated_plan", {})
        analyzed_profile = state.get("analyzed_profile", {})

        agent = CoachRewriterLLMAgent()
        plan_friendly = agent.generate_coaching_guidance(plan, analyzed_profile)

        return {
            "plan_friendly": plan_friendly,
        }

    except Exception as e:
        return {
            "error_occurred": True,
            "error_messages": state.get("error_messages", []) + [
                f"Personal coach error: {str(e)}"
            ],
        }
