#!/usr/bin/env python3
"""Gap Detection ML Node - Hybrid ML + LLM gap detection"""

from state import LearnerPlanState
from agents import GapDetectionMLAgent, GapSynthesizerLLMAgent


def gap_detection_ml_node(state: LearnerPlanState) -> dict:
    """
    Gap Detection Node - Hybrid ML + LLM approach for intelligent gap detection.

    HYBRID APPROACH:
    1. ML Model: Generates top-3 gap predictions with confidence scores
    2. LLM Agent: Synthesizes intelligent gap analysis using ML predictions + learner context
    3. Result: Multiple gaps identified with reasoning

    Reads from state: analyzed_profile
    Writes to state: gap_confidence_scores, gap_urgency_level, identified_gaps, gap_analysis

    Args:
        state: Current LearnerPlanState

    Returns:
        Dictionary with hybrid gap detection results
    """
    try:
        analyzed_profile = state.get("analyzed_profile", {})

        # STEP 1: ML Model generates top-3 predictions
        gap_ml_agent = GapDetectionMLAgent()
        top_3_gaps, confidence_scores, urgency = gap_ml_agent.detect_gaps(analyzed_profile)

        # STEP 2: LLM synthesizes intelligent gap analysis
        ml_predictions = {
            "top_gaps": top_3_gaps,
            "confidence_scores": confidence_scores,
            "urgency_level": urgency,
        }

        gap_llm_agent = GapSynthesizerLLMAgent()
        synthesized_gaps, gap_reasoning = gap_llm_agent.synthesize_gaps(
            analyzed_profile=analyzed_profile,
            ml_predictions=ml_predictions
        )

        return {
            "identified_gaps": synthesized_gaps,
            "gap_confidence_scores": confidence_scores,
            "gap_urgency_level": urgency,
        }
    except Exception as e:
        return {
            "error_occurred": True,
            "error_messages": [f"Gap Detection Error: {str(e)}"],
        }
