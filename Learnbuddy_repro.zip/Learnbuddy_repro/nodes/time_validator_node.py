"""Time Validator Node - Validate plan time feasibility"""

from state import LearnerPlanState
from agents.time_feasibility_llm import TimeFeasibilityLLMAgent


def time_validator_node(state: LearnerPlanState) -> dict:
    """
    Validate if learning plan is time-feasible for learner.

    Reads from state: generated_plan, analyzed_profile
    Writes to state: time_validation_passed, time_validation_issues

    Args:
        state: Current LearnerPlanState

    Returns:
        Dictionary with time validation results
    """
    try:
        plan = state.get("generated_plan", {})
        analyzed_profile = state.get("analyzed_profile", {})
        constraints = analyzed_profile.get("constraints_analysis", {})

        validator = TimeFeasibilityLLMAgent()
        passed, issues = validator.validate_timeline(plan, constraints)

        return {
            "time_validation_passed": passed,
            "time_validation_issues": issues,
        }

    except Exception as e:
        # For parallel validators, don't update error_occurred - just log the issue
        return {
            "time_validation_passed": False,
            "time_validation_issues": [f"Validation error: {str(e)}"],
        }
