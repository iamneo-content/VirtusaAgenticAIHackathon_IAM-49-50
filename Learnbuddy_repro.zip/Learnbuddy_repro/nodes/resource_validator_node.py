"""Resource Validator Node - Validate plan budget feasibility"""

from state import LearnerPlanState
from agents.budget_feasibility_llm import BudgetFeasibilityLLMAgent


def resource_validator_node(state: LearnerPlanState) -> dict:
    """
    Validate if learning plan cost is within learner's budget.

    Reads from state: generated_plan, analyzed_profile
    Writes to state: resource_validation_passed, resource_validation_issues

    Args:
        state: Current LearnerPlanState

    Returns:
        Dictionary with resource/budget validation results
    """
    try:
        plan = state.get("generated_plan", {})
        analyzed_profile = state.get("analyzed_profile", {})
        budget_limit = analyzed_profile.get("constraints_analysis", {}).get("budget_usd", 500)

        validator = BudgetFeasibilityLLMAgent()
        passed, issues = validator.validate_budget(plan, budget_limit)

        return {
            "resource_validation_passed": passed,
            "resource_validation_issues": issues,
        }

    except Exception as e:
        # For parallel validators, don't update error_occurred - just log the issue
        return {
            "resource_validation_passed": False,
            "resource_validation_issues": [f"Validation error: {str(e)}"],
        }
