"""Standard Plan Generator Node - Generate standard/intermediate learning plan"""

from state import LearnerPlanState
from agents.standard_plan_generator_llm import StandardPlanGeneratorLLMAgent


def standard_plan_generator_node(state: LearnerPlanState) -> dict:
    """
    Generate standard/intermediate personalized learning plan via LLM.

    Reads from state: analyzed_profile
    Writes to state: generated_plan

    Args:
        state: Current LearnerPlanState

    Returns:
        Dictionary with generated standard plan
    """
    try:
        analyzed_profile = state.get("analyzed_profile", {})

        generator = StandardPlanGeneratorLLMAgent()
        plan = generator.create_standard_plan(analyzed_profile)

        return {
            "generated_plan": plan,
        }

    except Exception as e:
        # Update error_messages via Annotated add operator
        return {
            "generated_plan": {},
            "error_messages": [f"Standard plan generation failed: {str(e)}"],
        }
