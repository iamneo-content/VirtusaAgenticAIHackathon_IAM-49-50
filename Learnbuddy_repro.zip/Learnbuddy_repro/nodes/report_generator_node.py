"""Report Generator Node - Generates final learning plan report and saves output"""

import json
from pathlib import Path
from datetime import datetime
from state import LearnerPlanState
from utils import create_output_directory, save_file


def report_generator_node(state: LearnerPlanState) -> dict:
    """
    Generate and save final learning plan report with validation results (Phase 2).

    Reads from state: All major fields (plan, analysis, coaching, validation)
    Writes to state: report_json, saved_path, output_dir

    Args:
        state: Current LearnerPlanState

    Returns:
        Dictionary with report JSON, saved path, and output directory
    """
    try:
        output_dir = create_output_directory(state["learner_id"])

        # Build comprehensive Phase 2 report
        report_json = {
            "metadata": {
                "generated_at": datetime.now().isoformat(),
                "version": "3.0",
                "workflow": "Phase2_SinglePlanWithValidation"
            },
            "learner_id": state["learner_id"],
            "proficiency": {
                "level": state.get("learner_proficiency_level", "Unknown"),
                "confidence": state.get("proficiency_confidence", 0.0),
            },
            "analysis": {
                "gaps": state.get("identified_gaps", []),
                "gap_urgency": state.get("gap_urgency_level", "Unknown"),
                "recommended_difficulty": state.get("recommended_difficulty", ""),
                "difficulty_confidence": state.get("difficulty_confidence", 0.0),
            },
            "selected_plan": state.get("generated_plan", {}),
            "validation_results": {
                "time": {
                    "passed": state.get("time_validation_passed", False),
                    "issues": state.get("time_validation_issues", []),
                },
                "difficulty": {
                    "passed": state.get("difficulty_validation_passed", False),
                    "issues": state.get("difficulty_validation_issues", []),
                },
                "resource": {
                    "passed": state.get("resource_validation_passed", False),
                    "issues": state.get("resource_validation_issues", []),
                },
            },
            "coaching_guidance": state.get("plan_friendly", ""),
        }

        report_path = Path(output_dir) / "learning_plan.json"
        save_file(str(report_path), json.dumps(report_json, indent=2))

        return {
            "report_json": report_json,
            "saved_path": str(report_path),
            "output_dir": output_dir,
        }

    except Exception as e:
        return {
            "error_messages": [
                f"Report generation error: {str(e)}"
            ],
        }
