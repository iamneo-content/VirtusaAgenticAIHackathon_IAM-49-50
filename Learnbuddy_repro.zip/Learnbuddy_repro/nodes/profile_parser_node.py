#!/usr/bin/env python3
"""Profile Parser Node - Validates and normalizes learner JSON input"""

from state import LearnerPlanState
from agents.profile_parser import ProfileParserAgent


def profile_parser_node(state: LearnerPlanState) -> dict:
    """Validate and normalize learner profile (20-field schema)"""
    try:
        parser = ProfileParserAgent()
        normalized, is_valid, errors = parser.validate_profile(state["learner_json"])

        if not is_valid:
            return {
                "validation_errors": errors,
                "error_occurred": True,
                "error_messages": state["error_messages"] + errors,
            }

        return {"parsed_learner": normalized}

    except Exception as e:
        return {
            "error_messages": [f"Parser error: {str(e)}"],
        }
