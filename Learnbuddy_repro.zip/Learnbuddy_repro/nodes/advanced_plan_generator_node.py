"""Advanced Plan Generator Node - Generate advanced/expert learning plan"""

from state import LearnerPlanState
from agents.advanced_plan_generator_llm import AdvancedPlanGeneratorLLMAgent


def advanced_plan_generator_node(state: LearnerPlanState) -> dict:
    """
    Generate advanced/expert personalized learning plan via LLM.

    Reads from state: analyzed_profile
    Writes to state: generated_plan

    Args:
        state: Current LearnerPlanState

    Returns:
        Dictionary with generated advanced plan
    """
    try:
        analyzed_profile = state.get("analyzed_profile", {})

        generator = AdvancedPlanGeneratorLLMAgent()
        plan = generator.create_advanced_plan(analyzed_profile)

        return {
            "generated_plan": plan,
        }

    except Exception as e:
        # Update error_messages via Annotated add operator
        return {
            "generated_plan": {},
            "error_messages": [f"Advanced plan generation failed: {str(e)}"],
        }
