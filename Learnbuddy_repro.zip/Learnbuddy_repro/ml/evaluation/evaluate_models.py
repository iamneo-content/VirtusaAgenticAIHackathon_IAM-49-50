#!/usr/bin/env python3
"""
Evaluate simplified ML models (Logistic Regression) on evaluation datasets
Phase 2: Models use pre-extracted numeric features (10 for gap, 8 for difficulty)
Evaluation data is in CSV format with features already extracted
"""

from typing import Dict, Any
import pickle
import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime
from sklearn.metrics import accuracy_score
import json
import warnings
warnings.filterwarnings('ignore')


def evaluate_gap_detection_model(model_dir: str = "ml/models", eval_data_path: str = "data/evaluation_dataset/gap_eval.csv") -> dict:
    """
    Evaluate Gap Detection Logistic Regression model on evaluation dataset.
    Uses 10 pre-extracted numeric features (simplified Phase 1 model).

    Args:
        model_dir: Directory containing trained model artifacts
        eval_data_path: Path to evaluation CSV dataset

    Returns:
        dict with evaluation metrics
    """
    try:
        model_path = Path(model_dir) / "gap_model.pkl"
        scaler_path = Path(model_dir) / "gap_scaler.pkl"

        if not model_path.exists() or not scaler_path.exists():
            return {"error": "Gap detection model artifacts not found"}

        # Load model and scaler
        with open(model_path, "rb") as f:
            model = pickle.load(f)
        with open(scaler_path, "rb") as f:
            scaler = pickle.load(f)

        # Load evaluation data
        eval_data_path = Path(eval_data_path)
        if not eval_data_path.exists():
            return {"error": f"Evaluation file not found: {eval_data_path}"}

        # Read CSV file
        eval_df = pd.read_csv(eval_data_path)
        if eval_df.empty:
            return {"error": "Evaluation dataset is empty"}

        # Feature columns (first 10) and target column (last one: primary_gap)
        feature_cols = eval_df.columns[:-1].tolist()  # All except last
        target_col = eval_df.columns[-1]  # Last column is target

        if len(feature_cols) != 10:
            return {"error": f"Expected 10 feature columns, got {len(feature_cols)}"}

        # Extract features and targets
        X = eval_df[feature_cols].values.astype(np.float32)
        y = eval_df[target_col].values

        # Scale features
        X_scaled = scaler.transform(X)

        # Make predictions
        y_pred = model.predict(X_scaled)

        # Get class distribution
        try:
            classes = model.classes_.tolist()
        except:
            classes = sorted(set(y) | set(y_pred))

        # Calculate accuracy
        accuracy = accuracy_score(y, y_pred)

        return {
            "model": "gap_detection",
            "type": str(type(model).__name__),
            "status": "trained",
            "accuracy": float(accuracy),
            "samples": len(eval_df),
            "features": 10,
            "classes": classes,
            "target_column": target_col,
            "evaluated_at": datetime.now().isoformat()
        }

    except Exception as e:
        return {"error": str(e), "model": "gap_detection"}


def evaluate_difficulty_prediction_model(model_dir: str = "ml/models", eval_data_path: str = "data/evaluation_dataset/difficulty_eval.csv") -> dict:
    """
    Evaluate Difficulty Prediction Logistic Regression model on evaluation dataset.
    Uses 8 numeric features (with categorical encoding for learning_pace and education_level).

    Args:
        model_dir: Directory containing trained model artifacts
        eval_data_path: Path to evaluation CSV dataset

    Returns:
        dict with evaluation metrics
    """
    try:
        model_path = Path(model_dir) / "difficulty_model.pkl"
        scaler_path = Path(model_dir) / "difficulty_scaler.pkl"

        if not model_path.exists() or not scaler_path.exists():
            return {"error": "Difficulty prediction model artifacts not found"}

        # Load model and scaler
        with open(model_path, "rb") as f:
            model = pickle.load(f)
        with open(scaler_path, "rb") as f:
            scaler = pickle.load(f)

        # Load evaluation data
        eval_data_path = Path(eval_data_path)
        if not eval_data_path.exists():
            return {"error": f"Evaluation file not found: {eval_data_path}"}

        # Read CSV file
        eval_df = pd.read_csv(eval_data_path)
        if eval_df.empty:
            return {"error": "Evaluation dataset is empty"}

        # Feature columns (first 8) and target column (last one: recommended_difficulty_level)
        feature_cols = eval_df.columns[:-1].tolist()  # All except last
        target_col = eval_df.columns[-1]  # Last column is target

        if len(feature_cols) != 8:
            return {"error": f"Expected 8 feature columns, got {len(feature_cols)}"}

        # Extract and prepare features (with categorical encoding)
        X_list = []
        for idx, row in eval_df.iterrows():
            # Numeric columns: indices 0, 1, 4, 5, 6, 7
            feature_vals = [
                float(row["current_proficiency_score"]),  # 0
                float(row["avg_course_score"]),           # 1
                # Categories need encoding
                float({
                    "slow": 0,
                    "moderate": 1,
                    "fast": 2,
                }.get(str(row["learning_pace"]).lower(), 1)),  # 2
                float({
                    "primary": 0,
                    "secondary": 1,
                    "bachelor": 2,
                    "master": 3,
                    "phd": 4,
                }.get(str(row["education_level"]).lower(), 1)),  # 3
                float(row["hours_available_per_week"]),  # 4
                float(row["total_courses_completed"]),   # 5
                float(row["learning_consistency"]),       # 6
                float(row["goal_alignment"]),             # 7
            ]
            X_list.append(feature_vals)

        X = np.array(X_list, dtype=np.float32)
        y = eval_df[target_col].values

        # Scale features
        X_scaled = scaler.transform(X)

        # Make predictions
        y_pred = model.predict(X_scaled)

        # Get class distribution
        try:
            classes = model.classes_.tolist()
        except:
            classes = sorted(set(y) | set(y_pred))

        # Calculate accuracy
        accuracy = accuracy_score(y, y_pred)

        return {
            "model": "difficulty_prediction",
            "type": str(type(model).__name__),
            "status": "trained",
            "accuracy": float(accuracy),
            "samples": len(eval_df),
            "features": 8,
            "classes": classes,
            "target_column": target_col,
            "evaluated_at": datetime.now().isoformat()
        }

    except Exception as e:
        return {"error": str(e), "model": "difficulty_prediction"}


def evaluate_all_models(model_dir: str = "ml/models", eval_data_dir: str = "data/evaluation_dataset") -> dict:
    """
    Evaluate all trained ML models on evaluation datasets.

    Args:
        model_dir: Directory containing trained model artifacts
        eval_data_dir: Directory containing evaluation CSV datasets

    Returns:
        dict with evaluation results for all models
    """
    gap_eval_path = Path(eval_data_dir) / "gap_eval.csv"
    difficulty_eval_path = Path(eval_data_dir) / "difficulty_eval.csv"

    gap_eval = evaluate_gap_detection_model(model_dir, str(gap_eval_path))
    difficulty_eval = evaluate_difficulty_prediction_model(model_dir, str(difficulty_eval_path))

    return {
        "timestamp": datetime.now().isoformat(),
        "gap_evaluation": gap_eval,
        "difficulty_evaluation": difficulty_eval
    }


if __name__ == "__main__":
    results = evaluate_all_models()
    print(json.dumps(results, indent=2, default=str))
