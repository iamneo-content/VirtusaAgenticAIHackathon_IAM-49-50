"""
Simplify gap detection training data cleaning
Select 10 numeric columns + target, handle missing values
"""

import pandas as pd
from pathlib import Path


def clean_gap_data():
    """Clean gap detection training data for simplified model."""

    print("\n" + "="*70)
    print("CLEANING GAP DETECTION TRAINING DATA")
    print("="*70)

    # Load raw training data
    input_path = Path("data/training_dataset/gap_training.csv")
    output_path = Path("data/processed/gap_cleaned.csv")

    print(f"\n[1/4] Loading training data from {input_path}...")
    df = pd.read_csv(input_path)
    print(f"  ✓ Loaded {len(df)} rows")

    # Required 10 numeric feature columns
    numeric_cols = [
        'current_proficiency_score',
        'avg_completion_rate',
        'avg_course_score',
        'course_dropout_rate',
        'total_courses_completed',
        'concept_understanding_score',
        'practical_application_score',
        'problem_solving_ability',
        'goal_clarity_score',
        'motivation_level',
    ]

    # Target column
    target_col = 'primary_gap'

    # Check for required columns
    print("\n[2/4] Selecting required columns...")
    available_cols = [col for col in numeric_cols if col in df.columns]
    print(f"  ✓ Available columns: {len(available_cols)}/{len(numeric_cols)}")

    if target_col not in df.columns:
        print(f"  ✗ ERROR: Target column '{target_col}' not found!")
        print(f"  Available columns: {list(df.columns)}")
        return False

    # Select columns
    cols_to_keep = available_cols + [target_col]
    df = df[cols_to_keep].copy()

    print(f"  ✓ Shape before cleaning: {df.shape}")

    # Handle missing values
    print("\n[3/4] Handling missing values and out-of-range data...")

    # For numeric columns: fill with mean
    for col in available_cols:
        missing_count = df[col].isna().sum()
        if missing_count > 0:
            mean_val = df[col].mean()
            if pd.isna(mean_val):
                mean_val = 0
            df[col] = df[col].fillna(mean_val)
            print(f"  ✓ {col}: {missing_count} missing filled")

    # For target: drop rows with missing values
    missing_target = df[target_col].isna().sum()
    if missing_target > 0:
        df = df.dropna(subset=[target_col])
        print(f"  ✓ Dropped {missing_target} rows with missing target")

    # Remove out-of-range values (noisy rows)
    # Valid ranges: 0-100 for most scores, 0-50 for courses
    initial_count = len(df)

    for col in available_cols:
        if col == 'total_courses_completed':
            df = df[(df[col] >= 0) & (df[col] <= 50)]
        else:
            df = df[(df[col] >= 0) & (df[col] <= 100)]

    removed_count = initial_count - len(df)
    if removed_count > 0:
        print(f"  ✓ Removed {removed_count} rows with out-of-range values (NOISE)")

    # Remove any remaining NaN rows
    df = df.dropna()
    print(f"  ✓ Final shape after cleaning: {df.shape}")

    # Save cleaned data
    print(f"\n[4/4] Saving cleaned data to {output_path}...")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(output_path, index=False)
    print(f"  ✓ Saved {len(df)} rows")

    print("\n" + "="*70)
    print("CLEANING COMPLETE")
    print("="*70)
    return True


if __name__ == "__main__":
    success = clean_gap_data()
    if not success:
        print("ERROR: Failed to clean gap data")
        exit(1)
