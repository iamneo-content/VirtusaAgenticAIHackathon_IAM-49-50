"""
Simplify difficulty prediction training data cleaning
Select 8 numeric columns + target, with categorical mapping
"""

import pandas as pd
from pathlib import Path


def clean_difficulty_data():
    """Clean difficulty prediction training data for simplified model."""

    print("\n" + "="*70)
    print("CLEANING DIFFICULTY PREDICTION TRAINING DATA")
    print("="*70)

    # Load raw training data
    input_path = Path("data/training_dataset/difficulty_training.csv")
    output_path = Path("data/processed/difficulty_cleaned.csv")

    print(f"\n[1/5] Loading training data from {input_path}...")
    df = pd.read_csv(input_path)
    print(f"  ✓ Loaded {len(df)} rows")

    # Required 8 numeric feature columns
    numeric_cols = [
        'current_proficiency_score',
        'avg_course_score',
        'hours_available_per_week',
        'total_courses_completed',
    ]

    # Categorical columns to encode
    categorical_cols = {
        'learning_pace': {'slow': 0, 'moderate': 1, 'fast': 2},
        'education_level': {'primary': 0, 'secondary': 1, 'bachelor': 2, 'master': 3, 'phd': 4},
    }

    # Additional numeric features to compute
    derived_cols = [
        'learning_consistency',
        'goal_alignment',
    ]

    # Target column
    target_col = 'recommended_difficulty_level'

    # Check for required columns
    print("\n[2/5] Selecting and preparing columns...")
    available_numeric = [col for col in numeric_cols if col in df.columns]
    print(f"  ✓ Numeric columns available: {len(available_numeric)}/{len(numeric_cols)}")

    if target_col not in df.columns:
        print(f"  ✗ ERROR: Target column '{target_col}' not found!")
        print(f"  Available columns: {list(df.columns)}")
        return False

    # Start with available numeric columns
    cols_to_keep = available_numeric.copy()

    # Encode categorical columns
    print("\n[3/5] Encoding categorical features...")
    for cat_col, mapping in categorical_cols.items():
        if cat_col in df.columns:
            new_col_name = f"{cat_col}_numeric"
            df[new_col_name] = df[cat_col].map(mapping).fillna(1)  # Default to moderate/secondary
            cols_to_keep.append(new_col_name)
            print(f"  ✓ {cat_col} → {new_col_name}")
        else:
            print(f"  ⚠ {cat_col} not found, creating default column")
            df[f"{cat_col}_numeric"] = 1  # Default value
            cols_to_keep.append(f"{cat_col}_numeric")

    # Compute derived columns
    print("\n[4/5] Computing derived features...")
    if 'avg_completion_rate' in df.columns:
        df['learning_consistency'] = df['avg_completion_rate'].clip(0, 100) / 100.0
        cols_to_keep.append('learning_consistency')
    else:
        df['learning_consistency'] = 0.5
        cols_to_keep.append('learning_consistency')

    # Goal alignment: simple derived score
    if 'current_proficiency_score' in df.columns:
        df['goal_alignment'] = (df['current_proficiency_score'].clip(0, 100) + 50) / 200.0
        cols_to_keep.append('goal_alignment')
    else:
        df['goal_alignment'] = 0.5
        cols_to_keep.append('goal_alignment')

    # Select final columns plus target
    final_cols = cols_to_keep + [target_col]
    df = df[final_cols].copy()

    print(f"  ✓ Final columns: {len(df.columns)}")

    # Handle missing values
    print("\n[5/5] Handling missing values and out-of-range data...")

    # Fill numeric columns with mean
    for col in [c for c in df.columns if c != target_col]:
        missing_count = df[col].isna().sum()
        if missing_count > 0:
            mean_val = df[col].mean()
            if pd.isna(mean_val):
                mean_val = 0
            df[col] = df[col].fillna(mean_val)
            print(f"  ✓ {col}: {missing_count} missing filled")

    # Drop rows with missing target
    missing_target = df[target_col].isna().sum()
    if missing_target > 0:
        df = df.dropna(subset=[target_col])
        print(f"  ✓ Dropped {missing_target} rows with missing target")

    # Remove out-of-range values (noisy rows)
    initial_count = len(df)

    # Valid ranges for numeric columns
    df = df[(df['current_proficiency_score'] >= 0) & (df['current_proficiency_score'] <= 100)]
    df = df[(df['avg_course_score'] >= 0) & (df['avg_course_score'] <= 100)]
    df = df[(df['hours_available_per_week'] >= 5) & (df['hours_available_per_week'] <= 70)]
    df = df[(df['total_courses_completed'] >= 0) & (df['total_courses_completed'] <= 50)]
    df = df[(df['learning_consistency'] >= 0) & (df['learning_consistency'] <= 1)]
    df = df[(df['goal_alignment'] >= 0) & (df['goal_alignment'] <= 1)]

    # Remove invalid categorical values
    df = df[df['learning_pace_numeric'].notna()]
    df = df[df['education_level_numeric'].notna()]

    removed_count = initial_count - len(df)
    if removed_count > 0:
        print(f"  ✓ Removed {removed_count} rows with out-of-range values (NOISE)")

    # Remove any remaining NaN rows
    df = df.dropna()
    print(f"  ✓ Final shape: {df.shape}")

    # Save cleaned data
    print(f"\nSaving cleaned data to {output_path}...")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(output_path, index=False)
    print(f"  ✓ Saved {len(df)} rows")

    print("\n" + "="*70)
    print("CLEANING COMPLETE")
    print("="*70)
    return True


if __name__ == "__main__":
    success = clean_difficulty_data()
    if not success:
        print("ERROR: Failed to clean difficulty data")
        exit(1)
