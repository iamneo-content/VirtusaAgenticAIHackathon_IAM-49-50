"""
Train Difficulty Prediction Model (Logistic Regression)
Uses 8 simplified numeric features (including categorical encoding).
Saves only 2 artifacts: model + scaler
"""

import pandas as pd
import numpy as np
import pickle
from pathlib import Path
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report
import warnings

warnings.filterwarnings('ignore')


def train_difficulty_prediction_model(train_df, data_dir="data", model_save_dir="ml/models"):
    """Train difficulty prediction model using Logistic Regression (8 features)."""

    print("\n" + "="*70)
    print("TRAINING DIFFICULTY PREDICTION MODEL (Logistic Regression - 8 features)")
    print("="*70)

    # Load evaluation data
    eval_path = Path(data_dir) / "evaluation_dataset" / "difficulty_eval.csv"
    eval_df = pd.read_csv(eval_path)

    # Categorical mappings for evaluation data
    education_level_mapping = {'primary': 0, 'secondary': 1, 'bachelor': 2, 'master': 3, 'phd': 4}
    learning_pace_mapping = {'slow': 0, 'moderate': 1, 'fast': 2}

    eval_df_copy = eval_df.copy()

    if 'education_level' in eval_df_copy.columns:
        eval_df_copy['education_level_numeric'] = eval_df_copy['education_level'].map(education_level_mapping).fillna(1)
    else:
        eval_df_copy['education_level_numeric'] = 1

    if 'learning_pace' in eval_df_copy.columns:
        eval_df_copy['learning_pace_numeric'] = eval_df_copy['learning_pace'].map(learning_pace_mapping).fillna(1)
    else:
        eval_df_copy['learning_pace_numeric'] = 1

    if 'avg_completion_rate' in eval_df_copy.columns:
        eval_df_copy['learning_consistency'] = eval_df_copy['avg_completion_rate'].clip(0, 100) / 100.0
    else:
        eval_df_copy['learning_consistency'] = 0.5

    if 'current_proficiency_score' in eval_df_copy.columns:
        eval_df_copy['goal_alignment'] = (eval_df_copy['current_proficiency_score'].clip(0, 100) + 50) / 200.0
    else:
        eval_df_copy['goal_alignment'] = 0.5

    eval_df = eval_df_copy

    # Initialize scaler
    scaler = StandardScaler()

    # Define 8 required numeric columns
    numeric_cols = [
        'current_proficiency_score',
        'avg_course_score',
        'learning_pace_numeric',
        'education_level_numeric',
        'hours_available_per_week',
        'total_courses_completed',
        'learning_consistency',
        'goal_alignment',
    ]

    # Prepare training features
    print("\n[1/5] Preparing training features...")
    numeric_cols_available = [col for col in numeric_cols if col in train_df.columns]
    numeric_df = train_df[numeric_cols_available].copy()

    for col in numeric_cols_available:
        numeric_df[col] = pd.to_numeric(numeric_df[col], errors='coerce')
        col_mean = numeric_df[col].mean()
        if pd.isna(col_mean):
            col_mean = 0
        numeric_df[col] = numeric_df[col].fillna(col_mean)

    X_train = scaler.fit_transform(numeric_df.values)
    y_train = train_df['recommended_difficulty_level'].values
    difficulty_classes = np.unique(y_train).tolist()

    print(f"  ✓ Training features shape: {X_train.shape}")
    print(f"  ✓ Classes: {difficulty_classes}")

    # Train model
    print("\n[2/5] Training Logistic Regression model...")
    model = LogisticRegression(
        multi_class='multinomial',
        solver='lbfgs',
        max_iter=500,
        random_state=42,
        n_jobs=-1
    )
    model.fit(X_train, y_train)
    print("  ✓ Model trained")

    # Evaluate on training set
    print("\n[3/5] Evaluating on training set...")
    y_pred = model.predict(X_train)
    train_acc = accuracy_score(y_train, y_pred)
    print(f"  ✓ Training Accuracy: {train_acc:.3f}")

    # Evaluate on eval set
    print("\n[4/5] Evaluating on evaluation set...")
    numeric_df_eval = eval_df[numeric_cols_available].copy()

    for col in numeric_cols_available:
        numeric_df_eval[col] = pd.to_numeric(numeric_df_eval[col], errors='coerce')
        col_mean = numeric_df_eval[col].mean()
        if pd.isna(col_mean):
            col_mean = 0
        numeric_df_eval[col] = numeric_df_eval[col].fillna(col_mean)

    X_eval = scaler.transform(numeric_df_eval.values)
    y_eval = eval_df['recommended_difficulty_level'].values
    y_eval_pred = model.predict(X_eval)
    eval_acc = accuracy_score(y_eval, y_eval_pred)
    print(f"  ✓ Eval Accuracy: {eval_acc:.3f}")

    print("\n  Classification Report:")
    print(classification_report(y_eval, y_eval_pred, target_names=difficulty_classes))

    # Save model artifacts (2 files only)
    print(f"\n[5/5] Saving artifacts to {model_save_dir}...")
    Path(model_save_dir).mkdir(parents=True, exist_ok=True)

    pickle.dump(model, open(f"{model_save_dir}/difficulty_model.pkl", "wb"))
    pickle.dump(scaler, open(f"{model_save_dir}/difficulty_scaler.pkl", "wb"))

    print("  ✓ Artifacts saved:")
    print(f"    - difficulty_model.pkl")
    print(f"    - difficulty_scaler.pkl")

    # Return metrics
    print("\n[Complete] Training finished")
    metrics = {
        "train_accuracy": float(train_acc),
        "eval_accuracy": float(eval_acc),
        "classes": difficulty_classes,
    }

    return metrics


if __name__ == "__main__":
    train_path = "data/processed/difficulty_cleaned.csv"
    train_df = pd.read_csv(train_path)
    print(f"Training samples: {len(train_df)}\n")

    metrics = train_difficulty_prediction_model(train_df)
    print("\n" + "="*70)
    print("TRAINING METRICS")
    print("="*70)
    for key, value in metrics.items():
        if key != "classes":
            print(f"  {key}: {value}")
