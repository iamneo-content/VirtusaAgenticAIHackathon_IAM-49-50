"""
Train Gap Detection Model (Logistic Regression)
Uses 10 simplified numeric features only.
Saves only 2 artifacts: model + scaler
"""

import pandas as pd
import numpy as np
import pickle
from pathlib import Path
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report
import warnings

warnings.filterwarnings('ignore')


def train_gap_detection_model(train_df, data_dir="data", model_save_dir="ml/models"):
    """Train gap detection model using Logistic Regression (10 features)."""

    print("\n" + "="*70)
    print("TRAINING GAP DETECTION MODEL (Logistic Regression - 10 features)")
    print("="*70)

    # Load evaluation data
    eval_path = Path(data_dir) / "evaluation_dataset" / "gap_eval.csv"
    eval_df = pd.read_csv(eval_path)

    # Initialize scaler
    scaler = StandardScaler()

    # Define 10 required numeric columns
    numeric_cols = [
        'current_proficiency_score',
        'avg_completion_rate',
        'avg_course_score',
        'course_dropout_rate',
        'total_courses_completed',
        'concept_understanding_score',
        'practical_application_score',
        'problem_solving_ability',
        'goal_clarity_score',
        'motivation_level',
    ]

    # Prepare training features
    print("\n[1/5] Preparing training features...")
    numeric_cols_available = [col for col in numeric_cols if col in train_df.columns]
    numeric_df = train_df[numeric_cols_available].copy()

    for col in numeric_cols_available:
        numeric_df[col] = pd.to_numeric(numeric_df[col], errors='coerce')
        col_mean = numeric_df[col].mean()
        if pd.isna(col_mean):
            col_mean = 0
        numeric_df[col] = numeric_df[col].fillna(col_mean)

    X_train = scaler.fit_transform(numeric_df.values)
    y_train = train_df['primary_gap'].values
    gap_classes = np.unique(y_train).tolist()

    print(f"  ✓ Training features shape: {X_train.shape}")
    print(f"  ✓ Classes: {gap_classes}")

    # Train model
    print("\n[2/5] Training Logistic Regression model...")
    model = LogisticRegression(
        multi_class='multinomial',
        solver='lbfgs',
        max_iter=500,
        random_state=42,
        n_jobs=-1
    )
    model.fit(X_train, y_train)
    print("  ✓ Model trained")

    # Evaluate on training set
    print("\n[3/5] Evaluating on training set...")
    y_pred = model.predict(X_train)
    train_acc = accuracy_score(y_train, y_pred)
    print(f"  ✓ Accuracy: {train_acc:.3f}")

    # Evaluate on eval set
    print("\n[4/5] Evaluating on evaluation set...")
    numeric_df_eval = eval_df[numeric_cols_available].copy()

    for col in numeric_cols_available:
        numeric_df_eval[col] = pd.to_numeric(numeric_df_eval[col], errors='coerce')
        col_mean = numeric_df_eval[col].mean()
        if pd.isna(col_mean):
            col_mean = 0
        numeric_df_eval[col] = numeric_df_eval[col].fillna(col_mean)

    X_eval = scaler.transform(numeric_df_eval.values)
    y_eval = eval_df['primary_gap'].values
    y_eval_pred = model.predict(X_eval)
    eval_acc = accuracy_score(y_eval, y_eval_pred)
    print(f"  ✓ Eval Accuracy: {eval_acc:.3f}")

    print("\n  Per-Gap Accuracy:")
    for gap in gap_classes:
        mask = y_eval == gap
        if mask.sum() > 0:
            acc = accuracy_score(y_eval[mask], y_eval_pred[mask])
            count = mask.sum()
            print(f"    {gap:30s} {acc:9.1%} ({count:4d} samples)")

    # Save model artifacts (2 files only)
    print(f"\n[5/5] Saving artifacts to {model_save_dir}...")
    Path(model_save_dir).mkdir(parents=True, exist_ok=True)

    pickle.dump(model, open(f"{model_save_dir}/gap_model.pkl", "wb"))
    pickle.dump(scaler, open(f"{model_save_dir}/gap_scaler.pkl", "wb"))

    print("  ✓ Artifacts saved:")
    print(f"    - gap_model.pkl")
    print(f"    - gap_scaler.pkl")

    # Return metrics
    print("\n[Complete] Training finished")
    metrics = {
        "train_accuracy": float(train_acc),
        "eval_accuracy": float(eval_acc),
        "gap_labels_count": len(gap_classes),
        "gap_labels": gap_classes,
    }

    return metrics


if __name__ == "__main__":
    train_path = "data/processed/gap_cleaned.csv"
    train_df = pd.read_csv(train_path)
    print(f"Loading training data: {len(train_df)} samples")

    metrics = train_gap_detection_model(train_df)
    print("\n" + "="*70)
    print("TRAINING METRICS")
    print("="*70)
    for key, value in metrics.items():
        if key != "gap_labels":
            print(f"  {key}: {value}")
