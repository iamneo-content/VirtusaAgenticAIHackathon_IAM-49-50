#!/usr/bin/env python3
"""
ML Training Pipeline Orchestration for LearnBuddy

Orchestrates complete ML pipeline:
1. Data cleaning (gap + difficulty datasets)
2. Model training (Gap Detection + Difficulty Prediction)

Follows SymptomOne_repro architecture pattern.
"""

from typing import Dict, Any
import pandas as pd
from pathlib import Path
import sys
import json

# Allow running both as module (`python -m ml.train_pipeline`)
# and as script (`python ml/train_pipeline.py`)
if __name__ == "__main__" and __package__ is None:
    sys.path.append(str(Path(__file__).resolve().parent.parent))

from ml.cleaning.clean_gap_data import clean_gap_data
from ml.cleaning.clean_difficulty_data import clean_difficulty_data
from ml.train_model.train_gap_model import train_gap_detection_model
from ml.train_model.train_difficulty_model import train_difficulty_prediction_model


def run_training_pipeline(
    data_dir: str = "data",
    processed_dir: str = "data/processed",
    model_dir: str = "ml/models"
) -> Dict[str, Any]:
    """
    Execute complete ML training pipeline.

    Stages:
    1. Clean gap detection data (from training_dataset → processed/)
    2. Clean difficulty prediction data (from training_dataset → processed/)
    3. Train gap detection model (Logistic Regression - 10 features)
    4. Train difficulty prediction model (Logistic Regression - 8 features)

    Args:
        data_dir: Root data directory
        processed_dir: Directory to save cleaned data
        model_dir: Directory to save trained models

    Returns:
        dict with training metrics for all models
    """

    results = {
        "gap_training": {},
        "difficulty_training": {},
        "status": "pending"
    }

    try:
        # ========== STAGE 1: CLEAN GAP DETECTION DATA ==========
        print("\n" + "=" * 70)
        print("LEARNBUDDY ML TRAINING PIPELINE")
        print("=" * 70)

        print("\n[STAGE 1] Cleaning gap detection data...")
        clean_gap_data()
        print("  ✓ Gap detection data cleaned")

        # ========== STAGE 2: CLEAN DIFFICULTY PREDICTION DATA ==========
        print("\n[STAGE 2] Cleaning difficulty prediction data...")
        clean_difficulty_data()
        print("  ✓ Difficulty prediction data cleaned")

        # ========== STAGE 3: LOAD CLEANED TRAINING DATA ==========
        print("\n[STAGE 3] Loading cleaned training data...")
        gap_train_path = f"{processed_dir}/gap_cleaned.csv"
        difficulty_train_path = f"{processed_dir}/difficulty_cleaned.csv"

        gap_train_df = pd.read_csv(gap_train_path)
        print(f"  ✓ Gap Detection Train: {len(gap_train_df)} rows")

        difficulty_train_df = pd.read_csv(difficulty_train_path)
        print(f"  ✓ Difficulty Prediction Train: {len(difficulty_train_df)} rows")

        # ========== STAGE 4: TRAIN GAP DETECTION MODEL ==========
        print("\n[STAGE 4] Training gap detection model (Logistic Regression)...")
        gap_metrics = train_gap_detection_model(
            gap_train_df,
            data_dir=data_dir,
            model_save_dir=model_dir
        )
        results["gap_training"] = gap_metrics
        print(f"  ✓ Gap detection model trained")
        print(f"    - Train accuracy: {gap_metrics.get('train_accuracy', 0):.2%}")
        print(f"    - Eval accuracy: {gap_metrics.get('eval_accuracy', 0):.2%}")
        print(f"    - Eval Hamming Loss: {gap_metrics.get('eval_hamming_loss', 0):.4f}")

        # ========== STAGE 5: TRAIN DIFFICULTY PREDICTION MODEL ==========
        print("\n[STAGE 5] Training difficulty prediction model (Logistic Regression)...")
        difficulty_metrics = train_difficulty_prediction_model(
            difficulty_train_df,
            data_dir=data_dir,
            model_save_dir=model_dir
        )
        results["difficulty_training"] = difficulty_metrics
        print(f"  ✓ Difficulty prediction model trained")
        print(f"    - Train accuracy: {difficulty_metrics.get('train_accuracy', 0):.2%}")
        print(f"    - Eval accuracy: {difficulty_metrics.get('eval_accuracy', 0):.2%}")
        print(f"    - CV score (5-fold): {difficulty_metrics.get('cv_score', 0):.2%}")

        # ========== COMPLETION ==========
        results["status"] = "success"
        print("\n" + "=" * 70)
        print("✓ TRAINING PIPELINE COMPLETE!")
        print("=" * 70)
        print(f"\nModels saved to: {model_dir}")
        print(f"Cleaned data saved to: {processed_dir}")

        return results

    except Exception as e:
        results["status"] = "failed"
        results["error"] = str(e)
        print(f"\n✗ Pipeline error: {str(e)}")
        import traceback
        traceback.print_exc()
        return results


if __name__ == "__main__":
    results = run_training_pipeline()
    print("\n" + "=" * 70)
    print("FINAL RESULTS")
    print("=" * 70)
    print(json.dumps(results, indent=2, default=str))
