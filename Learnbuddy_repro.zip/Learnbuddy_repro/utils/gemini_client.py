"""Google Gemini LLM Client with API key rotation and robust error handling"""
from __future__ import annotations

import json
import logging
import os
import re
from pathlib import Path
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)

try:
    from dotenv import load_dotenv
    env_file = Path.cwd() / ".env"
    if env_file.exists():
        load_dotenv(env_file)
except ImportError:
    pass

genai = None
is_new_api = False

try:
    from google import genai as genai_new
    genai = genai_new
    is_new_api = True
    logger.info("Using new google.genai API")
except (ImportError, AttributeError):
    try:
        from google import generativeai as genai_old
        genai = genai_old
        is_new_api = False
        logger.info("Using legacy google.generativeai API")
    except ImportError:
        genai = None


def _get_all_api_keys() -> list:
    """Get all available API keys from environment"""
    keys = []
    for i in range(1, 5):
        env_key_i = os.getenv(f"GEMINI_API_KEY_{i}")
        if env_key_i and env_key_i not in keys:
            keys.append(env_key_i)
    env_key = os.getenv("GEMINI_API_KEY")
    if env_key and env_key not in keys:
        keys.append(env_key)
    return keys


def _clean_json_text(text: str) -> str:
    """Remove markdown fences from JSON text"""
    cleaned = text.strip()
    cleaned = re.sub(r"```json\s*", "", cleaned, flags=re.IGNORECASE | re.MULTILINE)
    cleaned = re.sub(r"```", "", cleaned, flags=re.MULTILINE)
    return cleaned.strip()


def _strip_trailing_commas(text: str) -> str:
    """Remove trailing commas before closing braces/brackets"""
    previous = None
    current = text
    while current != previous:
        previous = current
        current = re.sub(r",\s*([}\]])", r"\1", current)
    return current


class GeminiClient:
    """Client for Google Gemini LLM API with key rotation and robust error handling"""

    def __init__(self, model: str = None):
        """
        Initialize Gemini client

        Args:
            model: Model name (default: from GEMINI_MODEL env or gemini-2.5-flash-lite)
        """
        self.model = model or os.getenv("GEMINI_MODEL", "gemini-2.5-flash-lite")
        self.api_keys = _get_all_api_keys()
        self.current_key_index = 0
        self.client = None

        if not self.api_keys:
            raise ValueError(
                "No Gemini API keys found. "
                "Set GEMINI_API_KEY_1..4 or GEMINI_API_KEY in .env file"
            )

        if genai is None:
            raise ImportError(
                "google-generativeai is not installed. "
                "Install with: pip install google-generativeai"
            )

        # Initialize client with current API key
        self._initialize_client()

    def _initialize_client(self) -> None:
        """Initialize Gemini client with current API key"""
        if self.current_key_index >= len(self.api_keys):
            raise ValueError("No valid API keys available for Gemini")

        current_key = self.api_keys[self.current_key_index]
        if is_new_api:
            self.client = genai.Client(api_key=current_key)
        else:
            genai.configure(api_key=current_key)
            self.client = genai.GenerativeModel(self.model)

        logger.info(f"Initialized Gemini client with key {self.current_key_index + 1}/{len(self.api_keys)}")

    def _rotate_api_key(self) -> None:
        """Rotate to next available API key"""
        self.current_key_index += 1
        if self.current_key_index >= len(self.api_keys):
            raise ValueError(f"All {len(self.api_keys)} API keys exhausted")

        self._initialize_client()
        logger.info(f"Rotated to API key {self.current_key_index + 1}/{len(self.api_keys)}")

    def generate_content(
        self,
        prompt: str,
        temperature: float = 0.7,
        max_tokens: int = 2000,
        response_mime_type: Optional[str] = None,
    ) -> str:
        """Generate content from Gemini with automatic API key rotation on quota exceeded"""
        max_retries = len(self.api_keys)
        attempt = 0

        while attempt < max_retries:
            try:
                generation_config = {
                    "temperature": temperature,
                    "max_output_tokens": max_tokens,
                }
                if response_mime_type:
                    generation_config["response_mime_type"] = response_mime_type

                response = self.client.generate_content(
                    prompt,
                    generation_config=generation_config,
                )

                if not response or not getattr(response, "text", None):
                    raise ValueError("Empty response from LLM")

                return response.text

            except Exception as e:
                error_str = str(e)

                # Check if it's a quota/rate limit error
                if any(
                    quota_indicator in error_str
                    for quota_indicator in [
                        "429",
                        "quota",
                        "rate limit",
                        "exceeded",
                        "per_minute",
                        "per_day",
                    ]
                ):
                    attempt += 1

                    if attempt < max_retries:
                        try:
                            self._rotate_api_key()
                            logger.warning(f"API quota exceeded, rotating to next key")
                            continue
                        except ValueError as rotate_error:
                            raise ValueError(f"All API keys exhausted or invalid: {rotate_error}")
                    else:
                        raise ValueError(
                            f"All {len(self.api_keys)} API keys quota exceeded. Please wait before retrying."
                        )
                else:
                    # Non-quota errors should fail immediately
                    raise ValueError(f"Failed to generate content from LLM: {error_str}")

        raise ValueError("Failed to generate content after all retries")

    def extract_json_from_response(self, response_text: str) -> Dict[str, Any]:
        """Extract and repair JSON from LLM response text"""
        try:
            cleaned = _clean_json_text(response_text)
            candidates = [cleaned]

            # If the response contains other text, try extracting the first JSON object
            json_match = re.search(r"\{.*\}", cleaned, re.DOTALL)
            if json_match:
                candidates.append(json_match.group(0))

            last_error = None
            for candidate in candidates:
                try:
                    repaired = _strip_trailing_commas(candidate)
                    parsed_json = json.loads(repaired)
                    if not isinstance(parsed_json, dict):
                        raise ValueError("LLM response is not a valid JSON object")
                    return parsed_json
                except Exception as parse_error:
                    last_error = parse_error
                    continue

            raise ValueError(f"Invalid JSON in LLM response: {last_error}")

        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON in LLM response: {str(e)}")
        except Exception as e:
            raise ValueError(f"Failed to extract JSON from LLM response: {str(e)}")

    def validate_response_fields(
        self, response: Dict[str, Any], required_fields: list
    ) -> None:
        """Validate that all required fields are present in response"""
        missing_fields = [field for field in required_fields if field not in response]

        if missing_fields:
            raise ValueError(f"LLM response missing required fields: {missing_fields}")

    def generate_structured_json(
        self,
        prompt: str,
        required_fields: list = None,
        temperature: float = 0.3,
        max_tokens: int = 2000,
    ) -> Dict[str, Any]:
        """Generate structured JSON response from LLM"""
        response_text = self.generate_content(
            prompt=prompt,
            temperature=temperature,
            max_tokens=max_tokens,
        )

        response_dict = self.extract_json_from_response(response_text)

        if required_fields:
            self.validate_response_fields(response_dict, required_fields)

        return response_dict
