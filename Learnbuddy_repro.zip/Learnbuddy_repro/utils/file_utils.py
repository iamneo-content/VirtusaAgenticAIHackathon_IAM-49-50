#!/usr/bin/env python3
"""File I/O utilities for LearnBuddy"""

from pathlib import Path


def create_output_directory(learner_id: str) -> str:
    """
    Create output directory for learner reports.

    Args:
        learner_id: Unique learner identifier

    Returns:
        Path to created learner output directory
    """
    output_base = Path("output")
    output_base.mkdir(parents=True, exist_ok=True)
    learner_dir = output_base / learner_id
    learner_dir.mkdir(parents=True, exist_ok=True)
    return str(learner_dir)


def save_file(file_path: str, content: str) -> bool:
    """
    Save content to file with error handling.

    Args:
        file_path: Path where file should be saved
        content: Content to write to file

    Returns:
        True if successful, False if error occurred
    """
    try:
        Path(file_path).parent.mkdir(parents=True, exist_ok=True)
        with open(file_path, 'w') as f:
            f.write(content)
        return True
    except Exception as e:
        print(f"Error saving file {file_path}: {e}")
        return False
