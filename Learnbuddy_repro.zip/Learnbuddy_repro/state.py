#!/usr/bin/env python3
"""
State Management for LearnBuddy - Clean & Minimal
Following SymptomOne_repro architecture patterns
Minimal fields, pure logic only
"""

from typing import TypedDict, List, Dict, Any, Annotated
from operator import add


class LearnerPlanState(TypedDict, total=False):
    """
    Minimal state for personalized learning path generation with conditional routing.

    Organized into pipeline stages:
    Input → Parsing → Analysis → ML → Proficiency Classification → Plan Generation
    → Multi-Stage Validation → Coaching → Reporting → Error Tracking
    """

    # INPUT STAGE (2 fields)
    learner_json: Dict[str, Any]
    learner_id: str

    # PARSING STAGE (2 fields)
    parsed_learner: Dict[str, Any]
    validation_errors: List[str]

    # ANALYSIS STAGE (1 field)
    analyzed_profile: Dict[str, Any]

    # ML STAGE (5 fields) - Output by ML nodes
    identified_gaps: List[str]
    gap_confidence_scores: Dict[str, float]
    gap_urgency_level: str
    recommended_difficulty: str
    difficulty_confidence: float

    # PROFICIENCY CLASSIFICATION STAGE (2 fields) - NEW
    learner_proficiency_level: str
    proficiency_confidence: float

    # PLAN GENERATION STAGE (1 field) - CHANGED from 6 to 1 (single plan instead of 3 variants)
    generated_plan: Dict[str, Any]

    # MULTI-STAGE VALIDATION (6 fields) - NEW (replaces old single validation_issues)
    time_validation_passed: bool
    time_validation_issues: List[str]
    difficulty_validation_passed: bool
    difficulty_validation_issues: List[str]
    resource_validation_passed: bool
    resource_validation_issues: List[str]

    # COACHING STAGE (1 field)
    plan_friendly: str

    # REPORTING STAGE (1 field) - Complete report data
    report_json: Dict[str, Any]

    # OUTPUT METADATA (2 fields) - File storage information
    output_dir: str
    saved_path: str

    # ERROR TRACKING (2 fields) - Error management
    error_occurred: bool
    error_messages: Annotated[List[str], add]


MicroPlanState = LearnerPlanState


def get_initial_state(learner_json: Dict[str, Any]) -> LearnerPlanState:
    """Initialize state with all fields set to defaults"""
    return {
        # INPUT
        "learner_json": learner_json,
        "learner_id": learner_json.get("learner_id", "UNKNOWN"),

        # PARSING
        "parsed_learner": {},
        "validation_errors": [],

        # ANALYSIS
        "analyzed_profile": {},
        "identified_gaps": [],

        # ML
        "gap_confidence_scores": {},
        "gap_urgency_level": "",
        "recommended_difficulty": "",
        "difficulty_confidence": 0.0,

        # PROFICIENCY CLASSIFICATION (Phase 2)
        "learner_proficiency_level": "",
        "proficiency_confidence": 0.0,

        # PLANNING (Phase 2 - single plan)
        "generated_plan": {},

        # MULTI-STAGE VALIDATION (Phase 2)
        "time_validation_passed": False,
        "time_validation_issues": [],
        "difficulty_validation_passed": False,
        "difficulty_validation_issues": [],
        "resource_validation_passed": False,
        "resource_validation_issues": [],

        # COACHING (Phase 2 - single plan)
        "plan_friendly": "",

        # REPORTING
        "report_json": {},

        # METADATA
        "output_dir": "",
        "saved_path": "",

        # ERROR
        "error_occurred": False,
        "error_messages": [],
    }


