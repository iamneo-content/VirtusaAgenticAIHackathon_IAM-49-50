#!/usr/bin/env python3
"""Workflow Orchestration - Learning plan generation execution"""

import uuid
from typing import Dict, Any, Optional
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))

from graph import run_learnbuddy_workflow


class LearnBuddyWorkflow:
    """Orchestrator for LangGraph workflow execution with JSON input"""

    def __init__(self):
        """Initialize workflow orchestrator"""
        self.output_dir = Path("output")
        self.output_dir.mkdir(exist_ok=True)

    def run_workflow(self, learner_json: Dict[str, Any], session_id: Optional[str] = None) -> Dict[str, Any]:
        """Execute LangGraph workflow with learner JSON data"""
        try:
            if session_id is None:
                session_id = str(uuid.uuid4())

            print(f"[Workflow] Executing learning plan for session: {session_id}")
            result = run_learnbuddy_workflow(learner_json)
            return result

        except Exception as e:
            print(f"[Workflow Error] {str(e)}")
            import traceback
            traceback.print_exc()
            return {
                "error": str(e),
                "status": "failed",
                "session_id": session_id
            }


workflow_instance = LearnBuddyWorkflow()
