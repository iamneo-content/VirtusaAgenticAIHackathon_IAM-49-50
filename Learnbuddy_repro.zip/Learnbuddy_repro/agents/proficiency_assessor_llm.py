"""Proficiency Assessor LLM Agent - Assess learner proficiency level using LLM reasoning"""

from typing import Dict, Any, Tuple, Optional
from agents.base_llm_agent import BaseLLMAgent
from utils import GeminiClient


class ProficiencyAssessorLLMAgent(BaseLLMAgent):
    """Assess learner proficiency level using LLM reasoning"""

    def __init__(self, client: Optional[GeminiClient] = None):
        """
        Initialize with optional GeminiClient dependency injection.

        Args:
            client: Optional GeminiClient instance (creates new if not provided)
        """
        super().__init__(client)

    def assess_proficiency(self, analyzed_profile: Dict[str, Any]) -> Tuple[str, float]:
        """
        Assess learner proficiency level using LLM reasoning.

        Analyzes learner's experience, skills, achievements, and goals to determine
        if they are Beginner, Intermediate, or Advanced.

        Args:
            analyzed_profile: Complete analyzed learner profile with metrics

        Returns:
            Tuple of (proficiency_level_string, confidence_float)
            - proficiency_level: "Beginner" / "Intermediate" / "Advanced"
            - confidence: Confidence score (0.0-1.0)
        """
        proficiency_score = analyzed_profile.get("current_proficiency", {}).get("score", 50)
        gaps = analyzed_profile.get("identified_gaps", [])
        history = analyzed_profile.get("learning_history_metrics", {})
        goals = analyzed_profile.get("goals_analysis", {})

        prompt = f"""You are an expert learning assessment professional. Assess the learner's proficiency level.

LEARNER PROFILE:
- Current Proficiency Score: {proficiency_score}/100
- Identified Learning Gaps: {', '.join(gaps) if gaps else 'None specified'}
- Total Courses Completed: {history.get('total_courses_completed', 0)}
- Average Course Score: {history.get('avg_score_obtained', 0):.1f}%
- Average Completion Rate: {history.get('avg_completion_rate', 0):.1f}%
- Primary Goal: {goals.get('primary_goal', 'Unknown')}
- Target Timeline: {goals.get('target_timeline_months', 12)} months

Based on this profile, assess the learner's proficiency level.

Return ONLY valid JSON with NO markdown or extra text:
{{
    "proficiency_level": "Beginner" or "Intermediate" or "Advanced",
    "reasoning": "Brief explanation (one sentence)",
    "confidence": 0.0 to 1.0
}}

Guidelines:
- Beginner: Limited experience, many gaps, foundational learning needed
- Intermediate: Moderate experience, some gaps, practical skills developing
- Advanced: Strong experience, minimal gaps, specialized knowledge present"""

        response_text = self.generate_response(
            prompt=prompt,
            temperature=0.3,
            max_tokens=300
        )

        result = self.extract_json(response_text)

        level = result.get("proficiency_level", "Intermediate")
        confidence = float(result.get("confidence", 0.7))

        return level, confidence
