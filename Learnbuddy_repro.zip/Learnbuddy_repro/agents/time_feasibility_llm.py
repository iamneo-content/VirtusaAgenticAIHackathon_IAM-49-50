"""Time Feasibility LLM Agent - Assess plan time feasibility using LLM reasoning"""

from typing import Dict, Any, Tuple, List, Optional
from agents.base_llm_agent import BaseLLMAgent
from utils import GeminiClient


class TimeFeasibilityLLMAgent(BaseLLMAgent):
    """Assess learning plan time feasibility using LLM reasoning"""

    def __init__(self, client: Optional[GeminiClient] = None):
        """
        Initialize with optional GeminiClient dependency injection.

        Args:
            client: Optional GeminiClient instance (creates new if not provided)
        """
        super().__init__(client)

    def validate_timeline(self, plan: Dict[str, Any], constraints: Dict[str, Any]) -> Tuple[bool, List[str]]:
        """
        Validate if plan timeline is feasible for learner using LLM reasoning.

        Args:
            plan: Generated learning plan with duration_weeks and hours_per_week
            constraints: Learner constraints with hours_available_per_week and target_timeline_months

        Returns:
            Tuple of (validation_passed_bool, issues_list)
            - validation_passed: True if all time constraints satisfied
            - issues: List of human-readable issues found (empty if passed)
        """
        plan_hours = plan.get("hours_per_week", 0)
        plan_weeks = plan.get("duration_weeks", 0)
        available_hours = constraints.get("hours_available_per_week", 0)
        target_months = constraints.get("target_timeline_months", 12)

        prompt = f"""You are an expert learning plan evaluator. Assess if the learning plan timeline is feasible for the learner.

PLAN TIMELINE:
- Duration: {plan_weeks} weeks
- Time Commitment: {plan_hours} hours per week
- Total Hours Required: {plan_hours * plan_weeks:.0f} hours

LEARNER CONSTRAINTS:
- Available Hours Per Week: {available_hours} hours/week
- Target Timeline: {target_months} months (~{target_months * 4.33:.0f} weeks)

Evaluate feasibility considering:
1. Does plan fit within learner's available time per week?
2. Does total plan duration align with learner's target timeline (within 30% variance)?
3. Can learner complete all hours within available capacity?
4. Is the timeline realistic and achievable?

Return ONLY valid JSON with NO markdown or extra text:
{{
    "is_feasible": true or false,
    "issues": ["issue1", "issue2"] or [],
    "reasoning": "Brief explanation (1-2 sentences)"
}}

Guidelines:
- List specific time conflicts if hours exceed available capacity
- Flag timeline misalignments if variance exceeds 30%
- Be realistic about feasibility constraints
- Empty issues list means plan is feasible"""

        response_text = self.generate_response(
            prompt=prompt,
            temperature=0.3,
            max_tokens=300
        )

        result = self.extract_json(response_text)

        is_feasible = result.get("is_feasible", True)
        issues = result.get("issues", [])

        # Ensure issues is a list
        if not isinstance(issues, list):
            issues = [str(issues)] if issues else []

        return (is_feasible, issues)
