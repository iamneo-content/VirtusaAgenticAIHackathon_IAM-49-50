"""Standard Plan Generator LLM Agent - Generate balanced learning plans"""

from typing import Dict, Any, Optional
from agents.base_llm_agent import BaseLLMAgent
from utils import GeminiClient


class StandardPlanGeneratorLLMAgent(BaseLLMAgent):
    """Generate standard/intermediate-focused personalized learning plan via LLM"""

    def __init__(self, client: Optional[GeminiClient] = None):
        """
        Initialize with optional GeminiClient dependency injection.

        Args:
            client: Optional GeminiClient instance (creates new if not provided)
        """
        super().__init__(client)

    def create_standard_plan(self, analyzed_profile: Dict[str, Any]) -> Dict[str, Any]:
        """
        Create a standard/intermediate learning plan using LLM.

        Plan characteristics:
        - Balanced curriculum mixing theory and practice
        - Standard learning pace (1.0x timeline multiplier)
        - Mix of prerequisites and direct learning
        - Practical projects and real-world applications
        - Moderate budget efficiency

        Args:
            analyzed_profile: Complete analyzed learner profile with metrics and gaps

        Returns:
            Dictionary with plan structure:
            {
                "plan_type": "Standard",
                "duration_weeks": int,
                "hours_per_week": int,
                "intensity": str,
                "topics": List[str],
                "resources": List[Dict],
                "milestones": List[Dict],
                "prerequisites": List[str],
                "success_criteria": List[str],
                "difficulty_progression": str
            }
        """
        learner_id = analyzed_profile.get("learner_id", "UNKNOWN")
        gaps = analyzed_profile.get("identified_gaps", [])
        domain = analyzed_profile.get("current_proficiency", {}).get("domain", "")
        target_timeline = analyzed_profile.get("goals_analysis", {}).get("target_timeline_months", 12)
        budget = analyzed_profile.get("constraints_analysis", {}).get("budget_usd", 500)

        prompt = f"""You are an expert educational curriculum designer specializing in intermediate-level learning paths.

LEARNER PROFILE:
- Learner ID: {learner_id}
- Domain: {domain}
- Target Timeline: {target_timeline} months
- Budget: ${budget}
- Identified Gaps: {', '.join(gaps) if gaps else 'General skill gaps'}

REQUIREMENTS FOR STANDARD PLAN:
1. Duration: Standard timeline (recommended 12-16 weeks)
2. Pace: Balanced - theory with practical applications
3. Resources: 50% free + 50% quality paid resources (aim for $100-250 total)
4. Intensity: Medium intensity with practical projects
5. Prerequisites: Include key prerequisites only where necessary

RESOURCE COST GUIDELINES FOR INTERMEDIATE LEARNERS:
- Free resources: Project tutorials, open-source projects, community forums (cost: $0)
- Mid-tier courses: Coursera/Udemy paid courses, professional platforms (cost: $30-50)
- Quality courses: Structured bootcamp courses, professional certifications (cost: $50-100)
- Books & references: Industry-standard books (cost: $20-40)
- Tools/Software: IDE, design tools, development environments (cost: $0-100)
- Keep total resource cost within budget: ${budget}

DIFFICULTY PROGRESSION GUIDELINES:
For domain "{domain}", progression should be:
1. Review key foundational concepts in {domain}
2. Deep dive into core intermediate topics
3. Apply knowledge to real-world problems
4. Build portfolio-worthy projects
5. Explore advanced variations and specializations
Make progression SPECIFIC to "{domain}" and address identified gaps directly.

Generate ONLY a valid JSON response (no markdown, no extra text) with this exact structure:
{{
    "plan_type": "Standard",
    "duration_weeks": 14,
    "hours_per_week": 10,
    "intensity": "Medium",
    "topics": ["Core Concepts Review", "Intermediate Techniques", "Real-World Application", "Portfolio Project"],
    "resources": [
        {{"title": "Comprehensive {domain} Course (Coursera/Udemy paid)", "type": "online course", "duration_hours": 35, "cost_usd": 45}},
        {{"title": "Real-World Project Tutorials", "type": "project tutorials", "duration_hours": 25, "cost_usd": 0}},
        {{"title": "Advanced Techniques Workshop", "type": "specialized course", "duration_hours": 15, "cost_usd": 35}},
        {{"title": "Professional Development Book", "type": "reading material", "duration_hours": 10, "cost_usd": 25}}
    ],
    "milestones": [
        {{"week": 2, "objective": "Review foundations and identify knowledge gaps"}},
        {{"week": 5, "objective": "Master intermediate concepts and techniques"}},
        {{"week": 9, "objective": "Complete 2-3 real-world projects"}},
        {{"week": 14, "objective": "Build and present portfolio-quality project"}}
    ],
    "prerequisites": ["Solid foundation in {domain}", "Basic problem-solving skills"],
    "success_criteria": ["Complete all projects", "Score 80%+ on assessments", "Build portfolio project"],
    "difficulty_progression": "Starts by reviewing intermediate concepts in {domain}, progresses through hands-on practical projects addressing {', '.join(gaps[:2]) if gaps else 'key skill gaps'}, advances to real-world problem solving, culminates in portfolio-quality project demonstrating mastery."
}}

IMPORTANT - Cost Instructions:
- Include 50% free resources (cost: $0)
- Include 50% paid resources ($30-50 per resource)
- Ensure total cost <= ${budget}
- All costs must be realistic numbers reflecting actual course prices
- Use SPECIFIC platform names (Coursera, Udemy, etc.)

Return ONLY the JSON object with NO additional text, markdown formatting, or explanation."""

        response_text = self.generate_response(
            prompt=prompt,
            temperature=0.3,
            max_tokens=2000
        )

        plan_dict = self.extract_json(response_text)
        self.validate_fields(
            plan_dict,
            required_fields=[
                "plan_type", "duration_weeks", "hours_per_week", "intensity",
                "topics", "resources", "milestones", "prerequisites",
                "success_criteria", "difficulty_progression"
            ]
        )

        return plan_dict
