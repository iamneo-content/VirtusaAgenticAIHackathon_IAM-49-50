"""Coach Rewriter LLM Agent - Personalizes learning plans with adaptive coaching tone"""

from typing import Dict, Any
from agents.base_llm_agent import BaseLLMAgent
from utils import GeminiClient


class CoachRewriterLLMAgent(BaseLLMAgent):
    """
    LLM agent for personalizing learning plan with adaptive coaching tone.

    Tone Selection (Phase 2 - single plan):
    - Young learners (<18): Encouraging
    - Visual learners: Metaphor-based
    - Kinesthetic learners: Action-oriented
    - Auditory learners: Conversational
    - Default: Analytical
    """

    def __init__(self, client: GeminiClient = None):
        """Initialize agent with centralized LLM client"""
        super().__init__(client)

    def generate_coaching_guidance(
        self,
        plan: Dict[str, Any],
        analyzed_profile: Dict[str, Any]
    ) -> str:
        """
        Generate personalized coaching guidance with adaptive tone (Phase 2).

        Args:
            plan: Single learning plan dictionary containing all plan details
            analyzed_profile: Analyzed learner profile with nested structure:
                {
                    "demographics": {"age": int},
                    "learning_characteristics": {"learning_style": str},
                    "current_proficiency": {...},
                    "challenges": {...}
                }

        Returns:
            String with personalized coaching guidance (variable length).
            Format and length determined by LLM based on learner profile.
            Tone adapted to age and learning style.
        """
        learning_style = analyzed_profile.get("learning_characteristics", {}).get("learning_style", "visual")
        age = analyzed_profile.get("demographics", {}).get("age", 30)

        if age < 18:
            tone = "encouraging_youth"
        elif learning_style == "auditory":
            tone = "conversational"
        elif learning_style == "kinesthetic":
            tone = "practical_action_oriented"
        elif learning_style == "visual":
            tone = "visual_metaphor_based"
        else:
            tone = "analytical"

        duration = plan.get("duration_weeks", 12)
        hours = plan.get("hours_per_week", 10)
        topics = ", ".join(str(t) for t in plan.get("topics", [])[:5])
        milestones = ", ".join(str(m) for m in plan.get("milestones", [])[:4])

        prompt = f"""You are an encouraging learning coach. Write personalized coaching guidance for this learning plan.

Plan Type: {plan.get('plan_type', 'Custom')}
Duration: {duration} weeks at {hours} hours per week
Key Topics: {topics if topics else 'Core skills'}
Milestones: {milestones if milestones else 'Foundational progress'}

Write 2-3 paragraphs in a {tone} tone that:
1. Motivate the learner to start this journey
2. Explain the practical path forward
3. Build confidence in their ability to succeed
4. Emphasize the importance of consistency and support

Use an encouraging, supportive tone. Make it feel achievable and personalized."""

        response = self.generate_response(prompt=prompt, temperature=0.5, max_tokens=500)
        return response.strip()
