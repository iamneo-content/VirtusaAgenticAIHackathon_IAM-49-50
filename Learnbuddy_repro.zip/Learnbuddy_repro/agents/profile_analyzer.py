"""Profile Analyzer Agent - Extract metrics and features from validated profile"""

from typing import Dict, Any, List


class ProfileAnalyzerAgent:
    """Extract learning metrics and ML features from validated learner profile"""

    def extract_metrics(self, parsed_profile: Dict[str, Any]) -> Dict[str, Any]:
        """
        Extract metrics and analyze normalized profile for ML models.

        Args:
            parsed_profile: Validated & normalized learner profile

        Returns:
            Dict with analyzed profile containing all extracted metrics
        """
        learner = parsed_profile

        # DEMOGRAPHICS
        demographics = {
            "age": learner["age"],
            "education_level": learner["education_level"],
            "employment_status": learner["employment_status"],
        }

        # LEARNING TRAITS
        learning_characteristics = {
            "learning_style": learner["learning_style"],
            "learning_pace": learner["learning_pace"],
        }

        # CURRENT PROFICIENCY
        current_proficiency = {
            "domain": learner["primary_domain"],
            "topic": learner["current_topic"],
            "score": learner["current_proficiency_score"],
        }

        # GOALS ANALYSIS
        goals_analysis = {
            "primary_goal": learner["primary_goal"],
            "career_aspiration": learner["career_aspiration"],
            "target_timeline_months": learner["target_timeline_months"],
        }

        # CONSTRAINTS ANALYSIS
        constraints_analysis = {
            "hours_per_week": learner["hours_available_per_week"],
            "budget_usd": learner["budget_limit_usd"],
            "certification_needed": learner["certification_needed"],
        }

        # LEARNING HISTORY METRICS
        history = learner.get("learning_history", [])
        if history:
            avg_completion = sum(c.get("completion_rate", 0) for c in history) / len(history)
            avg_score = sum(c.get("score", 0) for c in history) / len(history)
            total_hours = sum(c.get("time_invested_hours", 0) for c in history)
        else:
            avg_completion = 0
            avg_score = 0
            total_hours = 0

        learning_history_metrics = {
            "total_courses_completed": len(history),
            "avg_completion_rate": avg_completion,
            "avg_score_obtained": avg_score,
            "total_hours_invested": total_hours,
        }

        # CHALLENGES & SUPPORT NEEDS
        challenges = {
            "challenges_faced": learner.get("challenges_faced", []),
            "support_needed": learner.get("previous_support_needed", []),
        }

        # SIMPLIFIED ML FEATURES - Gap Detection (10 engineered numeric features)
        # These are DERIVED/ENGINEERED from input fields, not raw input values
        # Calculate derived metrics from proficiency and learning history
        course_dropout_rate = 1.0 - (avg_completion / 100.0) if avg_completion > 0 else 0.0
        concept_understanding = min(100.0, learner["current_proficiency_score"] * 0.9)
        practical_application = min(100.0, learner["current_proficiency_score"] * 0.85)
        problem_solving = min(100.0, learner["current_proficiency_score"] * 0.8)
        goal_clarity = min(100.0, learner["current_proficiency_score"])
        motivation_level = min(10.0, max(1.0, learner["current_proficiency_score"] / 10.0))

        gap_detection_numeric = [
            learner["current_proficiency_score"],  # 1. current_proficiency_score
            avg_completion,  # 2. avg_completion_rate
            avg_score,  # 3. avg_course_score
            course_dropout_rate,  # 4. course_dropout_rate
            float(len(history)),  # 5. total_courses_completed
            concept_understanding,  # 6. concept_understanding_score
            practical_application,  # 7. practical_application_score
            problem_solving,  # 8. problem_solving_ability
            goal_clarity,  # 9. goal_clarity_score
            motivation_level,  # 10. motivation_level
        ]

        # SIMPLIFIED ML FEATURES - Difficulty Prediction (8 engineered numeric features)
        # Mix of raw input fields and derived metrics with categorical encoding
        education_level_numeric = {
            "primary": 0,
            "secondary": 1,
            "bachelor": 2,
            "master": 3,
            "phd": 4,
        }.get(learner["education_level"], 1)

        learning_pace_numeric = {
            "slow": 0,
            "moderate": 1,
            "fast": 2,
        }.get(learner["learning_pace"], 1)

        learning_consistency = min(1.0, avg_completion / 100.0)
        goal_alignment = min(1.0, max(0.0, (learner["current_proficiency_score"] + 50) / 200.0))

        difficulty_numeric = [
            learner["current_proficiency_score"],  # 1. current_proficiency_score
            avg_score,  # 2. avg_course_score
            float(learning_pace_numeric),  # 3. learning_pace_numeric
            float(education_level_numeric),  # 4. education_level_numeric
            learner["hours_available_per_week"],  # 5. hours_available_per_week
            float(len(history)),  # 6. total_courses_completed
            learning_consistency,  # 7. learning_consistency
            goal_alignment,  # 8. goal_alignment
        ]

        ml_features = {
            "gap_detection_numeric": gap_detection_numeric,  # 10 features
            "difficulty_numeric": difficulty_numeric,  # 8 features
        }

        # AGGREGATE ANALYZED PROFILE
        analyzed_profile = {
            "learner_id": learner["learner_id"],
            "demographics": demographics,
            "learning_characteristics": learning_characteristics,
            "current_proficiency": current_proficiency,
            "goals_analysis": goals_analysis,
            "constraints_analysis": constraints_analysis,
            "learning_history_metrics": learning_history_metrics,
            "challenges": challenges,
            "ml_features": ml_features,
        }

        return analyzed_profile
