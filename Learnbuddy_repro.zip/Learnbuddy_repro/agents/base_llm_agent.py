"""Base LLM Agent class - All LLM agents inherit from this"""
import json
from typing import Dict, Any, Optional
from utils import GeminiClient


class BaseLLMAgent:
    """Base class for all LLM agents"""

    def __init__(self, client: Optional[GeminiClient] = None):
        """
        Initialize base LLM agent

        Args:
            client: GeminiClient instance (creates new if None)
        """
        self.client = client or GeminiClient()

    def generate_response(
        self,
        prompt: str,
        temperature: float = 0.7,
        max_tokens: int = 2000,
    ) -> str:
        """Generate text response from LLM"""
        return self.client.generate_content(
            prompt=prompt,
            temperature=temperature,
            max_tokens=max_tokens,
        )

    def generate_json_response(
        self,
        prompt: str,
        required_fields: list = None,
        temperature: float = 0.3,
        max_tokens: int = 2000,
    ) -> Dict[str, Any]:
        """Generate structured JSON response from LLM"""
        return self.client.generate_structured_json(
            prompt=prompt,
            required_fields=required_fields,
            temperature=temperature,
            max_tokens=max_tokens,
        )

    def extract_json(self, response_text: str) -> Dict[str, Any]:
        """Extract JSON from LLM response"""
        return self.client.extract_json_from_response(response_text)

    def validate_fields(self, response: Dict[str, Any], required_fields: list) -> None:
        """Validate required fields in response"""
        self.client.validate_response_fields(response, required_fields)
