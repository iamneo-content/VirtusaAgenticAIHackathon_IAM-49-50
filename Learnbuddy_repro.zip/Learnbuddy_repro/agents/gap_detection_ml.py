"""Gap Detection ML Agent - Uses trained ML Model to detect primary learning gap"""

import pickle
import numpy as np
from pathlib import Path
from typing import Dict, Any, Tuple, List


MODEL_DIR = Path("ml/models")


class GapDetectionMLAgent:
    """
    ML agent for detecting PRIMARY learning gap using trained Logistic Regression classifier.

    Loads model artifacts and uses them to predict the main learning gap from profile.
    PURE ML ONLY - NO FALLBACKS OR HEURISTICS
    Uses 10 simplified numeric features (no TF-IDF).
    """

    def __init__(self):
        """Initialize agent and load model artifacts (2 files: model + scaler)"""
        self.model = None
        self.scaler = None

        with open(MODEL_DIR / "gap_model.pkl", "rb") as f:
            self.model = pickle.load(f)

        with open(MODEL_DIR / "gap_scaler.pkl", "rb") as f:
            self.scaler = pickle.load(f)

    def detect_gaps(self, analyzed_profile: Dict[str, Any]) -> Tuple[List[str], Dict[str, float], str]:
        """
        Detect TOP-3 learning gaps using pre-extracted ML features (10 numeric only).

        Args:
            analyzed_profile: Analyzed learner profile containing nested structure:
                {
                    "current_proficiency": {"score": float},
                    "ml_features": {"gap_detection_numeric": [10 floats]}
                }

        Returns:
            Tuple of (top_3_gaps_list, confidence_dict, urgency_level)
            where urgency_level is determined from current_proficiency.score:
              < 30: "critical", < 50: "high", < 70: "medium", >= 70: "low"
        """
        if self.model is None:
            raise ValueError("Gap Detection model not initialized")

        # Get pre-extracted features from ProfileAnalyzerAgent
        ml_features = analyzed_profile.get("ml_features", {})
        if not ml_features:
            raise ValueError("ML features not found in analyzed_profile")

        numeric_features_list = ml_features.get("gap_detection_numeric", [])

        if not numeric_features_list or len(numeric_features_list) != 10:
            raise ValueError(f"Expected 10 numeric features, got {len(numeric_features_list)}")

        # Scale features
        X_scaled = self.scaler.transform([numeric_features_list])

        # Get probability predictions for all classes
        try:
            proba = self.model.predict_proba(X_scaled)[0]
        except:
            raise ValueError("Could not get probability predictions from model")

        # Get top 3 predictions by confidence
        top_3_indices = np.argsort(proba)[-3:][::-1]  # Top 3, descending order
        top_3_gaps = self.model.classes_[top_3_indices]
        top_3_probs = proba[top_3_indices]

        # Return top 3 gaps with confidence scores
        identified_gaps = list(top_3_gaps)
        confidence_scores = {gap: float(prob) for gap, prob in zip(top_3_gaps, top_3_probs)}

        # Determine urgency from proficiency
        proficiency = analyzed_profile.get("current_proficiency", {}).get("score", 50)
        if proficiency < 30:
            urgency = "critical"
        elif proficiency < 50:
            urgency = "high"
        elif proficiency < 70:
            urgency = "medium"
        else:
            urgency = "low"

        return identified_gaps, confidence_scores, urgency
