#!/usr/bin/env python3
"""Gap Synthesizer LLM Agent - Intelligent gap analysis using ML predictions + learner context"""

from typing import Dict, Any, List, Tuple
from agents.base_llm_agent import BaseLLMAgent
from utils import GeminiClient


class GapSynthesizerLLMAgent(BaseLLMAgent):
    """
    LLM agent for intelligent gap synthesis.

    Takes ML predictions (top-3 gaps) + full learner context and synthesizes
    a comprehensive gap analysis. Returns multiple gaps with reasoning.

    This is the "hybrid" approach: ML provides statistical predictions,
    LLM provides intelligent reasoning about learner context.
    """

    def __init__(self, client: GeminiClient = None):
        """
        Initialize with optional GeminiClient dependency injection.

        Args:
            client: Optional GeminiClient instance (creates new if not provided)
        """
        super().__init__(client)

    def synthesize_gaps(self, analyzed_profile: Dict[str, Any], ml_predictions: Dict[str, Any]) -> Tuple[List[str], str]:
        """
        Synthesize comprehensive gap analysis using ML predictions + learner context.

        Args:
            analyzed_profile: Complete analyzed learner profile with all metrics
            ml_predictions: Dict with:
                - top_gaps: List of top-3 gap predictions
                - confidence_scores: Dict of gap -> confidence
                - urgency_level: str

        Returns:
            Tuple of (identified_gaps, gap_analysis_reasoning)
        """
        # Extract ML predictions
        top_gaps = ml_predictions.get("top_gaps", [])
        confidence_scores = ml_predictions.get("confidence_scores", {})
        urgency = ml_predictions.get("urgency_level", "medium")

        # Extract learner context
        learner_id = analyzed_profile.get("learner_id", "UNKNOWN")
        proficiency_score = analyzed_profile.get("current_proficiency", {}).get("score", 50)
        domain = analyzed_profile.get("current_proficiency", {}).get("domain", "General")
        completion_rate = analyzed_profile.get("current_proficiency", {}).get("avg_completion_rate", 50)
        understanding = analyzed_profile.get("current_proficiency", {}).get("concept_understanding_score", 50)
        practical = analyzed_profile.get("current_proficiency", {}).get("practical_application_score", 50)

        # Build context string from ML predictions with confidence
        top_gaps_str = "\n".join([
            f"- {gap} ({confidence_scores.get(gap, 0):.1%} confidence)"
            for gap in top_gaps
        ])

        prompt = f"""You are an expert learning analyst synthesizing comprehensive gap analysis for learners.

LEARNER PROFILE:
- Learner ID: {learner_id}
- Domain: {domain}
- Proficiency Score: {proficiency_score}%
- Course Completion Rate: {completion_rate}%
- Concept Understanding: {understanding}%
- Practical Application: {practical}%
- Urgency Level: {urgency}

ML MODEL PREDICTIONS (Top-3):
{top_gaps_str}

TASK:
Based on the ML predictions and learner profile, synthesize a comprehensive list of the learner's actual gaps.
Consider:
1. Which ML-predicted gaps are likely REAL based on the profile?
2. Are there secondary/tertiary gaps that should be prioritized?
3. How do the metrics (completion rate, understanding, practical skills) support the ML predictions?
4. What is the learner's actual most critical gap right now?

RESPONSE FORMAT:
Return a JSON object with:
{{
    "primary_gap": "most critical gap to address",
    "secondary_gaps": ["gap_name_1", "gap_name_2"],
    "reasoning": "Brief explanation of why these gaps were identified based on profile and ML predictions",
    "recommended_focus": "Which gap to focus on first and why"
}}

Return ONLY valid JSON, no markdown, no explanation."""

        response_text = self.generate_response(
            prompt=prompt,
            temperature=0.4,
            max_tokens=1000
        )

        # Extract JSON
        analysis = self.extract_json(response_text)

        # Validate and structure response
        primary_gap = analysis.get("primary_gap", top_gaps[0] if top_gaps else "general_skills")
        secondary_gaps = analysis.get("secondary_gaps", top_gaps[1:] if len(top_gaps) > 1 else [])
        reasoning = analysis.get("reasoning", "Based on learner profile and ML model predictions")

        # Combine all identified gaps (primary + secondary)
        all_gaps = [primary_gap] + secondary_gaps

        return all_gaps, reasoning
