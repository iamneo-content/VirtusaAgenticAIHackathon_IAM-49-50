"""Advanced Plan Generator LLM Agent - Generate challenge-focused learning plans"""

from typing import Dict, Any, Optional
from agents.base_llm_agent import BaseLLMAgent
from utils import GeminiClient


class AdvancedPlanGeneratorLLMAgent(BaseLLMAgent):
    """Generate advanced-focused personalized learning plan via LLM"""

    def __init__(self, client: Optional[GeminiClient] = None):
        """
        Initialize with optional GeminiClient dependency injection.

        Args:
            client: Optional GeminiClient instance (creates new if not provided)
        """
        super().__init__(client)

    def create_advanced_plan(self, analyzed_profile: Dict[str, Any]) -> Dict[str, Any]:
        """
        Create an advanced/expert learning plan using LLM.

        Plan characteristics:
        - Challenge-focused, cutting-edge curriculum
        - Fast learning pace (0.7x timeline multiplier)
        - Advanced concepts and research topics
        - Optional prerequisites (assume solid foundation)
        - Premium resources and expert mentoring

        Args:
            analyzed_profile: Complete analyzed learner profile with metrics and gaps

        Returns:
            Dictionary with plan structure:
            {
                "plan_type": "Advanced",
                "duration_weeks": int,
                "hours_per_week": int,
                "intensity": str,
                "topics": List[str],
                "resources": List[Dict],
                "milestones": List[Dict],
                "prerequisites": List[str],
                "success_criteria": List[str],
                "difficulty_progression": str
            }
        """
        learner_id = analyzed_profile.get("learner_id", "UNKNOWN")
        gaps = analyzed_profile.get("identified_gaps", [])
        domain = analyzed_profile.get("current_proficiency", {}).get("domain", "")
        target_timeline = analyzed_profile.get("goals_analysis", {}).get("target_timeline_months", 12)
        budget = analyzed_profile.get("constraints_analysis", {}).get("budget_usd", 500)

        prompt = f"""You are an expert educational curriculum designer specializing in advanced/expert-level learning paths.

LEARNER PROFILE:
- Learner ID: {learner_id}
- Domain: {domain}
- Target Timeline: {target_timeline} months
- Budget: ${budget}
- Identified Gaps: {', '.join(gaps) if gaps else 'Advanced skill refinement'}

REQUIREMENTS FOR ADVANCED PLAN:
1. Duration: Accelerated timeline (recommended 8-10 weeks)
2. Pace: Fast-paced with deep research and projects
3. Resources: Premium, cutting-edge, research-oriented materials
4. Intensity: High intensity with expert-level challenges
5. Prerequisites: Optional - assumes solid foundation knowledge

RESOURCE COST GUIDELINES FOR ADVANCED LEARNERS:
- Premium courses: Specialized certifications, advanced bootcamps (cost: $150-300)
- Expert mentorship: 1-on-1 coaching, industry expert consultation (cost: $100-500/hour)
- Research access: Academic databases, premium tools, subscriptions (cost: $50-200)
- Conference/workshops: Industry conferences, advanced workshops (cost: $200-500)
- Advanced books: Technical deep-dives, research publications (cost: $30-100)
- Keep total resource cost within budget: ${budget}

DIFFICULTY PROGRESSION GUIDELINES:
For domain "{domain}", progression should be:
1. Review advanced concepts and cutting-edge developments
2. Deep dive into specialized sub-domains or emerging technologies
3. Conduct original research or solve complex real-world problems
4. Publish findings or create thought leadership content
5. Mentor others or contribute to field advancement
Make progression SPECIFIC to "{domain}" and focus on SPECIALIZED expertise.

Generate ONLY a valid JSON response (no markdown, no extra text) with this exact structure:
{{
    "plan_type": "Advanced",
    "duration_weeks": 10,
    "hours_per_week": 16,
    "intensity": "High",
    "topics": ["Advanced Concepts & Research", "Specialized Sub-Domain Mastery", "Original Problem Solving", "Thought Leadership"],
    "resources": [
        {{"title": "Advanced {domain} Certification Program", "type": "premium course", "duration_hours": 35, "cost_usd": 250}},
        {{"title": "Expert Mentorship/Coaching (Industry Professional)", "type": "mentoring", "duration_hours": 15, "cost_usd": 300}},
        {{"title": "Specialized Tools/Software Licenses", "type": "tools/software", "duration_hours": 10, "cost_usd": 150}},
        {{"title": "Research Database/Academic Access", "type": "research access", "duration_hours": 5, "cost_usd": 100}}
    ],
    "milestones": [
        {{"week": 2, "objective": "Master advanced concepts and latest research"}},
        {{"week": 4, "objective": "Define original research or innovation project"}},
        {{"week": 7, "objective": "Complete advanced project or research"}},
        {{"week": 10, "objective": "Publish findings or create thought leadership content"}}
    ],
    "prerequisites": ["Demonstrated mastery of {domain} fundamentals", "Research and independent learning capability"],
    "success_criteria": ["Complete advanced research", "Publish work or demonstrate expertise", "Contribute to field"],
    "difficulty_progression": "Rapid progression through cutting-edge {domain} concepts, specialized research methodologies, complex real-world problem solving, culminating in publication, certification, or thought leadership that advances the field."
}}

IMPORTANT - Cost Instructions:
- Include premium resources reflecting true market costs
- Allocate budget for expert mentorship/consultation (critical for advanced learning)
- Include specialized tools and research access
- Ensure total cost <= ${budget}
- All costs must be realistic (premium courses: $200-300, mentorship: $100+/hour)
- Use SPECIFIC names (Advanced Certification X, Workshop Y, etc.)

Return ONLY the JSON object with NO additional text, markdown formatting, or explanation."""

        response_text = self.generate_response(
            prompt=prompt,
            temperature=0.3,
            max_tokens=2000
        )

        plan_dict = self.extract_json(response_text)
        self.validate_fields(
            plan_dict,
            required_fields=[
                "plan_type", "duration_weeks", "hours_per_week", "intensity",
                "topics", "resources", "milestones", "prerequisites",
                "success_criteria", "difficulty_progression"
            ]
        )

        return plan_dict
