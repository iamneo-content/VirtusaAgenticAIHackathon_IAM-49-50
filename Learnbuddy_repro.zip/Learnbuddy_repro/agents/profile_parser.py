"""Profile Parser Agent - Validate and normalize 20-field learner profile"""

from typing import Dict, Any, List, Tuple


class ProfileParserAgent:
    """Parse and validate learner JSON with simplified 20-field schema"""

    REQUIRED_FIELDS = [
        "learner_id", "age", "education_level", "employment_status",
        "learning_style", "learning_pace", "hours_available_per_week",
        "primary_domain", "current_proficiency_score", "current_topic",
        "primary_goal", "target_timeline_months", "career_aspiration",
        "budget_limit_usd", "certification_needed",
        "learning_history", "challenges_faced", "previous_support_needed"
    ]

    def validate_profile(self, learner_json: Dict[str, Any]) -> Tuple[Dict[str, Any], bool, List[str]]:
        """
        Validate and normalize learner profile (20-field schema).

        Returns: (normalized_profile, is_valid, error_list)
        """
        errors = []

        # Check required fields
        for field in self.REQUIRED_FIELDS:
            if field not in learner_json:
                errors.append(f"Missing required field: {field}")

        if errors:
            return {}, False, errors

        # Validate field types
        try:
            # ID must be string
            if not isinstance(learner_json["learner_id"], str):
                errors.append("learner_id must be string")

            # Age must be numeric
            age = learner_json["age"]
            if not isinstance(age, (int, float)) or age < 8 or age > 100:
                errors.append("age must be numeric between 8-100")

            # Education level validation
            valid_educations = ["primary", "secondary", "bachelor", "master", "phd"]
            if learner_json["education_level"] not in valid_educations:
                errors.append(f"education_level must be one of {valid_educations}")

            # Employment status validation
            valid_statuses = ["unemployed", "employed", "student", "freelance", "self_employed"]
            if learner_json["employment_status"] not in valid_statuses:
                errors.append(f"employment_status must be one of {valid_statuses}")

            # Learning style validation
            valid_styles = ["visual", "auditory", "kinesthetic", "reading_writing", "mixed"]
            if learner_json["learning_style"] not in valid_styles:
                errors.append(f"learning_style must be one of {valid_styles}")

            # Learning pace validation
            valid_paces = ["slow", "moderate", "fast"]
            if learner_json["learning_pace"] not in valid_paces:
                errors.append(f"learning_pace must be one of {valid_paces}")

            # Hours per week validation
            hours = learner_json["hours_available_per_week"]
            if not isinstance(hours, (int, float)) or hours < 0 or hours > 168:
                errors.append("hours_available_per_week must be numeric 0-168")

            # Primary domain validation
            valid_domains = ["Programming", "Data Science", "Design", "Business", "Mathematics", "Language", "Music", "Other"]
            if learner_json["primary_domain"] not in valid_domains:
                errors.append(f"primary_domain must be one of {valid_domains}")

            # Proficiency score validation
            score = learner_json["current_proficiency_score"]
            if not isinstance(score, (int, float)) or score < 0 or score > 100:
                errors.append("current_proficiency_score must be numeric 0-100")

            # Timeline validation
            timeline = learner_json["target_timeline_months"]
            if not isinstance(timeline, int) or timeline < 1 or timeline > 60:
                errors.append("target_timeline_months must be integer 1-60")

            # Budget validation
            budget = learner_json["budget_limit_usd"]
            if not isinstance(budget, (int, float)) or budget < 0:
                errors.append("budget_limit_usd must be numeric >= 0")

            # Certification is boolean
            if not isinstance(learner_json["certification_needed"], bool):
                errors.append("certification_needed must be boolean")

            # Learning history is list
            if not isinstance(learner_json["learning_history"], list):
                errors.append("learning_history must be list")

            # Challenges faced is list
            if not isinstance(learner_json["challenges_faced"], list):
                errors.append("challenges_faced must be list of strings")

            # Previous support is list
            if not isinstance(learner_json["previous_support_needed"], list):
                errors.append("previous_support_needed must be list of strings")

        except (KeyError, ValueError) as e:
            errors.append(f"Validation error: {str(e)}")
            return {}, False, errors

        if errors:
            return {}, False, errors

        # Normalization: lowercase strings
        normalized = {}
        for key, value in learner_json.items():
            if isinstance(value, str):
                normalized[key] = value.strip().lower()
            elif isinstance(value, list):
                normalized[key] = [v.lower() if isinstance(v, str) else v for v in value]
            else:
                normalized[key] = value

        return normalized, True, []
