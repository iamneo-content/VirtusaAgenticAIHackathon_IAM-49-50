"""Beginner Plan Generator LLM Agent - Generate foundation-focused learning plans"""

from typing import Dict, Any, Optional
from agents.base_llm_agent import BaseLLMAgent
from utils import GeminiClient


class BeginnerPlanGeneratorLLMAgent(BaseLLMAgent):
    """Generate beginner-focused personalized learning plan via LLM"""

    def __init__(self, client: Optional[GeminiClient] = None):
        """
        Initialize with optional GeminiClient dependency injection.

        Args:
            client: Optional GeminiClient instance (creates new if not provided)
        """
        super().__init__(client)

    def create_beginner_plan(self, analyzed_profile: Dict[str, Any]) -> Dict[str, Any]:
        """
        Create a beginner-focused learning plan using LLM.

        Plan characteristics:
        - Foundation-focused curriculum
        - Slower learning pace (1.5x timeline multiplier)
        - Includes all prerequisites
        - Emphasis on core concepts
        - Free/low-cost resources prioritized

        Args:
            analyzed_profile: Complete analyzed learner profile with metrics and gaps

        Returns:
            Dictionary with plan structure:
            {
                "plan_type": "Beginner",
                "duration_weeks": int,
                "hours_per_week": int,
                "intensity": str,
                "topics": List[str],
                "resources": List[Dict],
                "milestones": List[Dict],
                "prerequisites": List[str],
                "success_criteria": List[str],
                "difficulty_progression": str
            }
        """
        learner_id = analyzed_profile.get("learner_id", "UNKNOWN")
        gaps = analyzed_profile.get("identified_gaps", [])
        domain = analyzed_profile.get("current_proficiency", {}).get("domain", "")
        target_timeline = analyzed_profile.get("goals_analysis", {}).get("target_timeline_months", 12)
        budget = analyzed_profile.get("constraints_analysis", {}).get("budget_usd", 500)

        prompt = f"""You are an expert educational curriculum designer specializing in beginner-level learning paths.

LEARNER PROFILE:
- Learner ID: {learner_id}
- Domain: {domain}
- Target Timeline: {target_timeline} months
- Budget: ${budget}
- Identified Gaps: {', '.join(gaps) if gaps else 'General foundation gaps'}

REQUIREMENTS FOR BEGINNER PLAN:
1. Duration: Extend timeline by 1.5x (slower pace, recommended 18-24 weeks)
2. Pace: Foundation-focused, cover prerequisites thoroughly
3. Resources: 70% free resources, 30% low-cost paid resources (max $100 total preferred)
4. Intensity: Low intensity with frequent breaks
5. Prerequisites: Include ALL prerequisite topics to master first

RESOURCE COST GUIDELINES FOR BEGINNERS:
- Free resources: Khan Academy, YouTube tutorials, free tier courses (cost: $0)
- Low-cost courses: Coursera audit mode, Udemy sales, eBooks (cost: $0-20)
- Paid courses: Optional premium courses for deep learning (cost: $20-50)
- Books: Digital or library books (cost: $0-30)
- Keep total resource cost within budget: ${budget}

DIFFICULTY PROGRESSION GUIDELINES:
For domain "{domain}", progression should be:
1. Start with foundational concepts and theory
2. Progress to basic tool/framework introduction
3. Move to simple practical exercises
4. End with small projects to apply concepts
Make progression SPECIFIC to "{domain}" and the identified gaps.

Generate ONLY a valid JSON response (no markdown, no extra text) with this exact structure:
{{
    "plan_type": "Beginner",
    "duration_weeks": 20,
    "hours_per_week": 8,
    "intensity": "Low",
    "topics": ["Foundation Concepts", "Core Principles", "Basic Practice", "Assessment"],
    "resources": [
        {{"title": "Free Introduction Course (Coursera audit or YouTube)", "type": "online course", "duration_hours": 25, "cost_usd": 0}},
        {{"title": "Hands-on Practice Platform", "type": "interactive platform", "duration_hours": 20, "cost_usd": 0}},
        {{"title": "Beginner Guide Book/eBook", "type": "reading material", "duration_hours": 15, "cost_usd": 15}}
    ],
    "milestones": [
        {{"week": 2, "objective": "Complete foundational theory module"}},
        {{"week": 6, "objective": "Understand core principles deeply"}},
        {{"week": 12, "objective": "Complete 5+ guided practical exercises"}},
        {{"week": 18, "objective": "Build first small project from scratch"}}
    ],
    "prerequisites": ["Basic computer literacy", "Commitment to 8 hours/week learning"],
    "success_criteria": ["Complete 80% of modules", "Build 1 beginner project", "Score 70%+ on assessments"],
    "difficulty_progression": "Starts with foundational theory of {domain}, gradually introduces core concepts and basic practical applications, building toward simple real-world projects. Each week builds on previous concepts with hands-on practice."
}}

IMPORTANT - Cost Instructions:
- Include 70% free resources (cost: $0)
- Include 30% low-cost resources ($10-20 each)
- Ensure total cost <= ${budget}
- All costs must be realistic numbers (not all $0)
- Explain resource choices based on beginner needs

Return ONLY the JSON object with NO additional text, markdown formatting, or explanation."""

        response_text = self.generate_response(
            prompt=prompt,
            temperature=0.3,
            max_tokens=2000
        )

        plan_dict = self.extract_json(response_text)
        self.validate_fields(
            plan_dict,
            required_fields=[
                "plan_type", "duration_weeks", "hours_per_week", "intensity",
                "topics", "resources", "milestones", "prerequisites",
                "success_criteria", "difficulty_progression"
            ]
        )

        return plan_dict
