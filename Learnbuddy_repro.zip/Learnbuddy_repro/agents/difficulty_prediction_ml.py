"""Difficulty Prediction ML Agent - Uses trained ML Model to predict optimal difficulty level"""

import pickle
import numpy as np
from pathlib import Path
from typing import Dict, Any, Tuple

MODEL_DIR = Path("ml/models")


class DifficultyPredictionMLAgent:
    """Predict optimal difficulty level using trained Logistic Regression - PURE ML ONLY

    Uses 8 simplified numeric features (no categorical encoding needed).
    Only loads 2 artifacts: model + scaler
    """

    def __init__(self):
        # Load model artifacts (2 files only: model + scaler)
        with open(MODEL_DIR / "difficulty_model.pkl", 'rb') as f:
            self.model = pickle.load(f)
        with open(MODEL_DIR / "difficulty_scaler.pkl", 'rb') as f:
            self.scaler = pickle.load(f)

    def predict_difficulty(self, analyzed_profile: Dict[str, Any]) -> Tuple[str, float]:
        """Predict optimal difficulty using 8 simplified numeric features.

        Args:
            analyzed_profile: Analyzed learner profile with ml_features

        Returns:
            Tuple of (difficulty_label, confidence) where difficulty_label is a string prediction
        """
        # Get pre-extracted features from ProfileAnalyzerAgent
        ml_features = analyzed_profile.get("ml_features", {})
        if not ml_features:
            raise ValueError("ML features not found in analyzed_profile")

        numeric_features = ml_features.get("difficulty_numeric", [])

        if not numeric_features or len(numeric_features) != 8:
            raise ValueError(f"Expected 8 numeric features, got {len(numeric_features)}")

        # Prepare and scale features
        numeric_array = np.array(numeric_features).reshape(1, -1)
        X_scaled = self.scaler.transform(numeric_array)

        # Make prediction
        prediction = self.model.predict(X_scaled)[0]

        # Get confidence
        try:
            probabilities = self.model.predict_proba(X_scaled)[0]
            confidence = float(np.max(probabilities))
        except:
            confidence = 0.5

        return prediction, confidence
