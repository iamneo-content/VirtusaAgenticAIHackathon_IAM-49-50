"""Budget Feasibility LLM Agent - Assess plan budget feasibility using LLM reasoning"""

from typing import Dict, Any, Tuple, List, Optional
from agents.base_llm_agent import BaseLLMAgent
from utils import GeminiClient


class BudgetFeasibilityLLMAgent(BaseLLMAgent):
    """Assess learning plan budget feasibility using LLM reasoning"""

    def __init__(self, client: Optional[GeminiClient] = None):
        """
        Initialize with optional GeminiClient dependency injection.

        Args:
            client: Optional GeminiClient instance (creates new if not provided)
        """
        super().__init__(client)

    def validate_budget(self, plan: Dict[str, Any], budget_limit: float) -> Tuple[bool, List[str]]:
        """
        Validate if plan budget requirements fit learner's budget using LLM reasoning.

        Args:
            plan: Generated learning plan with resources (each has cost_usd)
            budget_limit: Learner's budget limit in USD

        Returns:
            Tuple of (validation_passed_bool, issues_list)
            - validation_passed: True if plan fits within budget
            - issues: List of human-readable issues found (empty if passed)
        """
        resources = plan.get("resources", [])
        duration_weeks = plan.get("duration_weeks", 1)

        # Calculate costs
        total_cost = 0.0
        paid_count = 0
        free_count = 0
        resource_list = []

        for resource in resources:
            cost = resource.get("cost_usd", 0.0)
            if isinstance(cost, str):
                try:
                    cost = float(cost)
                except (ValueError, TypeError):
                    cost = 0.0

            total_cost += cost
            name = resource.get("name", "Resource")
            resource_list.append(f"{name} (${cost:.2f})")

            if cost > 0:
                paid_count += 1
            else:
                free_count += 1

        weekly_cost = total_cost / duration_weeks if duration_weeks > 0 else 0

        prompt = f"""You are an expert budget consultant for learning plans. Assess if the plan's budget fits the learner's constraints.

LEARNER BUDGET:
- Budget Limit: ${budget_limit:.2f}
- Plan Duration: {duration_weeks} weeks

PLAN COSTS:
- Total Cost: ${total_cost:.2f}
- Weekly Cost: ${weekly_cost:.2f}/week
- Paid Resources: {paid_count}
- Free Resources: {free_count}
- Resources: {', '.join(resource_list[:5]) if resource_list else 'None listed'}

Evaluate budget feasibility considering:
1. Does total plan cost fit within the budget limit?
2. Is the weekly cost sustainable for the learner?
3. Are there enough free/affordable alternatives if cost is high?
4. Is the resource mix balanced (free vs paid)?
5. Overall, is the plan financially feasible?

Return ONLY valid JSON with NO markdown or extra text:
{{
    "is_feasible": true or false,
    "issues": ["issue1", "issue2"] or [],
    "reasoning": "Brief explanation (1-2 sentences)"
}}

Guidelines:
- Flag if total cost exceeds budget limit
- Warn if weekly cost is unsustainable
- Suggest free alternatives if only paid resources exist
- Consider cost-effectiveness for the learner's budget
- Empty issues list means plan is budget-feasible"""

        response_text = self.generate_response(
            prompt=prompt,
            temperature=0.3,
            max_tokens=350
        )

        result = self.extract_json(response_text)

        is_feasible = result.get("is_feasible", True)
        issues = result.get("issues", [])

        # Ensure issues is a list
        if not isinstance(issues, list):
            issues = [str(issues)] if issues else []

        return (is_feasible, issues)
