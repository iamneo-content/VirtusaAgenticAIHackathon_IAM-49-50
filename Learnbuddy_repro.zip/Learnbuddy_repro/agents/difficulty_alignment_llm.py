"""Difficulty Alignment LLM Agent - Assess plan difficulty alignment using LLM reasoning"""

from typing import Dict, Any, Tuple, List, Optional
from agents.base_llm_agent import BaseLLMAgent
from utils import GeminiClient


class DifficultyAlignmentLLMAgent(BaseLLMAgent):
    """Assess learning plan difficulty alignment using LLM reasoning"""

    def __init__(self, client: Optional[GeminiClient] = None):
        """
        Initialize with optional GeminiClient dependency injection.

        Args:
            client: Optional GeminiClient instance (creates new if not provided)
        """
        super().__init__(client)

    def validate_alignment(self, plan: Dict[str, Any], proficiency_level: str) -> Tuple[bool, List[str]]:
        """
        Validate if plan difficulty aligns with learner's proficiency level using LLM reasoning.

        Args:
            plan: Generated learning plan with intensity, difficulty_progression, prerequisites
            proficiency_level: Learner's proficiency level ("Beginner" / "Intermediate" / "Advanced")

        Returns:
            Tuple of (validation_passed_bool, issues_list)
            - validation_passed: True if difficulty aligns with proficiency
            - issues: List of human-readable issues found (empty if passed)
        """
        intensity = plan.get("intensity", "Unknown")
        progression = plan.get("difficulty_progression", "Unknown")
        prerequisites = plan.get("prerequisites", [])
        topics = plan.get("topics", [])[:3]

        prompt = f"""You are an expert curriculum designer. Assess if the learning plan difficulty is appropriate for the learner's proficiency level.

LEARNER PROFICIENCY:
- Level: {proficiency_level}

PLAN DIFFICULTY:
- Intensity: {intensity}
- Progression: {progression}
- Prerequisites: {', '.join(prerequisites) if prerequisites else 'None'}
- Topics: {', '.join(str(t) for t in topics) if topics else 'Core concepts'}

Evaluate alignment considering:
1. Is plan intensity appropriate for {proficiency_level} level?
   - Beginner: Low intensity, foundational
   - Intermediate: Medium intensity, practical
   - Advanced: High intensity, specialized
2. Is difficulty progression suitable for the proficiency level?
   - Beginner: Gradual, step-by-step progression
   - Intermediate: Moderate pace with increasing complexity
   - Advanced: Rapid, challenging progression
3. Are prerequisites appropriate for the proficiency level?
   - Beginner: Should have 2+ foundational prerequisites
   - Intermediate: Balanced prerequisites
   - Advanced: Minimal or optional prerequisites
4. Overall, does the plan match the learner's capability level?

Return ONLY valid JSON with NO markdown or extra text:
{{
    "is_aligned": true or false,
    "issues": ["issue1", "issue2"] or [],
    "reasoning": "Brief explanation (1-2 sentences)"
}}

Guidelines:
- List specific misalignments between plan and proficiency level
- Consider progression pace vs learner level
- Evaluate prerequisite appropriateness
- Empty issues list means plan is well-aligned"""

        response_text = self.generate_response(
            prompt=prompt,
            temperature=0.3,
            max_tokens=350
        )

        result = self.extract_json(response_text)

        is_aligned = result.get("is_aligned", True)
        issues = result.get("issues", [])

        # Ensure issues is a list
        if not isinstance(issues, list):
            issues = [str(issues)] if issues else []

        return (is_aligned, issues)
