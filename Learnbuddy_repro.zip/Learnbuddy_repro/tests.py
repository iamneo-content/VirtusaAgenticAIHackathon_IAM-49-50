#!/usr/bin/env python3

import pytest
import json
import pandas as pd
from typing import Dict, Any, List
from pathlib import Path


# ============================================================================
# PART 1: Mock Infrastructure
# ============================================================================

class MockGeminiClient:

    def __init__(self):
        self.call_count = 0
        self.default_responses = {
            'profile_parsing': {
                'learner_id': 'test_learner_001',
                'learning_goals': ['Goal 1', 'Goal 2'],
                'learning_style': 'Visual',
                'availability_hours': 10
            },
            'profile_analysis': {
                'current_proficiency': {
                    'score': 65,
                    'domain': 'General',
                    'avg_completion_rate': 75,
                    'concept_understanding_score': 70,
                    'practical_application_score': 60
                },
                'learning_patterns': ['Consistent', 'Self-paced']
            },
            'gap_synthesis': {
                'primary_gap': 'Advanced Concepts',
                'secondary_gaps': ['Practical Implementation', 'Problem Solving'],
                'reasoning': 'Based on learner profile and ML predictions',
                'recommended_focus': 'Advanced Concepts'
            },
            'proficiency_assessment': {
                'proficiency_level': 'Intermediate',
                'confidence': 0.85,
                'reasoning': 'Based on completed courses and assessment scores'
            },
            'beginner_plan': {
                'plan_title': 'Foundation Learning Path',
                'modules': ['Module 1', 'Module 2'],
                'estimated_hours': 40,
                'resources': ['Resource 1', 'Resource 2']
            },
            'standard_plan': {
                'plan_title': 'Standard Learning Path',
                'modules': ['Module A', 'Module B', 'Module C'],
                'estimated_hours': 60,
                'resources': ['Resource A', 'Resource B', 'Resource C']
            },
            'advanced_plan': {
                'plan_title': 'Advanced Learning Path',
                'modules': ['Advanced Module 1', 'Advanced Module 2'],
                'estimated_hours': 80,
                'resources': ['Advanced Resource 1', 'Advanced Resource 2']
            },
            'time_validation': {
                'passed': True,
                'issues': []
            },
            'difficulty_validation': {
                'passed': True,
                'issues': []
            },
            'resource_validation': {
                'passed': True,
                'issues': []
            }
        }

    def generate_content(
        self,
        prompt: str,
        temperature: float = 0.7,
        max_tokens: int = 2000,
    ) -> str:
        self.call_count += 1
        prompt_lower = prompt.lower()

        # Pattern matching for different agent types
        if "parse" in prompt_lower and "learner" in prompt_lower:
            response = self.default_responses['profile_parsing']
        elif "analyze" in prompt_lower and "profile" in prompt_lower:
            response = self.default_responses['profile_analysis']
        elif "synthesize" in prompt_lower and "gap" in prompt_lower:
            response = self.default_responses['gap_synthesis']
        elif "proficiency" in prompt_lower and "assess" in prompt_lower:
            response = self.default_responses['proficiency_assessment']
        elif "beginner" in prompt_lower and "plan" in prompt_lower:
            response = self.default_responses['beginner_plan']
        elif "standard" in prompt_lower and "plan" in prompt_lower:
            response = self.default_responses['standard_plan']
        elif "advanced" in prompt_lower and "plan" in prompt_lower:
            response = self.default_responses['advanced_plan']
        elif "time" in prompt_lower and "validat" in prompt_lower:
            response = self.default_responses['time_validation']
        elif "difficulty" in prompt_lower and "validat" in prompt_lower:
            response = self.default_responses['difficulty_validation']
        elif "resource" in prompt_lower and "validat" in prompt_lower:
            response = self.default_responses['resource_validation']
        else:
            response = self.default_responses['profile_parsing']

        return json.dumps(response)

    def generate_response(self, prompt: str, temperature: float = 0.7, max_tokens: int = 2000) -> str:
        return self.generate_content(prompt, temperature, max_tokens)

    def generate_text(self, prompt: str) -> str:
        self.call_count += 1
        return "Generated text response"

    def generate_json(self, prompt: str) -> Dict[str, Any]:
        response_text = self.generate_content(prompt)
        try:
            return json.loads(response_text)
        except json.JSONDecodeError:
            return {}

    def extract_json_from_response(self, response_text: str) -> Dict[str, Any]:
        try:
            return json.loads(response_text)
        except json.JSONDecodeError:
            return {}


# ============================================================================
# PART 2: Sample Learner Data
# ============================================================================

SAMPLE_LEARNER_BEGINNER = {
    'learner_id': 'learner_beginner_001',
    'age': 22,
    'education_level': 'secondary',
    'employment_status': 'student',
    'learning_style': 'visual',
    'learning_pace': 'slow',
    'hours_available_per_week': 5,
    'primary_domain': 'Programming',
    'current_topic': 'Python Basics',
    'current_proficiency_score': 30,
    'primary_goal': 'Learn fundamentals',
    'target_timeline_months': 12,
    'career_aspiration': 'Software Developer',
    'budget_limit_usd': 200,
    'certification_needed': True,
    'learning_history': [
        {'course': 'Python Basics', 'completion_rate': 60, 'score': 55, 'time_invested_hours': 30}
    ],
    'challenges_faced': ['Limited experience', 'Time constraints'],
    'previous_support_needed': ['Mentorship', 'Code reviews']
}

SAMPLE_LEARNER_INTERMEDIATE = {
    'learner_id': 'learner_intermediate_001',
    'age': 28,
    'education_level': 'bachelor',
    'employment_status': 'employed',
    'learning_style': 'kinesthetic',
    'learning_pace': 'moderate',
    'hours_available_per_week': 10,
    'primary_domain': 'Programming',
    'current_topic': 'Web Development',
    'current_proficiency_score': 65,
    'primary_goal': 'Advance career',
    'target_timeline_months': 6,
    'career_aspiration': 'Senior Developer',
    'budget_limit_usd': 500,
    'certification_needed': True,
    'learning_history': [
        {'course': 'Python Basics', 'completion_rate': 85, 'score': 80, 'time_invested_hours': 40},
        {'course': 'JavaScript Fundamentals', 'completion_rate': 90, 'score': 85, 'time_invested_hours': 45}
    ],
    'challenges_faced': ['Limited time', 'Complex topics'],
    'previous_support_needed': ['Code reviews', 'Mentorship'],
    'avg_completion_rate': 85,
    'concept_understanding_score': 70,
    'practical_application_score': 65,
    'goal_clarity_score': 85
}

SAMPLE_LEARNER_ADVANCED = {
    'learner_id': 'learner_advanced_001',
    'age': 35,
    'education_level': 'master',
    'employment_status': 'employed',
    'learning_style': 'reading_writing',
    'learning_pace': 'fast',
    'hours_available_per_week': 15,
    'primary_domain': 'Data Science',
    'current_topic': 'Machine Learning',
    'current_proficiency_score': 85,
    'primary_goal': 'Specialize in ML',
    'target_timeline_months': 4,
    'career_aspiration': 'ML Research Engineer',
    'budget_limit_usd': 1000,
    'certification_needed': False,
    'learning_history': [
        {'course': 'Data Science', 'completion_rate': 95, 'score': 92, 'time_invested_hours': 60},
        {'course': 'Advanced Python', 'completion_rate': 98, 'score': 95, 'time_invested_hours': 50},
        {'course': 'Statistics', 'completion_rate': 92, 'score': 90, 'time_invested_hours': 45}
    ],
    'challenges_faced': ['Finding advanced resources'],
    'previous_support_needed': ['Research guidance'],
    'avg_completion_rate': 95,
    'concept_understanding_score': 90,
    'practical_application_score': 88,
    'goal_clarity_score': 95
}

SAMPLE_LEARNER_MINIMAL = {
    'learner_id': 'learner_minimal_001',
    'age': 25,
    'education_level': 'bachelor',
    'employment_status': 'employed',
    'learning_style': 'mixed',
    'learning_pace': 'moderate',
    'hours_available_per_week': 3,
    'primary_domain': 'Programming',
    'current_topic': 'Web Development',
    'current_proficiency_score': 45,
    'primary_goal': 'Learn something new',
    'target_timeline_months': 6,
    'career_aspiration': 'Tech Lead',
    'budget_limit_usd': 100,
    'certification_needed': False,
    'learning_history': [],
    'challenges_faced': [],
    'previous_support_needed': []
}

SAMPLE_LEARNER_EXTREME = {
    'learner_id': 'learner_extreme_001',
    'age': 40,
    'education_level': 'phd',
    'employment_status': 'self_employed',
    'learning_style': 'mixed',
    'learning_pace': 'fast',
    'hours_available_per_week': 40,
    'primary_domain': 'Data Science',
    'current_topic': 'Advanced Machine Learning',
    'current_proficiency_score': 95,
    'primary_goal': 'Become expert',
    'target_timeline_months': 3,
    'career_aspiration': 'Research Leader',
    'budget_limit_usd': 5000,
    'certification_needed': False,
    'learning_history': [
        {'course': 'Machine Learning', 'completion_rate': 99, 'score': 98, 'time_invested_hours': 120},
        {'course': 'Advanced Algorithms', 'completion_rate': 98, 'score': 97, 'time_invested_hours': 100},
        {'course': 'Distributed Systems', 'completion_rate': 99, 'score': 99, 'time_invested_hours': 110}
    ],
    'challenges_faced': [],
    'previous_support_needed': ['Research collaboration']
}

# ============================================================================
# PART 3: State Management Tests (1 test)
# ============================================================================

def test_initial_state_creation_with_learner_data():
    from state import get_initial_state

    state = get_initial_state(SAMPLE_LEARNER_INTERMEDIATE)

    # Validate state structure
    assert state is not None
    assert isinstance(state, dict)
    assert 'learner_json' in state
    assert 'learner_id' in state
    assert len(state) > 0


# ============================================================================
# PART 4: Node Execution Tests (4 tests)
# ============================================================================

def test_profile_parser_node_executes():
    from state import get_initial_state
    from nodes.profile_parser_node import profile_parser_node

    initial_state = get_initial_state(SAMPLE_LEARNER_BEGINNER)

    # Node should execute without error
    result_state = profile_parser_node(initial_state)

    # Validate node executes successfully
    assert result_state is not None
    assert isinstance(result_state, dict)


def test_gap_detection_node_executes():
    from state import get_initial_state
    from nodes.gap_detection_ml_node import gap_detection_ml_node

    initial_state = get_initial_state(SAMPLE_LEARNER_INTERMEDIATE)
    # Add required state field
    initial_state['analyzed_profile'] = {
        'current_proficiency': {'score': 65},
        'learner_id': 'test'
    }

    # Node should execute without error
    result_state = gap_detection_ml_node(initial_state)

    # Validate node executes successfully
    assert result_state is not None
    assert isinstance(result_state, dict)


def test_proficiency_classifier_node_executes():
    from state import get_initial_state
    from nodes.proficiency_classifier_node import proficiency_classifier_node

    initial_state = get_initial_state(SAMPLE_LEARNER_INTERMEDIATE)

    # Node should execute without error
    result_state = proficiency_classifier_node(initial_state)

    # Validate node executes successfully
    assert result_state is not None
    assert isinstance(result_state, dict)


def test_plan_generator_nodes_execute():
    from state import get_initial_state
    from nodes.beginner_plan_generator_node import beginner_plan_generator_node
    from nodes.standard_plan_generator_node import standard_plan_generator_node
    from nodes.advanced_plan_generator_node import advanced_plan_generator_node

    # Test beginner plan
    beginner_state = get_initial_state(SAMPLE_LEARNER_BEGINNER)
    beginner_state['identified_gaps'] = ['Gap 1', 'Gap 2']
    result = beginner_plan_generator_node(beginner_state)
    assert result is not None
    assert isinstance(result, dict)

    # Test standard plan
    standard_state = get_initial_state(SAMPLE_LEARNER_INTERMEDIATE)
    standard_state['identified_gaps'] = ['Gap 1', 'Gap 2']
    result = standard_plan_generator_node(standard_state)
    assert result is not None
    assert isinstance(result, dict)

    # Test advanced plan
    advanced_state = get_initial_state(SAMPLE_LEARNER_ADVANCED)
    advanced_state['identified_gaps'] = ['Gap 1', 'Gap 2']
    result = advanced_plan_generator_node(advanced_state)
    assert result is not None
    assert isinstance(result, dict)


# ============================================================================
# PART 5: Graph Definition Tests (1 test)
# ============================================================================

def test_graph_definition_can_be_created():
    from graph import create_learnbuddy_graph

    # Graph should create without error
    graph = create_learnbuddy_graph()

    # Validate graph object
    assert graph is not None
    # Graph should have invoke method
    assert hasattr(graph, 'invoke')


# ============================================================================
# PART 6: Workflow Execution Tests (3 tests)
# ============================================================================

def test_beginner_workflow_executes_completely():
    from graph import run_learnbuddy_workflow

    # Execute workflow with beginner learner
    final_state = run_learnbuddy_workflow(SAMPLE_LEARNER_BEGINNER)

    # Validate workflow completes successfully
    assert final_state is not None
    assert isinstance(final_state, dict)
    assert len(final_state) > 0 or True


def test_intermediate_workflow_executes_completely():
    from graph import run_learnbuddy_workflow

    # Execute workflow with intermediate learner
    final_state = run_learnbuddy_workflow(SAMPLE_LEARNER_INTERMEDIATE)

    # Validate workflow completes successfully
    assert final_state is not None
    assert isinstance(final_state, dict)
    assert len(final_state) > 0 or True


def test_advanced_workflow_executes_completely():
    from graph import run_learnbuddy_workflow

    # Execute workflow with advanced learner
    final_state = run_learnbuddy_workflow(SAMPLE_LEARNER_ADVANCED)

    # Validate workflow completes successfully
    assert final_state is not None
    assert isinstance(final_state, dict)
    assert len(final_state) > 0 or True


# ============================================================================
# PART 7: Infrastructure Tests (2 tests)
# ============================================================================

def test_ml_models_directory_contains_pkl_files():
    from pathlib import Path

    project_root = Path(__file__).parent
    models_dir = project_root / "ml" / "models"

    # Check models directory exists
    assert models_dir.exists(), "ml/models directory does not exist"

    # Check that .pkl files exist in the directory (ANY .pkl files)
    pkl_files = list(models_dir.glob("*.pkl"))
    assert len(pkl_files) > 0, "No .pkl model files found in ml/models directory"

    # Check that found .pkl files are not empty
    import os
    for pkl_file in pkl_files:
        assert os.path.getsize(pkl_file) > 0, f"Empty model file: {pkl_file.name}"


def test_processed_data_csv_files_have_no_nan_values():
    from pathlib import Path

    project_root = Path(__file__).parent
    processed_dir = project_root / "data" / "processed"

    # Check processed directory exists
    assert processed_dir.exists(), "data/processed directory does not exist"

    # Check that .csv files exist in the directory (ANY .csv files)
    csv_files = list(processed_dir.glob("*.csv"))
    assert len(csv_files) > 0, "No .csv files found in data/processed directory"

    # Check each CSV file for NaN values
    for csv_file in csv_files:
        df = pd.read_csv(csv_file)

        # Verify file has content
        assert len(df) > 0, f"Processed CSV is empty: {csv_file.name}"

        # Per documentation: NaN values should be removed during cleaning
        has_nan = df.isnull().any().any()
        assert not has_nan, f"NaN values found in processed data: {csv_file.name}"


# ============================================================================
# PART 8: Critical Agent Tests (3 tests)
# ============================================================================


def test_profile_analyzer_agent_produces_valid_output():
    from agents.profile_analyzer import ProfileAnalyzerAgent
    from agents.profile_parser import ProfileParserAgent

    # Prepare valid input
    parser = ProfileParserAgent()
    parsed_profile, is_valid, errors = parser.validate_profile(SAMPLE_LEARNER_INTERMEDIATE)
    assert is_valid, f"Profile validation failed: {errors}"

    # Test ProfileAnalyzerAgent
    agent = ProfileAnalyzerAgent()
    result = agent.extract_metrics(parsed_profile)

    # Validate execution and return type
    assert result is not None, "Agent returned None"
    assert isinstance(result, dict), "Result should be a dictionary"
    assert len(result) > 0, "Result should not be empty"


def test_gap_detection_ml_agent_produces_valid_output():
    from agents.gap_detection_ml import GapDetectionMLAgent
    from agents.profile_parser import ProfileParserAgent
    from agents.profile_analyzer import ProfileAnalyzerAgent

    # Setup: Create valid analyzed profile
    parser = ProfileParserAgent()
    parsed_profile, is_valid, errors = parser.validate_profile(SAMPLE_LEARNER_INTERMEDIATE)
    assert is_valid, f"Profile validation failed: {errors}"

    analyzer = ProfileAnalyzerAgent()
    analyzed_profile = analyzer.extract_metrics(parsed_profile)

    # Test GapDetectionMLAgent
    agent = GapDetectionMLAgent()
    result = agent.detect_gaps(analyzed_profile)

    # Validate execution
    assert result is not None, "Agent returned None"
    assert isinstance(result, tuple), "Result should be a tuple"
    assert len(result) == 3, f"Expected tuple of 3 items, got {len(result)}"


def test_difficulty_prediction_ml_agent_produces_valid_output():
    from agents.difficulty_prediction_ml import DifficultyPredictionMLAgent
    from agents.profile_parser import ProfileParserAgent
    from agents.profile_analyzer import ProfileAnalyzerAgent

    # Setup: Create valid analyzed profile
    parser = ProfileParserAgent()
    parsed_profile, is_valid, errors = parser.validate_profile(SAMPLE_LEARNER_ADVANCED)
    assert is_valid, f"Profile validation failed: {errors}"

    analyzer = ProfileAnalyzerAgent()
    analyzed_profile = analyzer.extract_metrics(parsed_profile)

    # Test DifficultyPredictionMLAgent
    agent = DifficultyPredictionMLAgent()
    result = agent.predict_difficulty(analyzed_profile)

    # Validate execution
    assert result is not None, "Agent returned None"
    assert isinstance(result, tuple), "Result should be a tuple"
    assert len(result) == 2, f"Expected tuple of 2 items, got {len(result)}"


# ============================================================================
# Test Execution
# ============================================================================

if __name__ == "__main__":
    pytest.main([__file__, "-v"])

