#!/usr/bin/env python3
"""
LearnBuddy Phase 2 - Streamlit Web Interface

Personalized learning plan generation with conditional routing,
proficiency classification, and multi-stage validation.
"""

import streamlit as st
import json
import os
from pathlib import Path
from dotenv import load_dotenv
from workflow import workflow_instance

try:
    from ml.evaluation.evaluate_models import evaluate_all_models
except ImportError:
    pass

load_dotenv()

st.set_page_config(
    page_title="LearnBuddy",
    page_icon="book",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.markdown("""
    <style>
    .stTabs [data-baseweb="tab-list"] button [data-testid="stMarkdownContainer"] p {
        font-size: 1.2rem;
    }
    .metric-container {
        background-color: #f0f2f6;
        padding: 10px;
        border-radius: 5px;
    }
    </style>
""", unsafe_allow_html=True)


def main():
    """Main Streamlit application"""

    # Initialize session state
    if "run_evaluation" not in st.session_state:
        st.session_state.run_evaluation = False
    if "eval_results" not in st.session_state:
        st.session_state.eval_results = None
    if "sample_profile" not in st.session_state:
        st.session_state.sample_profile = None
    if "analysis_result" not in st.session_state:
        st.session_state.analysis_result = None
    if "run_analysis" not in st.session_state:
        st.session_state.run_analysis = False

    st.title("LearnBuddy")
    st.markdown("### AI-Powered Personalized Learning Plan Generator")

    st.markdown("---")

    with st.expander("Important Disclaimer"):
        st.warning("""
            **Educational Use Only**: This system generates personalized learning recommendations
            based on AI analysis. This is NOT a substitute for professional educational guidance.

            - Results are for informational purposes only
            - Consult with educational professionals for formal guidance
            - Individual learning outcomes vary based on dedication and effort
            - Plans should be adapted based on actual progress
        """)

    st.markdown("---")

    with st.sidebar:
        st.header("Learner Selection")

        sample_dir = Path("data/input")
        if sample_dir.exists():
            json_files = sorted([f.name for f in sample_dir.glob("learn_*.json")])

            selected_file = st.selectbox(
                "Choose a sample learner profile",
                options=json_files,
                help="Select from pre-generated learner profiles"
            )

            if selected_file:
                profile_path = sample_dir / selected_file
                with open(profile_path, 'r') as f:
                    st.session_state.sample_profile = json.load(f)

                profile = st.session_state.sample_profile
                st.success(f"Loaded: {profile.get('learner_id', 'Unknown')}")

                with st.expander("View Profile Summary"):
                    col1, col2 = st.columns(2)
                    with col1:
                        st.metric("Age", profile.get("age", "N/A"))
                        st.metric("Education", profile.get("education_level", "N/A").title())
                    with col2:
                        st.metric("Learning Style", profile.get("learning_style", "N/A").title())
                        st.metric("Proficiency", f"{profile.get('current_proficiency_score', 0)}/100")

        else:
            st.error("Profile directory not found")
            st.session_state.sample_profile = None

        st.divider()
        st.subheader("Tools")

        if st.button("Run Model Evaluation", use_container_width=True, type="secondary"):
            st.session_state.run_evaluation = True

    st.markdown("---")

    col1, col2, col3, col4 = st.columns(4)

    with col1:
        st.info("Step 1: Profile & ML")
    with col2:
        st.info("Step 2: Classify")
    with col3:
        st.info("Step 3: Generate")
    with col4:
        st.info("Step 4: Validate")

    st.markdown("---")

    if st.button("Generate Personalized Learning Plan", use_container_width=True, type="primary"):
        if st.session_state.sample_profile is None:
            st.error("Please select a learner profile first")
            return
        st.session_state.run_analysis = True

    # Run analysis if triggered
    if st.session_state.run_analysis:
        if st.session_state.sample_profile is not None:
            progress_bar = st.progress(0, text="Initializing workflow...")

            try:
                progress_bar.progress(10, text="Parsing profile...")
                with st.spinner("AI is analyzing and generating your personalized plan..."):
                    result = workflow_instance.run_workflow(st.session_state.sample_profile)
                    st.session_state.analysis_result = result

                progress_bar.progress(100, text="Complete")
                st.success("Plan generated successfully!")
                st.session_state.run_analysis = False

            except Exception as e:
                st.error(f"Error generating plan: {str(e)}")
                st.exception(e)
                st.session_state.run_analysis = False
                result = None
        else:
            st.error("No profile selected")

    # Display results if available
    if st.session_state.analysis_result is not None:
        result = st.session_state.analysis_result

        st.success("Personalized learning plan generated successfully!")

        # Create tabs for Phase 2
        tab1, tab2, tab3, tab4, tab5 = st.tabs(
            ["Analysis", "Generated Plan", "Validation Results", "Coaching & Report", "Download"]
        )

        with tab1:
            st.subheader("Analysis Results")

            # Proficiency Classification (Phase 2)
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                proficiency_level = result.get("learner_proficiency_level", "Unknown")
                st.metric(
                    "Proficiency Level",
                    proficiency_level,
                    help="Classification: Beginner/Intermediate/Advanced"
                )

            with col2:
                proficiency_conf = result.get("proficiency_confidence", 0)
                st.metric(
                    "Confidence",
                    f"{proficiency_conf*100:.0f}%",
                    help="Classification confidence"
                )

            with col3:
                identified_gaps = result.get("identified_gaps", [])
                st.metric(
                    "Identified Gaps",
                    len(identified_gaps) if identified_gaps else 0,
                    help="Number of learning gaps detected"
                )

            with col4:
                difficulty = result.get("recommended_difficulty", "N/A")
                confidence = result.get("difficulty_confidence", 0)
                st.metric(
                    "Recommended Difficulty",
                    difficulty if difficulty else "N/A",
                    f"{confidence*100:.0f}% confidence" if confidence else "N/A"
                )

            st.divider()
            st.subheader("Detected Learning Gaps:")
            gaps = result.get("identified_gaps", [])
            if gaps and len(gaps) > 0:
                gap_scores = result.get("gap_confidence_scores", {})
                for gap in gaps:
                    confidence = gap_scores.get(gap, 0)
                    st.write(f"• **{gap.replace('_', ' ').title()}** ({confidence:.0%} confidence)")
            else:
                st.info("No specific gaps detected")

        with tab2:
            st.subheader("Your Personalized Learning Plan")

            plan = result.get("generated_plan", {})
            if not plan:
                st.warning("Plan generation in progress. Please check error messages below.")
                # Show error messages if plan failed
                error_messages = result.get("error_messages", [])
                if error_messages:
                    st.error("Generation Issues:")
                    for msg in error_messages:
                        st.write(f"• {msg}")

            if plan:
                col1, col2, col3, col4 = st.columns(4)

                with col1:
                    st.metric(
                        "Plan Type",
                        plan.get("plan_type", "Unknown"),
                        help="Beginner/Standard/Advanced based on proficiency"
                    )

                with col2:
                    st.metric(
                        "Duration",
                        f"{plan.get('duration_weeks', 0)} weeks",
                        help="Total weeks to complete"
                    )

                with col3:
                    st.metric(
                        "Weekly Commitment",
                        f"{plan.get('hours_per_week', 0)} hours",
                        help="Hours per week required"
                    )

                with col4:
                    st.metric(
                        "Intensity",
                        str(plan.get("intensity", "N/A")).upper(),
                        help="Low/Medium/High"
                    )

                st.divider()

                # Topics
                col1, col2 = st.columns([1, 1])
                with col1:
                    st.subheader("Learning Topics")
                    topics = plan.get("topics", [])
                    if topics:
                        for i, topic in enumerate(topics, 1):
                            st.write(f"{i}. {topic}")
                    else:
                        st.info("No topics defined")

                with col2:
                    st.subheader("Key Milestones")
                    milestones = plan.get("milestones", [])
                    if milestones:
                        for milestone in milestones[:5]:
                            week = milestone.get("week", "?")
                            objective = milestone.get("objective", "?")
                            st.write(f"Week {week}: {objective}")
                        if len(milestones) > 5:
                            st.info(f"+ {len(milestones)-5} more milestones")
                    else:
                        st.info("No milestones defined")

                st.divider()

                # Resources
                st.subheader("Learning Resources")
                resources = plan.get("resources", [])
                if resources:
                    for resource in resources[:10]:
                        title = resource.get("title", "Unknown")
                        res_type = resource.get("type", "Unknown")
                        duration = resource.get("duration_hours", 0)
                        cost = resource.get("cost_usd", 0)
                        st.write(f"- {title} ({res_type}) - {duration}h - ${cost}")
                    if len(resources) > 10:
                        st.info(f"+ {len(resources)-10} more resources")
                else:
                    st.info("No resources defined")

                st.divider()

                # Difficulty Progression
                st.subheader("Difficulty Progression")
                progression = plan.get("difficulty_progression", "Not specified")
                st.info(progression)
            else:
                st.error("Plan not generated")

        with tab3:
            st.subheader("Plan Validation Results")

            col1, col2, col3 = st.columns(3)

            # Time Validation
            with col1:
                st.subheader("Time Feasibility")
                time_passed = result.get("time_validation_passed", False)
                if time_passed:
                    st.success("PASSED - Plan fits within time constraints")
                else:
                    st.warning("ISSUES DETECTED - Plan may exceed time constraints")

                time_issues = result.get("time_validation_issues", [])
                if time_issues:
                    st.write("Issues found:")
                    for issue in time_issues:
                        st.write(f"• {issue}")
                else:
                    st.write("No time-related issues found")

            # Difficulty Validation
            with col2:
                st.subheader("Difficulty Alignment")
                diff_passed = result.get("difficulty_validation_passed", False)
                if diff_passed:
                    st.success("PASSED - Plan difficulty matches proficiency")
                else:
                    st.warning("ISSUES DETECTED - Difficulty may not align with proficiency")

                diff_issues = result.get("difficulty_validation_issues", [])
                if diff_issues:
                    st.write("Issues found:")
                    for issue in diff_issues:
                        st.write(f"• {issue}")
                else:
                    st.write("No difficulty-related issues found")

            # Resource Validation
            with col3:
                st.subheader("Budget Feasibility")
                res_passed = result.get("resource_validation_passed", False)
                if res_passed:
                    st.success("PASSED - Plan cost within budget")
                else:
                    st.warning("ISSUES DETECTED - Plan cost may exceed budget")

                res_issues = result.get("resource_validation_issues", [])
                if res_issues:
                    st.write("Issues found:")
                    for issue in res_issues:
                        st.write(f"• {issue}")
                else:
                    st.write("No budget-related issues found")

            st.divider()

            # Validation Summary
            all_passed = (
                result.get("time_validation_passed", False) and
                result.get("difficulty_validation_passed", False) and
                result.get("resource_validation_passed", False)
            )

            if all_passed:
                st.success("All validations passed - Plan is ready for execution")
            else:
                st.warning("Some validations detected issues - Review above before starting")

        with tab4:
            st.subheader("Personalized Coaching Guidance")
            st.caption("AI-generated personalized coaching text (variable length, tailored to your profile)")

            coaching = result.get("plan_friendly", "")
            if coaching:
                st.info(coaching)
            else:
                st.info("Coaching guidance not available")

            st.divider()
            st.subheader("Complete Learning Plan Report")

            report_json = result.get("report_json", {})
            if report_json:
                # Display report in professional format instead of raw JSON

                # Learner & Proficiency section
                st.markdown("#### Learner Proficiency")
                col1, col2 = st.columns(2)
                with col1:
                    st.write(f"**Learner ID:** {report_json.get('learner_id', 'N/A')}")
                    proficiency = report_json.get("proficiency", {})
                    st.write(f"**Level:** {proficiency.get('level', 'N/A')}")
                with col2:
                    conf = proficiency.get('confidence', 0)
                    st.write(f"**Confidence:** {conf*100:.1f}%")

                st.markdown("---")

                # Analysis section
                st.markdown("#### Learning Gap Analysis")
                analysis = report_json.get("analysis", {})
                col1, col2 = st.columns(2)
                with col1:
                    gaps = analysis.get("gaps", [])
                    st.write(f"**Identified Gaps:** {len(gaps)}")
                    if gaps:
                        for gap in gaps[:5]:
                            st.write(f"• {gap.replace('_', ' ').title()}")
                        if len(gaps) > 5:
                            st.write(f"+ {len(gaps)-5} more gaps")
                with col2:
                    st.write(f"**Gap Urgency:** {analysis.get('gap_urgency', 'N/A').upper()}")
                    st.write(f"**Recommended Difficulty:** {analysis.get('recommended_difficulty', 'N/A')}")
                    diff_conf = analysis.get('difficulty_confidence', 0)
                    st.write(f"**Difficulty Confidence:** {diff_conf*100:.1f}%")

                st.markdown("---")

                # Plan section
                st.markdown("#### Selected Learning Plan")
                plan = report_json.get("selected_plan", {})
                if plan:
                    col1, col2, col3, col4 = st.columns(4)
                    with col1:
                        st.metric("Plan Type", plan.get("plan_type", "N/A"))
                    with col2:
                        st.metric("Duration", f"{plan.get('duration_weeks', 0)} weeks")
                    with col3:
                        st.metric("Weekly Hours", f"{plan.get('hours_per_week', 0)}h")
                    with col4:
                        st.metric("Intensity", str(plan.get("intensity", "N/A")).upper())

                    # Plan details
                    col1, col2 = st.columns(2)
                    with col1:
                        topics = plan.get("topics", [])
                        st.write(f"**Topics** ({len(topics)})")
                        for topic in topics[:5]:
                            st.write(f"• {topic}")
                        if len(topics) > 5:
                            st.write(f"+ {len(topics)-5} more topics")
                    with col2:
                        milestones = plan.get("milestones", [])
                        st.write(f"**Milestones** ({len(milestones)})")
                        for milestone in milestones[:3]:
                            st.write(f"• Week {milestone.get('week', '?')}: {milestone.get('objective', '?')[:40]}...")
                        if len(milestones) > 3:
                            st.write(f"+ {len(milestones)-3} more milestones")

                st.markdown("---")

                # Validation section
                st.markdown("#### Validation Summary")
                validation = report_json.get("validation_results", {})
                col1, col2, col3 = st.columns(3)

                with col1:
                    time_status = "PASSED" if validation.get("time", {}).get("passed", False) else "ISSUES"
                    st.write(f"**Time Feasibility:** {time_status}")
                    time_issues = validation.get("time", {}).get("issues", [])
                    if time_issues:
                        for issue in time_issues[:2]:
                            st.caption(f"⚠ {issue[:60]}")

                with col2:
                    diff_status = "PASSED" if validation.get("difficulty", {}).get("passed", False) else "ISSUES"
                    st.write(f"**Difficulty Alignment:** {diff_status}")
                    diff_issues = validation.get("difficulty", {}).get("issues", [])
                    if diff_issues:
                        for issue in diff_issues[:2]:
                            st.caption(f"⚠ {issue[:60]}")

                with col3:
                    res_status = "PASSED" if validation.get("resource", {}).get("passed", False) else "ISSUES"
                    st.write(f"**Budget Feasibility:** {res_status}")
                    res_issues = validation.get("resource", {}).get("issues", [])
                    if res_issues:
                        for issue in res_issues[:2]:
                            st.caption(f"⚠ {issue[:60]}")

                st.markdown("---")

                # Raw JSON option
                with st.expander("View Raw JSON Report"):
                    st.json(report_json)
            else:
                st.info("Detailed report not available")

        with tab5:
            st.subheader("Download Your Plan")

            col1, col2 = st.columns(2)

            with col1:
                json_report = result.get("report_json", {})
                if json_report:
                    st.download_button(
                        label="Download JSON Report",
                        data=json.dumps(json_report, indent=2),
                        file_name="microplan_report.json",
                        mime="application/json"
                    )
                else:
                    st.info("JSON report not available")

            with col2:
                st.info("Text report format deprecated")

            output_dir = result.get("output_dir", "N/A")
            st.success(f"Files saved to: {output_dir}")


    # Handle model evaluation trigger from sidebar
    if st.session_state.run_evaluation:
        try:
            with st.spinner("Evaluating ML models..."):
                eval_results = evaluate_all_models()
                st.session_state.eval_results = eval_results
                st.success("Model evaluation complete!")
        except Exception as e:
            st.error(f"Evaluation failed: {str(e)}")
        finally:
            st.session_state.run_evaluation = False

    # Display model evaluation results if available
    st.divider()
    render_model_evaluation_section(st.session_state.get("eval_results"))


def render_model_evaluation_section(eval_results):
    """Render ML model evaluation metrics on the main page."""
    st.markdown("### ML Model Evaluation")
    st.markdown("Performance metrics of trained machine learning models")

    if not eval_results:
        st.info("Click 'Run Model Evaluation' in the sidebar to evaluate trained models.")
        return

    col1, col2 = st.columns(2)

    with col1:
        st.subheader("Gap Detection Model")
        gap_eval = eval_results.get("gap_evaluation", {})
        if gap_eval and "error" not in gap_eval:
            st.metric("Accuracy", f"{gap_eval.get('accuracy', 0)*100:.2f}%")
            st.metric("Hamming Loss", f"{gap_eval.get('hamming_loss', 0):.4f}")
            st.metric("Test Samples", gap_eval.get('samples', 0))
        else:
            st.error(f"Error: {gap_eval.get('error', 'Unknown error')}")

    with col2:
        st.subheader("Difficulty Prediction Model")
        difficulty_eval = eval_results.get("difficulty_evaluation", {})
        if difficulty_eval and "error" not in difficulty_eval:
            st.metric("Accuracy", f"{difficulty_eval.get('accuracy', 0)*100:.2f}%")
            st.metric("Cross-Val Score", f"{difficulty_eval.get('cv_score', 0)*100:.2f}%")
            st.metric("Test Samples", difficulty_eval.get('samples', 0))
        else:
            st.error(f"Error: {difficulty_eval.get('error', 'Unknown error')}")

    st.divider()
    with st.expander("View Raw Evaluation Data"):
        st.json(eval_results)


if __name__ == "__main__":
    main()
