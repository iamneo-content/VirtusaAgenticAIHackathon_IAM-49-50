#!/usr/bin/env python3
"""LearnBuddy LangGraph - 13-node personalized learning plan generation with conditional routing"""

from typing import Dict, Any
from langgraph.graph import StateGraph, START, END

from state import LearnerPlanState, get_initial_state

# Phase 1 nodes (existing)
from nodes.profile_parser_node import profile_parser_node
from nodes.profile_analyzer_node import profile_analyzer_node
from nodes.gap_detection_ml_node import gap_detection_ml_node
from nodes.difficulty_prediction_ml_node import difficulty_prediction_ml_node

# Phase 2 nodes (new)
from nodes.proficiency_classifier_node import proficiency_classifier_node
from nodes.beginner_plan_generator_node import beginner_plan_generator_node
from nodes.standard_plan_generator_node import standard_plan_generator_node
from nodes.advanced_plan_generator_node import advanced_plan_generator_node
from nodes.time_validator_node import time_validator_node
from nodes.difficulty_validator_node import difficulty_validator_node
from nodes.resource_validator_node import resource_validator_node

# Adapted nodes
from nodes.personal_coach_node import personal_coach_node
from nodes.report_generator_node import report_generator_node


def route_by_proficiency(state: LearnerPlanState) -> str:
    """
    Conditional routing based on learner proficiency level.

    Routes to appropriate plan generator:
    - "Beginner" → beginner_plan_generator
    - "Intermediate" → standard_plan_generator
    - "Advanced" → advanced_plan_generator

    Args:
        state: Current state with learner_proficiency_level

    Returns:
        String with next node name
    """
    proficiency_level = state.get("learner_proficiency_level", "Intermediate")

    if proficiency_level == "Beginner":
        return "beginner_plan_generator"
    elif proficiency_level == "Advanced":
        return "advanced_plan_generator"
    else:
        return "standard_plan_generator"


def create_learnbuddy_graph():
    """
    Build LearnBuddy Phase 2 workflow with conditional routing.

    Defined nodes: 13 total
    Executed nodes: 11 per workflow run (due to conditional routing)

    Node structure:
    1. profile_parser
    2. profile_analyzer
    3. gap_detection_ml (parallel with 4)
    4. difficulty_prediction_ml (parallel with 3)
    5. proficiency_classifier
    6. [CONDITIONAL] beginner_plan_generator (if Beginner proficiency)
    7. [CONDITIONAL] standard_plan_generator (if Intermediate proficiency)
    8. [CONDITIONAL] advanced_plan_generator (if Advanced proficiency)
       (Only ONE of nodes 6/7/8 executes per workflow)
    9. time_validator (parallel with 10, 11)
    10. difficulty_validator (parallel with 9, 11)
    11. resource_validator (parallel with 9, 10)
    12. personal_coach
    13. report_generator

    Typical execution flow: Nodes 1→2→3→4→5→(6 or 7 or 8)→9→10→11→12→13 = 11 nodes
    """
    workflow = StateGraph(LearnerPlanState)

    # Add all 13 nodes
    # Phase 1 nodes
    workflow.add_node("profile_parser", profile_parser_node)
    workflow.add_node("profile_analyzer", profile_analyzer_node)
    workflow.add_node("gap_detection_ml", gap_detection_ml_node)
    workflow.add_node("difficulty_prediction_ml", difficulty_prediction_ml_node)

    # Phase 2 proficiency classification
    workflow.add_node("proficiency_classifier", proficiency_classifier_node)

    # Phase 2 conditional plan generation
    workflow.add_node("beginner_plan_generator", beginner_plan_generator_node)
    workflow.add_node("standard_plan_generator", standard_plan_generator_node)
    workflow.add_node("advanced_plan_generator", advanced_plan_generator_node)

    # Phase 2 parallel validators
    workflow.add_node("time_validator", time_validator_node)
    workflow.add_node("difficulty_validator", difficulty_validator_node)
    workflow.add_node("resource_validator", resource_validator_node)

    # Final nodes (adapted for Phase 2)
    workflow.add_node("personal_coach", personal_coach_node)
    workflow.add_node("report_generator", report_generator_node)

    # Set entry point
    workflow.set_entry_point("profile_parser")

    # Phase 1 edges (sequential)
    workflow.add_edge("profile_parser", "profile_analyzer")

    # ML analysis edges (parallel)
    workflow.add_edge("profile_analyzer", "gap_detection_ml")
    workflow.add_edge("profile_analyzer", "difficulty_prediction_ml")

    # Proficiency classification (after ML converges)
    workflow.add_edge("gap_detection_ml", "proficiency_classifier")
    workflow.add_edge("difficulty_prediction_ml", "proficiency_classifier")

    # Conditional routing to plan generators
    workflow.add_conditional_edges(
        "proficiency_classifier",
        route_by_proficiency,
        {
            "beginner_plan_generator": "beginner_plan_generator",
            "standard_plan_generator": "standard_plan_generator",
            "advanced_plan_generator": "advanced_plan_generator",
        }
    )

    # Parallel validators (all three generators lead to all three validators)
    workflow.add_edge("beginner_plan_generator", "time_validator")
    workflow.add_edge("beginner_plan_generator", "difficulty_validator")
    workflow.add_edge("beginner_plan_generator", "resource_validator")

    workflow.add_edge("standard_plan_generator", "time_validator")
    workflow.add_edge("standard_plan_generator", "difficulty_validator")
    workflow.add_edge("standard_plan_generator", "resource_validator")

    workflow.add_edge("advanced_plan_generator", "time_validator")
    workflow.add_edge("advanced_plan_generator", "difficulty_validator")
    workflow.add_edge("advanced_plan_generator", "resource_validator")

    # Validators converge to coaching
    workflow.add_edge("time_validator", "personal_coach")
    workflow.add_edge("difficulty_validator", "personal_coach")
    workflow.add_edge("resource_validator", "personal_coach")

    # Final edges
    workflow.add_edge("personal_coach", "report_generator")
    workflow.add_edge("report_generator", END)

    return workflow.compile()


def run_learnbuddy_workflow(learner_json: Dict[str, Any]) -> LearnerPlanState:
    """
    Execute LearnBuddy Phase 2 personalized learning plan generation.

    Workflow:
    1. Parse learner profile
    2. Analyze profile and extract metrics
    3. Run ML models in parallel (gap detection, difficulty prediction)
    4. Classify learner proficiency level
    5. Route to appropriate plan generator (Beginner/Standard/Advanced)
    6. Validate plan with three validators in parallel (time, difficulty, resource)
    7. Generate personalized coaching guidance
    8. Generate and save final report

    Args:
        learner_json: Raw learner input (18 required fields)

    Returns:
        Complete LearnerPlanState with all generated outputs
    """
    initial_state = get_initial_state(learner_json)

    print("\n" + "=" * 70)
    print("LEARNBUDDY PHASE 2 - PERSONALIZED LEARNING PLAN GENERATOR")
    print("13 Nodes with Conditional Routing")
    print("=" * 70)

    graph = create_learnbuddy_graph()
    result = graph.invoke(initial_state)

    print("\n" + "=" * 70)
    print("WORKFLOW COMPLETE!")
    print("=" * 70)

    return result


if __name__ == "__main__":
    print("LearnBuddy Phase 2 Graph Interface")
    print("Use: run_learnbuddy_workflow(learner_json)")

