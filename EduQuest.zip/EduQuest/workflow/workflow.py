"""Workflow orchestration and utilities for EduQuest.

This module provides helper functions and orchestration utilities.
The actual graph definition is in graph.py
"""

from typing import Dict, Any


def get_workflow_metadata() -> Dict[str, Any]:
    """Get metadata about the EduQuest workflow.

    Returns:
        Dictionary with workflow configuration and metadata
    """
    return {
        "workflow_name": "EduQuest Career Guidance System",
        "version": "1.0.0",
        "description": "AI-powered career guidance using 3-tier adaptive routing",
        "entry_point": "graph.assess_career",
        "graph_builder": "graph.build_eduquest_graph",
    }


def get_routing_logic() -> Dict[str, Any]:
    """Get the routing logic rules for path selection.

    Returns:
        Dictionary describing routing thresholds and paths
    """
    return {
        "routing_field": "viability_score",
        "routing_type": "conditional_edges",
        "paths": {
            "HARD_PATH": {
                "description": "Challenging career transition requiring deep analysis",
                "condition": "viability_score < 0.3",
                "execution_strategy": "sequential_with_alternatives",
                "token_budget": 5400,
                "nodes_count": 12,
            },
            "MEDIUM_PATH": {
                "description": "Moderate career transition with balanced guidance",
                "condition": "0.3 <= viability_score < 0.6",
                "execution_strategy": "sequential_optimized",
                "token_budget": 2200,
                "nodes_count": 10,
            },
            "EASY_PATH": {
                "description": "Optimal career transition with quick guidance",
                "condition": "viability_score >= 0.6",
                "execution_strategy": "sequential_fast",
                "token_budget": 1550,
                "nodes_count": 10,
            },
        },
    }


def get_parallel_execution_info() -> Dict[str, Any]:
    """Get information about parallel execution opportunities.

    Returns:
        Dictionary describing which nodes can run in parallel
    """
    return {
        "parallel_stages": [
            {
                "stage": "ML Prediction",
                "nodes": ["career_viability_scorer", "academic_career_matcher"],
                "dependencies": ["ml_results_merger"],
                "description": "Both ML models run in parallel, results merged before routing",
            },
        ],
        "sequential_stages": [
            "Input validation and profile extraction",
            "ML prediction (parallel internally)",
            "Path routing",
            "Path-specific LLM agent execution",
            "Output aggregation",
        ],
    }


def get_token_budget_info() -> Dict[str, Any]:
    """Get token budget breakdown for different paths.

    Returns:
        Dictionary with token estimates per agent
    """
    return {
        "total_tokens_per_path": {
            "HARD_PATH": 5400,
            "MEDIUM_PATH": 2200,
            "EASY_PATH": 1550,
        },
        "tokens_per_agent": {
            "profile_extractor": 300,
            "reality_check_full": 800,
            "reality_check_medium": 400,
            "reality_check_light": 250,
            "financial_planner": 1200,
            "roadmap_builder_full": 1500,
            "roadmap_builder_medium": 800,
            "roadmap_builder_light": 500,
            "alternative_explorer": 600,
            "market_context_full": 700,
            "market_context_medium": 500,
            "market_context_light": 400,
        },
        "ml_tokens": 300,
    }


def get_execution_strategy() -> Dict[str, Any]:
    """Get information about workflow execution strategy.

    Returns:
        Dictionary describing how the workflow executes
    """
    return {
        "execution_model": "stateful_graph_execution",
        "state_management": "TypedDict with 60+ fields",
        "error_handling": "per_node_try_catch_with_aggregation",
        "client_pattern": "dependency_injection_via_lambda",
        "compilation_strategy": "lazy_compilation_per_request",
        "invocation_method": "graph.invoke(state)",
    }
