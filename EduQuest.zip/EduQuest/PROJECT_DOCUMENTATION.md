================================================================================
                    EDUQUEST CAREER GUIDANCE SYSTEM
                        PROJECT DOCUMENTATION
================================================================================

PROJECT OVERVIEW
================================================================================

EduQuest is an AI-powered career guidance and personalized transition planning
system that assesses career viability and generates customized career transition
roadmaps based on comprehensive user profiles, aspirations, and constraints.

The system leverages a hybrid architecture combining LLM-based intelligent
analysis with machine learning predictions to provide adaptive, multi-tier
career guidance tailored to the complexity of each user's career transition.


PROBLEM STATEMENT & DESCRIPTION
================================================================================

PROBLEM DEFINITION
---

Career transitions represent significant challenges for professionals. Most
individuals lack comprehensive guidance on:

1. Feasibility Assessment
   - Can they realistically achieve their target career?
   - What are actual success probabilities?
   - How do their current credentials align with target requirements?

2. Structured Planning
   - What concrete steps are required?
   - What is a realistic timeline?
   - What resources and funding are needed?

3. Risk Understanding
   - What are major obstacles?
   - What financial implications exist?
   - What alternative paths exist if primary goal is not viable?

4. Market Intelligence
   - What is job market demand?
   - What are salary expectations?
   - Where are job opportunities concentrated?
   - What certifications are required?

CURRENT CHALLENGES
---

Traditional career counseling:
- Is expensive and time-consuming
- Provides subjective, generic advice
- Lacks data-driven feasibility assessment
- Offers no personalized roadmaps
- Provides limited market context
- Cannot handle large-scale demand

SOLUTION APPROACH
---

EduQuest addresses these challenges through:

1. Intelligent Profile Extraction
   - Converts free-text user inputs to structured career profiles
   - Uses LLM to intelligently infer missing information
   - Standardizes diverse input formats

2. Data-Driven Viability Prediction
   - ML models quantify career transition feasibility
   - Predicts success probability and academic alignment
   - Provides confidence scores for decision-making

3. Adaptive Guidance Architecture
   - Routes users to appropriate analysis depth based on viability
   - HARD_PATH: Deep comprehensive analysis for challenging transitions
   - MEDIUM_PATH: Balanced analysis for moderate transitions
   - EASY_PATH: Quick guidance for natural progressions

4. Comprehensive Roadmapping
   - LLM generates personalized transition roadmaps
   - Timeline varies by complexity (12 months to 3-phase)
   - Includes milestones, resources, and success criteria

5. Financial Planning
   - Cost estimation for career transition
   - Funding source identification
   - ROI analysis and payback periods
   - Risk mitigation strategies

6. Alternative Exploration
   - Suggests viable alternative careers
   - Explains similarity and transition effort
   - Provides fallback options for low-viability goals

7. Market Intelligence
   - Job demand trends and growth forecasts
   - Salary ranges across experience levels
   - Geographic concentration of opportunities
   - Required certifications and skills


FILE STRUCTURE
================================================================================

EduQuest/
   agents/                          Agent implementations (business logic)
      __init__.py                  Package initialization with imports
      base_llm_agent.py            Base class for all LLM agents
      input_validator_agent.py     Input validation logic
      profile_extractor_llm.py     LLM-based profile extraction
      career_viability_scorer_ml.py ML model for viability prediction
      academic_career_matcher_ml.py ML model for academic fit
      reality_check_full_llm.py    Comprehensive reality check (HARD)
      reality_check_medium_llm.py  Balanced reality check (MEDIUM)
      reality_check_light_llm.py   Brief reality check (EASY)
      financial_planner_llm.py     Financial planning analysis
      roadmap_builder_full_llm.py  12-month detailed roadmap (HARD)
      roadmap_builder_medium_llm.py Quarterly roadmap (MEDIUM)
      roadmap_builder_light_llm.py 3-phase foundation roadmap (EASY)
      alternative_explorer_llm.py   Alternative career exploration
      market_context_full_llm.py    Comprehensive market analysis (HARD)
      market_context_medium_llm.py  Moderate market analysis (MEDIUM)
      market_context_light_llm.py   Brief market analysis (EASY)

   nodes/                          Workflow nodes (orchestration)
      __init__.py                  Package initialization with imports
      input_validator_node.py      Validation workflow node
      profile_extractor_node.py    Profile extraction workflow node
      career_viability_scorer_node.py Viability scoring node
      academic_career_matcher_node.py Academic fit scoring node
      ml_results_merger_node.py    ML results aggregation node
      viability_router_node.py     Path routing logic node
      reality_check_full_node.py   HARD path reality check node
      reality_check_medium_node.py MEDIUM path reality check node
      reality_check_light_node.py  EASY path reality check node
      financial_planner_node.py    Financial planning node
      roadmap_builder_full_node.py HARD path roadmap node
      roadmap_builder_medium_node.py MEDIUM path roadmap node
      roadmap_builder_light_node.py EASY path roadmap node
      alternative_explorer_node.py Alternative exploration node
      market_context_full_node.py  HARD path market context node
      market_context_medium_node.py MEDIUM path market context node
      market_context_light_node.py EASY path market context node
      output_aggregator_node.py    Final output aggregation node

   ml/                             Machine learning pipeline
      __init__.py                  Package initialization
      train_pipeline.py            ML training orchestrator (functions only)
      train_model/
         __init__.py              Package initialization
         train_viability_scorer.py Training for viability ML model
         train_academic_matcher.py Training for academic fit ML model
      data_cleaning/
         __init__.py              Package initialization
         clean_viability_data.py  Data cleaning for viability dataset
         clean_academic_matcher_data.py Data cleaning for academic dataset
      evaluation/
         __init__.py              Package initialization
         evaluate_models.py       ML model evaluation (functions only)
      models/                      Trained model artifacts (pickle files)
         career_viability_model.pkl
         career_viability_scaler.pkl
         career_viability_encoder.pkl
         academic_matcher_model.pkl
         academic_matcher_scaler.pkl
         academic_matcher_encoder.pkl

   utils/                          Utility modules
      __init__.py                  Package initialization
      gemini_client.py             Gemini API client with key rotation

   workflow/                       Workflow utilities
      __init__.py                  Package initialization
      workflow.py                  Workflow metadata and orchestration (functions only)

   data/                           Datasets
      training_dataset/            Raw training data
         career_viability_training.csv
         academic_matcher_training.csv
      evaluation_dataset/          Evaluation data for model testing
         career_viability_evaluation.csv
         academic_matcher_evaluation.csv
      processed/                   Cleaned and processed data
         career_viability_clean.csv       Cleaned viability training data (NaN/duplicates removed, outliers via IQR)
         academic_matcher_clean.csv       Cleaned academic fit training data (NaN/duplicates removed, outliers via IQR)

   state.py                        Central state management (TypedDict definition)
   graph.py                        LangGraph workflow orchestration (functions)
   main.py                         Streamlit UI application
   tests.py                        Unit and integration tests
   .env                            Configuration and API keys
   installation.txt                Python dependencies


PURPOSE OF KEY FILES
================================================================================

state.py
   Defines EduQuestState TypedDict central to entire application
   Manages 60+ fields tracking user input, profile, predictions, outputs
   Includes reducer functions for concurrent update conflict prevention
   Initializes state with default values for new assessments

graph.py
   Builds and orchestrates LangGraph workflow
   Defines 18 workflow nodes and their connections
   Implements conditional routing based on ML predictions
   Provides entry point function assess_career() for assessment execution
   Contains helper functions for workflow introspection and summarization

main.py
   Streamlit-based user interface
   Collects 5 free-text input fields from users
   Displays assessment results in 4 tabbed sections
   Provides model evaluation metrics and export functionality
   Handles session state management and caching

gemini_client.py
   Manages Google Gemini API interactions
   Implements API key rotation for rate limit handling
   Provides JSON parsing with error recovery
   Implements structured JSON generation with field validation

train_pipeline.py
   Orchestrates complete ML training workflow
   Manages data cleaning, model training, evaluation
   Saves trained model artifacts as pickle files

workflow.py
   Provides workflow metadata and introspection functions
   Documents routing logic, token budgets, execution strategy
   Supplies workflow structure information for debugging


MODULE BREAKDOWN: AGENTS (Business Logic Layer)
================================================================================

AGENT: BaseLLMAgent
===================

PURPOSE
   Base class for all LLM-based agents in the system
   Provides shared initialization and Gemini client management
   Ensures consistent client handling across 11 LLM agents

CLASS STRUCTURE
   Inheritance: Standalone class (no parent)
   Scope: agents/base_llm_agent.py

IMPORTANT METHODS

   Method: __init__
   Parameters: client (GeminiClient instance)
   Logic: Validates client is not None, stores for use by subclasses
   Returns: None
   Raises: ValueError if client is None

METHODS INHERITED BY SUBCLASSES
   All 11 LLM agents inherit:
   - self.client reference for API calls
   - No other inherited behavior


AGENT: InputValidatorAgent
===========================

PURPOSE
   Validates raw user input text fields for quality and completeness
   Enforces minimum and maximum length requirements
   Ensures all 5 required input fields are provided

CLASS STRUCTURE
   Inheritance: Standalone class (no parent)
   Scope: agents/input_validator_agent.py
   Constants: MIN_LENGTH = 50, MAX_LENGTH = 2000

IMPORTANT METHODS

   Method: validate_inputs
   Parameters: raw_inputs (Dictionary with 5 keys: dream_career,
              current_academics, constraints, interests, other_concerns)
   Logic:
      Iterates through each input field
      Strips whitespace and checks for empty strings
      Validates length is >= MIN_LENGTH and <= MAX_LENGTH
      Accumulates validation errors for all violations
      Returns whether all fields are valid
   Returns: Dictionary containing validation_errors (List), is_valid (Boolean),
            status (String: "success")


AGENT: ProfileExtractorLLMAgent
================================

PURPOSE
   Converts 5 free-text input fields into structured 11-field profile
   Uses LLM intelligence to infer missing information
   Standardizes diverse input formats into consistent structure

CLASS STRUCTURE
   Inheritance: Extends BaseLLMAgent
   Scope: agents/profile_extractor_llm.py

IMPORTANT METHODS

   Method: extract_structured_profile
   Parameters: raw_inputs (Dictionary with 5 text fields)
   Configuration: Temperature = 0.3 (deterministic), Max_tokens = 800
   Logic:
      Crafts detailed prompt with explicit extraction instructions
      Requests 11 specific structured fields
      Includes rules for inferring missing information
      Uses low temperature for consistent, reproducible results
      Calls client.generate_structured_json() with validation
   Returns: Dictionary with extracted_profile (containing 11 fields) and
            status ("success")

   Extracted Profile Fields:
      career_field (String: target career name)
      current_education_level (String: degree and field)
      years_of_experience (Integer >= 0)
      budget_constraint (String: financial situation)
      timeline_urgency (String: transition timeline)
      interests_list (List: at least 2 interests)
      concerns_list (List: at least 2 concerns)
      current_degree_field (String: subject of degree)
      gpa_percentile (Float 0.0-1.0: relative GPA strength)
      research_experience_months (Integer: total research/project months)
      project_portfolio_count (Integer: count of notable projects)


AGENT: CareerViabilityScorerMLAgent
====================================

PURPOSE
   Predicts career transition viability on 0-1 scale
   Uses trained regression model
   Quantifies probability of successfully achieving target career

CLASS STRUCTURE
   Inheritance: Standalone class (no parent)
   Scope: agents/career_viability_scorer_ml.py
   Models Loaded: 3 artifacts (model, scaler, encoder) from pickle files

IMPORTANT METHODS

   Method: __init__
   Logic: Loads 3 pickled artifacts from ml/models/ directory
          Disables parallel processing (n_jobs=1) for thread safety
   Returns: None
   Raises: Exception if pickle files not found

   Method: predict_viability
   Parameters: profile (Dictionary with extracted profile fields)
   Logic:
      Extracts 8 features from profile (4 categorical + 4 numerical)
      Encodes categorical features using saved LabelEncoder
      Handles unseen categories by defaulting to most common class
      Scales features using saved StandardScaler
      Runs prediction through loaded regression model
      Clips result to valid range [0.0, 1.0]
   Returns: Dictionary with viability_score (Float 0-1), status ("success")

   Features Used:
      Categorical: career_field, current_education_level,
                   budget_constraint, timeline_urgency
      Numerical: years_of_experience, gpa_percentile,
                research_experience_months, project_portfolio_count

   Model Details:
      Algorithm: Regression Model
      Parameters: 100 estimators, 0.1 learning rate, max_depth=5
      Training: 80% train / 20% test split
      Scaling: StandardScaler applied to all features


AGENT: AcademicCareerMatcherMLAgent
====================================

PURPOSE
   Predicts academic-to-career fit on 0-100 scale
   Uses trained regression model
   Assesses how well user's academic background matches target career

CLASS STRUCTURE
   Inheritance: Standalone class (no parent)
   Scope: agents/academic_career_matcher_ml.py
   Models Loaded: 3 artifacts (model, scaler, encoder) from pickle files

IMPORTANT METHODS

   Method: __init__
   Logic: Loads 3 pickled artifacts from ml/models/ directory
          Disables parallel processing for thread safety
   Returns: None
   Raises: Exception if pickle files not found

   Method: predict_fit
   Parameters: profile (Dictionary with extracted profile fields)
   Logic:
      Extracts 4 features from profile (1 categorical + 3 numerical)
      Uses current_degree_field as primary categorical feature
      Falls back to current_education_level if current_degree_field missing
      Encodes categorical feature using saved LabelEncoder
      Handles unseen categories by using most common class
      Scales features using saved StandardScaler
      Runs prediction through loaded regression model
      Clips result to valid range [0.0, 100.0]
   Returns: Dictionary with academic_fit_score (Float 0-100), status ("success")

   Features Used:
      Categorical: current_degree_field
      Numerical: gpa_percentile, research_experience_months,
                project_portfolio_count

   Model Details:
      Algorithm: Regression Model
      Parameters: 100 estimators, max_depth=15
      Training: 80% train / 20% test split
      Scaling: StandardScaler applied to all features


AGENT: RealityCheckFullLLMAgent
================================

PURPOSE
   Provides deep, honest reality assessment for challenging career transitions
   Used only in HARD_PATH (viability < 0.3)
   Identifies 4 major obstacles and required mindset shifts

CLASS STRUCTURE
   Inheritance: Extends BaseLLMAgent
   Scope: agents/reality_check_full_llm.py

IMPORTANT METHODS

   Method: generate_reality_check
   Parameters: profile (Dictionary with user profile fields),
              ml_results (Dictionary with viability_score and academic_fit_score)
   Configuration: Temperature = 0.5 (moderate creativity), Max_tokens = 1000
   Logic:
      Constructs prompt combining profile and ML scores
      Requests 4 specific outputs: honest assessment, major challenges
                                   (4 items), success probability,
                                   mindset requirements (3 items)
      Emphasizes brutally honest assessment of feasibility
      References ML scores in success probability
      Calls client.generate_structured_json() with field validation
   Returns: Dictionary with reality_check (containing 4 fields) and
            status ("success")

   Output Fields:
      honest_assessment (String: paragraph-long feasibility assessment)
      major_challenges (List of 4: real, specific obstacles)
      success_probability (String: percentage or probability description)
      mindset_requirements (List of 3: psychological shifts needed)


AGENT: RealityCheckMediumLLMAgent
==================================

PURPOSE
   Provides balanced reality assessment for moderate career transitions
   Used only in MEDIUM_PATH (0.3 <= viability < 0.6)
   Identifies 3 major challenges and 2 required mindset shifts

CLASS STRUCTURE
   Inheritance: Extends BaseLLMAgent
   Scope: agents/reality_check_medium_llm.py

IMPORTANT METHODS

   Method: generate_reality_check
   Parameters: profile (Dictionary with user profile fields),
              ml_results (Dictionary with viability_score and academic_fit_score)
   Configuration: Temperature = 0.5, Max_tokens = 600
   Logic:
      Constructs balanced prompt acknowledging strengths and challenges
      Requests 4 outputs with reduced scope: honest assessment,
                major_challenges (3 items), success_probability,
                mindset_requirements (2 items)
      Balances realistic assessment with encouragement
      Calls client.generate_structured_json() with field validation
   Returns: Dictionary with reality_check (containing 4 fields) and
            status ("success")


AGENT: RealityCheckLightLLMAgent
=================================

PURPOSE
   Provides brief, encouraging reality assessment for optimal transitions
   Used only in EASY_PATH (viability >= 0.6)
   Identifies 2 challenges and 1 key mindset shift

CLASS STRUCTURE
   Inheritance: Extends BaseLLMAgent
   Scope: agents/reality_check_light_llm.py

IMPORTANT METHODS

   Method: generate_reality_check
   Parameters: profile (Dictionary with user profile fields),
              ml_results (Dictionary with viability_score and academic_fit_score)
   Configuration: Temperature = 0.5, Max_tokens = 350
   Logic:
      Constructs brief, encouraging prompt
      Requests minimal outputs: honest_assessment (2-3 sentences),
                major_challenges (2 items), success_probability (positive tone),
                mindset_requirements (1 item)
      Tone emphasizes alignment and achievability
      Calls client.generate_structured_json() with field validation
   Returns: Dictionary with reality_check (containing 4 fields) and
            status ("success")


AGENT: FinancialPlannerLLMAgent
================================

PURPOSE
   Generates comprehensive financial analysis for career transition
   Used only in HARD_PATH
   Covers costs, funding sources, ROI, salary ranges, risk mitigation

CLASS STRUCTURE
   Inheritance: Extends BaseLLMAgent
   Scope: agents/financial_planner_llm.py

IMPORTANT METHODS

   Method: generate_financial_plan
   Parameters: profile (Dictionary with user profile fields),
              reality_check (Dictionary with reality check outputs)
   Configuration: Temperature = 0.6, Max_tokens = 1200
   Logic:
      Constructs detailed financial prompt from profile and reality check
      Requests 8 specific financial outputs
      Emphasizes realistic cost estimates and actionable funding sources
      References user's budget constraints from profile
      Calls client.generate_structured_json() with field validation
   Returns: Dictionary with financial_plan (containing 8 fields) and
            status ("success")

   Output Fields:
      estimated_total_cost (String: cost with currency and range)
      cost_breakdown (Nested Dictionary: education, certification,
                     living_expenses, other)
      funding_sources (List of 3+: specific, actionable sources)
      monthly_budget (String: recommended monthly investment)
      roi_analysis (String: return on investment paragraph with payback period)
      market_salary_range (String: current vs target career salary comparison)
      financial_timeline (String: timeline for financial recovery)
      risk_mitigation (List of 2+: financial strategies)


AGENT: RoadmapBuilderFullLLMAgent
==================================

PURPOSE
   Generates detailed 12-month career transition roadmap
   Used only in HARD_PATH
   Covers 3 phases (months 1-3, 4-8, 9-12) with goals and actions

CLASS STRUCTURE
   Inheritance: Extends BaseLLMAgent
   Scope: agents/roadmap_builder_full_llm.py

IMPORTANT METHODS

   Method: generate_roadmap
   Parameters: profile (Dictionary with user profile fields),
              ml_results (Dictionary with viability_score and academic_fit_score)
   Configuration: Temperature = 0.5, Max_tokens = 1500
   Logic:
      Constructs detailed roadmap prompt from profile and timeline
      Requests 6 structured outputs with 12-month coverage
      Emphasizes specific, actionable goals and milestones
      Includes prerequisite courses in appropriate phases
      References user's timeline and budget constraints
      Calls client.generate_structured_json() with field validation
   Returns: Dictionary with roadmap (containing 6 fields) and status ("success")

   Output Fields:
      phase_1_months (Dictionary: months "1-3", goals List[3], actions List[3])
      phase_2_months (Dictionary: months "4-8", goals List[3], actions List[3])
      phase_3_months (Dictionary: months "9-12", goals List[3], actions List[3])
      key_milestones (List of 4: measurable milestones)
      success_resources (List of 3+: courses, certifications, communities)
      timeline_notes (String: timeline adjustments and critical information)


AGENT: RoadmapBuilderMediumLLMAgent
====================================

PURPOSE
   Generates quarterly (4-quarter) career transition roadmap
   Used only in MEDIUM_PATH
   Covers progression across 4 quarters with goals and actions

CLASS STRUCTURE
   Inheritance: Extends BaseLLMAgent
   Scope: agents/roadmap_builder_medium_llm.py

IMPORTANT METHODS

   Method: generate_roadmap
   Parameters: profile (Dictionary with user profile fields),
              ml_results (Dictionary with viability_score and academic_fit_score),
              prerequisite_courses (Optional List of prerequisite courses)
   Configuration: Temperature = 0.5, Max_tokens = 900
   Logic:
      Constructs quarterly roadmap prompt
      Requests 6 outputs covering 4-quarter progression
      Includes prerequisite courses in appropriate quarters
      Emphasizes progressive advancement toward career goal
      Calls client.generate_structured_json() with field validation
   Returns: Dictionary with roadmap (containing 6 fields) and status ("success")

   Output Fields:
      q1/q2/q3/q4 (Dictionary: goals List[2-3], actions List[2-3])
      key_milestones (List of 3: measurable milestones)
      resources (List of 3+: courses and learning resources)


AGENT: RoadmapBuilderLightLLMAgent
===================================

PURPOSE
   Generates 3-phase high-level career transition roadmap
   Used only in EASY_PATH
   Covers foundation, development, and transition phases

CLASS STRUCTURE
   Inheritance: Extends BaseLLMAgent
   Scope: agents/roadmap_builder_light_llm.py

IMPORTANT METHODS

   Method: generate_roadmap
   Parameters: profile (Dictionary with user profile fields),
              ml_results (Dictionary with viability_score and academic_fit_score),
              prerequisite_courses (Optional List of prerequisite courses)
   Configuration: Temperature = 0.5, Max_tokens = 600
   Logic:
      Constructs brief 3-phase roadmap prompt
      Requests 5 outputs with high-level structure
      Emphasizes achievability and clear direction
      Includes prerequisite courses in appropriate phases
      Calls client.generate_structured_json() with field validation
   Returns: Dictionary with roadmap (containing 5 fields) and status ("success")

   Output Fields:
      phase_1_foundation (Dictionary: duration String, focus String,
                         actions List[3])
      phase_2_development (Dictionary: duration String, focus String,
                          actions List[3])
      phase_3_transition (Dictionary: duration String, focus String,
                         actions List[3])
      key_milestones (List of 2-3: measurable milestones)
      critical_resources (List of 2-3: courses and resources)


AGENT: AlternativeExplorerLLMAgent
===================================

PURPOSE
   Explores alternative career paths when primary goal has low viability
   Used only in HARD_PATH
   Suggests 5 alternative careers with similarity, viability, and effort

CLASS STRUCTURE
   Inheritance: Extends BaseLLMAgent
   Scope: agents/alternative_explorer_llm.py

IMPORTANT METHODS

   Method: explore_alternatives
   Parameters: profile (Dictionary with user profile fields),
              viability_score (Float 0-1: primary career viability)
   Configuration: Temperature = 0.7 (more creative), Max_tokens = 1200
   Logic:
      Constructs prompt emphasizing low viability of primary goal
      Requests 5 alternatives sharing skills or interests with dream career
      Each alternative includes 5 attributes describing it
      Requests 1-2 paragraph summary explaining alternatives
      Emphasizes alternatives should be viable given user's profile
      Calls client.generate_structured_json() with field validation
   Returns: Dictionary with alternatives (List of 5), summary (String),
            status ("success")

   Alternative Fields (each of 5):
      career (String: alternative career name)
      similarity_to_dream (String: 1-2 sentence explanation of similarity)
      viability_estimate (String: "high", "medium", or "low")
      reasoning (String: why good alternative given user profile)
      transition_effort (String: "Low", "Moderate", or "High")


AGENT: MarketContextFullLLMAgent
=================================

PURPOSE
   Provides comprehensive market context for target career
   Used only in HARD_PATH
   Covers 9 dimensions of market intelligence

CLASS STRUCTURE
   Inheritance: Extends BaseLLMAgent
   Scope: agents/market_context_full_llm.py

IMPORTANT METHODS

   Method: get_market_context
   Parameters: career_field (String: target career name)
   Configuration: Temperature = 0.4 (factual), Max_tokens = 1000
   Logic:
      Constructs detailed market analysis prompt
      Requests 9 specific market intelligence fields
      References 2024-2025 current market data
      Emphasizes salary ranges in INR with level breakdowns
      Includes geographic concentration and emerging opportunities
      Calls client.generate_structured_json() with field validation
   Returns: Dictionary with market_context (containing 9 fields) and
            status ("success")

   Output Fields:
      job_demand_trend (String: current and projected demand)
      salary_range_inr (String: entry/mid/senior salary ranges in INR)
      growth_forecast (String: 5-year growth forecast with percentage)
      geographic_hotspots (List of 3: top locations in India and globally)
      required_certifications (List of 2+: relevant recognized certifications)
      industry_insights (String: current industry status and trends)
      competitive_landscape (String: realistic competition and differentiation)
      emerging_opportunities (List of 2+: new, specific opportunities)
      market_risks (List of 2+: market-related risks)


AGENT: MarketContextMediumLLMAgent
===================================

PURPOSE
   Provides moderate market context for target career
   Used only in MEDIUM_PATH
   Covers 9 dimensions with reduced detail

CLASS STRUCTURE
   Inheritance: Extends BaseLLMAgent
   Scope: agents/market_context_medium_llm.py

IMPORTANT METHODS

   Method: get_market_context
   Parameters: career_field (String: target career name)
   Configuration: Temperature = 0.4, Max_tokens = 600
   Logic:
      Constructs moderate market analysis prompt
      Requests same 9 fields as Full agent
      Emphasizes key information without excessive detail
      Includes top 2 geographic hotspots in India
      Calls client.generate_structured_json() with field validation
   Returns: Dictionary with market_context (containing 9 fields) and
            status ("success")


AGENT: MarketContextLightLLMAgent
==================================

PURPOSE
   Provides brief market context for target career
   Used only in EASY_PATH
   Covers 9 dimensions with minimal detail

CLASS STRUCTURE
   Inheritance: Extends BaseLLMAgent
   Scope: agents/market_context_light_llm.py

IMPORTANT METHODS

   Method: get_market_context
   Parameters: career_field (String: target career name)
   Configuration: Temperature = 0.4, Max_tokens = 350
   Logic:
      Constructs brief market overview prompt
      Requests same 9 fields as other agents
      Emphasizes brief, encouraging responses (1-2 sentences per field)
      Focuses on positive outlook
      Calls client.generate_structured_json() with field validation
   Returns: Dictionary with market_context (containing 9 fields) and
            status ("success")


MODULE BREAKDOWN: NODES (Workflow Orchestration)
================================================================================

NODE PATTERN
===================

All nodes follow standard pattern:

Signature: node_name(state: EduQuestState, [client: GeminiClient]) -> EduQuestState

Logic Flow:
   1. Try block: Execute business logic
   2. Update relevant state fields
   3. Catch block: Add to error_messages, set error_occurred=True
   4. Return modified state

Nodes requiring LLM calls receive client via lambda wrapping in graph.py


NODE: input_validator_node
===========================

PURPOSE
   Validates all 5 raw user input text fields
   First node in workflow, ensures data quality
   Sets validation_complete flag for downstream nodes

LOGIC FLOW
   Creates InputValidatorAgent (no client needed)
   Passes 5 input fields from state
   Receives validation_errors list and is_valid boolean
   Updates state: validation_errors, parsing_complete flag
   If invalid, sets error_occurred=True and accumulates errors
   Returns updated state

STATE CHANGES
   Sets: validation_errors (List), parsing_complete (Boolean),
         error_occurred (Boolean if validation fails),
         error_messages (append if validation fails)


NODE: profile_extractor_node
=============================

PURPOSE
   Extracts structured 11-field profile from free-text inputs
   Second node in workflow, depends on input_validator_node
   Populates individual profile fields in state for downstream use

LOGIC FLOW
   Receives client via function parameter
   Creates ProfileExtractorLLMAgent(client)
   Passes 5 raw input fields to LLM agent
   Receives extracted_profile Dictionary with 11 fields
   Copies all 11 extracted fields into individual state fields
   If extraction fails, sets error flags
   Returns updated state

STATE CHANGES
   Sets: extracted_profile (Dictionary), profile_extraction_complete (Boolean),
         career_field, current_education_level, years_of_experience,
         budget_constraint, timeline_urgency, interests_list, concerns_list,
         current_degree_field, gpa_percentile, research_experience_months,
         project_portfolio_count (all from extracted_profile)


NODE: career_viability_scorer_node
===================================

PURPOSE
   Predicts career transition viability using ML model
   Runs in parallel with academic_career_matcher_node
   Produces 0-1 viability score for routing decision

LOGIC FLOW
   Creates CareerViabilityScorerMLAgent (no client needed)
   Gets extracted_profile from state
   Calls predict_viability with 8 features
   Receives viability_score (Float 0-1)
   Updates state with score
   If prediction fails, sets error flags
   Returns updated state

STATE CHANGES
   Sets: viability_score (Float 0-1)


NODE: academic_career_matcher_node
===================================

PURPOSE
   Predicts academic-to-career fit using ML model
   Runs in parallel with career_viability_scorer_node
   Produces 0-100 academic fit score for routing decision

LOGIC FLOW
   Creates AcademicCareerMatcherMLAgent (no client needed)
   Gets extracted_profile from state
   Calls predict_fit with 4 features
   Receives academic_fit_score (Float 0-100)
   Updates state with score
   If prediction fails, sets error flags
   Returns updated state

STATE CHANGES
   Sets: academic_fit_score (Float 0-100)


NODE: ml_results_merger_node
=============================

PURPOSE
   Merges two ML predictions into single feasibility score
   Pure logic node, no agents
   Calculates weighted average for routing threshold

LOGIC FLOW
   Reads viability_score and academic_fit_score from state
   Applies weighted formula:
      overall_feasibility = viability_score * 0.6 +
                           (academic_fit_score / 100) * 0.4
   Clips result to valid range [0.0, 1.0]
   Updates state
   No error handling needed (pure logic)
   Returns updated state

STATE CHANGES
   Sets: overall_feasibility (Float 0-1, clipped)


NODE: viability_router_node
============================

PURPOSE
   Routes workflow to appropriate path based on viability score
   Pure logic node, determines workflow branch
   Sets path_taken and budget_tier for subsequent nodes

LOGIC FLOW
   Reads viability_score from state
   Applies thresholds to determine path:
      IF viability_score < 0.3 THEN HARD_PATH
      ELIF viability_score < 0.6 THEN MEDIUM_PATH
      ELSE EASY_PATH
   Sets path_taken to routing decision
   Sets budget_tier corresponding to path
   No error handling needed
   Returns updated state

STATE CHANGES
   Sets: path_taken (String: "HARD_PATH", "MEDIUM_PATH", or "EASY_PATH"),
         daily_budget_tier (String: "hard_path", "medium_path", or "easy_path")


NODE: reality_check_full_node
==============================

PURPOSE
   HARD_PATH ONLY: Provides deep reality assessment
   Called after viability_router_node
   Feeds output to financial_planner_node

LOGIC FLOW
   Receives client via function parameter
   Constructs profile Dictionary from state fields
   Constructs ml_results Dictionary from viability and fit scores
   Creates RealityCheckFullLLMAgent(client)
   Calls generate_reality_check with profile and ml_results
   Receives reality_check Dictionary with 4 fields
   Updates state with output
   If generation fails, sets error flags
   Returns updated state

STATE CHANGES
   Sets: reality_check_output (Dictionary with 4 fields)


NODE: reality_check_medium_node
================================

PURPOSE
   MEDIUM_PATH ONLY: Provides balanced reality assessment
   Called after viability_router_node
   Feeds output to roadmap_builder_medium_node

LOGIC FLOW
   Similar to reality_check_full_node
   Creates RealityCheckMediumLLMAgent(client)
   Calls generate_reality_check with fewer fields required
   Updates state with reality_check_medium_output

STATE CHANGES
   Sets: reality_check_medium_output (Dictionary with 4 fields)


NODE: reality_check_light_node
===============================

PURPOSE
   EASY_PATH ONLY: Provides brief, encouraging assessment
   Called after viability_router_node
   Feeds output to roadmap_builder_light_node

LOGIC FLOW
   Similar to reality_check_full_node
   Creates RealityCheckLightLLMAgent(client)
   Calls generate_reality_check with minimal output
   Updates state with reality_check_light_output

STATE CHANGES
   Sets: reality_check_light_output (Dictionary with 4 fields)


NODE: financial_planner_node
=============================

PURPOSE
   HARD_PATH ONLY: Generates comprehensive financial planning
   Called after reality_check_full_node
   Feeds output to roadmap_builder_full_node

LOGIC FLOW
   Receives client via function parameter
   Constructs profile Dictionary from state fields
   Gets reality_check_output from state
   Creates FinancialPlannerLLMAgent(client)
   Calls generate_financial_plan with profile and reality_check
   Receives financial_plan Dictionary with 8 fields
   Updates state with output
   If generation fails, sets error flags
   Returns updated state

STATE CHANGES
   Sets: financial_plan_output (Dictionary with 8 fields)


NODE: roadmap_builder_full_node
================================

PURPOSE
   HARD_PATH ONLY: Generates 12-month detailed roadmap
   Called after financial_planner_node
   Feeds output to alternative_explorer_node

LOGIC FLOW
   Receives client via function parameter
   Constructs profile Dictionary from state fields
   Constructs ml_results Dictionary from scores
   Creates RoadmapBuilderFullLLMAgent(client)
   Calls generate_roadmap with profile and ml_results
   Receives roadmap Dictionary with 6 fields
   Updates state with roadmap_output
   If generation fails, sets error flags
   Returns updated state

STATE CHANGES
   Sets: roadmap_output (Dictionary with 6 fields)


NODE: roadmap_builder_medium_node
==================================

PURPOSE
   MEDIUM_PATH ONLY: Generates quarterly roadmap
   Called after reality_check_medium_node
   Feeds output to market_context_medium_node

LOGIC FLOW
   Similar to roadmap_builder_full_node
   Creates RoadmapBuilderMediumLLMAgent(client)
   Calls generate_roadmap
   Updates state with roadmap_medium_output

STATE CHANGES
   Sets: roadmap_medium_output (Dictionary with 6 fields)


NODE: roadmap_builder_light_node
=================================

PURPOSE
   EASY_PATH ONLY: Generates 3-phase foundation roadmap
   Called after reality_check_light_node
   Feeds output to market_context_light_node

LOGIC FLOW
   Similar to roadmap_builder_full_node
   Creates RoadmapBuilderLightLLMAgent(client)
   Calls generate_roadmap
   Updates state with roadmap_light_output

STATE CHANGES
   Sets: roadmap_light_output (Dictionary with 5 fields)


NODE: alternative_explorer_node
================================

PURPOSE
   HARD_PATH ONLY: Explores alternative career paths
   Called after roadmap_builder_full_node
   Feeds output to market_context_full_node

LOGIC FLOW
   Receives client via function parameter
   Constructs minimal profile Dictionary needed for alternatives
   Gets viability_score from state
   Creates AlternativeExplorerLLMAgent(client)
   Calls explore_alternatives with profile and viability_score
   Receives alternatives List of 5 and summary String
   Updates state with alternatives_output
   If generation fails, sets error flags
   Returns updated state

STATE CHANGES
   Sets: alternatives_output (Dictionary with alternatives List and summary)


NODE: market_context_full_node
===============================

PURPOSE
   HARD_PATH ONLY: Provides comprehensive market analysis
   Called after alternative_explorer_node
   Feeds output to output_aggregator_node

LOGIC FLOW
   Receives client via function parameter
   Gets career_field from state
   Creates MarketContextFullLLMAgent(client)
   Calls get_market_context with career_field
   Receives market_context Dictionary with 9 fields
   Updates state with market_context
   If generation fails, sets error flags
   Returns updated state

STATE CHANGES
   Sets: market_context (Dictionary with 9 fields)


NODE: market_context_medium_node
=================================

PURPOSE
   MEDIUM_PATH ONLY: Provides moderate market analysis
   Called after roadmap_builder_medium_node
   Feeds output to output_aggregator_node

LOGIC FLOW
   Similar to market_context_full_node
   Creates MarketContextMediumLLMAgent(client)
   Updates state with market_context_medium

STATE CHANGES
   Sets: market_context_medium (Dictionary with 9 fields)


NODE: market_context_light_node
================================

PURPOSE
   EASY_PATH ONLY: Provides brief market analysis
   Called after roadmap_builder_light_node
   Feeds output to output_aggregator_node

LOGIC FLOW
   Similar to market_context_full_node
   Creates MarketContextLightLLMAgent(client)
   Updates state with market_context_light

STATE CHANGES
   Sets: market_context_light (Dictionary with 9 fields)


NODE: output_aggregator_node
=============================

PURPOSE
   Final aggregation node, all paths converge here
   Consolidates path-specific outputs into single aggregated_output
   Marks processing as complete
   Follows all path-specific nodes

LOGIC FLOW
   Pure logic node, no agents
   Reads path_taken from state
   Based on path, creates aggregated output from appropriate fields:
      HARD_PATH: reality_check, financial_plan, roadmap, alternatives,
                market_context
      MEDIUM_PATH: reality_check_medium, roadmap_medium, market_context_medium
      EASY_PATH: reality_check_light, roadmap_light, market_context_light
   Includes path identifier in output
   Sets aggregated_output with selected outputs
   Sets processing_complete flag to True
   Returns updated state

STATE CHANGES
   Sets: aggregated_output (Dictionary with path-specific outputs and path type),
         processing_complete (Boolean: True)


MODULE BREAKDOWN: ML PIPELINE
================================================================================

FUNCTION-BASED MODULE: train_pipeline.py
=========================================

PURPOSE
   Orchestrates complete machine learning training workflow
   Manages data cleaning, model training, evaluation pipeline
   Provides single entry point for full model lifecycle

MAIN FUNCTION

   Function: run_full_pipeline
   Parameters:
      training_dir (String: directory with raw training CSV files)
      evaluation_dir (String: directory with evaluation CSV files)
      output_dir (String: directory to save trained model artifacts)
      processed_dir (Optional String: directory for cleaned data)

   Logic:
      Step 1: Data Cleaning
         Calls clean_viability_dataset() on career_viability_training.csv
         Calls clean_academic_dataset() on academic_matcher_training.csv
         Saves cleaned data if processed_dir provided
      Step 2: Model Training
         Calls train_viability_model() with cleaned data
         Calls train_academic_model() with cleaned data
         Saves model artifacts to output_dir
      Step 3: Model Evaluation
         Calls evaluate_all_models() on evaluation data
         Calculates MAE, RMSE, R-squared metrics
      Returns pipeline results dictionary with all outcomes

   Returns: Dictionary containing:
      status (String: "started" or "completed")
      steps (Dictionary with results for each step)
         cleaning_viability: {status, samples}
         cleaning_academic: {status, samples}
         training_viability: {status, train_r2, test_r2, n_features, ...}
         training_academic: {status, train_r2, test_r2, n_features, ...}
         evaluation: {status, models: {viability_metrics, academic_metrics}}


FUNCTION-BASED MODULE: train_viability_scorer.py
==================================================

PURPOSE
   Trains regression model for career viability prediction
   Manages feature engineering, model training, artifact persistence
   Creates 3 model artifacts: model, scaler, encoder

MAIN FUNCTION

   Function: train_viability_model
   Parameters:
      training_file (String: path to cleaned training CSV)
      output_dir (String: directory to save model artifacts)

   Logic:
      Load Data: Reads CSV file using pandas
      Feature Selection: Selects 8 features (4 categorical + 4 numerical)
         Categorical: career_field, current_education_level,
                     budget_constraint, timeline_urgency
         Numerical: years_of_experience, gpa_percentile,
                   research_experience_months, project_portfolio_count
      Encoding: LabelEncode each categorical column, stores encoder
      Scaling: StandardScaler on all features, stores scaler
      Train/Test Split: 80% train / 20% test with random_state=42
      Model Training: Regression Model
         Parameters: 100 estimators, 0.1 learning rate, max_depth=5
      Evaluation: R-squared score on train and test sets
      Serialization: Saves 3 pickled artifacts to output_dir

   Returns: Dictionary containing:
      status (String: "success")
      train_r2 (Float: R-squared on training set)
      test_r2 (Float: R-squared on test set)
      model_type (String: "Regression Model")
      n_features (Integer: number of features used)
      training_samples (Integer: count of training samples)
      test_samples (Integer: count of test samples)


FUNCTION-BASED MODULE: train_academic_matcher.py
==================================================

PURPOSE
   Trains regression model for academic-career fit prediction
   Manages feature engineering, model training, artifact persistence
   Creates 3 model artifacts: model, scaler, encoder

MAIN FUNCTION

   Function: train_academic_model
   Parameters:
      training_file (String: path to cleaned training CSV)
      output_dir (String: directory to save model artifacts)

   Logic:
      Load Data: Reads CSV file using pandas
      Feature Selection: Selects 4 features (1 categorical + 3 numerical)
         Categorical: current_degree_field
         Numerical: gpa_percentile, research_experience_months,
                   project_portfolio_count
      Encoding: LabelEncode categorical column, stores encoder
      Scaling: StandardScaler on all features, stores scaler
      Train/Test Split: 80% train / 20% test with random_state=42
      Model Training: Regression Model
         Parameters: 100 estimators, max_depth=15, n_jobs=-1
      Evaluation: R-squared score on train and test sets
      Serialization: Saves 3 pickled artifacts to output_dir

   Returns: Dictionary containing:
      status (String: "success")
      train_r2 (Float: R-squared on training set)
      test_r2 (Float: R-squared on test set)
      model_type (String: "Regression Model")
      n_features (Integer: number of features used)
      training_samples (Integer: count of training samples)
      test_samples (Integer: count of test samples)


FUNCTION-BASED MODULE: clean_viability_data.py
================================================

PURPOSE
   Cleans career viability training data for model training
   Handles missing values, outliers, invalid ranges
   Removes ~5% noise injected for testing model robustness

MAIN FUNCTION

   Function: clean_viability_dataset
   Parameters:
      input_file (String: path to raw career_viability_training.csv)

   Logic:
      Step 1: Remove NaN Rows
         Drops any row with missing values
      Step 2: Preserve Duplicates
         Intentionally keeps duplicate rows (from oversampling)
      Step 3: Outlier Removal
         Uses IQR method with 3*IQR threshold (conservative approach)
         Applied to: education_gap_years, prior_career_switches
         Removes extreme outliers while preserving data balance
      Step 4: Hard Bounds Validation
         Age: [18, 70]
         Years of experience: [0, 60]
         Learning commitment hours: [0, 168]
         Score fields: [0.0, 1.0]
         Viability target: [0.0, 1.0]
      Final: Reset index and return cleaned DataFrame

   Returns: pandas.DataFrame with cleaned data


FUNCTION-BASED MODULE: clean_academic_matcher_data.py
=======================================================

PURPOSE
   Cleans academic matcher training data for model training
   Handles missing values, outliers, invalid ranges
   Removes ~5% noise for testing model robustness

MAIN FUNCTION

   Function: clean_academic_dataset
   Parameters:
      input_file (String: path to raw academic_matcher_training.csv)

   Logic:
      Step 1: Remove NaN Rows
         Drops any row with missing values
      Step 2: Preserve Duplicates
         Intentionally keeps duplicate rows
      Step 3: Outlier Removal
         IQR method with 3*IQR threshold on:
         research_experience_months, project_portfolio_count
      Step 4: Hard Bounds Validation
         gpa_percentile: [0.0, 1.0]
         academic_fit_score: [0.0, 100.0]
      Final: Reset index and return cleaned DataFrame

   Returns: pandas.DataFrame with cleaned data


FUNCTION-BASED MODULE: evaluate_models.py
==========================================

PURPOSE
   Evaluates trained ML models on clean evaluation datasets
   Computes standard regression metrics
   Provides model performance assessment

MAIN FUNCTIONS

   Function: evaluate_viability_model
   Parameters:
      evaluation_file (String: path to evaluation CSV without noise)
      model_dir (String: directory with saved model artifacts)

   Logic:
      Load Artifacts: Unpickles model, scaler, encoder from files
      Prepare Data: Reads evaluation CSV, prepares same 8 features as training
      Feature Engineering: LabelEncodes categorical features using saved encoder
      Scaling: Applies saved StandardScaler to features
      Prediction: Runs loaded model on scaled features
      Evaluation: Calculates MSE, MAE, RMSE, R-squared

   Returns: Dictionary containing:
      status (String: "success")
      model (String: "career_viability")
      test_samples (Integer: number of evaluation samples)
      mse (Float: mean squared error)
      mae (Float: mean absolute error)
      rmse (Float: root mean squared error)
      r2_score (Float: R-squared metric 0-1)

   Function: evaluate_academic_model
   Parameters:
      evaluation_file (String: path to evaluation CSV without noise)
      model_dir (String: directory with saved model artifacts)

   Logic:
      Similar to evaluate_viability_model
      Loads academic matcher model, scaler, encoder
      Prepares same 4 features as training
      Calculates same metrics

   Returns: Dictionary with academic model evaluation metrics


MODULE BREAKDOWN: UTILITIES
================================================================================

CLASS: utils/gemini_client.py
==============================

PURPOSE
   Manages Google Gemini API interactions
   Implements robust API key rotation for rate limit handling
   Provides JSON parsing with error recovery
   Implements structured JSON generation with validation

CLASS: GeminiClient

   Method: __init__
   Parameters: model (String, default "gemini-2.5-flash-lite")
   Logic:
      Loads all available API keys from environment/Streamlit secrets
      Initializes current_key_index to 0 (first key)
      Calls _initialize_client() with first key
   Returns: None

   Method: _initialize_client
   Logic:
      Validates current_key_index is within valid range
      Configures genai library with current API key
      Creates GenerativeModel instance for LLM calls
   Returns: None
   Raises: ValueError if key index out of range

   Method: _rotate_api_key
   Logic:
      Increments current_key_index
      Calls _initialize_client() to set up next key
   Returns: None
   Raises: ValueError if all keys exhausted

   Method: generate_content
   Parameters:
      prompt (String: LLM prompt)
      temperature (Float default 0.7: creativity level)
      max_tokens (Integer default 2000: response length limit)
      response_mime_type (Optional String: response format)

   Logic:
      Constructs generation_config with temperature and max_tokens
      Calls genai.generate_content() on LLM
      Handles quota/rate limit errors by rotating API key and retrying
      Distinguishes quota errors (recoverable) from other errors (fail fast)
      Retries up to number of available API keys

   Returns: String (response text from LLM)
   Raises: ValueError if LLM fails or all keys exhausted

   Method: extract_json_from_response
   Parameters:
      response_text (String: raw LLM response potentially with markdown)

   Logic:
      Removes markdown fences (```json, ```)
      Uses regex to extract JSON object
      Strips trailing commas to repair minor JSON issues
      Attempts JSON parsing with multiple candidates
      Falls back to nested JSON extraction if main parsing fails

   Returns: Dictionary (parsed JSON object)
   Raises: ValueError if no valid JSON found

   Method: validate_response_fields
   Parameters:
      response (Dictionary: parsed JSON response)
      required_fields (List of Strings: field names that must exist)

   Logic:
      Checks if each required field exists in response
      Accumulates missing fields

   Returns: None
   Raises: ValueError if any required field missing

   Method: generate_structured_json
   Parameters:
      prompt (String: LLM prompt)
      required_fields (List of Strings: validation field names)
      temperature (Float default 0.7)
      max_tokens (Integer default 2000)

   Logic:
      Calls generate_content() to get LLM response
      Extracts JSON from response text
      Validates all required fields present

   Returns: Dictionary (validated, parsed JSON)
   Raises: ValueError if JSON invalid or fields missing

HELPER FUNCTIONS

   Function: _clean_json_text
   Parameters: text (String with potential markdown)
   Logic: Removes markdown JSON fences (```json and ```)
   Returns: String (cleaned text)

   Function: _strip_trailing_commas
   Parameters: text (String with potential trailing commas)
   Logic: Removes commas before closing braces/brackets iteratively
   Returns: String (repaired JSON text)

   Function: _get_all_api_keys
   Logic:
      Checks Streamlit secrets for GEMINI_API_KEY_1 through _4
      Checks environment variables for GEMINI_API_KEY and GEMINI_API_KEY_1-4
      Deduplicates keys
   Returns: List of Strings (valid API keys)

   Function: _get_first_api_key
   Logic: Gets all keys, returns first available
   Returns: Optional String (first available key or None)

   Function: build_gemini_client
   Logic:
      Gets first available API key
      Gets model from GEMINI_MODEL environment variable
      Validates API key and google-genai library availability
      Creates and returns configured GeminiClient instance
   Returns: GeminiClient instance
   Raises: ValueError or ImportError if configuration invalid


FUNCTION-BASED MODULE: workflow/workflow.py
============================================

PURPOSE
   Provides workflow metadata and introspection functions
   Documents routing logic, token budgets, execution strategy
   Supplies workflow structure for debugging and documentation

FUNCTIONS

   Function: get_workflow_metadata
   Parameters: None
   Logic: Returns static metadata dictionary about workflow
   Returns: Dictionary with:
      workflow_name (String)
      version (String)
      description (String)
      entry_point (String: "graph.assess_career")
      graph_builder (String: "graph.build_eduquest_graph")

   Function: get_routing_logic
   Parameters: None
   Logic: Returns comprehensive routing decision structure
   Returns: Dictionary with:
      routing_field (String: "viability_score")
      routing_type (String: "conditional_edges")
      paths (Dictionary with 3 paths):
         Each path contains: description, condition, execution_strategy,
                            token_budget, nodes_count

   Function: get_parallel_execution_info
   Parameters: None
   Logic: Documents which nodes can run in parallel
   Returns: Dictionary with:
      parallel_stages (List): ML viability and fit can run in parallel
      sequential_stages (List): Description of sequential execution order

   Function: get_token_budget_info
   Parameters: None
   Logic: Returns token consumption estimates per path and agent
   Returns: Dictionary with:
      total_tokens_per_path (Dictionary: HARD 5400, MEDIUM 2200, EASY 1550)
      tokens_per_agent (Dictionary: breakdown by agent type)
      ml_tokens (Integer: estimate for ML predictions)

   Function: get_execution_strategy
   Parameters: None
   Logic: Describes overall execution strategy
   Returns: Dictionary with:
      execution_model (String)
      state_management (String)
      error_handling (String)
      client_pattern (String)
      compilation_strategy (String)
      invocation_method (String)


FUNCTION-BASED MODULE: graph.py
================================

PURPOSE
   Orchestrates complete LangGraph workflow
   Manages 18 nodes and their connections
   Implements conditional routing based on ML predictions
   Provides workflow execution entry point and utilities

MAIN FUNCTIONS

   Function: build_eduquest_graph
   Parameters: client (GeminiClient instance)

   Logic:
      Creates StateGraph with EduQuestState
      Adds 18 workflow nodes:
         - Core nodes: input_validator, profile_extractor
         - ML nodes: career_viability_scorer, academic_career_matcher
         - Utility nodes: ml_results_merger, viability_router
         - Path-specific nodes (HARD/MEDIUM/EASY)
         - Output node: output_aggregator
      Wraps LLM nodes with lambda to provide client parameter
      Adds edges (sequential connections) between nodes:
         START -> input_validator -> profile_extractor
         profile_extractor -> [parallel: viability_scorer, fit_matcher]
         Both ML -> ml_results_merger -> viability_router
         viability_router -> [conditional routing based on path]
      Adds conditional_edges for path routing
      Compiles graph for execution

   Returns: Compiled StateGraph (ready for invocation)

   Function: assess_career
   Parameters: form_data (Dictionary with 5 input fields)

   Logic:
      Adds request_id (uuid4) and analysis_timestamp to form_data
      Initializes state using get_initial_state()
      Creates GeminiClient instance
      Builds graph using build_eduquest_graph()
      Invokes graph with initial state
      Catches any workflow exceptions and logs as errors
      Sets processing_complete flag

   Returns: Dictionary (final state with all results)

   Function: get_career_summary
   Parameters: assessment_result (Dictionary from assess_career)

   Logic:
      Extracts relevant fields based on path_taken
      Constructs nested summary with sections:
         user_profile: Dream career, education, experience, interests, concerns
         ml_predictions: Viability, fit, feasibility scores
         path_analysis: Path taken, budget tier
         outputs: Path-specific outputs (aggregated based on path)
         system: Request ID, timestamp, completion status, errors

   Returns: Dictionary with hierarchical summary

   Function: get_workflow_structure
   Parameters: None

   Logic: Documents complete workflow structure

   Returns: Dictionary with:
      workflow_name (String)
      total_nodes (Integer: 20)
      paths (Dictionary describing each of 3 paths)
      ml_models (Dictionary: model types and output ranges)
      llm_agents (Integer: 11)
      agents_by_path (Dictionary: agent counts per path)

   Function: get_workflow_info
   Parameters: None
   Logic: Alias that calls get_workflow_structure()
   Returns: Same as get_workflow_structure()


STATE MANAGEMENT MODULE: state.py
==================================

PURPOSE
   Defines EduQuestState TypedDict for entire workflow
   Manages 60+ fields tracking all user data and predictions
   Implements reducer functions for concurrent update conflict prevention

TYPEDDICT: EduQuestState

Structure: Dictionary with 60+ fields organized by category

FIELD CATEGORIES:

   System Metadata (5 fields):
      request_id (String: unique request identifier, reducer: keep_first)
      analysis_timestamp (String: ISO format timestamp, reducer: keep_first)
      error_occurred (Boolean: error flag, reducer: set_true)
      error_messages (List of Strings: accumulated errors, reducer: add)
      processing_complete (Boolean: completion flag, reducer: set_true)

   User Input (5 fields):
      dream_career (String: target career from user, reducer: keep_first)
      current_academics (String: education background, reducer: keep_first)
      constraints (String: budget/time constraints, reducer: keep_first)
      interests (String: interests and strengths, reducer: keep_first)
      other_concerns (String: concerns and challenges, reducer: keep_first)

   Validation (2 fields):
      validation_errors (List of Strings: input validation issues, reducer: add)
      parsing_complete (Boolean: validation completion, reducer: set_true)

   Extracted Profile (11 fields, all reducer: keep_first):
      extracted_profile (Dictionary: full extracted profile)
      profile_extraction_complete (Boolean)
      career_field (String)
      current_education_level (String)
      years_of_experience (Integer)
      budget_constraint (String)
      timeline_urgency (String)
      interests_list (List of Strings)
      concerns_list (List of Strings)
      current_degree_field (String)
      gpa_percentile (Float 0-1)
      research_experience_months (Integer)
      project_portfolio_count (Integer)

   ML Predictions (2 fields):
      viability_score (Float 0-1, reducer: keep_first)
      academic_fit_score (Float 0-100, reducer: keep_first)
      overall_feasibility (Float 0-1, calculated)

   Routing Decision (1 field):
      path_taken (String: HARD_PATH/MEDIUM_PATH/EASY_PATH, reducer: keep_first)

   Path-Specific Outputs:
      HARD_PATH (5 fields, reducer: keep_first for each):
         reality_check_output (Dictionary)
         financial_plan_output (Dictionary)
         roadmap_output (Dictionary)
         alternatives_output (Dictionary)
         market_context (Dictionary)
      MEDIUM_PATH (3 fields):
         reality_check_medium_output (Dictionary)
         roadmap_medium_output (Dictionary)
         market_context_medium (Dictionary)
      EASY_PATH (3 fields):
         reality_check_light_output (Dictionary)
         roadmap_light_output (Dictionary)
         market_context_light (Dictionary)

   Final Output (1 field):
      aggregated_output (Dictionary: consolidated path outputs, reducer: keep_first)

REDUCER FUNCTIONS

   Function: keep_first
   Parameters: existing (any type), new (any type)
   Logic: Returns existing if truthy, else returns new
   Purpose: Prevents concurrent updates from overwriting first value
   Returns: Whichever value is first non-empty

   Function: set_true
   Parameters: existing (Boolean), new (Boolean)
   Logic: Returns OR combination (True if either is True)
   Purpose: Ensures flag is set once, stays set
   Returns: Boolean (existing OR new)

INITIALIZATION FUNCTION

   Function: get_initial_state
   Parameters: form_data (Dictionary with 5 input fields and metadata)

   Logic:
      Creates dictionary with all 60+ fields
      Populates user input fields from form_data
      Sets metadata (request_id, timestamp)
      Sets all other fields to empty/default values
      Collections initialized as empty lists
      Numeric fields initialized to 0
      Boolean flags initialized to False
      Dictionaries initialized as empty

   Returns: EduQuestState (fully initialized state dictionary)


UI DESIGN & USER INTERFACE
================================================================================

FRAMEWORK: Streamlit Web Application (main.py - 600+ lines)

ARCHITECTURE
   Session State Management: Maintains state across page reruns
   Tabbed Interface: 4 tabs for different result sections
   Responsive Layout: Columns for side-by-side display
   Expandable Sections: Collapsible details for roadmap phases

SESSION STATE VARIABLES

   assessment_result (Dictionary): Complete workflow output stored in session
   eval_results (Dictionary): ML model evaluation metrics stored in session
   run_evaluation (Boolean): Flag triggering model evaluation

LAYOUT STRUCTURE

   Header Section:
      Title and description
      Logo/branding

   Input Form Section:
      5 text area inputs (dream_career, current_academics, constraints,
                         interests, concerns)
      Submit button triggering assess_career() workflow
      Loading indicator during processing

   Results Display Section (4 Tabs):

   TAB 1: ASSESSMENT OVERVIEW
      Three Metrics Cards:
         Career Viability Score (percentage, 0-100%)
         Academic Fit Score (0-100 points)
         Path Complexity (HARD/MEDIUM/EASY label)
      Path Assessment Box:
         Description of path type
         Key characteristics
      Assessment Details:
         Honest assessment text from reality check
         Key metrics summary

   TAB 2: CAREER ROADMAP
      Path-Specific Roadmap Display:

      HARD_PATH Display:
         3 Phase Expandable Sections:
            Phase 1 (Months 1-3)
            Phase 2 (Months 4-8)
            Phase 3 (Months 9-12)
         Each Phase Shows:
            Goals (bulleted list)
            Actions (bulleted list)
         Key Milestones: Grid display of 4 milestones
         Success Resources: List of courses/certifications

      MEDIUM_PATH Display:
         4 Quarter Expandable Sections:
            Q1, Q2, Q3, Q4
         Each Quarter Shows:
            Goals (bulleted list)
            Actions (bulleted list)
         Key Milestones: Grid display
         Recommended Resources: Bulleted list

      EASY_PATH Display:
         3 Phase Expandable Sections:
            Foundation Phase
            Development Phase
            Transition Phase
         Each Phase Shows:
            Duration (time estimate)
            Focus (area of focus)
            Actions (bulleted list)
         Key Milestones: Grid display
         Critical Resources: Bulleted list

   TAB 3: PLANNING & MARKET ANALYSIS
      HARD_PATH Section:
         Financial Planning Box:
            Estimated Total Cost
            Cost Breakdown (education, certification, living, other)
            Funding Sources (list)
            Monthly Budget Recommendation
            ROI Analysis (paragraph)
            Market Salary Range
            Financial Timeline
            Risk Mitigation Strategies

         Market Analysis Box:
            Job Demand Trend
            Salary Range in INR
            Growth Forecast
            Geographic Hotspots
            Required Certifications
            Industry Insights
            Competitive Landscape
            Emerging Opportunities
            Market Risks

         Reality Check Box:
            Honest Assessment
            Major Challenges (bulleted)
            Success Probability
            Mindset Requirements (bulleted)

      MEDIUM_PATH Section:
         Market Analysis Box (same as HARD)
         Reality Check Box (same structure)

      EASY_PATH Section:
         Market Analysis Box (same structure)
         Reality Check Box (brief version)

   TAB 4: ALTERNATIVE CAREERS (HARD_PATH ONLY)
      Alternative Careers List:
         For each of 5 alternatives:
            Career Name (heading)
            Similarity to Dream (description)
            Viability Estimate (high/medium/low badge)
            Reasoning (paragraph)
            Transition Effort (Low/Moderate/High badge)

      Summary Section:
         1-2 paragraph explanation of alternatives

   EXPORT SECTION (Bottom of UI):
      Export Button:
         Downloads assessment as JSON file
         Includes metadata and complete state
      Model Evaluation Button:
         Triggers ML evaluation on evaluation datasets
         Displays R-squared, MAE, RMSE metrics

DISPLAY FUNCTIONS

   Function: display_overview_tab
   Purpose: Renders overview tab
   Displays: 3 metric cards, path description, assessment excerpt

   Function: display_roadmap_tab
   Purpose: Renders roadmap tab
   Logic: Determines path, displays appropriate roadmap structure
   Displays: Phase/quarter sections with goals and actions

   Function: display_planning_tab
   Purpose: Renders planning and market analysis tab
   Logic: Determines path, displays relevant planning sections
   Displays: Financial (HARD only), market analysis, reality check

   Function: display_alternatives_tab
   Purpose: Renders alternative careers tab
   Logic: Only called for HARD_PATH, skipped for others
   Displays: 5 alternatives with details and summary

   Function: display_model_evaluation_section
   Purpose: Displays ML model performance metrics
   Displays: R-squared, MAE, RMSE for both models

   Function: export_assessment
   Parameters: assessment (Dictionary from workflow)
   Purpose: Formats assessment for JSON export
   Returns: JSON string with metadata and full assessment


EXECUTION FLOW & ENTRY POINTS
================================================================================

COMPLETE EXECUTION PIPELINE

PHASE 1: ENVIRONMENT SETUP
===========================

Step 1: Install Dependencies
   Command: pip install -r installation.txt
   Action: Installs all required packages
   Duration: 5-10 minutes
   Output: Python environment with all dependencies ready

Step 2: Configure API Keys
   File: .env in project root
   Required: GEMINI_API_KEY_1 (minimum)
   Optional: GEMINI_API_KEY_2 through 4 (for key rotation)
   Optional: GEMINI_MODEL (defaults to gemini-2.5-flash-lite)

Step 3: Verify Pickle Files
   Location: ml/models/ directory
   Required Files:
      career_viability_model.pkl
      career_viability_scaler.pkl
      career_viability_encoder.pkl
      academic_matcher_model.pkl
      academic_matcher_scaler.pkl
      academic_matcher_encoder.pkl
   If Missing: Run ML training pipeline (see Phase 2)

PHASE 2: ML MODEL TRAINING (Optional, only if retrain needed)
=============================================================

Step 1: Prepare Training Data
   Location: data/training_dataset/
   Required Files:
      career_viability_training.csv
      academic_matcher_training.csv
   Format: CSV with specific column names

Step 2: Run Training Pipeline
   Command: python ml/train_pipeline.py
   Process:
      1. Cleans raw training data
      2. Trains both ML regression models
      3. Saves 6 pickle artifacts
      4. Evaluates on evaluation_dataset
      5. Displays training metrics
   Output: Model artifacts in ml/models/
   Duration: 2-5 minutes depending on hardware

Step 3: Verify Training
   Check: ml/models/ contains 6 pickle files
   Verify: Model metrics appear in console output

PHASE 3: LAUNCH STREAMLIT APPLICATION
======================================

Step 1: Open Terminal in Project Root
   Navigate to: /Users/balamurale/Downloads/LangHackthon/EduQuest/

Step 2: Start Streamlit Server
   Command: streamlit run main.py
   Process:
      1. Loads .env file with API keys
      2. Initializes session state
      3. Starts web server on localhost:8501
   Output: URL in terminal (http://localhost:8501)
   Duration: 10-15 seconds startup

Step 3: Open Web Browser
   Navigate to: http://localhost:8501
   Browser: Any modern browser (Chrome, Firefox, Safari, Edge)

PHASE 4: USER INTERACTION
=========================

Step 1: Fill Form Fields
   Required: All 5 text fields (minimum 50 characters each)
   Fields:
      Dream Career: Target career description
      Current Academics: Education background and degree
      Constraints: Budget, time, family situation
      Interests & Strengths: Skills, interests, expertise
      Concerns & Challenges: Worries, limitations, challenges

Step 2: Submit Form
   Action: Click "Submit" button
   Process:
      1. Input validation (length checks)
      2. LLM profile extraction (creates structured profile)
      3. ML viability and fit prediction (parallel execution)
      4. Results merge and routing decision
      5. Path-specific analysis execution
      6. Output aggregation
   Duration: 30-60 seconds depending on path complexity
   Feedback: Progress indicators and loading state

Step 3: View Results
   Interface: 4 tabs with different perspectives
   Actions:
      - Click tabs to explore different result sections
      - Expand collapsible sections for details
      - Scroll through comprehensive analysis

Step 4: Export Results
   Action: Click "Export Assessment" button
   Output: JSON file download
   Contents: Full assessment with metadata and all results
   Format: Pretty-printed JSON

Step 5: View Model Metrics (Optional)
   Action: Click "Show Model Evaluation" button
   Output: ML model performance metrics
   Metrics: R-squared, MAE, RMSE for both models

INDIVIDUAL ENTRY POINTS

Entry Point 1: Web UI Application
   Command: streamlit run main.py
   Purpose: User-facing interface
   Input: Form submission from user
   Output: Web-based results display
   Use Case: End-user career assessment

Entry Point 2: Python Script API
   Script:
      from graph import assess_career
      results = assess_career({
         'dream_career': 'Data Scientist',
         'current_academics': 'Bachelor in Economics...',
         'constraints': 'Budget limited to...',
         'interests': 'Python, AI, research...',
         'concerns': 'Lack of ML background...'
      })
   Purpose: Programmatic access to assessment engine
   Output: Complete assessment dictionary
   Use Case: Automation, batch processing

Entry Point 3: ML Training Pipeline
   Command: python ml/train_pipeline.py
   Purpose: Retrain models on new data
   Input: CSV training files in data/training_dataset/
   Output: Model artifacts in ml/models/
   Use Case: Model updates with new training data

Entry Point 4: Model Evaluation
   Via UI: Click "Show Model Evaluation" button
   Via Python:
      from ml.evaluation import evaluate_all_models
      results = evaluate_all_models('data/evaluation_dataset/', 'ml/models/')
   Purpose: Assess model performance
   Output: Performance metrics (R-squared, MAE, RMSE)
   Use Case: Model monitoring and validation


APPLICATION WORKFLOW SEQUENCE
==============================

Timeline of execution when user submits form:

T+0s:   User clicks Submit
T+1s:   Input validation runs (0-5ms)
T+2s:   Profile extraction LLM call begins (10-20s)
T+12s:  Profile received, ML predictions start (parallel)
T+15s:  Both ML models complete (~3s each)
T+16s:  Results merged, routing decision made (<10ms)
T+17s:  Path-specific nodes execute based on path:
        HARD_PATH: 5 LLM calls (~50-70s total)
        MEDIUM_PATH: 3 LLM calls (~30-40s total)
        EASY_PATH: 3 LLM calls (~25-35s total)
T+70s:  (For HARD_PATH) All nodes complete
        Output aggregation (<10ms)
        UI renders with results
        User sees assessment


OUTPUT & RESULTS STRUCTURE
================================================================================

OVERVIEW OF OUTPUTS

The system produces comprehensive, multi-layered outputs depending on the
user's viability score and path taken. All outputs follow consistent JSON
structure standards.

HARD_PATH OUTPUT STRUCTURE
==========================

For users with viability_score < 0.3

REALITY CHECK (Full)
   honest_assessment (String): 1-paragraph brutally honest assessment
      Conveys feasibility challenges
      References specific obstacles from profile
      Provides realistic success probability

   major_challenges (List of 4 Strings): Specific obstacles
      Example: "Lack of advanced degree requirements"
      Example: "Limited years of relevant experience"
      Example: "Geographic concentration in distant locations"
      Example: "Rapidly changing skill requirements"

   success_probability (String): Probability statement
      Example: "25-35% with focused 18-24 month effort"
      Based on viability_score and academic_fit_score

   mindset_requirements (List of 3 Strings): Psychological shifts
      Example: "Accept need for total career reset"
      Example: "Build resilience for frequent setbacks"
      Example: "Embrace extended learning period"

FINANCIAL PLAN (HARD_PATH ONLY)
   estimated_total_cost (String): Total investment needed
      Example: "₹5-8 lakhs for 18-24 month transition"
      Includes education, certification, living expenses

   cost_breakdown (Nested Dictionary):
      education (String): Course/degree costs
      certification (String): Professional certification costs
      living_expenses (String): Monthly living cost during transition
      other (String): Additional costs (equipment, travel, etc.)

   funding_sources (List of 3+ Strings): Actionable funding options
      Example: "Online course platforms with financial aid"
      Example: "Employer-sponsored learning programs"
      Example: "Government skill development grants"
      Example: "Part-time income during transition"

   monthly_budget (String): Recommended monthly investment
      Example: "₹25,000-35,000 per month for 18 months"

   roi_analysis (String): Return on investment paragraph
      Includes payback period estimate
      Example: "Initial investment recovers in 3-4 years due to 40% salary increase"

   market_salary_range (String): Current vs target comparison
      Example: "Current: ₹6-8L → Target: ₹10-15L"

   financial_timeline (String): Recovery timeline
      Example: "Financial breakeven in 36-42 months"

   risk_mitigation (List of 2+ Strings): Financial strategies
      Example: "Start part-time before full transition"
      Example: "Maintain 6-month emergency fund"

ROADMAP (12-Month, Full)
   phase_1_months (Dictionary):
      months (String): "1-3"
      goals (List of 3 Strings): Phase 1 goals
         Example: "Complete foundational online courses"
         Example: "Build first 2 portfolio projects"
         Example: "Network with industry professionals"
      actions (List of 3 Strings): Concrete actions
         Example: "Enroll in Python for Data Science course"
         Example: "Complete first Kaggle competition"
         Example: "Attend 2 industry meetups/conferences"

   phase_2_months (Dictionary):
      months (String): "4-8"
      goals (List of 3 Strings): Phase 2 goals
      actions (List of 3 Strings): Concrete actions

   phase_3_months (Dictionary):
      months (String): "9-12"
      goals (List of 3 Strings): Phase 3 goals
      actions (List of 3 Strings): Concrete actions

   key_milestones (List of 4 Strings): Measurable checkpoints
      Example: "Complete 3-course specialization by month 3"
      Example: "Achieve 2000+ Kaggle ranking by month 6"
      Example: "Launch personal project on GitHub by month 9"
      Example: "Secure first entry-level offer by month 12"

   success_resources (List of 3+ Strings): Recommended learning
      Example: "Google Data Analytics Certificate"
      Example: "Python Data Science Specialization"
      Example: "Data Science mentorship programs"

   timeline_notes (String): Critical adjustments and notes
      Example: "If already proficient in Python, compress phases 1-2"

ALTERNATIVES (5 Alternative Careers, HARD_PATH ONLY)
   alternatives (List of 5 Dictionaries):
      Each alternative contains:

      career (String): Alternative career name
         Example: "Data Analyst"
         Example: "Business Analyst"
         Example: "Machine Learning Engineer"
         Example: "AI Research Scientist"
         Example: "Analytics Manager"

      similarity_to_dream (String): 1-2 sentence explanation
         Example: "Shares 70% of required technical skills,
                  requires less domain expertise"

      viability_estimate (String): Feasibility level
         One of: "high", "medium", "low"
         Based on profile match

      reasoning (String): Why good alternative for this user
         Example: "You have strong SQL background which is transferable,
                  and Statistics foundation provides advantage"

      transition_effort (String): Implementation difficulty
         One of: "Low", "Moderate", "High"
         Reflects additional learning required

   summary (String): 1-2 paragraph explanation
      Describes why these alternatives are good options
      Explains common threads across alternatives
      Encourages consideration of alternatives

MARKET CONTEXT (Comprehensive, 9 fields)
   job_demand_trend (String): Current and projected demand
      Example: "Strong demand growing 15-20% annually, projected to increase"

   salary_range_inr (String): Salary ranges by level
      Format: "Entry: ₹5-8L, Mid: ₹10-15L, Senior: ₹18-25L"
      Based on 2024-2025 market data

   growth_forecast (String): 5-year outlook
      Example: "Exceptional growth expected with AI adoption,
               estimated 25% CAGR through 2029"

   geographic_hotspots (List of 3+ Strings): Key locations
      Example: "Bangalore (30% of openings)"
      Example: "Hyderabad (25%)"
      Example: "Mumbai (20%)"
      Geographic distribution of opportunities

   required_certifications (List of 2+ Strings): Credentials needed
      Example: "Google Data Analytics Professional Certificate"
      Example: "AWS Machine Learning Specialty Certification"
      Industry-recognized certifications

   industry_insights (String): Industry status paragraph
      Current trends, key players, future directions
      Example: "Industry consolidating around cloud platforms,
               open source dominance increasing, edge computing emerging"

   competitive_landscape (String): Competition and differentiation
      Example: "Market competitive but differentiation available through
               niche specialization (financial markets, healthcare, etc.)"

   emerging_opportunities (List of 2+ Strings): New prospects
      Example: "Edge AI and IoT integration"
      Example: "Real-time personalization at scale"
      New market segments and possibilities

   market_risks (List of 2+ Strings): Market threats
      Example: "Commodity nature of role may pressure wages"
      Example: "Increasing automation of junior roles"
      Realistic risks to consider


MEDIUM_PATH OUTPUT STRUCTURE
=============================

For users with 0.3 <= viability_score < 0.6

REALITY CHECK (Medium)
   Same 4 fields as Full but:
   - Balanced tone acknowledging strengths and challenges
   - major_challenges: 3 items instead of 4
   - mindset_requirements: 2 items instead of 3
   - Focuses on practical steps

ROADMAP (Quarterly, MEDIUM_PATH)
   q1 (Dictionary):
      goals (List of 2-3 Strings): Q1 goals
      actions (List of 2-3 Strings): Q1 actions

   q2 (Dictionary): Q2 goals and actions
   q3 (Dictionary): Q3 goals and actions
   q4 (Dictionary): Q4 goals and actions
      Last two quarters often have fewer items

   key_milestones (List of 3 Strings): Quarterly checkpoints
      Example: "Complete foundation training by Q1 end"
      Example: "Build 2 portfolio projects by Q2 end"
      Example: "Secure first interviews by Q3 end"

   resources (List of 3+ Strings): Learning resources
      Example: "Coursera specialization"
      Example: "LinkedIn Learning paths"
      Example: "Industry certification programs"

MARKET CONTEXT (Moderate)
   Same 9 fields as Full but:
   - Reduced detail in descriptions
   - 2 geographic hotspots instead of 3+
   - 2 certifications instead of 2+
   - More concise paragraphs


EASY_PATH OUTPUT STRUCTURE
===========================

For users with viability_score >= 0.6

REALITY CHECK (Light)
   Same 4 fields but:
   - Encouraging, brief tone
   - honest_assessment: 2-3 sentences
   - major_challenges: 2 items
   - mindset_requirements: 1 item
   - Emphasis on alignment and feasibility

ROADMAP (3-Phase, EASY_PATH)
   phase_1_foundation (Dictionary):
      duration (String): "2-3 months" estimated timeframe
      focus (String): Description of foundation phase focus
      actions (List of 3 Strings): Foundation actions

   phase_2_development (Dictionary):
      duration (String): "3-4 months" estimated timeframe
      focus (String): Development phase focus area
      actions (List of 3 Strings): Development actions

   phase_3_transition (Dictionary):
      duration (String): "1-2 months" estimated timeframe
      focus (String): Final transition phase focus
      actions (List of 3 Strings): Transition actions

   key_milestones (List of 2-3 Strings): Key checkpoints
      Example: "Complete foundation by end of phase 1"
      Example: "Launch first job search by phase 3"

   critical_resources (List of 2-3 Strings): Essential learning
      Example: "Industry-specific skill courses"

MARKET CONTEXT (Brief)
   Same 9 fields but:
   - Very concise (1 sentence per field where possible)
   - 1 geographic hotspot
   - 1 certification
   - Optimistic tone


AGGREGATED OUTPUT (All Paths)
==============================

The output_aggregator_node creates single aggregated_output dictionary
containing consolidated results:

AGGREGATED OUTPUT (HARD_PATH):
   path (String): "HARD_PATH"
   reality_check (Dictionary): Full reality check output
   financial_plan (Dictionary): Full financial plan output
   roadmap (Dictionary): Full 12-month roadmap output
   alternatives (Dictionary): 5 alternatives with summary
   market_context (Dictionary): Comprehensive market analysis

AGGREGATED OUTPUT (MEDIUM_PATH):
   path (String): "MEDIUM_PATH"
   reality_check (Dictionary): Medium reality check output
   roadmap (Dictionary): Quarterly roadmap output
   market_context (Dictionary): Moderate market analysis

AGGREGATED OUTPUT (EASY_PATH):
   path (String): "EASY_PATH"
   reality_check (Dictionary): Light reality check output
   roadmap (Dictionary): 3-phase roadmap output
   market_context (Dictionary): Brief market analysis

EXPORT FORMAT (JSON Download)
==============================

When user exports assessment, JSON file contains:

metadata (Dictionary):
   request_id (String): Unique assessment identifier
   timestamp (String): ISO format creation time

assessment (Dictionary): Complete final state with:
   User profile data (5 input fields + 11 extracted fields)
   ML predictions (viability_score, academic_fit_score, overall_feasibility)
   Path determination (path_taken)
   All aggregated outputs
   System metadata (request_id, timestamp, errors)

File Name: assessment_{timestamp}.json
Download Location: Browser downloads folder


MODEL EVALUATION OUTPUT
=======================

When user clicks "Show Model Evaluation", displays:

Career Viability Model:
   R-squared: 0.75-0.85 (varies with data)
   MAE: 0.08-0.12 (mean absolute error)
   RMSE: 0.10-0.15 (root mean squared error)

Academic Fit Model:
   R-squared: 0.68-0.78 (varies with data)
   MAE: 8-12 (points out of 100)
   RMSE: 10-15 (points out of 100)


FINAL STATE STRUCTURE
=======================

Complete final state dictionary contains:

SYSTEM FIELDS (5):
   request_id: UUID for this assessment
   analysis_timestamp: ISO timestamp
   error_occurred: Boolean
   error_messages: List of any errors
   processing_complete: Boolean (True if successful)

USER INPUT FIELDS (5):
   dream_career: Original input text
   current_academics: Original input text
   constraints: Original input text
   interests: Original input text
   other_concerns: Original input text

PROFILE FIELDS (12):
   extracted_profile: Full dictionary
   career_field, current_education_level, years_of_experience, etc.

PREDICTION FIELDS (3):
   viability_score: Float 0-1
   academic_fit_score: Float 0-100
   overall_feasibility: Float 0-1 (calculated)

PATH DECISION FIELD (1):
   path_taken: HARD_PATH / MEDIUM_PATH / EASY_PATH

PATH OUTPUTS (5+ fields depending on path):
   reality_check_output (or medium/light variant)
   roadmap_output (or medium/light variant)
   market_context (or medium/light variant)
   financial_plan_output (HARD only)
   alternatives_output (HARD only)

AGGREGATED OUTPUT (1):
   aggregated_output: Consolidated results for display


================================================================================
                           END OF DOCUMENTATION
================================================================================

This document provides complete specification of EduQuest system including
problem statement, architecture, modules, classes, methods, workflow, and
output structures. For questions or updates, refer to specific sections
based on component of interest.

For technical implementation details, review actual source code files.
This documentation focuses on what each component does, not how it does it.

