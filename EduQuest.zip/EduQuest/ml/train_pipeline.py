"""ML training pipeline orchestrator."""

from data_cleaning import clean_viability_dataset, clean_academic_dataset
from train_model import train_viability_model, train_academic_model
from evaluation import evaluate_all_models
import os


def run_full_pipeline(
    training_dir: str,
    evaluation_dir: str,
    output_dir: str,
    processed_dir: str = None
) -> dict:
    """Run complete ML training pipeline.

    Steps:
    1. Clean training datasets (remove NaN, duplicates)
    2. Train both ML models
    3. Evaluate models on clean evaluation data
    4. Save results

    Args:
        training_dir: Directory containing raw training CSV files
        evaluation_dir: Directory containing evaluation CSV files
        output_dir: Directory to save trained models (.pkl files)
        processed_dir: Optional directory to save cleaned training data

    Returns:
        Dictionary with pipeline results
    """
    results = {
        "status": "started",
        "steps": {}
    }

    os.makedirs(output_dir, exist_ok=True)
    if processed_dir:
        os.makedirs(processed_dir, exist_ok=True)

    print("\n=== STEP 1: DATA CLEANING ===")
    try:
        viability_raw = f"{training_dir}/career_viability_training.csv"
        viability_clean = clean_viability_dataset(viability_raw)
        if processed_dir:
            viability_clean.to_csv(f"{processed_dir}/career_viability_clean.csv", index=False)
        print(f"✓ Career viability data cleaned: {len(viability_clean)} samples")
        results["steps"]["cleaning_viability"] = {"status": "success", "samples": len(viability_clean)}
    except Exception as e:
        print(f"✗ Career viability cleaning failed: {str(e)}")
        results["steps"]["cleaning_viability"] = {"status": "failed", "error": str(e)}
        return results

    try:
        academic_raw = f"{training_dir}/academic_matcher_training.csv"
        academic_clean = clean_academic_dataset(academic_raw)
        if processed_dir:
            academic_clean.to_csv(f"{processed_dir}/academic_matcher_clean.csv", index=False)
        print(f"✓ Academic matcher data cleaned: {len(academic_clean)} samples")
        results["steps"]["cleaning_academic"] = {"status": "success", "samples": len(academic_clean)}
    except Exception as e:
        print(f"✗ Academic matcher cleaning failed: {str(e)}")
        results["steps"]["cleaning_academic"] = {"status": "failed", "error": str(e)}
        return results

    print("\n=== STEP 2: MODEL TRAINING ===")
    try:
        viability_metrics = train_viability_model(f"{processed_dir or training_dir}/career_viability_clean.csv", output_dir)
        print(f"✓ Career viability model trained")
        print(f"  Train R²: {viability_metrics['train_r2']:.4f}")
        print(f"  Test R²: {viability_metrics['test_r2']:.4f}")
        results["steps"]["training_viability"] = viability_metrics
    except Exception as e:
        print(f"✗ Career viability training failed: {str(e)}")
        results["steps"]["training_viability"] = {"status": "failed", "error": str(e)}
        return results

    try:
        academic_metrics = train_academic_model(f"{processed_dir or training_dir}/academic_matcher_clean.csv", output_dir)
        print(f"✓ Academic matcher model trained")
        print(f"  Train R²: {academic_metrics['train_r2']:.4f}")
        print(f"  Test R²: {academic_metrics['test_r2']:.4f}")
        results["steps"]["training_academic"] = academic_metrics
    except Exception as e:
        print(f"✗ Academic matcher training failed: {str(e)}")
        results["steps"]["training_academic"] = {"status": "failed", "error": str(e)}
        return results

    print("\n=== STEP 3: MODEL EVALUATION ===")
    try:
        eval_results = evaluate_all_models(evaluation_dir, output_dir)
        print(f"✓ Model evaluation completed")
        for model_name, metrics in eval_results["models"].items():
            if metrics.get("status") == "success":
                print(f"  {model_name}:")
                print(f"    MAE: {metrics['mae']:.4f}")
                print(f"    RMSE: {metrics['rmse']:.4f}")
                print(f"    R²: {metrics['r2_score']:.4f}")
        results["steps"]["evaluation"] = eval_results
    except Exception as e:
        print(f"✗ Model evaluation failed: {str(e)}")
        results["steps"]["evaluation"] = {"status": "failed", "error": str(e)}
        return results

    print("\n=== PIPELINE COMPLETE ===")
    results["status"] = "success"
    return results


if __name__ == "__main__":
    import os
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    training_data_dir = os.path.join(base_dir, "data/training_dataset")
    evaluation_data_dir = os.path.join(base_dir, "data/evaluation_dataset")
    model_output_dir = os.path.join(base_dir, "ml/models")
    processed_data_dir = os.path.join(base_dir, "data/processed")

    pipeline_results = run_full_pipeline(
        training_dir=training_data_dir,
        evaluation_dir=evaluation_data_dir,
        output_dir=model_output_dir,
        processed_dir=processed_data_dir
    )

    print("\n=== FINAL RESULTS ===")
    print(f"Pipeline Status: {pipeline_results['status']}")
    for step, details in pipeline_results['steps'].items():
        print(f"{step}: {details.get('status', 'unknown')}")
