"""Evaluate trained ML models on evaluation datasets."""

import pickle
import pandas as pd
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import numpy as np


def evaluate_viability_model(evaluation_file: str, model_dir: str) -> dict:
    """Evaluate career viability model on clean evaluation data.

    Args:
        evaluation_file: Path to evaluation dataset CSV (no noise)
        model_dir: Directory containing saved model artifacts

    Returns:
        Dictionary with evaluation metrics
    """
    df = pd.read_csv(evaluation_file)

    with open(f"{model_dir}/career_viability_model.pkl", "rb") as f:
        model = pickle.load(f)
    with open(f"{model_dir}/career_viability_scaler.pkl", "rb") as f:
        scaler = pickle.load(f)
    with open(f"{model_dir}/career_viability_encoder.pkl", "rb") as f:
        label_encoders = pickle.load(f)

    categorical_cols = ['career_field', 'current_education_level', 'budget_constraint', 'timeline_urgency']
    numerical_cols = ['age', 'years_of_experience', 'interest_alignment_score',
                      'skill_transferability_score', 'learning_commitment_hours_per_week',
                      'current_career_satisfaction', 'education_gap_years',
                      'target_career_growth_trend', 'prior_career_switches']
    binary_cols = ['has_relevant_certifications', 'has_industry_connections']
    discrete_cols = ['geographic_flexibility', 'family_support_level']

    available_numerical = [col for col in numerical_cols if col in df.columns]
    available_categorical = [col for col in categorical_cols if col in df.columns]
    available_binary = [col for col in binary_cols if col in df.columns]
    available_discrete = [col for col in discrete_cols if col in df.columns]

    encoded_data = df.copy()
    for col in available_categorical:
        if col in label_encoders:
            encoded_data[col] = label_encoders[col].transform(df[col].astype(str))

    X = encoded_data[available_categorical + available_numerical + available_binary + available_discrete]
    y = encoded_data['viability_score']

    X_scaled = scaler.transform(X)
    y_pred = model.predict(X_scaled)

    mse = mean_squared_error(y, y_pred)
    mae = mean_absolute_error(y, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y, y_pred)

    return {
        "status": "success",
        "model": "career_viability",
        "test_samples": len(y),
        "mse": mse,
        "mae": mae,
        "rmse": rmse,
        "r2_score": r2,
    }


def evaluate_academic_model(evaluation_file: str, model_dir: str) -> dict:
    """Evaluate academic matcher model on clean evaluation data.

    Args:
        evaluation_file: Path to evaluation dataset CSV (no noise)
        model_dir: Directory containing saved model artifacts

    Returns:
        Dictionary with evaluation metrics
    """
    df = pd.read_csv(evaluation_file)

    with open(f"{model_dir}/academic_matcher_model.pkl", "rb") as f:
        model = pickle.load(f)
    with open(f"{model_dir}/academic_matcher_scaler.pkl", "rb") as f:
        scaler = pickle.load(f)
    with open(f"{model_dir}/academic_matcher_encoder.pkl", "rb") as f:
        label_encoders = pickle.load(f)

    # Use only the categorical columns that exist in the encoder
    categorical_cols = list(label_encoders.keys())
    numerical_cols = ['gpa_percentile', 'research_experience_months', 'project_portfolio_count']

    available_categorical = [col for col in categorical_cols if col in df.columns]
    available_numerical = [col for col in numerical_cols if col in df.columns]

    encoded_data = df.copy()
    for col in available_categorical:
        if col in label_encoders:
            encoded_data[col] = label_encoders[col].transform(df[col].astype(str))

    X = encoded_data[available_categorical + available_numerical]
    y = encoded_data['academic_fit_score']

    X_scaled = scaler.transform(X)
    y_pred = model.predict(X_scaled)

    mse = mean_squared_error(y, y_pred)
    mae = mean_absolute_error(y, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y, y_pred)

    return {
        "status": "success",
        "model": "academic_matcher",
        "test_samples": len(y),
        "mse": mse,
        "mae": mae,
        "rmse": rmse,
        "r2_score": r2,
    }


def evaluate_all_models(evaluation_dir: str, model_dir: str) -> dict:
    """Evaluate all trained models.

    Args:
        evaluation_dir: Directory containing evaluation CSV files
        model_dir: Directory containing saved model artifacts

    Returns:
        Dictionary with all evaluation results
    """
    results = {
        "status": "success",
        "models": {}
    }

    viability_file = f"{evaluation_dir}/career_viability_evaluation.csv"
    academic_file = f"{evaluation_dir}/academic_matcher_evaluation.csv"

    try:
        viability_metrics = evaluate_viability_model(viability_file, model_dir)
        results["models"]["viability"] = viability_metrics
    except Exception as e:
        results["models"]["viability"] = {"status": "failed", "error": str(e)}

    try:
        academic_metrics = evaluate_academic_model(academic_file, model_dir)
        results["models"]["academic"] = academic_metrics
    except Exception as e:
        results["models"]["academic"] = {"status": "failed", "error": str(e)}

    return results
