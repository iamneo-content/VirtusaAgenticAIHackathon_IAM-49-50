"""Data cleaning for career viability training dataset."""

import pandas as pd
import numpy as np


def clean_viability_dataset(input_file: str) -> pd.DataFrame:
    """Clean career viability training dataset.

    Handles SPECIFIC noise types per Noise Injection Summary:
    - Missing values (~5%) → dropna()
    - Categorical typos (2% typos like "Sofware Engineer") → standardize via isin()
    - Invalid categories (~1% like "YouTuber") → filter out
    - Case/variation noise ("FLEXIBLE" vs "flexible") → handled by isin()
    - Numerical outliers (age 16, 50, 55) → IQR method or hard bounds
    - Out-of-range values (interest_score -0.2, 1.5) → hard bounds [0, 1]
    - Invalid binary values (2, -1 instead of 0, 1) → filter to [0, 1]
    - Target noise on viability_score → keep as-is (tests model robustness)

    Args:
        input_file: Path to raw career_viability_training.csv

    Returns:
        Cleaned DataFrame ready for model training
    """
    df = pd.read_csv(input_file)

    # Step 1: Remove rows with any NaN/null values
    df = df.dropna()

    # Step 2: Keep duplicates to maintain balanced class distribution
    # (Balanced datasets may have intentional duplicates from oversampling)

    # Step 3: Remove extreme outliers using IQR method
    # Only remove values beyond Q1-3*IQR and Q3+3*IQR (extreme outliers, not moderate ones)
    # This preserves balance better than 1.5*IQR while removing garbage data

    if 'education_gap_years' in df.columns:
        Q1 = df['education_gap_years'].quantile(0.25)
        Q3 = df['education_gap_years'].quantile(0.75)
        IQR = Q3 - Q1
        # Use 3*IQR instead of 1.5*IQR to be less aggressive
        lower_bound = Q1 - 3 * IQR
        upper_bound = Q3 + 3 * IQR
        df = df[(df['education_gap_years'] >= lower_bound) & (df['education_gap_years'] <= upper_bound)]

    if 'prior_career_switches' in df.columns:
        Q1 = df['prior_career_switches'].quantile(0.25)
        Q3 = df['prior_career_switches'].quantile(0.75)
        IQR = Q3 - Q1
        # Use 3*IQR instead of 1.5*IQR to be less aggressive
        lower_bound = Q1 - 3 * IQR
        upper_bound = Q3 + 3 * IQR
        df = df[(df['prior_career_switches'] >= lower_bound) & (df['prior_career_switches'] <= upper_bound)]

    # Step 4: Validate range constraints for key features
    # These are hard bounds from domain knowledge, not statistical

    if 'age' in df.columns:
        df = df[(df['age'] >= 18) & (df['age'] <= 70)]

    if 'years_of_experience' in df.columns:
        df = df[(df['years_of_experience'] >= 0) & (df['years_of_experience'] <= 60)]

    if 'learning_commitment_hours_per_week' in df.columns:
        df = df[(df['learning_commitment_hours_per_week'] >= 0) & (df['learning_commitment_hours_per_week'] <= 168)]

    # Scores should be in valid ranges
    for col in ['interest_alignment_score', 'skill_transferability_score', 'current_career_satisfaction', 'target_career_growth_trend']:
        if col in df.columns:
            df = df[(df[col] >= 0.0) & (df[col] <= 1.0)]

    if 'viability_score' in df.columns:
        df = df[(df['viability_score'] >= 0.0) & (df['viability_score'] <= 1.0)]

    df = df.reset_index(drop=True)

    return df
