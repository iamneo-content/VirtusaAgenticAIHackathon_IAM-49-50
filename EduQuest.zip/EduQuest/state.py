"""
EduQuest State Definition - TypedDict for workflow state management.
"""

from typing import TypedDict, List, Dict, Any, Optional, Annotated
from datetime import datetime
from operator import add


def keep_first(existing, new):
    """Reducer that keeps the first value and ignores subsequent updates."""
    return existing if existing else new


def set_true(existing, new):
    """Reducer that sets value to True if either existing or new is True."""
    return existing or new


class EduQuestState(TypedDict, total=False):
    """Complete state for EduQuest career guidance workflow."""

    # System metadata - use reducers to prevent concurrent update conflicts
    request_id: Annotated[str, keep_first]
    analysis_timestamp: Annotated[str, keep_first]
    error_occurred: Annotated[bool, set_true]
    error_messages: Annotated[List[str], add]
    processing_complete: Annotated[bool, set_true]

    # User input - Raw text fields (use keep_first since these don't change)
    dream_career: Annotated[str, keep_first]
    current_academics: Annotated[str, keep_first]
    constraints: Annotated[str, keep_first]
    interests: Annotated[str, keep_first]
    other_concerns: Annotated[str, keep_first]

    # Input validation (use keep_first for validation flags)
    validation_errors: Annotated[List[str], add]
    parsing_complete: Annotated[bool, set_true]

    # Extracted profile (from LLM) - use keep_first for read-only fields
    extracted_profile: Annotated[Dict[str, Any], keep_first]
    profile_extraction_complete: Annotated[bool, set_true]
    career_field: Annotated[str, keep_first]
    current_education_level: Annotated[str, keep_first]
    years_of_experience: Annotated[int, keep_first]
    budget_constraint: Annotated[str, keep_first]
    timeline_urgency: Annotated[str, keep_first]
    interests_list: Annotated[List[str], keep_first]
    concerns_list: Annotated[List[str], keep_first]
    current_degree_field: Annotated[str, keep_first]
    gpa_percentile: Annotated[float, keep_first]
    research_experience_months: Annotated[int, keep_first]
    project_portfolio_count: Annotated[int, keep_first]

    # ML Predictions - Career Viability Model (keep_first since single node writes)
    viability_score: Annotated[float, keep_first]

    # ML Predictions - Academic Career Matcher Model (keep_first since single node writes)
    academic_fit_score: Annotated[float, keep_first]

    # Routing Decision (keep_first since single node writes)
    path_taken: Annotated[str, keep_first]

    # HARD PATH: Reality Check Full (keep_first since single node writes)
    reality_check_output: Annotated[Dict[str, Any], keep_first]

    # HARD PATH: Financial Planner (keep_first since single node writes)
    financial_plan_output: Annotated[Dict[str, Any], keep_first]
    market_context: Annotated[Dict[str, Any], keep_first]

    # HARD PATH: Roadmap Builder Full (keep_first since single node writes)
    roadmap_output: Annotated[Dict[str, Any], keep_first]

    # HARD PATH: Alternative Explorer (keep_first since single node writes)
    alternatives_output: Annotated[Dict[str, Any], keep_first]

    # MEDIUM PATH: Reality Check Medium (keep_first since single node writes)
    reality_check_medium_output: Annotated[Dict[str, Any], keep_first]

    # MEDIUM PATH: Roadmap Builder Medium (keep_first since single node writes)
    roadmap_medium_output: Annotated[Dict[str, Any], keep_first]

    # MEDIUM PATH: Market Context (keep_first since single node writes)
    market_context_medium: Annotated[Dict[str, Any], keep_first]

    # EASY PATH: Reality Check Light (keep_first since single node writes)
    reality_check_light_output: Annotated[Dict[str, Any], keep_first]

    # EASY PATH: Roadmap Builder Light (keep_first since single node writes)
    roadmap_light_output: Annotated[Dict[str, Any], keep_first]

    # EASY PATH: Market Context (keep_first since single node writes)
    market_context_light: Annotated[Dict[str, Any], keep_first]

    # Final aggregated output (keep_first since single node writes)
    aggregated_output: Annotated[Dict[str, Any], keep_first]


def get_initial_state(form_data: Dict[str, Any]) -> EduQuestState:
    """
    Initialize state from form data.

    Args:
        form_data: Dictionary containing user input fields

    Returns:
        Initialized EduQuestState dictionary
    """
    return {
        "request_id": form_data.get("request_id", ""),
        "analysis_timestamp": form_data.get("analysis_timestamp", datetime.now().isoformat()),
        "error_occurred": False,
        "error_messages": [],
        "processing_complete": False,
        "dream_career": form_data.get("dream_career", ""),
        "current_academics": form_data.get("current_academics", ""),
        "constraints": form_data.get("constraints", ""),
        "interests": form_data.get("interests", ""),
        "other_concerns": form_data.get("other_concerns", ""),
        "validation_errors": [],
        "parsing_complete": False,
        "extracted_profile": {},
        "profile_extraction_complete": False,
        "career_field": "",
        "current_education_level": "",
        "years_of_experience": 0,
        "budget_constraint": "",
        "timeline_urgency": "",
        "interests_list": [],
        "concerns_list": [],
        "current_degree_field": "",
        "gpa_percentile": 0.0,
        "research_experience_months": 0,
        "project_portfolio_count": 0,
        "viability_score": 0.0,
        "academic_fit_score": 0.0,
        "path_taken": "",
        "reality_check_output": {},
        "financial_plan_output": {},
        "market_context": {},
        "roadmap_output": {},
        "alternatives_output": {},
        "reality_check_medium_output": {},
        "roadmap_medium_output": {},
        "market_context_medium": {},
        "reality_check_light_output": {},
        "roadmap_light_output": {},
        "market_context_light": {},
        "aggregated_output": {},
    }
