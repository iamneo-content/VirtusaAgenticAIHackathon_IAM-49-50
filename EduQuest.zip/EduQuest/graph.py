"""
Main graph interface for EduQuest career guidance system.
Defines the complete StateGraph structure and orchestration.
"""

from datetime import datetime
from typing import Dict, Any
from uuid import uuid4

from langgraph.graph import StateGraph, START, END
from state import EduQuestState, get_initial_state
from utils.gemini_client import GeminiClient
from nodes import (
    input_validator_node,
    profile_extractor_node,
    career_viability_scorer_node,
    academic_career_matcher_node,
    ml_results_merger_node,
    viability_router_node,
    reality_check_full_node,
    reality_check_medium_node,
    reality_check_light_node,
    financial_planner_node,
    roadmap_builder_full_node,
    roadmap_builder_medium_node,
    roadmap_builder_light_node,
    alternative_explorer_node,
    market_context_full_node,
    market_context_medium_node,
    market_context_light_node,
    output_aggregator_node,
)


def build_eduquest_graph(client):
    """Build and return the compiled EduQuest LangGraph.

    Args:
        client: Gemini API client for LLM calls

    Returns:
        Compiled LangGraph StateGraph ready for invocation
    """
    graph = StateGraph(EduQuestState)

    graph.add_node("input_validator", input_validator_node)
    graph.add_node("profile_extractor", lambda state: profile_extractor_node(state, client))

    graph.add_node("career_viability_scorer", career_viability_scorer_node)
    graph.add_node("academic_career_matcher", academic_career_matcher_node)

    graph.add_node("ml_results_merger", ml_results_merger_node)
    graph.add_node("viability_router", viability_router_node)

    graph.add_node("reality_check_full", lambda state: reality_check_full_node(state, client))
    graph.add_node("reality_check_medium", lambda state: reality_check_medium_node(state, client))
    graph.add_node("reality_check_light", lambda state: reality_check_light_node(state, client))

    graph.add_node("financial_planner", lambda state: financial_planner_node(state, client))

    graph.add_node("roadmap_builder_full", lambda state: roadmap_builder_full_node(state, client))
    graph.add_node("roadmap_builder_medium", lambda state: roadmap_builder_medium_node(state, client))
    graph.add_node("roadmap_builder_light", lambda state: roadmap_builder_light_node(state, client))

    graph.add_node("alternative_explorer", lambda state: alternative_explorer_node(state, client))

    graph.add_node("market_context_full_node", lambda state: market_context_full_node(state, client))
    graph.add_node("market_context_medium_node", lambda state: market_context_medium_node(state, client))
    graph.add_node("market_context_light_node", lambda state: market_context_light_node(state, client))

    graph.add_node("output_aggregator", output_aggregator_node)

    graph.add_edge(START, "input_validator")
    graph.add_edge("input_validator", "profile_extractor")

    graph.add_edge("profile_extractor", "career_viability_scorer")
    graph.add_edge("profile_extractor", "academic_career_matcher")

    graph.add_edge("career_viability_scorer", "ml_results_merger")
    graph.add_edge("academic_career_matcher", "ml_results_merger")

    graph.add_edge("ml_results_merger", "viability_router")

    def route_by_viability(state: EduQuestState) -> str:
        """Route to HARD, MEDIUM, or EASY path based on viability score."""
        path = state.get("path_taken", "EASY_PATH")
        if path == "HARD_PATH":
            return "hard_path"
        elif path == "MEDIUM_PATH":
            return "medium_path"
        else:
            return "easy_path"

    graph.add_conditional_edges(
        "viability_router",
        route_by_viability,
        {
            "hard_path": "reality_check_full",
            "medium_path": "reality_check_medium",
            "easy_path": "reality_check_light",
        },
    )

    graph.add_edge("reality_check_full", "financial_planner")
    graph.add_edge("reality_check_medium", "roadmap_builder_medium")
    graph.add_edge("reality_check_light", "roadmap_builder_light")

    graph.add_edge("financial_planner", "roadmap_builder_full")
    graph.add_edge("roadmap_builder_full", "alternative_explorer")
    graph.add_edge("alternative_explorer", "market_context_full_node")

    graph.add_edge("roadmap_builder_medium", "market_context_medium_node")
    graph.add_edge("roadmap_builder_light", "market_context_light_node")

    graph.add_edge("market_context_full_node", "output_aggregator")
    graph.add_edge("market_context_medium_node", "output_aggregator")
    graph.add_edge("market_context_light_node", "output_aggregator")

    graph.add_edge("output_aggregator", END)

    return graph.compile()


def assess_career(form_data: Dict[str, str]) -> Dict[str, Any]:
    """
    Run complete EduQuest career assessment workflow.

    This is the main entry point for the application. It executes the complete
    career guidance workflow and returns comprehensive assessment results.

    API key is automatically loaded from .env file via GeminiClient.

    Args:
        form_data: Dictionary with 5 free-text fields:
            - dream_career: User's dream career or target career path
            - current_academics: Current education level and academic status
            - constraints: Budget, time, and other constraints
            - interests: Interests and hobbies
            - concerns: Concerns, doubts, or other relevant information

    Returns:
        Dictionary with complete career assessment results including:
        - User profile (extracted from free text)
        - ML predictions (viability score, academic fit)
        - Path determination (HARD/MEDIUM/EASY)
        - LLM-generated insights (reality check, roadmap, plans)
        - Aggregated final output
        - System metadata
    """
    # Add metadata to form_data before state initialization to avoid concurrent updates
    form_data["request_id"] = str(uuid4())
    form_data["analysis_timestamp"] = datetime.now().isoformat()

    state = get_initial_state(form_data)

    client = GeminiClient()
    graph = build_eduquest_graph(client)

    try:
        final_state = graph.invoke(state)
        final_state["processing_complete"] = True
        return final_state

    except Exception as e:
        state["error_occurred"] = True
        state["error_messages"].append(f"Workflow execution error: {str(e)}")
        state["processing_complete"] = False
        return state


def get_career_summary(assessment_result: Dict[str, Any]) -> Dict[str, Any]:
    """
    Extract summary from complete assessment result.

    Args:
        assessment_result: Result from assess_career()

    Returns:
        Dictionary with assessment summary
    """
    path_taken = assessment_result.get("path_taken", "UNKNOWN")

    summary = {
        "user_profile": {
            "dream_career": assessment_result.get("dream_career"),
            "current_education": assessment_result.get("current_education_level"),
            "years_of_experience": assessment_result.get("years_of_experience"),
            "interests": assessment_result.get("interests_list", []),
            "concerns": assessment_result.get("concerns_list", []),
        },
        "ml_predictions": {
            "viability_score": assessment_result.get("viability_score"),
            "academic_fit_score": assessment_result.get("academic_fit_score"),
            "overall_feasibility": assessment_result.get("overall_feasibility"),
        },
        "path_analysis": {
            "path_taken": path_taken,
            "budget_tier": assessment_result.get("daily_budget_tier"),
        },
        "outputs": {},
    }

    if path_taken == "HARD_PATH":
        summary["outputs"] = {
            "reality_check": assessment_result.get("reality_check_output", {}),
            "financial_plan": assessment_result.get("financial_plan_output", {}),
            "roadmap": assessment_result.get("roadmap_output", {}),
            "alternatives": assessment_result.get("alternatives_output", {}),
            "market_context": assessment_result.get("market_context", {}),
        }
    elif path_taken == "MEDIUM_PATH":
        summary["outputs"] = {
            "reality_check": assessment_result.get("reality_check_medium_output", {}),
            "roadmap": assessment_result.get("roadmap_medium_output", {}),
            "market_context": assessment_result.get("market_context_medium", {}),
        }
    elif path_taken == "EASY_PATH":
        summary["outputs"] = {
            "reality_check": assessment_result.get("reality_check_light_output", {}),
            "roadmap": assessment_result.get("roadmap_light_output", {}),
            "market_context": assessment_result.get("market_context_light", {}),
        }

    summary["system"] = {
        "request_id": assessment_result.get("request_id"),
        "timestamp": assessment_result.get("analysis_timestamp"),
        "processing_complete": assessment_result.get("processing_complete"),
        "error_occurred": assessment_result.get("error_occurred", False),
        "error_messages": assessment_result.get("error_messages", []),
    }

    return summary


def get_workflow_structure() -> Dict[str, Any]:
    """Get information about the EduQuest workflow structure.

    Returns:
        Dictionary describing workflow nodes, paths, and token budgets
    """
    return {
        "workflow_name": "EduQuest Career Guidance",
        "total_nodes": 20,
        "paths": {
            "HARD_PATH": {
                "viability_range": [0.0, 0.3],
                "nodes": [
                    "input_validator",
                    "profile_extractor",
                    "career_viability_scorer",
                    "academic_career_matcher",
                    "ml_results_merger",
                    "viability_router",
                    "reality_check_full",
                    "financial_planner",
                    "roadmap_builder_full",
                    "alternative_explorer",
                    "market_context_full",
                    "output_aggregator",
                ],
                "estimated_tokens": 5400,
                "description": "Comprehensive analysis for challenging career transitions"
            },
            "MEDIUM_PATH": {
                "viability_range": [0.3, 0.6],
                "nodes": [
                    "input_validator",
                    "profile_extractor",
                    "career_viability_scorer",
                    "academic_career_matcher",
                    "ml_results_merger",
                    "viability_router",
                    "reality_check_medium",
                    "roadmap_builder_medium",
                    "market_context_medium",
                    "output_aggregator",
                ],
                "estimated_tokens": 2200,
                "description": "Moderate analysis for achievable career transitions"
            },
            "EASY_PATH": {
                "viability_range": [0.6, 1.0],
                "nodes": [
                    "input_validator",
                    "profile_extractor",
                    "career_viability_scorer",
                    "academic_career_matcher",
                    "ml_results_merger",
                    "viability_router",
                    "reality_check_light",
                    "roadmap_builder_light",
                    "market_context_light",
                    "output_aggregator",
                ],
                "estimated_tokens": 1550,
                "description": "Quick analysis for optimal career transitions"
            }
        },
        "ml_models": {
            "career_viability_scorer": {
                "type": "GradientBoostingRegressor",
                "output_range": [0.0, 1.0],
                "model_file": "ml/models/career_viability_model.pkl"
            },
            "academic_career_matcher": {
                "type": "RandomForestRegressor",
                "output_range": [0.0, 100.0],
                "model_file": "ml/models/academic_matcher_model.pkl"
            }
        },
        "llm_agents": 11,
        "agents_by_path": {
            "HARD_PATH": 5,
            "MEDIUM_PATH": 3,
            "EASY_PATH": 3,
            "shared": [
                "input_validator",
                "profile_extractor",
                "career_viability_scorer",
                "academic_career_matcher",
                "ml_results_merger",
                "viability_router",
                "output_aggregator"
            ]
        }
    }


def get_workflow_info() -> Dict[str, Any]:
    """
    Get information about the EduQuest workflow.

    Returns:
        Dictionary describing the workflow structure
    """
    return get_workflow_structure()
