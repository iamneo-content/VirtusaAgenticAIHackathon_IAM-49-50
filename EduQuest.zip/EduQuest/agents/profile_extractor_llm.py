"""Profile Extractor LLM Agent - extracts structured profile from free text."""

from typing import Dict, Any
from agents.base_llm_agent import BaseLLMAgent


class ProfileExtractorLLMAgent(BaseLLMAgent):
    """Extracts structured profile information from 5 free-text input fields using LLM."""

    def extract_structured_profile(self, raw_inputs: Dict[str, str]) -> Dict[str, Any]:
        """
        Extract comprehensive profile from free-text inputs using Gemini LLM.

        Args:
            raw_inputs: Dictionary with 5 text fields:
                - dream_career
                - current_academics
                - constraints
                - interests
                - concerns

        Returns:
            Dictionary with:
            - extracted_profile: Dictionary containing 11 structured profile fields
            - status: "success" if extraction succeeds
        """
        prompt = f"""
Extract comprehensive career guidance profile from user inputs. MUST extract ALL required fields with actual values (NOT zeros or empty).

USER INPUTS:
Dream Career: {raw_inputs.get('dream_career', '')}
Current Academics: {raw_inputs.get('current_academics', '')}
Constraints: {raw_inputs.get('constraints', '')}
Interests & Strengths: {raw_inputs.get('interests', '')}
Concerns & Challenges: {raw_inputs.get('concerns', '')}

CRITICAL: Extract these fields with actual computed values (NEVER leave as 0 or empty unless explicitly impossible):

{{
    "career_field": "specific target career (e.g., 'Machine Learning Engineer')",
    "current_education_level": "education summary (e.g., 'Bachelor in CS, GPA 3.8')",
    "years_of_experience": integer ≥ 0,
    "budget_constraint": "budget description",
    "timeline_urgency": "timeline description",
    "interests_list": ["list of interests"],
    "concerns_list": ["list of concerns"],
    "current_degree_field": "subject/field of current degree (e.g., 'Computer Science')",
    "gpa_percentile": float between 0.0-1.0 representing relative GPA strength,
    "research_experience_months": integer total months of research/project experience,
    "project_portfolio_count": integer count of notable projects or portfolio items
}}

EXTRACTION RULES:
- MUST extract actual values, NEVER leave fields as 0 unless explicitly impossible
- If information is not in text, INFER from context
- interests_list and concerns_list MUST have at least 2 items each
- career_field: specific target career name
- current_education_level: current degree and field
- years_of_experience: total years in any career
- budget_constraint: description of financial situation
- timeline_urgency: how soon they need to transition
- current_degree_field: Infer from education background (e.g., if "CS degree" → "Computer Science")
- gpa_percentile: Extract GPA if mentioned, else infer from language (e.g., "3.8 GPA" → 0.95, "passed" → 0.5, "struggled" → 0.3)
- research_experience_months: Infer from years and project mentions (e.g., "6 years experience" → ~60-72 months)
- project_portfolio_count: Count mentioned projects, certifications, notable work (minimum 1, infer from context)
- Temperature is low (0.3) so be deterministic, not random

Return ONLY valid JSON, no markdown, no explanation, no codeblocks.
"""

        result = self.client.generate_structured_json(
            prompt,
            required_fields=[
                "career_field",
                "current_education_level",
                "years_of_experience",
                "budget_constraint",
                "timeline_urgency",
                "interests_list",
                "concerns_list",
                "current_degree_field",
                "gpa_percentile",
                "research_experience_months",
                "project_portfolio_count",
            ],
            temperature=0.3,
            max_tokens=800,
        )

        return {
            "extracted_profile": result,
            "status": "success",
        }
