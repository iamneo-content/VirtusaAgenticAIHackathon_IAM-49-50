"""Reality Check Medium LLM Agent - MEDIUM path moderate analysis."""

from typing import Dict, Any
from agents.base_llm_agent import BaseLLMAgent


class RealityCheckMediumLLMAgent(BaseLLMAgent):
    """Generates moderate reality check analysis for medium viability cases."""

    def generate_reality_check(
        self, profile: Dict[str, Any], ml_results: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Generate moderate reality check analysis.

        Args:
            profile: Extracted user profile
            ml_results: ML prediction results

        Returns:
            Dictionary with condensed reality_check and status
        """
        viability = ml_results.get("viability_score", 0)
        academic_fit = ml_results.get("academic_fit_score", 0)

        prompt = f"""
Provide a balanced reality check for this career transition.

PROFILE:
Career Goal: {profile.get('career_field')}
Current Education: {profile.get('current_education_level')}
Experience: {profile.get('years_of_experience')} years
Timeline: {profile.get('timeline_urgency')}

ML INSIGHTS:
Viability Score: {viability:.2f}
Academic Fit: {academic_fit:.1f}

Return valid JSON with EXACT field names:
{{
    "honest_assessment": "paragraph assessing feasibility",
    "major_challenges": ["challenge 1", "challenge 2", "challenge 3"],
    "success_probability": "probability description",
    "mindset_requirements": ["mindset shift 1", "mindset shift 2"]
}}

Requirements:
1. Balanced perspective - acknowledge strengths and challenges
2. major_challenges should be top 3 only
3. mindset_requirements should be practical shifts (2 items)
4. Use EXACT field names: honest_assessment, major_challenges, success_probability, mindset_requirements
5. Return only valid JSON
"""

        result = self.client.generate_structured_json(
            prompt,
            required_fields=[
                "honest_assessment",
                "major_challenges",
                "success_probability",
                "mindset_requirements",
            ],
            temperature=0.5,
            max_tokens=600,
        )

        return {
            "reality_check": result,
            "status": "success",
        }
