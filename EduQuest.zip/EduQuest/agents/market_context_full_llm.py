"""Market Context Full LLM Agent - HARD path comprehensive market analysis."""

from typing import Dict, Any
from agents.base_llm_agent import BaseLLMAgent


class MarketContextFullLLMAgent(BaseLLMAgent):
    """Provides comprehensive market context and job market analysis."""

    def get_market_context(self, career_field: str) -> Dict[str, Any]:
        """
        Get comprehensive market context for career.

        Args:
            career_field: Target career field

        Returns:
            Dictionary with market_context and status
        """
        prompt = f"""
Provide comprehensive market context for this career field.

CAREER FIELD: {career_field}

Return valid JSON:
{{
    "job_demand_trend": "current and projected job demand trend",
    "salary_range_inr": "salary range in INR (entry/mid/senior levels)",
    "growth_forecast": "5-year growth forecast and outlook",
    "geographic_hotspots": ["location 1", "location 2", "location 3"],
    "required_certifications": ["certification 1", "certification 2"],
    "industry_insights": "paragraph on industry status and trends",
    "competitive_landscape": "paragraph on competition and differentiation",
    "emerging_opportunities": ["opportunity 1", "opportunity 2"],
    "market_risks": ["risk 1", "risk 2"]
}}

Requirements:
1. Job demand must reference current market data (2024-2025)
2. Salary range must be in INR with levels (entry/mid/senior)
3. Growth forecast must be specific with percentage or descriptor
4. Geographic hotspots should be top 3 in India and globally
5. Certifications must be relevant and recognized
6. Industry insights should be current and substantive
7. Competitive analysis should be realistic
8. Opportunities should be emerging and specific
9. Risks should be market-related
10. Return only valid JSON
"""

        result = self.client.generate_structured_json(
            prompt,
            required_fields=[
                "job_demand_trend",
                "salary_range_inr",
                "growth_forecast",
                "geographic_hotspots",
                "required_certifications",
                "industry_insights",
                "competitive_landscape",
                "emerging_opportunities",
                "market_risks",
            ],
            temperature=0.4,
            max_tokens=1000,
        )

        return {
            "market_context": result,
            "status": "success",
        }
