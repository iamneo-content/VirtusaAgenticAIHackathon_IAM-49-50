"""Reality Check Full LLM Agent - HARD path deep analysis."""

from typing import Dict, Any
from agents.base_llm_agent import BaseLLMAgent


class RealityCheckFullLLMAgent(BaseLLMAgent):
    """Generates comprehensive reality check analysis for low viability cases."""

    def generate_reality_check(
        self, profile: Dict[str, Any], ml_results: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Generate deep reality check analysis.

        Args:
            profile: Extracted user profile
            ml_results: ML prediction results (viability_score, academic_fit_score)

        Returns:
            Dictionary with reality_check content and status
        """
        viability = ml_results.get("viability_score", 0)
        academic_fit = ml_results.get("academic_fit_score", 0)

        prompt = f"""
Provide a comprehensive, honest reality check for this career transition.

PROFILE:
Career Goal: {profile.get('career_field')}
Current Education: {profile.get('current_education_level')}
Experience: {profile.get('years_of_experience')} years
Budget: {profile.get('budget_constraint')}
Timeline: {profile.get('timeline_urgency')}
Interests: {', '.join(profile.get('interests_list', []))}
Concerns: {', '.join(profile.get('concerns_list', []))}

ML INSIGHTS:
Career Viability Score: {viability:.2f} (0-1 scale)
Academic Fit Score: {academic_fit:.1f} (0-100 scale)

Return valid JSON:
{{
    "honest_assessment": "paragraph-long honest assessment of feasibility",
    "major_challenges": ["challenge 1", "challenge 2", "challenge 3", "challenge 4"],
    "success_probability": "percentage or probability description",
    "mindset_requirements": ["mindset shift 1", "mindset shift 2", "mindset shift 3"]
}}

Requirements:
1. Be brutally honest about challenges
2. Major challenges must be real and specific (4 items)
3. Success probability should reference the ML scores
4. Mindset requirements must be actionable psychological shifts
5. Return only valid JSON
"""

        result = self.client.generate_structured_json(
            prompt,
            required_fields=[
                "honest_assessment",
                "major_challenges",
                "success_probability",
                "mindset_requirements",
            ],
            temperature=0.5,
            max_tokens=1000,
        )

        return {
            "reality_check": result,
            "status": "success",
        }
