"""Input Validator Agent - validates raw user inputs."""

from typing import Dict, Any, List


class InputValidatorAgent:
    """Validates 5 raw text input fields from user."""

    MIN_LENGTH = 50
    MAX_LENGTH = 2000

    def validate_inputs(self, raw_inputs: Dict[str, str]) -> Dict[str, Any]:
        """
        Validate all 5 input text fields.

        Args:
            raw_inputs: Dictionary with keys:
                - dream_career
                - current_academics
                - constraints
                - interests
                - other_concerns

        Returns:
            Dictionary with:
            - validation_errors: List of error messages (empty if valid)
            - is_valid: Boolean indicating if all fields are valid
            - status: "success" if validation completes
        """
        validation_errors: List[str] = []

        fields = [
            "dream_career",
            "current_academics",
            "constraints",
            "interests",
            "other_concerns",
        ]

        for field in fields:
            value = raw_inputs.get(field, "").strip()

            if not value:
                validation_errors.append(f"{field} is required and cannot be empty")
                continue

            if len(value) < self.MIN_LENGTH:
                validation_errors.append(
                    f"{field} must be at least {self.MIN_LENGTH} characters long. "
                    f"Current length: {len(value)}"
                )

            if len(value) > self.MAX_LENGTH:
                validation_errors.append(
                    f"{field} must not exceed {self.MAX_LENGTH} characters. "
                    f"Current length: {len(value)}"
                )

        is_valid = len(validation_errors) == 0

        return {
            "validation_errors": validation_errors,
            "is_valid": is_valid,
            "status": "success",
        }
