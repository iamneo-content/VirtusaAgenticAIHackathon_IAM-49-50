"""Base class for all LLM-based agents in EduQuest."""


class BaseLLMAgent:
    """
    Base class for all LLM-based agents.

    Provides shared initialization and client management.
    All 11 LLM agents inherit from this class.
    """

    def __init__(self, client):
        """
        Initialize LLM agent with Gemini client.

        Args:
            client: GeminiClient instance for API calls

        Raises:
            ValueError: If client is None
        """
        if client is None:
            raise ValueError("LLM client is required for LLM agents")
        self.client = client
