"""Alternative Explorer LLM Agent - HARD path alternative careers."""

from typing import Dict, Any, List
from agents.base_llm_agent import BaseLLMAgent


class AlternativeExplorerLLMAgent(BaseLLMAgent):
    """Explores alternative career paths when primary goal has low viability."""

    def explore_alternatives(
        self, profile: Dict[str, Any], viability_score: float
    ) -> Dict[str, Any]:
        """
        Explore alternative career paths.

        Args:
            profile: Extracted user profile
            viability_score: Career viability score from ML

        Returns:
            Dictionary with alternatives and status
        """
        prompt = f"""
Suggest 4-5 alternative career paths for someone whose dream career is low viability.

PROFILE DETAILS:
Dream Career: {profile.get('career_field')}
Current Education: {profile.get('current_education_level')}
Years of Experience: {profile.get('years_of_experience', 0)}
Interests: {', '.join(profile.get('interests_list', []))}
Concerns: {', '.join(profile.get('concerns_list', []))}
Viability Score: {viability_score:.2f} (low, so alternatives needed)

CRITICAL: You MUST return ONLY valid JSON with these EXACT fields:

{{
    "alternatives": [
        {{
            "career": "alternative career name",
            "similarity_to_dream": "how similar to original dream career (1-2 sentences)",
            "viability_estimate": "high/medium/low",
            "reasoning": "why this is a good alternative given their profile",
            "transition_effort": "Low/Moderate/High"
        }},
        {{
            "career": "alternative career name 2",
            "similarity_to_dream": "similarity description",
            "viability_estimate": "high/medium/low",
            "reasoning": "reasoning for alternative 2",
            "transition_effort": "Low/Moderate/High"
        }},
        {{
            "career": "alternative career name 3",
            "similarity_to_dream": "similarity description",
            "viability_estimate": "high/medium/low",
            "reasoning": "reasoning for alternative 3",
            "transition_effort": "Low/Moderate/High"
        }},
        {{
            "career": "alternative career name 4",
            "similarity_to_dream": "similarity description",
            "viability_estimate": "high/medium/low",
            "reasoning": "reasoning for alternative 4",
            "transition_effort": "Low/Moderate/High"
        }},
        {{
            "career": "alternative career name 5",
            "similarity_to_dream": "similarity description",
            "viability_estimate": "high/medium/low",
            "reasoning": "reasoning for alternative 5",
            "transition_effort": "Low/Moderate/High"
        }}
    ],
    "summary": "1-2 paragraph summary about these alternative careers and why they might be good options given the person's profile, education, and interests"
}}

REQUIREMENTS:
1. MUST provide exactly 5 alternatives
2. All careers must share at least some skills or interests with the dream career
3. Viability estimates: high/medium/low (choose one per alternative)
4. Reasoning must be specific to the person's profile
5. Transition effort: Low/Moderate/High (choose one per alternative)
6. Summary must be 1-2 paragraphs explaining the alternatives
7. Return ONLY valid JSON, no markdown, no explanation, no extra text
"""

        result = self.client.generate_structured_json(
            prompt,
            required_fields=["alternatives", "summary"],
            temperature=0.7,
            max_tokens=1200,
        )

        return {
            "alternatives": result.get("alternatives", []),
            "summary": result.get("summary", ""),
            "status": "success",
        }
