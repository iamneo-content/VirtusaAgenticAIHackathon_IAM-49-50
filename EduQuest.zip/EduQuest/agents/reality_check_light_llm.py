"""Reality Check Light LLM Agent - EASY path brief analysis."""

from typing import Dict, Any
from agents.base_llm_agent import BaseLLMAgent


class RealityCheckLightLLMAgent(BaseLLMAgent):
    """Generates brief reality check for high viability cases."""

    def generate_reality_check(
        self, profile: Dict[str, Any], ml_results: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Generate brief reality check analysis.

        Args:
            profile: Extracted user profile
            ml_results: ML prediction results

        Returns:
            Dictionary with light reality_check and status
        """
        viability = ml_results.get("viability_score", 0)

        prompt = f"""
Provide a brief, encouraging reality check for this career transition.

PROFILE:
Career Goal: {profile.get('career_field')}
Education: {profile.get('current_education_level')}

ML Score: {viability:.2f}

Return valid JSON with EXACT field names:
{{
    "honest_assessment": "brief assessment (2-3 sentences)",
    "major_challenges": ["challenge 1", "challenge 2"],
    "success_probability": "positive probability statement",
    "mindset_requirements": ["mindset shift 1"]
}}

Requirements:
1. Brief and encouraging tone
2. honest_assessment should be 2-3 sentences
3. major_challenges should be 2 items (common challenges)
4. success_probability should be positive given high viability
5. mindset_requirements should be 1 key mindset shift needed
6. Use EXACT field names: honest_assessment, major_challenges, success_probability, mindset_requirements
7. Return only valid JSON
"""

        result = self.client.generate_structured_json(
            prompt,
            required_fields=["honest_assessment", "major_challenges", "success_probability", "mindset_requirements"],
            temperature=0.5,
            max_tokens=350,
        )

        return {
            "reality_check": result,
            "status": "success",
        }
