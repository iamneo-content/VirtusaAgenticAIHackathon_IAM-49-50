"""Career Viability Scorer ML Agent - predicts career viability (0-1 score)."""

import pickle
import os
from typing import Dict, Any
import warnings
warnings.filterwarnings('ignore')

# CRITICAL: Set scikit-learn thread control to avoid deadlocks in parallel execution
os.environ['SCIKIT_LEARN_ASSUME_FINITE'] = 'True'
os.environ['SKLEARN_THREADING_CONTROL'] = 'true'


class CareerViabilityScorerMLAgent:
    """Predicts career viability score using trained ML model."""

    def __init__(self):
        """Load pre-trained model, scaler, and encoder."""
        # Set n_jobs=1 for thread-safe execution and disable threading
        import sklearn
        sklearn.set_config(assume_finite=True, working_memory=128)

        model_dir = os.path.join(
            os.path.dirname(__file__), "..", "ml", "models"
        )

        self.model = pickle.load(
            open(os.path.join(model_dir, "career_viability_model.pkl"), "rb")
        )
        # Ensure model doesn't use parallel processing
        if hasattr(self.model, 'n_jobs'):
            self.model.n_jobs = 1

        self.scaler = pickle.load(
            open(os.path.join(model_dir, "career_viability_scaler.pkl"), "rb")
        )
        self.encoder = pickle.load(
            open(os.path.join(model_dir, "career_viability_encoder.pkl"), "rb")
        )

    def predict_viability(self, profile: Dict[str, Any]) -> Dict[str, Any]:
        """
        Predict career viability score.

        Args:
            profile: Extracted user profile containing:
                - career_field: str
                - current_education_level: str
                - years_of_experience: int
                - budget_constraint: str
                - timeline_urgency: str
                - gpa_percentile: float
                - research_experience_months: int
                - project_portfolio_count: int

        Returns:
            Dictionary with:
            - viability_score: float (0-1)
            - status: "success"

        Raises:
            Exception: If prediction fails or model files missing
        """
        career_field = profile.get("career_field", "")
        education_level = profile.get("current_education_level", "")
        budget = profile.get("budget_constraint", "")
        timeline = profile.get("timeline_urgency", "")
        years_exp = profile.get("years_of_experience", 0)
        gpa_percentile = profile.get("gpa_percentile", 0.5)
        research_months = profile.get("research_experience_months", 0)
        portfolio_count = profile.get("project_portfolio_count", 0)

        # Encode categorical features using the saved encoders
        # Handle unseen labels by using the most common class (first in encoder.classes_)
        try:
            encoded_career = self.encoder["career_field"].transform([career_field])[0]
        except ValueError:
            encoded_career = self.encoder["career_field"].transform([self.encoder["career_field"].classes_[0]])[0]

        try:
            encoded_education = self.encoder["current_education_level"].transform([education_level])[0]
        except ValueError:
            encoded_education = self.encoder["current_education_level"].transform([self.encoder["current_education_level"].classes_[0]])[0]

        try:
            encoded_budget = self.encoder["budget_constraint"].transform([budget])[0]
        except ValueError:
            encoded_budget = self.encoder["budget_constraint"].transform([self.encoder["budget_constraint"].classes_[0]])[0]

        try:
            encoded_timeline = self.encoder["timeline_urgency"].transform([timeline])[0]
        except ValueError:
            encoded_timeline = self.encoder["timeline_urgency"].transform([self.encoder["timeline_urgency"].classes_[0]])[0]

        # Build features list with only extracted profile fields
        features = [
            [
                encoded_career,
                encoded_education,
                encoded_budget,
                encoded_timeline,
                years_exp,
                gpa_percentile,
                research_months,
                portfolio_count,
            ]
        ]

        features_scaled = self.scaler.transform(features)

        viability_score = float(self.model.predict(features_scaled)[0])
        viability_score = max(0.0, min(1.0, viability_score))

        return {
            "viability_score": viability_score,
            "status": "success",
        }
