"""Roadmap Builder Full LLM Agent - HARD path detailed roadmap."""

from typing import Dict, Any, List
from agents.base_llm_agent import BaseLLMAgent


class RoadmapBuilderFullLLMAgent(BaseLLMAgent):
    """Generates comprehensive month-by-month roadmap for career transition."""

    def generate_roadmap(
        self,
        profile: Dict[str, Any],
        ml_results: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Generate detailed month-by-month roadmap.

        Args:
            profile: Extracted user profile
            ml_results: ML prediction results

        Returns:
            Dictionary with roadmap content and status
        """
        prompt = f"""
Create a detailed 12-month career transition roadmap covering 3 phases.

PROFILE:
Current Level: {profile.get('current_education_level')} with {profile.get('years_of_experience', 0)} years experience
Target Career: {profile.get('career_field')}
Timeline Needed: {profile.get('timeline_urgency')}
Budget Available: {profile.get('budget_constraint')}

Return ONLY this JSON structure with these EXACT field names:
{{
    "phase_1_months": {{
        "months": "1-3",
        "goals": ["goal 1", "goal 2", "goal 3"],
        "actions": ["action 1", "action 2", "action 3"]
    }},
    "phase_2_months": {{
        "months": "4-8",
        "goals": ["goal 1", "goal 2", "goal 3"],
        "actions": ["action 1", "action 2", "action 3"]
    }},
    "phase_3_months": {{
        "months": "9-12",
        "goals": ["goal 1", "goal 2", "goal 3"],
        "actions": ["action 1", "action 2", "action 3"]
    }},
    "key_milestones": ["milestone 1", "milestone 2", "milestone 3", "milestone 4"],
    "success_resources": ["resource 1", "resource 2", "resource 3"],
    "timeline_notes": "any timeline adjustments, notes or critical information"
}}

CRITICAL REQUIREMENTS:
1. Use EXACT field names: phase_1_months, phase_2_months, phase_3_months, key_milestones, success_resources, timeline_notes
2. Each phase must have: months (string), goals (array), actions (array)
3. Phases must cover 12 months total (1-3, 4-8, 9-12)
4. Goals and actions must be specific and actionable
5. Include all prerequisite courses in appropriate phases
6. key_milestones must be array with 4 items (measurable)
7. success_resources should list courses, certifications, communities
8. timeline_notes should be a string with any adjustments
9. Return ONLY valid JSON, no markdown, no explanation, no extra text
"""

        result = self.client.generate_structured_json(
            prompt,
            required_fields=[
                "phase_1_months",
                "phase_2_months",
                "phase_3_months",
                "key_milestones",
                "success_resources",
                "timeline_notes",
            ],
            temperature=0.5,
            max_tokens=1500,
        )

        return {
            "roadmap": result,
            "status": "success",
        }
