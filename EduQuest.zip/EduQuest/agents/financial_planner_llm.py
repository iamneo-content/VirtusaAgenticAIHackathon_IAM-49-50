"""Financial Planner LLM Agent - HARD path financial analysis."""

from typing import Dict, Any
from agents.base_llm_agent import BaseLLMAgent


class FinancialPlannerLLMAgent(BaseLLMAgent):
    """Generates comprehensive financial plan for career transition."""

    def generate_financial_plan(
        self, profile: Dict[str, Any], reality_check: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Generate detailed financial planning analysis.

        Args:
            profile: Extracted user profile
            reality_check: Reality check output

        Returns:
            Dictionary with financial_plan and status
        """
        prompt = f"""
Create a comprehensive financial plan for career transition.

PROFILE:
Current Education: {profile.get('current_education_level')}
Experience: {profile.get('years_of_experience')} years
Target: {profile.get('career_field')}
Budget Situation: {profile.get('budget_constraint')}
Timeline: {profile.get('timeline_urgency')}

Return valid JSON with EXACT field names:
{{
    "estimated_total_cost": "cost with currency and range",
    "cost_breakdown": {{
        "education": "cost of education/courses",
        "certification": "certification costs",
        "living_expenses": "monthly living cost during transition",
        "other": "other expenses"
    }},
    "funding_sources": ["source 1", "source 2", "source 3"],
    "monthly_budget": "recommended monthly investment",
    "roi_analysis": "paragraph on return on investment",
    "market_salary_range": "salary range in current career to target career",
    "financial_timeline": "timeline for financial recovery post-transition",
    "risk_mitigation": ["mitigation strategy 1", "mitigation strategy 2"]
}}

Requirements:
1. All costs should be realistic and specific
2. Cost breakdown must be detailed (4 items)
3. Funding sources should be specific and actionable (3+ options)
4. ROI analysis should include payback period
5. Salary range must contrast current vs target
6. Risk mitigation should be financial strategies
7. Return only valid JSON
"""

        result = self.client.generate_structured_json(
            prompt,
            required_fields=[
                "estimated_total_cost",
                "cost_breakdown",
                "funding_sources",
                "monthly_budget",
                "roi_analysis",
                "market_salary_range",
                "financial_timeline",
                "risk_mitigation",
            ],
            temperature=0.6,
            max_tokens=1200,
        )

        return {
            "financial_plan": result,
            "status": "success",
        }
