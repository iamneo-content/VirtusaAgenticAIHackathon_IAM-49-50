"""Roadmap Builder Light LLM Agent - EASY path 3-phase roadmap."""

from typing import Dict, Any, List
from agents.base_llm_agent import BaseLLMAgent


class RoadmapBuilderLightLLMAgent(BaseLLMAgent):
    """Generates 3-phase high-level roadmap for clear direction cases."""

    def generate_roadmap(
        self,
        profile: Dict[str, Any],
        ml_results: Dict[str, Any],
        prerequisite_courses: List[str] = None,
    ) -> Dict[str, Any]:
        """
        Generate 3-phase high-level roadmap.

        Args:
            profile: Extracted user profile
            ml_results: ML prediction results
            prerequisite_courses: Optional list of prerequisite courses

        Returns:
            Dictionary with roadmap content and status
        """
        if prerequisite_courses is None:
            prerequisite_courses = []

        prompt = f"""
Create a 3-phase career roadmap for an achievable career transition.

TARGET CAREER: {profile.get('career_field')}
CURRENT LEVEL: {profile.get('current_education_level')}
TIMELINE: {profile.get('timeline_urgency', 'Flexible')}

PREREQUISITES TO INCLUDE: {', '.join(prerequisite_courses) if prerequisite_courses else 'None specified'}

Return ONLY this JSON structure with these EXACT field names:
{{
    "phase_1_foundation": {{
        "duration": "X months",
        "focus": "description of focus area",
        "actions": ["action 1", "action 2", "action 3"]
    }},
    "phase_2_development": {{
        "duration": "X months",
        "focus": "description of focus area",
        "actions": ["action 1", "action 2", "action 3"]
    }},
    "phase_3_transition": {{
        "duration": "X months",
        "focus": "final transition preparations",
        "actions": ["action 1", "action 2", "action 3"]
    }},
    "key_milestones": ["milestone 1", "milestone 2", "milestone 3"],
    "critical_resources": ["resource 1", "resource 2", "resource 3"]
}}

CRITICAL REQUIREMENTS:
1. Use EXACT field names: phase_1_foundation, phase_2_development, phase_3_transition, key_milestones, critical_resources
2. Each phase must have: duration, focus, actions
3. key_milestones must be an array with 2-3 items
4. critical_resources must be an array with 2-3 items
5. Return ONLY valid JSON, no markdown, no explanation, no extra text
"""

        result = self.client.generate_structured_json(
            prompt,
            required_fields=[
                "phase_1_foundation",
                "phase_2_development",
                "phase_3_transition",
                "key_milestones",
                "critical_resources",
            ],
            temperature=0.5,
            max_tokens=600,
        )

        return {
            "roadmap": result,
            "status": "success",
        }
