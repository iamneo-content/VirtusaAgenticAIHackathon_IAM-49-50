"""Market Context Light LLM Agent - EASY path brief market analysis."""

from typing import Dict, Any
from agents.base_llm_agent import BaseLLMAgent


class MarketContextLightLLMAgent(BaseLLMAgent):
    """Provides brief market context for career field."""

    def get_market_context(self, career_field: str) -> Dict[str, Any]:
        """
        Get brief market context for career.

        Args:
            career_field: Target career field

        Returns:
            Dictionary with market_context and status
        """
        prompt = f"""
Provide brief market overview for this career.

CAREER: {career_field}

Return valid JSON with EXACT field names:
{{
    "job_demand_trend": "brief demand outlook",
    "salary_range_inr": "salary range in INR",
    "growth_forecast": "brief growth outlook",
    "geographic_hotspots": ["location 1"],
    "required_certifications": ["certification"],
    "industry_insights": "one sentence on industry",
    "competitive_landscape": "one sentence on differentiation",
    "emerging_opportunities": ["opportunity"],
    "market_risks": ["risk"]
}}

Requirements:
1. All fields must be brief (1-2 sentences each)
2. job_demand_trend: Brief demand outlook
3. salary_range_inr: Salary in INR typical range
4. growth_forecast: Brief growth outlook (1-2 sentences, encouraging)
5. geographic_hotspots: 1 key location
6. required_certifications: 1 relevant certification
7. industry_insights: 1 sentence on industry
8. competitive_landscape: 1 sentence on differentiation
9. emerging_opportunities: 1 emerging opportunity
10. market_risks: 1 market-related risk
11. Return ONLY valid JSON with EXACT field names above
"""

        result = self.client.generate_structured_json(
            prompt,
            required_fields=["job_demand_trend", "salary_range_inr", "growth_forecast", "geographic_hotspots", "required_certifications", "industry_insights", "competitive_landscape", "emerging_opportunities", "market_risks"],
            temperature=0.4,
            max_tokens=350,
        )

        return {
            "market_context": result,
            "status": "success",
        }
