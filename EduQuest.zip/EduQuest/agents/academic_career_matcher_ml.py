"""Academic Career Matcher ML Agent - predicts academic-career fit (0-100 score)."""

import pickle
import os
from typing import Dict, Any, List
import warnings
warnings.filterwarnings('ignore')

# CRITICAL: Set scikit-learn thread control to avoid deadlocks in parallel execution
os.environ['SCIKIT_LEARN_ASSUME_FINITE'] = 'True'
os.environ['SKLEARN_THREADING_CONTROL'] = 'true'


class AcademicCareerMatcherMLAgent:
    """Predicts academic-career fit and identifies skill gaps."""

    SKILL_GAP_CATEGORIES = ["Low", "Medium", "High"]

    def __init__(self):
        """Load pre-trained model, scaler, and encoder."""
        # Set n_jobs=1 for thread-safe execution and disable threading
        import sklearn
        sklearn.set_config(assume_finite=True, working_memory=128)

        model_dir = os.path.join(
            os.path.dirname(__file__), "..", "ml", "models"
        )

        self.model = pickle.load(
            open(os.path.join(model_dir, "academic_matcher_model.pkl"), "rb")
        )
        # Ensure model doesn't use parallel processing
        if hasattr(self.model, 'n_jobs'):
            self.model.n_jobs = 1

        self.scaler = pickle.load(
            open(os.path.join(model_dir, "academic_matcher_scaler.pkl"), "rb")
        )
        self.encoder = pickle.load(
            open(os.path.join(model_dir, "academic_matcher_encoder.pkl"), "rb")
        )

    def predict_fit(self, profile: Dict[str, Any]) -> Dict[str, Any]:
        """
        Predict academic-career fit.

        Args:
            profile: Extracted user profile containing:
                - current_education_level or current_degree_field: str
                - gpa_percentile: float (0-1)
                - research_experience_months: int
                - project_portfolio_count: int

        Returns:
            Dictionary with:
            - academic_fit_score: float (0-100)
            - status: "success"

        Raises:
            Exception: If prediction fails or model files missing
        """
        # Use current_degree_field or fallback to current_education_level
        degree_field = profile.get("current_degree_field", "") or profile.get("current_education_level", "")
        gpa_percentile = profile.get("gpa_percentile", 0.5)
        research_months = profile.get("research_experience_months", 0)
        portfolio_count = profile.get("project_portfolio_count", 0)

        # Encode categorical feature using the saved encoder
        # Handle unseen labels by using the most common class (first in encoder.classes_)
        try:
            encoded_degree = self.encoder["current_degree_field"].transform([degree_field])[0]
        except ValueError:
            encoded_degree = self.encoder["current_degree_field"].transform([self.encoder["current_degree_field"].classes_[0]])[0]

        features = [[encoded_degree, gpa_percentile, research_months, portfolio_count]]

        features_scaled = self.scaler.transform(features)

        fit_score = float(self.model.predict(features_scaled)[0])
        fit_score = max(0.0, min(100.0, fit_score))

        return {
            "academic_fit_score": fit_score,
            "status": "success",
        }
