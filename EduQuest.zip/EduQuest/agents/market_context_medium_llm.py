"""Market Context Medium LLM Agent - MEDIUM path moderate market analysis."""

from typing import Dict, Any
from agents.base_llm_agent import BaseLLMAgent


class MarketContextMediumLLMAgent(BaseLLMAgent):
    """Provides moderate market context for career field."""

    def get_market_context(self, career_field: str) -> Dict[str, Any]:
        """
        Get moderate market context for career.

        Args:
            career_field: Target career field

        Returns:
            Dictionary with market_context and status
        """
        prompt = f"""
Provide market context for this career field.

CAREER FIELD: {career_field}

Return valid JSON with EXACT field names:
{{
    "job_demand_trend": "job market demand overview and trend",
    "salary_range_inr": "salary range in INR with typical entry/mid levels",
    "growth_forecast": "career growth outlook and trajectory",
    "geographic_hotspots": ["location 1", "location 2"],
    "required_certifications": ["certification 1", "certification 2"],
    "industry_insights": "paragraph on industry status and trends",
    "competitive_landscape": "brief note on competition and differentiation",
    "emerging_opportunities": ["opportunity 1"],
    "market_risks": ["risk 1"]
}}

Requirements:
1. job_demand_trend: Brief overview of current and future demand
2. salary_range_inr: Salary range in INR with typical entry and mid-level levels
3. growth_forecast: 2-3 sentence growth outlook
4. geographic_hotspots: 2 key locations in India
5. required_certifications: 2 relevant certifications
6. industry_insights: 1-2 sentences on industry status
7. competitive_landscape: 1 sentence on differentiation
8. emerging_opportunities: 1 emerging opportunity
9. market_risks: 1 market-related risk
10. Return ONLY valid JSON with EXACT field names above
"""

        result = self.client.generate_structured_json(
            prompt,
            required_fields=[
                "job_demand_trend",
                "salary_range_inr",
                "growth_forecast",
                "geographic_hotspots",
                "required_certifications",
                "industry_insights",
                "competitive_landscape",
                "emerging_opportunities",
                "market_risks",
            ],
            temperature=0.4,
            max_tokens=600,
        )

        return {
            "market_context": result,
            "status": "success",
        }
