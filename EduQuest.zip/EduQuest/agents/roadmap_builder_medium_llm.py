"""Roadmap Builder Medium LLM Agent - MEDIUM path quarterly roadmap."""

from typing import Dict, Any, List
from agents.base_llm_agent import BaseLLMAgent


class RoadmapBuilderMediumLLMAgent(BaseLLMAgent):
    """Generates quarterly career transition roadmap."""

    def generate_roadmap(
        self,
        profile: Dict[str, Any],
        ml_results: Dict[str, Any],
        prerequisite_courses: List[str] = None,
    ) -> Dict[str, Any]:
        """
        Generate quarterly roadmap.

        Args:
            profile: Extracted user profile
            ml_results: ML prediction results
            prerequisite_courses: Optional list of prerequisite courses

        Returns:
            Dictionary with roadmap content and status
        """
        if prerequisite_courses is None:
            prerequisite_courses = []

        prompt = f"""
Create a quarterly (4-quarter) career transition roadmap.

PROFILE:
Current Level: {profile.get('current_education_level')}
Target Career: {profile.get('career_field')}
Timeline: {profile.get('timeline_urgency')}

PREREQUISITES TO INCLUDE: {', '.join(prerequisite_courses) if prerequisite_courses else 'None specified'}

Return ONLY this JSON structure with these EXACT field names:
{{
    "q1": {{
        "goals": ["goal 1", "goal 2", "goal 3"],
        "actions": ["action 1", "action 2", "action 3"]
    }},
    "q2": {{
        "goals": ["goal 1", "goal 2", "goal 3"],
        "actions": ["action 1", "action 2", "action 3"]
    }},
    "q3": {{
        "goals": ["goal 1", "goal 2"],
        "actions": ["action 1", "action 2"]
    }},
    "q4": {{
        "goals": ["goal 1", "goal 2"],
        "actions": ["action 1", "action 2"]
    }},
    "key_milestones": ["milestone 1", "milestone 2", "milestone 3"],
    "resources": ["resource 1", "resource 2", "resource 3"]
}}

CRITICAL REQUIREMENTS:
1. Use EXACT field names: q1, q2, q3, q4, key_milestones, resources
2. Q1-Q4 should progressively advance toward career goal
3. Each quarter must have: goals (array), actions (array)
4. Include prerequisite courses in appropriate quarters
5. key_milestones must be array with 3 items
6. resources must be array with 3 items
7. Return ONLY valid JSON, no markdown, no explanation, no extra text
"""

        result = self.client.generate_structured_json(
            prompt,
            required_fields=["q1", "q2", "q3", "q4", "key_milestones", "resources"],
            temperature=0.5,
            max_tokens=900,
        )

        return {
            "roadmap": result,
            "status": "success",
        }
