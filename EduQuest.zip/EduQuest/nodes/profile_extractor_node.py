"""Profile Extractor Node - extracts structured profile from free text."""

from typing import Dict, Any
from state import EduQuestState
from agents.profile_extractor_llm import ProfileExtractorLLMAgent


def profile_extractor_node(state: EduQuestState, client) -> EduQuestState:
    """Extract structured profile using LLM."""
    try:
        agent = ProfileExtractorLLMAgent(client)
        raw_inputs = {
            "dream_career": state.get("dream_career", ""),
            "current_academics": state.get("current_academics", ""),
            "constraints": state.get("constraints", ""),
            "interests": state.get("interests", ""),
            "other_concerns": state.get("other_concerns", ""),
        }
        result = agent.extract_structured_profile(raw_inputs)
        if result.get("status") == "success":
            profile = result.get("extracted_profile", {})
            state["extracted_profile"] = profile
            state["profile_extraction_complete"] = True
            state["career_field"] = profile.get("career_field", "")
            state["current_education_level"] = profile.get("current_education_level", "")
            state["years_of_experience"] = profile.get("years_of_experience", 0)
            state["budget_constraint"] = profile.get("budget_constraint", "")
            state["timeline_urgency"] = profile.get("timeline_urgency", "")
            state["interests_list"] = profile.get("interests_list", [])
            state["concerns_list"] = profile.get("concerns_list", [])
        else:
            state["error_messages"].append("Profile extraction failed")
            state["error_occurred"] = True
        return state
    except Exception as e:
        state["error_messages"].append(f"Profile extractor node error: {str(e)}")
        state["error_occurred"] = True
        return state
