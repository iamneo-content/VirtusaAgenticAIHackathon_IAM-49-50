"""Career Viability Scorer Node - ML predictions."""

from state import EduQuestState
from agents.career_viability_scorer_ml import CareerViabilityScorerMLAgent


def career_viability_scorer_node(state: EduQuestState) -> EduQuestState:
    """Predict career viability score using ML model."""
    try:
        agent = CareerViabilityScorerMLAgent()

        # Use extracted profile which contains all 17 fields extracted by LLM
        extracted_profile = state.get("extracted_profile", {})

        if not extracted_profile:
            state["error_messages"].append("No extracted profile found for viability scoring")
            state["error_occurred"] = True
            return state

        result = agent.predict_viability(extracted_profile)
        state["viability_score"] = result.get("viability_score", 0.0)
        return state
    except Exception as e:
        state["error_messages"].append(f"Career viability scorer error: {str(e)}")
        state["error_occurred"] = True
        return state
