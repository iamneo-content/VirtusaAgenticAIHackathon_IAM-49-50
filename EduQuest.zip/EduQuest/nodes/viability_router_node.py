"""Viability Router Node - pure logic node for path routing."""

from state import EduQuestState


def viability_router_node(state: EduQuestState) -> EduQuestState:
    """Route to HARD/MEDIUM/EASY path based on career viability score.

    Uses simple thresholding on viability score since training data is balanced
    across all three path categories (33.3% HARD, 33.6% MEDIUM, 33.0% EASY).

    Routing Decision:
    - HARD_PATH: viability < 0.3 (challenging career transitions)
    - MEDIUM_PATH: 0.3 ≤ viability < 0.6 (moderate transitions)
    - EASY_PATH: viability ≥ 0.6 (natural career progressions)
    """
    viability = state.get("viability_score", 0.5)

    if viability < 0.3:
        state["path_taken"] = "HARD_PATH"
        state["daily_budget_tier"] = "hard_path"
    elif viability < 0.6:
        state["path_taken"] = "MEDIUM_PATH"
        state["daily_budget_tier"] = "medium_path"
    else:
        state["path_taken"] = "EASY_PATH"
        state["daily_budget_tier"] = "easy_path"

    return state
