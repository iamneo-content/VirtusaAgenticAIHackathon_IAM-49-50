"""ML Results Merger Node - pure logic node."""

from state import EduQuestState


def ml_results_merger_node(state: EduQuestState) -> EduQuestState:
    """Merge ML results with weighted average formula."""
    viability = state.get("viability_score", 0.0)
    academic_fit = state.get("academic_fit_score", 0.0)
    overall = viability * 0.6 + (academic_fit / 100.0) * 0.4
    state["overall_feasibility"] = max(0.0, min(1.0, overall))
    return state
