"""Market Context Light Node - EASY path."""

from state import EduQuestState
from agents.market_context_light_llm import MarketContextLightLLMAgent


def market_context_light_node(state: EduQuestState, client) -> EduQuestState:
    try:
        agent = MarketContextLightLLMAgent(client)
        career_field = state.get("career_field", "")
        result = agent.get_market_context(career_field)
        state["market_context_light"] = result.get("market_context", {})
        return state
    except Exception as e:
        state["error_messages"].append(f"Market context light error: {str(e)}")
        state["error_occurred"] = True
        return state
