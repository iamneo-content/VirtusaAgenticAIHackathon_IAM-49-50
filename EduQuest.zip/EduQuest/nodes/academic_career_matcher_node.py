"""Academic Career Matcher Node - ML predictions."""

from state import EduQuestState
from agents.academic_career_matcher_ml import AcademicCareerMatcherMLAgent


def academic_career_matcher_node(state: EduQuestState) -> EduQuestState:
    """Predict academic-career fit using ML model."""
    try:
        agent = AcademicCareerMatcherMLAgent()

        # Use extracted profile which contains all 17 fields extracted by LLM
        extracted_profile = state.get("extracted_profile", {})

        if not extracted_profile:
            state["error_messages"].append("No extracted profile found for academic matcher")
            state["error_occurred"] = True
            return state

        result = agent.predict_fit(extracted_profile)
        state["academic_fit_score"] = result.get("academic_fit_score", 0.0)
        return state
    except Exception as e:
        state["error_messages"].append(f"Academic matcher error: {str(e)}")
        state["error_occurred"] = True
        return state
