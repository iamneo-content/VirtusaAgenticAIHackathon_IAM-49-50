"""Market Context Full Node - HARD path."""

from state import EduQuestState
from agents.market_context_full_llm import MarketContextFullLLMAgent


def market_context_full_node(state: EduQuestState, client) -> EduQuestState:
    try:
        agent = MarketContextFullLLMAgent(client)
        career_field = state.get("career_field", "")
        result = agent.get_market_context(career_field)
        state["market_context"] = result.get("market_context", {})
        return state
    except Exception as e:
        state["error_messages"].append(f"Market context full error: {str(e)}")
        state["error_occurred"] = True
        return state
