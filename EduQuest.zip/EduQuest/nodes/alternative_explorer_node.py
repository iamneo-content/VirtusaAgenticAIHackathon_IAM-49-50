"""Alternative Explorer Node - HARD path only."""

from state import EduQuestState
from agents.alternative_explorer_llm import AlternativeExplorerLLMAgent


def alternative_explorer_node(state: EduQuestState, client) -> EduQuestState:
    try:
        agent = AlternativeExplorerLLMAgent(client)
        profile = {
            "career_field": state.get("career_field", ""),
            "current_education_level": state.get("current_education_level", ""),
            "years_of_experience": state.get("years_of_experience", 0),
            "interests_list": state.get("interests_list", []),
        }
        viability_score = state.get("viability_score", 0.0)
        result = agent.explore_alternatives(profile, viability_score)
        state["alternatives_output"] = result.get("alternatives", {})
        return state
    except Exception as e:
        state["error_messages"].append(f"Alternative explorer error: {str(e)}")
        state["error_occurred"] = True
        return state
