"""Roadmap Builder Light Node - EASY path."""

from state import EduQuestState
from agents.roadmap_builder_light_llm import RoadmapBuilderLightLLMAgent


def roadmap_builder_light_node(state: EduQuestState, client) -> EduQuestState:
    try:
        agent = RoadmapBuilderLightLLMAgent(client)
        profile = {
            "career_field": state.get("career_field", ""),
            "current_education_level": state.get("current_education_level", ""),
            "years_of_experience": state.get("years_of_experience", 0),
        }
        ml_results = {
            "viability_score": state.get("viability_score", 0.0),
            "academic_fit_score": state.get("academic_fit_score", 0.0),
        }
        result = agent.generate_roadmap(profile, ml_results)
        state["roadmap_light_output"] = result.get("roadmap", {})
        return state
    except Exception as e:
        state["error_messages"].append(f"Roadmap builder light error: {str(e)}")
        state["error_occurred"] = True
        return state
