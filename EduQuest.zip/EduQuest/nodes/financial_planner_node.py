"""Financial Planner Node - HARD path only."""

from state import EduQuestState
from agents.financial_planner_llm import FinancialPlannerLLMAgent


def financial_planner_node(state: EduQuestState, client) -> EduQuestState:
    try:
        agent = FinancialPlannerLLMAgent(client)
        profile = {
            "career_field": state.get("career_field", ""),
            "current_education_level": state.get("current_education_level", ""),
            "years_of_experience": state.get("years_of_experience", 0),
            "budget_constraints": state.get("budget_constraints", ""),
            "timeline_urgency": state.get("timeline_urgency", ""),
        }
        reality_check = state.get("reality_check_output", {})
        result = agent.generate_financial_plan(profile, reality_check)
        state["financial_plan_output"] = result.get("financial_plan", {})
        return state
    except Exception as e:
        state["error_messages"].append(f"Financial planner error: {str(e)}")
        state["error_occurred"] = True
        return state
