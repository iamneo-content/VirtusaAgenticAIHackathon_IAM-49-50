"""Input Validator Node - validates raw user inputs."""

from typing import Dict, Any
from state import EduQuestState
from agents.input_validator_agent import InputValidatorAgent


def input_validator_node(state: EduQuestState) -> EduQuestState:
    """
    Validate all 5 input text fields.

    Args:
        state: Current EduQuestState

    Returns:
        Updated state with validation results
    """
    try:
        agent = InputValidatorAgent()

        raw_inputs = {
            "dream_career": state.get("dream_career", ""),
            "current_academics": state.get("current_academics", ""),
            "constraints": state.get("constraints", ""),
            "interests": state.get("interests", ""),
            "other_concerns": state.get("other_concerns", ""),
        }

        result = agent.validate_inputs(raw_inputs)

        state["validation_errors"] = result.get("validation_errors", [])
        state["parsing_complete"] = result.get("is_valid", False)

        if not result.get("is_valid", False):
            state["error_occurred"] = True
            state["error_messages"].extend(result.get("validation_errors", []))

        return state

    except Exception as e:
        state["error_messages"].append(f"Input validator node error: {str(e)}")
        state["error_occurred"] = True
        return state
