"""Output Aggregator Node - Aggregates outputs based on path taken."""

from state import EduQuestState


def output_aggregator_node(state: EduQuestState) -> EduQuestState:
    path = state.get("path_taken", "UNKNOWN")

    if path == "HARD_PATH":
        aggregated = {
            "path": path,
            "reality_check": state.get("reality_check_output", {}),
            "financial_plan": state.get("financial_plan_output", {}),
            "roadmap": state.get("roadmap_output", {}),
            "alternatives": state.get("alternatives_output", {}),
            "market_context": state.get("market_context", {}),
        }
    elif path == "MEDIUM_PATH":
        aggregated = {
            "path": path,
            "reality_check": state.get("reality_check_medium_output", {}),
            "roadmap": state.get("roadmap_medium_output", {}),
            "market_context": state.get("market_context_medium", {}),
        }
    else:  # EASY_PATH
        aggregated = {
            "path": path,
            "reality_check": state.get("reality_check_light_output", {}),
            "roadmap": state.get("roadmap_light_output", {}),
            "market_context": state.get("market_context_light", {}),
        }

    state["aggregated_output"] = aggregated
    state["processing_complete"] = True
    return state
