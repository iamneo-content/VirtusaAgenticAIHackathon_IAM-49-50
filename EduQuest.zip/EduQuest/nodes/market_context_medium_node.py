"""Market Context Medium Node - MEDIUM path."""

from state import EduQuestState
from agents.market_context_medium_llm import MarketContextMediumLLMAgent


def market_context_medium_node(state: EduQuestState, client) -> EduQuestState:
    try:
        agent = MarketContextMediumLLMAgent(client)
        career_field = state.get("career_field", "")
        result = agent.get_market_context(career_field)
        state["market_context_medium"] = result.get("market_context", {})
        return state
    except Exception as e:
        state["error_messages"].append(f"Market context medium error: {str(e)}")
        state["error_occurred"] = True
        return state
