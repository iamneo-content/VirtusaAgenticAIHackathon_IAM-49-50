"""Reality Check Medium Node - MEDIUM path."""

from state import EduQuestState
from agents.reality_check_medium_llm import RealityCheckMediumLLMAgent


def reality_check_medium_node(state: EduQuestState, client) -> EduQuestState:
    try:
        agent = RealityCheckMediumLLMAgent(client)
        profile = {
            "career_field": state.get("career_field", ""),
            "current_education_level": state.get("current_education_level", ""),
            "years_of_experience": state.get("years_of_experience", 0),
            "budget_constraints": state.get("budget_constraints", ""),
            "timeline_urgency": state.get("timeline_urgency", ""),
            "interests_list": state.get("interests_list", []),
            "concerns_list": state.get("concerns_list", []),
        }
        ml_results = {
            "viability_score": state.get("viability_score", 0.0),
            "academic_fit_score": state.get("academic_fit_score", 0.0),
        }
        result = agent.generate_reality_check(profile, ml_results)
        state["reality_check_medium_output"] = result.get("reality_check", {})
        return state
    except Exception as e:
        state["error_messages"].append(f"Reality check medium error: {str(e)}")
        state["error_occurred"] = True
        return state
