"""Reality Check Light Node - EASY path."""

from state import EduQuestState
from agents.reality_check_light_llm import RealityCheckLightLLMAgent


def reality_check_light_node(state: EduQuestState, client) -> EduQuestState:
    try:
        agent = RealityCheckLightLLMAgent(client)
        profile = {
            "career_field": state.get("career_field", ""),
            "current_education_level": state.get("current_education_level", ""),
            "years_of_experience": state.get("years_of_experience", 0),
        }
        ml_results = {
            "viability_score": state.get("viability_score", 0.0),
            "academic_fit_score": state.get("academic_fit_score", 0.0),
        }
        result = agent.generate_reality_check(profile, ml_results)
        state["reality_check_light_output"] = result.get("reality_check", {})
        return state
    except Exception as e:
        state["error_messages"].append(f"Reality check light error: {str(e)}")
        state["error_occurred"] = True
        return state
