#!/usr/bin/env python3
"""
LearnBuddy Workflow Orchestration (7-Node DAG)

Builds optimized LangGraph workflow with intelligent parallel execution.
Inspired by VentureLens architecture patterns.

Pipeline Structure:
  form_parser (merged parsing + analysis)
  ↓
  [proficiency_assessment_ml, learning_readiness_ml] (parallel)
  ↓
  learning_path_generator (convergence point)
  ↓
  path_validator
  ↓
  personal_coach
  ↓
  report_generator (exit)
"""

from langgraph.graph import StateGraph, START, END
from state import LearnerViabilityState, get_initial_state
from nodes.form_parser_node import form_parser_node
from nodes.proficiency_assessment_node import proficiency_assessment_ml_node
from nodes.learning_readiness_node import learning_readiness_ml_node
from nodes.learning_path_generator_node import learning_path_generator_node
from nodes.path_validator_node import path_validator_node
from nodes.personal_coach_node import personal_coach_node
from nodes.report_generator_node import report_generator_node


def build_workflow():
    """
    Build optimized 7-node LearnBuddy workflow with LangGraph.

    DAG Structure:
    START
      ↓
    form_parser (validates input, analyzes profile)
      ↓
    [proficiency_assessment_ml, learning_readiness_ml] (parallel, CPU-bound)
      ↓
    learning_path_generator (receives output from both parallel nodes)
      ↓
    path_validator (validates plans against constraints)
      ↓
    personal_coach (personalizes tone/recommendations)
      ↓
    report_generator (creates final report)
      ↓
    END

    Returns:
        Compiled StateGraph for workflow execution
    """

    workflow = StateGraph(LearnerViabilityState)

    # ========== ADD NODES ==========
    workflow.add_node("form_parser", form_parser_node)
    workflow.add_node("proficiency_assessment_ml", proficiency_assessment_ml_node)
    workflow.add_node("learning_readiness_ml", learning_readiness_ml_node)
    workflow.add_node("learning_path_generator", learning_path_generator_node)
    workflow.add_node("path_validator", path_validator_node)
    workflow.add_node("personal_coach", personal_coach_node)
    workflow.add_node("report_generator", report_generator_node)

    # ========== DEFINE EDGES ==========

    # Entry point
    workflow.set_entry_point("form_parser")

    # Parallel execution: Both ML models run in parallel after parsing
    workflow.add_edge("form_parser", "proficiency_assessment_ml")
    workflow.add_edge("form_parser", "learning_readiness_ml")

    # Convergence: Both parallel nodes feed into learning_path_generator
    # (LangGraph will wait for both to complete before proceeding)
    workflow.add_edge("proficiency_assessment_ml", "learning_path_generator")
    workflow.add_edge("learning_readiness_ml", "learning_path_generator")

    # Sequential execution: Linear chain through final nodes
    workflow.add_edge("learning_path_generator", "path_validator")
    workflow.add_edge("path_validator", "personal_coach")
    workflow.add_edge("personal_coach", "report_generator")

    # Exit
    workflow.add_edge("report_generator", END)

    # Compile workflow
    return workflow.compile()


def run_microplan_workflow(learner_json: dict) -> LearnerViabilityState:
    """
    Execute the complete personalized learning plan generation workflow.

    Pipeline Stages:
    1. Form Parsing: Validates input, extracts 40+ profile metrics
    2. Parallel ML Assessment: Gap detection + Difficulty prediction (concurrent)
    3. Learning Path Generation: Creates 3 plan variants (Conservative/Standard/Aggressive)
    4. Validation: Checks feasibility against learner constraints
    5. Personalization: Adapts tone based on learning style
    6. Reporting: Generates final markdown + JSON reports

    Args:
        learner_json: Raw learner profile input (dict)

    Returns:
        Complete LearnerViabilityState with all analysis and recommendations
    """

    # Build workflow
    app = build_workflow()

    # Initialize state with all fields ready
    initial_state = get_initial_state(learner_json)

    # Run workflow with logging
    print("\n" + "=" * 70)
    print("LEARNBUDDY MICRO - PERSONALIZED LEARNING PLAN GENERATOR")
    print("=" * 70)

    result = app.invoke(initial_state)

    print("\n" + "=" * 70)
    print("WORKFLOW COMPLETE!")
    print("=" * 70)

    return result


# ========== TESTING & VISUALIZATION ==========

if __name__ == "__main__":
    print("LearnBuddy Micro Workflow ready")
    workflow = build_workflow()
    print(f"Workflow compiled successfully with {len(workflow.nodes)} nodes")
