#!/usr/bin/env python3
"""
Learning Path Generator Node (LLM-based Plan Generation)

Generates 3 personalized learning plan variants using Gemini LLM:
- Conservative (slow pace, foundation-heavy)
- Standard (balanced approach)
- Aggressive (fast-track intensive)

Uses centralized LearnerLLMClient for API key management and rotation.
"""

from utils.llm_client import LearnerLLMClient
from state import LearnerViabilityState


def learning_path_generator_node(state: LearnerViabilityState) -> dict:
    """
    Generate 3 personalized learning plan variants.

    Receives merged output from both parallel ML nodes:
    1. Gap detection (identified_gaps, confidence_scores, urgency)
    2. Difficulty prediction (difficulty, confidence, readiness assessment)

    Plan Variants:
    - Plan A (Conservative): 1.5× timeline, 8 hrs/week, prerequisites required
    - Plan B (Standard): 1× timeline, 10 hrs/week, prerequisites required
    - Plan C (Aggressive): 0.7× timeline, 15 hrs/week, prerequisites optional

    Each plan includes:
    - topics, resources, milestones, prerequisites, success_criteria
    - difficulty_progression, duration_weeks, hours_per_week, intensity

    Args:
        state: LearnerViabilityState with analyzed_profile and ML predictions

    Returns:
        dict with plan_variant_a/b/c, plan_generation_complete flag
    """
    print("\n[3] LEARNING PATH GENERATOR NODE (LLM)")
    print("=" * 60)

    try:
        # Extract inputs from state
        analyzed = state["analyzed_profile"]
        gaps = state["identified_gaps"]
        difficulty = state["recommended_difficulty"]

        if not analyzed:
            raise ValueError("analyzed_profile is missing")

        # Build LLM client with automatic key rotation
        client = LearnerLLMClient()

        # Generate 3 plan variants
        print("  Generating 3 learning plan variants...")

        plan_a = _generate_plan_variant(
            client, analyzed, gaps, difficulty,
            variant="Conservative",
            timeline_factor=1.5,
            hours_per_week=8,
            require_prerequisites=True,
            temperature=0.3
        )
        print("  ✓ Conservative plan generated")

        plan_b = _generate_plan_variant(
            client, analyzed, gaps, difficulty,
            variant="Standard",
            timeline_factor=1.0,
            hours_per_week=10,
            require_prerequisites=True,
            temperature=0.3
        )
        print("  ✓ Standard plan generated")

        plan_c = _generate_plan_variant(
            client, analyzed, gaps, difficulty,
            variant="Aggressive",
            timeline_factor=0.7,
            hours_per_week=15,
            require_prerequisites=False,
            temperature=0.3
        )
        print("  ✓ Aggressive plan generated")

        print(f"✓ Generated 3 learning plan variants")

        return {
            "plan_variant_a": plan_a,
            "plan_variant_b": plan_b,
            "plan_variant_c": plan_c,
            "plan_generation_complete": True
        }

    except ValueError as e:
        # JSON parsing or validation errors from LLM
        error_msg = f"Learning Path Generation Validation Error: {str(e)}"
        print(f"✗ {error_msg}")
        return {
            "plan_variant_a": {},
            "plan_variant_b": {},
            "plan_variant_c": {},
            "error_occurred": True,
            "error_messages": state["error_messages"] + [error_msg],
            "plan_generation_complete": False
        }

    except Exception as e:
        # API errors, network issues, etc.
        error_msg = f"Learning Path Generation Failed: {type(e).__name__} - {str(e)}"
        print(f"✗ {error_msg}")
        return {
            "plan_variant_a": {},
            "plan_variant_b": {},
            "plan_variant_c": {},
            "error_occurred": True,
            "error_messages": state["error_messages"] + [error_msg],
            "plan_generation_complete": False
        }


def _generate_plan_variant(
    client: LearnerLLMClient,
    analyzed: dict,
    gaps: list,
    difficulty: str,
    variant: str,
    timeline_factor: float,
    hours_per_week: int,
    require_prerequisites: bool,
    temperature: float
) -> dict:
    """
    Generate a single plan variant using LLM.

    Args:
        client: LearnerLLMClient instance
        analyzed: Analyzed profile dictionary
        gaps: List of identified gaps
        difficulty: Recommended difficulty level
        variant: Variant name (Conservative/Standard/Aggressive)
        timeline_factor: Multiplier for timeline (0.7-1.5)
        hours_per_week: Recommended hours per week
        require_prerequisites: Whether prerequisites are required
        temperature: LLM temperature for this variant

    Returns:
        Parsed plan variant as dict
    """
    learner_goals = analyzed.get("derived_metrics", {}).get("primary_goal", "Learning")
    timeline = analyzed.get("derived_metrics", {}).get("target_timeline_months", 12)
    adjusted_timeline = max(1, int(timeline * timeline_factor))

    prompt = f"""
    Create a personalized {variant.lower()} learning plan with these parameters:

    Learner Profile:
    - Goal: {learner_goals}
    - Difficulty Level: {difficulty}
    - Time Available: {hours_per_week} hours/week
    - Target Timeline: {adjusted_timeline} weeks
    - Learning Gaps: {', '.join(gaps) if gaps else 'None identified'}

    Plan Requirements ({variant} variant):
    - Duration: {adjusted_timeline} weeks
    - Weekly Commitment: {hours_per_week} hours
    - Include Prerequisites: {"Yes" if require_prerequisites else "Optional"}
    - Intensity: {"Low (foundation building)" if variant == "Conservative" else "Medium (balanced)" if variant == "Standard" else "High (intensive)"}

    Return a JSON object with these exact fields:
    {{
        "duration_weeks": {adjusted_timeline},
        "hours_per_week": {hours_per_week},
        "intensity": "string",
        "topics": ["topic1", "topic2", ...],
        "resources": ["resource1", "resource2", ...],
        "milestones": ["milestone1", "milestone2", ...],
        "prerequisites": ["prereq1", "prereq2", ...],
        "success_criteria": ["criterion1", "criterion2", ...],
        "difficulty_progression": "string describing progression"
    }}
    """

    response_text = client.generate_content(
        prompt=prompt,
        temperature=temperature,
        max_tokens=2000
    )

    plan_dict = client.extract_json_from_response(response_text)

    # Validate required fields
    required_fields = [
        "duration_weeks", "hours_per_week", "intensity", "topics",
        "resources", "milestones", "prerequisites", "success_criteria"
    ]
    client.validate_response_fields(plan_dict, required_fields)

    return plan_dict
