#!/usr/bin/env python3
"""
Path Validator Node (Plan Feasibility Validation)

Validates generated learning plans against learner constraints:
- Hours per week vs availability
- Timeline vs target timeline
- Prerequisites coverage
- Difficulty alignment
- Milestone feasibility

Uses LLM to provide explanatory validation feedback.
"""

from utils.llm_client import LearnerLLMClient
from state import LearnerViabilityState


def path_validator_node(state: LearnerViabilityState) -> dict:
    """
    Validate learning plans for feasibility and quality.

    Checks:
    1. Plan structure (required fields present)
    2. Constraint satisfaction (hours, timeline, difficulty)
    3. Coherence (milestones logical, prerequisites necessary)
    4. Practicality (success criteria achievable)

    Args:
        state: LearnerViabilityState with plan_variant_a/b/c populated

    Returns:
        dict with validated plans, validation_issues, validation_complete flag
    """
    print("\n[4] PATH VALIDATOR NODE")
    print("=" * 60)

    try:
        plans = (
            state["plan_variant_a"],
            state["plan_variant_b"],
            state["plan_variant_c"]
        )
        analyzed = state["analyzed_profile"]

        if not all(plans) or not analyzed:
            raise ValueError("Plans or analyzed_profile is missing")

        # Validate plans using LLM
        client = LearnerLLMClient()
        plan_a_val, plan_b_val, plan_c_val, issues = _validate_plans_with_llm(
            client, plans, analyzed
        )

        if issues:
            print(f"✓ Validation complete with {len(issues)} warning(s)")
            for issue in issues[:3]:
                print(f"  • {issue}")
            if len(issues) > 3:
                print(f"  ... and {len(issues) - 3} more")
        else:
            print(f"✓ All plans validated successfully")

        return {
            "plan_variant_a_validated": plan_a_val,
            "plan_variant_b_validated": plan_b_val,
            "plan_variant_c_validated": plan_c_val,
            "validation_issues": issues,
            "validation_complete": True
        }

    except ValueError as e:
        error_msg = f"Path Validator Validation Error: {str(e)}"
        print(f"✗ {error_msg}")
        return {
            "plan_variant_a_validated": state.get("plan_variant_a", {}),
            "plan_variant_b_validated": state.get("plan_variant_b", {}),
            "plan_variant_c_validated": state.get("plan_variant_c", {}),
            "validation_issues": [str(e)],
            "error_occurred": True,
            "error_messages": state["error_messages"] + [error_msg],
            "validation_complete": False
        }

    except Exception as e:
        error_msg = f"Path Validator Failed: {type(e).__name__} - {str(e)}"
        print(f"✗ {error_msg}")
        return {
            "plan_variant_a_validated": state.get("plan_variant_a", {}),
            "plan_variant_b_validated": state.get("plan_variant_b", {}),
            "plan_variant_c_validated": state.get("plan_variant_c", {}),
            "validation_issues": [],
            "error_occurred": True,
            "error_messages": state["error_messages"] + [error_msg],
            "validation_complete": False
        }


def _validate_plans_with_llm(
    client: LearnerLLMClient,
    plans: tuple,
    analyzed: dict
) -> tuple:
    """
    Use LLM to validate plan coherence and feasibility.

    Args:
        client: LearnerLLMClient instance
        plans: Tuple of (plan_a, plan_b, plan_c)
        analyzed: Analyzed profile dictionary

    Returns:
        Tuple of (plan_a_validated, plan_b_validated, plan_c_validated, issues_list)
    """
    plan_a, plan_b, plan_c = plans
    hours_available = analyzed.get("derived_metrics", {}).get("hours_per_week", 10)
    timeline = analyzed.get("derived_metrics", {}).get("target_timeline_months", 12)

    prompt = f"""
    Validate these 3 learning plans for feasibility and consistency:

    Learner Constraints:
    - Available: {hours_available} hours/week
    - Timeline: {timeline} months
    - Goal: {analyzed.get("derived_metrics", {}).get("primary_goal", "Learning")}

    Plans to validate:
    1. Conservative: {hours_available * plan_a.get('hours_per_week', 8)} hours/week, {plan_a.get('duration_weeks', 12)} weeks
    2. Standard: {plan_b.get('hours_per_week', 10)} hours/week, {plan_b.get('duration_weeks', 12)} weeks
    3. Aggressive: {plan_c.get('hours_per_week', 15)} hours/week, {plan_c.get('duration_weeks', 12)} weeks

    Check for:
    - Are hours realistic given availability?
    - Do timelines fit the target?
    - Are milestones achievable?
    - Are prerequisites necessary?

    Return JSON with only critical issues found:
    {{
        "critical_issues": ["issue1", "issue2"]
    }}
    """

    response_text = client.generate_content(
        prompt=prompt,
        temperature=0.3,
        max_tokens=500
    )

    response_dict = client.extract_json_from_response(response_text)
    issues = response_dict.get("critical_issues", [])

    # Return validated plans (with optional modifications) and issues
    return plan_a, plan_b, plan_c, issues
