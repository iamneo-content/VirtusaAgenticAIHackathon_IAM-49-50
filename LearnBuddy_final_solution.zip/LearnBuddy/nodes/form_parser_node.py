#!/usr/bin/env python3
"""
Form Parser Node (Merged Parsing + Analysis)

Combines profile parsing and analysis into a single node.
- Validates learner JSON input
- Extracts 40+ derived metrics from profile
- Prepares data for ML assessment stages

Uses VentureLens-inspired standardized error handling.
"""

from state import LearnerViabilityState
from agents.profile_parser import ProfileParserAgent
from agents.profile_analyzer import ProfileAnalyzerAgent


def form_parser_node(state: LearnerViabilityState) -> dict:
    """
    Parse and analyze learner profile in single combined step.

    Pipeline:
    1. Validate learner JSON (7 required fields)
    2. Normalize input (lowercase, type conversion)
    3. Extract 40+ metrics (learning traits, proficiency, goals, etc.)
    4. Prepare for downstream ML analysis

    Args:
        state: LearnerViabilityState with learner_json populated

    Returns:
        dict with parsed_learner, analyzed_profile, validation_errors, analysis_complete flags
    """
    print("\n[1] FORM PARSER NODE (Parse + Analyze)")
    print("=" * 60)

    try:
        # ========== STAGE 1: Parse ==========
        learner_json = state["learner_json"]
        parser_agent = ProfileParserAgent()
        normalized, is_valid, errors = parser_agent.parse(learner_json)

        if not is_valid:
            print(f"✗ Parsing failed: {errors}")
            return {
                "validation_errors": state["validation_errors"] + errors,
                "error_occurred": True,
                "error_messages": state["error_messages"] + [f"Parsing failed: {errors}"],
                "profile_complete": False,
                "analysis_complete": False
            }

        print(f"✓ Profile parsed successfully for {state['learner_id']}")

        # ========== STAGE 2: Analyze ==========
        # Add learner_json to normalized profile for analysis
        analysis_input = {**normalized, "learner_json": learner_json}
        analyzer_agent = ProfileAnalyzerAgent()
        analyzed = analyzer_agent.analyze(analysis_input)

        print(f"✓ Profile analyzed successfully")
        print(f"  - Extracted 40+ metrics across 6 categories")

        return {
            "parsed_learner": normalized,
            "analyzed_profile": analyzed,
            "validation_errors": [],
            "profile_complete": True,
            "analysis_complete": True
        }

    except ValueError as e:
        # Validation errors from parsing
        error_msg = f"Form Parser Validation Error: {str(e)}"
        print(f"✗ {error_msg}")
        return {
            "validation_errors": state["validation_errors"] + [str(e)],
            "error_occurred": True,
            "error_messages": state["error_messages"] + [error_msg],
            "profile_complete": False,
            "analysis_complete": False
        }

    except Exception as e:
        # Other errors (API, I/O, etc.)
        error_msg = f"Form Parser Failed: {type(e).__name__} - {str(e)}"
        print(f"✗ {error_msg}")
        return {
            "error_occurred": True,
            "error_messages": state["error_messages"] + [error_msg],
            "profile_complete": False,
            "analysis_complete": False
        }
