"""
LearnBuddy Nodes Package

7-Node DAG for learning plan generation.
All nodes instantiate agent classes directly (VentureLens pattern).

Active Node Pipeline:
1. form_parser_node - Parse and analyze learner profile (ProfileParserAgent + ProfileAnalyzerAgent)
2. proficiency_assessment_node - ML gap detection (GapDetectionMLAgent) [Parallel]
3. learning_readiness_node - ML difficulty prediction (DifficultyPredictionMLAgent) [Parallel]
4. learning_path_generator_node - LLM plan generation (PlanGeneratorLLMAgent)
5. path_validator_node - LLM plan validation (PlanValidatorAgent)
6. personal_coach_node - LLM tone personalization (CoachRewriterLLMAgent)
7. report_generator_node - Report generation and saving
"""

from . import form_parser_node
from . import proficiency_assessment_node
from . import learning_readiness_node
from . import learning_path_generator_node
from . import path_validator_node
from . import personal_coach_node
from . import report_generator_node

__all__ = [
    "form_parser_node",
    "proficiency_assessment_node",
    "learning_readiness_node",
    "learning_path_generator_node",
    "path_validator_node",
    "personal_coach_node",
    "report_generator_node",
]
