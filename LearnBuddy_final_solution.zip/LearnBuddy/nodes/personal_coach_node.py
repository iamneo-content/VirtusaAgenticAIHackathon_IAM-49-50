#!/usr/bin/env python3
"""
Personal Coach Node (Adaptive Tone Personalization)

Rewrites validated learning plans in adaptive, encouraging language.
Adapts tone based on learner profile:
- Young learners (<18): Encouraging, use emojis
- Visual learners: Use metaphors and visual descriptions
- Kinesthetic learners: Action-oriented, practical focus
- Auditory learners: Conversational tone
- Default: Analytical tone

Produces markdown text for each plan variant with motivational messaging.
"""

from utils.llm_client import LearnerLLMClient
from state import LearnerViabilityState


def personal_coach_node(state: LearnerViabilityState) -> dict:
    """
    Personalize validated plans with adaptive coaching tone.

    Analyzes learner profile to determine appropriate tone:
    - Age (young/adult)
    - Learning style (visual/kinesthetic/auditory/analytical)
    - Motivation level (high/medium/low)

    Generates encouraging, personalized markdown for each plan.

    Args:
        state: LearnerViabilityState with plan_variant_*_validated

    Returns:
        dict with variant_a/b/c_friendly (markdown text), rewriting_complete flag
    """
    print("\n[5] PERSONAL COACH NODE")
    print("=" * 60)

    try:
        plans = (
            state["plan_variant_a_validated"],
            state["plan_variant_b_validated"],
            state["plan_variant_c_validated"]
        )
        analyzed = state["analyzed_profile"]

        if not all(plans) or not analyzed:
            raise ValueError("Validated plans or analyzed_profile is missing")

        # Determine coaching tone based on learner profile
        tone = _determine_coaching_tone(analyzed)
        print(f"  Tone: {tone}")

        # Generate client
        client = LearnerLLMClient()

        # Rewrite each plan with personalized tone
        text_a = _rewrite_plan_with_tone(client, plans[0], analyzed, tone, "Conservative")
        print("  ✓ Personalized conservative plan")

        text_b = _rewrite_plan_with_tone(client, plans[1], analyzed, tone, "Standard")
        print("  ✓ Personalized standard plan")

        text_c = _rewrite_plan_with_tone(client, plans[2], analyzed, tone, "Aggressive")
        print("  ✓ Personalized aggressive plan")

        print(f"✓ Rewrote plans in friendly language")

        return {
            "variant_a_friendly": text_a,
            "variant_b_friendly": text_b,
            "variant_c_friendly": text_c,
            "rewriting_complete": True
        }

    except ValueError as e:
        error_msg = f"Personal Coach Validation Error: {str(e)}"
        print(f"✗ {error_msg}")
        return {
            "variant_a_friendly": "",
            "variant_b_friendly": "",
            "variant_c_friendly": "",
            "error_occurred": True,
            "error_messages": state["error_messages"] + [error_msg],
            "rewriting_complete": False
        }

    except Exception as e:
        error_msg = f"Personal Coach Failed: {type(e).__name__} - {str(e)}"
        print(f"✗ {error_msg}")
        return {
            "variant_a_friendly": "",
            "variant_b_friendly": "",
            "variant_c_friendly": "",
            "error_occurred": True,
            "error_messages": state["error_messages"] + [error_msg],
            "rewriting_complete": False
        }


def _determine_coaching_tone(analyzed: dict) -> str:
    """
    Determine appropriate coaching tone based on learner profile.

    Args:
        analyzed: Analyzed profile dictionary

    Returns:
        Tone description (e.g., "encouraging_youth", "practical_action_oriented")
    """
    metrics = analyzed.get("derived_metrics", {})
    age = metrics.get("age", 25)
    learning_style = metrics.get("learning_style", "analytical").lower()
    motivation = metrics.get("motivation_level", "medium").lower()

    # Age-based tone
    if age < 18:
        base_tone = "encouraging_youth"
    elif age < 25:
        base_tone = "conversational"
    else:
        base_tone = "professional"

    # Learning style override
    if "visual" in learning_style:
        return "visual_metaphor_based"
    elif "kinesthetic" in learning_style:
        return "practical_action_oriented"
    elif "auditory" in learning_style:
        return "conversational"

    return base_tone


def _rewrite_plan_with_tone(
    client: LearnerLLMClient,
    plan: dict,
    analyzed: dict,
    tone: str,
    variant_name: str
) -> str:
    """
    Rewrite a learning plan with personalized coaching tone.

    Args:
        client: LearnerLLMClient instance
        plan: Validated plan dictionary
        analyzed: Analyzed profile dictionary
        tone: Tone description
        variant_name: Plan variant name (Conservative/Standard/Aggressive)

    Returns:
        Markdown formatted plan with personalized coaching
    """
    learner_name = analyzed.get("derived_metrics", {}).get("name", "Learner")
    goal = analyzed.get("derived_metrics", {}).get("primary_goal", "Learning")
    motivation = analyzed.get("derived_metrics", {}).get("motivation_level", "medium")

    topics = plan.get("topics", [])
    milestones = plan.get("milestones", [])
    duration = plan.get("duration_weeks", 12)
    hours = plan.get("hours_per_week", 10)

    prompt = f"""
    Rewrite this learning plan as an encouraging personal coach message.

    Learner: {learner_name}
    Goal: {goal}
    Tone: {tone}
    Motivation Level: {motivation}

    Plan ({variant_name}):
    - Duration: {duration} weeks
    - Time commitment: {hours} hours/week
    - Topics: {', '.join(topics[:5])}
    - Key milestones: {', '.join(milestones[:3])}

    Tone Guidelines:
    - Use "you" to address the learner directly
    - Include encouraging phrases and celebrate small wins
    - Make it feel personal and achievable
    - For young learners: Add relevant emojis (no more than 3 per paragraph)
    - For visual learners: Use descriptive metaphors
    - For kinesthetic learners: Focus on hands-on practice and action steps
    - For auditory learners: Use conversational, natural language

    Generate a 2-3 paragraph personal coaching message in markdown format.
    Be warm, supportive, and realistic about the commitment.
    """

    response_text = client.generate_content(
        prompt=prompt,
        temperature=0.5,
        max_tokens=500
    )

    return response_text.strip()
