#!/usr/bin/env python3
"""
Proficiency Assessment ML Node (Gap Detection - OneVsRest + LinearSVC)

Runs in parallel with learning_readiness_ml to identify knowledge gaps.
Uses ML Model 1: OneVsRest classifier with TF-IDF + numeric features.

Determines:
- Identified learning gaps (e.g., "prerequisite_foundation", "advanced_concepts")
- Confidence scores for each gap
- Urgency level (critical/high/medium/low) based on proficiency
"""

from state import LearnerViabilityState
from agents.gap_detection_ml import GapDetectionMLAgent


def proficiency_assessment_ml_node(state: LearnerViabilityState) -> dict:
    """
    Assess learner proficiency gaps using ML Model 1.

    Model: OneVsRest(LinearSVC) with multi-label classification
    - Input: TF-IDF (domain, style, challenges, goals) + 15 numeric features
    - Output: Multi-label gap predictions with confidence scores

    Urgency Determination:
    - critical: proficiency < 30
    - high: proficiency < 50 AND has prerequisite_foundation gap
    - medium: proficiency < 70
    - low: else

    Args:
        state: LearnerViabilityState with analyzed_profile

    Returns:
        dict with identified_gaps, gap_confidence_scores, gap_urgency_level, ml_analysis_complete
    """
    print("\n[2a] PROFICIENCY ASSESSMENT ML NODE (Parallel)")
    print("=" * 60)

    try:
        analyzed = state["analyzed_profile"]

        if not analyzed:
            raise ValueError("analyzed_profile is empty")

        # Run gap detection ML model using agent class
        agent = GapDetectionMLAgent()
        gaps, confidence_scores, urgency = agent.detect_gaps(analyzed)

        print(f"✓ Detected {len(gaps)} learning gaps")
        print(f"  - Gaps: {', '.join(gaps)}")
        print(f"  - Urgency: {urgency.upper()}")
        print(f"  - Confidence: avg={sum(confidence_scores.values())/len(confidence_scores) if confidence_scores else 0:.1%}")

        return {
            "identified_gaps": gaps,
            "gap_confidence_scores": confidence_scores,
            "gap_urgency_level": urgency,
            "learning_characteristics_profile": {
                "proficiency_assessment_complete": True
            }
        }

    except ValueError as e:
        # Model loading or data validation errors
        error_msg = f"Proficiency Assessment Validation Error: {str(e)}"
        print(f"✗ {error_msg}")
        return {
            "identified_gaps": [],
            "error_messages": [error_msg]
        }

    except Exception as e:
        # Model inference errors, API errors, etc.
        error_msg = f"Proficiency Assessment Failed: {type(e).__name__} - {str(e)}"
        print(f"✗ {error_msg}")
        return {
            "identified_gaps": [],
            "error_messages": [error_msg]
        }
