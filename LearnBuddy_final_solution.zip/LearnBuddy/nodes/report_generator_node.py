#!/usr/bin/env python3
"""
Report Generator Node (Final Report Generation)

Generates comprehensive learning plan reports:
- Executive summary with key recommendations
- Detailed analysis of learner profile and gaps
- All 3 plan variants with personalized coaching
- Quality metrics and validation results
- Output to both markdown (.txt) and JSON formats

Saves outputs to /output/{learner_id}/ directory.
"""

import json
from pathlib import Path
from datetime import datetime

from utils.llm_client import LearnerLLMClient
from state import (
    LearnerViabilityState,
    create_output_directory,
    format_microplan_report,
    calculate_quality_score,
    save_file,
    extract_learner_metrics,
)


def report_generator_node(state: LearnerViabilityState) -> dict:
    """
    Generate and save comprehensive learning plan report.

    Report Contents:
    1. Executive summary with recommendations
    2. Learner profile analysis
    3. Learning gaps and urgency assessment
    4. All 3 plan variants with coaching notes
    5. Quality metrics and validation results
    6. Success strategies and next steps

    Output Formats:
    - Markdown (.txt) for human readability
    - JSON (.json) for programmatic access

    Args:
        state: LearnerViabilityState with all pipeline stages complete

    Returns:
        dict with saved_path, output_dir, quality_metrics, report_complete flag
    """
    print("\n[6] REPORT GENERATOR NODE")
    print("=" * 60)

    try:
        # Extract key information from state
        learner_id = state["learner_id"]
        analyzed = state["analyzed_profile"]

        if not analyzed:
            raise ValueError("analyzed_profile is missing")

        # Create output directory
        output_dir = create_output_directory(learner_id)
        print(f"  Output directory: {output_dir}")

        # Calculate quality metrics
        quality_metrics = calculate_quality_score(state)

        # Generate markdown report
        print("  Generating markdown report...")
        report_text = format_microplan_report(state)

        # Save markdown report
        report_path = Path(output_dir) / "micro_plan_report.txt"
        save_file(str(report_path), report_text)
        print(f"  ✓ Markdown report saved")

        # Generate JSON report
        print("  Generating JSON report...")
        report_json = _generate_json_report(state, quality_metrics)

        # Save JSON report
        json_path = Path(output_dir) / "micro_plan.json"
        save_file(str(json_path), json.dumps(report_json, indent=2))
        print(f"  ✓ JSON report saved")

        # Save quality metrics
        metrics_path = Path(output_dir) / "evaluation_metrics.json"
        save_file(str(metrics_path), json.dumps(quality_metrics, indent=2))
        print(f"  ✓ Evaluation metrics saved")

        print(f"✓ Report generation complete")
        print(f"  Quality Score: {quality_metrics.get('overall_quality', 0):.1%}")

        return {
            "final_report": report_text,
            "report_json": report_json,
            "quality_metrics": quality_metrics,
            "saved_path": str(report_path),
            "output_dir": output_dir,
            "report_complete": True
        }

    except ValueError as e:
        error_msg = f"Report Generator Validation Error: {str(e)}"
        print(f"✗ {error_msg}")
        return {
            "final_report": "",
            "report_json": {},
            "quality_metrics": {},
            "saved_path": "",
            "output_dir": "",
            "error_occurred": True,
            "error_messages": state["error_messages"] + [error_msg],
            "report_complete": False
        }

    except Exception as e:
        error_msg = f"Report Generator Failed: {type(e).__name__} - {str(e)}"
        print(f"✗ {error_msg}")
        return {
            "final_report": "",
            "report_json": {},
            "quality_metrics": {},
            "saved_path": "",
            "output_dir": "",
            "error_occurred": True,
            "error_messages": state["error_messages"] + [error_msg],
            "report_complete": False
        }


def _generate_json_report(state: LearnerViabilityState, quality_metrics: dict) -> dict:
    """
    Generate structured JSON report of learning plan.

    Args:
        state: Complete LearnerViabilityState
        quality_metrics: Calculated quality metrics

    Returns:
        Structured JSON report dictionary
    """
    return {
        "metadata": {
            "generated_at": datetime.now().isoformat(),
            "version": "2.0",
            "system": "LearnBuddy Micro v2.0"
        },
        "learner_profile": extract_learner_metrics(state),
        "analysis": {
            "gaps": state.get("identified_gaps", []),
            "urgency": state.get("gap_urgency_level", "medium"),
            "recommended_difficulty": state.get("recommended_difficulty", "Intermediate"),
            "difficulty_confidence": state.get("difficulty_confidence", 0.0),
            "learning_readiness": state.get("learning_readiness_assessment", "")
        },
        "learning_plans": {
            "conservative": state.get("plan_variant_a_validated", {}),
            "standard": state.get("plan_variant_b_validated", {}),
            "aggressive": state.get("plan_variant_c_validated", {})
        },
        "personalized_coaching": {
            "conservative_coaching": state.get("variant_a_friendly", ""),
            "standard_coaching": state.get("variant_b_friendly", ""),
            "aggressive_coaching": state.get("variant_c_friendly", "")
        },
        "validation": {
            "issues": state.get("validation_issues", []),
            "all_plans_validated": state.get("validation_complete", False)
        },
        "quality_metrics": quality_metrics,
        "recommendations": {
            "next_steps": [
                "Choose the learning plan variant that best fits your schedule",
                "Track your weekly progress against the milestones",
                "Adjust pace if needed based on your actual learning speed",
                "Engage with practice projects to solidify learning",
                "Seek help from community or mentors when stuck"
            ],
            "success_factors": [
                "Consistency over intensity - regular study is more effective",
                "Review prerequisites before moving to advanced topics",
                "Practice immediately after learning concepts",
                "Track progress and celebrate small wins",
                "Stay flexible and adapt based on real results"
            ]
        }
    }
