#!/usr/bin/env python3
"""
Learning Readiness ML Node (Difficulty Prediction - RandomForest)

Runs in parallel with proficiency_assessment_ml to predict optimal difficulty.
Uses ML Model 2: RandomForest classifier with numeric + categorical features.

Determines:
- Recommended difficulty level (Beginner/Intermediate/Advanced)
- Confidence score (0-1) for recommendation
- Learning readiness assessment (qualitative text)
"""

from state import LearnerViabilityState
from agents.difficulty_prediction_ml import DifficultyPredictionMLAgent


def learning_readiness_ml_node(state: LearnerViabilityState) -> dict:
    """
    Assess learning readiness and predict optimal difficulty using ML Model 2.

    Model: RandomForest classifier with feature importance weighting
    - Input: 16 numeric + 8 categorical features
    - Output: Difficulty class (Beginner/Intermediate/Advanced) + confidence

    Numeric Features (16):
    - age, hours_per_week, proficiency, pace_factor, avg_time_per_course
    - consistency, goal_alignment, courses_completed, avg_score, success_rate
    - complexity, prerequisites_count, prerequisites_mastery
    - estimated_hours_to_master, available_weeks, deadline_weeks

    Categorical Features (8):
    - education_level, learning_style, employment_status, past_performance_trend
    - motivation_level, career_urgency, preferred_difficulty, budget_constraint

    Args:
        state: LearnerViabilityState with analyzed_profile

    Returns:
        dict with recommended_difficulty, difficulty_confidence, ml_analysis_complete
    """
    print("\n[2b] LEARNING READINESS ML NODE (Parallel)")
    print("=" * 60)

    try:
        analyzed = state["analyzed_profile"]

        if not analyzed:
            raise ValueError("analyzed_profile is empty")

        # Run difficulty prediction ML model using agent class
        agent = DifficultyPredictionMLAgent()
        difficulty, confidence = agent.predict_difficulty(analyzed)

        print(f"✓ Predicted difficulty: {difficulty}")
        print(f"  - Confidence: {confidence:.1%}")
        print(f"  - Learning readiness: {['Low', 'Medium', 'High'][min(int(confidence * 3), 2)]}")

        # INLINED: Create readiness assessment text
        proficiency = analyzed.get("derived_metrics", {}).get("self_assessed_score", 50)
        hours = analyzed.get("derived_metrics", {}).get("hours_per_week", 5)
        goals = analyzed.get("derived_metrics", {}).get("goal_clarity_score", 50)
        readiness_level = "High" if confidence > 0.7 else "Medium" if confidence > 0.4 else "Low"
        readiness_text = (
            f"Based on proficiency ({proficiency}/100), time availability ({hours}h/week), "
            f"and goal clarity ({goals}/100), your learning readiness is {readiness_level}. "
            f"The {difficulty} difficulty level is recommended with {confidence:.0%} confidence. "
            f"You should be able to progress steadily with this path."
        )

        return {
            "recommended_difficulty": difficulty,
            "difficulty_confidence": confidence,
            "learning_readiness_assessment": readiness_text,
            "ml_analysis_complete": True
        }

    except ValueError as e:
        error_msg = f"Learning Readiness Validation Error: {str(e)}"
        print(f"✗ {error_msg}")
        return {
            "recommended_difficulty": "Intermediate",
            "difficulty_confidence": 0.0,
            "error_messages": [error_msg]
        }

    except Exception as e:
        error_msg = f"Learning Readiness Failed: {type(e).__name__} - {str(e)}"
        print(f"✗ {error_msg}")
        return {
            "recommended_difficulty": "Intermediate",
            "difficulty_confidence": 0.0,
            "error_messages": [error_msg]
        }
