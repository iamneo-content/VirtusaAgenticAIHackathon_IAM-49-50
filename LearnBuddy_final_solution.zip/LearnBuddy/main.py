#!/usr/bin/env python3
"""
LearnBuddy Micro - Streamlit Web Interface

Main entry point for personalized learning plan generation.
"""

import streamlit as st
import json
import os
from pathlib import Path
from dotenv import load_dotenv
from workflow.workflow import run_microplan_workflow

try:
    from ml.evaluation.evaluate_models import evaluate_all_models
except ImportError:
    pass

load_dotenv()

st.set_page_config(
    page_title="LearnBuddy Micro",
    page_icon="book",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.markdown("""
    <style>
    .stTabs [data-baseweb="tab-list"] button [data-testid="stMarkdownContainer"] p {
        font-size: 1.2rem;
    }
    .metric-container {
        background-color: #f0f2f6;
        padding: 10px;
        border-radius: 5px;
    }
    </style>
""", unsafe_allow_html=True)


def main():
    """Main Streamlit application"""

    # Initialize session state
    if "run_evaluation" not in st.session_state:
        st.session_state.run_evaluation = False
    if "eval_results" not in st.session_state:
        st.session_state.eval_results = None
    if "sample_profile" not in st.session_state:
        st.session_state.sample_profile = None
    if "analysis_result" not in st.session_state:
        st.session_state.analysis_result = None
    if "run_analysis" not in st.session_state:
        st.session_state.run_analysis = False

    col1, col2 = st.columns([3, 1])
    with col1:
        st.title("LearnBuddy Micro")
        st.markdown("### AI-Powered Personalized Learning Plan Generator")
    with col2:
        st.info("Production Ready")

    st.markdown("---")

    with st.expander("Important Disclaimer"):
        st.warning("""
            **Educational Use Only**: This system generates personalized learning recommendations
            based on AI analysis. This is NOT a substitute for professional educational guidance.

            - Results are for informational purposes only
            - Consult with educational professionals for formal guidance
            - Individual learning outcomes vary based on dedication and effort
            - Plans should be adapted based on actual progress
        """)

    st.markdown("---")

    with st.sidebar:
        st.header("Learner Selection")

        sample_dir = Path("data/input/learner_profiles")
        if sample_dir.exists():
            json_files = sorted([f.name for f in sample_dir.glob("learn_*.json")])

            selected_file = st.selectbox(
                "Choose a sample learner profile",
                options=json_files,
                help="Select from pre-generated learner profiles"
            )

            if selected_file:
                profile_path = sample_dir / selected_file
                with open(profile_path, 'r') as f:
                    st.session_state.sample_profile = json.load(f)

                profile = st.session_state.sample_profile
                st.success(f"Loaded: {profile.get('personal_info', {}).get('name', 'Unknown')}")

                with st.expander("View Profile Summary"):
                    col1, col2 = st.columns(2)
                    with col1:
                        st.metric("Age", profile.get("personal_info", {}).get("age", "N/A"))
                        st.metric("Education", profile.get("educational_background", {}).get("highest_qualification", "N/A"))
                    with col2:
                        st.metric("Learning Style", profile.get("learning_profile", {}).get("learning_style", "N/A"))
                        st.metric("Proficiency", f"{profile.get('current_status', {}).get('current_proficiency', {}).get('self_assessed_score', 0)}/100")

        else:
            st.error("Profile directory not found")
            st.session_state.sample_profile = None

        st.divider()
        st.subheader("Tools")

        if st.button("Run Model Evaluation", use_container_width=True, type="secondary"):
            st.session_state.run_evaluation = True

    st.markdown("---")

    col1, col2, col3 = st.columns(3)

    with col1:
        st.info("Step 1: Load learner profile")
    with col2:
        st.info("Step 2: ML analysis")
    with col3:
        st.info("Step 3: Get personalized plan")

    st.markdown("---")

    if st.button("Generate Personalized Learning Plan", use_container_width=True, type="primary"):
        if st.session_state.sample_profile is None:
            st.error("Please select a learner profile first")
            return
        st.session_state.run_analysis = True

    # Run analysis if triggered
    if st.session_state.run_analysis:
        if st.session_state.sample_profile is not None:
            progress_bar = st.progress(0, text="Initializing workflow...")

            try:
                progress_bar.progress(10, text="Parsing profile...")
                with st.spinner("AI is analyzing and generating your personalized plan..."):
                    result = run_microplan_workflow(st.session_state.sample_profile)
                    st.session_state.analysis_result = result

                progress_bar.progress(100, text="Complete")
                st.success("Plan generated successfully!")
                st.session_state.run_analysis = False

            except Exception as e:
                st.error(f"Error generating plan: {str(e)}")
                st.exception(e)
                st.session_state.run_analysis = False
                result = None
        else:
            st.error("No profile selected")

    # Display results if available
    if st.session_state.analysis_result is not None:
        result = st.session_state.analysis_result

        st.success("Analysis Complete! View results in tabs below:")

        # Create tabs
        tab1, tab2, tab3, tab4, tab5 = st.tabs(
            ["Analysis", "Plans", "Recommendations", "Full Report", "Download"]
        )

        with tab1:
            st.subheader("Analysis Results")
            col1, col2, col3 = st.columns(3)

            with col1:
                identified_gaps = result.get("identified_gaps", [])
                st.metric(
                    "Identified Gaps",
                    len(identified_gaps) if identified_gaps else 0,
                    help="Number of learning gaps detected"
                )

            with col2:
                urgency = result.get("gap_urgency_level", "N/A")
                st.metric(
                    "Urgency Level",
                    urgency.upper() if urgency else "N/A",
                    help="Priority level for addressing gaps"
                )

            with col3:
                difficulty = result.get("recommended_difficulty", "N/A")
                confidence = result.get("difficulty_confidence", 0)
                st.metric(
                    "Recommended Level",
                    difficulty if difficulty else "N/A",
                    f"{confidence*100:.0f}% confidence" if confidence else "N/A"
                )

            st.markdown("---")
            st.subheader("Detected Learning Gaps:")
            gaps = result.get("identified_gaps", [])
            if gaps and len(gaps) > 0:
                gap_scores = result.get("gap_confidence_scores", {})
                for gap in gaps:
                    confidence = gap_scores.get(gap, 0)
                    st.write(f"• **{gap.replace('_', ' ').title()}** ({confidence:.0%} confidence)")
            else:
                st.info("No specific gaps detected")

        with tab2:
            st.subheader("Learning Plans")

            col1, col2, col3 = st.columns(3)

            with col1:
                st.markdown("#### Plan A: Conservative")
                plan_a = result.get("plan_variant_a_validated", {})
                if plan_a:
                    st.write(f"**Duration:** {plan_a.get('duration_weeks', 0)} weeks")
                    st.write(f"**Weekly Commitment:** {plan_a.get('hours_per_week', 0)} hours")
                    st.write(f"**Intensity:** {str(plan_a.get('intensity', 'N/A')).upper()}")
                    st.write(f"**Topics:** {len(plan_a.get('topics', []))} topics")
                    topics = plan_a.get('topics', [])
                    if topics:
                        for topic in topics[:5]:
                            st.write(f"  • {topic}")
                        if len(topics) > 5:
                            st.write(f"  ... and {len(topics)-5} more")
                else:
                    st.info("Plan not available")

            with col2:
                st.markdown("#### Plan B: Standard")
                plan_b = result.get("plan_variant_b_validated", {})
                if plan_b:
                    st.write(f"**Duration:** {plan_b.get('duration_weeks', 0)} weeks")
                    st.write(f"**Weekly Commitment:** {plan_b.get('hours_per_week', 0)} hours")
                    st.write(f"**Intensity:** {str(plan_b.get('intensity', 'N/A')).upper()}")
                    st.write(f"**Topics:** {len(plan_b.get('topics', []))} topics")
                    topics = plan_b.get('topics', [])
                    if topics:
                        for topic in topics[:5]:
                            st.write(f"  • {topic}")
                        if len(topics) > 5:
                            st.write(f"  ... and {len(topics)-5} more")
                else:
                    st.info("Plan not available")

            with col3:
                st.markdown("#### Plan C: Aggressive")
                plan_c = result.get("plan_variant_c_validated", {})
                if plan_c:
                    st.write(f"**Duration:** {plan_c.get('duration_weeks', 0)} weeks")
                    st.write(f"**Weekly Commitment:** {plan_c.get('hours_per_week', 0)} hours")
                    st.write(f"**Intensity:** {str(plan_c.get('intensity', 'N/A')).upper()}")
                    st.write(f"**Topics:** {len(plan_c.get('topics', []))} topics")
                    topics = plan_c.get('topics', [])
                    if topics:
                        for topic in topics[:5]:
                            st.write(f"  • {topic}")
                        if len(topics) > 5:
                            st.write(f"  ... and {len(topics)-5} more")
                else:
                    st.info("Plan not available")

        with tab3:
            st.subheader("Personalized Recommendations")

            col1, col2, col3 = st.columns(3)

            with col1:
                st.markdown("#### Conservative Coaching")
                coaching_a = result.get("variant_a_friendly", "")
                st.write(coaching_a if coaching_a else "No coaching notes available")

            with col2:
                st.markdown("#### Standard Coaching")
                coaching_b = result.get("variant_b_friendly", "")
                st.write(coaching_b if coaching_b else "No coaching notes available")

            with col3:
                st.markdown("#### Aggressive Coaching")
                coaching_c = result.get("variant_c_friendly", "")
                st.write(coaching_c if coaching_c else "No coaching notes available")

        with tab4:
            st.subheader("Full Learning Plan Report")
            report_text = result.get("final_report", "")
            if report_text:
                st.text(report_text)
            else:
                st.info("Full report not available")

        with tab5:
            st.subheader("Download Your Plan")

            col1, col2 = st.columns(2)

            with col1:
                json_report = result.get("report_json", {})
                if json_report:
                    st.download_button(
                        label="Download JSON Report",
                        data=json.dumps(json_report, indent=2),
                        file_name="microplan_report.json",
                        mime="application/json"
                    )
                else:
                    st.info("JSON report not available")

            with col2:
                final_report = result.get("final_report", "")
                if final_report:
                    st.download_button(
                        label="Download Text Report",
                        data=final_report,
                        file_name="microplan_report.txt",
                        mime="text/plain"
                    )
                else:
                    st.info("Text report not available")

            output_dir = result.get("output_dir", "N/A")
            st.success(f"Files saved to: {output_dir}")

        st.markdown("---")
        st.subheader("Quality Assessment")
        metrics = result.get("quality_metrics", {})
        col1, col2, col3, col4 = st.columns(4)

        with col1:
            st.metric("Profile Complete", f"{metrics.get('profile_completeness', 0):.0%}")
        with col2:
            st.metric("Gap Detection", f"{metrics.get('gap_detection_accuracy', 0):.0%}")
        with col3:
            st.metric("Plan Feasible", f"{metrics.get('plan_feasibility', 0):.0%}")
        with col4:
            st.metric("Overall Quality", f"{metrics.get('overall_quality', 0):.0%}")

    # Handle model evaluation trigger from sidebar
    if st.session_state.run_evaluation:
        try:
            with st.spinner("Evaluating ML models..."):
                eval_results = evaluate_all_models()
                st.session_state.eval_results = eval_results
                st.success("Model evaluation complete!")
        except Exception as e:
            st.error(f"Evaluation failed: {str(e)}")
        finally:
            st.session_state.run_evaluation = False

    # Display model evaluation results if available
    st.divider()
    render_model_evaluation_section(st.session_state.get("eval_results"))


def render_model_evaluation_section(eval_results):
    """Render ML model evaluation metrics on the main page."""
    st.markdown("### ML Model Evaluation")
    st.markdown("Performance metrics of trained machine learning models")

    if not eval_results:
        st.info("Click 'Run Model Evaluation' in the sidebar to evaluate trained models.")
        return

    col1, col2 = st.columns(2)

    with col1:
        st.subheader("Gap Detection Model")
        gap_eval = eval_results.get("gap_evaluation", {})
        if gap_eval and "error" not in gap_eval:
            st.metric("Accuracy", f"{gap_eval.get('accuracy', 0)*100:.2f}%")
            st.metric("Hamming Loss", f"{gap_eval.get('hamming_loss', 0):.4f}")
            st.metric("Test Samples", gap_eval.get('samples', 0))
        else:
            st.error(f"Error: {gap_eval.get('error', 'Unknown error')}")

    with col2:
        st.subheader("Difficulty Prediction Model")
        difficulty_eval = eval_results.get("difficulty_evaluation", {})
        if difficulty_eval and "error" not in difficulty_eval:
            st.metric("Accuracy", f"{difficulty_eval.get('accuracy', 0)*100:.2f}%")
            st.metric("Cross-Val Score", f"{difficulty_eval.get('cv_score', 0)*100:.2f}%")
            st.metric("Test Samples", difficulty_eval.get('samples', 0))
        else:
            st.error(f"Error: {difficulty_eval.get('error', 'Unknown error')}")

    st.divider()
    with st.expander("View Raw Evaluation Data"):
        st.json(eval_results)


if __name__ == "__main__":
    main()
