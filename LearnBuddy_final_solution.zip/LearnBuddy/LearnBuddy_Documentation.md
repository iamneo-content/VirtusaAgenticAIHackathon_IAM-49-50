================================================================================
                        LEARNBUDDY PROJECT DOCUMENTATION
                     AI-Powered Personalized Learning Plan Generator
================================================================================

Version: 2.0
Date: 2025-12-11
System: LearnBuddy Micro
Authors: Development Team


================================================================================
                          1. PROBLEM DESCRIPTION
================================================================================

1.1 CLEAR PROBLEM STATEMENT
----------------------------

Traditional learning platforms provide one-size-fits-all educational content that
fails to account for individual learner differences in proficiency, learning
styles, time constraints, and career goals. This generic approach leads to high
dropout rates, suboptimal learning outcomes, and wasted time and resources.

LearnBuddy addresses this fundamental problem by providing AI-driven personalized
learning plan generation that adapts to each learner's unique profile, constraints,
and goals.


1.2 SCENARIO-BASED EXPLANATION
-------------------------------

Scenario 1: The Busy Professional
   Alex is a 28-year-old software engineer who wants to transition into Data
   Science. He works full-time and can only dedicate 10 hours per week to learning.
   He has strong programming fundamentals but lacks statistical knowledge.
   Traditional courses either move too slowly (wasting his existing knowledge) or
   too quickly (overwhelming him with prerequisites he hasn't mastered).

   LearnBuddy Solution:
   - Analyzes Alex's programming proficiency and identifies statistical gaps
   - Predicts optimal difficulty level based on his background and constraints
   - Generates three learning plan variants (Conservative, Standard, Aggressive)
   - Each plan accounts for his 10-hour weekly limit and 6-month timeline
   - Provides personalized coaching in his preferred learning style

Scenario 2: The High School Student
   Sarah is a 16-year-old student interested in web development. She has no prior
   experience but is highly motivated and has 20 hours per week during summer.
   She learns best through visual content and hands-on projects.

   LearnBuddy Solution:
   - Identifies foundational knowledge gaps in programming basics
   - Recommends Beginner difficulty level with high confidence
   - Creates project-based learning plans suited to visual learners
   - Provides encouraging, youth-friendly coaching messages
   - Suggests resources and milestones appropriate for beginners

Scenario 3: The Career Changer
   Maria is a 35-year-old marketing professional looking to learn UX Design. She
   has limited budget (100 USD), works irregular hours, and needs certification for
   credibility. She has creative skills but no technical background.

   LearnBuddy Solution:
   - Detects technical prerequisite gaps and creative strengths
   - Balances budget constraints with certification requirements
   - Generates flexible learning plans adaptable to irregular schedules
   - Recommends free and low-cost resources that offer certification
   - Provides motivational coaching tailored to career transition challenges


1.3 BUSINESS CONTEXT AND NEED
------------------------------

The global e-learning market is projected to reach 400 billion USD by 2026, yet
learner engagement and completion rates remain critically low (average 15 percent
completion rate for online courses).

Key Business Drivers:

1. Personalization Gap
   - 94 percent of learners report wanting personalized learning experiences
   - Current platforms offer minimal customization beyond surface-level filtering
   - One-size-fits-all content wastes learner time and platform resources

2. Learner Success Metrics
   - Low completion rates indicate poor content-learner matching
   - High dropout costs platforms revenue and damages brand reputation
   - Personalized paths can increase completion rates by 3-5x

3. Competitive Differentiation
   - Educational institutions need data-driven learner assessment
   - Corporate training programs require adaptive skill development
   - Individual learners seek guidance that respects their constraints

4. Operational Efficiency
   - Manual learning plan creation is time-intensive and expensive
   - AI automation scales personalization to millions of learners
   - ML models improve continuously with more learner data

LearnBuddy Value Proposition:
   - Automated, scalable personalization at fraction of manual cost
   - Data-driven recommendations backed by ML model predictions
   - Multi-variant plans give learners choice and control
   - Integration-ready API for educational platforms and corporate LMS
   - Continuous improvement through ML model retraining


================================================================================
                  2. FILE STRUCTURE AND DIRECTORY HIERARCHY
================================================================================

LearnBuddy/
|
|-- main.py                              (Streamlit web application entry point)
|-- graph.py                             (Programmatic workflow execution interface)
|-- state.py                             (State management and data structures)
|-- tests.py                             (Unit and integration tests)
|-- installation.txt                     (Dependencies and requirements)
|
|-- agents/                              (ML and LLM agent implementations)
|   |-- __init__.py
|   |-- profile_parser.py                (Input validation and normalization)
|   |-- profile_analyzer.py              (Feature extraction and metric calculation)
|   |-- gap_detection_ml.py              (ML-based learning gap detection)
|   |-- difficulty_prediction_ml.py      (ML-based difficulty level prediction)
|   |-- plan_generator_llm.py            (LLM-based plan generation)
|   |-- plan_validator.py                (Plan feasibility validation)
|   |-- coach_rewriter_llm.py            (Adaptive tone personalization)
|
|-- nodes/                               (LangGraph workflow nodes)
|   |-- __init__.py
|   |-- form_parser_node.py              (Parse and analyze learner input)
|   |-- proficiency_assessment_node.py   (ML gap detection node)
|   |-- learning_readiness_node.py       (ML difficulty prediction node)
|   |-- learning_path_generator_node.py  (LLM plan generation node)
|   |-- path_validator_node.py           (Plan validation node)
|   |-- personal_coach_node.py           (Coaching personalization node)
|   |-- report_generator_node.py         (Report generation and file output)
|
|-- utils/                               (Shared utilities)
|   |-- __init__.py
|   |-- llm_client.py                    (Centralized Gemini LLM client)
|
|-- workflow/                            (Workflow orchestration)
|   |-- __init__.py
|   |-- workflow.py                      (LangGraph workflow builder)
|
|-- ml/                                  (Machine learning pipeline)
|   |-- __init__.py
|   |-- train_pipeline.py                (End-to-end ML training orchestration)
|   |
|   |-- cleaning/                        (Data preprocessing)
|   |   |-- __init__.py
|   |   |-- clean_gap_data.py            (Gap detection data cleaning)
|   |   |-- clean_difficulty_data.py     (Difficulty prediction data cleaning)
|   |
|   |-- train_model/                     (Model training scripts)
|   |   |-- __init__.py
|   |   |-- train_gap_model.py           (Train multi-label gap detection)
|   |   |-- train_difficulty_model.py    (Train multi-class difficulty)
|   |
|   |-- evaluation/                      (Model evaluation)
|   |   |-- __init__.py
|   |   |-- evaluate_models.py           (Evaluate trained ML models)
|   |
|   |-- model/                           (Trained model artifacts)
|       |-- gap_model.pkl
|       |-- gap_vectorizer.pkl
|       |-- gap_mlb.pkl
|       |-- gap_scaler.pkl
|       |-- gap_labels.json
|       |-- difficulty_model.pkl
|       |-- difficulty_scaler.pkl
|       |-- difficulty_label_encoder.pkl
|       |-- difficulty_categorical_encoders.pkl
|
|-- data/                                (Training and input data)
|   |-- raw/                             (Raw training datasets)
|   |   |-- gap_training_raw.csv
|   |   |-- gap_eval_raw.csv
|   |   |-- difficulty_training_raw.csv
|   |   |-- difficulty_eval_raw.csv
|   |
|   |-- processed/                       (Cleaned training datasets)
|   |   |-- gap_detection_cleaned.csv
|   |   |-- difficulty_prediction_cleaned.csv
|   |
|   |-- input/                           (User input profiles)
|       |-- learner_profiles/
|           |-- learn_001.json
|           |-- learn_002.json
|           |-- (15 sample learner profiles)
|
|-- output/                              (Generated learning plans)
    |-- learner_001/
    |   |-- micro_plan_report.txt        (Human-readable markdown report)
    |   |-- micro_plan.json              (Structured JSON report)
    |   |-- evaluation_metrics.json      (Quality assessment metrics)
    |
    |-- learner_002/
    |-- learner_003/


================================================================================
                         3. PURPOSE OF FILES
================================================================================

3.1 MAIN APPLICATION FILES
---------------------------

main.py
   Purpose: Streamlit web application providing user interface for learning plan
            generation
   Module Responsibilities:
   - Render multi-tab web interface (Analysis, Plans, Recommendations, Report)
   - Load and display sample learner profiles
   - Execute workflow via run_microplan_workflow function
   - Display results in interactive format with metrics and visualizations
   - Provide download options for JSON and text reports
   - Trigger ML model evaluation from sidebar
   Integration Points: workflow.workflow, ml.evaluation.evaluate_models

graph.py
   Purpose: Programmatic API for workflow execution
   Module Responsibilities:
   - Expose run_microplan function for direct workflow execution
   - Provide run_microplan_from_file for file-based input
   - Extract and format workflow summaries
   - Serve as library interface for external integration
   Integration Points: workflow.workflow, state module

state.py
   Purpose: State management and data structures for entire pipeline
   Module Responsibilities:
   - Define LearnerViabilityState TypedDict (93 fields, 9 pipeline stages)
   - Initialize state with default values via get_initial_state
   - Format final reports via format_microplan_report
   - Calculate quality metrics via calculate_quality_score
   - Manage file I/O (create_output_directory, save_file)
   - Validate state integrity at each pipeline stage
   Integration Points: All nodes, workflow orchestration

tests.py
   Purpose: Automated testing suite
   Module Responsibilities:
   - Unit tests for individual agents and nodes
   - Integration tests for end-to-end workflow
   - Validation of ML model predictions
   - Test data fixtures and mocking
   Integration Points: All modules


3.2 AGENT FILES (agents/ directory)
------------------------------------

profile_parser.py
   Purpose: Validate and normalize raw learner JSON input
   Module Responsibilities:
   - Validate 7 required fields (learner_id, personal_info, etc.)
   - Check field types and data ranges
   - Normalize strings to lowercase, preserve numeric values
   - Generate validation errors and warnings
   Integration Points: nodes.form_parser_node

profile_analyzer.py
   Purpose: Extract features and calculate derived metrics from profile
   Module Responsibilities:
   - Extract demographics (age, education, country)
   - Analyze learning characteristics (style, pace, preferences)
   - Calculate proficiency metrics and goal clarity scores
   - Compute constraints analysis (time pressure, budget)
   - Analyze learning history (completion rates, trends)
   - Pre-calculate ML features (15 numeric + text for gap detection)
   - Pre-calculate ML features (16 numeric + 8 categorical for difficulty)
   Integration Points: nodes.form_parser_node, ML agents

gap_detection_ml.py
   Purpose: ML-based multi-label learning gap detection
   Module Responsibilities:
   - Load trained gap detection model
   - Transform text features via TF-IDF vectorizer
   - Scale numeric features
   - Predict multiple gap labels with confidence scores
   - Determine urgency level based on proficiency
   Integration Points: nodes.proficiency_assessment_node

difficulty_prediction_ml.py
   Purpose: ML-based optimal difficulty level prediction
   Module Responsibilities:
   - Load trained difficulty classifier
   - Encode categorical features
   - Scale numeric features
   - Predict difficulty class (Beginner/Intermediate/Advanced)
   - Return prediction confidence score
   Integration Points: nodes.learning_readiness_node

plan_generator_llm.py (not found, logic inlined in node)
plan_validator.py (not found, logic inlined in node)
coach_rewriter_llm.py (not found, logic inlined in node)


3.3 NODE FILES (nodes/ directory)
----------------------------------

form_parser_node.py
   Purpose: Combined parsing and analysis in single node
   Module Responsibilities:
   - Validate learner JSON via ProfileParserAgent
   - Normalize input data
   - Analyze profile via ProfileAnalyzerAgent
   - Extract 40+ derived metrics across 6 categories
   - Set profile_complete and analysis_complete flags
   Integration Points: Entry point of workflow, feeds parallel ML nodes

proficiency_assessment_node.py
   Purpose: Gap detection ML node (runs in parallel)
   Module Responsibilities:
   - Execute gap detection via GapDetectionMLAgent
   - Identify learning gaps with confidence scores
   - Determine gap urgency level (critical/high/medium/low)
   - Set gap_detection_complete flag
   Integration Points: Parallel with learning_readiness_node, converges at
                      learning_path_generator_node

learning_readiness_node.py
   Purpose: Difficulty prediction ML node (runs in parallel)
   Module Responsibilities:
   - Execute difficulty prediction via DifficultyPredictionMLAgent
   - Recommend difficulty level (Beginner/Intermediate/Advanced)
   - Calculate confidence score for recommendation
   - Generate learning readiness assessment text
   - Set ml_analysis_complete flag
   Integration Points: Parallel with proficiency_assessment_node, converges at
                      learning_path_generator_node

learning_path_generator_node.py
   Purpose: LLM-based learning plan generation
   Module Responsibilities:
   - Generate 3 plan variants (Conservative/Standard/Aggressive)
   - Use LearnerLLMClient for Gemini API access
   - Create plans with topics, resources, milestones, prerequisites
   - Adjust timeline and intensity for each variant
   - Validate JSON structure and required fields
   Integration Points: Receives merged output from parallel ML nodes, feeds
                      path_validator_node

path_validator_node.py
   Purpose: Plan feasibility validation
   Module Responsibilities:
   - Validate plans against learner constraints
   - Check hours per week vs availability
   - Verify timeline vs target timeline
   - Assess milestone feasibility and prerequisite coverage
   - Generate validation issues list
   Integration Points: Receives plan variants, feeds personal_coach_node

personal_coach_node.py
   Purpose: Adaptive tone personalization
   Module Responsibilities:
   - Determine coaching tone based on learner profile
   - Adapt for age (youth/adult), learning style, motivation
   - Rewrite plans in encouraging, personalized language
   - Generate 2-3 paragraph coaching messages per plan
   - Use emojis for young learners, metaphors for visual learners
   Integration Points: Receives validated plans, feeds report_generator_node

report_generator_node.py
   Purpose: Final report generation and file output
   Module Responsibilities:
   - Generate comprehensive markdown text report
   - Create structured JSON report
   - Calculate quality metrics (6 dimensions)
   - Save reports to output/{learner_id}/ directory
   - Save evaluation metrics separately
   Integration Points: Terminal node, outputs final results


3.4 UTILITY FILES (utils/ directory)
-------------------------------------

llm_client.py
   Purpose: Centralized Gemini LLM client with key management
   Module Responsibilities:
   - Manage multiple Gemini API keys (rotation on quota exceeded)
   - Generate content with temperature and token controls
   - Extract and repair JSON from LLM responses
   - Clean markdown fences and trailing commas
   - Validate response fields
   - Provide structured JSON generation pipeline
   Integration Points: All LLM-based nodes (generator, validator, coach)


3.5 WORKFLOW FILES (workflow/ directory)
-----------------------------------------

workflow.py
   Purpose: LangGraph workflow orchestration
   Module Responsibilities:
   - Build 7-node DAG with parallel execution
   - Define edges and convergence points
   - Compile workflow for execution
   - Run complete pipeline via run_microplan_workflow
   - Log progress at each stage
   Integration Points: Called by main.py and graph.py, orchestrates all nodes


3.6 ML TRAINING FILES (ml/ directory)
--------------------------------------

train_pipeline.py
   Purpose: End-to-end ML training orchestration
   Module Responsibilities:
   - Load raw training and evaluation datasets
   - Clean gap detection data
   - Clean difficulty prediction data
   - Train multi-label gap detection model
   - Train multi-class difficulty prediction model
   - Save model artifacts to ml/model/
   - Return training and evaluation metrics
   Integration Points: Calls cleaning and training modules

clean_gap_data.py
   Purpose: Gap detection data preprocessing
   Module Responsibilities:
   - Remove duplicates from training data
   - Fill missing numeric values with median
   - Fix categorical value inconsistencies
   - Clip outliers to valid ranges
   - Parse and validate gap label lists
   - Save cleaned data to data/processed/
   Integration Points: Called by train_pipeline.py

clean_difficulty_data.py
   Purpose: Difficulty prediction data preprocessing
   Module Responsibilities:
   - Remove duplicates from training data
   - Fill missing numeric values with median
   - Fix categorical value inconsistencies
   - Clip outliers to valid ranges
   - Validate class distribution
   - Save cleaned data to data/processed/
   Integration Points: Called by train_pipeline.py

train_gap_model.py
   Purpose: Train gap detection ML model
   Module Responsibilities:
   - Initialize multi-label classifier
   - Prepare TF-IDF text features from domain, style, challenges
   - Prepare 15 numeric features
   - Fit MultiLabelBinarizer for 12 gap categories
   - Train model on cleaned data
   - Evaluate on train and eval sets (accuracy, Hamming loss)
   - Save model, vectorizer, scaler, binarizer, labels
   Integration Points: Called by train_pipeline.py

train_difficulty_model.py
   Purpose: Train difficulty prediction ML model
   Module Responsibilities:
   - Initialize multi-class classifier
   - Prepare 16 numeric features
   - Encode 3 categorical features (education, style, employment)
   - Fit LabelEncoder for 3 difficulty classes
   - Train model with 100 estimators, max_depth 20
   - Evaluate on train and eval sets (accuracy, classification report)
   - Perform 5-fold cross-validation
   - Save model, scaler, encoders, label encoder
   Integration Points: Called by train_pipeline.py

evaluate_models.py
   Purpose: Evaluate trained ML models
   Module Responsibilities:
   - Load gap detection model and return metrics
   - Load difficulty prediction model and return metrics
   - Check model availability and status
   - Return evaluation results with timestamp
   Integration Points: Called by main.py for sidebar evaluation


================================================================================
                     4. CLASS STRUCTURE AND METHODS
================================================================================

4.1 STATE MODULE CLASSES
-------------------------

Class: LearnerViabilityState (TypedDict)
   Description: Comprehensive state container for personalized learning plan
                generation with 93 fields organized into 9 pipeline stages

   Fields are organized as follows:

   Input Stage (2 fields):
      - learner_json: Dictionary containing raw learner profile input
      - learner_id: String identifier for the learner

   Parsing Stage (2 fields):
      - parsed_learner: Dictionary with validated and normalized input
      - validation_errors: List of string error messages from validation

   Profiling Stage (6 fields):
      - analyzed_profile: Dictionary with derived metrics
      - derived_metrics: Dictionary with calculated features
      - identified_gaps: List of string gap labels
      - gap_confidence_scores: Dictionary mapping gaps to confidence (0-1)
      - gap_urgency_level: String urgency (critical/high/medium/low)
      - gap_detection_complete: Boolean completion flag

   ML Analysis Stage (7 fields):
      - recommended_difficulty: String difficulty level
      - difficulty_confidence: Float confidence score (0-1)
      - difficulty_prediction_complete: Boolean completion flag
      - learning_readiness_assessment: String text assessment
      - learning_characteristics_profile: Dictionary with learning traits
      - prerequisite_gaps: List of string prerequisite deficits
      - proficiency_assessment_complete: Boolean completion flag
      - ml_analysis_complete: Boolean pipeline stage flag

   Analysis Completion Flags (2 fields):
      - profile_complete: Boolean flag for profile stage
      - analysis_complete: Boolean flag for analysis stage

   LLM Enhancement Stage (8 fields):
      - learning_path_recommendations: Dictionary with recommendations
      - personalized_coaching: String motivational guidance
      - motivation_framework: Dictionary with motivation strategy
      - skill_development_strategy: Dictionary with skill building approach
      - progress_tracking_plan: Dictionary with progress metrics
      - success_metrics: Dictionary defining success
      - peer_learning_opportunities: List of string community features
      - llm_enhancement_complete: Boolean pipeline stage flag

   Plan Generation Stage (6 fields):
      - plan_variant_a: Dictionary raw conservative plan
      - plan_variant_b: Dictionary raw standard plan
      - plan_variant_c: Dictionary raw aggressive plan
      - plan_variant_a_validated: Dictionary validated conservative plan
      - plan_variant_b_validated: Dictionary validated standard plan
      - plan_variant_c_validated: Dictionary validated aggressive plan
      - validation_issues: List of string validation feedback
      - plan_generation_complete: Boolean pipeline stage flag
      - validation_complete: Boolean validation completion flag

   Coach Rewriting Stage (4 fields):
      - variant_a_friendly: String conservative plan friendly text
      - variant_b_friendly: String standard plan friendly text
      - variant_c_friendly: String aggressive plan friendly text
      - rewriting_complete: Boolean pipeline stage flag

   Reporting Stage (4 fields):
      - final_report: String comprehensive text report
      - report_json: Dictionary structured JSON report
      - quality_metrics: Dictionary with quality scores
      - report_complete: Boolean pipeline stage flag

   Output Metadata (2 fields):
      - saved_path: String path to saved report file
      - output_dir: String output directory for learner

   Error Tracking (2 fields):
      - error_occurred: Boolean error flag
      - error_messages: Annotated list of string error messages


4.2 AGENT CLASSES
-----------------

Class: ProfileParserAgent
   Location: agents/profile_parser.py
   Purpose: Validate and normalize learner JSON profile

   Constants:
      REQUIRED_FIELDS: Dictionary mapping field names to expected types
      VALID_EDUCATION_LEVELS: List of valid education level strings
      VALID_LEARNING_STYLES: List of valid learning style strings

   Attributes:
      errors: List[str] - Validation error messages
      warnings: List[str] - Validation warning messages

   Method: __init__
      Parameters: self
      Logic: Initialize empty errors and warnings lists
      Return: None (constructor)

   Method: parse
      Parameters:
         self
         learner_json: Dict[str, Any] - Raw learner profile dictionary
      Logic:
         1. Reset errors and warnings lists
         2. Validate all required fields exist with correct types
         3. Validate personal info (age range 8-100, languages_spoken list)
         4. Validate educational background (education level, GPA 0-4.0)
         5. Validate learning profile (learning style, focus duration 5-240 min)
         6. Validate current status (proficiency score 0-100)
         7. Validate learning goals (timeline 1-60 months)
         8. Validate constraints (hours 0-168 per week, budget >= 0)
         9. If errors exist, return empty dict with is_valid=False
         10. Normalize all string fields to lowercase via recursive normalize_dict
         11. Preserve numeric values and nested structures
         12. Return normalized profile with is_valid=True
      Return: Tuple[Dict[str, Any], bool, List[str]] - (normalized_profile,
              is_valid, error_messages)


Class: ProfileAnalyzerAgent
   Location: agents/profile_analyzer.py
   Purpose: Extract features and calculate derived metrics from normalized profile

   Method: __init__
      Parameters: self
      Logic: Initialize agent (no state required)
      Return: None (constructor)

   Method: analyze
      Parameters:
         self
         normalized_profile: Dict[str, Any] - Validated and normalized profile
      Logic:
         1. Extract demographics (age, country, education level, years educated)
         2. Raise ValueError if required fields missing (age, country, education)
         3. Extract learning characteristics (style, pace, focus duration, formats)
         4. Raise ValueError if learning_style missing
         5. Extract proficiency (domain, topic, scores, challenges)
         6. Raise ValueError if primary_domain missing
         7. Analyze goals (primary, secondary, timeline, clarity score 0-100)
         8. Calculate goal alignment (0-1 scale based on career, timeline, projects)
         9. Analyze constraints (hours per week, budget, time pressure score)
         10. Analyze learning history (completion rates, scores, trend, consistency)
         11. Pre-calculate gap detection ML features:
             - 15 numeric features (age, hours, proficiency, focus, clarity, etc.)
             - Text features (domain + style + challenges + goals combined)
         12. Pre-calculate difficulty prediction ML features:
             - 16 numeric features (age, ability, speed, time, experience, etc.)
             - 8 categorical features (education, style, employment, trend, etc.)
         13. Raise ValueError if employment_status missing
         14. Return comprehensive analyzed profile dictionary
      Return: Dict[str, Any] - Analyzed profile with 7 sections (demographics,
              learning_characteristics, proficiency, goals_analysis,
              constraints_analysis, history_analysis, ml_features)


Class: GapDetectionMLAgent
   Location: agents/gap_detection_ml.py
   Purpose: ML-based multi-label learning gap detection

   Constants:
      MODEL_DIR: Path - Directory containing trained model artifacts

   Attributes:
      model: Trained multi-label gap detection model
      vectorizer: Text feature transformer
      mlb: MultiLabelBinarizer - Label encoder for 12 gap categories
      scaler: Numeric feature scaler
      gap_labels: List[str] - List of 12 gap category labels

   Method: __init__
      Parameters: self
      Logic:
         1. Initialize attributes to None
         2. Load gap_model.pkl (multi-label classifier)
         3. Load gap_vectorizer.pkl (TF-IDF transformer)
         4. Load gap_mlb.pkl (MultiLabelBinarizer)
         5. Load gap_scaler.pkl (feature scaler)
         6. Load gap_labels.json (12 gap categories)
      Return: None (constructor)

   Method: detect_gaps
      Parameters:
         self
         analyzed_profile: Dict[str, Any] - Profile with pre-calculated ML features
      Logic:
         1. Raise ValueError if model not initialized
         2. Extract ml_features from analyzed_profile
         3. Raise ValueError if ml_features missing
         4. Get gap_detection_text (pre-calculated combined text)
         5. Get gap_detection_numeric (pre-calculated 15 features)
         6. Raise ValueError if not exactly 15 numeric features
         7. Transform text via vectorizer.transform
         8. Scale numeric features via scaler.transform
         9. Horizontally stack text and numeric features
         10. Predict gaps via model.predict (binary matrix)
         11. Get decision scores via model.decision_function
         12. Convert scores to confidence via sigmoid function
         13. Extract predicted gap labels where prediction=1
         14. Map gaps to confidence scores
         15. Determine urgency: proficiency <30=critical, <50 or has
             prerequisite_foundation=high, <70=medium, else=low
         16. Return identified gaps, confidence dict, urgency string
      Return: Tuple[List[str], Dict[str, float], str] - (gaps_list, confidence_dict,
              urgency_level)


Class: DifficultyPredictionMLAgent
   Location: agents/difficulty_prediction_ml.py
   Purpose: ML-based optimal difficulty level prediction

   Constants:
      difficulty_classes: List[str] - ["Beginner", "Intermediate", "Advanced"]

   Attributes:
      model_dir: Path - Directory containing trained model artifacts
      model: Trained multi-class difficulty prediction model
      scaler: Numeric feature scaler
      label_encoder: LabelEncoder - Difficulty class encoder
      categorical_encoders: Dict - categorical feature encoders

   Method: __init__
      Parameters: self
      Logic:
         1. Set model_dir to ml/model
         2. Initialize difficulty_classes list
         3. Load difficulty_model.pkl (multi-class classifier)
         4. Load difficulty_scaler.pkl (feature scaler)
         5. Load difficulty_label_encoder.pkl (LabelEncoder)
         6. Load difficulty_categorical_encoders.pkl (Dict of categorical encoders)
      Return: None (constructor)

   Method: predict_difficulty
      Parameters:
         self
         analyzed_profile: Dict[str, Any] - Profile with pre-calculated ML features
      Logic:
         1. Extract ml_features from analyzed_profile
         2. Raise ValueError if ml_features missing
         3. Get difficulty_numeric (pre-calculated 16 features)
         4. Get difficulty_categorical (pre-calculated 8 features)
         5. Raise ValueError if not exactly 16 numeric features
         6. Raise ValueError if fewer than 3 categorical features
         7. Convert numeric to array and scale via scaler.transform
         8. Encode first 3 categorical features (education_level, learning_style,
            employment_status) via categorical encoders
         9. Handle unknown categories by using zeros
         10. Horizontally stack numeric and encoded categorical features
         11. Predict difficulty class via model.predict
         12. Get probabilities via model.predict_proba
         13. Decode prediction via label_encoder.inverse_transform
         14. Extract max probability as confidence
         15. Return difficulty label and confidence score
      Return: Tuple[str, float] - (difficulty_label, confidence)


Class: LearnerLLMClient
   Location: utils/llm_client.py
   Purpose: Centralized Gemini LLM client with automatic API key rotation

   Attributes:
      model: str - Gemini model name (default: gemini-2.5-flash-lite)
      api_keys: List[str] - List of available Gemini API keys
      current_key_index: int - Index of currently active API key
      client: GenerativeModel - Initialized Gemini client

   Method: __init__
      Parameters:
         self
         model: str - Gemini model to use (default gemini-2.5-flash-lite)
      Logic:
         1. Set model attribute
         2. Get all available API keys via _get_all_api_keys helper
         3. Initialize current_key_index to 0
         4. Raise ValueError if no API keys found
         5. Raise ImportError if google-generativeai not installed
         6. Call _initialize_client to configure first key
      Return: None (constructor)

   Method: _initialize_client
      Parameters: self
      Logic:
         1. Raise ValueError if current_key_index out of bounds
         2. Get API key at current_key_index
         3. Configure genai with current key
         4. Initialize GenerativeModel with model name
      Return: None

   Method: _rotate_api_key
      Parameters: self
      Logic:
         1. Increment current_key_index by 1
         2. Raise ValueError if all keys exhausted
         3. Call _initialize_client with new key
      Return: None

   Method: generate_content
      Parameters:
         self
         prompt: str - Input prompt for Gemini
         temperature: float - Sampling temperature (default 0.7)
         max_tokens: int - Maximum output tokens (default 1000)
         response_mime_type: Optional[str] - Response MIME type (e.g.,
                                             application/json)
      Logic:
         1. Set max_retries to number of available keys
         2. Loop through retry attempts
         3. Build generation_config dict with temperature, max_tokens, mime_type
         4. Call client.generate_content with prompt and config
         5. Raise ValueError if response empty
         6. Return response.text on success
         7. Catch exceptions and check for quota errors (429, quota, rate limit)
         8. If quota error, increment attempt and rotate to next key
         9. If all keys exhausted, raise ValueError with quota message
         10. If non-quota error, raise ValueError immediately
      Return: str - Generated text response

   Method: extract_json_from_response
      Parameters:
         self
         response_text: str - Raw LLM response text
      Logic:
         1. Clean text via _clean_json_text (remove markdown fences)
         2. Create candidates list with cleaned text
         3. Try regex extraction of first JSON object
         4. Add extracted JSON to candidates if found
         5. Loop through candidates
         6. For each candidate, strip trailing commas via _strip_trailing_commas
         7. Parse JSON via json.loads
         8. Raise ValueError if not a dict
         9. Return parsed JSON on success
         10. If all candidates fail, raise ValueError with last error
      Return: Dict[str, Any] - Parsed JSON object

   Method: validate_response_fields
      Parameters:
         self
         response: Dict[str, Any] - JSON response from LLM
         required_fields: list - List of required field names
      Logic:
         1. Create missing_fields list by checking each required field
         2. Raise ValueError if any fields missing with list of missing fields
      Return: None

   Method: generate_structured_json
      Parameters:
         self
         prompt: str - Input prompt for Gemini
         required_fields: list - Required fields in response
         temperature: float - Sampling temperature (default 0.7)
         max_tokens: int - Maximum output tokens (default 1000)
      Logic:
         1. Call generate_content with response_mime_type=application/json
         2. Extract JSON from response via extract_json_from_response
         3. Validate required fields via validate_response_fields
         4. Return validated JSON dict
      Return: Dict[str, Any] - Validated JSON response


================================================================================
                    5. FUNCTION SIGNATURES
================================================================================

5.1 STATE MODULE FUNCTIONS
---------------------------

Function: slugify
   Location: state.py
   Parameters:
      text: str - Text to convert to URL-safe slug format
      max_length: int - Maximum length of output (default 50)
   Logic:
      1. Convert text to lowercase and strip whitespace
      2. Remove all non-word characters except spaces and hyphens
      3. Replace spaces and hyphens with single underscores
      4. Remove leading and trailing underscores
      5. Truncate to max_length characters
   Return: str - URL-safe slug (example: "Severe Chest Pain" becomes
           "severe_chest_pain")

Function: get_initial_state
   Location: state.py
   Parameters:
      learner_json: Dict[str, Any] - Raw learner profile input
   Logic:
      1. Extract learner_id from input or use "UNKNOWN"
      2. Initialize all 93 state fields with default values
      3. Set learner_json and learner_id from input
      4. Set empty dicts/lists for intermediate results
      5. Set False for all completion flags
      6. Set default difficulty to "Intermediate"
      7. Set default urgency to "medium"
      8. Return complete initialized state
   Return: LearnerViabilityState - State dict with all fields initialized

Function: create_output_directory
   Location: state.py
   Parameters:
      learner_id: str - Unique learner identifier
   Logic:
      1. Create Path object for output base directory
      2. Create output base with parents if not exists
      3. Create subdirectory for learner_id
      4. Return string path to learner directory
   Return: str - Path to created output directory

Function: save_file
   Location: state.py
   Parameters:
      file_path: str - Full path to file
      content: str - Content to write
   Logic:
      1. Create parent directories if needed
      2. Open file in write mode
      3. Write content to file
      4. Return True on success
      5. Catch exceptions, print error, return False
   Return: bool - Success status

Function: format_microplan_report
   Location: state.py
   Parameters:
      state: MicroPlanState - Complete state with all pipeline results
   Logic:
      1. Extract learner info from state
      2. Build formatted text sections for:
         - Learner information (name, age, education, style, domain)
         - Goal (primary goal, timeline, outcome)
         - Current proficiency (score, topic)
         - Analysis results (gaps, urgency, difficulty, constraints)
         - Plan Variant A (duration, topics, resources, milestones, coach notes)
         - Plan Variant B (duration, topics, resources, milestones, coach notes)
         - Plan Variant C (duration, topics, resources, milestones, coach notes)
         - Quality metrics
         - Validation results
         - Recommendations for success
         - Disclaimer
      3. Format lists as bullet points
      4. Format plans with nested sections
      5. Add timestamp and system info
      6. Return complete markdown report
   Return: str - Formatted text report

Function: format_list
   Location: state.py
   Parameters:
      items: List[str] - List of items to format
   Logic:
      1. Return "None" if list empty
      2. Join items with newlines, prefix each with bullet
   Return: str - Formatted bullet list

Function: format_plan
   Location: state.py
   Parameters:
      plan: Dict[str, Any] - Plan variant dictionary
   Logic:
      1. Return "Plan not yet generated" if dict empty
      2. Format duration, hours, topics, resources, milestones
      3. Format prerequisites, difficulty progression, success criteria
      4. Return multi-line formatted plan text
   Return: str - Formatted plan section

Function: format_metrics
   Location: state.py
   Parameters:
      metrics: Dict[str, float] - Quality metrics dictionary
   Logic:
      1. Loop through metric key-value pairs
      2. Format booleans as Yes/No
      3. Format floats 0-1 as percentages
      4. Format other floats with 2 decimals
      5. Format other types as strings
   Return: str - Formatted metrics text

Function: get_timestamp
   Location: state.py
   Parameters: None
   Logic:
      1. Get current datetime
      2. Format as "YYYY-MM-DD HH:MM:SS UTC"
   Return: str - Formatted timestamp

Function: extract_learner_metrics
   Location: state.py
   Parameters:
      state: MicroPlanState - Complete state
   Logic:
      1. Extract key metrics from state for quality assessment
      2. Return dict with learner_id, age, education, style, domain, proficiency,
         hours per week, goal timeline
   Return: Dict[str, Any] - Key learner metrics

Function: validate_state
   Location: state.py
   Parameters:
      state: LearnerViabilityState - State to validate
   Logic:
      1. Initialize errors list
      2. Check learner_json and learner_id required
      3. Check analyzed_profile exists if analysis_complete=True
      4. Check difficulty_confidence > 0 if ml_analysis_complete=True
      5. Check plan_variant_a exists if plan_generation_complete=True
      6. Return tuple of (is_valid boolean, errors list)
   Return: tuple[bool, List[str]] - (is_valid, error_list)

Function: calculate_quality_score
   Location: state.py
   Parameters:
      state: LearnerViabilityState - Complete learning plan state
   Logic:
      1. Calculate profile_completeness (0.95 if complete, else 0.0)
      2. Calculate gap_detection_accuracy (gaps count / 12, max 1.0)
      3. Get difficulty_confidence from state
      4. Calculate plan_feasibility (0.85 if validated without issues, else 0.65)
      5. Calculate coaching_adaptation (0.90 if rewriting complete, else 0.0)
      6. Calculate report_completeness (1.0 if complete, else 0.0)
      7. Average all 6 metrics
      8. Add overall_quality to metrics dict
      9. Return metrics dict
   Return: Dict[str, float] - Quality metrics with overall_quality


5.2 GRAPH MODULE FUNCTIONS
---------------------------

Function: run_microplan
   Location: graph.py
   Parameters:
      learner_json: Dict[str, Any] - Learner profile as dictionary
   Logic:
      1. Call run_microplan_workflow from workflow module
      2. Return complete state with all analysis and generated plans
   Return: MicroPlanState - Complete state

Function: run_microplan_from_file
   Location: graph.py
   Parameters:
      file_path: str - Path to learner JSON profile
   Logic:
      1. Open file and load JSON
      2. Call run_microplan with loaded data
      3. Return complete state
   Return: MicroPlanState - Complete state

Function: get_microplan_summary
   Location: graph.py
   Parameters:
      result: MicroPlanState - Complete workflow result
   Logic:
      1. Extract key fields: learner_id, gaps, urgency, difficulty, confidence,
         validation issues, quality score, output directory
      2. Return summary dict
   Return: Dict[str, Any] - Summary with key information

Function: print_microplan_summary
   Location: graph.py
   Parameters:
      result: MicroPlanState - Complete workflow result
   Logic:
      1. Get summary via get_microplan_summary
      2. Print formatted summary with separators
      3. Print identified gaps as bullet list
      4. Print urgency, difficulty, confidence, quality score
      5. Print validation warnings if any
      6. Print output directory
   Return: None


5.3 WORKFLOW MODULE FUNCTIONS
------------------------------

Function: build_workflow
   Location: workflow/workflow.py
   Parameters: None
   Logic:
      1. Create StateGraph with LearnerViabilityState
      2. Add 7 nodes: form_parser, proficiency_assessment_ml,
         learning_readiness_ml, learning_path_generator, path_validator,
         personal_coach, report_generator
      3. Set entry point to form_parser
      4. Add parallel edges from form_parser to both ML nodes
      5. Add convergence edges from both ML nodes to learning_path_generator
      6. Add sequential edges: generator to validator to coach to report
      7. Add exit edge from report_generator to END
      8. Compile and return workflow
   Return: Compiled StateGraph for workflow execution

Function: run_microplan_workflow
   Location: workflow/workflow.py
   Parameters:
      learner_json: dict - Raw learner profile input
   Logic:
      1. Build workflow via build_workflow
      2. Initialize state via get_initial_state
      3. Print workflow header
      4. Invoke workflow with initial state
      5. Print workflow completion message
      6. Return final state
   Return: LearnerViabilityState - Complete state with all results


5.4 NODE MODULE FUNCTIONS
--------------------------

Function: form_parser_node
   Location: nodes/form_parser_node.py
   Parameters:
      state: LearnerViabilityState - State with learner_json populated
   Logic:
      1. Print node header
      2. Initialize ProfileParserAgent
      3. Parse learner_json and get normalized profile, validity, errors
      4. If invalid, return validation_errors and error flags
      5. Initialize ProfileAnalyzerAgent
      6. Analyze normalized profile
      7. Print success with extracted metrics count
      8. Return parsed_learner, analyzed_profile, completion flags
      9. Catch ValueError for validation errors
      10. Catch Exception for other errors
      11. Return appropriate error state
   Return: dict - Updates to state

Function: proficiency_assessment_ml_node
   Location: nodes/proficiency_assessment_node.py
   Parameters:
      state: LearnerViabilityState - State with analyzed_profile
   Logic:
      1. Print node header
      2. Raise ValueError if analyzed_profile empty
      3. Initialize GapDetectionMLAgent
      4. Call detect_gaps with analyzed profile
      5. Print detected gaps count, list, urgency, average confidence
      6. Return identified_gaps, gap_confidence_scores, gap_urgency_level
      7. Catch ValueError for model/data errors
      8. Catch Exception for inference errors
      9. Return error state with empty gaps
   Return: dict - Updates to state

Function: learning_readiness_ml_node
   Location: nodes/learning_readiness_node.py
   Parameters:
      state: LearnerViabilityState - State with analyzed_profile
   Logic:
      1. Print node header
      2. Raise ValueError if analyzed_profile empty
      3. Initialize DifficultyPredictionMLAgent
      4. Call predict_difficulty with analyzed profile
      5. Print predicted difficulty and confidence
      6. Extract proficiency, hours, goals from analyzed profile
      7. Determine readiness level from confidence (>0.7=High, >0.4=Medium, else Low)
      8. Generate readiness text with proficiency, hours, goals, level, difficulty
      9. Return recommended_difficulty, difficulty_confidence,
         learning_readiness_assessment, ml_analysis_complete flag
      10. Catch ValueError for model/data errors
      11. Catch Exception for inference errors
      12. Return error state with default Intermediate difficulty
   Return: dict - Updates to state

Function: learning_path_generator_node
   Location: nodes/learning_path_generator_node.py
   Parameters:
      state: LearnerViabilityState - State with analyzed_profile and ML predictions
   Logic:
      1. Print node header
      2. Extract analyzed profile, gaps, difficulty from state
      3. Raise ValueError if analyzed_profile missing
      4. Initialize LearnerLLMClient
      5. Generate Plan A (Conservative): 1.5x timeline, 8 hrs/week, prerequisites
         required, temp 0.3
      6. Generate Plan B (Standard): 1x timeline, 10 hrs/week, prerequisites
         required, temp 0.3
      7. Generate Plan C (Aggressive): 0.7x timeline, 15 hrs/week, prerequisites
         optional, temp 0.3
      8. Print success message
      9. Return plan_variant_a/b/c, plan_generation_complete flag
      10. Catch ValueError for JSON parsing errors
      11. Catch Exception for API errors
      12. Return error state with empty plans
   Return: dict - Updates to state

Function: _generate_plan_variant
   Location: nodes/learning_path_generator_node.py
   Parameters:
      client: LearnerLLMClient - LLM client instance
      analyzed: dict - Analyzed profile
      gaps: list - Identified gaps
      difficulty: str - Recommended difficulty
      variant: str - Variant name (Conservative/Standard/Aggressive)
      timeline_factor: float - Timeline multiplier (0.7-1.5)
      hours_per_week: int - Recommended hours per week
      require_prerequisites: bool - Whether prerequisites required
      temperature: float - LLM temperature
   Logic:
      1. Extract learner goals and timeline from analyzed profile
      2. Calculate adjusted timeline (timeline * timeline_factor, min 1 week)
      3. Build prompt with learner profile, difficulty, time, gaps, variant requirements
      4. Specify JSON structure with 8 required fields (duration_weeks, hours_per_week,
         intensity, topics, resources, milestones, prerequisites, success_criteria,
         difficulty_progression)
      5. Call client.generate_content with prompt, temperature, max_tokens=2000
      6. Extract JSON from response via client.extract_json_from_response
      7. Validate required fields via client.validate_response_fields
      8. Return plan dict
   Return: dict - Plan variant with all required fields

Function: path_validator_node
   Location: nodes/path_validator_node.py
   Parameters:
      state: LearnerViabilityState - State with plan_variant_a/b/c populated
   Logic:
      1. Print node header
      2. Extract plan variants and analyzed profile from state
      3. Raise ValueError if plans or analyzed_profile missing
      4. Initialize LearnerLLMClient
      5. Call _validate_plans_with_llm with client, plans tuple, analyzed profile
      6. Print validation results (warnings count or success)
      7. Return plan_variant_a/b/c_validated, validation_issues,
         validation_complete flag
      8. Catch ValueError for validation errors
      9. Catch Exception for API errors
      10. Return error state with original plans as validated
   Return: dict - Updates to state

Function: _validate_plans_with_llm
   Location: nodes/path_validator_node.py
   Parameters:
      client: LearnerLLMClient - LLM client instance
      plans: tuple - Tuple of (plan_a, plan_b, plan_c)
      analyzed: dict - Analyzed profile
   Logic:
      1. Unpack plan tuple
      2. Extract hours_available and timeline from analyzed profile
      3. Build prompt with learner constraints and plan summaries
      4. Ask LLM to validate hours vs availability, timeline fit, milestone
         achievability, prerequisite necessity
      5. Request JSON with critical_issues list
      6. Call client.generate_content with prompt, temp 0.3, max_tokens 500
      7. Extract JSON and get critical_issues list
      8. Return original plans unchanged plus issues list
   Return: tuple - (plan_a_validated, plan_b_validated, plan_c_validated,
           issues_list)

Function: personal_coach_node
   Location: nodes/personal_coach_node.py
   Parameters:
      state: LearnerViabilityState - State with plan_variant_*_validated
   Logic:
      1. Print node header
      2. Extract validated plans and analyzed profile from state
      3. Raise ValueError if plans or analyzed_profile missing
      4. Determine coaching tone via _determine_coaching_tone
      5. Print tone
      6. Initialize LearnerLLMClient
      7. Rewrite Plan A with tone via _rewrite_plan_with_tone
      8. Rewrite Plan B with tone
      9. Rewrite Plan C with tone
      10. Print success message
      11. Return variant_a/b/c_friendly, rewriting_complete flag
      12. Catch ValueError for validation errors
      13. Catch Exception for API errors
      14. Return error state with empty friendly texts
   Return: dict - Updates to state

Function: _determine_coaching_tone
   Location: nodes/personal_coach_node.py
   Parameters:
      analyzed: dict - Analyzed profile
   Logic:
      1. Extract age, learning_style, motivation from derived_metrics
      2. Determine base tone from age: <18=encouraging_youth, <25=conversational,
         else=professional
      3. Override with learning style: visual=visual_metaphor_based,
         kinesthetic=practical_action_oriented, auditory=conversational
      4. Return tone string
   Return: str - Tone description

Function: _rewrite_plan_with_tone
   Location: nodes/personal_coach_node.py
   Parameters:
      client: LearnerLLMClient - LLM client instance
      plan: dict - Validated plan
      analyzed: dict - Analyzed profile
      tone: str - Tone description
      variant_name: str - Plan variant name (Conservative/Standard/Aggressive)
   Logic:
      1. Extract learner name, goal, motivation from analyzed profile
      2. Extract topics, milestones, duration, hours from plan
      3. Build prompt with learner info, goal, tone, plan summary
      4. Provide tone guidelines: use "you", encourage, personalize, add emojis for
         youth, metaphors for visual, action steps for kinesthetic, conversational
         for auditory
      5. Request 2-3 paragraph personal coaching message in markdown
      6. Call client.generate_content with prompt, temp 0.5, max_tokens 500
      7. Strip and return response text
   Return: str - Markdown formatted coaching message

Function: report_generator_node
   Location: nodes/report_generator_node.py
   Parameters:
      state: LearnerViabilityState - State with all pipeline stages complete
   Logic:
      1. Print node header
      2. Extract learner_id and analyzed profile from state
      3. Raise ValueError if analyzed_profile missing
      4. Create output directory via create_output_directory
      5. Calculate quality metrics via calculate_quality_score
      6. Generate markdown report via format_microplan_report
      7. Save markdown report to micro_plan_report.txt
      8. Generate JSON report via _generate_json_report
      9. Save JSON report to micro_plan.json
      10. Save quality metrics to evaluation_metrics.json
      11. Print completion message and quality score
      12. Return final_report, report_json, quality_metrics, saved_path,
          output_dir, report_complete flag
      13. Catch ValueError for validation errors
      14. Catch Exception for file I/O errors
      15. Return error state with empty reports
   Return: dict - Updates to state

Function: _generate_json_report
   Location: nodes/report_generator_node.py
   Parameters:
      state: LearnerViabilityState - Complete state
      quality_metrics: dict - Calculated quality metrics
   Logic:
      1. Build metadata section with timestamp, version, system name
      2. Extract learner_profile via extract_learner_metrics
      3. Build analysis section with gaps, urgency, difficulty, confidence, readiness
      4. Build learning_plans section with conservative/standard/aggressive variants
      5. Build personalized_coaching section with coaching texts for all variants
      6. Build validation section with issues and completion flag
      7. Add quality_metrics section
      8. Build recommendations section with next_steps and success_factors lists
      9. Return complete structured JSON report
   Return: dict - Structured JSON report


5.5 ML TRAINING FUNCTIONS
--------------------------

Function: run_training_pipeline
   Location: ml/train_pipeline.py
   Parameters:
      data_dir: str - Root data directory (default "data")
      processed_dir: str - Directory for cleaned data (default "data/processed")
      model_dir: str - Directory for trained models (default "ml/model")
   Logic:
      1. Initialize results dict with empty sections for gap/difficulty
         cleaning and training
      2. Load raw gap and difficulty training/eval datasets from data/raw/
      3. Clean gap training data via clean_gap_data, save to processed/
      4. Clean difficulty training data via clean_difficulty_data, save to processed/
      5. Train gap detection model via train_gap_detection_model, save to ml/model/
      6. Train difficulty prediction model via train_difficulty_prediction_model,
         save to ml/model/
      7. Update results dict with metrics from each stage
      8. Set status to "success"
      9. Print completion message with model and data paths
      10. Return results dict
      11. Catch exceptions, set status to "failed", print error, return results
   Return: Dict[str, Any] - Training pipeline results with cleaning stats and
           training metrics

Function: prepare_gap_features
   Location: ml/train_model/train_gap_model.py
   Parameters:
      df: DataFrame - Input data
      vectorizer: Text transformer
      scaler: Numeric feature scaler
      fit: bool - Whether to fit transformers (default False)
   Logic:
      1. Combine text columns (primary_domain, learning_style, data_source) into
         single text string per row
      2. If fit=True, fit_transform vectorizer on text, else transform only
      3. Select 15 numeric columns (age, proficiency, hours, completion, motivation,
         gpa, dropout, education years, courses, concept understanding, practical
         application, problem solving, goal clarity, assessment confidence, timeline)
      4. Convert to numeric type, coerce errors to NaN
      5. Fill NaN with column means (or 0 if all NaN)
      6. If fit=True, fit_transform scaler on numeric, else transform only
      7. Horizontally stack TF-IDF and scaled numeric features
      8. Return combined feature matrix
   Return: ndarray - Combined features (n_samples, n_features)

Function: prepare_gap_targets
   Location: ml/train_model/train_gap_model.py
   Parameters:
      df: DataFrame - Input data
      mlb: MultiLabelBinarizer - Label binarizer
      fit: bool - Whether to fit binarizer (default False)
   Logic:
      1. Define parse_gaps helper to convert string/list to list of gap labels
      2. Apply parse_gaps to identified_gaps column
      3. If fit=True, fit_transform mlb on gaps list, return binary matrix and labels
      4. Else transform only, return binary matrix
   Return: tuple - (binary_matrix, gap_labels) if fit, else (binary_matrix, None)

Function: train_gap_detection_model
   Location: ml/train_model/train_gap_model.py
   Parameters:
      train_df: DataFrame - Training data
      eval_df: DataFrame - Evaluation data
      model_save_dir: str - Directory to save artifacts (default "ml/model")
   Logic:
      1. Initialize text vectorizer (max 5000 features, bigrams)
      2. Initialize feature scaler
      3. Initialize MultiLabelBinarizer
      4. Initialize multi-label classifier
      5. Prepare training features via prepare_gap_features with fit=True
      6. Prepare training targets via prepare_gap_targets with fit=True
      7. Print feature and target shapes, gap labels
      8. Train model via model.fit
      9. Evaluate on training set (accuracy, Hamming loss)
      10. Prepare eval features and targets with fit=False
      11. Evaluate on eval set (accuracy, Hamming loss)
      12. Save model, vectorizer, mlb, scaler, labels to model_save_dir
      13. Return metrics dict with train/eval accuracy, Hamming loss, overfitting gap,
          label count, labels list
   Return: dict - Training metrics

Function: prepare_difficulty_features
   Location: ml/train_model/train_difficulty_model.py
   Parameters:
      df: DataFrame - Input data
      numeric_scaler: Numeric feature scaler
      categorical_encoders: dict - Dict of categorical encoders
      fit: bool - Whether to fit transformers (default False)
   Logic:
      1. Select 16 numeric columns (age, ability, speed, time, motivation, consistency,
         goal alignment, career urgency, previous attempts, avg score, success rate,
         topic complexity, prerequisites count, mastery, estimated hours, available weeks)
      2. Convert to numeric type, coerce errors to NaN
      3. Fill NaN with column means (or 0 if all NaN)
      4. If fit=True, fit_transform scaler, else transform only
      5. Select 3 categorical columns (education_level, learning_style,
         employment_status)
      6. For each categorical column:
         a. Fill NaN with 'unknown'
         b. If fit=True, fit_transform categorical encoder and store in encoders dict
         c. Else transform with existing encoder
         d. Append encoded array to list
      7. Horizontally stack all categorical encoded arrays
      8. Horizontally stack numeric and categorical features
      9. Return combined feature matrix
   Return: ndarray - Combined features (n_samples, n_features)

Function: prepare_difficulty_targets
   Location: ml/train_model/train_difficulty_model.py
   Parameters:
      df: DataFrame - Input data
      label_encoder: LabelEncoder - Label encoder
      fit: bool - Whether to fit encoder (default False)
   Logic:
      1. Determine target column (recommended_difficulty_level or
         recommended_difficulty)
      2. Extract target values
      3. If fit=True, fit_transform label_encoder, else transform only
      4. Return encoded labels
   Return: ndarray - Encoded labels (n_samples,)

Function: train_difficulty_prediction_model
   Location: ml/train_model/train_difficulty_model.py
   Parameters:
      train_df: DataFrame - Training data
      eval_df: DataFrame - Evaluation data
      model_save_dir: str - Directory to save artifacts (default "ml/model")
   Logic:
      1. Initialize feature scaler
      2. Initialize LabelEncoder
      3. Initialize empty categorical_encoders dict
      4. Initialize multi-class classifier
      5. Prepare training features via prepare_difficulty_features with fit=True
      6. Prepare training targets via prepare_difficulty_targets with fit=True
      7. Print feature and target shapes, class labels
      8. Train model via model.fit
      9. Evaluate on training set (accuracy)
      10. Perform 5-fold cross-validation, print scores and mean
      11. Prepare eval features and targets with fit=False
      12. Evaluate on eval set (accuracy, classification report)
      13. Save model, scaler, label_encoder, categorical_encoders to model_save_dir
      14. Return metrics dict with train/eval accuracy, CV score, CV std,
          overfitting gap, classes
   Return: dict - Training metrics

Function: clean_gap_data
   Location: ml/cleaning/clean_gap_data.py
   Parameters:
      df: DataFrame - Input data
      save_processed: bool - Whether to save cleaned data (default False)
      output_dir: str - Output directory (default "data/processed")
   Logic:
      1. Record original row count
      2. Remove duplicates
      3. For 17 numeric columns, convert to numeric, fill NaN with median
      4. For 3 categorical columns, fill NaN with mode or 'Unknown'
      5. Fix categorical values to valid sets (education levels, learning styles,
         employment status)
      6. Clip numeric outliers to valid ranges (age 10-100, proficiency 0-100, etc.)
      7. Parse identified_gaps column (JSON or literal eval) to lists
      8. Remove rows with empty gaps
      9. Calculate cleaning stats (rows removed, duplicates, empty gaps)
      10. If save_processed, save to output_dir/gap_detection_cleaned.csv
      11. Return cleaned df and stats dict
   Return: Tuple[DataFrame, dict] - (cleaned_df, stats)

Function: clean_difficulty_data
   Location: ml/cleaning/clean_difficulty_data.py
   Parameters:
      df: DataFrame - Input data
      save_processed: bool - Whether to save cleaned data (default False)
      output_dir: str - Output directory (default "data/processed")
   Logic:
      1. Record original row count
      2. Remove duplicates
      3. For 16 numeric columns, convert to numeric, fill NaN with median
      4. For 8 categorical columns, fill NaN with mode or 'Unknown'
      5. Fix categorical values to valid sets (education, learning styles, motivation,
         employment, difficulty levels)
      6. Clip numeric outliers to valid ranges (age 10-100, ability 0-100, etc.)
      7. Calculate class distribution for recommended_difficulty
      8. Calculate cleaning stats (rows removed, duplicates, class distribution)
      9. If save_processed, save to output_dir/difficulty_prediction_cleaned.csv
      10. Return cleaned df and stats dict
   Return: Tuple[DataFrame, dict] - (cleaned_df, stats)

Function: evaluate_gap_detection_model
   Location: ml/evaluation/evaluate_models.py
   Parameters:
      model_dir: str - Model directory (default "ml/model")
   Logic:
      1. Check if gap_model.pkl exists
      2. Return error dict if not found
      3. Load model from pickle
      4. Return dict with model type, status, placeholder accuracy (0.87),
         placeholder Hamming loss (0.0234), samples (0)
      5. Catch exceptions and return error dict
   Return: dict - Evaluation results or error

Function: evaluate_difficulty_prediction_model
   Location: ml/evaluation/evaluate_models.py
   Parameters:
      model_dir: str - Model directory (default "ml/model")
   Logic:
      1. Check if difficulty_model.pkl exists
      2. Return error dict if not found
      3. Load model from pickle
      4. Return dict with model type, status, placeholder accuracy (0.82),
         placeholder CV score (0.85), samples (0)
      5. Catch exceptions and return error dict
   Return: dict - Evaluation results or error

Function: evaluate_all_models
   Location: ml/evaluation/evaluate_models.py
   Parameters:
      model_dir: str - Model directory (default "ml/model")
   Logic:
      1. Evaluate gap detection model
      2. Evaluate difficulty prediction model
      3. Return dict with timestamp and both evaluation results
   Return: dict - Combined evaluation results


5.6 UTILITY FUNCTIONS
----------------------

Function: _get_all_api_keys
   Location: utils/llm_client.py
   Parameters: None
   Logic:
      1. Initialize empty keys list
      2. Try importing streamlit, check secrets for GEMINI_API_KEY_1 through 4
      3. Add found secrets to keys list
      4. Check environment variable GEMINI_API_KEY, add if not in list
      5. Check environment variables GEMINI_API_KEY_1 through 4, add if not in list
      6. Return deduplicated keys list
   Return: list - List of API keys

Function: _get_first_api_key
   Location: utils/llm_client.py
   Parameters: None
   Logic:
      1. Get all keys via _get_all_api_keys
      2. Return first key if list not empty, else None
   Return: Optional[str] - First API key or None

Function: _clean_json_text
   Location: utils/llm_client.py
   Parameters:
      text: str - Raw LLM response text
   Logic:
      1. Strip whitespace
      2. Remove "json" markdown fences via regex
      3. Remove all markdown fences
      4. Strip and return
   Return: str - Cleaned text without markdown

Function: _strip_trailing_commas
   Location: utils/llm_client.py
   Parameters:
      text: str - JSON text with potential trailing commas
   Logic:
      1. Loop until text stops changing
      2. Replace ", }" with " }" and ", ]" with " ]" via regex
      3. Return fixed text
   Return: str - JSON text with trailing commas removed

Function: build_llm_client
   Location: utils/llm_client.py
   Parameters:
      model: str - Gemini model to use (default gemini-2.5-flash-lite)
   Logic:
      1. Get first API key via _get_first_api_key
      2. Raise ValueError if no key found
      3. Raise ImportError if google-generativeai not installed
      4. Create and return LearnerLLMClient instance
   Return: LearnerLLMClient - Configured client

Function: extract_json
   Location: utils/llm_client.py
   Parameters:
      text: str - Text potentially containing JSON
   Logic:
      1. Regex search for first JSON object
      2. Raise ValueError if no JSON found
      3. Parse JSON via json.loads
      4. Return parsed JSON
      5. Catch exceptions and raise ValueError
   Return: Dict[str, Any] - Extracted JSON


================================================================================
                       6. INCLUDE ALL MODULES
================================================================================

This documentation covers all modules from all directories as follows:

AGENTS DIRECTORY (agents/)
   - profile_parser.py - Input validation and normalization
   - profile_analyzer.py - Feature extraction and metric calculation
   - gap_detection_ml.py - ML-based learning gap detection
   - difficulty_prediction_ml.py - ML-based difficulty level prediction

NODES DIRECTORY (nodes/)
   - form_parser_node.py - Parse and analyze learner input
   - proficiency_assessment_node.py - ML gap detection node
   - learning_readiness_node.py - ML difficulty prediction node
   - learning_path_generator_node.py - LLM plan generation node
   - path_validator_node.py - Plan validation node
   - personal_coach_node.py - Coaching personalization node
   - report_generator_node.py - Report generation and file output

ML DIRECTORY (ml/)
   - train_pipeline.py - End-to-end ML training orchestration
   - cleaning/clean_gap_data.py - Gap detection data cleaning
   - cleaning/clean_difficulty_data.py - Difficulty prediction data cleaning
   - train_model/train_gap_model.py - Train multi-label gap detection
   - train_model/train_difficulty_model.py - Train multi-class difficulty
   - evaluation/evaluate_models.py - Evaluate trained ML models

UTILS DIRECTORY (utils/)
   - llm_client.py - Centralized Gemini LLM client

WORKFLOW DIRECTORY (workflow/)
   - workflow.py - LangGraph workflow orchestration

ROOT LEVEL FILES
   - state.py - State management and data structures
   - graph.py - Programmatic workflow execution interface
   - main.py - Streamlit web application entry point


================================================================================
                      7. USER INTERFACE DESIGN
================================================================================

7.1 STREAMLIT UI COMPONENTS
----------------------------

The LearnBuddy application provides a web-based interface built with Streamlit,
offering an intuitive and interactive experience for generating personalized
learning plans.

Main Application Structure (main.py):

1. Page Configuration
   - Title: "LearnBuddy Micro"
   - Subtitle: "AI-Powered Personalized Learning Plan Generator"
   - Layout: Wide layout for maximum content visibility
   - Sidebar: Expanded by default for learner selection
   - Page Icon: Book emoji
   - Status Badge: "Production Ready" info badge

2. Session State Management
   The application maintains state across user interactions:
   - run_evaluation: Boolean flag for model evaluation trigger
   - eval_results: Dictionary storing model evaluation metrics
   - sample_profile: Currently selected learner profile dictionary
   - analysis_result: Complete workflow output state
   - run_analysis: Boolean flag for workflow execution trigger


7.2 PAGE LAYOUT DESCRIPTION
----------------------------

HEADER SECTION
   Column 1 (75 percent width):
      - Main title "LearnBuddy Micro"
      - Subtitle with description

   Column 2 (25 percent width):
      - "Production Ready" status badge

DISCLAIMER SECTION (Collapsible Expander)
   Warning Box containing:
      - Educational use only notice
      - Results are informational only
      - Consult professionals disclaimer
      - Individual outcomes vary notice
      - Adaptation recommendation

WORKFLOW STEPS INDICATOR
   Three equal columns displaying:
      Column 1: "Step 1: Load learner profile"
      Column 2: "Step 2: ML analysis"
      Column 3: "Step 3: Get personalized plan"

SIDEBAR SECTION
   Learner Selection Panel:
      - Header: "Learner Selection"
      - Dropdown: Select from learn_001.json through learn_015.json
      - Help text: "Select from pre-generated learner profiles"
      - Profile Summary (Collapsible):
         * Age metric
         * Education metric
         * Learning Style metric
         * Proficiency metric (X/100 format)
      - Success message: Shows loaded learner name

   Tools Section:
      - "Run Model Evaluation" button (secondary style, full width)

MAIN ACTION SECTION
   Primary Button: "Generate Personalized Learning Plan"
      - Full width
      - Primary style (blue)
      - Disabled if no profile selected
      - Triggers workflow execution

PROGRESS INDICATOR (During Execution)
   Progress bar showing:
      - 0 percent: "Initializing workflow..."
      - 10 percent: "Parsing profile..."
      - Spinner: "AI is analyzing and generating your personalized plan..."
      - 100 percent: "Complete"

RESULTS SECTION (Post-Execution)
   Success message: "Analysis Complete! View results in tabs below:"


7.3 TABS AND SECTIONS
----------------------

The results are organized into 5 main tabs for easy navigation:

TAB 1: ANALYSIS
   Top Metrics Row (3 columns):
      Column 1: "Identified Gaps" metric
         - Shows count of detected gaps
         - Help text: "Number of learning gaps detected"

      Column 2: "Urgency Level" metric
         - Shows urgency in uppercase (CRITICAL/HIGH/MEDIUM/LOW)
         - Help text: "Priority level for addressing gaps"

      Column 3: "Recommended Level" metric
         - Shows difficulty level (Beginner/Intermediate/Advanced)
         - Delta: Confidence percentage
         - Help text: Recommendation with confidence

   Gap Details Section:
      - Subheader: "Detected Learning Gaps:"
      - For each gap:
         * Gap name (formatted, title case)
         * Confidence percentage in parentheses
      - If no gaps: Info message "No specific gaps detected"

TAB 2: PLANS
   Three columns showing plan variants side-by-side:

   Column 1: Plan A (Conservative)
      - Duration in weeks
      - Weekly commitment in hours
      - Intensity level (uppercase)
      - Topics count and first 5 topics as bullets
      - "... and X more" if topics exceed 5

   Column 2: Plan B (Standard)
      - Same structure as Plan A

   Column 3: Plan C (Aggressive)
      - Same structure as Plan A

TAB 3: RECOMMENDATIONS
   Three columns showing personalized coaching:

   Column 1: "Conservative Coaching"
      - Personalized coaching text for Plan A
      - Motivational message in learner's tone

   Column 2: "Standard Coaching"
      - Personalized coaching text for Plan B

   Column 3: "Aggressive Coaching"
      - Personalized coaching text for Plan C

TAB 4: FULL REPORT
   - Subheader: "Full Learning Plan Report"
   - Text box displaying complete markdown report
   - Includes all sections: learner info, goals, analysis, all plans, metrics,
     recommendations, disclaimer

TAB 5: DOWNLOAD
   - Subheader: "Download Your Plan"

   Two columns:
      Column 1: JSON Download
         - Download button for JSON report
         - File name: microplan_report.json
         - MIME type: application/json

      Column 2: Text Download
         - Download button for text report
         - File name: microplan_report.txt
         - MIME type: text/plain

   - Success message showing output directory path

QUALITY ASSESSMENT SECTION (Below Tabs)
   Four columns showing quality metrics:
      Column 1: "Profile Complete" percentage
      Column 2: "Gap Detection" percentage
      Column 3: "Plan Feasible" percentage
      Column 4: "Overall Quality" percentage

MODEL EVALUATION SECTION (Bottom of Page)
   Header: "ML Model Evaluation"
   Description: "Performance metrics of trained machine learning models"

   Default State:
      - Info message: "Click 'Run Model Evaluation' in sidebar to evaluate models"

   Evaluation Results (After Running):
      Two columns:
         Column 1: Gap Detection Model
            - Accuracy metric with percentage
            - Hamming Loss metric with 4 decimals
            - Test Samples count

         Column 2: Difficulty Prediction Model
            - Accuracy metric with percentage
            - Cross-Val Score metric with percentage
            - Test Samples count

      Expandable Raw Data Section:
         - "View Raw Evaluation Data" expander
         - JSON display of complete evaluation results


7.4 USER INTERACTION FLOW
--------------------------

STEP 1: LEARNER PROFILE SELECTION
   1. User navigates to application
   2. Sidebar shows available learner profiles in dropdown
   3. User selects a profile (e.g., learn_001.json)
   4. Profile loads and displays summary in sidebar
   5. Success message shows learner name
   6. Main button becomes enabled

STEP 2: GENERATE LEARNING PLAN
   1. User clicks "Generate Personalized Learning Plan" button
   2. Progress bar appears at 0 percent with "Initializing workflow..."
   3. Progress updates to 10 percent with "Parsing profile..."
   4. Spinner appears with "AI is analyzing..."
   5. Workflow executes through 7 nodes:
      - Form parsing and analysis
      - Parallel ML assessment (gap detection + difficulty prediction)
      - Learning path generation (3 variants)
      - Plan validation
      - Personal coaching
      - Report generation
   6. Progress completes at 100 percent
   7. Success message appears

STEP 3: VIEW RESULTS
   1. Tab navigation appears below success message
   2. User can switch between 5 tabs:
      - Analysis: View detected gaps and recommendations
      - Plans: Compare three plan variants
      - Recommendations: Read personalized coaching
      - Full Report: See comprehensive text report
      - Download: Get JSON and text files
   3. Quality metrics display at bottom
   4. User can review all results interactively

STEP 4: DOWNLOAD REPORTS (Optional)
   1. User switches to Download tab
   2. Clicks "Download JSON Report" for machine-readable output
   3. Clicks "Download Text Report" for human-readable output
   4. Files download to user's system
   5. Output directory path shown for reference

STEP 5: EVALUATE MODELS (Optional)
   1. User clicks "Run Model Evaluation" in sidebar
   2. Spinner appears with "Evaluating ML models..."
   3. Evaluation results populate at bottom of page
   4. Metrics display for both ML models
   5. Raw data available in expander

STEP 6: TRY ANOTHER LEARNER (Optional)
   1. User selects different profile from sidebar
   2. Results clear
   3. User clicks generate button again
   4. New results appear
   5. Process repeats


7.5 INPUT FIELDS AND OUTPUT DISPLAYS
-------------------------------------

INPUT FIELDS:

1. Learner Profile Selector (Sidebar)
   - Type: Dropdown select box
   - Options: learn_001.json through learn_015.json
   - Source: data/input/learner_profiles/ directory
   - Format: JSON files with standardized learner schema
   - Required Fields in JSON:
     * learner_id (string)
     * personal_info (age, country, languages, timezone)
     * educational_background (qualification, GPA, field)
     * learning_profile (style, pace, formats, focus duration)
     * current_status (domain, proficiency, projects, challenges)
     * learning_goals (primary, secondary, timeline, outcome)
     * constraints (hours per week, budget, certification need)
     * learning_history (courses, completion rates, scores)
     * preferences (instructor type, difficulty pace, project-based)
     * challenges_and_support (learning challenges, accessibility)

2. Action Trigger Button
   - Type: Primary button
   - Label: "Generate Personalized Learning Plan"
   - Action: Executes run_microplan_workflow function
   - Validation: Disabled if no profile selected

3. Model Evaluation Trigger (Sidebar)
   - Type: Secondary button
   - Label: "Run Model Evaluation"
   - Action: Calls evaluate_all_models function
   - No validation required

OUTPUT DISPLAYS:

1. Analysis Tab Metrics
   - Identified Gaps: Integer count with bullet list of gap names
   - Urgency Level: String (CRITICAL/HIGH/MEDIUM/LOW)
   - Recommended Difficulty: String (Beginner/Intermediate/Advanced)
   - Confidence: Float percentage (0-100 percent)
   - Gap Confidence Scores: Dictionary mapping gaps to percentages

2. Plans Tab Displays
   For each variant (A, B, C):
      - Duration: Integer weeks
      - Weekly Commitment: Integer hours
      - Intensity: String (LOW/MEDIUM/HIGH)
      - Topics: List of strings (first 5 shown, count if more)
      - Resources: List of strings
      - Milestones: List of strings
      - Prerequisites: List of strings
      - Success Criteria: List of strings
      - Difficulty Progression: String description

3. Recommendations Tab Displays
   For each variant:
      - Coaching Text: Markdown formatted 2-3 paragraphs
      - Personalized tone based on learner profile
      - Motivational messaging
      - Action-oriented guidance

4. Full Report Display
   - Format: Markdown text in monospace font
   - Sections:
     * Learner Information (name, ID, age, education, style, domain)
     * Goal (primary goal, timeline, outcome)
     * Current Proficiency (score, topic)
     * Analysis Results (gaps, urgency, difficulty, constraints)
     * Plan Variant A (complete plan with coach notes)
     * Plan Variant B (complete plan with coach notes)
     * Plan Variant C (complete plan with coach notes)
     * Quality Metrics (6 dimensions + overall)
     * Validation Results (status, issues if any)
     * Recommendations for Success (7 bullet points)
     * Disclaimer

5. Download Tab Outputs
   - JSON Report: Structured JSON with 7 top-level sections
     * metadata (timestamp, version, system)
     * learner_profile (8 key metrics)
     * analysis (gaps, urgency, difficulty, readiness)
     * learning_plans (3 variants as dicts)
     * personalized_coaching (3 coaching texts)
     * validation (issues, completion flag)
     * quality_metrics (6 scores + overall)
     * recommendations (next_steps, success_factors)

   - Text Report: Same content as Full Report tab
   - Output Directory: String path to saved files

6. Quality Assessment Metrics
   - Profile Completeness: Float percentage (0-100 percent)
   - Gap Detection Accuracy: Float percentage (0-100 percent)
   - Plan Feasibility: Float percentage (0-100 percent)
   - Overall Quality: Float percentage (0-100 percent)

7. Model Evaluation Outputs
   Gap Detection Model:
      - Accuracy: Float percentage (0-100 percent)
      - Hamming Loss: Float (0-1 scale)
      - Test Samples: Integer count

   Difficulty Prediction Model:
      - Accuracy: Float percentage (0-100 percent)
      - Cross-Val Score: Float percentage (0-100 percent)
      - Test Samples: Integer count


================================================================================
                  8. RUNNING COMMANDS AND EXECUTION FLOW
================================================================================

8.1 ENVIRONMENT SETUP
----------------------

STEP 1: INSTALL DEPENDENCIES

Command:
   pip install -r installation.txt

Required Packages:
   - streamlit (latest version)
   - python-dotenv==1.0.1
   - joblib>=1.3.0
   - langgraph==0.2.50
   - langchain==0.3.7
   - langchain-core==0.3.15
   - langchain-community==0.3.5
   - langchain-google-genai==2.0.5
   - pydantic==2.8.2
   - pydantic-settings>=2.7,<3
   - rouge-score==0.1.2
   - loguru==0.7.2
   - scikit-learn>=1.3.0
   - pandas>=2.0.0
   - numpy>=1.24.0
   - scipy>=1.10.0
   - typing-extensions>=4.8.0
   - importlib-metadata>=6.8.0
   - pytest>=7.4.0
   - google-generativeai>=0.3.0
   - email-validator>=2.0.0
   - python-magic>=0.4.27
   - requests>=2.31.0

Duration: 2-5 minutes depending on network speed

STEP 2: CONFIGURE API KEYS

Create .env file in project root:
   GEMINI_API_KEY=your_api_key_here
   GEMINI_API_KEY_1=backup_key_1
   GEMINI_API_KEY_2=backup_key_2
   GEMINI_API_KEY_3=backup_key_3
   GEMINI_API_KEY_4=backup_key_4

Alternative: Set environment variables
   export GEMINI_API_KEY=your_api_key_here

Note: Multiple keys enable automatic rotation on quota exceeded

STEP 3: VERIFY DIRECTORY STRUCTURE

Ensure the following directories exist:
   - data/raw/ (for training datasets)
   - data/processed/ (for cleaned data)
   - data/input/learner_profiles/ (for input profiles)
   - ml/model/ (for trained model artifacts)
   - output/ (for generated reports)

Create missing directories:
   mkdir -p data/raw data/processed data/input/learner_profiles ml/model output


8.2 DATA CLEANING AND PREPROCESSING COMMANDS
---------------------------------------------

STEP 1: PREPARE RAW TRAINING DATA

Place raw CSV files in data/raw/:
   - gap_training_raw.csv (gap detection training data)
   - gap_eval_raw.csv (gap detection evaluation data)
   - difficulty_training_raw.csv (difficulty prediction training data)
   - difficulty_eval_raw.csv (difficulty prediction evaluation data)

Expected Format for gap_training_raw.csv:
   Columns: learner_id, age, current_proficiency_score, hours_available_per_week,
            primary_domain, learning_style, employment_status,
            avg_completion_rate, motivation_level, current_gpa,
            course_dropout_rate, years_in_education, total_courses_completed,
            concept_understanding_score, practical_application_score,
            problem_solving_ability, goal_clarity_score, assessment_confidence,
            target_timeline_months, data_source, identified_gaps

Expected Format for difficulty_training_raw.csv:
   Columns: learner_id, age, current_ability_score, learning_speed_factor,
            time_to_complete_typical_course_hours, education_level,
            learning_style, employment_status, motivation_level,
            learning_consistency, goal_alignment, career_urgency,
            previous_attempts_on_similar, avg_score_on_similar_topics,
            success_rate_on_similar_topics, topic_complexity_rating,
            required_prerequisites_count, prerequisites_mastery_level,
            estimated_hours_to_master, available_time_weeks,
            recommended_difficulty_level

STEP 2: RUN DATA CLEANING (STANDALONE)

Clean gap detection data:
   python -m ml.cleaning.clean_gap_data

   Process:
   1. Load gap_training_raw.csv
   2. Remove duplicates
   3. Fill missing numeric values with median
   4. Fill missing categorical values with mode
   5. Fix categorical values to valid sets
   6. Clip numeric outliers (age 10-100, proficiency 0-100, etc.)
   7. Parse and validate gap labels
   8. Remove rows with empty gaps
   9. Save to data/processed/gap_detection_cleaned.csv

   Output:
   - Cleaned CSV file
   - Stats printed (original rows, cleaned rows, duplicates removed, etc.)

Clean difficulty prediction data:
   python -m ml.cleaning.clean_difficulty_data

   Process:
   1. Load difficulty_training_raw.csv
   2. Remove duplicates
   3. Fill missing numeric values with median
   4. Fill missing categorical values with mode
   5. Fix categorical values to valid sets
   6. Clip numeric outliers
   7. Validate class distribution
   8. Save to data/processed/difficulty_prediction_cleaned.csv

   Output:
   - Cleaned CSV file
   - Stats printed (original rows, cleaned rows, class distribution, etc.)

Duration: 10-30 seconds per dataset


8.3 ML MODEL TRAINING COMMANDS
-------------------------------

OPTION A: TRAIN ALL MODELS (RECOMMENDED)

Command:
   python -m ml.train_pipeline

Execution Flow:
   Stage 1: Load Datasets
      - Load gap_training_raw.csv and gap_eval_raw.csv
      - Load difficulty_training_raw.csv and difficulty_eval_raw.csv
      - Print dataset sizes

   Stage 2: Clean Gap Detection Data
      - Clean training data via clean_gap_data
      - Save to data/processed/gap_detection_cleaned.csv
      - Print cleaning stats

   Stage 3: Clean Difficulty Prediction Data
      - Clean training data via clean_difficulty_data
      - Save to data/processed/difficulty_prediction_cleaned.csv
      - Print cleaning stats

   Stage 4: Train Gap Detection Model
      - Initialize multi-label classifier
      - Prepare TF-IDF text features and 15 numeric features
      - Fit MultiLabelBinarizer for 12 gap categories
      - Train model on cleaned data
      - Evaluate on train set (accuracy, Hamming loss)
      - Evaluate on eval set (accuracy, Hamming loss)
      - Save model artifacts to ml/model/:
         * gap_model.pkl
         * gap_vectorizer.pkl
         * gap_mlb.pkl
         * gap_scaler.pkl
         * gap_labels.json
      - Print training metrics

   Stage 5: Train Difficulty Prediction Model
      - Initialize multi-class classifier
      - Prepare 16 numeric + 3 categorical features
      - Fit LabelEncoder for 3 difficulty classes
      - Train model with 100 trees, max_depth=20
      - Evaluate on train set (accuracy)
      - Perform 5-fold cross-validation
      - Evaluate on eval set (accuracy, classification report)
      - Save model artifacts to ml/model/:
         * difficulty_model.pkl
         * difficulty_scaler.pkl
         * difficulty_label_encoder.pkl
         * difficulty_categorical_encoders.pkl
      - Print training metrics

   Completion:
      - Print "TRAINING PIPELINE COMPLETE!"
      - Print model save directory
      - Print cleaned data directory
      - Print final results JSON

Duration: 2-5 minutes depending on dataset size and CPU

Expected Output:
   ======================================================================
   LEARNBUDDY ML TRAINING PIPELINE
   ======================================================================

   [STAGE 1] Loading datasets...
     ✓ Gap Detection - Train: 5000, Eval: 1000
     ✓ Difficulty Prediction - Train: 4500, Eval: 900

   [STAGE 2] Cleaning gap detection data...
     ✓ Gap data cleaned
       - Original: 5000, Cleaned: 4850
       - Duplicates removed: 150

   [STAGE 3] Cleaning difficulty prediction data...
     ✓ Difficulty data cleaned
       - Original: 4500, Cleaned: 4450
       - Duplicates removed: 50

   [STAGE 4] Training multi-label gap detection model...
     ✓ Gap detection model trained
       - Train accuracy: 95.2%
       - Eval accuracy: 87.1%
       - Eval Hamming Loss: 0.0234

   [STAGE 5] Training multi-class difficulty prediction model...
     ✓ Difficulty prediction model trained
       - Train accuracy: 98.5%
       - Eval accuracy: 82.3%
       - CV score (5-fold): 85.7%

   ======================================================================
   TRAINING PIPELINE COMPLETE!
   ======================================================================

   Models saved to: ml/model
   Cleaned data saved to: data/processed

OPTION B: TRAIN INDIVIDUAL MODELS

Train gap detection only:
   python -m ml.train_model.train_gap_model

Train difficulty prediction only:
   python -m ml.train_model.train_difficulty_model


8.4 APPLICATION STARTUP COMMANDS
---------------------------------

STREAMLIT WEB APPLICATION (PRIMARY INTERFACE)

Command:
   streamlit run main.py

Execution Flow:
   1. Streamlit server starts on http://localhost:8501
   2. Browser opens automatically
   3. Application loads session state
   4. Sidebar displays learner profile selector
   5. Main page displays workflow steps
   6. Ready for user interaction

Console Output:
   You can now view your Streamlit app in your browser.

   Local URL: http://localhost:8501
   Network URL: http://192.168.1.100:8501

Duration: 2-3 seconds to start

PROGRAMMATIC API (PYTHON SCRIPT)

Command:
   python

Interactive Session:
   >>> from graph import run_microplan_from_file
   >>> result = run_microplan_from_file("data/input/learner_profiles/learn_001.json")
   >>> print(result["identified_gaps"])
   >>> print(result["recommended_difficulty"])
   >>> print(result["quality_metrics"])

Or create script:
   # my_script.py
   from graph import run_microplan
   import json

   with open("data/input/learner_profiles/learn_001.json") as f:
       learner = json.load(f)

   result = run_microplan(learner)

   print("Gaps:", result["identified_gaps"])
   print("Difficulty:", result["recommended_difficulty"])
   print("Output:", result["output_dir"])

Run script:
   python my_script.py


8.5 COMPLETE EXECUTION PATH FROM START TO FINISH
-------------------------------------------------

END-TO-END WORKFLOW EXECUTION

When user clicks "Generate Personalized Learning Plan":

PHASE 1: INITIALIZATION (0-10 percent)
   Step 1: Load learner JSON from session state
   Step 2: Build LangGraph workflow via build_workflow
   Step 3: Initialize state via get_initial_state
   Step 4: Print workflow header
   Duration: 0.1 seconds

PHASE 2: PARSING AND ANALYSIS (10-20 percent)
   Node: form_parser_node

   Step 1: Initialize ProfileParserAgent
   Step 2: Validate 7 required fields
   Step 3: Check field types and data ranges
   Step 4: Normalize strings to lowercase
   Step 5: Generate validation errors if any
   Step 6: Initialize ProfileAnalyzerAgent
   Step 7: Extract demographics (age, country, education)
   Step 8: Extract learning characteristics (style, pace, formats)
   Step 9: Extract proficiency (domain, topic, scores)
   Step 10: Analyze goals (clarity, alignment)
   Step 11: Analyze constraints (time pressure, budget)
   Step 12: Analyze learning history (completion rates, trends)
   Step 13: Pre-calculate gap detection ML features (15 numeric + text)
   Step 14: Pre-calculate difficulty prediction ML features (16 numeric + 8 categorical)
   Step 15: Return analyzed_profile with 40+ metrics

   Duration: 0.2-0.5 seconds

PHASE 3: PARALLEL ML ANALYSIS (20-50 percent)
   Parallel Execution of Two Nodes:

   Node A: proficiency_assessment_ml_node
      Step 1: Load gap detection model artifacts
      Step 2: Extract pre-calculated ML features from analyzed_profile
      Step 3: Transform text via TF-IDF vectorizer
      Step 4: Scale numeric features
      Step 5: Horizontally stack features
      Step 6: Predict gaps via multi-label model
      Step 7: Get decision scores and convert to confidence via sigmoid
      Step 8: Extract predicted gap labels
      Step 9: Map gaps to confidence scores
      Step 10: Determine urgency level based on proficiency
      Step 11: Return identified_gaps, gap_confidence_scores, gap_urgency_level
      Duration: 0.5-1 seconds

   Node B: learning_readiness_ml_node
      Step 1: Load difficulty prediction model artifacts
      Step 2: Extract pre-calculated ML features from analyzed_profile
      Step 3: Scale numeric features
      Step 4: Encode categorical featuress
      Step 5: Horizontally stack features
      Step 6: Predict difficulty via multi-class classifier
      Step 7: Get probabilities and extract max as confidence
      Step 8: Decode prediction via LabelEncoder
      Step 9: Generate readiness assessment text
      Step 10: Return recommended_difficulty, difficulty_confidence,
               learning_readiness_assessment
      Duration: 0.3-0.7 seconds

   Total Duration: 0.5-1 seconds (parallel execution)

PHASE 4: PLAN GENERATION (50-70 percent)
   Node: learning_path_generator_node

   Step 1: Extract analyzed profile, gaps, difficulty from state
   Step 2: Initialize LearnerLLMClient with API key rotation
   Step 3: Generate Plan A (Conservative):
      a. Build prompt with 1.5x timeline, 8 hrs/week, prerequisites required
      b. Call Gemini API with temp 0.3, max_tokens 2000
      c. Extract JSON from response (8 required fields)
      d. Validate structure
   Step 4: Generate Plan B (Standard):
      a. Build prompt with 1x timeline, 10 hrs/week, prerequisites required
      b. Call Gemini API
      c. Extract and validate JSON
   Step 5: Generate Plan C (Aggressive):
      a. Build prompt with 0.7x timeline, 15 hrs/week, prerequisites optional
      b. Call Gemini API
      c. Extract and validate JSON
   Step 6: Return plan_variant_a/b/c

   Duration: 5-10 seconds (3 LLM calls)

PHASE 5: VALIDATION (70-80 percent)
   Node: path_validator_node

   Step 1: Extract plan variants and analyzed profile
   Step 2: Initialize LearnerLLMClient
   Step 3: Build validation prompt with learner constraints and plan summaries
   Step 4: Call Gemini API to validate feasibility
   Step 5: Extract critical_issues list from JSON response
   Step 6: Return plan_variant_a/b/c_validated (unchanged), validation_issues

   Duration: 2-4 seconds (1 LLM call)

PHASE 6: PERSONALIZATION (80-90 percent)
   Node: personal_coach_node

   Step 1: Extract validated plans and analyzed profile
   Step 2: Determine coaching tone based on age, learning style, motivation
   Step 3: Initialize LearnerLLMClient
   Step 4: Rewrite Plan A:
      a. Build prompt with learner info, tone, plan summary
      b. Request 2-3 paragraph coaching message
      c. Call Gemini API with temp 0.5, max_tokens 500
      d. Return markdown text
   Step 5: Rewrite Plan B (same process)
   Step 6: Rewrite Plan C (same process)
   Step 7: Return variant_a/b/c_friendly

   Duration: 4-8 seconds (3 LLM calls)

PHASE 7: REPORT GENERATION (90-100 percent)
   Node: report_generator_node

   Step 1: Extract learner_id and analyzed profile
   Step 2: Create output directory (output/{learner_id}/)
   Step 3: Calculate quality metrics (6 dimensions)
   Step 4: Generate markdown report via format_microplan_report
   Step 5: Save markdown to micro_plan_report.txt
   Step 6: Generate JSON report via _generate_json_report
   Step 7: Save JSON to micro_plan.json
   Step 8: Save quality metrics to evaluation_metrics.json
   Step 9: Return final_report, report_json, quality_metrics, saved_path,
           output_dir

   Duration: 0.5-1 seconds

PHASE 8: COMPLETION
   Step 1: Print "WORKFLOW COMPLETE!"
   Step 2: Return final state to Streamlit
   Step 3: Update session state with analysis_result
   Step 4: Display success message
   Step 5: Render results tabs

   Duration: 0.1 seconds

TOTAL DURATION: 12-25 seconds
   - Parsing and Analysis: 0.5 seconds
   - ML Analysis: 1 second
   - Plan Generation: 8 seconds
   - Validation: 3 seconds
   - Personalization: 6 seconds
   - Report Generation: 1 second
   - Overhead: 0.5 seconds

Bottlenecks:
   - LLM API calls (plan generation, validation, personalization) account for
     70 percent of execution time
   - Network latency affects LLM response times
   - API key rotation on quota adds 1-2 seconds if needed

Optimizations:
   - Parallel ML analysis reduces time by 50 percent vs sequential
   - API key rotation prevents workflow failures on quota limits
   - Pre-calculated ML features eliminate redundant computation


================================================================================
                     9. EXPECTED OUTPUT AND RESULTS
================================================================================

9.1 OUTPUT FORMAT (JSON, MARKDOWN, ETC.)
-----------------------------------------

The LearnBuddy system generates outputs in THREE formats:

FORMAT 1: MARKDOWN TEXT REPORT (micro_plan_report.txt)

Structure:
   - Header with system branding
   - Learner Information section
   - Goal section
   - Current Proficiency section
   - Analysis Results section (gaps, urgency, difficulty)
   - Personalized Micro-Learning Plans section
      * Plan Variant A with coach notes
      * Plan Variant B with coach notes
      * Plan Variant C with coach notes
   - Quality Metrics section
   - Validation Results section
   - Recommendations for Success
   - Disclaimer
   - Footer with timestamp and system info

Purpose: Human-readable comprehensive report for learner review
File Size: Typically 3-8 KB
Line Count: 300-500 lines
Encoding: UTF-8 text

FORMAT 2: STRUCTURED JSON REPORT (micro_plan.json)

Structure:
   {
     "metadata": {
       "generated_at": "ISO 8601 timestamp",
       "version": "2.0",
       "system": "LearnBuddy Micro v2.0"
     },
     "learner_profile": {
       "learner_id": "string",
       "age": integer,
       "education_level": "string",
       "learning_style": "string",
       "domain": "string",
       "proficiency_score": integer,
       "hours_per_week": integer,
       "goal_timeline": integer
     },
     "analysis": {
       "gaps": ["gap1", "gap2", ...],
       "urgency": "string",
       "recommended_difficulty": "string",
       "difficulty_confidence": float,
       "learning_readiness": "string"
     },
     "learning_plans": {
       "conservative": {plan_dict},
       "standard": {plan_dict},
       "aggressive": {plan_dict}
     },
     "personalized_coaching": {
       "conservative_coaching": "string",
       "standard_coaching": "string",
       "aggressive_coaching": "string"
     },
     "validation": {
       "issues": ["issue1", "issue2", ...],
       "all_plans_validated": boolean
     },
     "quality_metrics": {
       "profile_completeness": float,
       "gap_detection_accuracy": float,
       "difficulty_confidence": float,
       "plan_feasibility": float,
       "coaching_adaptation": float,
       "report_completeness": float,
       "overall_quality": float
     },
     "recommendations": {
       "next_steps": ["step1", "step2", ...],
       "success_factors": ["factor1", "factor2", ...]
     }
   }

Purpose: Machine-readable structured data for programmatic access
File Size: Typically 8-15 KB
Indent: 2 spaces
Encoding: UTF-8

FORMAT 3: EVALUATION METRICS JSON (evaluation_metrics.json)

Structure:
   {
     "profile_completeness": 0.95,
     "gap_detection_accuracy": 0.83,
     "difficulty_confidence": 0.87,
     "plan_feasibility": 0.85,
     "coaching_adaptation": 0.90,
     "report_completeness": 1.0,
     "overall_quality": 0.90
   }

Purpose: Quality assessment scores for monitoring and analysis
File Size: Typically 200-400 bytes
Indent: 2 spaces
Encoding: UTF-8


9.2 SAMPLE OUTPUT STRUCTURE
----------------------------

LEARNER PROFILE INPUT (learn_001.json):

{
  "learner_id": "LEARN_001",
  "personal_info": {
    "name": "Alex Kumar",
    "age": 16,
    "country": "India"
  },
  "educational_background": {
    "highest_qualification": "secondary",
    "gpa_cgpa": 2.54
  },
  "learning_profile": {
    "learning_style": "visual",
    "learning_pace": "fast",
    "focus_duration_minutes": 30
  },
  "current_status": {
    "primary_domain": "Programming",
    "current_proficiency": {
      "self_assessed_score": 85,
      "standardized_test_score": 76
    },
    "challenges_faced": ["Motivation", "Advanced concepts", "Time management"]
  },
  "learning_goals": {
    "primary_goal": "Master Programming for Software Engineer",
    "target_timeline_months": 12,
    "career_aspiration": "Software Engineer"
  },
  "constraints": {
    "hours_available_per_week": 15,
    "budget_limit_usd": 100,
    "employment_status": "employed"
  }
}

EXPECTED ANALYSIS OUTPUT:

Identified Gaps:
   - advanced_concepts (85 percent confidence)
   - time_management (78 percent confidence)
   - motivation_strategies (72 percent confidence)

Gap Urgency Level: MEDIUM

Recommended Difficulty: Intermediate

Difficulty Confidence: 87.3 percent

Learning Readiness Assessment:
   "Based on proficiency (85/100), time availability (15h/week), and goal
   clarity (80/100), your learning readiness is High. The Intermediate
   difficulty level is recommended with 87 percent confidence. You should
   be able to progress steadily with this path."

EXPECTED PLAN VARIANT A (CONSERVATIVE):

Duration: 18 weeks
Hours per week: 8 hours
Intensity: LOW (foundation building)

Topics (11 total):
   - Foundational Programming Principles
   - Object-Oriented Programming Basics
   - Data Structures Fundamentals
   - Algorithm Analysis Introduction
   - Design Patterns Overview
   - Software Development Lifecycle
   - Version Control with Git
   - Testing and Debugging Strategies
   - Code Optimization Basics
   - Clean Code Principles
   - Practical Project: Build Console Application

Resources (7 total):
   - Online Course: CS50 Introduction to Computer Science (Free)
   - Book: Clean Code by Robert Martin
   - Interactive Platform: Codecademy Python Track
   - Video Series: freeCodeCamp YouTube Channel
   - Practice Platform: HackerRank Easy Problems
   - Documentation: Official Python Documentation
   - Community: Stack Overflow for Programming Questions

Milestones (6 total):
   - Week 3: Complete foundational programming concepts
   - Week 6: Build first OOP project (task manager)
   - Week 9: Implement data structures (linked list, stack, queue)
   - Week 12: Complete algorithm analysis module with 10 practice problems
   - Week 15: Develop design patterns project (factory, observer)
   - Week 18: Deliver final console application with tests

Prerequisites:
   - Basic computer literacy
   - Understanding of variables and control flow
   - Ability to install software and use terminal
   - Access to computer with internet connection

Success Criteria:
   - Complete all 11 topic modules with quizzes
   - Build 3 projects demonstrating OOP and design patterns
   - Solve 50+ coding problems on practice platform
   - Write unit tests for final project with 80 percent coverage
   - Document code with clear comments and README

EXPECTED COACH NOTES (CONSERVATIVE):

"Hey Alex! I'm really excited to be your coach on this programming journey.
You've got a strong foundation with your 85/100 proficiency score, and I can
see you're motivated to reach that Software Engineer goal. This conservative
plan gives you 18 weeks to really solidify the fundamentals, working at a
comfortable 8 hours per week.

Think of this as building a house - we're starting with a rock-solid foundation
before we add the fancy features. Your visual learning style will love the
video tutorials and diagrams we've included. By week 6, you'll have your first
working project to show off!

Remember, consistency beats intensity every time. Those 8 hours per week, spread
across your preferred study times, will get you further than cramming. You've
got this!"

EXPECTED PLAN VARIANT B (STANDARD):

Duration: 12 weeks
Hours per week: 10 hours
Intensity: MEDIUM (balanced)

Topics: Similar to Plan A but condensed timeline
Resources: Same mix of free and premium resources
Milestones: Faster progression with 2-week intervals
Prerequisites: Same as Plan A
Success Criteria: Higher problem-solving volume (75+ problems)

EXPECTED PLAN VARIANT C (AGGRESSIVE):

Duration: 8 weeks
Hours per week: 15 hours
Intensity: HIGH (intensive)

Topics: Fast-paced with combined modules
Resources: Premium courses and bootcamp-style resources
Milestones: Weekly checkpoints with daily tasks
Prerequisites: Strong prerequisite knowledge recommended
Success Criteria: Intensive project delivery (5 projects in 8 weeks)


9.3 KEY METRICS AND FIELDS IN OUTPUT
-------------------------------------

LEARNER PROFILE METRICS (8 fields):

1. learner_id (string)
   - Unique identifier for learner
   - Example: "LEARN_001", "learner_002"
   - Used for file naming and tracking

2. age (integer)
   - Learner age in years
   - Range: 8-100
   - Affects coaching tone and difficulty recommendations

3. education_level (string)
   - Highest educational qualification
   - Values: "primary", "secondary", "bachelor", "master", "phd"
   - Influences prerequisite assumptions

4. learning_style (string)
   - Preferred learning modality
   - Values: "visual", "auditory", "kinesthetic", "reading_writing", "mixed"
   - Determines coaching tone and resource recommendations

5. domain (string)
   - Primary subject area
   - Examples: "Programming", "Data Science", "UX Design", "Marketing"
   - Used for gap detection and resource selection

6. proficiency_score (integer)
   - Self-assessed skill level
   - Range: 0-100
   - Drives difficulty prediction and urgency calculation

7. hours_per_week (integer)
   - Available study time
   - Range: 0-168
   - Determines plan duration and pacing

8. goal_timeline (integer)
   - Target completion timeline in months
   - Range: 1-60
   - Affects plan variant timeline calculations

ANALYSIS METRICS (5 fields):

1. gaps (list of strings)
   - Identified learning gaps from ML model
   - Possible values (12 gap categories):
     * prerequisite_foundation
     * advanced_concepts
     * practical_application
     * time_management
     * motivation_strategies
     * resource_access
     * assessment_skills
     * study_techniques
     * peer_collaboration
     * career_planning
     * technical_tools
     * domain_knowledge
   - Used to prioritize learning objectives

2. urgency (string)
   - Priority level for addressing gaps
   - Values: "critical", "high", "medium", "low"
   - Calculation:
     * critical: proficiency < 30
     * high: proficiency < 50 OR has prerequisite_foundation gap
     * medium: proficiency < 70
     * low: else

3. recommended_difficulty (string)
   - Optimal difficulty level from ML model
   - Values: "Beginner", "Intermediate", "Advanced"
   - Determines topic complexity and pacing

4. difficulty_confidence (float)
   - ML model confidence score
   - Range: 0.0-1.0
   - Higher values indicate stronger recommendation

5. learning_readiness (string)
   - Qualitative assessment text
   - Length: 2-3 sentences
   - Includes proficiency, hours, goal clarity, readiness level

LEARNING PLAN METRICS (per variant - 8 fields):

1. duration_weeks (integer)
   - Total plan duration
   - Conservative: target_timeline * 1.5
   - Standard: target_timeline * 1.0
   - Aggressive: target_timeline * 0.7

2. hours_per_week (integer)
   - Recommended weekly commitment
   - Conservative: 8 hours
   - Standard: 10 hours
   - Aggressive: 15 hours

3. intensity (string)
   - Plan pacing descriptor
   - Values: "low", "medium", "high"

4. topics (list of strings)
   - Learning topics to cover
   - Count: Typically 8-15 topics
   - Ordered by difficulty progression

5. resources (list of strings)
   - Recommended learning resources
   - Count: Typically 5-10 resources
   - Mix of free and paid, books, courses, platforms

6. milestones (list of strings)
   - Progress checkpoints
   - Count: Typically 4-8 milestones
   - Format: "Week X: Achievement description"

7. prerequisites (list of strings)
   - Required prior knowledge
   - Count: Typically 3-6 prerequisites
   - Used to assess learner readiness

8. success_criteria (list of strings)
   - Measurable completion criteria
   - Count: Typically 4-6 criteria
   - Defines what "finished" looks like

QUALITY METRICS (7 fields):

1. profile_completeness (float)
   - Profile data quality score
   - Range: 0.0-1.0
   - Calculation: 0.95 if profile_complete, else 0.0

2. gap_detection_accuracy (float)
   - Gap identification quality
   - Range: 0.0-1.0
   - Calculation: min(1.0, len(identified_gaps) / 12.0)

3. difficulty_confidence (float)
   - ML model confidence
   - Range: 0.0-1.0
   - Direct from DifficultyPredictionMLAgent

4. plan_feasibility (float)
   - Plan viability score
   - Range: 0.0-1.0
   - Calculation: 0.85 if validated without issues, else 0.65

5. coaching_adaptation (float)
   - Personalization quality
   - Range: 0.0-1.0
   - Calculation: 0.90 if rewriting_complete, else 0.0

6. report_completeness (float)
   - Report generation success
   - Range: 0.0-1.0
   - Calculation: 1.0 if report_complete, else 0.0

7. overall_quality (float)
   - Average of all 6 metrics
   - Range: 0.0-1.0
   - Target: >0.80 for production-ready output

VALIDATION METRICS (2 fields):

1. issues (list of strings)
   - Validation warnings or errors
   - Count: 0-10 typically
   - Examples:
     * "Plan C hours (15/week) exceeds availability (10/week)"
     * "Timeline compressed too aggressively in Plan C"
     * "Prerequisites may be challenging for current proficiency level"

2. all_plans_validated (boolean)
   - Overall validation status
   - True: All plans passed validation
   - False: Issues found in one or more plans


9.4 REPORT GENERATION DETAILS
------------------------------

REPORT GENERATION PROCESS:

Step 1: Calculate Quality Metrics
   - Evaluate 6 quality dimensions
   - Compute overall_quality as average
   - Store in quality_metrics dict

Step 2: Generate Markdown Report
   Function: format_microplan_report(state)

   Sections Generated:

   A. Header Section
      - ASCII art title: "LEARNBUDDY MICRO - LEARNING PLAN"
      - Subtitle: "Personalized Plan Report"

   B. Learner Information
      - Name from personal_info.name
      - Learner ID from state.learner_id
      - Age from personal_info.age
      - Education from educational_background.highest_qualification
      - Learning Style from learning_profile.learning_style
      - Primary Domain from current_status.primary_domain

   C. Goal
      - Primary Goal from learning_goals.primary_goal
      - Timeline from learning_goals.target_timeline_months
      - Desired Outcome from learning_goals.desired_outcome

   D. Current Proficiency
      - Score from current_status.current_proficiency.self_assessed_score
      - Topic from current_status.current_proficiency.topic

   E. Analysis Results
      - Identified Learning Gaps as bullet list
      - Gap Urgency Level in uppercase
      - Recommended Difficulty Level with confidence percentage
      - Constraints (hours per week, budget, certification need)

   F. Personalized Micro-Learning Plans
      For each variant (A, B, C):
         - Variant header with description
         - Duration and estimated hours
         - Topics to Cover (bullet list)
         - Learning Resources (bullet list)
         - Milestones (bullet list)
         - Prerequisites (bullet list)
         - Difficulty Progression (paragraph)
         - Success Criteria (bullet list)
         - Coach Notes (personalized text)

   G. Quality Metrics
      - All 6 metrics with percentages
      - Overall quality score

   H. Validation Results
      - Status (PASSED or WARNINGS)
      - List of issues if any

   I. Recommendations for Success
      - 7 actionable recommendations
      - Generic best practices for all learners

   J. Disclaimer
      - Educational use notice
      - AI-generated guidance disclaimer
      - Adaptation recommendation
      - Consult professionals notice

   K. Footer
      - Generated timestamp
      - System version

Step 3: Generate JSON Report
   Function: _generate_json_report(state, quality_metrics)

   Sections Built:

   A. Metadata
      - generated_at: ISO 8601 timestamp
      - version: "2.0"
      - system: "LearnBuddy Micro v2.0"

   B. Learner Profile
      - Extract 8 key metrics via extract_learner_metrics
      - Include ID, demographics, proficiency, constraints, goals

   C. Analysis
      - gaps: List of identified gaps
      - urgency: Urgency level string
      - recommended_difficulty: Difficulty level string
      - difficulty_confidence: Confidence float
      - learning_readiness: Readiness assessment text

   D. Learning Plans
      - conservative: plan_variant_a_validated dict
      - standard: plan_variant_b_validated dict
      - aggressive: plan_variant_c_validated dict

   E. Personalized Coaching
      - conservative_coaching: variant_a_friendly text
      - standard_coaching: variant_b_friendly text
      - aggressive_coaching: variant_c_friendly text

   F. Validation
      - issues: List of validation issues
      - all_plans_validated: Boolean completion flag

   G. Quality Metrics
      - All 7 quality scores (6 dimensions + overall)

   H. Recommendations
      - next_steps: 5 actionable next steps
      - success_factors: 5 success principles

Step 4: Save Files
   Directory: output/{learner_id}/

   Files Created:
   1. micro_plan_report.txt (markdown format)
   2. micro_plan.json (structured JSON)
   3. evaluation_metrics.json (quality scores only)

Step 5: Return Results
   State Updates:
   - final_report: Markdown text
   - report_json: JSON dict
   - quality_metrics: Quality scores dict
   - saved_path: Path to markdown file
   - output_dir: Directory path
   - report_complete: True

FILE NAMING CONVENTIONS:

Pattern: {output_dir}/{learner_id}/{file_name}

Examples:
   - output/LEARN_001/micro_plan_report.txt
   - output/learner_002/micro_plan.json
   - output/alex_kumar/evaluation_metrics.json

Directory Creation:
   - Automatic via create_output_directory(learner_id)
   - Creates parent directories if needed
   - Ensures no file path conflicts

FILE PERMISSIONS:
   - Read/write for owner
   - Standard file system permissions
   - No special security requirements

ERROR HANDLING:

Scenario 1: File Write Failure
   - Catch exception in save_file function
   - Print error message with file path
   - Return False status
   - Set error_occurred flag in state
   - Continue workflow (non-fatal)

Scenario 2: Directory Creation Failure
   - Catch exception in create_output_directory
   - Print error message
   - Raise exception to halt workflow
   - Return error state to user

Scenario 3: Report Generation Failure
   - Catch exception in report_generator_node
   - Return empty reports
   - Set report_complete to False
   - Log error in error_messages

REPORT QUALITY VALIDATION:

Pre-Save Checks:
   1. Verify final_report is not empty
   2. Verify report_json is valid dict
   3. Verify quality_metrics has 7 fields
   4. Verify all plan variants present

Post-Save Verification:
   1. Check files exist at saved_path
   2. Verify file sizes > 0 bytes
   3. Confirm JSON is valid via json.loads
   4. Print success message with paths

Typical File Sizes:
   - micro_plan_report.txt: 5-10 KB
   - micro_plan.json: 10-20 KB
   - evaluation_metrics.json: 300-500 bytes


================================================================================
                              10. CONCLUSION
================================================================================

This comprehensive documentation covers the complete LearnBuddy project
architecture, including:

   - Problem statement and business context
   - Complete file structure and directory hierarchy
   - Purpose and responsibilities of all modules
   - Detailed class structures with all methods
   - Function signatures with logic explanations
   - Full coverage of agents, nodes, ML, utils, and workflow modules
   - Streamlit UI design and user interaction flow
   - Running commands and complete execution flow
   - Expected output formats and report generation

The LearnBuddy system represents a production-ready AI-powered personalized
learning plan generator that combines machine learning models, large language
models, and workflow orchestration to deliver customized educational guidance
at scale.

Key System Capabilities:
   - Automated learner profile analysis with 40+ derived metrics
   - ML-based gap detection (12 categories) with confidence scores
   - ML-based difficulty prediction (3 levels) with 80+ percent accuracy
   - LLM-generated learning plans with 3 variants per learner
   - Adaptive coaching personalization based on learning style and age
   - Comprehensive reporting in both human and machine-readable formats
   - Quality assessment across 6 dimensions with overall scoring

The system is designed for scalability, maintainability, and continuous
improvement through ML model retraining and API integration with educational
platforms.

For technical support, integration questions, or feature requests, please
refer to the codebase documentation and inline comments.

================================================================================
                          END OF DOCUMENTATION
================================================================================
