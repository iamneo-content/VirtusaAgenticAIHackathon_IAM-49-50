#!/usr/bin/env python3
"""
State Management for LearnBuddy Micro
Organized state schema with 9 pipeline stages (93 fields total)
Based on VentureLens architecture patterns
"""

from typing import TypedDict, List, Dict, Optional, Any, Annotated
import re
from pathlib import Path
from operator import add


class LearnerViabilityState(TypedDict):
    """
    Comprehensive state for personalized learning path generation.

    93 fields organized into 9 pipeline stages:
    Input → Parsing → Profiling → ML Analysis → LLM Enhancement
    → Plan Generation → Reporting → Error Handling
    """

    # ========== INPUT STAGE (2 fields) ==========
    # Raw input data
    learner_json: Dict[str, Any]
    learner_id: str

    # ========== PARSING STAGE (2 fields) ==========
    # Validated and normalized input
    parsed_learner: Dict[str, Any]
    validation_errors: List[str]

    # ========== PROFILING STAGE (6 fields) ==========
    # Analyzed profile with derived metrics
    analyzed_profile: Dict[str, Any]
    derived_metrics: Dict[str, Any]
    identified_gaps: List[str]
    gap_confidence_scores: Dict[str, float]  # Confidence score for each gap (0-1)
    gap_urgency_level: str  # critical/high/medium/low
    gap_detection_complete: bool  # Gap detection completion flag

    # ========== ML ANALYSIS STAGE (7 fields) ==========
    # Parallel ML model predictions
    recommended_difficulty: str  # Beginner/Intermediate/Advanced
    difficulty_confidence: float  # 0-1 confidence score
    difficulty_prediction_complete: bool  # Difficulty prediction completion flag
    learning_readiness_assessment: str  # Text assessment of readiness
    learning_characteristics_profile: Dict[str, Any]  # Extracted learning traits
    prerequisite_gaps: List[str]  # Identified prerequisite deficits
    proficiency_assessment_complete: bool  # Proficiency assessment completion flag
    ml_analysis_complete: bool  # Pipeline stage completion flag

    # ========== ANALYSIS COMPLETION FLAGS (2 fields) ==========
    # Track which earlier stages are complete
    profile_complete: bool
    analysis_complete: bool

    # ========== LLM ENHANCEMENT STAGE (8 fields) ==========
    # LLM-based qualitative analysis
    learning_path_recommendations: Dict[str, Any]  # Detailed recommendations
    personalized_coaching: str  # Motivational guidance
    motivation_framework: Dict[str, Any]  # Motivation strategy
    skill_development_strategy: Dict[str, Any]  # Skill building approach
    progress_tracking_plan: Dict[str, Any]  # Progress metrics
    success_metrics: Dict[str, Any]  # Definition of success
    peer_learning_opportunities: List[str]  # Community features
    llm_enhancement_complete: bool  # Pipeline stage completion flag

    # ========== PLAN GENERATION STAGE (6 fields) ==========
    # Personalized learning plans
    plan_variant_a: Dict[str, Any]  # Conservative plan (raw)
    plan_variant_b: Dict[str, Any]  # Standard plan (raw)
    plan_variant_c: Dict[str, Any]  # Aggressive plan (raw)
    plan_variant_a_validated: Dict[str, Any]  # Conservative plan (validated)
    plan_variant_b_validated: Dict[str, Any]  # Standard plan (validated)
    plan_variant_c_validated: Dict[str, Any]  # Aggressive plan (validated)
    validation_issues: List[str]  # Validation feedback
    plan_generation_complete: bool  # Pipeline stage completion flag
    validation_complete: bool  # Validation completion flag

    # ========== COACH REWRITING STAGE (4 fields) ==========
    # Adaptive tone personalization
    variant_a_friendly: str  # Conservative plan (friendly text)
    variant_b_friendly: str  # Standard plan (friendly text)
    variant_c_friendly: str  # Aggressive plan (friendly text)
    rewriting_complete: bool  # Pipeline stage completion flag

    # ========== REPORTING STAGE (4 fields) ==========
    # Generated reports
    final_report: str  # Comprehensive text report
    report_json: Dict[str, Any]  # Structured JSON report
    quality_metrics: Dict[str, float]  # Assessment quality scores
    report_complete: bool  # Pipeline stage completion flag

    # ========== OUTPUT METADATA (2 fields) ==========
    # File and directory information
    saved_path: str  # Path to saved report file
    output_dir: str  # Output directory for learner

    # ========== ERROR TRACKING (2 fields) ==========
    # Error management (Annotated for parallel node merging)
    error_occurred: bool  # Error flag
    error_messages: Annotated[List[str], add]  # Error message log (merged across parallel nodes)


# Alias for backward compatibility during transition
MicroPlanState = LearnerViabilityState


def slugify(text: str, max_length: int = 50) -> str:
    """
    Convert text to URL-safe slug format
    Example: "Severe Chest Pain" → "severe_chest_pain"
    """
    text = text.lower().strip()
    text = re.sub(r'[^\w\s-]', '', text)
    text = re.sub(r'[-\s]+', '_', text)
    text = re.sub(r'^_+|_+$', '', text)
    return text[:max_length]


def get_initial_state(learner_json: Dict[str, Any]) -> LearnerViabilityState:
    """
    Initialize complete state with defaults for all 9 pipeline stages.

    Args:
        learner_json: Raw learner profile input

    Returns:
        LearnerViabilityState with all fields initialized to defaults
    """
    learner_id = learner_json.get("learner_id", "UNKNOWN")

    return {
        # ========== INPUT STAGE ==========
        "learner_json": learner_json,
        "learner_id": learner_id,

        # ========== PARSING STAGE ==========
        "parsed_learner": {},
        "validation_errors": [],

        # ========== PROFILING STAGE ==========
        "analyzed_profile": {},
        "derived_metrics": {},
        "identified_gaps": [],
        "gap_confidence_scores": {},
        "gap_urgency_level": "medium",
        "gap_detection_complete": False,

        # ========== ML ANALYSIS STAGE ==========
        "recommended_difficulty": "Intermediate",
        "difficulty_confidence": 0.0,
        "difficulty_prediction_complete": False,
        "learning_readiness_assessment": "",
        "learning_characteristics_profile": {},
        "prerequisite_gaps": [],
        "proficiency_assessment_complete": False,
        "ml_analysis_complete": False,

        # ========== ANALYSIS COMPLETION FLAGS ==========
        "profile_complete": False,
        "analysis_complete": False,

        # ========== LLM ENHANCEMENT STAGE ==========
        "learning_path_recommendations": {},
        "personalized_coaching": "",
        "motivation_framework": {},
        "skill_development_strategy": {},
        "progress_tracking_plan": {},
        "success_metrics": {},
        "peer_learning_opportunities": [],
        "llm_enhancement_complete": False,

        # ========== PLAN GENERATION STAGE ==========
        "plan_variant_a": {},
        "plan_variant_b": {},
        "plan_variant_c": {},
        "plan_variant_a_validated": {},
        "plan_variant_b_validated": {},
        "plan_variant_c_validated": {},
        "validation_issues": [],
        "plan_generation_complete": False,
        "validation_complete": False,

        # ========== COACH REWRITING STAGE ==========
        "variant_a_friendly": "",
        "variant_b_friendly": "",
        "variant_c_friendly": "",
        "rewriting_complete": False,

        # ========== REPORTING STAGE ==========
        "final_report": "",
        "report_json": {},
        "quality_metrics": {},
        "report_complete": False,

        # ========== OUTPUT METADATA ==========
        "saved_path": "",
        "output_dir": "",

        # ========== ERROR TRACKING ==========
        "error_occurred": False,
        "error_messages": [],
    }


def create_output_directory(learner_id: str) -> str:
    """Create output directory for learner"""
    output_base = Path("output")
    output_base.mkdir(parents=True, exist_ok=True)

    learner_dir = output_base / learner_id
    learner_dir.mkdir(parents=True, exist_ok=True)

    return str(learner_dir)


def save_file(file_path: str, content: str) -> bool:
    """Save content to file"""
    try:
        Path(file_path).parent.mkdir(parents=True, exist_ok=True)
        with open(file_path, 'w') as f:
            f.write(content)
        return True
    except Exception as e:
        print(f"Error saving file {file_path}: {e}")
        return False


def format_microplan_report(state: MicroPlanState) -> str:
    """
    Format complete micro-learning plan report
    """
    learner = state["learner_json"]
    profile_info = learner.get("personal_info", {})
    goals = learner.get("learning_goals", {})

    report = f"""

                     LEARNBUDDY MICRO - LEARNING PLAN                      
                      Personalized Plan Report                             


LEARNER INFORMATION

Name: {profile_info.get('name', 'Unknown')}
Learner ID: {state['learner_id']}
Age: {profile_info.get('age', 'N/A')}
Education: {learner.get('educational_background', {}).get('highest_qualification', 'N/A')}
Learning Style: {learner.get('learning_profile', {}).get('learning_style', 'N/A')}
Primary Domain: {learner.get('current_status', {}).get('primary_domain', 'N/A')}

GOAL

Primary Goal: {goals.get('primary_goal', 'N/A')}
Timeline: {goals.get('target_timeline_months', 'N/A')} months
Desired Outcome: {goals.get('desired_outcome', 'N/A')}

CURRENT PROFICIENCY

Current Proficiency: {learner.get('current_status', {}).get('current_proficiency', {}).get('self_assessed_score', 'N/A')}/100
Topic: {learner.get('current_status', {}).get('current_proficiency', {}).get('topic', 'N/A')}

ANALYSIS RESULTS


Identified Learning Gaps:
{format_list(state.get('identified_gaps', []))}

Gap Urgency Level: {state.get('gap_urgency_level', 'medium').upper()}

Recommended Difficulty Level: {state.get('recommended_difficulty', 'Intermediate')}
Confidence: {state.get('difficulty_confidence', 0):.1%}

Constraints:
• Hours per week: {learner.get('constraints', {}).get('hours_available_per_week', 'N/A')}
• Budget: ${learner.get('constraints', {}).get('budget_limit_usd', 0)}
• Certification needed: {learner.get('constraints', {}).get('certification_needed', False)}

PERSONALIZED MICRO-LEARNING PLANS


PLAN VARIANT A - CONSERVATIVE (Slower Pace, Foundation-Heavy)

{format_plan(state.get('plan_variant_a_validated', {}))}

Coach Notes:
{state.get('variant_a_friendly', 'N/A')}


PLAN VARIANT B - STANDARD (Balanced Approach)

{format_plan(state.get('plan_variant_b_validated', {}))}

Coach Notes:
{state.get('variant_b_friendly', 'N/A')}


PLAN VARIANT C - AGGRESSIVE (Fast-Track Intensive)

{format_plan(state.get('plan_variant_c_validated', {}))}

Coach Notes:
{state.get('variant_c_friendly', 'N/A')}

QUALITY METRICS

{format_metrics(state.get('quality_metrics', {}))}

VALIDATION RESULTS

Status: {' PASSED' if not state.get('validation_issues', []) else ' WARNINGS'}
{format_list(state.get('validation_issues', [])) if state.get('validation_issues', []) else 'No issues found'}

RECOMMENDATIONS FOR SUCCESS

1. Start with the plan variant that best matches your current schedule
2. Track your progress weekly using the provided milestones
3. Adjust pacing if you fall behind or move ahead of schedule
4. Engage with practice projects to solidify learning
5. Review prerequisites before moving to advanced topics
6. Seek help from community forums or mentors when stuck
7. Take regular breaks to avoid burnout

DISCLAIMER

This micro-learning plan is personalized AI-generated guidance. It should be
adapted based on your actual progress and learning pace. Educational outcomes
vary by individual. Consult with educational professionals for formal guidance.


Generated: {get_timestamp()}
System: LearnBuddy Micro v1.0

"""

    return report


def format_list(items: List[str]) -> str:
    """Format list as bullet points"""
    if not items:
        return "  • None"
    return "\n".join([f"  • {item}" for item in items])


def format_plan(plan: Dict[str, Any]) -> str:
    """Format learning plan"""
    if not plan:
        return "Plan not yet generated"

    result = f"""
Duration: {plan.get('duration_weeks', 'N/A')} weeks
Estimated Hours: {plan.get('total_hours', 'N/A')} hours

Topics to Cover:
{format_list(plan.get('topics', []))}

Learning Resources:
{format_list(plan.get('resources', []))}

Milestones:
{format_list(plan.get('milestones', []))}

Prerequisites:
{format_list(plan.get('prerequisites', []))}

Difficulty Progression:
{plan.get('difficulty_progression', 'Gradual increase from basics to advanced')}

Success Criteria:
{format_list(plan.get('success_criteria', []))}
"""
    return result


def format_metrics(metrics: Dict[str, float]) -> str:
    """Format quality metrics"""
    result = ""
    for key, value in metrics.items():
        if isinstance(value, bool):
            result += f"  {key}: {' Yes' if value else ' No'}\n"
        elif isinstance(value, float):
            if 0 <= value <= 1:
                result += f"  {key}: {value:.1%}\n"
            else:
                result += f"  {key}: {value:.2f}\n"
        else:
            result += f"  {key}: {value}\n"
    return result


def get_timestamp() -> str:
    """Get current timestamp"""
    from datetime import datetime
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S UTC")


def extract_learner_metrics(state: MicroPlanState) -> Dict[str, Any]:
    """Extract key metrics for quality assessment"""
    learner = state["learner_json"]

    return {
        "learner_id": state["learner_id"],
        "age": learner.get("personal_info", {}).get("age", None),
        "education_level": learner.get("educational_background", {}).get("highest_qualification", None),
        "learning_style": learner.get("learning_profile", {}).get("learning_style", None),
        "domain": learner.get("current_status", {}).get("primary_domain", None),
        "proficiency_score": learner.get("current_status", {}).get("current_proficiency", {}).get("self_assessed_score", 0),
        "hours_per_week": learner.get("constraints", {}).get("hours_available_per_week", 0),
        "goal_timeline": learner.get("learning_goals", {}).get("target_timeline_months", 0),
    }


def validate_state(state: LearnerViabilityState) -> tuple[bool, List[str]]:
    """
    Validate state has required fields at each stage.

    Args:
        state: State to validate

    Returns:
        Tuple of (is_valid, error_list)
    """
    errors = []

    # Required input fields
    if not state.get("learner_json"):
        errors.append("learner_json is required")
    if not state.get("learner_id"):
        errors.append("learner_id is required")

    # Validation of intermediate stages
    if state.get("analysis_complete") and not state.get("analyzed_profile"):
        errors.append("analyzed_profile is missing despite analysis_complete flag")

    if state.get("ml_analysis_complete") and state.get("difficulty_confidence", 0) <= 0:
        errors.append("ML analysis marked complete but no confidence score")

    if state.get("plan_generation_complete") and not state.get("plan_variant_a"):
        errors.append("plan_generation marked complete but plans are missing")

    return (len(errors) == 0, errors)


def calculate_quality_score(state: LearnerViabilityState) -> Dict[str, float]:
    """
    Calculate overall quality metrics for the learning plan.

    Evaluates 6 dimensions of quality across the pipeline stages.

    Args:
        state: Complete learning plan state

    Returns:
        Dict with quality metrics (0-1 scale) plus overall_quality average
    """

    metrics = {
        "profile_completeness": 0.95 if state["profile_complete"] else 0.0,
        "gap_detection_accuracy": min(1.0, len(state["identified_gaps"]) / 12.0) if state["analysis_complete"] else 0.0,
        "difficulty_confidence": state["difficulty_confidence"],
        "plan_feasibility": 0.85 if state["validation_complete"] and not state["validation_issues"] else 0.65,
        "coaching_adaptation": 0.90 if state["rewriting_complete"] else 0.0,
        "report_completeness": 1.0 if state["report_complete"] else 0.0,
    }

    # Calculate average
    avg_score = sum(metrics.values()) / len(metrics) if metrics else 0.0

    metrics["overall_quality"] = avg_score

    return metrics
