#!/usr/bin/env python3
"""
Centralized LLM Client for LearnBuddy
Manages Gemini API access with automatic key rotation and error handling
Based on VentureLens's GeniniLLMClient pattern
"""

from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Dict, Any, Optional

try:
    from dotenv import load_dotenv

    env_file = Path.cwd() / ".env"
    if env_file.exists():
        load_dotenv(env_file)
except ImportError:
    pass

try:
    from google import generativeai as genai
except ImportError:
    genai = None


# ========== HELPER FUNCTIONS ==========

def _get_all_api_keys() -> list:
    """
    Return all available Gemini API keys for rotation.
    Checks Streamlit secrets (GEMINI_API_KEY_1..4) then environment variables.

    Priority order:
    1. Streamlit secrets (if running in Streamlit)
    2. Environment variable GEMINI_API_KEY (single key)
    3. Environment variables GEMINI_API_KEY_1..4 (multiple keys)

    Returns:
        List of API keys, deduplicated
    """
    keys = []

    # Check Streamlit secrets first
    try:
        import streamlit as st

        for i in range(1, 5):
            try:
                key = st.secrets.get(f"GEMINI_API_KEY_{i}")
                if key:
                    keys.append(key)
            except Exception:
                pass
    except ImportError:
        pass

    # Check environment variables
    env_key = os.getenv("GEMINI_API_KEY")
    if env_key and env_key not in keys:
        keys.append(env_key)

    for i in range(1, 5):
        env_key_i = os.getenv(f"GEMINI_API_KEY_{i}")
        if env_key_i and env_key_i not in keys:
            keys.append(env_key_i)

    return keys


def _get_first_api_key() -> Optional[str]:
    """
    Return the first available Gemini API key.

    Returns:
        First API key from available keys, or None if no keys found
    """
    keys = _get_all_api_keys()
    return keys[0] if keys else None


def _clean_json_text(text: str) -> str:
    """
    Remove Markdown fences and surrounding whitespace from LLM response.
    Keeps content intact while making it easier to parse as JSON.

    Args:
        text: Raw LLM response text

    Returns:
        Cleaned text without markdown fences
    """
    cleaned = text.strip()
    cleaned = re.sub(r"```json\s*", "", cleaned, flags=re.IGNORECASE | re.MULTILINE)
    cleaned = re.sub(r"```", "", cleaned, flags=re.MULTILINE)
    return cleaned.strip()


def _strip_trailing_commas(text: str) -> str:
    """
    Remove trailing commas before closing braces/brackets.
    Repairs minor JSON formatting issues from LLM output.

    Example:
        Input: '{"field": "value",}'
        Output: '{"field": "value"}'

    Args:
        text: JSON text with potential trailing commas

    Returns:
        JSON text with trailing commas removed
    """
    previous = None
    current = text
    while current != previous:
        previous = current
        current = re.sub(r",\s*([}\]])", r"\1", current)
    return current


# ========== MAIN LLM CLIENT CLASS ==========

class LearnerLLMClient:
    """
    Centralized Gemini LLM client with automatic API key rotation.

    Features:
    - Manages multiple Gemini API keys
    - Automatic failover on quota exceeded
    - JSON response extraction and repair
    - Consistent error handling
    - Logging for debugging

    Usage:
        client = LearnerLLMClient()
        response = client.generate_content(prompt="Explain ML to me")
        json_response = client.generate_structured_json(prompt, required_fields=[...])
    """

    def __init__(self, model: str = "gemini-2.5-flash-lite"):
        """
        Initialize LLM client with available API keys.

        Args:
            model: Gemini model to use (default: gemini-2.5-flash-lite)

        Raises:
            ValueError: If no API keys are found
            ImportError: If google-generativeai library is not installed
        """
        self.model = model
        self.api_keys = _get_all_api_keys()
        self.current_key_index = 0
        self.client = None

        if not self.api_keys:
            raise ValueError(
                "No Gemini API keys found. "
                "Set GEMINI_API_KEY or GEMINI_API_KEY_1..4 in .env or Streamlit secrets"
            )

        if genai is None:
            raise ImportError(
                "google-generativeai is not installed. "
                "Install with: pip install google-generativeai"
            )

        self._initialize_client()

    def _initialize_client(self) -> None:
        """
        Initialize Gemini client with current API key.

        Raises:
            ValueError: If current key index is out of bounds
        """
        if self.current_key_index >= len(self.api_keys):
            raise ValueError("No valid API keys available for Gemini")

        current_key = self.api_keys[self.current_key_index]
        genai.configure(api_key=current_key)
        self.client = genai.GenerativeModel(self.model)

    def _rotate_api_key(self) -> None:
        """
        Rotate to next available API key.

        Called when current key quota is exceeded.

        Raises:
            ValueError: If all keys are exhausted
        """
        self.current_key_index += 1
        if self.current_key_index >= len(self.api_keys):
            raise ValueError("All API keys exhausted")
        self._initialize_client()

    def generate_content(
        self,
        prompt: str,
        temperature: float = 0.7,
        max_tokens: int = 1000,
        response_mime_type: Optional[str] = None,
    ) -> str:
        """
        Generate content from Gemini with automatic API key rotation on quota exceeded.

        Args:
            prompt: Input prompt for Gemini
            temperature: Sampling temperature (0.0-1.0)
            max_tokens: Maximum output tokens
            response_mime_type: Optional MIME type for response (e.g., "application/json")

        Returns:
            Generated text response

        Raises:
            ValueError: If all API keys quota exceeded or other error occurs
        """
        max_retries = len(self.api_keys)
        attempt = 0

        while attempt < max_retries:
            try:
                generation_config = {
                    "temperature": temperature,
                    "max_output_tokens": max_tokens,
                }
                if response_mime_type:
                    generation_config["response_mime_type"] = response_mime_type

                response = self.client.generate_content(
                    prompt,
                    generation_config=generation_config,
                )

                if not response or not getattr(response, "text", None):
                    raise ValueError("Empty response from LLM")

                return response.text

            except Exception as e:
                error_str = str(e)

                # Check if it's a quota/rate limit error
                if any(
                    quota_indicator in error_str
                    for quota_indicator in [
                        "429",
                        "quota",
                        "rate limit",
                        "exceeded",
                        "per_minute",
                        "per_day",
                    ]
                ):
                    attempt += 1

                    if attempt < max_retries:
                        try:
                            self._rotate_api_key()
                            continue
                        except ValueError as rotate_error:
                            raise ValueError(
                                f"All API keys exhausted or invalid: {rotate_error}"
                            )
                    else:
                        raise ValueError(
                            f"All {len(self.api_keys)} API keys quota exceeded. "
                            f"Please wait before retrying."
                        )
                else:
                    # Non-quota errors should fail immediately
                    raise ValueError(f"Failed to generate content from LLM: {error_str}")

        raise ValueError("Failed to generate content after all retries")

    def extract_json_from_response(self, response_text: str) -> Dict[str, Any]:
        """
        Extract and repair JSON from LLM response text.

        Handles common formatting issues:
        - Markdown code fences (```json ... ```)
        - Trailing commas before closing braces
        - JSON embedded in other text

        Args:
            response_text: Raw LLM response

        Returns:
            Parsed JSON object as dict

        Raises:
            ValueError: If JSON cannot be parsed or is invalid
        """
        try:
            cleaned = _clean_json_text(response_text)
            candidates = [cleaned]

            # If the response contains other text, try extracting the first JSON object
            json_match = re.search(r"\{.*\}", cleaned, re.DOTALL)
            if json_match:
                candidates.append(json_match.group(0))

            last_error = None
            for candidate in candidates:
                try:
                    repaired = _strip_trailing_commas(candidate)
                    parsed_json = json.loads(repaired)
                    if not isinstance(parsed_json, dict):
                        raise ValueError("LLM response is not a valid JSON object")
                    return parsed_json
                except Exception as parse_error:
                    last_error = parse_error
                    continue

            raise ValueError(f"Invalid JSON in LLM response: {last_error}")

        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON in LLM response: {str(e)}")
        except Exception as e:
            raise ValueError(f"Failed to extract JSON from LLM response: {str(e)}")

    def validate_response_fields(
        self, response: Dict[str, Any], required_fields: list
    ) -> None:
        """
        Validate that all required fields are present in response.

        Args:
            response: JSON response from LLM
            required_fields: List of field names that must be present

        Raises:
            ValueError: If any required fields are missing
        """
        missing_fields = [field for field in required_fields if field not in response]

        if missing_fields:
            raise ValueError(f"LLM response missing required fields: {missing_fields}")

    def generate_structured_json(
        self,
        prompt: str,
        required_fields: list,
        temperature: float = 0.7,
        max_tokens: int = 1000,
    ) -> Dict[str, Any]:
        """
        Generate and parse a JSON response with validation.

        Complete pipeline:
        1. Generate content with JSON response format
        2. Extract JSON from response
        3. Validate all required fields present

        Args:
            prompt: Input prompt for Gemini
            required_fields: List of required fields in response
            temperature: Sampling temperature
            max_tokens: Maximum output tokens

        Returns:
            Validated JSON response as dict

        Raises:
            ValueError: If generation, parsing, or validation fails
        """
        response_text = self.generate_content(
            prompt,
            temperature=temperature,
            max_tokens=max_tokens,
            response_mime_type="application/json",
        )
        result = self.extract_json_from_response(response_text)
        self.validate_response_fields(result, required_fields)
        return result


# ========== FACTORY FUNCTION ==========

def build_llm_client(model: str = "gemini-2.5-flash-lite") -> LearnerLLMClient:
    """
    Factory function to build LLM client.

    Raises ValueError if API keys are missing or library not installed.

    Args:
        model: Gemini model to use

    Returns:
        Configured LearnerLLMClient instance
    """
    api_key = _get_first_api_key()

    if not api_key:
        raise ValueError(
            "Gemini API key not found. Set GEMINI_API_KEY or GEMINI_API_KEY_1..4"
        )

    if genai is None:
        raise ImportError(
            "google-generativeai is not installed. "
            "Install with: pip install google-generativeai"
        )

    return LearnerLLMClient(model=model)


# ========== UTILITY FUNCTION FOR BACKWARD COMPATIBILITY ==========

def extract_json(text: str) -> Dict[str, Any]:
    """
    Standalone function to extract JSON from text (backward compatibility).

    Args:
        text: Text potentially containing JSON

    Returns:
        Extracted JSON as dict

    Raises:
        ValueError: If JSON cannot be found or parsed
    """
    try:
        json_match = re.search(r"\{.*\}", text, re.DOTALL)
        if not json_match:
            raise ValueError("No JSON found in response")
        return json.loads(json_match.group(0))
    except Exception as e:
        raise ValueError(f"Failed to parse JSON: {str(e)}")
