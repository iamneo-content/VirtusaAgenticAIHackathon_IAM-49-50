"""
LearnBuddy Utilities Module

Centralized utilities for LLM management and shared functionality.
Based on VentureLens architecture patterns.

Exports:
- LearnerLLMClient: Main LLM client with API key rotation
- Helper functions for JSON cleaning and API key management
"""

from .llm_client import (
    LearnerLLMClient,
    _get_all_api_keys,
    _get_first_api_key,
    _clean_json_text,
    _strip_trailing_commas,
)

__all__ = [
    # Main client class
    "LearnerLLMClient",
    # Helper functions (private but exported for internal use)
    "_get_all_api_keys",
    "_get_first_api_key",
    "_clean_json_text",
    "_strip_trailing_commas",
]
