LEARNBUDDY PROJECT - AGENT TO AGENT COMMUNICATION FLOW
=======================================================


AGENT COMMUNICATION ARCHITECTURE DIAGRAM
========================================


graph TD
    Start([Learner Profile Input]) --> FormParser[Form Parser Agent]


    FormParser -->|Parsed & Validated Profile| ProfileAnalyzer[Profile Analyzer Agent]


    ProfileAnalyzer -->|Analyzed Profile + ML Features| GapDetection[Gap Detection ML Agent]
    ProfileAnalyzer -->|Analyzed Profile + ML Features| DifficultyPrediction[Difficulty Prediction ML Agent]


    GapDetection -->|Identified Gaps + Confidence Scores + Urgency Level| LLMPlanGenerator
    DifficultyPrediction -->|Recommended Difficulty + Confidence| LLMPlanGenerator[LLM Plan Generator Agent]


    LLMPlanGenerator -->|Three Learning Plan Variants A,B,C| PlanValidator[Plan Validator Agent]


    PlanValidator -->|Validated Plans + Issues| PersonalCoach[Personal Coach Agent]


    PersonalCoach -->|Tone-Adapted Plan Variants| ReportGenerator[Report Generator Agent]


    ReportGenerator -->|Final Report + JSON + Metrics| End([Learner Microplan Output])


    style Start fill:#e1f5ff,stroke:#01579b,stroke-width:3px
    style FormParser fill:#fff3e0,stroke:#e65100,stroke-width:2px
    style ProfileAnalyzer fill:#f3e5f5,stroke:#4a148c,stroke-width:2px
    style GapDetection fill:#e8f5e9,stroke:#1b5e20,stroke-width:2px
    style DifficultyPrediction fill:#e8f5e9,stroke:#1b5e20,stroke-width:2px
    style LLMPlanGenerator fill:#fce4ec,stroke:#880e4f,stroke-width:2px
    style PlanValidator fill:#e0f2f1,stroke:#004d40,stroke-width:2px
    style PersonalCoach fill:#f1f8e9,stroke:#33691e,stroke-width:2px
    style ReportGenerator fill:#ede7f6,stroke:#311b92,stroke-width:2px
    style End fill:#ffebee,stroke:#b71c1c,stroke-width:3px


DETAILED AGENT COMMUNICATION PROTOCOL
=====================================


1. FORM PARSER AGENT
====================

Role: Input Validation and Normalization
Inputs:
  - Raw learner JSON profile with 7 required sections
    * personal_info (name, age, timezone, country)
    * educational_background (education_level, field_of_study, years_educated)
    * learning_profile (learning_style, learning_pace, focus_duration, preferred_formats)
    * current_status (domain, topic, proficiency, projects, challenges)
    * learning_goals (primary_goal, timeline, career_aspiration)
    * constraints (hours_per_week, budget, employment_status, preferred_study_time)

Processing:
  - Validates 7 required JSON sections exist
  - Type checks and normalizes values
  - Converts strings to lowercase for consistency
  - Preserves numeric and boolean values
  - Collects validation errors without stopping

Outputs to Profile Analyzer Agent:
  - parsed_learner: Dict with normalized learner data
  - validation_errors: List of validation failure messages
  - is_valid: Boolean indicating if parsing succeeded
  - status: PARSING_COMPLETE


2. PROFILE ANALYZER AGENT
=========================

Role: Feature Extraction and Metric Calculation
Inputs from Form Parser:
  - Parsed learner data (all sections normalized)

Processing:
  - Extracts 6 categories of derived metrics
    * Demographics (age, timezone, country, education_level, years_educated, field_of_study)
    * Learning Characteristics (learning_style, pace, focus_duration, breaks, formats)
    * Proficiency (domain, topic, self-assessed score, test scores, projects, challenges)
    * Goals Analysis (primary goal, timeline, career aspiration, goal clarity)
    * Constraints Analysis (weekly hours, budget, employment, study time, time pressure)
    * Learning History (courses completed, completion rate, average score, trend)

  - Prepares ML-specific features
    * Gap Detection Features: 15 numeric + text features (TF-IDF vectorization ready)
    * Difficulty Prediction Features: 16 numeric + 8 categorical features

Outputs to ML Agents:
  - analyzed_profile: Dict with all extracted metrics
  - ml_features: Dict with prepared numeric and text features
  - demographic_profile: Dict with demographic information
  - learning_characteristics: Dict with learning style and preferences
  - status: ANALYSIS_COMPLETE


3. GAP DETECTION ML AGENT (PARALLEL EXECUTION)
===============================================

Role: Identify Learning Gaps and Determine Urgency
Inputs from Profile Analyzer:
  - analyzed_profile with all extracted metrics
  - ml_features (15 numeric + text for TF-IDF)

Processing:
  - Loads pre-trained OneVsRest LinearSVC model
  - Extracts text features: primary_domain, learning_style, challenges, goals
  - Vectorizes text using fitted TfidfVectorizer (max_features=5000, ngram_range=1,2)
  - Scales numeric features (age, proficiency, motivation, GPA, etc.) using StandardScaler
  - Combines text and numeric features via hstack
  - Predicts gaps using OneVsRest classifier
  - Computes confidence via sigmoid activation on decision scores
  - Determines urgency level based on proficiency score thresholds:
    * CRITICAL: proficiency < 30
    * HIGH: proficiency < 50 OR has prerequisite_foundation gap
    * MEDIUM: proficiency < 70
    * LOW: all others

Outputs to LLM Plan Generator:
  - identified_gaps: List of detected gap strings (e.g., "prerequisite_foundation")
  - gap_confidence_scores: Dict mapping gap_name to confidence float 0-1
  - gap_urgency_level: String from [CRITICAL, HIGH, MEDIUM, LOW]
  - status: GAP_DETECTION_COMPLETE


4. DIFFICULTY PREDICTION ML AGENT (PARALLEL EXECUTION)
=======================================================

Role: Recommend Optimal Learning Difficulty Level
Inputs from Profile Analyzer:
  - analyzed_profile with all extracted metrics
  - ml_features (16 numeric + 8 categorical)

Processing:
  - Loads pre-trained RandomForest classifier
  - Extracts numeric features: age, ability_score, learning_speed, time_available, etc. (16 total)
  - Extracts categorical features: education_level, learning_style, employment_status
  - Scales numeric features using fitted StandardScaler
  - One-hot encodes categorical features using fitted OneHotEncoders
  - Combines all features via hstack
  - Predicts difficulty class using RandomForestClassifier
  - Obtains prediction probability via predict_proba()
  - Inverse-transforms encoded label back to readable class name

Outputs to LLM Plan Generator:
  - recommended_difficulty: String from [Beginner, Intermediate, Advanced]
  - difficulty_confidence: Float 0-1 representing probability confidence
  - learning_readiness_assessment: Qualitative text describing readiness
  - status: DIFFICULTY_PREDICTION_COMPLETE


5. LLM PLAN GENERATOR AGENT
===========================

Role: Generate Three Learning Plan Variants
Inputs from ML Agents:
  - analyzed_profile (demographics, goals, constraints)
  - identified_gaps from Gap Detection Agent
  - gap_confidence_scores from Gap Detection Agent
  - recommended_difficulty from Difficulty Prediction Agent
  - difficulty_confidence from Difficulty Prediction Agent

Processing (For Each Variant A, B, C):

  Variant A (CONSERVATIVE):
    - Uses 1.5x timeline multiplier (extends learning period)
    - Allocates 8 hours per week
    - Includes ALL prerequisites (required: True)
    - Low intensity learning path
    - Includes more review and reinforcement

  Variant B (STANDARD):
    - Uses 1.0x timeline multiplier (baseline)
    - Allocates 10 hours per week
    - Includes prerequisites where applicable (required: True)
    - Medium intensity learning path
    - Balanced between breadth and depth

  Variant C (AGGRESSIVE):
    - Uses 0.7x timeline multiplier (accelerated)
    - Allocates 15 hours per week
    - Prerequisites optional (required: False)
    - High intensity learning path
    - Assumes strong foundational knowledge

  For each variant, LLM generates:
    - duration_weeks: Calculated as (target_timeline * factor)
    - hours_per_week: Allocated hours for this variant
    - intensity: Low/Medium/High intensity descriptor
    - topics: List of specific topics to cover
    - resources: Learning resources (books, courses, videos)
    - milestones: Measurable checkpoints for progress
    - prerequisites: Knowledge required before starting
    - success_criteria: Goals to achieve in this plan
    - difficulty_progression: How difficulty increases over time

  LLM Parameters:
    - Model: Gemini 2.5 Flash Lite
    - Temperature: 0.3 (focused, deterministic output)
    - Max Tokens: 2000 per plan
    - Response Format: JSON with above schema

Outputs to Plan Validator Agent:
  - plan_variant_a: Dict with Conservative plan structure
  - plan_variant_b: Dict with Standard plan structure
  - plan_variant_c: Dict with Aggressive plan structure
  - status: PLAN_GENERATION_COMPLETE


6. PLAN VALIDATOR AGENT
=======================

Role: Validate and Refine Generated Learning Plans
Inputs from LLM Plan Generator:
  - plan_variant_a, plan_variant_b, plan_variant_c (all three plans)
  - analyzed_profile (constraints and goals)

Processing:

  Validation Checks Performed:
    - Time Feasibility: Does plan fit within learner's available hours?
    - Timeline Feasibility: Can goals be achieved within timeline?
    - Goal Alignment: Does plan address primary and secondary goals?
    - Prerequisite Coverage: Are all gaps covered by prerequisites?
    - Difficulty Progression: Does difficulty ramp gradually without jumps?
    - Milestone Realism: Are milestones achievable with allocated time?

  For each failing check:
    - Documents specific validation issue
    - Provides remediation suggestion
    - Marks plan as needing revision or acceptable

  LLM Parameters:
    - Temperature: 0.3 (focused validation logic)
    - Max Tokens: 1500 for validation assessment
    - Response Format: JSON with issues and recommendations

Outputs to Personal Coach Agent:
  - plan_variant_a_validated: Dict with validated Conservative plan
  - plan_variant_b_validated: Dict with validated Standard plan
  - plan_variant_c_validated: Dict with validated Aggressive plan
  - validation_issues: List of identified validation problems
  - status: PLAN_VALIDATION_COMPLETE


7. PERSONAL COACH AGENT
=======================

Role: Personalize Plans with Learner-Specific Tone and Style
Inputs from Plan Validator:
  - plan_variant_a_validated, plan_variant_b_validated, plan_variant_c_validated
  - analyzed_profile (age, learning_style, personality signals)

Processing:

  Tone Selection Logic:
    - Age based:
      * Age < 18: "encouraging_youth" tone (supportive, celebratory)
      * Age 18-25: "conversational" tone (friendly, relatable)
      * Age >= 25: "professional" tone (formal, growth-oriented)

    - Learning style override (if strong signal):
      * learning_style = visual: "visual_metaphor_based" tone
      * learning_style = kinesthetic: "practical_action_oriented" tone
      * learning_style = auditory: "conversational" tone

  For each validated plan:
    - Rewrite plan structure into markdown narrative
    - Use selected tone throughout
    - Add motivational messages aligned with tone
    - Include progress tracking suggestions
    - Personalize milestone descriptions
    - Add encouragement phrases matched to tone

  LLM Parameters:
    - Temperature: 0.5 (balanced creativity and structure)
    - Max Tokens: 500 per rewritten plan
    - Response Format: Markdown narrative text

Outputs to Report Generator Agent:
  - variant_a_friendly: Markdown text of Conservative plan with tone
  - variant_b_friendly: Markdown text of Standard plan with tone
  - variant_c_friendly: Markdown text of Aggressive plan with tone
  - determined_tone: String indicating tone applied
  - status: COACH_REWRITING_COMPLETE


8. REPORT GENERATOR AGENT
=========================

Role: Synthesize Results and Generate Final Reports
Inputs from Personal Coach and Previous Agents:
  - All validated and tone-adapted plans (3 variants)
  - analyzed_profile (learner information)
  - identified_gaps (from Gap Detection)
  - recommended_difficulty (from Difficulty Prediction)
  - quality_metrics calculation

Processing:

  1. Quality Score Calculation:
     - profile_completeness: 0.95 if complete, 0.0 otherwise
     - gap_detection_accuracy: min(1.0, num_gaps / 12.0)
     - difficulty_confidence: direct confidence value
     - plan_feasibility: 0.85 if validated and no issues, 0.65 otherwise
     - coaching_adaptation: 0.90 if tone applied, 0.0 otherwise
     - report_completeness: 1.0 if all sections generated, 0.0 otherwise
     - overall_quality: mean of all 6 metrics

  2. Report Generation (3 formats):

     Format 1: MARKDOWN REPORT
     - File: micro_plan_report.txt
     - Content:
       * Learner Profile Summary (age, education, goals, constraints)
       * Gap Analysis Section (identified gaps, urgency, recommendations)
       * Difficulty Assessment (recommended difficulty, confidence, reasoning)
       * Three Plan Variants (Conservative, Standard, Aggressive)
       * Personalized Coaching Section (tone-adapted advice)
       * Success Metrics (how to track progress)
       * Next Steps (immediate action items)

     Format 2: JSON REPORT
     - File: micro_plan.json
     - Structure:
       * metadata (timestamp, version, system_name)
       * learner_profile (extracted key demographics)
       * analysis (gaps, urgency, difficulty, readiness)
       * learning_plans (3 variants with full details)
       * personalized_coaching (tone-adapted texts for each variant)
       * validation (any issues found during validation)
       * quality_metrics (6-dimensional quality assessment)
       * recommendations (next_steps, success_factors, resource_links)

     Format 3: METRICS JSON
     - File: evaluation_metrics.json
     - Content:
       * quality_metrics: 6 scores on 0-1 scale
       * overall_quality: weighted average
       * completion_status: 7 stage completion flags
       * summary_statistics: counts and distributions

  3. File Output:
     - Create output directory: output/{learner_id}/
     - Save all 3 formats
     - Record output paths in state

Outputs (Final Results):
  - final_report: Markdown string with complete report
  - report_json: Dict with structured JSON output
  - quality_metrics: Dict with quality scores
  - saved_path: Path to saved markdown report
  - output_dir: Directory containing all outputs
  - status: REPORT_GENERATION_COMPLETE


AGENT COMMUNICATION PATTERNS
============================


1. SEQUENTIAL DEPENDENCY PATTERN
   Form Parser -> Profile Analyzer -> (ML Agents in parallel) -> LLM Plan Generator

   Rationale: Each agent depends on complete output from previous agent
   Pipeline ensures data validation and enrichment at each stage


2. PARALLEL EXECUTION PATTERN
   Profile Analyzer -> {Gap Detection Agent, Difficulty Prediction Agent}

   Rationale: Two ML agents operate independently on same analyzed profile
   Reduces total execution time by running predictions concurrently
   Both outputs feed into single LLM Plan Generator


3. COLLECTIVE OUTPUT PATTERN
   {Gap Detection, Difficulty Prediction} -> LLM Plan Generator

   Rationale: LLM needs both ML predictions for context-aware plan generation
   Combines objective ML scores with LLM's natural language reasoning
   Creates hybrid analysis (quantitative + qualitative)


4. VALIDATION HANDOFF PATTERN
   LLM Plan Generator -> Plan Validator -> Personal Coach

   Rationale: Plans validated before personalization
   Ensures only feasible plans get tone adaptation
   Prevents propagation of infeasible suggestions


5. CONTEXT ENRICHMENT PATTERN
   Each agent adds metadata to state for downstream agents
   Example: Gap Detection adds confidence_scores that Coach uses for emphasis
   Enables agents to make intelligent prioritization decisions


CRITICAL COMMUNICATION REQUIREMENTS
===================================


1. Data Validation Between Agents
   - Each agent validates inputs from previous agent
   - Missing required fields trigger error collection (not failures)
   - Agents must be resilient to partial data

2. Type Consistency
   - All agent outputs must match expected TypedDict structure
   - Lists, Dicts, and scalars must have consistent types
   - No type coercion on agent boundary crossings

3. State Preservation
   - All agent outputs merged into single state dict
   - Previous agent results never overwritten
   - Complete audit trail maintained

4. Error Recovery
   - Agent failures do not stop workflow
   - Status flags track completion per agent
   - Downstream agents check upstream completion before processing

5. Metadata Propagation
   - Confidence scores, timestamps, and version info passed along
   - Enables quality assessment and debugging
   - Allows quality metrics calculation at end


DATAFLOW VOLUME ESTIMATES
=========================


Typical Learner Profile Analysis:

Input Size:
  - Raw JSON: ~5-10 KB
  - Normalized Profile: ~8-12 KB
  - ML Features: ~15-20 KB

Intermediate Outputs:
  - Gap Detection Result: ~3-5 KB
  - Difficulty Prediction: ~2-3 KB
  - Validated Plans (3): ~25-35 KB

Final Output:
  - Markdown Report: ~20-30 KB
  - JSON Report: ~30-50 KB
  - Metrics: ~2-3 KB

Total Workflow:
  - End-to-End Execution Time: 12-25 seconds
  - Bottleneck: LLM API calls (3-5 seconds each)
  - Data Processing: <2 seconds
  - Model Inference: <1 second


AGENT ORCHESTRATION SUMMARY
===========================


The LearnBuddy agent architecture implements a sophisticated multi-stage pipeline:

1. Input validation ensures data quality
2. Feature extraction prepares diverse inputs
3. Parallel ML models provide quantitative insights
4. Unified LLM consolidates insights into plans
5. Validation ensures feasibility
6. Personalization delivers learner-specific guidance
7. Reporting synthesizes complete analysis

Each agent communicates through a shared state dict, enabling:
- Transparent data flow across modules
- Comprehensive audit trails
- Quality metrics calculation
- Error recovery and resilience
- Extensibility for new agents

This architecture balances simplicity (single state dict) with modularity
(independent agents) to create a maintainable, scalable system.
