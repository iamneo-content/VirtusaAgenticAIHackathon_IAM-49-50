#!/usr/bin/env python3
"""
Profile Analyzer Agent
Extracts features and calculates derived metrics from normalized profile.

PURE ANALYSIS ONLY - NO FALLBACKS OR HEURISTIC DEFAULTS
All values must come from actual profile data or raise errors.
"""

from typing import Dict, Any
import statistics

class ProfileAnalyzerAgent:
    """Analyze learner profile and calculate derived metrics"""

    def __init__(self):
        pass

    def analyze(self, normalized_profile: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze profile and extract key metrics - all logic inlined.

        PURE ANALYSIS - NO FALLBACKS OR DEFAULTS
        Requires all essential fields. Raises ValueError if data is incomplete.
        """
        # DEMOGRAPHICS EXTRACTION - require essential fields
        personal = normalized_profile.get("personal_info", {})
        education = normalized_profile.get("educational_background", {})

        age = personal.get("age")
        if age is None:
            raise ValueError("Missing required field: personal_info.age")

        country = personal.get("country")
        if not country:
            raise ValueError("Missing required field: personal_info.country")

        education_level = education.get("highest_qualification")
        if not education_level:
            raise ValueError("Missing required field: educational_background.highest_qualification")

        demographics = {
            "age": age,
            "timezone": personal.get("timezone", "UTC"),  # OK to default timezone
            "country": country,
            "education_level": education_level,
            "years_educated": max(0, age - 6),
            "field_of_study": education.get("field_of_study", "unknown"),
        }

        # LEARNING CHARACTERISTICS EXTRACTION - require essential fields
        learning = normalized_profile.get("learning_profile", {})
        preferences = normalized_profile.get("preferences", {})

        learning_style = learning.get("learning_style")
        if not learning_style:
            raise ValueError("Missing required field: learning_profile.learning_style")

        learning_characteristics = {
            "learning_style": learning_style,
            "learning_pace": learning.get("learning_pace", "moderate"),
            "focus_duration_minutes": learning.get("focus_duration_minutes", 45),
            "break_preference_minutes": learning.get("break_preference_minutes", 10),
            "preferred_formats": learning.get("preferred_formats", []),
            "instructor_type": preferences.get("instructor_type", "any"),
            "gamification_preference": preferences.get("gamification_preference", "low"),
            "community_engagement": preferences.get("community_engagement", "low"),
        }

        # PROFICIENCY EXTRACTION - require essential fields
        current = normalized_profile.get("current_status", {})
        current_proficiency = current.get("current_proficiency", {})

        domain = current.get("primary_domain")
        if not domain:
            raise ValueError("Missing required field: current_status.primary_domain")

        proficiency = {
            "domain": domain,
            "topic": current_proficiency.get("topic", "unknown"),
            "self_assessed_score": current_proficiency.get("self_assessed_score", 50),
            "standardized_test_score": current_proficiency.get("standardized_test_score", 50),
            "assessment_date": current_proficiency.get("assessment_date", "unknown"),
            "current_projects": current.get("current_projects", []),
            "challenges": current.get("challenges_faced", []),
        }

        # GOALS ANALYSIS
        goals = normalized_profile.get("learning_goals", {})
        primary_goal = goals.get("primary_goal", "")
        secondary_goals = goals.get("secondary_goals", [])

        if primary_goal and len(secondary_goals) > 0:
            goal_clarity = 80
        elif primary_goal:
            goal_clarity = 60
        else:
            goal_clarity = 50

        # Goal alignment calculation
        goal_alignment = 0.5
        if goals.get("career_aspiration"):
            goal_alignment += 0.2
        if goals.get("target_timeline_months", 0) > 0:
            goal_alignment += 0.2
        if preferences.get("project_based_learning"):
            goal_alignment += 0.1
        goal_alignment = min(1.0, goal_alignment)

        goals_analysis = {
            "primary_goal": primary_goal,
            "secondary_goals": secondary_goals,
            "target_timeline_months": goals.get("target_timeline_months", 6),
            "desired_outcome": goals.get("desired_outcome", "unknown"),
            "career_aspiration": goals.get("career_aspiration", "unknown"),
            "goal_clarity_score": goal_clarity,
            "goal_alignment": goal_alignment,
        }

        # CONSTRAINTS ANALYSIS
        constraints = normalized_profile.get("constraints", {})
        hours_per_week = constraints.get("hours_available_per_week", 10)
        budget = constraints.get("budget_limit_usd", 0)
        timeline_months = goals.get("target_timeline_months", 6) if "target_timeline_months" in goals else 6
        estimated_hours_needed = 200
        time_pressure = min(100, max(0, 100 * (1 - (hours_per_week * 4 * timeline_months) / estimated_hours_needed)))

        constraints_analysis = {
            "hours_per_week": hours_per_week,
            "budget_limit_usd": budget,
            "certification_needed": constraints.get("certification_needed", False),
            "employment_status": constraints.get("employment_status", "unknown"),
            "preferred_study_time": constraints.get("preferred_study_time", "evening"),
            "time_pressure_score": time_pressure,
            "financial_constraint": budget == 0,
        }

        # LEARNING HISTORY ANALYSIS
        history = normalized_profile.get("learning_history", [])

        if not history:
            history_analysis = {
                "courses_completed": 0,
                "avg_completion_rate": 0,
                "avg_score": 0,
                "learning_trend": "new_learner",
                "avg_time_per_course": 0,
                "consistency_score": 0.5,
            }
        else:
            completion_rates = [h.get("completion_rate", 0) for h in history if "completion_rate" in h]
            scores = [h.get("score_obtained", 0) for h in history if "score_obtained" in h]
            times = [h.get("time_invested_hours", 0) for h in history if "time_invested_hours" in h]

            avg_completion = statistics.mean(completion_rates) if completion_rates else 0
            avg_score = statistics.mean(scores) if scores else 0
            avg_time = statistics.mean(times) if times else 0

            # Determine learning trend
            if len(scores) >= 6:
                recent_scores = scores[-3:]
                earlier_scores = scores[:-3]
                if statistics.mean(recent_scores) > statistics.mean(earlier_scores):
                    trend = "improving"
                elif statistics.mean(recent_scores) < statistics.mean(earlier_scores):
                    trend = "declining"
                else:
                    trend = "stable"
            elif scores:
                trend = "stable"
            else:
                trend = "unknown"

            # Calculate consistency
            if not completion_rates or len(completion_rates) < 2:
                consistency = 0.5
            else:
                if len(completion_rates) == 1:
                    consistency = completion_rates[0] / 100
                else:
                    std_dev = statistics.stdev(completion_rates)
                    consistency = 1.0 - (std_dev / 100)
                    consistency = max(0.0, min(1.0, consistency))

            history_analysis = {
                "courses_completed": len(history),
                "avg_completion_rate": avg_completion,
                "avg_score": avg_score,
                "learning_trend": trend,
                "avg_time_per_course": avg_time,
                "consistency_score": consistency,
            }

        # ========== ML FEATURE EXTRACTION (Single Source of Truth) ==========
        # Extract 15 numeric features for Gap Detection ML Model
        gap_detection_numeric_features = [
            personal.get("age") or 30,                                # age
            constraints.get("hours_available_per_week", 10),           # hours_per_week
            current_proficiency.get("self_assessed_score", 50),        # self_assessed_score
            current_proficiency.get("standardized_test_score", 50),    # standardized_test_score
            learning.get("focus_duration_minutes", 45),                # focus_duration_minutes
            goal_clarity,                                              # goal_clarity_score
            time_pressure,                                             # time_pressure_score
            history_analysis["consistency_score"],                     # consistency_score
            goal_clarity / 100.0,                                      # motivation_score (normalized)
            1.0 if learning.get("learning_pace") == "fast" else 0.5,  # learning_pace_factor
            constraints.get("budget_limit_usd", 100),                  # budget
            0,                                                         # num_gaps (will be filled by ML model result)
            education.get("gpa", 3.0),                                 # gpa
            education.get("years_of_experience", 0),                   # years_experience
            goals.get("target_timeline_months", 6),                    # target_timeline_months
        ]

        # Extract text features for Gap Detection (domain, style, challenges, goals)
        gap_detection_text = " ".join([
            str(current.get("primary_domain", "learning")),
            str(learning.get("learning_style", "mixed")),
            " ".join([str(c) for c in current.get("challenges_faced", [])]),
            str(goals.get("desired_outcome", ""))
        ])

        # Extract 16 numeric features for Difficulty Prediction ML Model
        difficulty_numeric_features = [
            personal.get("age") or 25,                                 # age
            current_proficiency.get("self_assessed_score", 50),        # ability_score
            1.0 if learning.get("learning_pace") == "fast" else 0.5,  # learning_speed_factor
            constraints.get("hours_available_per_week", 10) * 52,      # time_available_hours (yearly)
            education.get("years_of_experience", 0),                   # years_of_experience
            history_analysis["courses_completed"],                     # num_completed_courses
            education.get("gpa", 3.0),                                 # gpa
            goal_clarity,                                              # motivation_level
            current_proficiency.get("self_assessed_score", 50),        # prerequisite_mastery
            history_analysis["avg_completion_rate"] / 100.0,           # previous_success_rate
            current_proficiency.get("self_assessed_score", 50),        # current_knowledge_base
            history_analysis["avg_completion_rate"] / 100.0,           # learning_capacity
            learning.get("focus_duration_minutes", 45) / 60.0,         # focus_duration_hours
            constraints.get("budget_limit_usd", 100) / 100.0,          # resource_access_level (normalized)
            goal_clarity,                                              # support_network_strength
            time_pressure,                                             # pressure_handling_score
        ]

        # Extract 8 categorical features for Difficulty Prediction ML Model
        employment_status = constraints.get("employment_status")
        if not employment_status:
            raise ValueError("Missing required field: constraints.employment_status")

        # Get preferred difficulty - use default if not provided
        preferred_difficulty = current_proficiency.get("preferred_difficulty_level", "intermediate")

        difficulty_categorical_features = [
            education.get("highest_qualification", "Bachelor"),        # education_level
            learning.get("learning_style", "mixed"),                   # learning_style
            employment_status,                                         # employment_status
            history_analysis["learning_trend"],                        # past_performance_trend
            "intrinsic" if goal_clarity > 70 else "extrinsic",        # motivation_level_category
            "high" if time_pressure > 70 else "low",                   # career_urgency
            preferred_difficulty,                                      # preferred_difficulty_in_past
            "available" if budget > 0 else "limited",                  # budget_constraint
        ]

        learner_id = normalized_profile.get("learner_id")
        if not learner_id:
            raise ValueError("Missing required field: learner_id")

        ml_features = {
            "gap_detection_numeric": gap_detection_numeric_features,
            "gap_detection_text": gap_detection_text,
            "difficulty_numeric": difficulty_numeric_features,
            "difficulty_categorical": difficulty_categorical_features,
        }

        return {
            "learner_id": learner_id,
            "demographics": demographics,
            "learning_characteristics": learning_characteristics,
            "proficiency": proficiency,
            "goals_analysis": goals_analysis,
            "constraints_analysis": constraints_analysis,
            "history_analysis": history_analysis,
            "ml_features": ml_features,  # ← NEW: Pre-calculated ML features
        }
