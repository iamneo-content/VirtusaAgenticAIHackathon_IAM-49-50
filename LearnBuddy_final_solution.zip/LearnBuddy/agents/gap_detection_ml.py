#!/usr/bin/env python3
"""
Gap Detection ML Agent

Uses trained ML Model (OneVsRest + LinearSVC) to detect learning gaps.

Model: OneVsRest(LinearSVC)
Input: TF-IDF text features + 15 numeric features
Output: Multi-label gap predictions with confidence scores

PURE ML ONLY - NO FALLBACKS OR HEURISTICS
"""

import pickle
import json
import numpy as np
from pathlib import Path
from typing import Dict, Any, Tuple, List
from sklearn.feature_extraction.text import TfidfVectorizer
from scipy.sparse import hstack

MODEL_DIR = Path("ml/model")


class GapDetectionMLAgent:
    """
    ML agent for detecting learning gaps using trained OneVsRest classifier.

    Loads model artifacts and uses them to predict learning gaps from profile.
    PURE ML ONLY - NO FALLBACKS OR HEURISTICS
    """

    def __init__(self):
        """Initialize agent and load model artifacts."""
        self.model = self.vectorizer = self.mlb = self.scaler = self.gap_labels = None

        with open(MODEL_DIR / "gap_model.pkl", "rb") as f:
            self.model = pickle.load(f)

        with open(MODEL_DIR / "gap_vectorizer.pkl", "rb") as f:
            self.vectorizer = pickle.load(f)

        with open(MODEL_DIR / "gap_mlb.pkl", "rb") as f:
            self.mlb = pickle.load(f)

        with open(MODEL_DIR / "gap_scaler.pkl", "rb") as f:
            self.scaler = pickle.load(f)

        with open(MODEL_DIR / "gap_labels.json", "r") as f:
            self.gap_labels = json.load(f)

    def detect_gaps(self, analyzed_profile: Dict[str, Any]) -> Tuple[List[str], Dict[str, float], str]:
        """
        Detect learning gaps in learner's proficiency using pre-extracted ML features.

        Features are pre-calculated by ProfileAnalyzerAgent (single source of truth).

        PURE ML - NO FALLBACKS

        Args:
            analyzed_profile: Analyzed learner profile with ml_features pre-calculated

        Returns:
            Tuple of (gaps_list, confidence_dict, urgency_level)

        Raises:
            ValueError: If model not initialized or features missing
        """
        if self.model is None:
            raise ValueError("Gap Detection model not initialized")

        # Get pre-extracted features from ProfileAnalyzerAgent
        ml_features = analyzed_profile.get("ml_features", {})
        if not ml_features:
            raise ValueError("ML features not found in analyzed_profile")

        text_features = ml_features.get("gap_detection_text", "learning")
        numeric_features_list = ml_features.get("gap_detection_numeric", [])

        if not numeric_features_list or len(numeric_features_list) != 15:
            raise ValueError(f"Expected 15 numeric features, got {len(numeric_features_list)}")

        # Transform pre-extracted features using trained transformers
        X_text = self.vectorizer.transform([text_features])
        X_numeric_scaled = self.scaler.transform([numeric_features_list])
        X = hstack([X_text, X_numeric_scaled])

        # Make predictions
        predictions = self.model.predict(X)

        # Get decision function scores (OneVsRest + LinearSVC doesn't support predict_proba)
        # Convert decision scores to confidence [0-1] range using sigmoid
        decision_scores = self.model.decision_function(X)[0]
        confidences = 1.0 / (1.0 + np.exp(-decision_scores))  # Sigmoid function

        # Extract predicted gaps and confidence scores
        identified_gaps = []
        confidence_scores = {}

        for idx, label in enumerate(self.gap_labels):
            if predictions[0, idx] == 1:
                identified_gaps.append(label)
                confidence_scores[label] = float(confidences[idx])

        # Determine urgency level from proficiency score
        proficiency = analyzed_profile.get("proficiency", {}).get("self_assessed_score", 50)
        if proficiency < 30:
            urgency = "critical"
        elif proficiency < 50 or "prerequisite_foundation" in identified_gaps:
            urgency = "high"
        elif proficiency < 70:
            urgency = "medium"
        else:
            urgency = "low"

        return identified_gaps, confidence_scores, urgency
