#!/usr/bin/env python3
"""
Plan Validator Agent

Validates learning plan feasibility and quality using LLM feedback.
Uses centralized LearnerLLMClient for API key management.

Validation Checks:
- Time feasibility (hours vs availability)
- Goal alignment (gaps and objectives)
- Prerequisite coverage (foundations before advanced)
- Difficulty progression (gradual escalation)
- Topic relevance (domain alignment)
- Milestone realism (achievable checkpoints)

PURE LLM ONLY - NO FALLBACKS OR HEURISTICS
"""

from typing import Dict, Any, List, Tuple
from utils.llm_client import LearnerLLMClient


class PlanValidatorAgent:
    """
    LLM agent for validating learning plan feasibility and quality.

    Validates 3 plan variants against learner profile constraints:
    - Time availability and hours per week
    - Learning goals and identified gaps
    - Difficulty progression
    - Prerequisite coverage
    - Milestone achievability

    PURE LLM ONLY - NO FALLBACKS OR HEURISTICS

    Attributes:
        client: LearnerLLMClient instance for API access
    """

    def __init__(self):
        """Initialize agent with centralized LLM client."""
        self.client = LearnerLLMClient()

    def validate_plans(
        self,
        plans: Tuple[Dict, Dict, Dict],
        analyzed_profile: Dict[str, Any]
    ) -> Tuple[Dict, Dict, Dict, List[str]]:
        """
        Validate 3 plans using LLM - all logic inlined.

        PURE LLM - NO FALLBACKS OR HEURISTICS

        Expects plans to be fully populated by PlanGeneratorLLMAgent.
        Raises ValueError if required fields are missing.
        """
        plan_a, plan_b, plan_c = plans

        # Validate plans structure - require all fields
        required_fields = [
            "duration_weeks", "hours_per_week", "intensity", "topics",
            "resources", "milestones", "prerequisites", "success_criteria", "difficulty_progression"
        ]

        for idx, plan in enumerate([plan_a, plan_b, plan_c]):
            for field in required_fields:
                if field not in plan or (isinstance(plan[field], (list, str)) and len(plan[field]) == 0):
                    plan_name = ["A", "B", "C"][idx]
                    raise ValueError(
                        f"Plan {plan_name} missing required field '{field}'. "
                        f"PlanGeneratorLLMAgent must provide all fields."
                    )

        # LLM validation for feasibility
        plans_summary = f"""
PLAN A (Conservative):
- Duration: {plan_a['duration_weeks']} weeks
- Hours/Week: {plan_a['hours_per_week']} hours
- Topics: {', '.join(plan_a['topics'][:5])}
- Milestones: {', '.join(plan_a['milestones'])}
- Difficulty Progression: {plan_a['difficulty_progression']}

PLAN B (Standard):
- Duration: {plan_b['duration_weeks']} weeks
- Hours/Week: {plan_b['hours_per_week']} hours
- Topics: {', '.join(plan_b['topics'][:5])}
- Milestones: {', '.join(plan_b['milestones'])}
- Difficulty Progression: {plan_b['difficulty_progression']}

PLAN C (Aggressive):
- Duration: {plan_c['duration_weeks']} weeks
- Hours/Week: {plan_c['hours_per_week']} hours
- Topics: {', '.join(plan_c['topics'][:5])}
- Milestones: {', '.join(plan_c['milestones'])}
- Difficulty Progression: {plan_c['difficulty_progression']}

LEARNER CONSTRAINTS:
- Hours Available/Week: {analyzed_profile.get('constraints_analysis', {}).get('hours_per_week', 10)}
- Timeline: {analyzed_profile.get('goals_analysis', {}).get('target_timeline_months', 12)} months
- Identified Gaps: {', '.join(analyzed_profile.get('identified_gaps', []))}
"""

        prompt = f"""Review these three learning plans against learner constraints.

{plans_summary}

Identify feasibility issues:
- Are hours realistic given availability?
- Do milestones fit timeline?
- Are prerequisites covered?
- Is difficulty progression gradual?

Return ONLY JSON array: ["issue1", "issue2"] or []"""

        response_text = self.client.generate_content(prompt=prompt, temperature=0.3, max_tokens=500)

        issues_dict = self.client.extract_json_from_response(response_text)
        if isinstance(issues_dict, dict):
            issues = issues_dict.get("issues", [])
        elif isinstance(issues_dict, list):
            issues = issues_dict
        else:
            issues = []
        issues = [str(issue) for issue in issues if issue]

        return plan_a, plan_b, plan_c, issues
