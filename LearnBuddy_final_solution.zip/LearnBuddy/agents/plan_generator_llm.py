#!/usr/bin/env python3
"""
Plan Generator LLM Agent (Standardized Class Pattern)

Generates 3 micro-learning plan variants using Gemini LLM.
Uses centralized LearnerLLMClient for API key management and rotation.

Variants:
- Conservative: 1.5× timeline, 8 hrs/week, foundation-heavy, prerequisites required
- Standard: 1× timeline, 10 hrs/week, balanced, prerequisites required
- Aggressive: 0.7× timeline, 15 hrs/week, intensive, prerequisites optional
"""

from typing import Dict, Any, List, Tuple
from utils.llm_client import LearnerLLMClient


class PlanGeneratorLLMAgent:
    """
    LLM agent for generating personalized learning plan variants.

    Uses Gemini API to generate 3 distinct learning plans based on:
    - Domain of study
    - Identified learning gaps
    - Recommended difficulty level
    - Learner constraints (timeline, hours/week)

    Attributes:
        client: LearnerLLMClient instance for API access
    """

    def __init__(self):
        """Initialize agent with centralized LLM client."""
        self.client = LearnerLLMClient()

    def generate_plans(
        self,
        analyzed_profile: Dict[str, Any],
        gaps: List[str],
        difficulty: str
    ) -> Tuple[Dict, Dict, Dict]:
        """Generate 3 plans - all logic inlined (no nested methods)."""
        domain = analyzed_profile.get("proficiency", {}).get("domain", "Programming")
        timeline = analyzed_profile.get("goals_analysis", {}).get("target_timeline_months", 6)

        required_fields = [
            "duration_weeks", "hours_per_week", "intensity", "topics",
            "resources", "milestones", "prerequisites", "success_criteria",
            "difficulty_progression"
        ]

        plans = []

        # INLINED: Generate all 3 plan variants
        for variant_config in [
            ("Conservative", timeline * 1.5, "low", gaps[:3], True),
            ("Standard", timeline, "medium", gaps[:5], True),
            ("Aggressive", timeline * 0.7, "high", gaps, False),
        ]:
            variant, timeline_var, intensity, focus_areas, prereq = variant_config
            weeks = int(timeline_var * 4)
            hours_per_week = {"low": 8, "medium": 10, "high": 15}.get(intensity, 10)

            prompt = f"""Generate detailed micro-learning plan:
Domain: {domain}
Variant: {variant}
Duration: {timeline_var:.1f} months ({weeks} weeks)
Intensity: {intensity}
Weekly: {hours_per_week} hours
Gaps: {', '.join(focus_areas) if focus_areas else 'General'}
Prerequisites: {"Include" if prereq else "Optional"}

Return JSON:
{{"duration_weeks": {weeks}, "hours_per_week": {hours_per_week}, "intensity": "{intensity}", "topics": [], "resources": [], "milestones": [], "prerequisites": {["Basics"] if prereq else []}, "success_criteria": [], "difficulty_progression": ""}}"""

            try:
                response_text = self.client.generate_content(prompt=prompt, temperature=0.3, max_tokens=2000)
                plan_data = self.client.extract_json_from_response(response_text)
                self.client.validate_response_fields(plan_data, required_fields)

                # Sanitize list fields
                plan_data["topics"] = [str(t) for t in plan_data.get("topics", [])]
                plan_data["resources"] = [str(r) for r in plan_data.get("resources", [])]
                plan_data["milestones"] = [str(m) for m in plan_data.get("milestones", [])]
                plan_data["prerequisites"] = [str(p) for p in plan_data.get("prerequisites", [])]
                plan_data["success_criteria"] = [str(c) for c in plan_data.get("success_criteria", [])]

                plans.append(plan_data)
            except ValueError as e:
                raise
            except Exception as e:
                raise

        return tuple(plans)
