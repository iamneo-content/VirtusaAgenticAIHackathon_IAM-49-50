"""
LearnBuddy Agents Package

All agents follow VentureLens class-based pattern.
ZERO standalone functions - agents instantiated by nodes only.

7 Core Agent Classes:
- ProfileParserAgent: Input validation and normalization
- ProfileAnalyzerAgent: Feature extraction (40+ metrics)
- GapDetectionMLAgent: ML gap detection (OneVsRest + LinearSVC)
- DifficultyPredictionMLAgent: ML difficulty prediction (RandomForest)
- PlanGeneratorLLMAgent: LLM-based plan generation
- PlanValidatorAgent: LLM feasibility validation
- CoachRewriterLLMAgent: Personalized tone adaptation
"""

from .profile_parser import ProfileParserAgent
from .profile_analyzer import ProfileAnalyzerAgent
from .gap_detection_ml import GapDetectionMLAgent
from .difficulty_prediction_ml import DifficultyPredictionMLAgent
from .plan_generator_llm import PlanGeneratorLLMAgent
from .plan_validator import PlanValidatorAgent
from .coach_rewriter_llm import CoachRewriterLLMAgent

__all__ = [
    "ProfileParserAgent",
    "ProfileAnalyzerAgent",
    "GapDetectionMLAgent",
    "DifficultyPredictionMLAgent",
    "PlanGeneratorLLMAgent",
    "PlanValidatorAgent",
    "CoachRewriterLLMAgent",
]
