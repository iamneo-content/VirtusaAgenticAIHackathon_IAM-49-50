#!/usr/bin/env python3
"""
Difficulty Prediction ML Agent
Uses trained ML Model to predict optimal difficulty level

PURE ML ONLY - NO FALLBACKS OR HEURISTICS
"""

import pickle
import numpy as np
from pathlib import Path
from typing import Dict, Any, Tuple
import warnings
warnings.filterwarnings('ignore')

class DifficultyPredictionMLAgent:
    """Predict optimal difficulty level using trained ML model - PURE ML ONLY"""

    def __init__(self):
        self.model_dir = Path("ml/model")
        self.difficulty_classes = ["Beginner", "Intermediate", "Advanced"]

        # Load all model artifacts
        with open(self.model_dir / "difficulty_model.pkl", 'rb') as f:
            self.model = pickle.load(f)
        with open(self.model_dir / "difficulty_scaler.pkl", 'rb') as f:
            self.scaler = pickle.load(f)
        with open(self.model_dir / "difficulty_label_encoder.pkl", 'rb') as f:
            self.label_encoder = pickle.load(f)
        with open(self.model_dir / "difficulty_categorical_encoders.pkl", 'rb') as f:
            self.categorical_encoders = pickle.load(f)

    def predict_difficulty(self, analyzed_profile: Dict[str, Any]) -> Tuple[str, float]:
        """Predict optimal difficulty using pre-extracted ML features.

        Features are pre-calculated by ProfileAnalyzerAgent (single source of truth).

        PURE ML - NO FALLBACKS
        """
        # Get pre-extracted features from ProfileAnalyzerAgent
        ml_features = analyzed_profile.get("ml_features", {})
        if not ml_features:
            raise ValueError("ML features not found in analyzed_profile")

        numeric_features = ml_features.get("difficulty_numeric", [])
        categorical_features_list = ml_features.get("difficulty_categorical", [])

        if not numeric_features or len(numeric_features) != 16:
            raise ValueError(f"Expected 16 numeric features, got {len(numeric_features)}")

        # Only 3 of the 8 categorical features are used (trained model uses education_level, learning_style, employment_status)
        if not categorical_features_list or len(categorical_features_list) < 3:
            raise ValueError(f"Expected at least 3 categorical features, got {len(categorical_features_list)}")

        # Prepare and combine features using trained transformers
        numeric_array = np.array(numeric_features).reshape(1, -1)
        numeric_scaled = self.scaler.transform(numeric_array)

        # Encode categorical features using OneHotEncoders (match training setup)
        categorical_names = [
            "education_level",
            "learning_style",
            "employment_status"
        ]

        categorical_encoded_list = []
        for idx, col_name in enumerate(categorical_names):
            if idx < len(categorical_features_list) and col_name in self.categorical_encoders:
                encoder = self.categorical_encoders[col_name]
                value = categorical_features_list[idx]
                try:
                    # OneHotEncoder requires 2D input
                    encoded = encoder.transform([[value]])
                    categorical_encoded_list.append(encoded)
                except (ValueError, AttributeError):
                    # If value not in encoder's classes, use all zeros (unknown)
                    n_features = encoder.get_feature_names_out().shape[0] if hasattr(encoder, 'get_feature_names_out') else 1
                    categorical_encoded_list.append(np.zeros((1, n_features)))

        if categorical_encoded_list:
            categorical_array = np.hstack(categorical_encoded_list)
            X = np.hstack([numeric_scaled, categorical_array])
        else:
            X = numeric_scaled

        # Make prediction
        prediction = self.model.predict(X)[0]
        probabilities = self.model.predict_proba(X)[0]

        difficulty_label = self.label_encoder.inverse_transform([prediction])[0]
        confidence = float(np.max(probabilities))

        return difficulty_label, confidence
