#!/usr/bin/env python3
"""
Coach Rewriter LLM Agent

Rewrites validated learning plans with personalized coaching tone.
Uses LearnerLLMClient for API access.
"""

from typing import Dict, Any, Tuple
from utils.llm_client import LearnerLLMClient


class CoachRewriterLLMAgent:
    """
    LLM agent for personalizing learning plans with adaptive tone.

    Tone Selection:
    - Young learners (<18): Encouraging
    - Visual learners: Metaphor-based
    - Kinesthetic learners: Action-oriented
    - Auditory learners: Conversational
    - Default: Analytical
    """

    def __init__(self):
        """Initialize agent with centralized LLM client."""
        self.client = LearnerLLMClient()

    def rewrite_plans(
        self,
        plans: Tuple[Dict, Dict, Dict],
        analyzed_profile: Dict[str, Any]
    ) -> Tuple[str, str, str]:
        """
        Rewrite 3 plans with adaptive coaching tone.

        All personalization logic inlined here.

        Args:
            plans: Tuple of (plan_a, plan_b, plan_c) dictionaries
            analyzed_profile: Analyzed learner profile

        Returns:
            Tuple of (text_a, text_b, text_c) strings
        """
        # Determine coaching tone (inline from helper function)
        learning_style = analyzed_profile.get("learning_characteristics", {}).get("learning_style", "visual")
        age = analyzed_profile.get("demographics", {}).get("age", 30)

        if age < 18:
            tone = "encouraging_youth"
        elif learning_style == "auditory":
            tone = "conversational"
        elif learning_style == "kinesthetic":
            tone = "practical_action_oriented"
        elif learning_style == "visual":
            tone = "visual_metaphor_based"
        else:
            tone = "analytical"

        plan_a, plan_b, plan_c = plans

        # Personalize each plan (inline from helper function)
        personalized_plans = []
        for plan, variant_name in [(plan_a, "Conservative"), (plan_b, "Standard"), (plan_c, "Aggressive")]:
            duration = plan.get("duration_weeks", 12)
            hours = plan.get("hours_per_week", 10)
            topics = ", ".join(plan.get("topics", [])[:5])
            milestones = ", ".join(plan.get("milestones", [])[:4])
            resources = ", ".join(plan.get("resources", [])[:5])

            prompt = f"""You are a learning coach. Write personalized coaching guidance for this plan.

Plan Variant: {variant_name}
Duration: {duration} weeks at {hours} hours per week
Topics: {topics}
Milestones: {milestones}
Resources: {resources}

Write 2-3 paragraphs in a {tone} tone that:
1. Motivate the learner
2. Explain the path forward
3. Build confidence in success

Tone style: {tone}"""

            response = self.client.generate_content(prompt=prompt, temperature=0.5)
            personalized_plans.append(response.strip())

        return tuple(personalized_plans)
