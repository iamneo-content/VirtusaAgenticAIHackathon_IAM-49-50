#!/usr/bin/env python3
"""
Profile Parser Agent

Validates and normalizes learner JSON profile.
"""

from typing import Dict, Any, List, Tuple


class ProfileParserAgent:
    """Parse and validate learner JSON profile."""

    REQUIRED_FIELDS = {
        "learner_id": str,
        "personal_info": dict,
        "educational_background": dict,
        "learning_profile": dict,
        "current_status": dict,
        "learning_goals": dict,
        "constraints": dict,
    }

    VALID_EDUCATION_LEVELS = ["primary", "secondary", "bachelor", "master", "phd"]
    VALID_LEARNING_STYLES = ["visual", "auditory", "kinesthetic", "reading_writing", "mixed"]

    def __init__(self):
        self.errors: List[str] = []
        self.warnings: List[str] = []

    def parse(self, learner_json: Dict[str, Any]) -> Tuple[Dict[str, Any], bool, List[str]]:
        """
        Main parse function - validates and normalizes profile.

        All validation and normalization logic inlined here.

        Returns: (normalized_profile, is_valid, error_messages)
        """
        self.errors = []
        self.warnings = []

        # ===== VALIDATION =====
        # Check required fields
        for field, field_type in self.REQUIRED_FIELDS.items():
            if field not in learner_json:
                self.errors.append(f"Missing required field: {field}")
            elif not isinstance(learner_json.get(field), field_type):
                self.errors.append(f"Invalid type for {field}: expected {field_type.__name__}")

        # Validate personal info
        info = learner_json.get("personal_info", {})
        if info:
            if "age" in info and (info["age"] < 8 or info["age"] > 100):
                self.warnings.append(f"Age seems unusual: {info['age']}")
            if "languages_spoken" in info:
                if not isinstance(info["languages_spoken"], list) or len(info["languages_spoken"]) == 0:
                    self.warnings.append("Languages spoken should be non-empty list")

        # Validate educational background
        background = learner_json.get("educational_background", {})
        if background:
            if "highest_qualification" in background:
                if background["highest_qualification"] not in self.VALID_EDUCATION_LEVELS:
                    self.warnings.append(f"Unknown education level: {background['highest_qualification']}")
            if "gpa_cgpa" in background:
                gpa = background["gpa_cgpa"]
                if not (0 <= gpa <= 4.0):
                    self.warnings.append(f"GPA seems unusual: {gpa}")

        # Validate learning profile
        learning = learner_json.get("learning_profile", {})
        if learning:
            if "learning_style" in learning:
                if learning["learning_style"] not in self.VALID_LEARNING_STYLES:
                    self.warnings.append(f"Unknown learning style: {learning['learning_style']}")
            if "focus_duration_minutes" in learning:
                duration = learning["focus_duration_minutes"]
                if duration < 5 or duration > 240:
                    self.warnings.append(f"Focus duration seems unusual: {duration} minutes")

        # Validate current status
        status = learner_json.get("current_status", {})
        if status and "current_proficiency" in status:
            prof = status["current_proficiency"]
            if "self_assessed_score" in prof:
                score = prof["self_assessed_score"]
                if not (0 <= score <= 100):
                    self.warnings.append(f"Proficiency score out of range: {score}")

        # Validate learning goals
        goals = learner_json.get("learning_goals", {})
        if goals and "target_timeline_months" in goals:
            timeline = goals["target_timeline_months"]
            if timeline < 1 or timeline > 60:
                self.warnings.append(f"Timeline seems unusual: {timeline} months")

        # Validate constraints
        constraints = learner_json.get("constraints", {})
        if constraints:
            if "hours_available_per_week" in constraints:
                hours = constraints["hours_available_per_week"]
                if hours < 0 or hours > 168:
                    self.warnings.append(f"Hours per week out of range: {hours}")
            if "budget_limit_usd" in constraints:
                budget = constraints["budget_limit_usd"]
                if budget < 0:
                    self.warnings.append(f"Budget should be positive: ${budget}")

        # Check if validation passed
        is_valid = len(self.errors) == 0

        if not is_valid:
            return {}, False, self.errors

        # ===== NORMALIZATION =====
        def normalize_dict(d: Dict[str, Any]) -> Dict[str, Any]:
            """Normalize dictionary values (strings to lowercase, preserve numbers and structure)."""
            normalized = {}
            for key, value in d.items():
                if isinstance(value, str):
                    # Only normalize string values to lowercase
                    normalized[key] = value.strip().lower()
                elif isinstance(value, dict):
                    # Recursively normalize nested dicts
                    normalized[key] = normalize_dict(value)
                elif isinstance(value, list):
                    # Handle lists of dicts and other values
                    normalized[key] = [
                        normalize_dict(v) if isinstance(v, dict) else (v.strip().lower() if isinstance(v, str) else v)
                        for v in value
                    ]
                else:
                    # Keep numbers, booleans, and other types as-is
                    normalized[key] = value
            return normalized

        normalized = {}
        normalized["learner_id"] = str(learner_json.get("learner_id", "UNKNOWN")).strip()
        normalized["personal_info"] = normalize_dict(learner_json.get("personal_info", {}))
        normalized["educational_background"] = normalize_dict(learner_json.get("educational_background", {}))
        normalized["learning_profile"] = normalize_dict(learner_json.get("learning_profile", {}))
        normalized["current_status"] = normalize_dict(learner_json.get("current_status", {}))
        normalized["learning_goals"] = normalize_dict(learner_json.get("learning_goals", {}))
        normalized["constraints"] = normalize_dict(learner_json.get("constraints", {}))
        normalized["learning_history"] = learner_json.get("learning_history", [])
        normalized["preferences"] = normalize_dict(learner_json.get("preferences", {}))
        normalized["challenges_and_support"] = normalize_dict(learner_json.get("challenges_and_support", {}))

        return normalized, True, self.errors + self.warnings
