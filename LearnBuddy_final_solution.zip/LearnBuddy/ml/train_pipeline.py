#!/usr/bin/env python3
"""
ML Training Pipeline Orchestration for LearnBuddy

Orchestrates complete ML pipeline:
1. Data cleaning (gap + difficulty datasets)
2. Model training (Gap Detection + Difficulty Prediction)
3. Model evaluation

Pipeline structure follows VentureLens architecture pattern.
"""

from typing import Dict, Any
import pandas as pd
from pathlib import Path
import sys
import json

# Allow running both as module (`python -m ml.train_pipeline`)
# and as script (`python ml/train_pipeline.py`)
if __name__ == "__main__" and __package__ is None:
    sys.path.append(str(Path(__file__).resolve().parent.parent))

from ml.cleaning.clean_gap_data import clean_gap_data
from ml.cleaning.clean_difficulty_data import clean_difficulty_data
from ml.train_model.train_gap_model import train_gap_detection_model
from ml.train_model.train_difficulty_model import train_difficulty_prediction_model


def run_training_pipeline(
    data_dir: str = "data",
    processed_dir: str = "data/processed",
    model_dir: str = "ml/model"
) -> Dict[str, Any]:
    """
    Execute complete ML training pipeline.

    Stages:
    1. Load raw training + eval datasets
    2. Clean gap detection data
    3. Clean difficulty prediction data
    4. Train gap detection model (OneVsRest + LinearSVC)
    5. Train difficulty prediction model (RandomForest)
    6. Return metrics for both models

    Args:
        data_dir: Root data directory
        processed_dir: Directory to save cleaned data
        model_dir: Directory to save trained models

    Returns:
        dict with cleaning stats and training metrics for all models
    """

    results = {
        "gap_cleaning": {},
        "difficulty_cleaning": {},
        "gap_training": {},
        "difficulty_training": {},
        "status": "pending"
    }

    try:
        # ========== PATHS ==========
        gap_train_path = f"{data_dir}/raw/gap_training_raw.csv"
        gap_eval_path = f"{data_dir}/raw/gap_eval_raw.csv"

        difficulty_train_path = f"{data_dir}/raw/difficulty_training_raw.csv"
        difficulty_eval_path = f"{data_dir}/raw/difficulty_eval_raw.csv"

        # ========== STAGE 1: LOAD DATASETS ==========
        print("\n" + "=" * 70)
        print("LEARNBUDDY ML TRAINING PIPELINE")
        print("=" * 70)

        print("\n[STAGE 1] Loading datasets...")
        try:
            gap_train_df = pd.read_csv(gap_train_path)
            gap_eval_df = pd.read_csv(gap_eval_path)
            print(f"  ✓ Gap Detection - Train: {len(gap_train_df)}, Eval: {len(gap_eval_df)}")
        except FileNotFoundError as e:
            raise FileNotFoundError(f"Gap detection data not found: {e}")

        try:
            difficulty_train_df = pd.read_csv(difficulty_train_path)
            difficulty_eval_df = pd.read_csv(difficulty_eval_path)
            print(f"  ✓ Difficulty Prediction - Train: {len(difficulty_train_df)}, Eval: {len(difficulty_eval_df)}")
        except FileNotFoundError as e:
            raise FileNotFoundError(f"Difficulty prediction data not found: {e}")

        # ========== STAGE 2: CLEAN GAP DETECTION DATA ==========
        print("\n[STAGE 2] Cleaning gap detection data...")
        gap_train_clean, gap_stats = clean_gap_data(
            gap_train_df,
            save_processed=True,
            output_dir=processed_dir
        )
        # Evaluation data is validated but not cleaned (prevents data leakage)
        gap_eval_clean = gap_eval_df.copy()
        results["gap_cleaning"] = gap_stats
        print(f"  ✓ Gap data cleaned")
        print(f"    - Original: {gap_stats['original_rows']}, Cleaned: {gap_stats['cleaned_rows']}")
        print(f"    - Duplicates removed: {gap_stats['duplicates_removed']}")

        # ========== STAGE 3: CLEAN DIFFICULTY PREDICTION DATA ==========
        print("\n[STAGE 3] Cleaning difficulty prediction data...")
        difficulty_train_clean, difficulty_stats = clean_difficulty_data(
            difficulty_train_df,
            save_processed=True,
            output_dir=processed_dir
        )
        # Evaluation data is validated but not cleaned (prevents data leakage)
        difficulty_eval_clean = difficulty_eval_df.copy()
        results["difficulty_cleaning"] = difficulty_stats
        print(f"  ✓ Difficulty data cleaned")
        print(f"    - Original: {difficulty_stats['original_rows']}, Cleaned: {difficulty_stats['cleaned_rows']}")
        print(f"    - Duplicates removed: {difficulty_stats['duplicates_removed']}")

        # ========== STAGE 4: TRAIN GAP DETECTION MODEL ==========
        print("\n[STAGE 4] Training gap detection model (OneVsRest + LinearSVC)...")
        gap_metrics = train_gap_detection_model(
            gap_train_clean,
            gap_eval_clean,
            model_save_dir=model_dir
        )
        results["gap_training"] = gap_metrics
        print(f"  ✓ Gap detection model trained")
        print(f"    - Train accuracy: {gap_metrics.get('train_accuracy', 0):.2%}")
        print(f"    - Eval accuracy: {gap_metrics.get('eval_accuracy', 0):.2%}")
        print(f"    - Eval Hamming Loss: {gap_metrics.get('eval_hamming_loss', 0):.4f}")

        # ========== STAGE 5: TRAIN DIFFICULTY PREDICTION MODEL ==========
        print("\n[STAGE 5] Training difficulty prediction model (RandomForest)...")
        difficulty_metrics = train_difficulty_prediction_model(
            difficulty_train_clean,
            difficulty_eval_clean,
            model_save_dir=model_dir
        )
        results["difficulty_training"] = difficulty_metrics
        print(f"  ✓ Difficulty prediction model trained")
        print(f"    - Train accuracy: {difficulty_metrics.get('train_accuracy', 0):.2%}")
        print(f"    - Eval accuracy: {difficulty_metrics.get('eval_accuracy', 0):.2%}")
        print(f"    - CV score (5-fold): {difficulty_metrics.get('cv_score', 0):.2%}")

        # ========== COMPLETION ==========
        results["status"] = "success"
        print("\n" + "=" * 70)
        print("TRAINING PIPELINE COMPLETE!")
        print("=" * 70)
        print(f"\nModels saved to: {model_dir}")
        print(f"Cleaned data saved to: {processed_dir}")

        return results

    except Exception as e:
        results["status"] = "failed"
        results["error"] = str(e)
        print(f"\n✗ Pipeline error: {str(e)}")
        import traceback
        traceback.print_exc()
        return results


if __name__ == "__main__":
    results = run_training_pipeline()
    print("\n" + "=" * 70)
    print("FINAL RESULTS")
    print("=" * 70)
    print(json.dumps(results, indent=2, default=str))
