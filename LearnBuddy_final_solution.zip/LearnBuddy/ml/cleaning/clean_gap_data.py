#!/usr/bin/env python3
"""
Clean gap detection training data
"""

from typing import Tuple, Dict, Any
import pandas as pd
import json
import ast
from pathlib import Path


def clean_gap_data(df: pd.DataFrame, save_processed: bool = False, output_dir: str = "data/processed") -> Tuple[pd.DataFrame, dict]:
    """Clean gap detection dataset.

    Args:
        df: Input DataFrame
        save_processed: Whether to save cleaned data
        output_dir: Directory to save cleaned data

    Returns:
        Tuple of (cleaned_df, stats_dict)
    """
    original_rows = len(df)

    # Remove duplicates
    df = df.drop_duplicates()
    duplicates_removed = original_rows - len(df)

    # Handle missing values - numeric columns
    numeric_cols = ['age', 'proficiency_score', 'hours_per_week', 'completion_rate',
                    'motivation_score', 'learning_pace', 'budget', 'num_failed_courses',
                    'gpa', 'study_consistency', 'years_experience', 'previous_attempts',
                    'prerequisite_knowledge', 'support_available', 'time_pressure',
                    'target_timeline_months', 'career_urgency']

    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')
            df[col].fillna(df[col].median(), inplace=True)

    # Handle missing values - categorical columns
    categorical_cols = ['education_level', 'learning_style', 'employment_status']
    for col in categorical_cols:
        if col in df.columns:
            df[col].fillna(df[col].mode()[0] if not df[col].mode().empty else 'Unknown', inplace=True)

    # Fix categorical values
    valid_education = ['Primary', 'Secondary', 'Bachelor', 'Master', 'PhD']
    if 'education_level' in df.columns:
        df.loc[~df['education_level'].isin(valid_education), 'education_level'] = 'Bachelor'

    valid_learning_styles = ['visual', 'auditory', 'reading/writing', 'kinesthetic', 'mixed']
    if 'learning_style' in df.columns:
        df.loc[~df['learning_style'].isin(valid_learning_styles), 'learning_style'] = 'mixed'

    valid_employment = ['Student', 'Employed', 'Self-employed', 'Unemployed', 'Retired']
    if 'employment_status' in df.columns:
        df.loc[~df['employment_status'].isin(valid_employment), 'employment_status'] = 'Employed'

    # Clip outliers
    outlier_ranges = {
        'age': (10, 100),
        'proficiency_score': (0, 100),
        'hours_per_week': (0, 60),
        'completion_rate': (0, 1),
        'motivation_score': (0, 100),
        'gpa': (0, 4),
        'budget': (0, 100000),
        'num_failed_courses': (0, 100),
    }

    for col, (min_val, max_val) in outlier_ranges.items():
        if col in df.columns:
            df[col] = df[col].clip(min_val, max_val)

    # Parse and validate gap labels
    def parse_gap_str(gap_str):
        try:
            if isinstance(gap_str, str):
                try:
                    return json.loads(gap_str)
                except:
                    return ast.literal_eval(gap_str)
            else:
                return gap_str if isinstance(gap_str, list) else []
        except:
            return []

    df['identified_gaps'] = df['identified_gaps'].apply(parse_gap_str)

    # Remove rows with empty gaps
    initial_before_gaps = len(df)
    df = df[df['identified_gaps'].apply(len) > 0].reset_index(drop=True)
    empty_gaps_removed = initial_before_gaps - len(df)

    cleaned_rows = len(df)
    rows_removed_pct = ((original_rows - cleaned_rows) / original_rows) * 100 if original_rows > 0 else 0

    output_path = None
    if save_processed:
        Path(output_dir).mkdir(parents=True, exist_ok=True)
        output_path = f"{output_dir}/gap_detection_cleaned.csv"
        df.to_csv(output_path, index=False)

    stats = {
        "original_rows": original_rows,
        "cleaned_rows": cleaned_rows,
        "duplicates_removed": duplicates_removed,
        "empty_gaps_removed": empty_gaps_removed,
        "rows_removed_pct": rows_removed_pct,
        "output_path": output_path
    }

    return df, stats
