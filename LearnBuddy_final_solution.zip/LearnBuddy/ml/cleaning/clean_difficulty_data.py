#!/usr/bin/env python3
"""
Clean difficulty prediction training data
"""

from typing import Tuple, Dict, Any
import pandas as pd
from pathlib import Path


def clean_difficulty_data(df: pd.DataFrame, save_processed: bool = False, output_dir: str = "data/processed") -> Tuple[pd.DataFrame, dict]:
    """Clean difficulty prediction dataset.

    Args:
        df: Input DataFrame
        save_processed: Whether to save cleaned data
        output_dir: Directory to save cleaned data

    Returns:
        Tuple of (cleaned_df, stats_dict)
    """
    original_rows = len(df)

    # Remove duplicates
    df = df.drop_duplicates()
    duplicates_removed = original_rows - len(df)

    # Handle missing values - numeric columns
    numeric_cols = ['age', 'ability_score', 'learning_speed', 'time_available_hours',
                    'years_of_experience', 'num_completed_courses', 'gpa', 'motivation_level',
                    'prerequisite_mastery', 'previous_success_rate', 'current_knowledge_base',
                    'learning_capacity', 'focus_duration_hours', 'resource_access_level',
                    'support_network_strength', 'pressure_handling_score']

    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')
            df[col].fillna(df[col].median(), inplace=True)

    # Handle missing values - categorical columns
    categorical_cols = ['education_level', 'learning_style', 'employment_status',
                        'motivation_type', 'primary_goal', 'learning_environment',
                        'previous_experience_level', 'support_availability']
    for col in categorical_cols:
        if col in df.columns:
            df[col].fillna(df[col].mode()[0] if not df[col].mode().empty else 'Unknown', inplace=True)

    # Fix categorical values
    valid_education = ['Primary', 'Secondary', 'Bachelor', 'Master', 'PhD']
    if 'education_level' in df.columns:
        df.loc[~df['education_level'].isin(valid_education), 'education_level'] = 'Bachelor'

    valid_learning_styles = ['visual', 'auditory', 'reading/writing', 'kinesthetic', 'mixed']
    if 'learning_style' in df.columns:
        df.loc[~df['learning_style'].isin(valid_learning_styles), 'learning_style'] = 'mixed'

    valid_motivation = ['intrinsic', 'extrinsic', 'mixed']
    if 'motivation_type' in df.columns:
        df.loc[~df['motivation_type'].isin(valid_motivation), 'motivation_type'] = 'mixed'

    valid_employment = ['Student', 'Employed', 'Self-employed', 'Unemployed', 'Retired']
    if 'employment_status' in df.columns:
        df.loc[~df['employment_status'].isin(valid_employment), 'employment_status'] = 'Employed'

    valid_difficulty = ['Beginner', 'Intermediate', 'Advanced']
    if 'recommended_difficulty' in df.columns:
        df.loc[~df['recommended_difficulty'].isin(valid_difficulty), 'recommended_difficulty'] = 'Intermediate'

    # Clip outliers
    outlier_ranges = {
        'age': (10, 100),
        'ability_score': (0, 100),
        'learning_speed': (0, 10),
        'time_available_hours': (0, 168),
        'years_of_experience': (0, 80),
        'num_completed_courses': (0, 500),
        'gpa': (0, 4),
        'motivation_level': (0, 100),
        'prerequisite_mastery': (0, 100),
        'previous_success_rate': (0, 1),
    }

    for col, (min_val, max_val) in outlier_ranges.items():
        if col in df.columns:
            df[col] = df[col].clip(min_val, max_val)

    # Validate class distribution
    class_stats = {}
    if 'recommended_difficulty' in df.columns:
        dist = df['recommended_difficulty'].value_counts()
        for cls, count in dist.items():
            class_stats[cls] = count

    cleaned_rows = len(df)
    rows_removed_pct = ((original_rows - cleaned_rows) / original_rows) * 100 if original_rows > 0 else 0

    output_path = None
    if save_processed:
        Path(output_dir).mkdir(parents=True, exist_ok=True)
        output_path = f"{output_dir}/difficulty_prediction_cleaned.csv"
        df.to_csv(output_path, index=False)

    stats = {
        "original_rows": original_rows,
        "cleaned_rows": cleaned_rows,
        "duplicates_removed": duplicates_removed,
        "rows_removed_pct": rows_removed_pct,
        "class_distribution": class_stats,
        "output_path": output_path
    }

    return df, stats
