"""
Data Cleaning Module for LearnBuddy ML Pipeline

Function-based cleaning architecture:
- clean_gap_data: Clean and validate gap training/evaluation data
- clean_difficulty_data: Clean and validate difficulty training/evaluation data

Both functions follow VentureLens pattern:
- Training data: Full cleaning (6 stages)
- Evaluation data: Validation only (prevent data leakage)
"""

from .clean_gap_data import clean_gap_data
from .clean_difficulty_data import clean_difficulty_data

__all__ = [
    "clean_gap_data",
    "clean_difficulty_data",
]
