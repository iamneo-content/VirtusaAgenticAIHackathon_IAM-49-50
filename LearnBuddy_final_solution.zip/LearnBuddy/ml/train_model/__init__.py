"""
Model Training Module for LearnBuddy ML Pipeline

Function-based training architecture:
- train_gap_detection_model: Train OneVsRest(LinearSVC) for gap detection
- train_difficulty_prediction_model: Train RandomForest for difficulty prediction

Both functions follow VentureLens pattern:
- Accept cleaned DataFrames
- Return trained models + artifacts (pkl files)
- Include evaluation metrics
"""

from .train_gap_model import train_gap_detection_model
from .train_difficulty_model import train_difficulty_prediction_model

__all__ = [
    "train_gap_detection_model",
    "train_difficulty_prediction_model",
]
