"""
Train Gap Detection Model (OneVsRest + LinearSVC)
Multi-label classification for 12 learning gap categories
"""

import pandas as pd
import numpy as np
import json
import pickle
from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import StandardScaler, MultiLabelBinarizer
from sklearn.multiclass import OneVsRestClassifier
from sklearn.svm import LinearSVC
from sklearn.metrics import accuracy_score, hamming_loss
import ast
import warnings

warnings.filterwarnings('ignore')


def prepare_gap_features(df, vectorizer, scaler, fit=False):
    """Prepare text and numeric features for gap detection.

    Args:
        df: Input DataFrame
        vectorizer: TfidfVectorizer instance
        scaler: StandardScaler instance
        fit: Whether to fit transformers (True for training data)

    Returns:
        X: Combined features array (n_samples, n_features)
    """
    # Text features: TF-IDF from available text columns
    text_data = (df['primary_domain'].fillna('') + ' ' +
                df['learning_style'].fillna('') + ' ' +
                df['data_source'].fillna('')).astype(str)

    if fit:
        text_features = vectorizer.fit_transform(text_data)
    else:
        text_features = vectorizer.transform(text_data)

    # Numeric features - using available numeric columns
    numeric_cols = ['age', 'current_proficiency_score', 'hours_available_per_week', 'avg_completion_rate',
                   'motivation_level', 'current_gpa', 'course_dropout_rate',
                   'years_in_education', 'total_courses_completed',
                   'concept_understanding_score', 'practical_application_score', 'problem_solving_ability',
                   'goal_clarity_score', 'assessment_confidence', 'target_timeline_months']

    # Filter to only columns that exist
    numeric_cols = [col for col in numeric_cols if col in df.columns]

    # Convert all numeric columns to numeric type, coercing errors to NaN
    numeric_df = df[numeric_cols].copy()
    for col in numeric_cols:
        numeric_df[col] = pd.to_numeric(numeric_df[col], errors='coerce')

    # Fill NaN values with column means
    for col in numeric_cols:
        col_mean = numeric_df[col].mean()
        if pd.isna(col_mean):
            col_mean = 0  # Default to 0 if all values are NaN
        numeric_df[col] = numeric_df[col].fillna(col_mean)

    numeric_data = numeric_df.values

    if fit:
        numeric_features = scaler.fit_transform(numeric_data)
    else:
        numeric_features = scaler.transform(numeric_data)

    # Combine text and numeric features
    X = np.hstack([text_features.toarray(), numeric_features])
    return X


def prepare_gap_targets(df, mlb, fit=False):
    """Prepare multi-label targets for gap detection.

    Args:
        df: Input DataFrame
        mlb: MultiLabelBinarizer instance
        fit: Whether to fit binarizer (True for training data)

    Returns:
        y: Multi-label binary matrix (n_samples, n_labels)
        gap_labels: List of gap category labels (only if fit=True)
    """
    def parse_gaps(gap_str):
        try:
            if isinstance(gap_str, str):
                try:
                    gaps = json.loads(gap_str)
                except:
                    gaps = ast.literal_eval(gap_str)
            else:
                gaps = gap_str
            return gaps if isinstance(gaps, list) else []
        except:
            return []

    gaps_list = df['identified_gaps'].apply(parse_gaps).tolist()

    if fit:
        y = mlb.fit_transform(gaps_list)
        gap_labels = mlb.classes_.tolist()
        return y, gap_labels
    else:
        y = mlb.transform(gaps_list)
        return y, None


def train_gap_detection_model(train_df, eval_df, model_save_dir="ml/model"):
    """Train gap detection model using OneVsRest + LinearSVC.

    Args:
        train_df: Training data DataFrame
        eval_df: Evaluation data DataFrame
        model_save_dir: Directory to save model artifacts

    Returns:
        dict: Training and evaluation metrics
    """
    print("\n" + "="*70)
    print("TRAINING GAP DETECTION MODEL (OneVsRest + LinearSVC)")
    print("="*70)

    # Initialize transformers and model
    vectorizer = TfidfVectorizer(max_features=5000, ngram_range=(1, 2))
    scaler = StandardScaler()
    mlb = MultiLabelBinarizer()
    model = OneVsRestClassifier(LinearSVC(random_state=42, max_iter=2000))

    # Prepare training data
    print("\n[1/6] Preparing training features...")
    X_train = prepare_gap_features(train_df, vectorizer, scaler, fit=True)
    y_train, gap_labels = prepare_gap_targets(train_df, mlb, fit=True)

    print(f"  ✓ Training features shape: {X_train.shape}")
    print(f"  ✓ Training targets shape: {y_train.shape}")
    print(f"  ✓ Gap labels ({len(gap_labels)}): {gap_labels}")

    # Train model
    print("\n[2/6] Training model...")
    model.fit(X_train, y_train)
    print("  ✓ Model trained")

    # Evaluate on training set
    print("\n[3/6] Evaluating on training set...")
    y_pred = model.predict(X_train)
    train_acc = accuracy_score(y_train, y_pred)
    train_hl = hamming_loss(y_train, y_pred)
    print(f"  ✓ Accuracy: {train_acc:.3f}")
    print(f"  ✓ Hamming Loss: {train_hl:.3f}")

    # Evaluate on eval set
    print("\n[4/6] Evaluating on evaluation set...")
    X_eval = prepare_gap_features(eval_df, vectorizer, scaler, fit=False)
    y_eval, _ = prepare_gap_targets(eval_df, mlb, fit=False)
    y_eval_pred = model.predict(X_eval)
    eval_acc = accuracy_score(y_eval, y_eval_pred)
    eval_hl = hamming_loss(y_eval, y_eval_pred)
    print(f"  ✓ Eval Accuracy: {eval_acc:.3f}")
    print(f"  ✓ Eval Hamming Loss: {eval_hl:.3f}")

    # Save model artifacts
    print(f"\n[5/6] Saving artifacts to {model_save_dir}...")
    Path(model_save_dir).mkdir(parents=True, exist_ok=True)

    pickle.dump(model, open(f"{model_save_dir}/gap_model.pkl", "wb"))
    pickle.dump(vectorizer, open(f"{model_save_dir}/gap_vectorizer.pkl", "wb"))
    pickle.dump(mlb, open(f"{model_save_dir}/gap_mlb.pkl", "wb"))
    pickle.dump(scaler, open(f"{model_save_dir}/gap_scaler.pkl", "wb"))

    with open(f"{model_save_dir}/gap_labels.json", "w") as f:
        json.dump(gap_labels, f)

    print("  ✓ Artifacts saved")

    # Return metrics
    print("\n[6/6] Training complete")
    metrics = {
        "train_accuracy": float(train_acc),
        "train_hamming_loss": float(train_hl),
        "eval_accuracy": float(eval_acc),
        "eval_hamming_loss": float(eval_hl),
        "overfitting_gap": float(train_acc - eval_acc),
        "gap_labels_count": len(gap_labels),
        "gap_labels": gap_labels,
    }

    return metrics


if __name__ == "__main__":
    # Paths
    train_path = "data/processed/gap_detection_train_clean.csv"
    eval_path = "data/processed/gap_detection_eval_validated.csv"
    model_dir = "ml/model"

    # Load data
    print("Loading data...")
    train_df = pd.read_csv(train_path)
    eval_df = pd.read_csv(eval_path)
    print(f"Training samples: {len(train_df)}")
    print(f"Eval samples: {len(eval_df)}")

    # Train model
    metrics = train_gap_detection_model(train_df, eval_df, model_dir)
    print("\nTraining metrics:")
    for key, value in metrics.items():
        if key != "gap_labels":
            print(f"  {key}: {value}")
