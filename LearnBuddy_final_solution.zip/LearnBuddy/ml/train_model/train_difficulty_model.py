"""
Train Difficulty Prediction Model (RandomForest)
Multi-class classification for 3 difficulty levels
"""

import pandas as pd
import numpy as np
import pickle
from pathlib import Path
from sklearn.preprocessing import StandardScaler, LabelEncoder, OneHotEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score
from sklearn.metrics import accuracy_score, classification_report
import warnings

warnings.filterwarnings('ignore')


def prepare_difficulty_features(df, numeric_scaler, categorical_encoders, fit=False):
    """Prepare numeric and categorical features for difficulty prediction.

    Args:
        df: Input DataFrame
        numeric_scaler: StandardScaler instance
        categorical_encoders: Dict of OneHotEncoder instances
        fit: Whether to fit transformers (True for training data)

    Returns:
        X: Combined features array (n_samples, n_features)
    """
    # Numeric features - using available columns
    numeric_cols = ['age', 'current_ability_score', 'learning_speed_factor', 'time_to_complete_typical_course_hours',
                   'motivation_level', 'learning_consistency', 'goal_alignment', 'career_urgency',
                   'previous_attempts_on_similar', 'avg_score_on_similar_topics', 'success_rate_on_similar_topics',
                   'topic_complexity_rating', 'required_prerequisites_count', 'prerequisites_mastery_level',
                   'estimated_hours_to_master', 'available_time_weeks']

    # Filter to columns that exist
    numeric_cols = [col for col in numeric_cols if col in df.columns]

    # Convert to numeric and fill
    numeric_df = df[numeric_cols].copy()
    for col in numeric_cols:
        numeric_df[col] = pd.to_numeric(numeric_df[col], errors='coerce')

    # Fill NaN values
    for col in numeric_cols:
        col_mean = numeric_df[col].mean()
        if pd.isna(col_mean):
            col_mean = 0
        numeric_df[col] = numeric_df[col].fillna(col_mean)

    numeric_data = numeric_df.values

    if fit:
        numeric_features = numeric_scaler.fit_transform(numeric_data)
    else:
        numeric_features = numeric_scaler.transform(numeric_data)

    # Categorical features - use available categorical columns
    categorical_cols = ['education_level', 'learning_style', 'employment_status']

    categorical_features_list = []
    for col in categorical_cols:
        if col in df.columns:
            col_data = df[col].fillna('unknown').astype(str).values.reshape(-1, 1)

            if fit:
                encoder = OneHotEncoder(sparse_output=False, handle_unknown='ignore')
                encoded = encoder.fit_transform(col_data)
                categorical_encoders[col] = encoder
            else:
                encoded = categorical_encoders[col].transform(col_data)

            categorical_features_list.append(encoded)

    if categorical_features_list:
        categorical_features = np.hstack(categorical_features_list)
        # Combine numeric and categorical
        X = np.hstack([numeric_features, categorical_features])
    else:
        X = numeric_features

    return X


def prepare_difficulty_targets(df, label_encoder, fit=False):
    """Prepare target variable for difficulty prediction.

    Args:
        df: Input DataFrame
        label_encoder: LabelEncoder instance
        fit: Whether to fit encoder (True for training data)

    Returns:
        y: Encoded target labels (n_samples,)
    """
    # Use the actual target column name
    target_col = 'recommended_difficulty_level' if 'recommended_difficulty_level' in df.columns else 'recommended_difficulty'
    y_raw = df[target_col].values

    if fit:
        y = label_encoder.fit_transform(y_raw)
    else:
        y = label_encoder.transform(y_raw)

    return y


def train_difficulty_prediction_model(train_df, eval_df, model_save_dir="ml/model"):
    """Train difficulty prediction model using RandomForest.

    Args:
        train_df: Training data DataFrame
        eval_df: Evaluation data DataFrame
        model_save_dir: Directory to save model artifacts

    Returns:
        dict: Training and evaluation metrics
    """
    print("\n" + "="*70)
    print("TRAINING DIFFICULTY PREDICTION MODEL (RandomForest)")
    print("="*70)

    # Initialize transformers and model
    numeric_scaler = StandardScaler()
    label_encoder = LabelEncoder()
    categorical_encoders = {}
    model = RandomForestClassifier(n_estimators=100, max_depth=20, random_state=42, n_jobs=-1)

    # Prepare training features
    print("\n[1/6] Preparing training features...")
    X_train = prepare_difficulty_features(train_df, numeric_scaler, categorical_encoders, fit=True)
    y_train = prepare_difficulty_targets(train_df, label_encoder, fit=True)

    print(f"  ✓ Training features shape: {X_train.shape}")
    print(f"  ✓ Training targets shape: {y_train.shape}")
    print(f"  ✓ Classes: {label_encoder.classes_}")

    # Train model
    print("\n[2/6] Training model...")
    model.fit(X_train, y_train)
    print("  ✓ Model trained")

    # Evaluate on training set
    print("\n[3/6] Evaluating on training set...")
    y_pred = model.predict(X_train)
    train_acc = accuracy_score(y_train, y_pred)
    print(f"  ✓ Training Accuracy: {train_acc:.4f}")

    # Cross-validation
    print("\n[4/6] Cross-validation (5-fold)...")
    cv_scores = cross_val_score(model, X_train, y_train, cv=5)
    cv_mean = cv_scores.mean()
    cv_std = cv_scores.std()
    print(f"  ✓ CV Scores: {[f'{s:.4f}' for s in cv_scores]}")
    print(f"  ✓ CV Mean: {cv_mean:.4f} (+/- {cv_std:.4f})")

    # Evaluate on eval set
    print("\n[5/6] Evaluating on evaluation set...")
    X_eval = prepare_difficulty_features(eval_df, numeric_scaler, categorical_encoders, fit=False)
    y_eval = prepare_difficulty_targets(eval_df, label_encoder, fit=False)
    y_eval_pred = model.predict(X_eval)
    eval_acc = accuracy_score(y_eval, y_eval_pred)
    print(f"  ✓ Eval Accuracy: {eval_acc:.4f}")
    print("\n  Classification Report:")
    print(classification_report(y_eval, y_eval_pred, target_names=label_encoder.classes_))

    # Save model artifacts
    print(f"\n[6/6] Saving artifacts to {model_save_dir}...")
    Path(model_save_dir).mkdir(parents=True, exist_ok=True)

    pickle.dump(model, open(f"{model_save_dir}/difficulty_model.pkl", "wb"))
    pickle.dump(numeric_scaler, open(f"{model_save_dir}/difficulty_scaler.pkl", "wb"))
    pickle.dump(label_encoder, open(f"{model_save_dir}/difficulty_label_encoder.pkl", "wb"))
    pickle.dump(categorical_encoders, open(f"{model_save_dir}/difficulty_categorical_encoders.pkl", "wb"))

    print("  ✓ Artifacts saved")

    # Return metrics
    print("\n[6/6] Training complete")
    metrics = {
        "train_accuracy": float(train_acc),
        "eval_accuracy": float(eval_acc),
        "cv_score": float(cv_mean),
        "cv_std": float(cv_std),
        "overfitting_gap": float(train_acc - eval_acc),
        "classes": label_encoder.classes_.tolist(),
    }

    return metrics


if __name__ == "__main__":
    # Paths
    train_path = "data/processed/difficulty_prediction_train_clean.csv"
    eval_path = "data/processed/difficulty_prediction_eval_validated.csv"
    model_dir = "ml/model"

    # Load data
    print("Loading data...")
    train_df = pd.read_csv(train_path)
    eval_df = pd.read_csv(eval_path)
    print(f"Training samples: {len(train_df)}")
    print(f"Eval samples: {len(eval_df)}")

    # Train model
    metrics = train_difficulty_prediction_model(train_df, eval_df, model_dir)
    print("\nTraining metrics:")
    for key, value in metrics.items():
        if key != "classes":
            print(f"  {key}: {value}")
