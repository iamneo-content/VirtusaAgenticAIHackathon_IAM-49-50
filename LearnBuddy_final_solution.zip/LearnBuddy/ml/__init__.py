"""
LearnBuddy ML Pipeline Module

Function-based architecture (VentureLens pattern):
- No class-based trainers or cleaners
- All logic in standalone functions
- Single responsibility per function

Exports:
- Cleaning functions: clean_gap_data, clean_difficulty_data
- Training functions: train_gap_detection_model, train_difficulty_prediction_model
"""

from .cleaning.clean_gap_data import clean_gap_data
from .cleaning.clean_difficulty_data import clean_difficulty_data
from .train_model.train_gap_model import train_gap_detection_model
from .train_model.train_difficulty_model import train_difficulty_prediction_model

__all__ = [
    # Cleaning functions
    "clean_gap_data",
    "clean_difficulty_data",
    # Training functions
    "train_gap_detection_model",
    "train_difficulty_prediction_model",
]
