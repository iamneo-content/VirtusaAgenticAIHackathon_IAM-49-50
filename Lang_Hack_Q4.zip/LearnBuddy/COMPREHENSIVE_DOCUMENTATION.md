LEARNBUDDY MICRO - COMPREHENSIVE PROJECT DOCUMENTATION
=======================================================

PROJECT OVERVIEW
================

LearnBuddy Micro is an AI-powered personalized learning plan generation system that orchestrates
multiple specialized agents to analyze learner profiles, identify knowledge gaps, predict optimal
difficulty levels, and generate three customized learning plans with personalized coaching guidance.

The system combines logic-based agents, machine learning models, and large language models in a
coordinated workflow managed by LangGraph for reliable state management and error handling.

PROBLEM STATEMENT
=================

Core Challenge:
Develop a multi-agent system that can analyze diverse learner profiles and generate personalized
learning recommendations by:
- Parsing and validating complex nested learner profile structures
- Extracting meaningful features from unstructured profile data
- Predicting learning gaps using multi-label classification
- Predicting optimal difficulty using multi-class classification
- Generating three plan variants using LLMs
- Validating plans for feasibility and quality
- Adapting content to individual learning styles
- Generating professional reports with quality metrics
- Handling errors gracefully without losing intermediate results
- Managing parallel execution of independent tasks for performance

Requirements:
+ Parse and validate diverse learner profile formats with 7 required sections
+ Extract 6 feature groups from normalized profiles
+ Identify 1-12 learning gap categories with confidence scores
+ Predict 3 difficulty levels: Beginner, Intermediate, Advanced
+ Generate 3 plan variants: Conservative, Standard, Aggressive
+ Validate all plans against 6 different criteria
+ Rewrite plans in 5 different adaptive tones
+ Calculate 7 quality metrics for assessment
+ Execute 2 ML tasks in parallel for performance optimization
+ Complete entire workflow in 8-12 seconds per learner


SYSTEM ARCHITECTURE
===================



Pipeline Components:

Entry Points:
- main.py: Streamlit web interface for interactive use
- graph.py: Programmatic API for batch/integration use

State Management:
- state.py: MicroPlanState TypedDict with 40+ fields tracking complete workflow

Orchestration:
- workflow.py: LangGraph DAG assembly with 8 nodes and parallel execution

Node Execution Layer:
- profile_parser_node.py: Input validation and normalization
- profile_analyzer_node.py: Feature extraction
- gap_detector_node.py: ML-based gap detection
- difficulty_predictor_node.py: ML-based difficulty prediction
- plan_generator_node.py: LLM-based plan generation
- plan_validator_node.py: LLM-based plan validation
- coach_rewriter_node.py: LLM-based adaptive rewriting
- report_saver_node.py: Report generation and persistence

Agent Layer:
+ ProfileParserAgent: Logic-based validation and normalization
+ ProfileAnalyzerAgent: Logic-based feature extraction
+ GapDetectionMLAgent: ML classification for learning gaps
+ DifficultyPredictionMLAgent: ML classification for difficulty levels
+ PlanGeneratorLLMAgent: LLM-based plan generation
+ PlanValidatorAgent: LLM-based plan validation
+ CoachRewriterLLMAgent: LLM-based adaptive rewriting
+ ReportSaverAgent: LLM-based report generation

Infrastructure:
- ML models: 9 trained artifacts (gap and difficulty models)
- Data: Sample profiles and training datasets
- Output: Generated reports per learner


FILE STRUCTURE AND PURPOSES
============================

ROOT DIRECTORY
==============

main.py (295 lines)
-------------------
Purpose: Streamlit web interface providing interactive user experience
Type: Web Application
Framework: Streamlit
Entry Command: streamlit run main.py

Key Methods:
+ main()
  Parameters: None
  Returns: None
  Side Effects: Renders complete Streamlit application
  Behavior:
    - Initializes page configuration
    - Loads learner profiles from file system
    - Renders sidebar with profile selector
    - Creates 5-tab interface for results display
    - Handles button clicks and triggers workflow execution
    - Displays analysis, plans, recommendations, reports, downloads

+ st.selectbox() integration
  Loads available profiles from: /data/input/learner_profiles/
  Displays: 15 sample learner profiles for selection

+ st.tabs() layout
  Tab 1 - Analysis: Shows identified gaps, urgency level, difficulty
  Tab 2 - Plans: Displays 3 plan variants side-by-side
  Tab 3 - Recommendations: Shows coach notes for each variant
  Tab 4 - Full Report: Professional prose report
  Tab 5 - Download: JSON and text file exports

+ st.metric() components
  Profile Completeness: Percentage score
  Gap Detection Accuracy: Percentage score
  Plan Feasibility: Percentage score
  Overall Quality: Percentage score

Output: Rendered Streamlit UI with 5 tabs displaying personalized learning plans

graph.py (92 lines)
-------------------
Purpose: Programmatic API for non-interactive batch processing
Type: Python Module API
Usage: Import and call functions directly

Key Methods:

+ run_microplan(learner_json: Dict[str, Any]) -> MicroPlanState
  Parameters:
    learner_json (Dict): Learner profile as dictionary
  Returns: Complete MicroPlanState with all analysis and generated plans
  Purpose: Main entry point for programmatic workflow execution
  Behavior: Calls run_microplan_workflow() and returns state
  Example Usage:
    import json
    with open("data/input/learner_profiles/learn_001.json") as f:
        learner = json.load(f)
    result = run_microplan(learner)

+ run_microplan_from_file(file_path: str) -> MicroPlanState
  Parameters:
    file_path (str): Path to learner JSON profile
  Returns: Complete MicroPlanState
  Purpose: Load profile from file and execute workflow
  Behavior: Opens file, parses JSON, calls run_microplan()

+ get_microplan_summary(result: MicroPlanState) -> Dict[str, Any]
  Parameters:
    result (MicroPlanState): Completed workflow state
  Returns: Dictionary with key metrics only
  Purpose: Extract essential information from complete state
  Content:
    - learner_id: Unique identifier
    - identified_gaps: List of detected gaps
    - urgency_level: Priority level
    - recommended_difficulty: Beginner/Intermediate/Advanced
    - difficulty_confidence: 0-1 confidence score
    - validation_issues: List of warnings
    - quality_score: Overall quality percentage
    - output_directory: Path to saved reports

+ print_microplan_summary(result: MicroPlanState) -> None
  Parameters:
    result (MicroPlanState): Completed workflow state
  Returns: None
  Side Effects: Prints formatted summary to console
  Purpose: Display results in human-readable format
  Output Format: Formatted text with ASCII separators and structured sections


state.py (370 lines)
--------------------
Purpose: Complete state management for workflow execution
Type: State Schema and Utilities Module

Key Data Structures:

MicroPlanState (TypedDict):
Complete state dictionary with 40+ fields tracking workflow progress

Input Fields:
+ learner_json (Dict): Raw input profile
+ learner_id (str): Unique learner identifier

Profile Processing:
+ normalized_profile (Dict): Cleaned and validated profile
+ profile_complete (bool): Completion flag

Analysis Fields:
+ analyzed_profile (Dict): Extracted features in 6 groups
+ derived_metrics (Dict): Calculated metrics
+ analysis_complete (bool): Completion flag

ML Prediction Fields:
+ identified_gaps (List[str]): 1-12 gap categories
+ gap_confidence_scores (Dict): Confidence per gap
+ urgency_level (str): critical/high/medium/low
+ gap_detection_complete (bool): Completion flag
+ recommended_difficulty (str): Beginner/Intermediate/Advanced
+ difficulty_confidence (float): 0-1 confidence
+ difficulty_prediction_complete (bool): Completion flag

Plan Generation:
+ plan_variant_a (Dict): Conservative plan
+ plan_variant_b (Dict): Standard plan
+ plan_variant_c (Dict): Aggressive plan
+ plan_generation_complete (bool): Completion flag

Validation & Rewriting:
+ plan_variant_a/b/c_validated (Dict): Validated plans
+ validation_issues (List[str]): Issues found
+ validation_complete (bool): Completion flag
+ variant_a/b/c_friendly (str): Friendly versions
+ rewriting_complete (bool): Completion flag

Reporting:
+ final_report (str): Text report
+ report_json (Dict): Structured report
+ quality_metrics (Dict): 7 quality scores
+ saved_path (str): Report file path
+ output_dir (str): Output directory path
+ report_complete (bool): Completion flag

Error Tracking:
+ error_occurred (bool): Error flag
+ error_messages (List[str]): Error log

Key Methods:

+ get_initial_state(learner_json: Dict[str, Any]) -> MicroPlanState
  Parameters:
    learner_json (Dict): Input learner profile
  Returns: Initialized MicroPlanState with all defaults
  Purpose: Create clean initial state for workflow
  Behavior: Sets all 40+ fields to defaults (empty lists, False, etc.)

+ create_output_directory(learner_id: str) -> str
  Parameters:
    learner_id (str): Learner identifier
  Returns: Path to created directory
  Purpose: Create /output/{learner_id}/ directory
  Behavior: Creates nested directories with mkdir(parents=True)

+ save_file(file_path: str, content: str) -> bool
  Parameters:
    file_path (str): Target file path
    content (str): Content to write
  Returns: True if successful, False if error
  Purpose: Save content to file with error handling
  Behavior: Creates parent directories, writes file, catches exceptions

+ format_microplan_report(state: MicroPlanState) -> str
  Parameters:
    state (MicroPlanState): Completed workflow state
  Returns: Formatted text report as string
  Purpose: Format state into professional 7-section report
  Sections:
    1. Learner Information
    2. Goal Summary
    3. Current Proficiency
    4. Analysis Results
    5. Plan Variants A/B/C
    6. Quality Metrics
    7. Recommendations and Disclaimer

+ calculate_quality_score(state: MicroPlanState) -> Dict[str, float]
  Parameters:
    state (MicroPlanState): Completed workflow state
  Returns: Dictionary with 7 quality metrics
  Purpose: Calculate quality assessment metrics
  Metrics Calculated:
    - profile_completeness (0-1)
    - gap_detection_accuracy (gaps/12)
    - difficulty_confidence (from ML model)
    - plan_feasibility (0.85 if valid, 0.65 if issues)
    - coaching_adaptation (0.90 if rewritten, 0.0 if not)
    - report_completeness (1.0 if generated)
    - overall_quality (average of above)

+ slugify(text: str, max_length: int = 50) -> str
  Parameters:
    text (str): Text to convert
    max_length (int): Maximum length of result (default 50)
  Returns: URL-safe slug string
  Purpose: Convert text to filename-safe format
  Example: "Severe Chest Pain" becomes "severe_chest_pain"

+ extract_learner_metrics(state: MicroPlanState) -> Dict[str, Any]
  Parameters:
    state (MicroPlanState): Current state
  Returns: Dictionary with learner characteristics
  Purpose: Extract key metrics for assessment
  Content: Age, education, learning style, domain, scores, hours, timeline

Utility Functions:

+ format_list(items: List[str]) -> str
  Converts list to bullet-pointed string format

+ format_plan(plan: Dict[str, Any]) -> str
  Formats single plan with duration, topics, resources, milestones

+ format_metrics(metrics: Dict[str, float]) -> str
  Formats metrics dictionary with percentages and values

+ get_timestamp() -> str
  Returns current timestamp in UTC format


WORKFLOW DIRECTORY
==================

workflow.py (106 lines)
-----------------------
Purpose: LangGraph workflow assembly and orchestration
Type: Workflow Definition Module
Framework: LangGraph

Key Methods:

+ build_workflow() -> CompiledStateGraph
  Parameters: None
  Returns: Compiled LangGraph workflow object
  Purpose: Assemble complete DAG with 8 nodes and edges
  Behavior:
    1. Creates StateGraph with MicroPlanState
    2. Adds 8 nodes (profile_parser through report_saver)
    3. Sets entry point to profile_parser
    4. Adds linear edges: parser -> analyzer
    5. Adds parallel edges: analyzer -> gap_detector AND difficulty_predictor
    6. Adds convergence edges: both ML nodes -> plan_generator
    7. Adds linear edges: generator -> validator -> rewriter -> saver
    8. Compiles and returns graph

Edge Configuration:
Entry: profile_parser
Linear: profile_parser -> profile_analyzer
Parallel: profile_analyzer -> [gap_detector, difficulty_predictor]
Convergence: gap_detector -> plan_generator, difficulty_predictor -> plan_generator
Linear: plan_generator -> plan_validator
Linear: plan_validator -> coach_rewriter
Linear: coach_rewriter -> report_saver
Exit: report_saver -> END

+ run_microplan_workflow(learner_json: dict) -> MicroPlanState
  Parameters:
    learner_json (dict): Learner profile input
  Returns: Final MicroPlanState after all nodes execute
  Purpose: Execute complete workflow from start to end
  Behavior:
    1. Builds workflow using build_workflow()
    2. Initializes state using get_initial_state()
    3. Prints workflow progress banners
    4. Invokes workflow with initial state
    5. Returns final state with all results
    6. Prints completion banner

Process Flow:
Input: learner_json
Initialize state
Execute 8 nodes sequentially with parallel branches
Return completed state with analysis, plans, validation, reports


NODES DIRECTORY
===============

profile_parser_node.py (40 lines)
---------------------------------
Purpose: First node in workflow - validates and normalizes input profiles
Type: LangGraph Node
Called By: workflow.py (entry point)
Calls: agents/profile_parser.py::parse_learner_profile()

Function:

+ profile_parser_node(state: MicroPlanState) -> dict
  Parameters:
    state (MicroPlanState): Initial workflow state
  Returns: Dictionary with updated state fields
  Purpose: Parse and validate learner JSON profile
  Behavior:
    1. Extracts learner_json from state
    2. Calls parse_learner_profile() agent
    3. If validation fails, returns error state
    4. If successful, returns normalized_profile and profile_complete=True
  Output State Updates:
    - normalized_profile (Dict): Cleaned profile
    - profile_complete (bool): True/False
    - error_occurred (bool): False if success, True if error
    - error_messages (List): Appended with errors if any

Validation Checks:
- 7 required fields present
- Correct types for each field
- Nested structure validation
- Data range validation


profile_analyzer_node.py (34 lines)
------------------------------------
Purpose: Second node - extracts 6 feature groups from normalized profile
Type: LangGraph Node
Called By: workflow.py (after profile_parser)
Calls: agents/profile_analyzer.py::analyze_learner_profile()

Function:

+ profile_analyzer_node(state: MicroPlanState) -> dict
  Parameters:
    state (MicroPlanState): State with normalized_profile
  Returns: Dictionary with updated state fields
  Purpose: Extract meaningful features for ML and LLM agents
  Behavior:
    1. Extracts normalized_profile from state
    2. Calls analyze_learner_profile() agent
    3. Extracts 6 feature groups and derived metrics
    4. Returns analyzed_profile and analysis_complete=True
  Output State Updates:
    - analyzed_profile (Dict): Feature extraction result
    - derived_metrics (Dict): Calculated metrics
    - analysis_complete (bool): True

Feature Groups Extracted:
1. Demographics: age, timezone, country, education_level, years_educated, field_of_study
2. Learning Characteristics: style, pace, duration, formats, instructor_type, gamification
3. Proficiency: domain, topic, scores, projects, challenges
4. Goals: primary/secondary goals, timeline, clarity_score, alignment
5. Constraints: hours/week, budget, employment, time_pressure_score
6. History: courses_completed, completion_rates, trend, consistency_score


gap_detector_node.py (35 lines)
--------------------------------
Purpose: Third node (Parallel) - ML-based gap detection
Type: LangGraph Node - Parallel Execution
Called By: workflow.py (parallel with difficulty_predictor)
Calls: agents/gap_detection_ml.py::GapDetectionMLAgent.detect_gaps_main()

Function:

+ gap_detector_node(state: MicroPlanState) -> dict
  Parameters:
    state (MicroPlanState): State with analyzed_profile
  Returns: Dictionary with gap detection results
  Purpose: Identify 1-12 learning gaps using trained ML model
  Behavior:
    1. Extracts analyzed_profile from state
    2. Calls GapDetectionMLAgent to detect gaps
    3. Returns identified gaps with confidence scores
    4. Calculates urgency level based on gaps and profile
    5. Sets gap_detection_complete=True
  Output State Updates:
    - identified_gaps (List[str]): Gap categories detected
    - gap_confidence_scores (Dict): Confidence per gap
    - urgency_level (str): critical/high/medium/low
    - gap_detection_complete (bool): True

ML Model Details:
Model Type: OneVsRest + LinearSVC (Multi-label classification)
Features: TF-IDF text + 15 numeric features
Gap Categories: 12 possible categories
Output: List of detected gaps with 0-1 confidence per gap


difficulty_predictor_node.py (34 lines)
----------------------------------------
Purpose: Third node (Parallel) - ML-based difficulty prediction
Type: LangGraph Node - Parallel Execution
Called By: workflow.py (parallel with gap_detector)
Calls: agents/difficulty_prediction_ml.py::DifficultyPredictionMLAgent.predict_difficulty()

Function:

+ difficulty_predictor_node(state: MicroPlanState) -> dict
  Parameters:
    state (MicroPlanState): State with analyzed_profile
  Returns: Dictionary with difficulty prediction
  Purpose: Predict optimal difficulty level using trained ML model
  Behavior:
    1. Extracts analyzed_profile from state
    2. Calls DifficultyPredictionMLAgent to predict difficulty
    3. Returns difficulty level and confidence score
    4. Handles feature mismatch with graceful fallback
    5. Sets difficulty_prediction_complete=True
  Output State Updates:
    - recommended_difficulty (str): Beginner/Intermediate/Advanced
    - difficulty_confidence (float): 0-1 confidence score
    - difficulty_prediction_complete (bool): True

ML Model Details:
Model Type: RandomForest (3-class classification)
Classes: Beginner, Intermediate, Advanced
Features: 16 numeric + 8 categorical features
Graceful Fallback: Returns (Intermediate, 0.5) on feature mismatch


plan_generator_node.py (47 lines)
----------------------------------
Purpose: Fourth node - LLM-based plan generation
Type: LangGraph Node - Convergence Point
Called By: workflow.py (after both parallel ML nodes complete)
Calls: agents/plan_generator_llm.py::generate_microlearning_plans()

Function:

+ plan_generator_node(state: MicroPlanState) -> dict
  Parameters:
    state (MicroPlanState): State with analysis and ML results
  Returns: Dictionary with 3 generated plans
  Purpose: Generate 3 micro-learning plan variants using LLM
  Behavior:
    1. Extracts analyzed_profile, identified_gaps, recommended_difficulty
    2. Calls generate_microlearning_plans() agent
    3. Receives 3 plan dictionaries (variant A, B, C)
    4. Returns all plans with plan_generation_complete=True
    5. Handles JSON parsing errors gracefully
  Output State Updates:
    - plan_variant_a (Dict): Conservative plan
    - plan_variant_b (Dict): Standard plan
    - plan_variant_c (Dict): Aggressive plan
    - plan_generation_complete (bool): True
    - error_occurred (bool): True if JSON parsing fails

Plan Variants:

Variant A - Conservative:
  Timeline: target_timeline * 1.5 months
  Hours/Week: 8
  Intensity: low
  Includes Prerequisites: Yes
  Focus: First 3 gaps

Variant B - Standard:
  Timeline: target_timeline * 1.0 months
  Hours/Week: 10
  Intensity: medium
  Includes Prerequisites: Yes
  Focus: First 5 gaps

Variant C - Aggressive:
  Timeline: target_timeline * 0.7 months
  Hours/Week: 15
  Intensity: high
  Includes Prerequisites: No
  Focus: All gaps

Plan Dictionary Fields:
+ variant (str): conservative/standard/aggressive
+ duration_weeks (int): Number of weeks
+ hours_per_week (int): Weekly commitment
+ total_hours (int): Total hours required
+ intensity (str): low/medium/high
+ topics (List[str]): Topics to cover
+ resources (List[str]): Recommended resources
+ milestones (List[str]): 4 major milestones
+ success_criteria (List[str]): Success criteria
+ difficulty_progression (str): How difficulty increases


plan_validator_node.py (53 lines)
----------------------------------
Purpose: Fifth node - LLM-based plan validation
Type: LangGraph Node
Called By: workflow.py (after plan_generator)
Calls: agents/plan_validator.py::validate_plans()

Function:

+ plan_validator_node(state: MicroPlanState) -> dict
  Parameters:
    state (MicroPlanState): State with generated plans
  Returns: Dictionary with validated plans and issues
  Purpose: Validate all 3 plans for feasibility and quality
  Behavior:
    1. Extracts plan variants from state
    2. Calls validate_plans() agent with LLM
    3. Validates against 6 criteria
    4. Returns validated plans and validation_issues list
    5. Sets validation_complete=True
  Output State Updates:
    - plan_variant_a/b/c_validated (Dict): Validated plans
    - validation_issues (List[str]): Issues found
    - validation_complete (bool): True

Validation Checks:
1. Time Feasibility: Can learner complete in allocated hours?
2. Goal Alignment: Do plans address identified gaps?
3. Prerequisite Coverage: Are prerequisites included and ordered correctly?
4. Difficulty Progression: Is difficulty increase gradual or too steep?
5. Topic Relevance: Are topics relevant to learner's domain?
6. Milestone Realism: Are milestones achievable in given timeframe?


coach_rewriter_node.py (37 lines)
----------------------------------
Purpose: Sixth node - LLM-based adaptive rewriting
Type: LangGraph Node
Called By: workflow.py (after plan_validator)
Calls: agents/coach_rewriter_llm.py::rewrite_learning_plans()

Function:

+ coach_rewriter_node(state: MicroPlanState) -> dict
  Parameters:
    state (MicroPlanState): State with validated plans
  Returns: Dictionary with friendly rewritten versions
  Purpose: Rewrite plans in adaptive, motivational language
  Behavior:
    1. Extracts validated plans from state
    2. Determines tone based on learner age and learning_style
    3. Calls rewrite_learning_plans() agent
    4. Returns 3 friendly versions with emojis and formatting
    5. Sets rewriting_complete=True
  Output State Updates:
    - variant_a_friendly (str): Friendly conservative plan
    - variant_b_friendly (str): Friendly standard plan
    - variant_c_friendly (str): Friendly aggressive plan
    - rewriting_complete (bool): True

Tone Determination:
+ Age < 18: encouraging_youth tone
+ Learning Style auditory: conversational tone
+ Learning Style kinesthetic: practical_action_oriented tone
+ Learning Style visual: visual_metaphor_based tone
+ Default: analytical tone

Friendly Version Components:
1. Motivational overview
2. Inspiring learning journey breakdown
3. Resource context and rationale
4. Achievable success criteria presentation
5. Personalized pro tips
6. Encouraging conclusion
7. Markdown formatting with emojis and headers


report_saver_node.py (36 lines)
--------------------------------
Purpose: Seventh node - Report generation and persistence
Type: LangGraph Node
Called By: workflow.py (after coach_rewriter)
Calls: agents/report_saver.py::save_microplan_report()

Function:

+ report_saver_node(state: MicroPlanState) -> dict
  Parameters:
    state (MicroPlanState): Complete state with all analysis
  Returns: Dictionary with saved file paths and metrics
  Purpose: Generate professional reports and save to disk
  Behavior:
    1. Calls save_microplan_report() agent
    2. Generates 3 output files
    3. Calculates 7 quality metrics
    4. Returns paths and metrics
    5. Sets report_complete=True
  Output State Updates:
    - saved_path (str): Path to text report
    - output_dir (str): Output directory path
    - quality_metrics (Dict): 7 quality scores
    - report_complete (bool): True

Generated Files:

1. micro_plan_report.txt (Professional prose report):
   Location: /output/{learner_id}/micro_plan_report.txt
   Format: Plain text with sections
   Sections:
   - Learner Information (name, age, education, style)
   - Goal Summary (primary/secondary goals, timeline)
   - Current Proficiency (assessment and performance)
   - Analysis Results (gaps, urgency, difficulty)
   - Personalized Micro-Learning Plans (A, B, C variants)
   - Quality Metrics (7 scores displayed)
   - Recommendations and Success Strategies

2. micro_plan.json (Structured data report):
   Location: /output/{learner_id}/micro_plan.json
   Format: JSON with nested structure
   Content:
   + metadata: timestamp, system version
   + learner_profile: personal info and goals
   + analysis_results: extracted features and metrics
   + identified_gaps: gap list with confidence scores
   + learning_plans: 3 plan variants with all details
   + recommendations: coach notes and success strategies
   + quality_metrics: 7 metric scores

3. evaluation_metrics.json (Quality assessment):
   Location: /output/{learner_id}/evaluation_metrics.json
   Format: JSON flat structure
   Metrics:
   + profile_completeness (0-1): Field coverage score
   + gap_detection_accuracy (0-1): Gaps / 12
   + difficulty_confidence (0-1): ML model confidence
   + plan_feasibility (0-1): Alignment with constraints
   + coaching_adaptation (0-1): Rewriting quality
   + report_completeness (0-1): Always 1.0 if generated
   + overall_quality (0-1): Average of above metrics


AGENTS DIRECTORY
================

agents/profile_parser.py (164 lines)
------------------------------------
Purpose: Logic-based agent for profile validation and normalization
Type: Agent Module
Used By: profile_parser_node.py

Class: ProfileParserAgent

+ __init__()
  Initializes: errors list, warnings list
  Purpose: Set up validation state

+ validate_profile(profile: Dict[str, Any]) -> Tuple[bool, List, List]
  Parameters:
    profile (Dict): Learner profile to validate
  Returns: Tuple of (is_valid boolean, errors list, warnings list)
  Purpose: Validate profile structure and content
  Behavior:
    1. Checks 7 required fields and types
    2. Validates nested structures
    3. Checks data ranges and valid values
    4. Collects errors and warnings
    5. Returns validation result

Validation Methods:

+ _validate_personal_info(info: Dict)
  Checks: Age 8-100, languages non-empty

+ _validate_educational_background(background: Dict)
  Checks: Education level in valid set, GPA 0-4.0

+ _validate_learning_profile(profile: Dict)
  Checks: Learning style in valid set, focus_duration 5-240 minutes

+ _validate_current_status(status: Dict)
  Checks: Proficiency score 0-100

+ _validate_learning_goals(goals: Dict)
  Checks: Timeline 1-60 months

+ _validate_constraints(constraints: Dict)
  Checks: Hours 0-168/week, budget >= 0

+ normalize_profile(profile: Dict[str, Any]) -> Dict
  Parameters:
    profile (Dict): Profile to normalize
  Returns: Normalized profile dictionary
  Purpose: Clean and standardize profile data
  Behavior: Lowercases strings, preserves types, normalizes nested dicts

+ _normalize_dict(d: Dict) -> Dict
  Helper for recursively normalizing dictionaries

+ parse(learner_json: Dict[str, Any]) -> Tuple
  Parameters:
    learner_json (Dict): Raw learner profile
  Returns: Tuple of (normalized profile, is_valid boolean, messages list)
  Purpose: Main entry point for parsing
  Behavior: Validates then normalizes profile

Function: parse_learner_profile(learner_json: Dict) -> Tuple
  Convenience function that creates agent instance and calls parse()


agents/profile_analyzer.py (220 lines)
--------------------------------------
Purpose: Logic-based agent for feature extraction and metric calculation
Type: Agent Module
Used By: profile_analyzer_node.py

Class: ProfileAnalyzerAgent

+ analyze(normalized_profile: Dict) -> Dict
  Parameters:
    normalized_profile (Dict): Normalized learner profile
  Returns: Dictionary with analyzed profile containing 6 feature groups
  Purpose: Extract meaningful features for ML and LLM agents
  Behavior: Calls 6 extraction methods and returns complete analysis

Feature Extraction Methods:

+ _extract_demographics(profile: Dict) -> Dict
  Returns: age, timezone, country, education_level, years_educated, field_of_study
  Calculations: years_educated = age - 6 (estimate)

+ _extract_learning_characteristics(profile: Dict) -> Dict
  Returns: learning_style, pace, focus_duration, break_preference, formats,
           instructor_type, gamification_preference, community_engagement

+ _extract_proficiency(profile: Dict) -> Dict
  Returns: domain, topic, self_assessed_score, standardized_test_score,
           assessment_date, current_projects, challenges

+ _extract_goals(profile: Dict) -> Dict
  Returns: primary_goal, secondary_goals, target_timeline_months, desired_outcome,
           career_aspiration, goal_clarity_score, goal_alignment
  Calculations:
    goal_clarity_score: 50 (default), 60 (primary goal), 80 (primary + secondary)

+ _extract_constraints(profile: Dict) -> Dict
  Returns: hours_per_week, budget_limit_usd, certification_needed,
           employment_status, preferred_study_time, time_pressure_score,
           financial_constraint
  Calculations:
    time_pressure_score: min(100, max(0, 100 * (1 - (hours * 4 * months) / 200)))

+ _analyze_learning_history(profile: Dict) -> Dict
  Returns: courses_completed, avg_completion_rate, avg_score,
           learning_trend, avg_time_per_course, consistency_score
  Calculations:
    learning_trend: "improving"/"declining"/"stable"/"unknown"
    consistency_score: 1.0 - (std_dev / 100)

Helper Methods:

+ _calculate_goal_alignment(goals: Dict, preferences: Dict) -> float
  Returns: 0-1 alignment score
  Logic: Base 0.5 + 0.2 for career aspiration + 0.2 for timeline + 0.1 for project-based

+ _calculate_consistency(completion_rates: List) -> float
  Returns: 0-1 consistency score
  Logic: Based on standard deviation of completion rates

Function: analyze_learner_profile(normalized_profile: Dict) -> Dict
  Convenience function that creates agent and calls analyze()


agents/gap_detection_ml.py (207 lines)
--------------------------------------
Purpose: Machine learning agent for multi-label gap detection
Type: ML Agent Module
Used By: gap_detector_node.py
Model: Trained OneVsRest + LinearSVC classifier

Module-Level Variables:
+ _gap_model: Loaded ML model
+ _gap_vectorizer: TF-IDF vectorizer
+ _gap_mlb: MultiLabelBinarizer
+ _gap_scaler: StandardScaler
+ _gap_labels: Label names JSON

Functions:

+ load_gap_artifacts() -> None
  Parameters: None
  Purpose: Load trained model artifacts from pkl files
  Behavior:
    1. Loads gap_model.pkl (OneVsRest classifier)
    2. Loads gap_vectorizer.pkl (TF-IDF)
    3. Loads gap_mlb.pkl (MultiLabelBinarizer)
    4. Loads gap_scaler.pkl (StandardScaler)
    5. Loads gap_labels.json (label names)
  Side Effects: Sets module-level variables

+ prepare_gap_text_features(profile: Dict) -> str
  Parameters:
    profile (Dict): Analyzed profile
  Returns: Concatenated text string
  Purpose: Extract text features for TF-IDF
  Features Used: domain + learning_style + challenges + desired_outcome

+ prepare_gap_numeric_features(profile: Dict) -> ndarray
  Parameters:
    profile (Dict): Analyzed profile
  Returns: NumPy array of 15 numeric features
  Purpose: Extract numeric features for scaling
  Features: age, hours_per_week, self_assessed_score, standardized_test_score,
           focus_duration, goal_clarity, time_pressure, consistency, motivation,
           learning_pace, budget, num_gaps, gpa, years_exp, target_timeline

+ detect_gaps_main(profile: Dict) -> Dict
  Parameters:
    profile (Dict): Analyzed profile
  Returns: Dictionary with gaps, confidence scores, and urgency
  Purpose: Main entry point for gap detection
  Behavior:
    1. Prepares text and numeric features
    2. Vectorizes text with TF-IDF
    3. Scales numeric features
    4. Combines features via hstack
    5. Predicts with ML model
    6. Decodes predictions to gap labels
    7. Calculates confidence scores
    8. Determines urgency level

Class: GapDetectionMLAgent

+ detect_gaps_main(profile: Dict) -> Dict
  Alternative entry point using class wrapper


agents/difficulty_prediction_ml.py (221 lines)
----------------------------------------------
Purpose: Machine learning agent for difficulty level classification
Type: ML Agent Module
Used By: difficulty_predictor_node.py
Model: Trained RandomForest classifier

Module-Level Variables:
+ _difficulty_model: Loaded RandomForest model
+ _difficulty_scaler: StandardScaler
+ _difficulty_label_encoder: LabelEncoder
+ _difficulty_categorical_encoders: OneHotEncoders dict

Functions:

+ load_difficulty_artifacts() -> None
  Parameters: None
  Purpose: Load trained model artifacts
  Behavior: Loads all 4 difficulty model artifacts from pkl files

+ prepare_difficulty_features(profile: Dict) -> Tuple[ndarray, dict]
  Parameters:
    profile (Dict): Analyzed profile
  Returns: Tuple of (numeric features array, categorical features dict)
  Purpose: Extract all 24 features for model
  Numeric Features (16): age, hours_per_week, self_assessed_score,
                         learning_pace_factor, avg_time_per_course, consistency,
                         goal_alignment, courses_completed, avg_score,
                         completion_rate, complexity, prerequisites,
                         prerequisites_mastery, hours_to_master,
                         weeks_available, deadline_weeks
  Categorical Features (8): education_level, learning_style,
                            employment_status, trend, motivation,
                            career_urgency, preferred_difficulty, budget

+ predict_difficulty(profile: Dict) -> Dict
  Parameters:
    profile (Dict): Analyzed profile
  Returns: Dictionary with difficulty, confidence, and status
  Purpose: Main entry point for difficulty prediction
  Behavior:
    1. Prepares numeric and categorical features
    2. Scales numeric features
    3. One-hot encodes categorical features
    4. Combines features
    5. Predicts class with RandomForest
    6. Returns difficulty and confidence
    7. Handles missing features with fallback (Intermediate, 0.5)

Class: DifficultyPredictionMLAgent

+ predict_difficulty(profile: Dict) -> Dict
  Alternative entry point using class wrapper


agents/plan_generator_llm.py (124 lines)
----------------------------------------
Purpose: LLM-based agent for generating 3 learning plan variants
Type: LLM Agent Module
Used By: plan_generator_node.py
LLM: Google Gemini 2.0 Flash

Class: PlanGeneratorLLMAgent

+ __init__()
  Purpose: Initialize LLM connection
  Behavior:
    1. Loads GEMINI_API_KEY_1 from environment
    2. Creates ChatGoogleGenerativeAI instance
    3. Sets temperature=0.3 for consistency
    4. Handles fallback to mock mode if API unavailable

+ generate_plans(analyzed_profile: Dict, gaps: List, difficulty: str) -> Tuple[Dict, Dict, Dict]
  Parameters:
    analyzed_profile (Dict): Analyzed learner profile
    gaps (List[str]): Identified learning gaps
    difficulty (str): Recommended difficulty level
  Returns: Tuple of 3 plan dictionaries (A, B, C)
  Purpose: Generate 3 micro-learning plan variants
  Behavior:
    1. Extracts domain and timeline from profile
    2. Creates 3 variants with different parameters
    3. Calls _create_plan_variant for each
    4. Returns tuple of 3 plans

+ _create_plan_variant(domain, variant, timeline, intensity, focus_areas, prerequisites) -> Dict
  Parameters:
    domain (str): Learning domain
    variant (str): "conservative"/"standard"/"aggressive"
    timeline (float): Duration in months
    intensity (str): "low"/"medium"/"high"
    focus_areas (List[str]): Gaps to address
    prerequisites (bool): Include prerequisites
  Returns: Dictionary with complete plan
  Purpose: Create single plan variant using LLM
  Behavior:
    1. Calculates weeks and hours_per_week based on intensity
    2. Creates prompt for LLM
    3. Invokes Gemini model
    4. Extracts JSON from response via regex
    5. Parses JSON and validates structure
    6. Returns plan dictionary with all fields

Plan Dictionary Structure:
+ variant: "conservative"/"standard"/"aggressive"
+ duration_weeks: int
+ hours_per_week: int
+ total_hours: int
+ intensity: "low"/"medium"/"high"
+ topics: List[str]
+ resources: List[str]
+ milestones: List[str]
+ success_criteria: List[str]
+ difficulty_progression: str

Function: generate_microlearning_plans(analyzed_profile, gaps, difficulty) -> Tuple
  Convenience function that creates agent and calls generate_plans()


agents/plan_validator.py (141 lines)
------------------------------------
Purpose: LLM-based agent for validating generated learning plans
Type: LLM Agent Module
Used By: plan_validator_node.py
LLM: Google Gemini 2.0 Flash

Class: PlanValidatorAgent

+ __init__()
  Purpose: Initialize LLM connection
  Behavior:
    1. Loads GEMINI_API_KEY_4 from environment
    2. Creates ChatGoogleGenerativeAI instance with temperature=0.3

+ validate_plans(plans: Tuple[Dict, Dict, Dict], analyzed_profile: Dict) -> Tuple
  Parameters:
    plans (Tuple): Tuple of 3 plan dictionaries
    analyzed_profile (Dict): Analyzed learner profile
  Returns: Tuple of (validated_plans tuple, issues list)
  Purpose: Validate all 3 plans using LLM
  Behavior:
    1. Validates each plan individually
    2. Collects validation issues
    3. Returns validated plans and issue list

+ _validate_single_plan(plan: Dict, analyzed_profile: Dict) -> Tuple
  Parameters:
    plan (Dict): Single plan to validate
    analyzed_profile (Dict): Learner profile
  Returns: Tuple of (validated plan, issues list)
  Purpose: Validate single plan
  Checks:
    1. Time feasibility: hours_per_week * weeks vs available time
    2. Goal alignment: topics cover identified gaps
    3. Prerequisite coverage and ordering
    4. Difficulty progression appropriateness
    5. Topic relevance to domain
    6. Milestone realism

Validation Process:
1. Creates detailed prompt with plan and profile
2. Invokes Gemini LLM
3. Parses response for issues
4. Returns validated plan with enhanced fields if needed


agents/coach_rewriter_llm.py (100 lines)
----------------------------------------
Purpose: LLM-based agent for rewriting plans in adaptive tone
Type: LLM Agent Module
Used By: coach_rewriter_node.py
LLM: Google Gemini 2.0 Flash

Class: CoachRewriterLLMAgent

+ __init__()
  Purpose: Initialize LLM connection
  Behavior:
    1. Loads GEMINI_API_KEY_2 from environment
    2. Creates ChatGoogleGenerativeAI instance with temperature=0.5

+ rewrite_plans(plans: Tuple[Dict, Dict, Dict], analyzed_profile: Dict) -> Tuple[str, str, str]
  Parameters:
    plans (Tuple): 3 validated plan dictionaries
    analyzed_profile (Dict): Analyzed learner profile
  Returns: Tuple of 3 friendly text versions
  Purpose: Rewrite all 3 plans in adaptive, motivational language
  Behavior:
    1. Determines tone based on learner characteristics
    2. Rewrites each plan with tone
    3. Returns tuple of 3 friendly versions

+ _determine_tone(learning_style: str, age: int) -> str
  Parameters:
    learning_style (str): Visual/Auditory/Kinesthetic/etc.
    age (int): Learner age
  Returns: Tone string
  Purpose: Determine appropriate tone
  Logic:
    - If age < 18: "encouraging_youth"
    - Elif auditory: "conversational"
    - Elif kinesthetic: "practical_action_oriented"
    - Elif visual: "visual_metaphor_based"
    - Else: "analytical"

+ _rewrite_plan(plan: Dict, tone: str, title: str) -> str
  Parameters:
    plan (Dict): Plan to rewrite
    tone (str): Tone to use
    title (str): Plan title
  Returns: Friendly text version
  Purpose: Rewrite single plan using LLM
  Behavior:
    1. Extracts plan details
    2. Creates prompt with tone specification
    3. Invokes Gemini LLM
    4. Returns formatted text response

Friendly Version Components:
1. Motivational overview
2. Learning journey breakdown
3. Resource context
4. Success criteria
5. Pro tips
6. Encouragement


agents/report_saver.py (194 lines)
----------------------------------
Purpose: LLM-based agent for generating and saving final reports
Type: LLM Agent Module
Used By: report_saver_node.py
LLM: Google Gemini 2.0 Flash

Class: ReportSaverAgent

+ __init__()
  Purpose: Initialize agent and output directory
  Behavior:
    1. Sets output base path
    2. Creates directories if needed
    3. Initializes LLM connection with GEMINI_API_KEY_3

+ save_report(state: Dict) -> Dict
  Parameters:
    state (Dict): Complete MicroPlanState
  Returns: Dictionary with file paths and metrics
  Purpose: Generate and save all 3 output files
  Behavior:
    1. Creates learner output directory
    2. Generates LLM-based text report
    3. Creates structured JSON report
    4. Calculates quality metrics
    5. Saves all 3 files
    6. Returns summary dictionary

+ _generate_llm_report(state: Dict) -> str
  Parameters:
    state (Dict): Complete state
  Returns: Professional prose report string
  Purpose: Generate 7-section text report using LLM
  Behavior:
    1. Prepares context from state
    2. Creates detailed prompt
    3. Invokes Gemini LLM
    4. Returns formatted text report

Report Sections:
1. Executive Summary
2. Learning Gap Analysis
3. Personalized Assessment
4. Three Learning Plan Options
5. Recommendations
6. Success Strategies
7. Next Steps

+ _create_json_report(state: Dict) -> Dict
  Parameters:
    state (Dict): Complete state
  Returns: Structured dictionary
  Purpose: Create structured JSON report
  Structure:
    + metadata: timestamp, version
    + learner_profile: basic info and goals
    + analysis_results: extracted features
    + identified_gaps: with confidence
    + learning_plans: 3 plan variants
    + recommendations: coach notes
    + quality_metrics: 7 scores

Output Files Created:

1. micro_plan_report.txt
   Location: /output/{learner_id}/micro_plan_report.txt
   Format: Plain text

2. micro_plan.json
   Location: /output/{learner_id}/micro_plan.json
   Format: JSON

3. evaluation_metrics.json
   Location: /output/{learner_id}/evaluation_metrics.json
   Format: JSON with 7 quality metrics


ML MODELS DIRECTORY
===================

ml/model/ - Trained Model Artifacts

Gap Detection Models (5 files):
+ gap_model.pkl: OneVsRest + LinearSVC classifier
+ gap_vectorizer.pkl: TF-IDF vectorizer for text features
+ gap_scaler.pkl: StandardScaler for numeric features
+ gap_mlb.pkl: MultiLabelBinarizer for gap labels
+ gap_labels.json: 12 gap category names

Difficulty Prediction Models (4 files):
+ difficulty_model.pkl: RandomForest classifier (53MB)
+ difficulty_scaler.pkl: StandardScaler for features
+ difficulty_label_encoder.pkl: LabelEncoder for difficulty classes
+ difficulty_categorical_encoders.pkl: OneHotEncoders for categorical features

ml/train_model/ - Model Training Scripts:
+ train_gap_model.py: Script to train gap detection model
+ train_difficulty_model.py: Script to train difficulty prediction model

ml/cleaning/ - Data Preprocessing:
+ clean_gap_data.py: Preprocessing for gap detection data
+ clean_difficulty_data.py: Preprocessing for difficulty prediction data


DATA DIRECTORY
==============

data/input/learner_profiles/ - Sample Learner Profiles:

15 Sample Profiles (learn_001.json through learn_015.json):
+ Each file contains complete learner profile structure
+ Format: JSON with 17 main sections
+ Used for testing and demonstration

Profile Structure:
+ learner_id: Unique identifier
+ personal_info: Name, age, timezone, country, languages
+ educational_background: Qualification, GPA, field of study
+ learning_profile: Style, pace, focus duration, preferences
+ current_status: Domain, topic, proficiency, projects, challenges
+ learning_goals: Primary/secondary goals, timeline, career aspirations
+ constraints: Hours available, budget, study time preferences
+ learning_history: Past courses with completion rates and scores
+ preferences: Instructor type, resources, gamification, engagement
+ challenges_and_support: Learning difficulties, needed support, accessibility
+ metadata: Profile creation date, quality score, archetype

all_learners.json: Aggregated data from all 15 profiles

data/raw/ - Raw Training Data (CSV files):
+ gap_training_raw.csv: Training data for gap detection model
+ gap_eval_raw.csv: Evaluation data for gap detection model
+ difficulty_training_raw.csv: Training data for difficulty model
+ difficulty_eval_raw.csv: Evaluation data for difficulty model

data/processed/ - Cleaned Training Data (CSV files):
+ gap_train_clean.csv: Cleaned gap training data
+ gap_eval_clean.csv: Cleaned gap evaluation data
+ difficulty_train_clean.csv: Cleaned difficulty training data
+ difficulty_eval_clean.csv: Cleaned difficulty evaluation data


OUTPUT DIRECTORY
================

output/ - Generated Reports Per Learner

Directory Structure:
output/
  LEARN_001/
    micro_plan_report.txt
    micro_plan.json
    evaluation_metrics.json
  LEARN_002/
    ...
  LEARN_NNN/
    ...

Per-Learner Output Files:

micro_plan_report.txt:
Format: Plain text
Content:
- Professional 7-section prose report
- Learner information header
- Analysis results summary
- Three plan variants with details
- Quality metrics
- Recommendations
- Disclaimer

micro_plan.json:
Format: JSON structured data
Content:
- Metadata (timestamp, version)
- Complete learner profile
- Analysis results with all features
- Identified gaps with confidence scores
- 3 learning plans with full details
- Recommendations and coaching notes
- Quality metrics

evaluation_metrics.json:
Format: JSON flat structure
Content:
- profile_completeness: 0-1 score
- gap_detection_accuracy: gaps/12
- difficulty_confidence: ML confidence
- plan_feasibility: 0.85 or 0.65
- coaching_adaptation: 0.90 or 0.0
- report_completeness: 1.0 if generated
- overall_quality: average score


ENVIRONMENT VARIABLES (.env)
============================

Configuration File: .env
Location: Project root directory

Required Variables:
+ GEMINI_API_KEY_1: API key for Plan Generator LLM
+ GEMINI_API_KEY_2: API key for Coach Rewriter LLM
+ GEMINI_API_KEY_3: API key for Report Saver LLM
+ GEMINI_API_KEY_4: API key for Plan Validator LLM

Optional Variables:
+ LOG_LEVEL: Logging level (default: INFO)
+ DEBUG: Debug mode flag (default: false)
+ MODEL_TEMPERATURE: LLM temperature override (overridden per agent)
+ MAX_TOKENS: Maximum tokens for LLM responses


RUNNING THE SYSTEM
==================

Web Interface (Streamlit):

Command:
streamlit run main.py

Expected Output:
- Streamlit server starts on http://localhost:8501
- Displays web interface with sidebar and 5 tabs
- Loads 15 sample learner profiles
- User can select profile and click "Generate Plan"
- Results display in 5 tabs after workflow completes
- Quality metrics shown at bottom
- Download buttons to export results

Programmatic Interface (Python API):

Command:
python -c "from graph import run_microplan; import json;
with open('data/input/learner_profiles/learn_001.json') as f:
  result = run_microplan(json.load(f));
print(result['learner_id'], result['identified_gaps'])"

Expected Output:
- Prints learner ID
- Prints identified gaps list
- Execution time: 8-12 seconds
- All files saved to output directory

Running Tests:

Command:
pytest tests.py -v

Expected Output:
- 17 test cases executed
- All tests pass
- Coverage: State utilities, parser, analyzer, nodes, ML agents
- Execution time: 10-30 seconds

Command:
pytest tests.py -v -s

Expected Output:
- With output: Shows detailed test execution and print statements

Running Single Test:

Command:
pytest tests.py::test_get_initial_state_returns_microplan_state -v

Expected Output:
- Single test executes
- Pass or Fail result shown


TYPICAL EXECUTION FLOW & OUTPUT
================================

Step 1: Load Learner Profile

Input: learn_001.json (Alex Kumar, 16 years old, Programming domain)

Output Console:
[1] PROFILE PARSER NODE
Profile parsed successfully for LEARN_001

Step 2: Extract Features

Output Console:
[2] PROFILE ANALYZER NODE
Profile analyzed successfully for LEARN_001

Step 3: Parallel ML Tasks

Output Console:
[3A] GAP DETECTOR NODE
Gap model loaded successfully
Identified 3 gaps: prerequisite_foundation, frontend_frameworks, backend_architecture
Urgency: HIGH

[3B] DIFFICULTY PREDICTOR NODE
Difficulty model loaded successfully
Recommended: Intermediate (confidence: 0.75)

Step 4: Generate Plans

Output Console:
[4] PLAN GENERATOR NODE
Generated 3 plan variants

Step 5: Validate Plans

Output Console:
[5] PLAN VALIDATOR NODE
Validated 3 plans
Validation issues: 0

Step 6: Rewrite Plans

Output Console:
[6] COACH REWRITER NODE
Rewritten 3 plans in tone: encouraging_youth

Step 7: Generate Reports

Output Console:
[7] REPORT SAVER NODE
Report saved to /output/LEARN_001/
Overall Quality Score: 0.78

Final Output Summary:

File System Changes:
Created /output/LEARN_001/ directory
Created micro_plan_report.txt (800 words, 7 sections)
Created micro_plan.json (structured data)
Created evaluation_metrics.json (quality scores)

State Dictionary:
+ learner_id: "LEARN_001"
+ identified_gaps: ["prerequisite_foundation", "frontend_frameworks", "backend_architecture"]
+ urgency_level: "high"
+ recommended_difficulty: "Intermediate"
+ difficulty_confidence: 0.75
+ plan_variant_a_validated: {Dict with Conservative plan}
+ plan_variant_b_validated: {Dict with Standard plan}
+ plan_variant_c_validated: {Dict with Aggressive plan}
+ variant_a_friendly: {String with coaching notes}
+ variant_b_friendly: {String with coaching notes}
+ variant_c_friendly: {String with coaching notes}
+ saved_path: "/output/LEARN_001/micro_plan_report.txt"
+ output_dir: "/output/LEARN_001/"
+ quality_metrics: {
    "profile_completeness": 0.95,
    "gap_detection_accuracy": 0.25,
    "difficulty_confidence": 0.75,
    "plan_feasibility": 0.85,
    "coaching_adaptation": 0.90,
    "report_completeness": 1.0,
    "overall_quality": 0.78
  }
+ report_complete: true
+ error_occurred: false
+ error_messages: []


PERFORMANCE METRICS
===================

Typical Execution Times Per Learner:

[1] Profile Parser: 50-100ms
[2] Profile Analyzer: 100-200ms
[3A] Gap Detector (ML, parallel): 200-300ms
[3B] Difficulty Predictor (ML, parallel): 200-300ms
[4] Plan Generator (LLM): 3-5 seconds
[5] Plan Validator (LLM): 2-3 seconds
[6] Coach Rewriter (LLM): 2-3 seconds
[7] Report Saver (LLM): 2-3 seconds

Total Workflow Time: 8-12 seconds (with parallel ML execution)
Sequential Time: 11-17 seconds (without parallel execution)
Speedup from Parallel Execution: 35-50% improvement

Quality Metrics Typical Ranges:

profile_completeness: 85-95%
gap_detection_accuracy: 20-40%
difficulty_confidence: 60-85%
plan_feasibility: 65-85%
coaching_adaptation: 85-95%
report_completeness: 100%
overall_quality: 70-85%


ERROR HANDLING STRATEGY
=======================

Graceful Degradation Philosophy:
System continues execution with sensible defaults rather than failing completely

Error Scenarios and Handling:

Profile Parser Error:
- Condition: Missing required fields or type validation fails
- Action: TERMINATE workflow immediately
- State: error_occurred = True
- Message: Added to error_messages list
- Output: User sees error message, no plans generated

Profile Analyzer Error:
- Condition: Exception during feature extraction
- Action: TERMINATE workflow
- State: error_occurred = True
- Message: Exception details in error_messages

Gap Detection Error:
- Condition: ML model prediction fails or feature mismatch
- Action: CONTINUE with default
- Default Gap: "prerequisite_foundation"
- Default Confidence: 0.5
- Urgency: "medium"
- Note: Workflow continues despite error

Difficulty Prediction Error:
- Condition: Feature mismatch or model error
- Action: CONTINUE with fallback
- Default Difficulty: "Intermediate"
- Default Confidence: 0.5
- Note: Graceful degradation, workflow continues

Plan Generation Error:
- Condition: LLM response invalid JSON or API error
- Action: TERMINATE workflow
- State: error_occurred = True
- Message: "Plan Generation Failed: [error details]"

Plan Validation Error:
- Condition: LLM validation fails
- Action: TERMINATE workflow
- State: error_occurred = True
- Message: "Plan Validation Failed: [error details]"

Coach Rewriting Error:
- Condition: LLM rewriting fails
- Action: TERMINATE workflow
- State: error_occurred = True

Report Saving Error:
- Condition: File I/O or LLM generation fails
- Action: TERMINATE workflow
- State: error_occurred = True

Error Recovery:
- All errors logged to state["error_messages"]
- Partial results accessible if workflow terminates early
- Intermediate files may be saved depending on failure point


TESTING FRAMEWORK
=================

Test File: tests.py (389 lines)
Framework: pytest
Total Tests: 24 test cases

Test Categories and Details:

=== State Utility Tests (3 tests) ===

Test 1: test_get_initial_state_returns_microplan_state
Purpose: Verify get_initial_state returns MicroPlanState dict with required fields
Input: sample_profile with learner_id, age, education_level, learning_style
Output: Assertion that dict contains all required fields
Checks: learner_id, learner_json, analyzed_profile, error_messages

Test 2: test_get_initial_state_initializes_empty_lists
Purpose: Verify error_messages initialized as empty list
Input: sample_profile with learner_id
Output: Assertions on list initialization and error_occurred flag
Checks: error_messages is empty list, error_occurred is False

Test 3: test_format_microplan_report_returns_string
Purpose: Verify format_microplan_report returns formatted string
Input: State with identified_gaps and recommended_difficulty
Output: String containing learner_id and gap information
Checks: Return type is str, contains expected content

=== Profile Parser Tests (2 tests) ===

Test 4: test_parse_learner_profile_returns_tuple
Purpose: Verify parse_learner_profile returns tuple structure
Input: profile dictionary with learner_id, age, education_level
Output: Tuple of (normalized dict, is_valid bool, errors list)
Checks: All tuple elements have correct types

Test 5: test_parse_learner_profile_validates_required_fields
Purpose: Verify validation fails on missing required fields
Input: incomplete_profile missing learner_id
Output: is_valid=False with non-empty errors list
Checks: Validation correctly rejects incomplete profiles

=== Profile Analyzer Tests (1 test) ===

Test 6: test_analyze_learner_profile_returns_dict_with_metrics
Purpose: Verify analyze_learner_profile returns analyzed profile dict
Input: profile with learner_id, age, education_level, learning_style
Output: Dictionary with learner_id and extracted metrics
Checks: learner_id matches, dict structure correct

=== Node Function Tests (3 tests) ===

Test 7: test_profile_parser_node_returns_error_dict_on_invalid_input
Purpose: Verify profile_parser_node handles invalid input
Input: state with empty learner_json (missing learner_id)
Output: error_dict with error_occurred=True and error_messages
Checks: Error handling in node execution

Test 8: test_gap_detector_node_returns_dict (with @patch)
Purpose: Verify gap_detector_node returns complete dict
Mock: detect_learning_gaps returns (gaps, confidence_scores, urgency)
Input: state with analyzed_profile
Output: Dict with identified_gaps and gap_detection_complete=True
Checks: Node properly processes ML predictions

Test 9: test_difficulty_predictor_node_returns_dict (with @patch)
Purpose: Verify difficulty_predictor_node returns complete dict
Mock: predict_difficulty_level returns (difficulty, confidence)
Input: state with analyzed_profile
Output: Dict with recommended_difficulty and difficulty_prediction_complete=True
Checks: Node properly processes difficulty predictions

=== Data Validation and Error Handling Tests (3 tests) ===

Test 10: test_profile_parser_rejects_invalid_education_level
Purpose: Verify parser validates education level from predefined set
Input: profile with invalid education_level="InvalidLevel"
Output: Parser response (normalized, is_valid, errors)
Checks: Type validation on education level

Test 11: test_profile_parser_handles_missing_optional_fields
Purpose: Verify parser handles missing optional fields gracefully
Input: minimal_profile with only required fields
Output: Parser successfully normalizes profile
Checks: Returns valid dict despite missing optional fields

Test 12: test_gap_detector_handles_empty_profile
Purpose: Verify gap_detector handles empty profile gracefully
Input: state with empty analyzed_profile
Output: Dict with gap_detection_complete field
Checks: Node gracefully handles minimal input

=== State Flow and Integration Tests (2 tests) ===

Test 13: test_gap_and_difficulty_predictions_independent (with @patch decorators)
Purpose: Verify gap and difficulty predictions produce independent results
Mock: Both gap and difficulty detectors with specific returns
Input: state with analyzed_profile
Output: Two independent result dicts
Checks: Results from parallel nodes are independent
Behavior: gap_result and difficulty_result have different contents

Test 14: test_state_merges_from_parallel_nodes (with @patch decorators)
Purpose: Verify state correctly merges outputs from parallel nodes
Mock: Both gap and difficulty detectors
Input: Initial state
Output: Merged state with both gap and difficulty fields
Checks: Both gap_detection_complete and difficulty_prediction_complete true
Behavior: Demonstrates state merging after parallel execution

=== Report Generation and Formatting Tests (1 test) ===

Test 15: test_format_microplan_report_includes_all_key_sections
Purpose: Verify formatted report includes all key sections
Input: state with learner_id, identified_gaps, recommended_difficulty
Output: Formatted report string
Checks: Report contains learner_id, gaps, and difficulty information

=== Data Pipeline Artifacts Tests (2 tests) ===

Test 16: test_cleaned_datasets_exist_in_processed_directory
Purpose: Verify cleaned dataset files exist in data/processed/
Expected Files:
  - difficulty_train_clean.csv
  - difficulty_eval_clean.csv
  - gap_train_clean.csv
  - gap_eval_clean.csv
Checks: All files exist and have non-zero size
Path: data/processed/

Test 17: test_ml_models_exist_in_ml_model_directory
Purpose: Verify ML model .pkl files exist in ml/model/
Expected Files:
  - gap_model.pkl
  - gap_vectorizer.pkl
  - gap_scaler.pkl
  - gap_mlb.pkl
  - difficulty_model.pkl
  - difficulty_scaler.pkl
  - difficulty_label_encoder.pkl
  - difficulty_categorical_encoders.pkl
Checks: All files exist and have non-zero size
Path: ml/model/

=== Module-Level Functions Tests (7 tests) ===

Test 18: test_load_gap_artifacts_callable
Purpose: Verify load_gap_artifacts is callable module-level function
Import: from agents.gap_detection_ml import load_gap_artifacts
Checks: callable() returns True

Test 19: test_prepare_gap_text_features_callable
Purpose: Verify prepare_gap_text_features is callable module-level function
Import: from agents.gap_detection_ml import prepare_gap_text_features
Checks: callable() returns True

Test 20: test_prepare_gap_numeric_features_callable
Purpose: Verify prepare_gap_numeric_features is callable module-level function
Import: from agents.gap_detection_ml import prepare_gap_numeric_features
Checks: callable() returns True

Test 21: test_determine_gap_urgency_callable
Purpose: Verify determine_gap_urgency is callable module-level function
Import: from agents.gap_detection_ml import determine_gap_urgency
Checks: callable() returns True

Test 22: test_gap_detection_main_callable
Purpose: Verify detect_gaps_main is callable module-level function
Import: from agents.gap_detection_ml import detect_gaps_main
Checks: callable() returns True

Test 23: test_module_level_functions_accessible_via_agents_package
Purpose: Verify module-level functions accessible via agents package
Import: Multiple functions from agents package
Functions:
  - load_gap_artifacts
  - prepare_gap_text_features
  - prepare_gap_numeric_features
  - determine_gap_urgency
Checks: All functions callable() returns True

Test 24: test_extracted_functions_in_agents_all_exports
Purpose: Verify extracted functions appear in agents.__all__
Expected Functions:
  - load_gap_artifacts
  - prepare_gap_text_features
  - prepare_gap_numeric_features
  - determine_gap_urgency
Checks: Each function in agents.__all__

Running Tests:

Command: pytest tests.py -v
Result: 24 passed, execution ~20-30 seconds

Command: pytest tests.py -v -k "parser"
Result: Parser-related tests only

Command: pytest tests.py -v -k "gap"
Result: Gap detection and callable tests

Command: pytest tests.py -v -s
Result: All tests with print statement output shown

Command: pytest tests.py::test_get_initial_state_returns_microplan_state -v
Result: Single specific test execution


DEPENDENCIES (requirements.txt)
===============================

Core Framework:
+ streamlit >= 1.28.0 (Web UI)
+ langgraph >= 0.0.40 (Workflow orchestration)
+ langchain >= 0.1.0 (LLM framework)
+ langchain-google-genai >= 0.0.1 (Gemini integration)

Machine Learning:
+ scikit-learn >= 1.3.0 (ML models and preprocessing)
+ pandas >= 2.0.0 (Data manipulation)
+ numpy >= 1.24.0 (Numerical computations)
+ scipy >= 1.10.0 (Scientific computing)

Utilities:
+ python-dotenv >= 1.0.0 (Environment variable management)
+ typing-extensions >= 4.8.0 (Type hints)

Testing:
+ pytest >= 7.4.0 (Testing framework)

Optional:
+ torch >= 2.0.0 (For future GPU acceleration)


DEPLOYMENT AND CONFIGURATION
=============================

Prerequisites:
- Python 3.9 or higher
- Pip package manager
- 4 Google Gemini API keys

Installation Steps:

1. Clone/Download project
2. Navigate to project directory
3. Create virtual environment:
   python -m venv venv
4. Activate virtual environment:
   On Linux/Mac: source venv/bin/activate
   On Windows: venv\Scripts\activate
5. Install dependencies:
   pip install -r requirements.txt
6. Create .env file with API keys:
   GEMINI_API_KEY_1=your_key_here
   GEMINI_API_KEY_2=your_key_here
   GEMINI_API_KEY_3=your_key_here
   GEMINI_API_KEY_4=your_key_here

Running Web Interface:
streamlit run main.py
Access at: http://localhost:8501

Running Programmatic API:
Import and use: from graph import run_microplan

Output Organization:
Results saved in: /output/{learner_id}/
Contains: .txt, .json, and metrics files


SYSTEM CHARACTERISTICS
======================

Strengths:
- Multi-agent architecture with clear separation of concerns
- Parallel execution of independent ML tasks for performance
- Graceful error handling with sensible defaults
- Three plan variants catering to different learning styles
- Adaptive coaching tone based on learner characteristics
- Comprehensive quality metrics for assessment
- LLM-based natural language generation for friendly content
- Complete state management with TypedDict
- 8-12 second execution time per learner
- Professional report generation in multiple formats

Limitations:
- Requires 4 Google Gemini API keys
- ML models trained on specific datasets
- Feature engineering relies on profile structure
- Single learner processing (not batch optimized)
- LLM temperature fixed per agent (no dynamic adjustment)
- Gap labels and difficulty classes are fixed

Scalability Considerations:
- Adding more ML models requires new agents and nodes
- Can add new plan variants by modifying plan generator
- Can add new tones by updating coach rewriter logic
- Can extend profile schema by updating parser validation
- Report sections can be customized via report saver

Future Enhancements:
- Batch processing of multiple learners
- Real-time progress streaming
- Feedback loop for plan adjustments
- Integration with learning management systems
- Mobile app interface
- Advanced analytics dashboard
- Dynamic model updates based on user feedback

END OF DOCUMENTATION
====================
