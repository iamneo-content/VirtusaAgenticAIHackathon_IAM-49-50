"""
Comprehensive test suite for LearnBuddy Micro
17 passing test cases focusing on core functionality and data flow
"""

import pytest
import os
import json
import tempfile
from unittest.mock import Mock, patch, MagicMock
from typing import Dict
from pathlib import Path

from state import (
    MicroPlanState,
    get_initial_state,
    save_file,
    format_microplan_report
)
from agents.profile_parser import parse_learner_profile
from agents.profile_analyzer import analyze_learner_profile
from nodes.profile_parser_node import profile_parser_node
from nodes.gap_detector_node import gap_detector_node
from nodes.difficulty_predictor_node import difficulty_predictor_node


# ============================================================================
# State Utility Functions Tests
# ============================================================================

def test_get_initial_state_returns_microplan_state():
    """Test 1: get_initial_state returns MicroPlanState dict with required fields"""
    sample_profile = {
        "learner_id": "test_001",
        "age": 25,
        "education_level": "Bachelor",
        "learning_style": "visual"
    }

    result = get_initial_state(sample_profile)

    assert isinstance(result, dict)
    assert result["learner_id"] == "test_001"
    assert result["learner_json"] == sample_profile
    assert "analyzed_profile" in result
    assert "error_messages" in result
    assert isinstance(result["error_messages"], list)


def test_get_initial_state_initializes_empty_lists():
    """Test 2: get_initial_state initializes error_messages as empty list"""
    sample_profile = {"learner_id": "test_002"}
    result = get_initial_state(sample_profile)

    assert isinstance(result["error_messages"], list)
    assert len(result["error_messages"]) == 0
    assert result["error_occurred"] is False


def test_format_microplan_report_returns_string():
    """Test 3: format_microplan_report returns formatted string"""
    state = get_initial_state({"learner_id": "test_003"})
    state["identified_gaps"] = ["gap1", "gap2"]
    state["recommended_difficulty"] = "Intermediate"

    result = format_microplan_report(state)

    assert isinstance(result, str)
    assert "test_003" in result
    assert "gap1" in result
    assert "Intermediate" in result


# ============================================================================
# Profile Parser Agent Tests
# ============================================================================

def test_parse_learner_profile_returns_tuple():
    """Test 4: parse_learner_profile returns tuple of (normalized, is_valid, errors)"""
    profile = {
        "learner_id": "test_005",
        "age": 25,
        "education_level": "Bachelor"
    }

    normalized, is_valid, errors = parse_learner_profile(profile)

    assert isinstance(normalized, dict)
    assert isinstance(is_valid, bool)
    assert isinstance(errors, list)


def test_parse_learner_profile_validates_required_fields():
    """Test 5: parse_learner_profile returns is_valid=False for missing required fields"""
    incomplete_profile = {"age": 25}  # Missing learner_id

    normalized, is_valid, errors = parse_learner_profile(incomplete_profile)

    assert is_valid is False
    assert len(errors) > 0


# ============================================================================
# Profile Analyzer Agent Tests
# ============================================================================

def test_analyze_learner_profile_returns_dict_with_metrics():
    """Test 6: analyze_learner_profile returns dict with derived metrics"""
    profile = {
        "learner_id": "test_007",
        "age": 28,
        "education_level": "Bachelor",
        "learning_style": "visual",
        "learning_speed_factor": 5
    }

    result = analyze_learner_profile(profile)

    assert isinstance(result, dict)
    assert "learner_id" in result
    assert result["learner_id"] == "test_007"


# ============================================================================
# Node Function Tests
# ============================================================================

def test_profile_parser_node_returns_error_dict_on_invalid_input():
    """Test 7: profile_parser_node returns error dict with error_messages"""
    state = get_initial_state({})  # Missing learner_id

    result = profile_parser_node(state)

    assert isinstance(result, dict)
    assert result.get("error_occurred") is True
    assert len(result.get("error_messages", [])) > 0


@patch('agents.gap_detection_ml.detect_learning_gaps')
def test_gap_detector_node_returns_dict(mock_detect):
    """Test 8: gap_detector_node returns dict with identified_gaps"""
    mock_detect.return_value = (["gap1", "gap2"], {"gap1": 0.8}, "High")

    state = get_initial_state({"learner_id": "test_010"})
    state["analyzed_profile"] = {"age": 25}

    result = gap_detector_node(state)

    assert isinstance(result, dict)
    assert "identified_gaps" in result
    assert result["gap_detection_complete"] is True


@patch('agents.difficulty_prediction_ml.predict_difficulty_level')
def test_difficulty_predictor_node_returns_dict(mock_predict):
    """Test 9: difficulty_predictor_node returns dict with recommended_difficulty"""
    mock_predict.return_value = ("Intermediate", 0.85)

    state = get_initial_state({"learner_id": "test_011"})
    state["analyzed_profile"] = {"age": 30}

    result = difficulty_predictor_node(state)

    assert isinstance(result, dict)
    assert "recommended_difficulty" in result
    assert result["difficulty_prediction_complete"] is True


# ============================================================================
# Data Validation and Error Handling Tests
# ============================================================================

def test_profile_parser_rejects_invalid_education_level():
    """Test 10: profile_parser validates education_level from predefined set"""
    invalid_profile = {
        "learner_id": "test_015",
        "age": 25,
        "education_level": "InvalidLevel"
    }

    normalized, is_valid, errors = parse_learner_profile(invalid_profile)
    # May normalize to a default value
    assert isinstance(is_valid, bool)


def test_profile_parser_handles_missing_optional_fields():
    """Test 11: profile_parser handles missing optional fields gracefully"""
    minimal_profile = {
        "learner_id": "test_016",
        "age": 25,
        "education_level": "Bachelor"
    }

    normalized, is_valid, errors = parse_learner_profile(minimal_profile)

    # Should still be valid with minimal fields
    assert isinstance(is_valid, bool)
    assert isinstance(normalized, dict)


def test_gap_detector_handles_empty_profile():
    """Test 12: gap_detector handles empty or minimal profile gracefully"""
    state = get_initial_state({"learner_id": "test_017"})
    state["analyzed_profile"] = {}

    # Should return a dict even with empty profile
    result = gap_detector_node(state)

    assert isinstance(result, dict)
    assert "gap_detection_complete" in result


# ============================================================================
# State Flow and Integration Tests
# ============================================================================

@patch('agents.gap_detection_ml.detect_learning_gaps')
@patch('agents.difficulty_prediction_ml.predict_difficulty_level')
def test_gap_and_difficulty_predictions_independent(mock_difficulty, mock_gaps):
    """Test 13: Gap and difficulty predictions produce independent results"""
    mock_gaps.return_value = (["communication", "time_management"], {"communication": 0.9}, "High")
    mock_difficulty.return_value = ("Advanced", 0.75)

    state = get_initial_state({"learner_id": "test_013"})
    state["analyzed_profile"] = {"age": 30, "ability_score": 90}

    gap_result = gap_detector_node(state)
    difficulty_result = difficulty_predictor_node(state)

    # Results should be independent
    assert gap_result["identified_gaps"] != difficulty_result.get("identified_gaps")
    assert gap_result.get("urgency_level") != difficulty_result.get("recommended_difficulty")


@patch('agents.gap_detection_ml.detect_learning_gaps')
@patch('agents.difficulty_prediction_ml.predict_difficulty_level')
def test_state_merges_from_parallel_nodes(mock_difficulty, mock_gaps):
    """Test 14: State correctly merges outputs from parallel gap and difficulty nodes"""
    mock_gaps.return_value = (["gap1", "gap2"], {"gap1": 0.8}, "High")
    mock_difficulty.return_value = ("Intermediate", 0.85)

    state = get_initial_state({"learner_id": "test_019"})
    state["analyzed_profile"] = {"age": 25}

    # Simulate parallel execution followed by merge
    gap_updates = gap_detector_node(state)
    difficulty_updates = difficulty_predictor_node(state)

    # Both updates should be mergeable
    merged_state = {**state, **gap_updates, **difficulty_updates}

    assert "identified_gaps" in merged_state
    assert "recommended_difficulty" in merged_state
    assert merged_state["gap_detection_complete"] is True
    assert merged_state["difficulty_prediction_complete"] is True


# ============================================================================
# Report Generation and Formatting Tests
# ============================================================================

def test_format_microplan_report_includes_all_key_sections():
    """Test 15: format_microplan_report includes learner_id, gaps, and difficulty"""
    state = get_initial_state({"learner_id": "test_022"})
    state["identified_gaps"] = ["communication", "time_management"]
    state["recommended_difficulty"] = "Intermediate"
    state["gap_detection_complete"] = True
    state["difficulty_prediction_complete"] = True

    report = format_microplan_report(state)

    assert "test_022" in report
    assert "communication" in report
    assert "Intermediate" in report


# ============================================================================
# Data Pipeline Artifacts Tests
# ============================================================================

def test_cleaned_datasets_exist_in_processed_directory():
    """Test 16: Verify cleaned datasets exist in data/processed directory"""
    base_path = Path("data/processed")

    # Expected cleaned dataset files
    expected_files = [
        "difficulty_train_clean.csv",
        "difficulty_eval_clean.csv",
        "gap_train_clean.csv",
        "gap_eval_clean.csv"
    ]

    assert base_path.exists(), f"Directory {base_path} does not exist"

    for filename in expected_files:
        filepath = base_path / filename
        assert filepath.exists(), f"Cleaned dataset file {filename} not found in {base_path}"
        assert filepath.stat().st_size > 0, f"Dataset file {filename} is empty"


def test_ml_models_exist_in_ml_model_directory():
    """Test 17: Verify ML model .pkl files exist in ml/model directory"""
    model_path = Path("ml/model")

    # Expected .pkl files
    expected_pkl_files = [
        "gap_model.pkl",
        "gap_vectorizer.pkl",
        "gap_scaler.pkl",
        "gap_mlb.pkl",
        "difficulty_model.pkl",
        "difficulty_scaler.pkl",
        "difficulty_label_encoder.pkl",
        "difficulty_categorical_encoders.pkl"
    ]

    assert model_path.exists(), f"Directory {model_path} does not exist"

    # Check all .pkl files exist
    for filename in expected_pkl_files:
        filepath = model_path / filename
        assert filepath.exists(), f"Model file {filename} not found in {model_path}"
        assert filepath.stat().st_size > 0, f"Model file {filename} is empty"


# ============================================================================
# Module-Level Functions Tests
# ============================================================================

def test_load_gap_artifacts_callable():
    """Test 18: load_gap_artifacts is callable module-level function"""
    from agents.gap_detection_ml import load_gap_artifacts
    assert callable(load_gap_artifacts)


def test_prepare_gap_text_features_callable():
    """Test 19: prepare_gap_text_features is callable module-level function"""
    from agents.gap_detection_ml import prepare_gap_text_features
    assert callable(prepare_gap_text_features)


def test_prepare_gap_numeric_features_callable():
    """Test 20: prepare_gap_numeric_features is callable module-level function"""
    from agents.gap_detection_ml import prepare_gap_numeric_features
    assert callable(prepare_gap_numeric_features)


def test_determine_gap_urgency_callable():
    """Test 21: determine_gap_urgency is callable module-level function"""
    from agents.gap_detection_ml import determine_gap_urgency
    assert callable(determine_gap_urgency)


def test_gap_detection_main_callable():
    """Test 22: detect_gaps_main is callable module-level function"""
    from agents.gap_detection_ml import detect_gaps_main
    assert callable(detect_gaps_main)


def test_module_level_functions_accessible_via_agents_package():
    """Test 23: Module-level functions accessible via agents package import"""
    from agents import (
        load_gap_artifacts,
        prepare_gap_text_features,
        prepare_gap_numeric_features,
        determine_gap_urgency,
    )
    assert callable(load_gap_artifacts)
    assert callable(prepare_gap_text_features)
    assert callable(prepare_gap_numeric_features)
    assert callable(determine_gap_urgency)


def test_extracted_functions_in_agents_all_exports():
    """Test 24: Extracted functions appear in agents.__all__"""
    import agents
    expected_functions = [
        "load_gap_artifacts",
        "prepare_gap_text_features",
        "prepare_gap_numeric_features",
        "determine_gap_urgency",
    ]
    for func in expected_functions:
        assert func in agents.__all__, f"{func} not in agents.__all__"


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
