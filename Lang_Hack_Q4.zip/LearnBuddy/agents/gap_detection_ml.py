#!/usr/bin/env python3
"""
Gap Detection ML Agent - Flattened Architecture

Uses trained ML Model 1 to detect learning gaps.
All helper functions extracted as independent module-level functions.
"""

import pickle
import json
import numpy as np
from pathlib import Path
from typing import Dict, Any, Tuple, List
from sklearn.feature_extraction.text import TfidfVectorizer
from scipy.sparse import hstack

MODEL_DIR = Path("/Users/balamurale/Downloads/LangHackthon/LearnBuddy/ml/model")

_gap_model = None
_gap_vectorizer = None
_gap_mlb = None
_gap_scaler = None
_gap_labels = None


def load_gap_artifacts() -> None:
    """Load trained model artifacts into module-level variables"""
    global _gap_model, _gap_vectorizer, _gap_mlb, _gap_scaler, _gap_labels

    try:
        with open(MODEL_DIR / "gap_model.pkl", 'rb') as f:
            _gap_model = pickle.load(f)

        with open(MODEL_DIR / "gap_vectorizer.pkl", 'rb') as f:
            _gap_vectorizer = pickle.load(f)

        with open(MODEL_DIR / "gap_mlb.pkl", 'rb') as f:
            _gap_mlb = pickle.load(f)

        with open(MODEL_DIR / "gap_scaler.pkl", 'rb') as f:
            _gap_scaler = pickle.load(f)

        with open(MODEL_DIR / "gap_labels.json", 'r') as f:
            _gap_labels = json.load(f)

        print("Gap Detection model loaded successfully")
    except Exception as e:
        print(f"Error loading gap detection model: {e}")
        raise


def prepare_gap_text_features(profile: Dict[str, Any]) -> str:
    """Extract text features from profile for gap detection"""
    parts = []

    if "proficiency" in profile and "domain" in profile["proficiency"]:
        parts.append(profile["proficiency"]["domain"])

    if "learning_characteristics" in profile and "learning_style" in profile["learning_characteristics"]:
        parts.append(profile["learning_characteristics"]["learning_style"])

    if "proficiency" in profile and "challenges" in profile["proficiency"]:
        parts.extend(profile["proficiency"]["challenges"])

    if "goals_analysis" in profile and "desired_outcome" in profile["goals_analysis"]:
        parts.append(profile["goals_analysis"]["desired_outcome"])

    text = " ".join([str(p) for p in parts if p])
    return text if text else "learning"


def prepare_gap_numeric_features(profile: Dict[str, Any]) -> np.ndarray:
    """Extract numeric features from profile for gap detection"""
    features = []

    # Core features
    age = profile.get("demographics", {}).get("age") or 30
    features.append(age)

    hours = profile.get("constraints_analysis", {}).get("hours_per_week") or 10
    features.append(hours)

    score = profile.get("proficiency", {}).get("self_assessed_score") or 50
    features.append(score)

    test_score = profile.get("proficiency", {}).get("standardized_test_score") or 50
    features.append(test_score)

    focus = profile.get("learning_characteristics", {}).get("focus_duration_minutes") or 45
    features.append(focus)

    clarity = profile.get("goals_analysis", {}).get("goal_clarity_score") or 50
    features.append(clarity)

    pressure = profile.get("constraints_analysis", {}).get("time_pressure_score") or 50
    features.append(pressure)

    consistency = profile.get("history_analysis", {}).get("consistency_score") or 0.5
    features.append(consistency)

    # Pad with additional features to match scaler expectations (15 total)
    # These are derived from available profile data
    motivation = profile.get("constraints_analysis", {}).get("goal_clarity_score", 50) / 100.0
    features.append(motivation)

    learning_pace = 1.0 if profile.get("learning_characteristics", {}).get("learning_pace") == "fast" else 0.5
    features.append(learning_pace)

    budget = profile.get("constraints_analysis", {}).get("budget", 100)
    features.append(budget)

    num_gaps = len(profile.get("identified_gaps", []))
    features.append(num_gaps)

    gpa = profile.get("educational_background", {}).get("gpa", 3.0) if "educational_background" in profile else 3.0
    features.append(gpa)

    years_exp = profile.get("learning_history", {}).get("years_of_experience", 0) if "learning_history" in profile else 0
    features.append(years_exp)

    target_timeline = profile.get("goals_analysis", {}).get("target_timeline_months", 6) or 6
    features.append(target_timeline)

    return np.array([features])


def determine_gap_urgency(profile: Dict[str, Any], gaps: List[str]) -> str:
    """Determine urgency level based on gaps and profile"""
    proficiency = profile.get("proficiency", {}).get("self_assessed_score", 50)

    if proficiency < 30:
        return "critical"
    elif proficiency < 50 or "prerequisite_foundation" in gaps:
        return "high"
    elif proficiency < 70:
        return "medium"
    else:
        return "low"


def detect_gaps_main(analyzed_profile: Dict[str, Any]) -> Tuple[List[str], Dict[str, float], str]:
    """Core gap detection logic (independent function)"""
    global _gap_model

    if _gap_model is None:
        load_gap_artifacts()

    try:
        text_features = prepare_gap_text_features(analyzed_profile)
        numeric_features = prepare_gap_numeric_features(analyzed_profile)

        X_text = _gap_vectorizer.transform([text_features])
        X_numeric_scaled = _gap_scaler.transform(numeric_features)
        X = hstack([X_text, X_numeric_scaled])

        predictions = _gap_model.predict(X)

        # Get probabilities or use decision function if predict_proba not available
        try:
            probabilities = _gap_model.predict_proba(X)[0]
        except AttributeError:
            # OneVsRestClassifier may not have predict_proba, use decision_function instead
            decision_scores = _gap_model.decision_function(X)[0]
            # Normalize decision scores to [0, 1] range
            probabilities = (decision_scores - decision_scores.min()) / (decision_scores.max() - decision_scores.min() + 1e-10)

        identified_gaps = []
        confidence_scores = {}

        for idx, label in enumerate(_gap_labels):
            if predictions[0, idx] == 1:
                identified_gaps.append(label)
                confidence_scores[label] = float(probabilities[idx])

        urgency = determine_gap_urgency(analyzed_profile, identified_gaps)

        if not identified_gaps:
            identified_gaps = ["prerequisite_foundation"]
            confidence_scores["prerequisite_foundation"] = 0.6

        return identified_gaps, confidence_scores, urgency
    except ValueError as e:
        # Feature dimension or format mismatch
        print(f" Warning: Feature extraction error in gap detection: {e}")
        print(f"         Returning default gaps: [prerequisite_foundation]")
        return ["prerequisite_foundation"], {"prerequisite_foundation": 0.6}, "medium"

    except Exception as e:
        print(f"Error detecting gaps: {e}")
        return ["prerequisite_foundation"], {"prerequisite_foundation": 0.5}, "medium"


class GapDetectionMLAgent:
    """Wrapper class for backward compatibility"""

    def __init__(self):
        if _gap_model is None:
            load_gap_artifacts()

    def detect_gaps(self, analyzed_profile: Dict[str, Any]) -> Tuple[List[str], Dict[str, float], str]:
        """Detect gaps (delegates to module-level function)"""
        return detect_gaps_main(analyzed_profile)


def detect_learning_gaps(analyzed_profile: Dict[str, Any]) -> Tuple[List[str], Dict[str, float], str]:
    """Convenience function to detect gaps"""
    return detect_gaps_main(analyzed_profile)
