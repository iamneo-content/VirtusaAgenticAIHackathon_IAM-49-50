#!/usr/bin/env python3
"""
Coach Rewriter LLM Agent
Rewrites plans in adaptive, friendly language based on learner style
"""

import os
from typing import Dict, Any, Tuple

class CoachRewriterLLMAgent:
    """Rewrite plans in friendly, adaptive language"""

    def __init__(self):
        self.api_key = os.getenv("GEMINI_API_KEY_2", "")
        try:
            from langchain_google_genai import ChatGoogleGenerativeAI
            self.llm = ChatGoogleGenerativeAI(model="gemini-2.0-flash", temperature=0.5, api_key=self.api_key)
        except:
            self.llm = None
            print(" Gemini API not available, using mock mode")

    def rewrite_plans(self, plans: Tuple[Dict, Dict, Dict], analyzed_profile: Dict[str, Any]) -> Tuple[str, str, str]:
        """Rewrite 3 plans in friendly language with adaptive tone"""

        learning_style = analyzed_profile.get("learning_characteristics", {}).get("learning_style", "visual")
        age = analyzed_profile.get("demographics", {}).get("age", 30)

        # Determine tone based on learner
        tone = self._determine_tone(learning_style, age)

        plan_a, plan_b, plan_c = plans

        # Rewrite each plan
        text_a = self._rewrite_plan(plan_a, tone, "Conservative Plan - Take It Slow")
        text_b = self._rewrite_plan(plan_b, tone, "Standard Plan - Balanced Approach")
        text_c = self._rewrite_plan(plan_c, tone, "Aggressive Plan - Fast Track")

        return text_a, text_b, text_c

    def _determine_tone(self, learning_style: str, age: int) -> str:
        """Determine appropriate tone based on learner profile"""
        if age < 18:
            return "encouraging_youth"
        elif learning_style == "auditory":
            return "conversational"
        elif learning_style == "kinesthetic":
            return "practical_action_oriented"
        elif learning_style == "visual":
            return "visual_metaphor_based"
        else:
            return "analytical"

    def _rewrite_plan(self, plan: Dict[str, Any], tone: str, title: str) -> str:
        """Rewrite a single plan with adaptive tone using LLM"""

        intensity = plan.get("intensity", "medium").upper()
        duration = plan.get("duration_weeks", 12)
        hours = plan.get("hours_per_week", 10)
        topics = plan.get("topics", [])
        milestones = plan.get("milestones", [])

        topics_str = ", ".join(topics[:5])
        milestones_str = ", ".join(milestones)
        resources_str = ", ".join(plan.get("resources", []))
        criteria_str = ", ".join(plan.get("success_criteria", []))

        prompt = f"""
You are an encouraging learning coach. Rewrite the following learning plan in a {tone} tone.
Make it motivational, personal, and practical. Format it nicely with markdown headers and emojis.

Plan Title: {title}
Intensity: {intensity}
Duration: {duration} weeks
Weekly Hours: {hours} hours/week
Total Hours: {plan.get('total_hours', 0)}

Topics: {topics_str}
Milestones: {milestones_str}
Resources: {resources_str}
Success Criteria: {criteria_str}

Write an engaging, personalized version of this plan that:
1. Starts with a motivational overview
2. Breaks down the learning journey in an inspiring way
3. Explains resources in context
4. Makes success criteria feel achievable
5. Includes personalized pro tips
6. Ends with encouragement

Use emojis, headers, and formatting to make it engaging and easy to follow.
"""
        response = self.llm.invoke(prompt)
        response_text = response.content if hasattr(response, 'content') else str(response)
        return response_text


def rewrite_learning_plans(plans: Tuple[Dict, Dict, Dict], analyzed_profile: Dict[str, Any]) -> Tuple[str, str, str]:
    """Convenience function"""
    agent = CoachRewriterLLMAgent()
    return agent.rewrite_plans(plans, analyzed_profile)
