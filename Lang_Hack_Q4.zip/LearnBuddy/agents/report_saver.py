#!/usr/bin/env python3
"""
Report Saver Agent - LLM Based
Generates and saves final micro-learning plan report using Gemini 2.0 Flash
"""

import json
import os
from typing import Dict, Any
from pathlib import Path
from state import slugify, save_file, calculate_quality_score

class ReportSaverAgent:
    """Generate and save final report using LLM"""

    def __init__(self):
        self.output_base = Path("/Users/balamurale/Downloads/LangHackthon/LearnBuddy/output")
        self.output_base.mkdir(parents=True, exist_ok=True)

        self.api_key = os.getenv("GEMINI_API_KEY_3", "")
        try:
            from langchain_google_genai import ChatGoogleGenerativeAI
            self.llm = ChatGoogleGenerativeAI(model="gemini-2.0-flash", temperature=0.3, api_key=self.api_key)
        except:
            self.llm = None
            print(" Gemini API not available, using fallback mode")

    def save_report(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Generate and save complete report using LLM"""

        learner_id = state.get("learner_id", "unknown")
        output_dir = str(self.output_base / learner_id)
        Path(output_dir).mkdir(parents=True, exist_ok=True)

        # Generate LLM-based report text
        report_text = self._generate_llm_report(state)

        # Create JSON report
        report_json = self._create_json_report(state)

        # Calculate metrics
        quality_metrics = calculate_quality_score(state)

        # Save files
        report_path = Path(output_dir) / "micro_plan_report.txt"
        json_path = Path(output_dir) / "micro_plan.json"
        metrics_path = Path(output_dir) / "evaluation_metrics.json"

        # Save report text
        if save_file(str(report_path), report_text):
            print(f" Report saved: {report_path}")

        # Save JSON report
        with open(json_path, 'w') as f:
            json.dump(report_json, f, indent=2)

        # Save metrics
        with open(metrics_path, 'w') as f:
            json.dump(quality_metrics, f, indent=2)

        return {
            "saved_path": str(report_path),
            "output_dir": output_dir,
            "json_path": str(json_path),
            "metrics_path": str(metrics_path),
            "quality_metrics": quality_metrics,
        }

    def _generate_llm_report(self, state: Dict[str, Any]) -> str:
        """Generate professional report using LLM"""

        learner = state["learner_json"]
        profile_info = learner.get("personal_info", {})
        goals = learner.get("learning_goals", {})

        # Prepare context for LLM
        context = f"""
LEARNER PROFILE SUMMARY:
- Name: {profile_info.get('name', 'Student')}
- Age: {profile_info.get('age', 'N/A')}
- Education: {learner.get('educational_background', {}).get('highest_qualification', 'N/A')}
- Learning Style: {learner.get('learning_profile', {}).get('learning_style', 'Mixed')}
- Domain: {learner.get('current_status', {}).get('primary_domain', 'N/A')}
- Hours Available/Week: {learner.get('constraints', {}).get('hours_available_per_week', 'N/A')}
- Goal Timeline: {goals.get('target_timeline_months', 'N/A')} months
- Primary Goal: {goals.get('primary_goal', 'N/A')}

ANALYSIS RESULTS:
- Identified Gaps: {', '.join(state.get('identified_gaps', []))}
- Gap Urgency: {state.get('urgency_level', 'medium')}
- Recommended Difficulty: {state.get('recommended_difficulty', 'Intermediate')}
- Difficulty Confidence: {state.get('difficulty_confidence', 0):.1%}

LEARNING PLANS:
Plan A (Conservative):
Duration: {state.get('plan_variant_a_validated', {}).get('duration_weeks', 'N/A')} weeks
Hours/Week: {state.get('plan_variant_a_validated', {}).get('hours_per_week', 'N/A')}
Topics: {', '.join(state.get('plan_variant_a_validated', {}).get('topics', [])[:3])}

Plan B (Standard):
Duration: {state.get('plan_variant_b_validated', {}).get('duration_weeks', 'N/A')} weeks
Hours/Week: {state.get('plan_variant_b_validated', {}).get('hours_per_week', 'N/A')}
Topics: {', '.join(state.get('plan_variant_b_validated', {}).get('topics', [])[:3])}

Plan C (Aggressive):
Duration: {state.get('plan_variant_c_validated', {}).get('duration_weeks', 'N/A')} weeks
Hours/Week: {state.get('plan_variant_c_validated', {}).get('hours_per_week', 'N/A')}
Topics: {', '.join(state.get('plan_variant_c_validated', {}).get('topics', [])[:3])}

Quality Metrics:
{json.dumps(state.get('quality_metrics', {}), indent=2)}
"""

        prompt = f"""
You are an expert educational consultant creating a professional, personalized learning plan report.
Generate a comprehensive, well-structured report based on the learner profile and analysis results below.

{context}

Create a professional report with these sections:
1. Executive Summary - Brief overview of the learner profile and key findings
2. Learning Gap Analysis - Detailed explanation of identified gaps and urgency
3. Personalized Assessment - How the difficulty level matches the learner's profile
4. Three Learning Plan Options - Present all three plans clearly with pros/cons for each
5. Recommendations - Specific advice tailored to this learner's situation
6. Success Strategies - Practical tips for achieving the learning goals
7. Next Steps - Clear action items to get started

Use professional language, clear structure with headers, emojis where appropriate, and make it engaging and motivating.
Focus on the learner's strengths and opportunities while acknowledging challenges.
Make the report feel personalized, not generic.
"""
        response = self.llm.invoke(prompt)
        response_text = response.content if hasattr(response, 'content') else str(response)

        # Add footer with metadata
        footer = f"""


Report Generated: {self._get_timestamp()}
System: LearnBuddy Micro v2.0 (LLM-Enhanced)
Learner ID: {state.get('learner_id', 'UNKNOWN')}

"""
        return response_text + footer

    def _create_json_report(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """Create structured JSON report"""

        return {
            "metadata": {
                "learner_id": state.get("learner_id"),
                "generated_at": self._get_timestamp(),
                "version": "1.0",
            },
            "learner_profile": {
                "age": state.get("learner_json", {}).get("personal_info", {}).get("age"),
                "education": state.get("learner_json", {}).get("educational_background", {}).get("highest_qualification"),
                "learning_style": state.get("learner_json", {}).get("learning_profile", {}).get("learning_style"),
            },
            "analysis": {
                "identified_gaps": state.get("identified_gaps", []),
                "gap_confidence": state.get("gap_confidence_scores", {}),
                "urgency_level": state.get("urgency_level"),
                "recommended_difficulty": state.get("recommended_difficulty"),
                "difficulty_confidence": state.get("difficulty_confidence"),
            },
            "learning_plans": {
                "conservative": state.get("plan_variant_a_validated", {}),
                "standard": state.get("plan_variant_b_validated", {}),
                "aggressive": state.get("plan_variant_c_validated", {}),
            },
            "coach_recommendations": {
                "conservative": state.get("variant_a_friendly", ""),
                "standard": state.get("variant_b_friendly", ""),
                "aggressive": state.get("variant_c_friendly", ""),
            },
            "quality_metrics": calculate_quality_score(state),
            "validation": {
                "issues": state.get("validation_issues", []),
                "passed": len(state.get("validation_issues", [])) == 0,
            },
        }

    def _get_timestamp(self) -> str:
        """Get timestamp"""
        from datetime import datetime
        return datetime.now().isoformat()


def save_microplan_report(state: Dict[str, Any]) -> Dict[str, Any]:
    """Convenience function"""
    agent = ReportSaverAgent()
    return agent.save_report(state)
