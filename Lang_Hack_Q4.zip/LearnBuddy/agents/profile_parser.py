#!/usr/bin/env python3
"""
Profile Parser Agent
Validates and normalizes learner JSON profile
"""

from typing import Dict, Any, List, Tuple
import json

class ProfileParserAgent:
    """Parse and validate learner JSON profile"""

    REQUIRED_FIELDS = {
        "learner_id": str,
        "personal_info": dict,
        "educational_background": dict,
        "learning_profile": dict,
        "current_status": dict,
        "learning_goals": dict,
        "constraints": dict,
    }

    def __init__(self):
        self.errors: List[str] = []
        self.warnings: List[str] = []

    def validate_profile(self, profile: Dict[str, Any]) -> Tuple[bool, List[str], List[str]]:
        """Validate profile structure and content"""
        self.errors = []
        self.warnings = []

        # Check required fields
        for field, field_type in self.REQUIRED_FIELDS.items():
            if field not in profile:
                self.errors.append(f"Missing required field: {field}")
            elif not isinstance(profile.get(field), field_type):
                self.errors.append(f"Invalid type for {field}: expected {field_type.__name__}")

        # Validate nested structures
        self._validate_personal_info(profile.get("personal_info", {}))
        self._validate_educational_background(profile.get("educational_background", {}))
        self._validate_learning_profile(profile.get("learning_profile", {}))
        self._validate_current_status(profile.get("current_status", {}))
        self._validate_learning_goals(profile.get("learning_goals", {}))
        self._validate_constraints(profile.get("constraints", {}))

        is_valid = len(self.errors) == 0

        return is_valid, self.errors, self.warnings

    def _validate_personal_info(self, info: Dict[str, Any]):
        """Validate personal information"""
        if not info:
            self.warnings.append("Personal info is empty")
            return

        if "age" in info and (info["age"] < 8 or info["age"] > 100):
            self.warnings.append(f"Age seems unusual: {info['age']}")

        if "languages_spoken" in info:
            if not isinstance(info["languages_spoken"], list) or len(info["languages_spoken"]) == 0:
                self.warnings.append("Languages spoken should be non-empty list")

    def _validate_educational_background(self, background: Dict[str, Any]):
        """Validate educational background"""
        valid_levels = ["primary", "secondary", "bachelor", "master", "phd"]
        if "highest_qualification" in background:
            if background["highest_qualification"] not in valid_levels:
                self.warnings.append(f"Unknown education level: {background['highest_qualification']}")

        if "gpa_cgpa" in background:
            gpa = background["gpa_cgpa"]
            if not (0 <= gpa <= 4.0):
                self.warnings.append(f"GPA seems unusual: {gpa}")

    def _validate_learning_profile(self, profile: Dict[str, Any]):
        """Validate learning profile"""
        valid_styles = ["visual", "auditory", "kinesthetic", "reading_writing", "mixed"]
        if "learning_style" in profile:
            if profile["learning_style"] not in valid_styles:
                self.warnings.append(f"Unknown learning style: {profile['learning_style']}")

        if "focus_duration_minutes" in profile:
            duration = profile["focus_duration_minutes"]
            if duration < 5 or duration > 240:
                self.warnings.append(f"Focus duration seems unusual: {duration} minutes")

    def _validate_current_status(self, status: Dict[str, Any]):
        """Validate current status"""
        if "current_proficiency" in status:
            prof = status["current_proficiency"]
            if "self_assessed_score" in prof:
                score = prof["self_assessed_score"]
                if not (0 <= score <= 100):
                    self.warnings.append(f"Proficiency score out of range: {score}")

    def _validate_learning_goals(self, goals: Dict[str, Any]):
        """Validate learning goals"""
        if "target_timeline_months" in goals:
            timeline = goals["target_timeline_months"]
            if timeline < 1 or timeline > 60:
                self.warnings.append(f"Timeline seems unusual: {timeline} months")

    def _validate_constraints(self, constraints: Dict[str, Any]):
        """Validate constraints"""
        if "hours_available_per_week" in constraints:
            hours = constraints["hours_available_per_week"]
            if hours < 0 or hours > 168:
                self.warnings.append(f"Hours per week out of range: {hours}")

        if "budget_limit_usd" in constraints:
            budget = constraints["budget_limit_usd"]
            if budget < 0:
                self.warnings.append(f"Budget should be positive: ${budget}")

    def normalize_profile(self, profile: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize and clean profile data"""
        normalized = {}

        # Copy essential fields
        normalized["learner_id"] = str(profile.get("learner_id", "UNKNOWN")).strip()
        normalized["personal_info"] = self._normalize_dict(profile.get("personal_info", {}))
        normalized["educational_background"] = self._normalize_dict(profile.get("educational_background", {}))
        normalized["learning_profile"] = self._normalize_dict(profile.get("learning_profile", {}))
        normalized["current_status"] = self._normalize_dict(profile.get("current_status", {}))
        normalized["learning_goals"] = self._normalize_dict(profile.get("learning_goals", {}))
        normalized["constraints"] = self._normalize_dict(profile.get("constraints", {}))
        normalized["learning_history"] = profile.get("learning_history", [])
        normalized["preferences"] = self._normalize_dict(profile.get("preferences", {}))
        normalized["challenges_and_support"] = self._normalize_dict(profile.get("challenges_and_support", {}))

        return normalized

    def _normalize_dict(self, d: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize dictionary values"""
        normalized = {}
        for key, value in d.items():
            if isinstance(value, str):
                normalized[key] = value.strip().lower()
            elif isinstance(value, list):
                normalized[key] = [self._normalize_dict(v) if isinstance(v, dict) else v for v in value]
            else:
                normalized[key] = value
        return normalized

    def parse(self, learner_json: Dict[str, Any]) -> Tuple[Dict[str, Any], bool, List[str]]:
        """
        Main parse function
        Returns: (normalized_profile, is_valid, error_messages)
        """
        is_valid, errors, warnings = self.validate_profile(learner_json)

        if not is_valid:
            return {}, False, errors

        normalized = self.normalize_profile(learner_json)

        return normalized, True, errors + warnings


def parse_learner_profile(learner_json: Dict[str, Any]) -> Tuple[Dict[str, Any], bool, List[str]]:
    """Convenience function to parse profile"""
    parser = ProfileParserAgent()
    return parser.parse(learner_json)
