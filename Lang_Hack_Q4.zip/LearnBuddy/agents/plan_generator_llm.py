#!/usr/bin/env python3
"""
Plan Generator LLM Agent
Generates 3 micro-learning plan variants using Gemini LLM
"""

import json
import os
from typing import Dict, Any, List, Tuple

class PlanGeneratorLLMAgent:
    """Generate learning plan variants using LLM"""

    def __init__(self):
        self.api_key = os.getenv("GEMINI_API_KEY_1", "")
        try:
            from langchain_google_genai import ChatGoogleGenerativeAI
            self.llm = ChatGoogleGenerativeAI(model="gemini-2.0-flash", temperature=0.3, api_key=self.api_key)
        except:
            self.llm = None
            print(" Gemini API not available, using mock mode")

    def generate_plans(self, analyzed_profile: Dict[str, Any], gaps: List[str], difficulty: str) -> Tuple[Dict, Dict, Dict]:
        """Generate 3 plan variants"""
        learner = analyzed_profile.get("learner_json", {})
        domain = analyzed_profile.get("proficiency", {}).get("domain", "Programming")
        timeline = analyzed_profile.get("goals_analysis", {}).get("target_timeline_months", 6)

        # Generate conservative plan (slow, foundation-heavy)
        plan_a = self._create_plan_variant(
            domain=domain,
            variant="conservative",
            timeline=timeline * 1.5,
            intensity="low",
            focus_areas=gaps[:3],
            prerequisites=True
        )

        # Generate standard plan (balanced)
        plan_b = self._create_plan_variant(
            domain=domain,
            variant="standard",
            timeline=timeline,
            intensity="medium",
            focus_areas=gaps[:5],
            prerequisites=True
        )

        # Generate aggressive plan (fast, intensive)
        plan_c = self._create_plan_variant(
            domain=domain,
            variant="aggressive",
            timeline=timeline * 0.7,
            intensity="high",
            focus_areas=gaps,
            prerequisites=False
        )

        return plan_a, plan_b, plan_c

    def _create_plan_variant(self, domain: str, variant: str, timeline: float, intensity: str, focus_areas: List[str], prerequisites: bool) -> Dict[str, Any]:
        """Create a single plan variant using LLM"""

        weeks = int(timeline * 4)  # Convert months to weeks
        hours_per_week = 15 if intensity == "high" else (10 if intensity == "medium" else 8)
        total_hours = weeks * hours_per_week

        prompt = f"""
Generate a detailed micro-learning plan for the following:
- Domain: {domain}
- Variant: {variant} (conservative: slow & foundation-heavy, standard: balanced, aggressive: fast-track)
- Duration: {timeline:.1f} months ({weeks} weeks)
- Intensity: {intensity}
- Learning gaps to address: {', '.join(focus_areas)}
- Include prerequisites: {prerequisites}

Format your response as JSON with these fields:
- topics: list of main topics to cover
- resources: list of recommended resources
- milestones: list of 4 major milestones
- success_criteria: list of success criteria
- difficulty_progression: description of how difficulty increases

Be specific and practical for the {domain} domain.
"""
        response = self.llm.invoke(prompt)
        response_text = response.content if hasattr(response, 'content') else str(response)

        # Extract JSON from response
        import re
        json_match = re.search(r'\{.*\}', response_text, re.DOTALL)
        if not json_match:
            raise ValueError("LLM did not return valid JSON in response")

        plan_data = json.loads(json_match.group())

        # Ensure all list fields contain only strings
        def ensure_string_list(items):
            """Convert list items to strings"""
            if not isinstance(items, list):
                return []
            return [str(item) for item in items]

        # Return plan with LLM-generated content
        return {
            "variant": variant,
            "duration_weeks": weeks,
            "hours_per_week": hours_per_week,
            "total_hours": total_hours,
            "intensity": intensity,
            "topics": ensure_string_list(plan_data.get("topics", [])),
            "focus_areas": focus_areas,
            "resources": ensure_string_list(plan_data.get("resources", [])),
            "milestones": ensure_string_list(plan_data.get("milestones", [])),
            "prerequisites": ["Basics"] if prerequisites else [],
            "success_criteria": ensure_string_list(plan_data.get("success_criteria", [])),
            "difficulty_progression": str(plan_data.get("difficulty_progression", "")),
        }


def generate_microlearning_plans(analyzed_profile: Dict[str, Any], gaps: List[str], difficulty: str) -> Tuple[Dict, Dict, Dict]:
    """Convenience function"""
    agent = PlanGeneratorLLMAgent()
    return agent.generate_plans(analyzed_profile, gaps, difficulty)
