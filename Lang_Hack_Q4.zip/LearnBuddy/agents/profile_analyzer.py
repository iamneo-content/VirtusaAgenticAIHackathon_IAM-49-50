#!/usr/bin/env python3
"""
Profile Analyzer Agent
Extracts features and calculates derived metrics from normalized profile
"""

from typing import Dict, Any
import statistics

class ProfileAnalyzerAgent:
    """Analyze learner profile and calculate derived metrics"""

    def __init__(self):
        pass

    def analyze(self, normalized_profile: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze profile and extract key metrics
        """
        analyzed = {
            "learner_id": normalized_profile.get("learner_id", "UNKNOWN"),

            # Demographics
            "demographics": self._extract_demographics(normalized_profile),

            # Learning characteristics
            "learning_characteristics": self._extract_learning_characteristics(normalized_profile),

            # Current proficiency
            "proficiency": self._extract_proficiency(normalized_profile),

            # Goals and motivation
            "goals_analysis": self._extract_goals(normalized_profile),

            # Constraints
            "constraints_analysis": self._extract_constraints(normalized_profile),

            # Learning history
            "history_analysis": self._analyze_learning_history(normalized_profile),
        }

        return analyzed

    def _extract_demographics(self, profile: Dict[str, Any]) -> Dict[str, Any]:
        """Extract demographic information"""
        personal = profile.get("personal_info", {})
        education = profile.get("educational_background", {})

        return {
            "age": personal.get("age", None),
            "timezone": personal.get("timezone", "UTC"),
            "country": personal.get("country", "Unknown"),
            "education_level": education.get("highest_qualification", "unknown"),
            "years_educated": max(0, personal.get("age", 25) - 6),  # Estimate
            "field_of_study": education.get("field_of_study", "unknown"),
        }

    def _extract_learning_characteristics(self, profile: Dict[str, Any]) -> Dict[str, Any]:
        """Extract learning style and characteristics"""
        learning = profile.get("learning_profile", {})
        preferences = profile.get("preferences", {})

        return {
            "learning_style": learning.get("learning_style", "mixed"),
            "learning_pace": learning.get("learning_pace", "moderate"),
            "focus_duration_minutes": learning.get("focus_duration_minutes", 45),
            "break_preference_minutes": learning.get("break_preference_minutes", 10),
            "preferred_formats": learning.get("preferred_formats", []),
            "instructor_type": preferences.get("instructor_type", "any"),
            "gamification_preference": preferences.get("gamification_preference", "low"),
            "community_engagement": preferences.get("community_engagement", "low"),
        }

    def _extract_proficiency(self, profile: Dict[str, Any]) -> Dict[str, Any]:
        """Extract current proficiency information"""
        current = profile.get("current_status", {})
        proficiency = current.get("current_proficiency", {})

        return {
            "domain": current.get("primary_domain", "unknown"),
            "topic": proficiency.get("topic", "unknown"),
            "self_assessed_score": proficiency.get("self_assessed_score", 50),
            "standardized_test_score": proficiency.get("standardized_test_score", 50),
            "assessment_date": proficiency.get("assessment_date", "unknown"),
            "current_projects": current.get("current_projects", []),
            "challenges": current.get("challenges_faced", []),
        }

    def _extract_goals(self, profile: Dict[str, Any]) -> Dict[str, Any]:
        """Extract goal information and calculate goal clarity"""
        goals = profile.get("learning_goals", {})
        preferences = profile.get("preferences", {})

        primary_goal = goals.get("primary_goal", "")
        secondary_goals = goals.get("secondary_goals", [])

        # Calculate goal clarity score (0-100)
        goal_clarity = 50  # Default
        if primary_goal and len(secondary_goals) > 0:
            goal_clarity = 80
        elif primary_goal:
            goal_clarity = 60

        return {
            "primary_goal": primary_goal,
            "secondary_goals": secondary_goals,
            "target_timeline_months": goals.get("target_timeline_months", 6),
            "desired_outcome": goals.get("desired_outcome", "unknown"),
            "career_aspiration": goals.get("career_aspiration", "unknown"),
            "goal_clarity_score": goal_clarity,
            "goal_alignment": self._calculate_goal_alignment(goals, preferences),
        }

    def _extract_constraints(self, profile: Dict[str, Any]) -> Dict[str, Any]:
        """Extract constraint information"""
        constraints = profile.get("constraints", {})
        learning = profile.get("learning_profile", {})

        hours_per_week = constraints.get("hours_available_per_week", 10)
        budget = constraints.get("budget_limit_usd", 0)

        # Calculate time pressure score (0-100, where higher = more time pressure)
        timeline_months = constraints.get("target_timeline_months", 6) if "target_timeline_months" in profile.get("learning_goals", {}) else 6
        estimated_hours_needed = 200  # Rough estimate
        time_pressure = min(100, max(0, 100 * (1 - (hours_per_week * 4 * timeline_months) / estimated_hours_needed)))

        return {
            "hours_per_week": hours_per_week,
            "budget_limit_usd": budget,
            "certification_needed": constraints.get("certification_needed", False),
            "employment_status": constraints.get("employment_status", "unknown"),
            "preferred_study_time": constraints.get("preferred_study_time", "evening"),
            "time_pressure_score": time_pressure,
            "financial_constraint": budget == 0,
        }

    def _analyze_learning_history(self, profile: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze past learning history"""
        history = profile.get("learning_history", [])

        if not history:
            return {
                "courses_completed": 0,
                "avg_completion_rate": 0,
                "avg_score": 0,
                "learning_trend": "new_learner",
                "avg_time_per_course": 0,
                "consistency_score": 0.5,
            }

        completion_rates = [h.get("completion_rate", 0) for h in history if "completion_rate" in h]
        scores = [h.get("score_obtained", 0) for h in history if "score_obtained" in h]
        times = [h.get("time_invested_hours", 0) for h in history if "time_invested_hours" in h]

        avg_completion = statistics.mean(completion_rates) if completion_rates else 0
        avg_score = statistics.mean(scores) if scores else 0
        avg_time = statistics.mean(times) if times else 0

        # Determine learning trend
        if len(scores) >= 6:
            recent_scores = scores[-3:]
            earlier_scores = scores[:-3]
            if statistics.mean(recent_scores) > statistics.mean(earlier_scores):
                trend = "improving"
            elif statistics.mean(recent_scores) < statistics.mean(earlier_scores):
                trend = "declining"
            else:
                trend = "stable"
        elif scores:
            trend = "stable"
        else:
            trend = "unknown"

        return {
            "courses_completed": len(history),
            "avg_completion_rate": avg_completion,
            "avg_score": avg_score,
            "learning_trend": trend,
            "avg_time_per_course": avg_time,
            "consistency_score": self._calculate_consistency(completion_rates),
        }

    def _calculate_goal_alignment(self, goals: Dict[str, Any], preferences: Dict[str, Any]) -> float:
        """Calculate how well goals align with profile (0-1)"""
        alignment = 0.5  # Default middle value

        if goals.get("career_aspiration"):
            alignment += 0.2

        if goals.get("target_timeline_months", 0) > 0:
            alignment += 0.2

        if preferences.get("project_based_learning"):
            alignment += 0.1

        return min(1.0, alignment)

    def _calculate_consistency(self, completion_rates: list) -> float:
        """Calculate learning consistency (0-1)"""
        if not completion_rates:
            return 0.5

        if len(completion_rates) < 2:
            return 0.5

        # Standard deviation of completion rates
        mean = statistics.mean(completion_rates)
        if len(completion_rates) == 1:
            return mean / 100

        std_dev = statistics.stdev(completion_rates)
        consistency = 1.0 - (std_dev / 100)  # Lower variation = higher consistency

        return max(0.0, min(1.0, consistency))


def analyze_learner_profile(normalized_profile: Dict[str, Any]) -> Dict[str, Any]:
    """Convenience function to analyze profile"""
    analyzer = ProfileAnalyzerAgent()
    return analyzer.analyze(normalized_profile)
