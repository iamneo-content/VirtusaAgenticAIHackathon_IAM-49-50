#!/usr/bin/env python3
"""
Difficulty Prediction ML Agent
Uses trained ML Model 2 to predict optimal difficulty level
"""

import pickle
import numpy as np
from pathlib import Path
from typing import Dict, Any, Tuple

class DifficultyPredictionMLAgent:
    """Predict optimal difficulty level using trained ML model"""

    def __init__(self):
        self.model_dir = Path("/Users/balamurale/Downloads/LangHackthon/LearnBuddy/ml/model")
        self.model = None
        self.scaler = None
        self.label_encoder = None
        self.categorical_encoders = None
        self.difficulty_classes = ["Beginner", "Intermediate", "Advanced"]

        self._load_artifacts()

    def _load_artifacts(self):
        """Load trained model artifacts"""
        try:
            with open(self.model_dir / "difficulty_model.pkl", 'rb') as f:
                self.model = pickle.load(f)

            with open(self.model_dir / "difficulty_scaler.pkl", 'rb') as f:
                self.scaler = pickle.load(f)

            with open(self.model_dir / "difficulty_label_encoder.pkl", 'rb') as f:
                self.label_encoder = pickle.load(f)

            with open(self.model_dir / "difficulty_categorical_encoders.pkl", 'rb') as f:
                self.categorical_encoders = pickle.load(f)

            print(" Difficulty Prediction model loaded successfully")
        except Exception as e:
            print(f" Error loading difficulty prediction model: {e}")
            raise

    def predict_difficulty(self, analyzed_profile: Dict[str, Any]) -> Tuple[str, float]:
        """
        Predict optimal difficulty level for learner

        Returns:
            Tuple of (difficulty_level, confidence)
        """
        try:
            # Prepare features
            X = self._prepare_features(analyzed_profile)

            # Predict
            prediction = self.model.predict(X)[0]
            probabilities = self.model.predict_proba(X)[0]

            # Get difficulty label and confidence
            difficulty_label = self.label_encoder.inverse_transform([prediction])[0]
            confidence = float(np.max(probabilities))

            return difficulty_label, confidence

        except ValueError as e:
            # Feature dimension mismatch - model trained with different feature set
            print(f" Warning: Feature dimension mismatch in difficulty prediction: {e}")
            print(f"         Returning default prediction: Intermediate (confidence: 50%)")
            return "Intermediate", 0.5
        except Exception as e:
            # Other errors (API, model issues, etc.)
            print(f" Error predicting difficulty: {e}")
            return "Intermediate", 0.5

    def _prepare_features(self, profile: Dict[str, Any]) -> np.ndarray:
        """Prepare feature vector from analyzed profile"""

        numeric_features = self._extract_numeric_features(profile)
        categorical_features = self._extract_categorical_features(profile)

        # Combine
        numeric_array = np.array(numeric_features).reshape(1, -1)
        numeric_scaled = self.scaler.transform(numeric_array)

        # Encode categoricals
        categorical_encoded = []
        for col_idx, (col_name, le) in enumerate(self.categorical_encoders.items()):
            value = categorical_features.get(col_name, "unknown")
            try:
                encoded = le.transform([value])[0]
            except:
                encoded = 0
            categorical_encoded.append(encoded)

        categorical_array = np.array(categorical_encoded).reshape(1, -1)

        # Combine all features
        X = np.hstack([numeric_scaled, categorical_array])
        return X

    def _extract_numeric_features(self, profile: Dict[str, Any]) -> list:
        """Extract numeric features"""
        features = []

        # Age
        if "demographics" in profile:
            features.append(profile["demographics"].get("age", 30))
        else:
            features.append(30)

        # Hours per week
        if "constraints_analysis" in profile:
            features.append(profile["constraints_analysis"].get("hours_per_week", 10))
        else:
            features.append(10)

        # Current ability score
        if "proficiency" in profile:
            features.append(profile["proficiency"].get("self_assessed_score", 50))
        else:
            features.append(50)

        # Learning speed factor
        learning_pace = profile.get("learning_characteristics", {}).get("learning_pace", "moderate")
        pace_factor = {"slow": -0.3, "moderate": 0.0, "fast": 1.0}.get(learning_pace, 0.0)
        features.append(pace_factor)

        # Time to complete typical course
        avg_time = profile.get("history_analysis", {}).get("avg_time_per_course", 50)
        features.append(avg_time)

        # Learning consistency
        consistency = profile.get("history_analysis", {}).get("consistency_score", 0.5)
        features.append(consistency)

        # Goal alignment
        goal_alignment = profile.get("goals_analysis", {}).get("goal_alignment", 0.5)
        features.append(goal_alignment)

        # Previous attempts on similar
        courses_completed = profile.get("history_analysis", {}).get("courses_completed", 0)
        features.append(min(courses_completed, 10))  # Cap at 10

        # Average score on similar topics
        avg_score = profile.get("history_analysis", {}).get("avg_score", 50)
        features.append(avg_score)

        # Success rate on similar topics
        success_rate = profile.get("history_analysis", {}).get("avg_completion_rate", 50)
        features.append(success_rate)

        # Topic complexity rating (estimate from proficiency gap)
        proficiency = profile.get("proficiency", {}).get("self_assessed_score", 50)
        complexity = (100 - proficiency) / 100 * 10  # Scale to 0-10
        features.append(complexity)

        # Prerequisites count (estimate)
        features.append(3)

        # Prerequisites mastery level
        features.append(proficiency * 0.8)  # Assume 80% mastery of prereqs

        # Estimated hours to master
        features.append(120)

        # Available time weeks
        hours_per_week = profile.get("constraints_analysis", {}).get("hours_per_week", 10)
        features.append(hours_per_week / 3)  # Rough conversion to weeks

        # Certification deadline weeks
        timeline = profile.get("goals_analysis", {}).get("target_timeline_months", 6)
        features.append(timeline * 4)

        return features

    def _extract_categorical_features(self, profile: Dict[str, Any]) -> dict:
        """Extract categorical features"""
        return {
            "education_level": profile.get("demographics", {}).get("education_level", "bachelor"),
            "learning_style": profile.get("learning_characteristics", {}).get("learning_style", "visual"),
            "employment_status": profile.get("constraints_analysis", {}).get("employment_status", "employed"),
            "past_performance_trend": profile.get("history_analysis", {}).get("learning_trend", "stable"),
            "motivation_level": self._estimate_motivation(profile),
            "career_urgency": self._estimate_career_urgency(profile),
            "preferred_difficulty_in_past": "Intermediate",  # Default
            "budget_constraint": "free" if profile.get("constraints_analysis", {}).get("financial_constraint", True) else "medium",
        }

    def _estimate_motivation(self, profile: Dict[str, Any]) -> str:
        """Estimate motivation level"""
        goal_clarity = profile.get("goals_analysis", {}).get("goal_clarity_score", 50)
        consistency = profile.get("history_analysis", {}).get("consistency_score", 0.5)
        avg_score = profile.get("history_analysis", {}).get("avg_score", 50)

        score = (goal_clarity / 100) + (consistency) + (avg_score / 100)

        if score > 2.0:
            return "high"
        elif score > 1.0:
            return "medium"
        else:
            return "low"

    def _estimate_career_urgency(self, profile: Dict[str, Any]) -> str:
        """Estimate career urgency"""
        employment = profile.get("constraints_analysis", {}).get("employment_status", "employed")
        timeline = profile.get("goals_analysis", {}).get("target_timeline_months", 6)

        if employment != "employed" or timeline < 3:
            return "high"
        elif timeline < 6:
            return "medium"
        else:
            return "low"


def predict_difficulty_level(analyzed_profile: Dict[str, Any]) -> Tuple[str, float]:
    """Convenience function to predict difficulty"""
    agent = DifficultyPredictionMLAgent()
    return agent.predict_difficulty(analyzed_profile)
