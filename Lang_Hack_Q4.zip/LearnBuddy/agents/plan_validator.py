#!/usr/bin/env python3
"""
Plan Validator Agent - LLM Based
Validates plan feasibility and quality using intelligent LLM feedback
"""

import os
import json
from typing import Dict, Any, List, Tuple

class PlanValidatorAgent:
    """Validate learning plan quality and feasibility using LLM"""

    def __init__(self):
        self.api_key = os.getenv("GEMINI_API_KEY_4", "")
        try:
            from langchain_google_genai import ChatGoogleGenerativeAI
            self.llm = ChatGoogleGenerativeAI(model="gemini-2.0-flash", temperature=0.3, api_key=self.api_key)
        except:
            self.llm = None
            print(" Gemini API not available, using rule-based validation")

    def validate_plans(self, plans: Tuple[Dict, Dict, Dict], analyzed_profile: Dict[str, Any]) -> Tuple[Dict, Dict, Dict, List[str]]:
        """Validate 3 plans and return validated versions with intelligent issues"""

        plan_a, plan_b, plan_c = plans

        # Ensure all required fields
        plan_a_val = self._validate_plan(plan_a, "A")
        plan_b_val = self._validate_plan(plan_b, "B")
        plan_c_val = self._validate_plan(plan_c, "C")

        # Use LLM for intelligent validation
        issues = self._validate_with_llm(plan_a_val, plan_b_val, plan_c_val, analyzed_profile)

        return plan_a_val, plan_b_val, plan_c_val, issues

    def _validate_with_llm(self, plan_a: Dict, plan_b: Dict, plan_c: Dict, profile: Dict[str, Any]) -> List[str]:
        """Validate plans using LLM for intelligent feedback"""

        # Prepare plan summaries
        plans_summary = f"""
PLAN A (Conservative):
- Duration: {plan_a.get('duration_weeks')} weeks
- Hours/Week: {plan_a.get('hours_per_week')} hours
- Total Hours: {plan_a.get('total_hours', 'N/A')} hours
- Topics: {', '.join(plan_a.get('topics', [])[:5])}
- Milestones: {', '.join(plan_a.get('milestones', []))}

PLAN B (Standard):
- Duration: {plan_b.get('duration_weeks')} weeks
- Hours/Week: {plan_b.get('hours_per_week')} hours
- Total Hours: {plan_b.get('total_hours', 'N/A')} hours
- Topics: {', '.join(plan_b.get('topics', [])[:5])}
- Milestones: {', '.join(plan_b.get('milestones', []))}

PLAN C (Aggressive):
- Duration: {plan_c.get('duration_weeks')} weeks
- Hours/Week: {plan_c.get('hours_per_week')} hours
- Total Hours: {plan_c.get('total_hours', 'N/A')} hours
- Topics: {', '.join(plan_c.get('topics', [])[:5])}
- Milestones: {', '.join(plan_c.get('milestones', []))}

LEARNER CONSTRAINTS:
- Hours Available/Week: {profile.get('constraints_analysis', {}).get('hours_per_week', 10)}
- Goal Timeline: {profile.get('constraints_analysis', {}).get('goal_timeline_months', 'N/A')} months
- Identified Gaps: {', '.join(profile.get('identified_gaps', []))}
- Urgency Level: {profile.get('urgency_level', 'medium')}
"""

        prompt = f"""
You are an expert educational plan validator. Review these three learning plans against the learner's profile and constraints.
Identify any feasibility issues, quality concerns, and misalignments with the learner's goals.

{plans_summary}

For EACH issue found:
1. Be specific about which plan(s) are affected
2. Explain WHY it's an issue
3. Suggest what could be adjusted

Focus on:
- Time feasibility (realistic given learner's hours available)
- Goal alignment (does the plan address identified gaps and learning goals)
- Prerequisite coverage (are foundations before advanced topics)
- Difficulty progression (gradual vs. too steep)
- Topic relevance (are topics aligned with learner's domain)
- Milestone realism (are checkpoints achievable)

Return ONLY a JSON array of issue strings, one per problem found. Example format:
["Issue 1: Specific feedback and suggestion", "Issue 2: ..."]

If no critical issues, return an empty array: []
"""

        response = self.llm.invoke(prompt)
        response_text = response.content if hasattr(response, 'content') else str(response)

        # Parse JSON response
        json_start = response_text.find('[')
        json_end = response_text.rfind(']') + 1
        if json_start >= 0 and json_end > json_start:
            json_str = response_text[json_start:json_end]
            issues = json.loads(json_str)

            # Ensure all items are strings
            if isinstance(issues, list):
                return [str(issue) for issue in issues]
            return []

        raise ValueError("LLM validation response did not contain JSON array")

    def _validate_plan(self, plan: Dict[str, Any], variant: str) -> Dict[str, Any]:
        """Ensure plan has all required fields"""

        validated = plan.copy()

        # Ensure all required fields
        required_fields = ["duration_weeks", "hours_per_week", "topics", "milestones", "success_criteria"]
        for field in required_fields:
            if field not in validated or not validated[field]:
                validated[field] = plan.get(field, self._get_default_value(field))

        return validated

    def _get_default_value(self, field: str) -> Any:
        """Get default value for field"""
        defaults = {
            "duration_weeks": 12,
            "hours_per_week": 10,
            "topics": ["Fundamentals", "Core Concepts", "Application"],
            "milestones": ["Foundation", "Intermediate", "Advanced"],
            "success_criteria": ["Complete course", "Build project", "Assess mastery"],
        }
        return defaults.get(field, None)


def validate_learning_plans(plans: Tuple[Dict, Dict, Dict], analyzed_profile: Dict[str, Any]) -> Tuple[Dict, Dict, Dict, List[str]]:
    """Convenience function"""
    agent = PlanValidatorAgent()
    return agent.validate_plans(plans, analyzed_profile)
