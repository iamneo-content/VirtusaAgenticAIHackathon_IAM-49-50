LEARNBUDDY MICRO: PERSONALIZED LEARNING PLAN GENERATION SYSTEM
================================================================

PROBLEM STATEMENT
=================

LearnBuddy Micro is an AI-powered system designed to generate personalized micro-learning plans
for diverse learners. The system analyzes individual learner profiles, identifies learning gaps,
predicts optimal difficulty levels, and generates three customized learning plan variants with
varying intensity levels.

The core challenge involves orchestrating multiple specialized agents (logic-based, ML-based, and
LLM-based) in a coordinated workflow, managing complex state transitions, handling errors gracefully,
and producing high-quality personalized recommendations that align with learner constraints and goals.

Key Requirements:
1. Parse and validate diverse learner profile formats
2. Extract meaningful features from profiles using multiple techniques
3. Predict learning gaps using multi-label ML classification
4. Predict optimal difficulty using multi-class ML classification
5. Generate three plan variants using LLM with different intensities
6. Validate generated plans for feasibility and quality
7. Rewrite plans in adaptive, personalized language
8. Generate professional reports with quality metrics
9. Handle errors gracefully without losing intermediate results
10. Manage parallel execution for independent ML tasks


PROJECT STRUCTURE
=================

LearnBuddy/
|
+-- main.py                          (Streamlit web interface entry point)
|
+-- graph.py                         (Programmatic API entry point)
|
+-- state.py                         (State management and utilities)
|
+-- workflow/
|   +-- __init__.py
|   +-- workflow.py                  (LangGraph workflow orchestration)
|
+-- nodes/                           (8 execution nodes)
|   +-- __init__.py
|   +-- profile_parser_node.py       (Node 1: Parse profiles)
|   +-- profile_analyzer_node.py     (Node 2: Extract features)
|   +-- gap_detector_node.py         (Node 3: ML gap detection)
|   +-- difficulty_predictor_node.py (Node 4: ML difficulty prediction)
|   +-- plan_generator_node.py       (Node 5: LLM plan generation)
|   +-- plan_validator_node.py       (Node 6: LLM plan validation)
|   +-- coach_rewriter_node.py       (Node 7: LLM friendly rewriting)
|   +-- report_saver_node.py         (Node 8: Report generation and saving)
|
+-- agents/                          (9 agent implementations)
|   +-- __init__.py
|   +-- profile_parser.py            (Logic: Profile validation)
|   +-- profile_analyzer.py          (Logic: Feature extraction)
|   +-- gap_detection_ml.py          (ML Model 1: OneVsRest + LinearSVC)
|   +-- difficulty_prediction_ml.py  (ML Model 2: RandomForest)
|   +-- plan_generator_llm.py        (LLM: Gemini for plan generation)
|   +-- plan_validator.py            (LLM: Gemini for validation)
|   +-- coach_rewriter_llm.py        (LLM: Gemini for rewriting)
|   +-- report_saver.py              (LLM: Gemini for reporting)
|
+-- ml/
|   +-- model/                       (Trained model artifacts: 9 pkl files)
|   |   +-- gap_model.pkl
|   |   +-- gap_vectorizer.pkl
|   |   +-- gap_scaler.pkl
|   |   +-- gap_mlb.pkl
|   |   +-- gap_labels.json
|   |   +-- difficulty_model.pkl
|   |   +-- difficulty_scaler.pkl
|   |   +-- difficulty_label_encoder.pkl
|   |   +-- difficulty_categorical_encoders.pkl
|   |
|   +-- train_model/                 (Model training scripts)
|   |   +-- train_gap_model.py
|   |   +-- train_difficulty_model.py
|   |
|   +-- cleaning/                    (Data preprocessing)
|   |   +-- clean_gap_data.py
|   |   +-- clean_difficulty_data.py
|
+-- data/
|   +-- input/
|   |   +-- learner_profiles/        (16 sample learner profiles)
|   |       +-- learn_001.json
|   |       +-- learn_002.json
|   |       ...
|   |       +-- learn_015.json
|   |       +-- all_learners.json
|   |
|   +-- raw/                         (Raw training data)
|   |   +-- gap_training_raw.csv
|   |   +-- gap_eval_raw.csv
|   |   +-- difficulty_training_raw.csv
|   |   +-- difficulty_eval_raw.csv
|   |
|   +-- processed/                   (Cleaned training data)
|       +-- gap_train_clean.csv
|       +-- gap_eval_clean.csv
|       +-- difficulty_train_clean.csv
|       +-- difficulty_eval_clean.csv
|
+-- output/                          (Generated reports per learner)
|   +-- LEARN_001/
|   |   +-- micro_plan_report.txt
|   |   +-- micro_plan.json
|   |   +-- evaluation_metrics.json
|   +-- LEARN_002/
|   |   ...
|
+-- tests.py                         (17 unit and integration tests)
|
+-- requirements.txt                 (Python dependencies)
|
+-- .env                             (Environment variables: 4 Gemini API keys)


FILE PURPOSES AND METHODS
=========================

1. MAIN ENTRY POINTS
--------------------

main.py (295 lines)
Purpose: Streamlit web interface for user interaction
Key Components:
  - main() function
    Returns: None
    Side effects: Renders Streamlit UI with sidebar profile selection,
                  generates workflow, displays results in 5 tabs
    Behavior: Loads learner profiles from JSON, triggers workflow,
              displays analysis and plans

graph.py (92 lines)
Purpose: Programmatic API for non-web usage
Key Methods:
  - run_microplan(learner_json: Dict) -> MicroPlanState
    Param: learner_json - Raw learner profile dictionary
    Returns: Final state with all analysis and plans
    Purpose: Main entry for programmatic usage

  - run_microplan_from_file(file_path: str) -> MicroPlanState
    Param: file_path - Path to learner JSON profile
    Returns: Complete state
    Purpose: Load profile from file and execute workflow

  - get_microplan_summary(result: MicroPlanState) -> Dict
    Param: result - Complete workflow result state
    Returns: Summary dict with key fields
    Purpose: Extract important information from result

  - print_microplan_summary(result: MicroPlanState) -> None
    Param: result - Complete workflow result
    Returns: None
    Purpose: Pretty-print summary to console


2. STATE MANAGEMENT
-------------------

state.py (370 lines)
Purpose: Define complete state schema and utility functions
Key Components:

  MicroPlanState TypedDict (30+ fields):
    Input: learner_json, learner_id
    Profile: normalized_profile, profile_complete
    Analysis: analyzed_profile, derived_metrics, analysis_complete
    ML Results: identified_gaps, gap_confidence_scores, urgency_level,
                recommended_difficulty, difficulty_confidence
    Plans: plan_variant_a/b/c, plan_generation_complete
    Validation: plan_variant_a/b/c_validated, validation_issues,
                validation_complete
    Rewriting: variant_a/b/c_friendly, rewriting_complete
    Reporting: final_report, report_json, quality_metrics, saved_path,
               output_dir, report_complete
    Errors: error_occurred, error_messages

Key Methods:
  - get_initial_state(learner_json: Dict) -> MicroPlanState
    Param: learner_json - Raw learner profile
    Returns: MicroPlanState with all fields initialized to defaults
    Purpose: Create initial state for workflow execution

  - create_output_directory(learner_id: str) -> str
    Param: learner_id - Identifier for learner
    Returns: Path to created directory
    Purpose: Create /output/{learner_id}/ directory structure

  - save_file(file_path: str, content: str) -> bool
    Param: file_path - Full path to save file
    Param: content - File content to write
    Returns: True if successful, False otherwise
    Purpose: Save content to file with error handling

  - calculate_quality_score(state: MicroPlanState) -> Dict[str, float]
    Param: state - Complete workflow state
    Returns: Dict with 6 individual metrics and overall_quality average
    Purpose: Compute quality assessment (0-1 scale)
    Metrics Calculated:
      1. profile_completeness (0.95 or 0.0)
      2. gap_detection_accuracy (0-1 based on number of gaps)
      3. difficulty_confidence (direct ML confidence)
      4. plan_feasibility (0.85 or 0.65)
      5. coaching_adaptation (0.90 or 0.0)
      6. report_completeness (1.0 or 0.0)
      7. overall_quality (average of 6 metrics)

  - format_microplan_report(state: MicroPlanState) -> str
    Param: state - Complete workflow state
    Returns: Formatted text report as string
    Purpose: Create plain text report summary

  - format_list(items: List[str]) -> str
    Param: items - List of strings to format
    Returns: Bullet-point formatted string
    Purpose: Format list as readable bullet points

  - format_plan(plan: Dict) -> str
    Param: plan - Learning plan dictionary
    Returns: Formatted plan as readable text
    Purpose: Format plan details for display

  - format_metrics(metrics: Dict) -> str
    Param: metrics - Dictionary of metric values
    Returns: Formatted metrics as readable text
    Purpose: Format quality metrics for display

  - slugify(text: str, max_length: int = 50) -> str
    Param: text - Text to slugify
    Param: max_length - Maximum output length (default 50)
    Returns: URL-safe slug (e.g., 'severe_chest_pain')
    Purpose: Convert text to safe filename format


3. WORKFLOW ORCHESTRATION
-------------------------

workflow/workflow.py (106 lines)
Purpose: Build and execute LangGraph workflow with 8 nodes
Key Methods:

  - build_workflow() -> CompiledGraph
    Returns: Compiled LangGraph ready for execution
    Purpose: Build DAG with 8 nodes and parallel execution
    Architecture:
      START -> Parser -> Analyzer -> (Gap Detector || Difficulty Predictor)
             -> Generator -> Validator -> Rewriter -> Saver -> END
    Features: Parallel execution for nodes 3A and 3B, convergence before node 4

  - run_microplan_workflow(learner_json: dict) -> MicroPlanState
    Param: learner_json - Raw learner profile dictionary
    Returns: Final MicroPlanState with all analysis and plans
    Purpose: Execute complete workflow from start to finish
    Steps:
      1. Build workflow via build_workflow()
      2. Initialize state via get_initial_state()
      3. Execute app.invoke(initial_state)
      4. Return final state


4. EXECUTION NODES
------------------

profile_parser_node.py
Purpose: Parse and validate learner JSON profiles
Function Signature: profile_parser_node(state: MicroPlanState) -> dict
Input State Fields: learner_json
Calls: parse_learner_profile(learner_json)
Output State Updates:
  - normalized_profile: Cleaned and validated profile dictionary
  - profile_complete: Boolean indicating success
  - error_occurred: True if validation failed
  - error_messages: List of error strings

profile_analyzer_node.py
Purpose: Extract features and derived metrics from normalized profile
Function Signature: profile_analyzer_node(state: MicroPlanState) -> dict
Input State Fields: normalized_profile, learner_json
Calls: analyze_learner_profile(normalized_profile)
Output State Updates:
  - analyzed_profile: Dictionary with 6 feature groups
  - analysis_complete: Boolean indicating success

gap_detector_node.py
Purpose: Detect learning gaps using ML Model 1 (OneVsRest + LinearSVC)
Function Signature: gap_detector_node(state: MicroPlanState) -> dict
Input State Fields: analyzed_profile
Calls: detect_learning_gaps(analyzed_profile)
Output State Updates:
  - identified_gaps: List of 1-12 gap category strings
  - gap_confidence_scores: Dictionary mapping gaps to confidence (0-1)
  - urgency_level: One of critical/high/medium/low
  - gap_detection_complete: Boolean indicating success
Parallel Execution: Runs simultaneously with difficulty_predictor_node

difficulty_predictor_node.py
Purpose: Predict optimal difficulty using ML Model 2 (RandomForest)
Function Signature: difficulty_predictor_node(state: MicroPlanState) -> dict
Input State Fields: analyzed_profile
Calls: predict_difficulty_level(analyzed_profile)
Output State Updates:
  - recommended_difficulty: One of Beginner/Intermediate/Advanced
  - difficulty_confidence: Float between 0 and 1
  - difficulty_prediction_complete: Boolean indicating success
Parallel Execution: Runs simultaneously with gap_detector_node
Graceful Degradation: Returns (Intermediate, 0.5) on feature mismatch errors

plan_generator_node.py
Purpose: Generate 3 micro-learning plan variants using LLM
Function Signature: plan_generator_node(state: MicroPlanState) -> dict
Input State Fields: analyzed_profile, identified_gaps, recommended_difficulty
Calls: generate_microlearning_plans(analyzed, gaps, difficulty)
Output State Updates:
  - plan_variant_a: Conservative plan dictionary
  - plan_variant_b: Standard plan dictionary
  - plan_variant_c: Aggressive plan dictionary
  - plan_generation_complete: Boolean indicating success
Error Handling: Separates ValueError (JSON parsing) from general exceptions

plan_validator_node.py
Purpose: Validate generated plans for feasibility and quality
Function Signature: plan_validator_node(state: MicroPlanState) -> dict
Input State Fields: plan_variant_a/b/c, analyzed_profile
Calls: validate_learning_plans(plans_tuple, analyzed_profile)
Output State Updates:
  - plan_variant_a/b/c_validated: Validated plan dictionaries
  - validation_issues: List of warning/concern strings from LLM
  - validation_complete: Boolean indicating success
Validation Checks: Time feasibility, goal alignment, prerequisites,
                    difficulty progression, topic relevance, milestone realism

coach_rewriter_node.py
Purpose: Rewrite plans in adaptive, friendly language
Function Signature: coach_rewriter_node(state: MicroPlanState) -> dict
Input State Fields: plan_variant_a/b/c_validated, analyzed_profile
Calls: rewrite_learning_plans(plans_tuple, analyzed_profile)
Output State Updates:
  - variant_a_friendly: Rewritten text in adaptive tone
  - variant_b_friendly: Rewritten text in adaptive tone
  - variant_c_friendly: Rewritten text in adaptive tone
  - rewriting_complete: Boolean indicating success
Tone Selection: Determines tone based on age and learning_style
Tones Available: encouraging_youth, conversational, practical_action_oriented,
                 visual_metaphor_based, analytical

report_saver_node.py
Purpose: Generate and save final professional reports
Function Signature: report_saver_node(state: MicroPlanState) -> dict
Input State Fields: entire state (all 30+ fields)
Calls: save_microplan_report(state)
Output State Updates:
  - saved_path: Path to text report file
  - output_dir: Directory containing all outputs
  - quality_metrics: Dictionary of 7 quality scores
  - report_complete: Boolean indicating success
Outputs Generated:
  1. micro_plan_report.txt - Professional prose report (7 sections)
  2. micro_plan.json - Structured data report
  3. evaluation_metrics.json - Quality assessment scores


5. AGENT IMPLEMENTATIONS
------------------------

ProfileParserAgent (profile_parser.py)
Purpose: Validate and normalize learner JSON profiles
Key Methods:

  - __init__() -> None
    Initializes errors and warnings lists

  - validate_profile(profile: Dict) -> Tuple[bool, List, List]
    Param: profile - Learner profile dictionary
    Returns: (is_valid, error_list, warning_list)
    Purpose: Validate required fields, types, and nested structures
    Validations:
      1. Required fields: learner_id, personal_info, educational_background,
                         learning_profile, current_status, learning_goals,
                         constraints
      2. Type checking: Ensure correct types for each field
      3. Content validation: Age 8-100, GPA 0-4.0, hours 0-168/week,
                            timeline 1-60 months, etc.

  - normalize_profile(profile: Dict) -> Dict
    Param: profile - Raw profile dictionary
    Returns: Normalized profile with cleaned string values
    Purpose: Normalize strings to lowercase, preserve numeric/list types

  - parse(learner_json: Dict) -> Tuple[Dict, bool, List]
    Param: learner_json - Raw learner profile
    Returns: (normalized_profile, is_valid, error_messages)
    Purpose: Main parse function combining validation and normalization


ProfileAnalyzerAgent (profile_analyzer.py)
Purpose: Extract features and calculate derived metrics
Key Methods:

  - __init__() -> None
    Initializes empty agent (stateless)

  - analyze(normalized_profile: Dict) -> Dict
    Param: normalized_profile - Cleaned profile from parser
    Returns: analyzed_profile with 6 feature groups
    Purpose: Extract features for downstream ML/LLM components
    Feature Groups:
      1. Demographics: age, timezone, country, education_level,
                       years_educated, field_of_study
      2. Learning Characteristics: style, pace, focus_duration, break_preference,
                                   preferred_formats, instructor_type,
                                   gamification_preference, community_engagement
      3. Proficiency: domain, topic, self_assessed_score, standardized_test_score,
                      assessment_date, current_projects, challenges
      4. Goals Analysis: primary_goal, secondary_goals, target_timeline_months,
                         desired_outcome, career_aspiration, goal_clarity_score,
                         goal_alignment
      5. Constraints Analysis: hours_per_week, budget_limit_usd,
                               certification_needed, employment_status,
                               preferred_study_time, time_pressure_score,
                               financial_constraint
      6. History Analysis: courses_completed, avg_completion_rate, avg_score,
                          learning_trend, avg_time_per_course, consistency_score

  - _extract_demographics(personal_info: Dict, education: Dict) -> Dict
    Purpose: Extract demographic features

  - _extract_learning_characteristics(learning: Dict, preferences: Dict) -> Dict
    Purpose: Extract learning style and characteristic features

  - _extract_proficiency(current: Dict) -> Dict
    Purpose: Extract current proficiency information

  - _extract_goals(goals: Dict, preferences: Dict) -> Dict
    Purpose: Extract goal information and calculate goal_clarity_score
    Scoring: 80 if primary + secondary goals, 60 if primary only, 50 default

  - _extract_constraints(constraints: Dict, learning: Dict) -> Dict
    Purpose: Extract constraint information and calculate time_pressure_score
    Formula: time_pressure = min(100, max(0, 100 * (1 - hours_per_week*4*months/200)))

  - _analyze_learning_history(history: List) -> Dict
    Purpose: Analyze past learning behavior and calculate trend
    Trend Calculation: If 6+ courses, compare recent 3 vs earlier 3 scores
    Values: improving / declining / stable / unknown

  - _calculate_consistency(completion_rates: List) -> float
    Purpose: Calculate learning consistency (0-1)
    Formula: 1.0 - (std_dev / 100), capped to [0, 1]


GapDetectionMLAgent (gap_detection_ml.py)
Purpose: Detect learning gaps using ML Model 1 (OneVsRest + LinearSVC)
Key Methods:

  - load_gap_artifacts() -> None
    Purpose: Load trained model artifacts into module-level variables
    Artifacts Loaded:
      1. gap_model.pkl - OneVsRest + LinearSVC classifier
      2. gap_vectorizer.pkl - TF-IDF vectorizer
      3. gap_scaler.pkl - StandardScaler
      4. gap_mlb.pkl - MultiLabelBinarizer
      5. gap_labels.json - 12 gap category labels

  - prepare_gap_text_features(profile: Dict) -> str
    Param: profile - Analyzed profile dictionary
    Returns: Combined text string
    Purpose: Extract text features from profile fields
    Fields Used: domain, learning_style, challenges, desired_outcome

  - prepare_gap_numeric_features(profile: Dict) -> np.ndarray
    Param: profile - Analyzed profile dictionary
    Returns: Array of shape (1, 15) with numeric features
    Purpose: Extract and prepare numeric features
    Features (15 total):
      1-8: age, hours_per_week, self_assessed_score, standardized_test_score,
           focus_duration, goal_clarity, time_pressure, consistency
      9-15: motivation, learning_pace, budget, num_gaps, gpa,
            years_experience, target_timeline

  - determine_gap_urgency(profile: Dict, gaps: List) -> str
    Param: profile - Analyzed profile
    Param: gaps - List of identified gaps
    Returns: One of critical/high/medium/low
    Purpose: Determine urgency level based on proficiency and gaps
    Logic:
      critical if proficiency < 30
      high if proficiency < 50 OR prerequisite_foundation in gaps
      medium if proficiency < 70
      low otherwise

  - detect_gaps_main(analyzed_profile: Dict) -> Tuple[List, Dict, str]
    Param: analyzed_profile - Profile with extracted features
    Returns: (identified_gaps, confidence_scores, urgency_level)
    Purpose: Core gap detection using ML Model 1
    Steps:
      1. Prepare text features (TF-IDF)
      2. Prepare numeric features (15 features, scaled)
      3. Combine via hstack
      4. Predict with model (binary output)
      5. Get probabilities (fallback to decision_function if needed)
      6. Determine urgency level
    Error Handling: ValueError for dimension mismatch, returns defaults


DifficultyPredictionMLAgent (difficulty_prediction_ml.py)
Purpose: Predict optimal difficulty using ML Model 2 (RandomForest)
Key Methods:

  - _load_artifacts() -> None
    Purpose: Load trained model artifacts
    Artifacts Loaded:
      1. difficulty_model.pkl - RandomForest classifier
      2. difficulty_scaler.pkl - StandardScaler
      3. difficulty_label_encoder.pkl - Label encoder
      4. difficulty_categorical_encoders.pkl - OneHotEncoders

  - _prepare_features(profile: Dict) -> np.ndarray
    Param: profile - Analyzed profile
    Returns: Combined feature matrix
    Purpose: Prepare feature vector from analyzed profile

  - _extract_numeric_features(profile: Dict) -> List
    Param: profile - Analyzed profile
    Returns: 16 numeric features
    Purpose: Extract numeric features
    Features:
      1-3: age, hours_per_week, self_assessed_score
      4: learning_pace_factor (1.0/-0.3/0.0)
      5-10: avg_time_per_course, consistency, goal_alignment,
            courses_completed (capped 10), avg_score, completion_rate
      11-16: complexity, prerequisites_count, prerequisites_mastery,
             hours_to_master, weeks_available, deadline_weeks

  - _extract_categorical_features(profile: Dict) -> Dict
    Param: profile - Analyzed profile
    Returns: 8 categorical features
    Purpose: Extract categorical features
    Features: education_level, learning_style, employment_status,
             past_performance_trend, motivation_level, career_urgency,
             preferred_difficulty_in_past, budget_constraint

  - _estimate_motivation(profile: Dict) -> str
    Param: profile - Analyzed profile
    Returns: high/medium/low
    Purpose: Estimate motivation level

  - _estimate_career_urgency(profile: Dict) -> str
    Param: profile - Analyzed profile
    Returns: high/medium/low
    Purpose: Estimate career urgency

  - predict_difficulty(analyzed_profile: Dict) -> Tuple[str, float]
    Param: analyzed_profile - Profile with features
    Returns: (difficulty_level, confidence)
    Purpose: Predict optimal difficulty and confidence


PlanGeneratorLLMAgent (plan_generator_llm.py)
Purpose: Generate 3 micro-learning plan variants using Gemini LLM
Key Methods:

  - __init__() -> None
    Purpose: Initialize LLM connection
    LLM Used: Gemini 2.0 Flash (temperature=0.3)
    API Key: GEMINI_API_KEY_1

  - generate_plans(analyzed_profile: Dict, gaps: List, difficulty: str) -> Tuple
    Param: analyzed_profile - Analyzed learner profile
    Param: gaps - List of identified learning gaps
    Param: difficulty - Recommended difficulty level
    Returns: (plan_a, plan_b, plan_c) dictionaries
    Purpose: Generate 3 plan variants
    Variants:
      Plan A (Conservative): timeline*1.5, 8hrs/week, low intensity
      Plan B (Standard): timeline*1.0, 10hrs/week, medium intensity
      Plan C (Aggressive): timeline*0.7, 15hrs/week, high intensity

  - _create_plan_variant(domain: str, variant: str, timeline: float,
                         intensity: str, focus_areas: List,
                         prerequisites: bool) -> Dict
    Purpose: Create single plan variant using LLM
    Returns: Plan dictionary with fields:
      variant, duration_weeks, hours_per_week, total_hours, intensity,
      topics, resources, milestones, prerequisites, success_criteria,
      difficulty_progression
    LLM Prompt: Detailed requirements for domain and variant
    JSON Parsing: Regex extract r'\{.*\}' from response


PlanValidatorAgent (plan_validator.py)
Purpose: Validate learning plans for feasibility and quality
Key Methods:

  - __init__() -> None
    Purpose: Initialize LLM connection
    LLM Used: Gemini 2.0 Flash (temperature=0.3)
    API Key: GEMINI_API_KEY_4

  - validate_plans(plans: Tuple, analyzed_profile: Dict) -> Tuple
    Param: plans - Tuple of (plan_a, plan_b, plan_c)
    Param: analyzed_profile - Analyzed profile
    Returns: (plan_a_val, plan_b_val, plan_c_val, issues_list)
    Purpose: Validate 3 plans and return validated versions with issues

  - _validate_with_llm(plan_a: Dict, plan_b: Dict, plan_c: Dict,
                        profile: Dict) -> List
    Purpose: Validate plans using LLM for intelligent feedback
    Validation Checks:
      1. Time feasibility vs learner hours available
      2. Goal alignment with identified gaps
      3. Prerequisite coverage and ordering
      4. Difficulty progression (gradual vs steep)
      5. Topic relevance to domain
      6. Milestone realism and achievability

  - _validate_plan(plan: Dict, variant: str) -> Dict
    Purpose: Ensure plan has all required fields
    Defaults Added: duration_weeks, hours_per_week, topics,
                   milestones, success_criteria


CoachRewriterLLMAgent (coach_rewriter_llm.py)
Purpose: Rewrite plans in adaptive, friendly language
Key Methods:

  - __init__() -> None
    Purpose: Initialize LLM connection
    LLM Used: Gemini 2.0 Flash (temperature=0.5)
    API Key: GEMINI_API_KEY_2
    Note: Higher temperature (0.5) for creative/motivational tone

  - rewrite_plans(plans: Tuple, analyzed_profile: Dict) -> Tuple
    Param: plans - Tuple of (plan_a, plan_b, plan_c)
    Param: analyzed_profile - Analyzed profile
    Returns: (text_a, text_b, text_c) friendly-tone texts
    Purpose: Rewrite plans in adaptive language

  - _determine_tone(learning_style: str, age: int) -> str
    Param: learning_style - From profile (visual/auditory/kinesthetic)
    Param: age - From profile demographics
    Returns: Tone string (encouraging_youth/conversational/practical/visual/analytical)
    Purpose: Select appropriate tone for learner
    Logic:
      age < 18: encouraging_youth
      auditory: conversational
      kinesthetic: practical_action_oriented
      visual: visual_metaphor_based
      default: analytical

  - _rewrite_plan(plan: Dict, tone: str, title: str) -> str
    Param: plan - Validated plan dictionary
    Param: tone - Adaptive tone (from _determine_tone)
    Param: title - Plan title (Conservative/Standard/Aggressive)
    Returns: Rewritten text in friendly, adaptive language
    Purpose: Rewrite single plan with LLM
    LLM Prompt Includes:
      1. Motivational overview
      2. Inspiring learning journey breakdown
      3. Resource context and rationale
      4. Achievable success criteria
      5. Personalized pro tips
      6. Encouraging conclusion


ReportSaverAgent (report_saver.py)
Purpose: Generate and save final reports with quality metrics
Key Methods:

  - __init__() -> None
    Purpose: Initialize output directory and LLM
    LLM Used: Gemini 2.0 Flash (temperature=0.3)
    API Key: GEMINI_API_KEY_3

  - save_report(state: Dict) -> Dict
    Param: state - Complete workflow state
    Returns: {saved_path, output_dir, json_path, metrics_path, quality_metrics}
    Purpose: Generate and save complete report
    Output Files Created:
      1. micro_plan_report.txt - Professional prose (7 sections)
      2. micro_plan.json - Structured data report
      3. evaluation_metrics.json - Quality metrics

  - _generate_llm_report(state: Dict) -> str
    Param: state - Complete workflow state
    Returns: Professional prose report
    Purpose: Generate report text using LLM
    Sections (7 total):
      1. Executive Summary
      2. Learning Gap Analysis
      3. Personalized Assessment
      4. Three Learning Plan Options
      5. Recommendations
      6. Success Strategies
      7. Next Steps

  - _create_json_report(state: Dict) -> Dict
    Param: state - Complete workflow state
    Returns: Structured JSON report
    Purpose: Create structured data representation
    Structure:
      metadata: learner_id, timestamp, version
      learner_profile: age, education, learning_style
      analysis: gaps, urgency, difficulty, confidence
      learning_plans: conservative/standard/aggressive
      coach_recommendations: friendly texts
      quality_metrics: 7 scores
      validation: issues, passed flag


RUNNING COMMANDS
================

Setup and Installation
----------------------

1. Install Python dependencies:
   pip install -r requirements.txt

2. Create .env file with API keys:
   GEMINI_API_KEY_1=your_api_key_1
   GEMINI_API_KEY_2=your_api_key_2
   GEMINI_API_KEY_3=your_api_key_3
   GEMINI_API_KEY_4=your_api_key_4


Running the Application
-----------------------

Option 1: Web Interface (Streamlit)
Command: streamlit run main.py
Usage: Open browser to localhost:8501
Features:
  - Select learner profile from sidebar
  - Generate plans with one click
  - View analysis in 5 tabs
  - Download results

Option 2: Programmatic API
Command: python
Python code example:
  from graph import run_microplan, print_microplan_summary
  import json

  with open('data/input/learner_profiles/learn_001.json') as f:
      learner = json.load(f)

  result = run_microplan(learner)
  print_microplan_summary(result)


Running Tests
-------------

Command: pytest tests.py -v
Output Shows: 17 test cases covering:
  - State initialization and utilities
  - Profile parser validation and normalization
  - Profile analyzer feature extraction
  - Gap detection ML predictions
  - Difficulty prediction ML
  - Node execution
  - Workflow integration


Checking Workflow Structure
---------------------------

Command: python
Python code:
  from workflow.workflow import build_workflow
  app = build_workflow()
  print(f'Nodes: {len(app.nodes)}')
  print('Workflow compiled successfully')


OUTPUT AND RESULTS
==================

Typical Workflow Output
-----------------------

When running via main.py or run_microplan_workflow():

[1] PROFILE PARSER NODE
    Profile parsed successfully for LEARN_001

[2] PROFILE ANALYZER NODE
    Profile analyzed successfully

[3] GAP DETECTOR NODE (Parallel)
    Detected 3 gaps with urgency: high

[4] DIFFICULTY PREDICTOR NODE (Parallel)
    Predicted difficulty: Intermediate (75.0% confidence)

[5] PLAN GENERATOR NODE
    Generated 3 plan variants

[6] PLAN VALIDATOR NODE
    Validation warnings: 2
    - Plan C too aggressive for available hours
    - Consider prerequisite review for Plan A

[7] COACH REWRITER NODE
    Rewrote plans in friendly language

[8] REPORT SAVER NODE
    Report saved to /output/LEARN_001/
    Overall Quality Score: 82.5%

WORKFLOW COMPLETE!


Output Files Generated
----------------------

For each learner, three files are created in /output/{learner_id}/:

1. micro_plan_report.txt (Sample excerpt)
   ========================================
   LEARNBUDDY MICRO - LEARNING PLAN
   Personalized Plan Report

   LEARNER INFORMATION
   Name: Alex Kumar
   Learner ID: LEARN_001
   Age: 16
   Education: high_school
   Learning Style: visual
   Primary Domain: programming

   GOAL
   Primary Goal: Learn Full-Stack Web Development
   Timeline: 6 months
   Desired Outcome: Build production-ready web application

   CURRENT PROFICIENCY
   Current Proficiency: 55/100
   Topic: web_development

   ANALYSIS RESULTS

   Identified Learning Gaps:
   - prerequisite_foundation
   - frontend_frameworks
   - backend_architecture

   Gap Urgency Level: HIGH

   Recommended Difficulty Level: Intermediate
   Confidence: 75.0%

   Constraints:
   - Hours per week: 10
   - Budget: 500
   - Certification needed: false

   PERSONALIZED MICRO-LEARNING PLANS

   PLAN VARIANT A - CONSERVATIVE (Slower Pace, Foundation-Heavy)

   Duration: 9 weeks
   Estimated Hours: 72 hours

   Topics to Cover:
   - HTML5 and CSS3 Fundamentals
   - JavaScript ES6 Basics
   - Version Control with Git
   - RESTful API Concepts

   Learning Resources:
   - freeCodeCamp HTML/CSS Course
   - JavaScript.info Tutorial
   - Git Official Documentation
   - REST API Design Best Practices

   Milestones:
   - Week 3: Master HTML/CSS
   - Week 5: JavaScript fundamentals complete
   - Week 7: First REST API working
   - Week 9: Portfolio project demo-ready

   Prerequisites:
   - Basics

   Difficulty Progression:
   Start with fundamental HTML/CSS concepts, gradually introduce JavaScript
   complexity, finally cover API design patterns

   Success Criteria:
   - Build 3 static websites from scratch
   - Write 20 JavaScript functions without frameworks
   - Create simple REST API
   - Deploy to GitHub Pages

   Coach Notes:
   This conservative plan is perfect for building a strong foundation. Take time
   to really understand each concept before moving forward. Visual learners often
   benefit from creating multiple projects at each level. You've got this!

   [Similar sections for PLAN VARIANT B - STANDARD and PLAN VARIANT C - AGGRESSIVE]

   QUALITY METRICS

   Profile Completeness: 95.0%
   Gap Detection Accuracy: 25.0%
   Difficulty Confidence: 75.0%
   Plan Feasibility: 85.0%
   Coaching Adaptation: 90.0%
   Report Completeness: 100.0%
   Overall Quality: 78.3%

   RECOMMENDATIONS FOR SUCCESS

   1. Start with the plan variant that best matches your current schedule
   2. Track your progress weekly using the provided milestones
   3. Adjust pacing if you fall behind or move ahead of schedule
   4. Engage with practice projects to solidify learning
   5. Review prerequisites before moving to advanced topics
   6. Seek help from community forums or mentors when stuck
   7. Take regular breaks to avoid burnout

2. micro_plan.json (Structured data)
   Sample structure:
   {
     "metadata": {
       "learner_id": "LEARN_001",
       "generated_at": "2025-12-05T14:23:45.123456",
       "version": "1.0"
     },
     "learner_profile": {
       "age": 16,
       "education": "high_school",
       "learning_style": "visual"
     },
     "analysis": {
       "identified_gaps": [
         "prerequisite_foundation",
         "frontend_frameworks",
         "backend_architecture"
       ],
       "gap_confidence": {
         "prerequisite_foundation": 0.85,
         "frontend_frameworks": 0.72,
         "backend_architecture": 0.68
       },
       "urgency_level": "high",
       "recommended_difficulty": "Intermediate",
       "difficulty_confidence": 0.75
     },
     "learning_plans": {
       "conservative": {...plan_dict...},
       "standard": {...plan_dict...},
       "aggressive": {...plan_dict...}
     },
     "coach_recommendations": {
       "conservative": "This conservative plan...",
       "standard": "The balanced approach...",
       "aggressive": "This intensive track..."
     },
     "quality_metrics": {...6_metrics...},
     "validation": {
       "issues": ["Plan C may be too aggressive"],
       "passed": false
     }
   }

3. evaluation_metrics.json (Quality assessment)
   {
     "profile_completeness": 0.95,
     "gap_detection_accuracy": 0.25,
     "difficulty_confidence": 0.75,
     "plan_feasibility": 0.85,
     "coaching_adaptation": 0.90,
     "report_completeness": 1.0,
     "overall_quality": 0.7833
   }


Programmatic API Output Example
--------------------------------

Code:
  from graph import run_microplan, print_microplan_summary
  import json

  with open('data/input/learner_profiles/learn_001.json') as f:
      learner = json.load(f)

  result = run_microplan(learner)
  print_microplan_summary(result)

Output:
  ======================================================================
  MICROPLAN GENERATION SUMMARY
  ======================================================================
  Learner: LEARN_001

  Identified Gaps (3):
    - prerequisite_foundation
    - frontend_frameworks
    - backend_architecture

  Urgency Level: HIGH
  Recommended Difficulty: Intermediate
  Confidence: 75%

  Quality Score: 78%

  Validation Warnings (1):
     Plan C too aggressive for 10 hours/week availability

  Output Directory: /Users/balamurale/Downloads/LangHackthon/LearnBuddy/output/LEARN_001
  ======================================================================


Web Interface Output
--------------------

When running via Streamlit (streamlit run main.py):

Sidebar Display:
  LEARNER SELECTION
  - Dropdown menu with 15 learner profiles
  - Profile summary showing:
    Age: 16
    Education: high_school
    Learning Style: visual
    Current Proficiency: 55/100
  - Generate button

Main Tabs (5 tabs):
  1. Analysis Tab:
     - Learner information
     - Proficiency assessment
     - Learning gaps with urgency
     - Recommended difficulty and confidence

  2. Plans Tab:
     - Three plan variants displayed side-by-side
     - Plan A: Conservative (9 weeks, 8 hrs/week)
     - Plan B: Standard (6 weeks, 10 hrs/week)
     - Plan C: Aggressive (4 weeks, 15 hrs/week)
     - Topics, milestones, and resources for each

  3. Recommendations Tab:
     - Coach notes (adaptive tone based on learning style)
     - Validation warnings and concerns
     - Success strategies and tips

  4. Full Report Tab:
     - Complete professional report
     - 7 sections with detailed analysis
     - Formatted for reading and printing

  5. Download Tab:
     - Download options for:
       1. Text report (PDF/TXT)
       2. JSON structured data
       3. Quality metrics (JSON)
     - Links to view files


Error Handling Output
---------------------

If error occurs during workflow:

Example 1: Profile Parsing Error
  [1] PROFILE PARSER NODE
  Error: Missing required field: learning_goals

  Error Status:
    error_occurred: true
    error_messages: [Missing required field: learning_goals]
    profile_complete: false

Example 2: ML Feature Dimension Error
  [4] DIFFICULTY PREDICTOR NODE
  Error: X has 19 features, but RandomForestClassifier is expecting 22 features
  Default fallback: Intermediate, 50% confidence

  Error Status:
    recommended_difficulty: Intermediate
    difficulty_confidence: 0.5

Example 3: LLM JSON Parsing Error
  [5] PLAN GENERATOR NODE
  Error: LLM response format invalid - No JSON object found in response

  Error Status:
    error_occurred: true
    error_messages: [Plan Generation Failed: LLM response format invalid]
    plan_generation_complete: false


Performance Metrics
-------------------

Execution Times (per learner):
  - Profile Parsing: 50-100ms
  - Profile Analysis: 100-200ms
  - Gap Detection (ML): 200-300ms
  - Difficulty Prediction (ML): 200-300ms (parallel)
  - Plan Generation (LLM): 3-5 seconds
  - Plan Validation (LLM): 2-3 seconds
  - Plan Rewriting (LLM): 2-3 seconds
  - Report Generation: 2-3 seconds

  Total Workflow Time: 8-12 seconds (including parallel ML execution)

Quality Scores (typical):
  - Profile Completeness: 85-95%
  - Gap Detection Accuracy: 20-40% (depends on learner profile)
  - Difficulty Confidence: 60-85% (ML model confidence)
  - Plan Feasibility: 65-85% (depends on validation issues)
  - Coaching Adaptation: 85-95% (LLM quality)
  - Report Completeness: 100% (always complete)
  - Overall Quality Score: 70-85% (average)


Sample Execution Log
--------------------

Timestamp: 2025-12-05 14:23:45
Learner: LEARN_001 (Alex Kumar, 16, Visual Learner, Programming)

===============================================================================
LEARNBUDDY MICRO - PERSONALIZED LEARNING PLAN GENERATOR
===============================================================================

[1] PROFILE PARSER NODE
Profile parsed successfully for LEARN_001

[2] PROFILE ANALYZER NODE
Profile analyzed successfully

[3] GAP DETECTOR NODE (Parallel)
Detected 3 gaps with urgency: high

[4] DIFFICULTY PREDICTOR NODE (Parallel)
Predicted difficulty: Intermediate (75.0% confidence)

[5] PLAN GENERATOR NODE
Generated 3 plan variants

[6] PLAN VALIDATOR NODE
Validation warnings: 2
   - Plan C may be too aggressive for 10 hours/week availability
   - Consider additional time for prerequisite mastery in Plan A

[7] COACH REWRITER NODE
Rewrote plans in friendly language

[8] REPORT SAVER NODE
Report saved to /Users/balamurale/Downloads/LangHackthon/LearnBuddy/output/LEARN_001
   Overall Quality Score: 78.3%

===============================================================================
WORKFLOW COMPLETE!
===============================================================================

Output Files:
  1. /output/LEARN_001/micro_plan_report.txt
  2. /output/LEARN_001/micro_plan.json
  3. /output/LEARN_001/evaluation_metrics.json

Execution Summary:
  Total Time: 9.2 seconds
  Status: SUCCESS
  Quality Score: 78.3%

===============================================================================
