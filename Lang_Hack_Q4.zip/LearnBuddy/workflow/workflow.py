#!/usr/bin/env python3
"""
LearnBuddy Micro Workflow Assembly
Builds LangGraph workflow with parallel execution and conditional routing
"""

from langgraph.graph import StateGraph, START, END
from state import MicroPlanState, get_initial_state
from nodes.profile_parser_node import profile_parser_node
from nodes.profile_analyzer_node import profile_analyzer_node
from nodes.gap_detector_node import gap_detector_node
from nodes.difficulty_predictor_node import difficulty_predictor_node
from nodes.plan_generator_node import plan_generator_node
from nodes.plan_validator_node import plan_validator_node
from nodes.coach_rewriter_node import coach_rewriter_node
from nodes.report_saver_node import report_saver_node

def build_workflow():
    """
    Build complete LearnBuddy workflow with LangGraph

    Workflow:
    1. Parse Profile (entry point)
    2. Analyze Profile
    3. [Parallel] Gap Detector + Difficulty Predictor
    4. Plan Generator
    5. Plan Validator
    6. Coach Rewriter
    7. Report Saver (exit point)
    """

    workflow = StateGraph(MicroPlanState)

    # Add all 8 nodes
    workflow.add_node("profile_parser", profile_parser_node)
    workflow.add_node("profile_analyzer", profile_analyzer_node)
    workflow.add_node("gap_detector", gap_detector_node)
    workflow.add_node("difficulty_predictor", difficulty_predictor_node)
    workflow.add_node("plan_generator", plan_generator_node)
    workflow.add_node("plan_validator", plan_validator_node)
    workflow.add_node("coach_rewriter", coach_rewriter_node)
    workflow.add_node("report_saver", report_saver_node)

    # Set entry point
    workflow.set_entry_point("profile_parser")

    # Linear flow: parser → analyzer
    workflow.add_edge("profile_parser", "profile_analyzer")

    # Parallel execution: analyzer → both gap_detector and difficulty_predictor
    workflow.add_edge("profile_analyzer", "gap_detector")
    workflow.add_edge("profile_analyzer", "difficulty_predictor")

    # Convergence: both parallel nodes → plan_generator
    workflow.add_edge("gap_detector", "plan_generator")
    workflow.add_edge("difficulty_predictor", "plan_generator")

    # Linear flow: generator → validator → rewriter → saver
    workflow.add_edge("plan_generator", "plan_validator")
    workflow.add_edge("plan_validator", "coach_rewriter")
    workflow.add_edge("coach_rewriter", "report_saver")

    # End
    workflow.add_edge("report_saver", END)

    # Compile workflow
    return workflow.compile()


def run_microplan_workflow(learner_json: dict) -> MicroPlanState:
    """
    Execute the complete micro-learning plan generation workflow

    Args:
        learner_json: Input learner profile JSON

    Returns:
        Final state with all analysis and plans
    """

    # Build workflow
    app = build_workflow()

    # Initialize state
    initial_state = get_initial_state(learner_json)

    # Run workflow
    print("\n" + "=" * 70)
    print("LEARNBUDDY MICRO - PERSONALIZED LEARNING PLAN GENERATOR")
    print("=" * 70)

    result = app.invoke(initial_state)

    print("\n" + "=" * 70)
    print("WORKFLOW COMPLETE!")
    print("=" * 70)

    return result


# For testing/visualization
if __name__ == "__main__":
    print("LearnBuddy Micro Workflow ready")
    workflow = build_workflow()
    print(f"Workflow compiled successfully with {len(workflow.nodes)} nodes")
