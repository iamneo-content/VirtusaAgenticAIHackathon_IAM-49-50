"""
Plan Generator Node
Generates 3 micro-learning plan variants using LLM.
"""

from state import MicroPlanState
from agents.plan_generator_llm import generate_microlearning_plans


def plan_generator_node(state: MicroPlanState) -> dict:
    """Generate 3 micro-learning plan variants using LLM"""
    print("\n[5] PLAN GENERATOR NODE")
    print("" * 60)

    try:
        analyzed = state["analyzed_profile"]
        gaps = state["identified_gaps"]
        difficulty = state["recommended_difficulty"]

        plan_a, plan_b, plan_c = generate_microlearning_plans(analyzed, gaps, difficulty)

        print(f" Generated 3 plan variants")
        return {
            "plan_variant_a": plan_a,
            "plan_variant_b": plan_b,
            "plan_variant_c": plan_c,
            "plan_generation_complete": True
        }

    except ValueError as e:
        # JSON parsing error or invalid response
        error_msg = f"Plan Generation Failed: LLM response format invalid - {str(e)}"
        print(f" {error_msg}")
        return {
            "error_occurred": True,
            "error_messages": state["error_messages"] + [error_msg],
            "plan_generation_complete": False
        }
    except Exception as e:
        # API errors, network issues, etc.
        error_msg = f"Plan Generation Failed: {type(e).__name__} - {str(e)}"
        print(f" {error_msg}")
        return {
            "error_occurred": True,
            "error_messages": state["error_messages"] + [error_msg],
            "plan_generation_complete": False
        }
