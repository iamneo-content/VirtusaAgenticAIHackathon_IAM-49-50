"""
Gap Detector Node
Detects learning gaps using ML Model 1 (OneVsRest + LinearSVC).
"""

from state import MicroPlanState
from agents.gap_detection_ml import detect_learning_gaps


def gap_detector_node(state: MicroPlanState) -> dict:
    """Detect learning gaps using ML Model 1"""
    print("\n[3] GAP DETECTOR NODE (Parallel)")
    print("" * 60)

    try:
        analyzed = state["analyzed_profile"]
        gaps, confidence_scores, urgency = detect_learning_gaps(analyzed)

        print(f" Detected {len(gaps)} gaps with urgency: {urgency}")

        return {
            "identified_gaps": gaps,
            "gap_confidence_scores": confidence_scores,
            "urgency_level": urgency,
            "gap_detection_complete": True
        }

    except Exception as e:
        error_msg = f"Gap detection error: {str(e)}"
        print(f" Error: {e}")
        return {
            "error_occurred": True,
            "error_messages": state["error_messages"] + [error_msg],
            "gap_detection_complete": False
        }
