"""
Profile Parser Node
Parses and validates learner JSON profiles.
"""

from state import MicroPlanState
from agents.profile_parser import parse_learner_profile


def profile_parser_node(state: MicroPlanState) -> dict:
    """Parse and validate learner JSON profile"""
    print("\n[1] PROFILE PARSER NODE")
    print("" * 60)

    try:
        learner_json = state["learner_json"]
        normalized, is_valid, errors = parse_learner_profile(learner_json)

        if not is_valid:
            print(f" Parsing failed: {errors}")
            return {
                "error_occurred": True,
                "error_messages": state["error_messages"] + errors,
                "profile_complete": False
            }

        print(f" Profile parsed successfully for {state['learner_id']}")
        return {
            "normalized_profile": normalized,
            "profile_complete": True
        }

    except Exception as e:
        error_msg = f"Profile parsing error: {str(e)}"
        print(f" Error: {e}")
        return {
            "error_occurred": True,
            "error_messages": state["error_messages"] + [error_msg],
            "profile_complete": False
        }
