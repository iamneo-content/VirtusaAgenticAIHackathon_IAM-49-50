"""
Plan Validator Node
Validates plans for feasibility and quality.
"""

from state import MicroPlanState
from agents.plan_validator import validate_learning_plans


def plan_validator_node(state: MicroPlanState) -> dict:
    """Validate plans for feasibility and quality"""
    print("\n[6] PLAN VALIDATOR NODE")
    print("" * 60)

    try:
        plans = (state["plan_variant_a"], state["plan_variant_b"], state["plan_variant_c"])
        analyzed = state["analyzed_profile"]

        plan_a_val, plan_b_val, plan_c_val, issues = validate_learning_plans(plans, analyzed)

        if issues:
            print(f" Validation warnings: {len(issues)}")
            for issue in issues:
                print(f"   • {issue}")
        else:
            print(f" All plans validated successfully")

        return {
            "plan_variant_a_validated": plan_a_val,
            "plan_variant_b_validated": plan_b_val,
            "plan_variant_c_validated": plan_c_val,
            "validation_issues": issues,
            "validation_complete": True
        }

    except ValueError as e:
        # JSON parsing error or invalid response
        error_msg = f"Plan Validation Failed: LLM response format invalid - {str(e)}"
        print(f" {error_msg}")
        return {
            "error_occurred": True,
            "error_messages": state["error_messages"] + [error_msg],
            "validation_complete": False
        }
    except Exception as e:
        # API errors, network issues, etc.
        error_msg = f"Plan Validation Failed: {type(e).__name__} - {str(e)}"
        print(f" {error_msg}")
        return {
            "error_occurred": True,
            "error_messages": state["error_messages"] + [error_msg],
            "validation_complete": False
        }
