"""
Difficulty Predictor Node
Predicts optimal difficulty level using ML Model 2 (RandomForest).
"""

from state import MicroPlanState
from agents.difficulty_prediction_ml import predict_difficulty_level


def difficulty_predictor_node(state: MicroPlanState) -> dict:
    """Predict optimal difficulty level using ML Model 2"""
    print("\n[4] DIFFICULTY PREDICTOR NODE (Parallel)")
    print("" * 60)

    try:
        analyzed = state["analyzed_profile"]
        difficulty, confidence = predict_difficulty_level(analyzed)

        print(f" Predicted difficulty: {difficulty} ({confidence:.1%} confidence)")

        return {
            "recommended_difficulty": difficulty,
            "difficulty_confidence": confidence,
            "difficulty_prediction_complete": True
        }

    except Exception as e:
        error_msg = f"Difficulty prediction error: {str(e)}"
        print(f" Error: {e}")
        return {
            "error_occurred": True,
            "error_messages": state["error_messages"] + [error_msg],
            "difficulty_prediction_complete": False
        }
