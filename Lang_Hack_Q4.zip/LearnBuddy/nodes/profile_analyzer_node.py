"""
Profile Analyzer Node
Analyzes profile and extracts derived metrics.
"""

from state import MicroPlanState
from agents.profile_analyzer import analyze_learner_profile


def profile_analyzer_node(state: MicroPlanState) -> dict:
    """Analyze profile and extract derived metrics"""
    print("\n[2] PROFILE ANALYZER NODE")
    print("" * 60)

    try:
        normalized_profile = state["normalized_profile"]
        normalized_profile["learner_json"] = state["learner_json"]

        analyzed = analyze_learner_profile(normalized_profile)

        print(f" Profile analyzed successfully")
        return {
            "analyzed_profile": analyzed,
            "analysis_complete": True
        }

    except Exception as e:
        error_msg = f"Profile analysis error: {str(e)}"
        print(f" Error: {e}")
        return {
            "error_occurred": True,
            "error_messages": state["error_messages"] + [error_msg],
            "analysis_complete": False
        }
