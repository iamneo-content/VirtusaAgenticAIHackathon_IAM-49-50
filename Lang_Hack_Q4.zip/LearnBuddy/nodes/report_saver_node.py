"""
Report Saver Node
Generates and saves final reports.
"""

from state import MicroPlanState
from agents.report_saver import save_microplan_report


def report_saver_node(state: MicroPlanState) -> dict:
    """Generate and save final report"""
    print("\n[8] REPORT SAVER NODE")
    print("" * 60)

    try:
        result = save_microplan_report(state)

        print(f" Report saved to {result.get('output_dir')}")
        print(f"   Overall Quality Score: {result.get('quality_metrics', {}).get('overall_quality', 0):.1%}")

        return {
            "saved_path": result.get("saved_path", ""),
            "output_dir": result.get("output_dir", ""),
            "quality_metrics": result.get("quality_metrics", {}),
            "report_complete": True
        }

    except Exception as e:
        # API errors, file I/O errors, network issues, etc.
        error_msg = f"Report Saving Failed: {type(e).__name__} - {str(e)}"
        print(f" {error_msg}")
        return {
            "error_occurred": True,
            "error_messages": state["error_messages"] + [error_msg],
            "report_complete": False
        }
