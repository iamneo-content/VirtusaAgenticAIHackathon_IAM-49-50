"""
Coach Rewriter Node
Rewrites plans in adaptive, friendly language.
"""

from state import MicroPlanState
from agents.coach_rewriter_llm import rewrite_learning_plans


def coach_rewriter_node(state: MicroPlanState) -> dict:
    """Rewrite plans in adaptive, friendly language"""
    print("\n[7] COACH REWRITER NODE")
    print("" * 60)

    try:
        plans = (state["plan_variant_a_validated"], state["plan_variant_b_validated"], state["plan_variant_c_validated"])
        analyzed = state["analyzed_profile"]

        text_a, text_b, text_c = rewrite_learning_plans(plans, analyzed)

        print(f" Rewrote plans in friendly language")
        return {
            "variant_a_friendly": text_a,
            "variant_b_friendly": text_b,
            "variant_c_friendly": text_c,
            "rewriting_complete": True
        }

    except Exception as e:
        # API errors, network issues, etc.
        error_msg = f"Coach Rewriting Failed: {type(e).__name__} - {str(e)}"
        print(f" {error_msg}")
        return {
            "error_occurred": True,
            "error_messages": state["error_messages"] + [error_msg],
            "rewriting_complete": False
        }
