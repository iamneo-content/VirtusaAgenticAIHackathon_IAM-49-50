LEARNBUDDY PROJECT - AGENT-TO-AGENT COMMUNICATION FLOW
=======================================================

```mermaid
graph TD
    Start([Microplan Generation Starts]) --> PPA[Profile Parser Agent]

    PPA -->|Profile Valid Score >= 95| PAA[Profile Analyzer Agent]
    PPA -->|Profile Validation Failed| SkipAnalysis[Skip Workflow]

    SkipAnalysis --> End([Workflow Terminated])

    PAA -->|Analysis Complete| GDMA[Gap Detection ML Agent]
    PAA -->|Feature Extraction Failed| SkipGapDetection[Skip Gap Detection]

    SkipGapDetection --> End

    PAA -->|Analysis Complete| DPMA[Difficulty Prediction ML Agent]

    GDMA -->|Gaps Detected with Score >= 60| PGA[Plan Generator LLM Agent]
    GDMA -->|Gap Detection Failed| SkipPlanGeneration[Skip Plan Generation]

    SkipPlanGeneration --> End

    DPMA -->|Difficulty Predicted with Confidence >= 50| PGA
    DPMA -->|Difficulty Prediction Failed| DefaultDifficulty[Use Default Difficulty]

    DefaultDifficulty --> PGA

    PGA -->|3 Plan Variants Generated| PVA[Plan Validator LLM Agent]
    PGA -->|Plan Generation Failed| SkipValidation[Skip Validation]

    SkipValidation --> End

    PVA -->|Validation Score >= 70| CRA[Coach Rewriter LLM Agent]
    PVA -->|Validation Score 50-69| CRA
    PVA -->|Validation Failed| SkipRewriting[Skip Rewriting]

    SkipRewriting --> End

    CRA -->|Plans Rewritten Successfully| RSA[Report Saver Agent]
    CRA -->|Rewriting Failed| SkipReporting[Skip Report Generation]

    SkipReporting --> End

    RSA -->|Report Quality >= 75| HighQuality[HIGH Quality Report]
    RSA -->|Report Quality 50-74| MediumQuality[MEDIUM Quality Report]
    RSA -->|Report Quality < 50| LowQuality[LOW Quality Report]

    HighQuality --> SaveResults[Save All Results and Artifacts]
    MediumQuality --> SaveResults
    LowQuality --> SaveResults

    SaveResults --> GenerateOutputFiles[Generate Output Files]
    GenerateOutputFiles --> End

    style Start fill:#c8e6c9,stroke:#1b5e20,stroke-width:2px
    style End fill:#c8e6c9,stroke:#1b5e20,stroke-width:2px

    style PPA fill:#e1f5ff,stroke:#01579b,stroke-width:2px
    style PAA fill:#f3e5f5,stroke:#4a148c,stroke-width:2px
    style GDMA fill:#fff3e0,stroke:#e65100,stroke-width:2px
    style DPMA fill:#fff3e0,stroke:#e65100,stroke-width:2px
    style PGA fill:#fce4ec,stroke:#880e4f,stroke-width:2px
    style PVA fill:#e8f5e9,stroke:#1b5e20,stroke-width:2px
    style CRA fill:#b2dfdb,stroke:#00695c,stroke-width:2px
    style RSA fill:#ede7f6,stroke:#311b92,stroke-width:2px

    style SkipAnalysis fill:#ffebee,stroke:#b71c1c,stroke-width:1px,stroke-dasharray: 5 5
    style SkipGapDetection fill:#ffebee,stroke:#b71c1c,stroke-width:1px,stroke-dasharray: 5 5
    style SkipPlanGeneration fill:#ffebee,stroke:#b71c1c,stroke-width:1px,stroke-dasharray: 5 5
    style SkipValidation fill:#ffebee,stroke:#b71c1c,stroke-width:1px,stroke-dasharray: 5 5
    style SkipRewriting fill:#ffebee,stroke:#b71c1c,stroke-width:1px,stroke-dasharray: 5 5
    style SkipReporting fill:#ffebee,stroke:#b71c1c,stroke-width:1px,stroke-dasharray: 5 5
    style DefaultDifficulty fill:#ffebee,stroke:#b71c1c,stroke-width:1px,stroke-dasharray: 5 5

    style HighQuality fill:#c8e6c9,stroke:#2e7d32,stroke-width:2px
    style MediumQuality fill:#fff9c4,stroke:#f57f17,stroke-width:2px
    style LowQuality fill:#ffcdd2,stroke:#c62828,stroke-width:2px

    style SaveResults fill:#e1bee7,stroke:#6a1b9a,stroke-width:2px
    style GenerateOutputFiles fill:#b2dfdb,stroke:#00695c,stroke-width:2px
```

AGENT COMMUNICATION MATRIX
===========================

Agent Data Flow:

1. PROFILE PARSER AGENT
   Input From: User (learner JSON profile)
   Output To: Profile Analyzer Agent
   Data Exchanged: normalized_profile (validated and cleaned)
   Validation: 7 required fields, type checking, nested structure validation
   Error Handling: Returns validation errors if format incorrect

2. PROFILE ANALYZER AGENT
   Input From: Profile Parser Agent
   Output To: Gap Detection ML Agent + Difficulty Prediction ML Agent (parallel)
   Data Exchanged: analyzed_profile (6 feature groups)
   Features Extracted:
     - Demographics (age, education, timezone, country)
     - Learning Characteristics (style, pace, focus_duration, preferences)
     - Proficiency (domain, topic, scores, challenges)
     - Goals Analysis (goals, timeline, clarity_score, alignment)
     - Constraints Analysis (hours, budget, employment, time_pressure)
     - History Analysis (courses, trend, consistency, avg_score)
   Error Handling: Returns feature extraction errors

3. GAP DETECTION ML AGENT (Parallel Execution)
   Input From: Profile Analyzer Agent
   Output To: Plan Generator LLM Agent
   Data Exchanged:
     - identified_gaps (list of 1-12 learning gaps)
     - gap_confidence_scores (dict with confidence per gap)
     - urgency_level (critical/high/medium/low)
   ML Model: OneVsRest + LinearSVC (multi-label classification)
   Features Used: TF-IDF text features + 15 numeric scaled features
   Error Handling: Falls back to default gaps if feature dimension mismatch

4. DIFFICULTY PREDICTION ML AGENT (Parallel Execution)
   Input From: Profile Analyzer Agent
   Output To: Plan Generator LLM Agent
   Data Exchanged:
     - recommended_difficulty (Beginner/Intermediate/Advanced)
     - difficulty_confidence (0-1 probability)
   ML Model: RandomForest (3-class classification)
   Features Used: 16 numeric scaled + 8 categorical one-hot encoded features
   Error Handling: Returns default (Intermediate, 0.5) if feature mismatch

5. PLAN GENERATOR LLM AGENT
   Input From: Profile Analyzer Agent + Gap Detection ML Agent + Difficulty Prediction ML Agent
   Output To: Plan Validator LLM Agent
   Data Exchanged:
     - plan_variant_a (conservative: 1.5x timeline, 8hrs/week)
     - plan_variant_b (standard: 1.0x timeline, 10hrs/week)
     - plan_variant_c (aggressive: 0.7x timeline, 15hrs/week)
   Each Plan Contains:
     - duration_weeks, hours_per_week, total_hours
     - topics, resources, milestones, prerequisites, success_criteria
     - difficulty_progression
   LLM Model: Gemini 2.0 Flash (temperature=0.3)
   Error Handling: Catches ValueError for JSON parsing, general exceptions for API errors

6. PLAN VALIDATOR LLM AGENT
   Input From: Plan Generator LLM Agent + Profile Analyzer Agent
   Output To: Coach Rewriter LLM Agent
   Data Exchanged:
     - plan_variant_a_validated (with required fields ensured)
     - plan_variant_b_validated (with required fields ensured)
     - plan_variant_c_validated (with required fields ensured)
     - validation_issues (list of warning/concern strings)
   Validation Checks:
     1. Time feasibility vs learner hours available
     2. Goal alignment with identified gaps
     3. Prerequisite coverage and ordering
     4. Difficulty progression (gradual vs too steep)
     5. Topic relevance to domain
     6. Milestone realism and achievability
   LLM Model: Gemini 2.0 Flash (temperature=0.3)
   Error Handling: Converts all validation issues to strings to prevent TypeError

7. COACH REWRITER LLM AGENT
   Input From: Plan Validator LLM Agent + Profile Analyzer Agent
   Output To: Report Saver Agent
   Data Exchanged:
     - variant_a_friendly (rewritten text with adaptive tone)
     - variant_b_friendly (rewritten text with adaptive tone)
     - variant_c_friendly (rewritten text with adaptive tone)
   Adaptive Tone Selection:
     - age < 18: encouraging_youth
     - learning_style auditory: conversational
     - learning_style kinesthetic: practical_action_oriented
     - learning_style visual: visual_metaphor_based
     - default: analytical
   Content Components:
     1. Motivational overview
     2. Inspiring learning journey breakdown
     3. Resource context and rationale
     4. Achievable success criteria
     5. Personalized pro tips
     6. Encouraging conclusion
   LLM Model: Gemini 2.0 Flash (temperature=0.5 - higher for creativity)
   Error Handling: Catches general exceptions for API/network failures

8. REPORT SAVER AGENT
   Input From: Coach Rewriter LLM Agent + All Previous Agents (complete state)
   Output To: User (files saved to /output/{learner_id}/)
   Data Exchanged:
     - micro_plan_report.txt (professional prose, 7 sections)
     - micro_plan.json (structured data report)
     - evaluation_metrics.json (quality scores: 7 metrics)
   Report Sections:
     1. Executive Summary
     2. Learning Gap Analysis
     3. Personalized Assessment
     4. Three Learning Plan Options
     5. Recommendations
     6. Success Strategies
     7. Next Steps
   Quality Metrics Calculated:
     - profile_completeness (0-1)
     - gap_detection_accuracy (0-1)
     - difficulty_confidence (0-1)
     - plan_feasibility (0-1)
     - coaching_adaptation (0-1)
     - report_completeness (0-1)
     - overall_quality (average of above)
   LLM Model: Gemini 2.0 Flash (temperature=0.3)
   Error Handling: Catches general exceptions for file I/O and LLM failures

STATE MANAGEMENT BETWEEN AGENTS
================================

State Field Transitions:

Step 1: Profile Parser Agent
  Adds: normalized_profile, profile_complete
  Status: profile_complete = true/false

Step 2: Profile Analyzer Agent
  Adds: analyzed_profile, analysis_complete
  Status: analysis_complete = true/false

Step 3A & 3B: ML Agents (Parallel)
  Gap Detection adds: identified_gaps, gap_confidence_scores, urgency_level, gap_detection_complete
  Difficulty Prediction adds: recommended_difficulty, difficulty_confidence, difficulty_prediction_complete
  Status: Both agents complete before proceeding

Step 4: Plan Generator LLM Agent
  Adds: plan_variant_a, plan_variant_b, plan_variant_c, plan_generation_complete
  Requires: analyzed_profile, identified_gaps, recommended_difficulty
  Status: plan_generation_complete = true/false

Step 5: Plan Validator LLM Agent
  Adds: plan_variant_a_validated, plan_variant_b_validated, plan_variant_c_validated, validation_issues, validation_complete
  Requires: plan_variant_a/b/c, analyzed_profile
  Status: validation_complete = true/false

Step 6: Coach Rewriter LLM Agent
  Adds: variant_a_friendly, variant_b_friendly, variant_c_friendly, rewriting_complete
  Requires: plan_variant_a/b/c_validated, analyzed_profile
  Status: rewriting_complete = true/false

Step 7: Report Saver Agent
  Adds: saved_path, output_dir, quality_metrics, report_complete
  Requires: All previous state fields
  Status: report_complete = true/false

ERROR HANDLING AND FALLBACK COMMUNICATION
===========================================

Error Scenarios:

1. Profile Parser Agent Error
   Communication: error_occurred = true, error_messages appended
   Impact: Workflow terminates (SkipAnalysis)
   Fallback: None - workflow ends

2. Profile Analyzer Agent Error
   Communication: error_occurred = true, error_messages appended
   Impact: Both ML agents skip, workflow terminates
   Fallback: None - workflow ends

3. Gap Detection ML Agent Error
   Communication: error_occurred = true, identified_gaps = [prerequisite_foundation]
   Impact: Default gaps passed to Plan Generator
   Fallback: Graceful - uses default values, continues

4. Difficulty Prediction ML Agent Error
   Communication: error_occurred = true, difficulty = Intermediate, confidence = 0.5
   Impact: Default difficulty passed to Plan Generator
   Fallback: Graceful - uses default values, continues

5. Plan Generator LLM Agent Error
   Communication: ValueError or generic Exception caught separately
   Impact: plan_generation_complete = false
   Fallback: None - workflow terminates (SkipPlanGeneration)

6. Plan Validator LLM Agent Error
   Communication: error_occurred = true, validation_issues = []
   Impact: validation_complete = false
   Fallback: None - workflow terminates (SkipValidation)

7. Coach Rewriter LLM Agent Error
   Communication: error_occurred = true, variant_friendly = empty strings
   Impact: rewriting_complete = false
   Fallback: None - workflow terminates (SkipRewriting)

8. Report Saver Agent Error
   Communication: error_occurred = true, saved_path = empty
   Impact: report_complete = false
   Fallback: None - workflow terminates (SkipReporting)

PARALLEL EXECUTION COMMUNICATION
=================================

Gap Detection ML Agent and Difficulty Prediction ML Agent communicate in parallel:

Time Sequence:
  T0: Profile Analyzer Agent completes
  T0+Gap: Gap Detection ML Agent starts with analyzed_profile
  T0+Diff: Difficulty Prediction ML Agent starts with analyzed_profile (simultaneously)
  T_max: Both agents complete (Plan Generator waits for both)
  T_max+Plan: Plan Generator uses both outputs

Data Exchange (Parallel):
  Gap Detection → State: identified_gaps, gap_confidence_scores, urgency_level
  Difficulty Prediction → State: recommended_difficulty, difficulty_confidence

Convergence Point:
  Plan Generator LLM Agent waits for BOTH agents before executing
  LangGraph handles synchronization automatically

Performance Benefit:
  Sequential: Gap Detection time + Difficulty Prediction time = ~400-600ms
  Parallel: max(Gap Detection, Difficulty Prediction) = ~200-300ms
  Speedup: ~35-50% faster execution

AGENT DEPENDENCIES SUMMARY
===========================

Dependency Chain:
  Profile Parser (no dependencies)
    ↓
  Profile Analyzer (depends on Profile Parser)
    ↓
  Gap Detection ML (depends on Profile Analyzer) [PARALLEL]
  Difficulty Prediction ML (depends on Profile Analyzer) [PARALLEL]
    ↓
  Plan Generator LLM (depends on both ML agents)
    ↓
  Plan Validator LLM (depends on Plan Generator)
    ↓
  Coach Rewriter LLM (depends on Plan Validator)
    ↓
  Report Saver (depends on Coach Rewriter + all previous agents)

No Circular Dependencies: Linear DAG with one parallel branch

Agent Count: 8 agents total
Sequential Nodes: 6 (Parser → Analyzer → Generator → Validator → Rewriter → Saver)
Parallel Nodes: 2 (ML agents run simultaneously)

Typical Execution Time Breakdown:
  Parser: 50-100ms
  Analyzer: 100-200ms
  ML agents (parallel): 200-300ms (not additive)
  Plan Generator: 3-5 seconds (LLM)
  Plan Validator: 2-3 seconds (LLM)
  Coach Rewriter: 2-3 seconds (LLM)
  Report Saver: 2-3 seconds (LLM)

  Total: 8-12 seconds
```

DIAGRAM LEGEND
==============

Node Colors:
  Light Blue (#e1f5ff): Profile Parser Agent (Logic-based)
  Light Purple (#f3e5f5): Profile Analyzer Agent (Logic-based)
  Light Orange (#fff3e0): ML Agents (Machine Learning)
  Light Pink (#fce4ec): Plan Generator LLM Agent
  Light Green (#e8f5e9): Plan Validator LLM Agent
  Light Teal (#b2dfdb): Coach Rewriter LLM Agent
  Light Indigo (#ede7f6): Report Saver Agent
  Light Green (#c8e6c9): Start and End nodes

Error/Skip Nodes (dashed lines):
  Light Red (#ffebee): Skip analysis, validation, generation paths
  Default fallback states

Quality Result Nodes:
  High Quality (#c8e6c9): Reports >= 75% quality
  Medium Quality (#fff9c4): Reports 50-74% quality
  Low Quality (#ffcdd2): Reports < 50% quality

Arrow Types:
  Solid arrows: Normal flow with condition
  Condition text shows: Quality thresholds, validation scores, data quality checks

Parallel Execution:
  Gap Detection and Difficulty Prediction execute simultaneously
  Both arrows emerge from Profile Analyzer
  Both converge back at Plan Generator (synchronization point)
