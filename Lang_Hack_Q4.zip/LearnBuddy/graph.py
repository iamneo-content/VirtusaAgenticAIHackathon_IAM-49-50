#!/usr/bin/env python3
"""
Graph Interface for LearnBuddy Micro
Programmatic entry point for running the microplan workflow
"""

from typing import Dict, Any
from workflow.workflow import run_microplan_workflow
from state import MicroPlanState
import json


def run_microplan(learner_json: Dict[str, Any]) -> MicroPlanState:
    """
    Main entry point for microplan generation

    Args:
        learner_json: Learner profile as dictionary

    Returns:
        Complete state with all analysis and generated plans

    Example:
        >>> import json
        >>> with open("data/input/learner_profiles/learner_001.json") as f:
        ...     learner = json.load(f)
        >>> result = run_microplan(learner)
        >>> print(result["identified_gaps"])
    """
    return run_microplan_workflow(learner_json)


def run_microplan_from_file(file_path: str) -> MicroPlanState:
    """
    Run microplan from JSON file

    Args:
        file_path: Path to learner JSON profile

    Returns:
        Complete state with all analysis and generated plans
    """
    with open(file_path, 'r') as f:
        learner_json = json.load(f)

    return run_microplan(learner_json)


# Convenience functions
def get_microplan_summary(result: MicroPlanState) -> Dict[str, Any]:
    """Extract key information from result"""
    return {
        "learner_id": result.get("learner_id"),
        "identified_gaps": result.get("identified_gaps", []),
        "urgency_level": result.get("urgency_level"),
        "recommended_difficulty": result.get("recommended_difficulty"),
        "difficulty_confidence": result.get("difficulty_confidence"),
        "validation_issues": result.get("validation_issues", []),
        "quality_score": result.get("quality_metrics", {}).get("overall_quality", 0),
        "output_directory": result.get("output_dir"),
    }


def print_microplan_summary(result: MicroPlanState):
    """Print summary of microplan result"""
    summary = get_microplan_summary(result)

    print("\n" + "=" * 70)
    print("MICROPLAN GENERATION SUMMARY")
    print("=" * 70)
    print(f"Learner: {summary['learner_id']}")
    print(f"\nIdentified Gaps ({len(summary['identified_gaps'])}):")
    for gap in summary['identified_gaps']:
        print(f"  • {gap.replace('_', ' ').title()}")
    print(f"\nUrgency Level: {summary['urgency_level'].upper()}")
    print(f"Recommended Difficulty: {summary['recommended_difficulty']}")
    print(f"Confidence: {summary['difficulty_confidence']:.0%}")
    print(f"\nQuality Score: {summary['quality_score']:.0%}")

    if summary['validation_issues']:
        print(f"\nValidation Warnings ({len(summary['validation_issues'])}):")
        for issue in summary['validation_issues']:
            print(f"   {issue}")

    print(f"\nOutput Directory: {summary['output_directory']}")
    print("=" * 70 + "\n")


if __name__ == "__main__":
    print("LearnBuddy Micro Graph Interface")
    print("Use: run_microplan(learner_json) or run_microplan_from_file(path)")
