#!/usr/bin/env python3
"""
State Management for LearnBuddy Micro
Defines the complete state schema and utility functions
"""

from typing import TypedDict, List, Dict, Optional, Any
import re
from pathlib import Path

class MicroPlanState(TypedDict):
    """Complete state schema for micro-learning plan generation"""

    # Input
    learner_json: Dict[str, Any]
    learner_id: str

    # Profile Processing
    normalized_profile: Dict[str, Any]
    profile_complete: bool

    # Analysis
    analyzed_profile: Dict[str, Any]
    derived_metrics: Dict[str, Any]
    analysis_complete: bool

    # ML Predictions (Parallel)
    identified_gaps: List[str]
    gap_confidence_scores: Dict[str, float]
    urgency_level: str
    gap_detection_complete: bool

    recommended_difficulty: str  # Beginner/Intermediate/Advanced
    difficulty_confidence: float
    difficulty_prediction_complete: bool

    # Plan Generation
    plan_variant_a: Dict[str, Any]  # Conservative plan
    plan_variant_b: Dict[str, Any]  # Standard plan
    plan_variant_c: Dict[str, Any]  # Aggressive plan
    plan_generation_complete: bool

    # Validation
    plan_variant_a_validated: Dict[str, Any]
    plan_variant_b_validated: Dict[str, Any]
    plan_variant_c_validated: Dict[str, Any]
    validation_issues: List[str]
    validation_complete: bool

    # Coach Rewriting (Adaptive tone based on learner style)
    variant_a_friendly: str
    variant_b_friendly: str
    variant_c_friendly: str
    rewriting_complete: bool

    # Report Generation
    final_report: str
    report_json: Dict[str, Any]
    quality_metrics: Dict[str, float]
    saved_path: str
    output_dir: str
    report_complete: bool

    # Error Tracking
    error_occurred: bool
    error_messages: List[str]


def slugify(text: str, max_length: int = 50) -> str:
    """
    Convert text to URL-safe slug format
    Example: "Severe Chest Pain" → "severe_chest_pain"
    """
    text = text.lower().strip()
    text = re.sub(r'[^\w\s-]', '', text)
    text = re.sub(r'[-\s]+', '_', text)
    text = re.sub(r'^_+|_+$', '', text)
    return text[:max_length]


def get_initial_state(learner_json: Dict[str, Any]) -> MicroPlanState:
    """
    Initialize complete state with defaults
    """
    learner_id = learner_json.get("learner_id", "UNKNOWN")

    return {
        # Input
        "learner_json": learner_json,
        "learner_id": learner_id,

        # Profile Processing
        "normalized_profile": {},
        "profile_complete": False,

        # Analysis
        "analyzed_profile": {},
        "derived_metrics": {},
        "analysis_complete": False,

        # ML Predictions
        "identified_gaps": [],
        "gap_confidence_scores": {},
        "urgency_level": "medium",
        "gap_detection_complete": False,

        "recommended_difficulty": "Intermediate",
        "difficulty_confidence": 0.0,
        "difficulty_prediction_complete": False,

        # Plan Generation
        "plan_variant_a": {},
        "plan_variant_b": {},
        "plan_variant_c": {},
        "plan_generation_complete": False,

        # Validation
        "plan_variant_a_validated": {},
        "plan_variant_b_validated": {},
        "plan_variant_c_validated": {},
        "validation_issues": [],
        "validation_complete": False,

        # Coach Rewriting
        "variant_a_friendly": "",
        "variant_b_friendly": "",
        "variant_c_friendly": "",
        "rewriting_complete": False,

        # Report Generation
        "final_report": "",
        "report_json": {},
        "quality_metrics": {},
        "saved_path": "",
        "output_dir": "",
        "report_complete": False,

        # Error Tracking
        "error_occurred": False,
        "error_messages": [],
    }


def create_output_directory(learner_id: str) -> str:
    """Create output directory for learner"""
    output_base = Path("/Users/balamurale/Downloads/LangHackthon/LearnBuddy/output")
    output_base.mkdir(parents=True, exist_ok=True)

    learner_dir = output_base / learner_id
    learner_dir.mkdir(parents=True, exist_ok=True)

    return str(learner_dir)


def save_file(file_path: str, content: str) -> bool:
    """Save content to file"""
    try:
        Path(file_path).parent.mkdir(parents=True, exist_ok=True)
        with open(file_path, 'w') as f:
            f.write(content)
        return True
    except Exception as e:
        print(f"Error saving file {file_path}: {e}")
        return False


def format_microplan_report(state: MicroPlanState) -> str:
    """
    Format complete micro-learning plan report
    """
    learner = state["learner_json"]
    profile_info = learner.get("personal_info", {})
    goals = learner.get("learning_goals", {})

    report = f"""

                     LEARNBUDDY MICRO - LEARNING PLAN                      
                      Personalized Plan Report                             


LEARNER INFORMATION

Name: {profile_info.get('name', 'Unknown')}
Learner ID: {state['learner_id']}
Age: {profile_info.get('age', 'N/A')}
Education: {learner.get('educational_background', {}).get('highest_qualification', 'N/A')}
Learning Style: {learner.get('learning_profile', {}).get('learning_style', 'N/A')}
Primary Domain: {learner.get('current_status', {}).get('primary_domain', 'N/A')}

GOAL

Primary Goal: {goals.get('primary_goal', 'N/A')}
Timeline: {goals.get('target_timeline_months', 'N/A')} months
Desired Outcome: {goals.get('desired_outcome', 'N/A')}

CURRENT PROFICIENCY

Current Proficiency: {learner.get('current_status', {}).get('current_proficiency', {}).get('self_assessed_score', 'N/A')}/100
Topic: {learner.get('current_status', {}).get('current_proficiency', {}).get('topic', 'N/A')}

ANALYSIS RESULTS


Identified Learning Gaps:
{format_list(state['identified_gaps'])}

Gap Urgency Level: {state['urgency_level'].upper()}

Recommended Difficulty Level: {state['recommended_difficulty']}
Confidence: {state['difficulty_confidence']:.1%}

Constraints:
• Hours per week: {learner.get('constraints', {}).get('hours_available_per_week', 'N/A')}
• Budget: ${learner.get('constraints', {}).get('budget_limit_usd', 0)}
• Certification needed: {learner.get('constraints', {}).get('certification_needed', False)}

PERSONALIZED MICRO-LEARNING PLANS


PLAN VARIANT A - CONSERVATIVE (Slower Pace, Foundation-Heavy)

{format_plan(state['plan_variant_a_validated'])}

Coach Notes:
{state.get('variant_a_friendly', 'N/A')}


PLAN VARIANT B - STANDARD (Balanced Approach)

{format_plan(state['plan_variant_b_validated'])}

Coach Notes:
{state.get('variant_b_friendly', 'N/A')}


PLAN VARIANT C - AGGRESSIVE (Fast-Track Intensive)

{format_plan(state['plan_variant_c_validated'])}

Coach Notes:
{state.get('variant_c_friendly', 'N/A')}

QUALITY METRICS

{format_metrics(state['quality_metrics'])}

VALIDATION RESULTS

Status: {' PASSED' if not state['validation_issues'] else ' WARNINGS'}
{format_list(state['validation_issues']) if state['validation_issues'] else 'No issues found'}

RECOMMENDATIONS FOR SUCCESS

1. Start with the plan variant that best matches your current schedule
2. Track your progress weekly using the provided milestones
3. Adjust pacing if you fall behind or move ahead of schedule
4. Engage with practice projects to solidify learning
5. Review prerequisites before moving to advanced topics
6. Seek help from community forums or mentors when stuck
7. Take regular breaks to avoid burnout

DISCLAIMER

This micro-learning plan is personalized AI-generated guidance. It should be
adapted based on your actual progress and learning pace. Educational outcomes
vary by individual. Consult with educational professionals for formal guidance.


Generated: {get_timestamp()}
System: LearnBuddy Micro v1.0

"""

    return report


def format_list(items: List[str]) -> str:
    """Format list as bullet points"""
    if not items:
        return "  • None"
    return "\n".join([f"  • {item}" for item in items])


def format_plan(plan: Dict[str, Any]) -> str:
    """Format learning plan"""
    if not plan:
        return "Plan not yet generated"

    result = f"""
Duration: {plan.get('duration_weeks', 'N/A')} weeks
Estimated Hours: {plan.get('total_hours', 'N/A')} hours

Topics to Cover:
{format_list(plan.get('topics', []))}

Learning Resources:
{format_list(plan.get('resources', []))}

Milestones:
{format_list(plan.get('milestones', []))}

Prerequisites:
{format_list(plan.get('prerequisites', []))}

Difficulty Progression:
{plan.get('difficulty_progression', 'Gradual increase from basics to advanced')}

Success Criteria:
{format_list(plan.get('success_criteria', []))}
"""
    return result


def format_metrics(metrics: Dict[str, float]) -> str:
    """Format quality metrics"""
    result = ""
    for key, value in metrics.items():
        if isinstance(value, bool):
            result += f"  {key}: {' Yes' if value else ' No'}\n"
        elif isinstance(value, float):
            if 0 <= value <= 1:
                result += f"  {key}: {value:.1%}\n"
            else:
                result += f"  {key}: {value:.2f}\n"
        else:
            result += f"  {key}: {value}\n"
    return result


def get_timestamp() -> str:
    """Get current timestamp"""
    from datetime import datetime
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S UTC")


def extract_learner_metrics(state: MicroPlanState) -> Dict[str, Any]:
    """Extract key metrics for quality assessment"""
    learner = state["learner_json"]

    return {
        "learner_id": state["learner_id"],
        "age": learner.get("personal_info", {}).get("age", None),
        "education_level": learner.get("educational_background", {}).get("highest_qualification", None),
        "learning_style": learner.get("learning_profile", {}).get("learning_style", None),
        "domain": learner.get("current_status", {}).get("primary_domain", None),
        "proficiency_score": learner.get("current_status", {}).get("current_proficiency", {}).get("self_assessed_score", 0),
        "hours_per_week": learner.get("constraints", {}).get("hours_available_per_week", 0),
        "goal_timeline": learner.get("learning_goals", {}).get("target_timeline_months", 0),
    }


def calculate_quality_score(state: MicroPlanState) -> Dict[str, float]:
    """Calculate overall quality metrics for the plan"""

    metrics = {
        "profile_completeness": 0.95 if state["profile_complete"] else 0.0,
        "gap_detection_accuracy": min(1.0, len(state["identified_gaps"]) / 12.0) if state["gap_detection_complete"] else 0.0,
        "difficulty_confidence": state["difficulty_confidence"],
        "plan_feasibility": 0.85 if state["validation_complete"] and not state["validation_issues"] else 0.65,
        "coaching_adaptation": 0.90 if state["rewriting_complete"] else 0.0,
        "report_completeness": 1.0 if state["report_complete"] else 0.0,
    }

    # Calculate average
    avg_score = sum(metrics.values()) / len(metrics) if metrics else 0.0

    metrics["overall_quality"] = avg_score

    return metrics
