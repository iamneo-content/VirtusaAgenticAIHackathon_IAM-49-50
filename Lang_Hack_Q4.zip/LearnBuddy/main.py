#!/usr/bin/env python3
"""
LearnBuddy Micro - Streamlit Web Interface
Main entry point for the personalized learning plan generator
"""

import streamlit as st
import json
import os
from pathlib import Path
from dotenv import load_dotenv
from workflow.workflow import run_microplan_workflow

# Load environment
load_dotenv()

# Page configuration
st.set_page_config(
    page_title="LearnBuddy Micro",
    page_icon="",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom styling
st.markdown("""
    <style>
    .stTabs [data-baseweb="tab-list"] button [data-testid="stMarkdownContainer"] p {
        font-size: 1.2rem;
    }
    .metric-container {
        background-color: #f0f2f6;
        padding: 10px;
        border-radius: 5px;
    }
    </style>
""", unsafe_allow_html=True)


def main():
    """Main Streamlit app"""

    # Title and description
    col1, col2 = st.columns([3, 1])
    with col1:
        st.title(" LearnBuddy Micro")
        st.markdown("### AI-Powered Personalized Learning Plan Generator")
    with col2:
        st.info("Phase 2: Agents & Workflow ")

    st.markdown("---")

    # Medical disclaimer (adapted)
    with st.expander(" Important Disclaimer"):
        st.warning("""
            **Educational Use Only**: This system generates personalized learning recommendations
            based on AI analysis. This is NOT a substitute for professional educational guidance.

            - Results are for informational purposes only
            - Consult with educational professionals for formal guidance
            - Individual learning outcomes vary based on dedication and effort
            - Plans should be adapted based on actual progress
        """)

    st.markdown("---")

    # Sidebar - Sample selection
    with st.sidebar:
        st.header(" Learner Selection")

        sample_dir = Path("/Users/balamurale/Downloads/LangHackthon/LearnBuddy/data/input/learner_profiles")
        if sample_dir.exists():
            json_files = sorted([f.name for f in sample_dir.glob("learn_*.json")])

            selected_file = st.selectbox(
                "Choose a sample learner profile",
                options=json_files,
                help="Select from 15 pre-generated diverse learner profiles"
            )

            if selected_file:
                profile_path = sample_dir / selected_file
                with open(profile_path, 'r') as f:
                    sample_profile = json.load(f)

                st.success(f"Loaded: {sample_profile.get('personal_info', {}).get('name', 'Unknown')}")

                # Show profile summary
                with st.expander("View Profile Summary"):
                    col1, col2 = st.columns(2)
                    with col1:
                        st.metric("Age", sample_profile.get("personal_info", {}).get("age", "N/A"))
                        st.metric("Education", sample_profile.get("educational_background", {}).get("highest_qualification", "N/A"))
                    with col2:
                        st.metric("Learning Style", sample_profile.get("learning_profile", {}).get("learning_style", "N/A"))
                        st.metric("Current Proficiency", f"{sample_profile.get('current_status', {}).get('current_proficiency', {}).get('self_assessed_score', 0)}/100")

        else:
            st.error(" Profile directory not found")
            sample_profile = None

    st.markdown("---")

    # Main content area
    col1, col2, col3 = st.columns(3)

    with col1:
        st.info(" **Step 1**: Load learner profile")
    with col2:
        st.info(" **Step 2**: ML analysis")
    with col3:
        st.info(" **Step 3**: Get personalized plan")

    st.markdown("---")

    # Generate plan button
    if st.button(" Generate Personalized Learning Plan", use_container_width=True, type="primary"):

        if "sample_profile" not in locals() or sample_profile is None:
            st.error(" Please select a learner profile first")
            return

        # Progress indicator
        progress_bar = st.progress(0, text="Initializing workflow...")

        try:
            # Update progress
            progress_bar.progress(10, text="1⃣ Parsing profile...")
            st.status("Generating micro-learning plan...", state="running")

            # Run workflow
            with st.spinner(" AI is analyzing and generating your personalized plan..."):
                result = run_microplan_workflow(sample_profile)

            progress_bar.progress(100, text=" Complete!")

            # Show results in tabs
            st.success(" Plan generated successfully!")

            tab1, tab2, tab3, tab4, tab5 = st.tabs(
                [" Analysis", " Plans", " Recommendations", " Full Report", " Download"]
            )

            # Tab 1: Analysis Results
            with tab1:
                col1, col2, col3 = st.columns(3)

                with col1:
                    st.metric(
                        " Identified Gaps",
                        len(result.get("identified_gaps", [])),
                        help="Number of learning gaps detected"
                    )

                with col2:
                    st.metric(
                        " Urgency Level",
                        result.get("urgency_level", "N/A").upper(),
                        help="Priority level for addressing gaps"
                    )

                with col3:
                    st.metric(
                        " Recommended Level",
                        result.get("recommended_difficulty", "N/A"),
                        f"{result.get('difficulty_confidence', 0):.0%} confidence"
                    )

                st.subheader("Detected Learning Gaps:")
                gaps = result.get("identified_gaps", [])
                if gaps:
                    for gap in gaps:
                        confidence = result.get("gap_confidence_scores", {}).get(gap, 0)
                        st.write(f"  • **{gap.replace('_', ' ').title()}** ({confidence:.0%})")
                else:
                    st.info("No specific gaps detected")

            # Tab 2: Plan Variants
            with tab2:
                col1, col2, col3 = st.columns(3)

                with col1:
                    with st.expander(" Plan A: Conservative", expanded=False):
                        plan_a = result.get("plan_variant_a_validated", {})
                        st.write(f"**Duration:** {plan_a.get('duration_weeks', 0)} weeks")
                        st.write(f"**Weekly Commitment:** {plan_a.get('hours_per_week', 0)} hours")
                        st.write(f"**Intensity:** {plan_a.get('intensity', 'N/A').upper()}")
                        st.write(f"**Topics:**")
                        for topic in plan_a.get('topics', []):
                            st.write(f"  - {topic}")

                with col2:
                    with st.expander(" Plan B: Standard", expanded=True):
                        plan_b = result.get("plan_variant_b_validated", {})
                        st.write(f"**Duration:** {plan_b.get('duration_weeks', 0)} weeks")
                        st.write(f"**Weekly Commitment:** {plan_b.get('hours_per_week', 0)} hours")
                        st.write(f"**Intensity:** {plan_b.get('intensity', 'N/A').upper()}")
                        st.write(f"**Topics:**")
                        for topic in plan_b.get('topics', []):
                            st.write(f"  - {topic}")

                with col3:
                    with st.expander(" Plan C: Aggressive", expanded=False):
                        plan_c = result.get("plan_variant_c_validated", {})
                        st.write(f"**Duration:** {plan_c.get('duration_weeks', 0)} weeks")
                        st.write(f"**Weekly Commitment:** {plan_c.get('hours_per_week', 0)} hours")
                        st.write(f"**Intensity:** {plan_c.get('intensity', 'N/A').upper()}")
                        st.write(f"**Topics:**")
                        for topic in plan_c.get('topics', []):
                            st.write(f"  - {topic}")

            # Tab 3: Coach Recommendations
            with tab3:
                col1, col2, col3 = st.columns(3)

                with col1:
                    st.subheader(" Conservative Plan Coach Notes")
                    st.write(result.get("variant_a_friendly", ""))

                with col2:
                    st.subheader(" Standard Plan Coach Notes")
                    st.write(result.get("variant_b_friendly", ""))

                with col3:
                    st.subheader(" Aggressive Plan Coach Notes")
                    st.write(result.get("variant_c_friendly", ""))

            # Tab 4: Full Report
            with tab4:
                if result.get("saved_path"):
                    report_path = result.get("saved_path")
                    if Path(report_path).exists():
                        with open(report_path, 'r') as f:
                            report_text = f.read()
                        st.text(report_text)
                    else:
                        st.info("Full report not available")

            # Tab 5: Download
            with tab5:
                st.subheader(" Download Your Plan")

                # Download JSON report
                if result.get("saved_path"):
                    output_dir = result.get("output_dir")
                    json_path = Path(output_dir) / "micro_plan.json"

                    if json_path.exists():
                        with open(json_path, 'r') as f:
                            json_data = json.load(f)

                        st.download_button(
                            label=" Download JSON Report",
                            data=json.dumps(json_data, indent=2),
                            file_name="microplan_report.json",
                            mime="application/json"
                        )

                    # Download text report
                    report_path = Path(output_dir) / "micro_plan_report.txt"
                    if report_path.exists():
                        with open(report_path, 'r') as f:
                            report_text = f.read()

                        st.download_button(
                            label=" Download Text Report",
                            data=report_text,
                            file_name="microplan_report.txt",
                            mime="text/plain"
                        )

                st.success(f" Files saved to: {result.get('output_dir', 'N/A')}")

            # Show quality metrics
            st.markdown("---")
            st.subheader(" Quality Assessment")
            metrics = result.get("quality_metrics", {})
            col1, col2, col3, col4 = st.columns(4)

            with col1:
                st.metric("Profile Complete", f"{metrics.get('profile_completeness', 0):.0%}")
            with col2:
                st.metric("Gap Detection", f"{metrics.get('gap_detection_accuracy', 0):.0%}")
            with col3:
                st.metric("Plan Feasible", f"{metrics.get('plan_feasibility', 0):.0%}")
            with col4:
                st.metric("Overall Quality", f"{metrics.get('overall_quality', 0):.0%}")

        except Exception as e:
            st.error(f" Error generating plan: {str(e)}")
            st.exception(e)


if __name__ == "__main__":
    main()
