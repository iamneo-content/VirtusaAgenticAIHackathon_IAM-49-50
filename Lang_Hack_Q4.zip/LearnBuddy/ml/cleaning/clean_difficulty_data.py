"""
Clean difficulty prediction training dataset
Handles missing values, outliers, and inconsistencies
NO DATA LEAKAGE: Train and eval processed separately with training statistics
"""

import pandas as pd
import numpy as np
from pathlib import Path
import warnings

warnings.filterwarnings('ignore')


class DifficultyDataCleaner:
    """Clean difficulty prediction dataset without data leakage"""

    VALID_EDUCATION = ['Primary', 'Secondary', 'Bachelor', 'Master', 'PhD']
    VALID_LEARNING_STYLES = ['visual', 'auditory', 'reading/writing', 'kinesthetic', 'mixed']
    VALID_MOTIVATION = ['intrinsic', 'extrinsic', 'mixed']
    VALID_EMPLOYMENT = ['Student', 'Employed', 'Self-employed', 'Unemployed', 'Retired']
    VALID_DIFFICULTY = ['Beginner', 'Intermediate', 'Advanced']

    def __init__(self):
        self.df = None
        self.numeric_cols = ['age', 'ability_score', 'learning_speed', 'time_available_hours',
                            'years_of_experience', 'num_completed_courses', 'gpa', 'motivation_level',
                            'prerequisite_mastery', 'previous_success_rate', 'current_knowledge_base',
                            'learning_capacity', 'focus_duration_hours', 'resource_access_level',
                            'support_network_strength', 'pressure_handling_score']
        self.categorical_cols = ['education_level', 'learning_style', 'employment_status',
                                'motivation_type', 'primary_goal', 'learning_environment',
                                'previous_experience_level', 'support_availability']
        self.training_stats = {}  # Store statistics from training data

    def load_data(self, input_path):
        """Load raw data"""
        print(f"Loading data from {input_path}...")
        self.df = pd.read_csv(input_path)
        initial_count = len(self.df)
        print(f"Initial rows: {initial_count}")
        return initial_count

    def compute_statistics(self):
        """Compute statistics from TRAINING data only"""
        print("\n[Computing statistics from training data...]")

        # Compute mean for numeric columns
        for col in self.numeric_cols:
            if col in self.df.columns:
                self.training_stats[f"{col}_mean"] = self.df[col].mean()

        # Compute mode for categorical columns
        for col in self.categorical_cols:
            if col in self.df.columns:
                mode_val = self.df[col].mode()[0] if len(self.df[col].mode()) > 0 else 'Unknown'
                self.training_stats[f"{col}_mode"] = mode_val

        print(f"Computed statistics: {len(self.training_stats)} values")

    def handle_missing_values(self, use_training_stats=False):
        """Handle missing values using provided statistics or computed statistics"""
        print("\n[1/6] Handling missing values...")

        # Convert numeric columns to numeric type
        for col in self.numeric_cols:
            if col in self.df.columns:
                self.df[col] = pd.to_numeric(self.df[col], errors='coerce')

        # Fill numeric with mean
        for col in self.numeric_cols:
            if col in self.df.columns:
                if self.df[col].isnull().sum() > 0:
                    if use_training_stats and f"{col}_mean" in self.training_stats:
                        # Use training statistics (for eval data)
                        fill_value = self.training_stats[f"{col}_mean"]
                    else:
                        # Use own statistics (for training data)
                        fill_value = self.df[col].mean()
                    self.df[col] = self.df[col].fillna(fill_value)

        # Fill categorical with mode
        for col in self.categorical_cols:
            if col in self.df.columns and self.df[col].isnull().sum() > 0:
                if use_training_stats and f"{col}_mode" in self.training_stats:
                    # Use training statistics (for eval data)
                    fill_value = self.training_stats[f"{col}_mode"]
                else:
                    # Use own statistics (for training data)
                    fill_value = self.df[col].mode()[0] if len(self.df[col].mode()) > 0 else 'Unknown'
                self.df[col] = self.df[col].fillna(fill_value)

        print(f"Fixed missing values. Remaining nulls: {self.df.isnull().sum().sum()}")

    def fix_categorical_values(self):
        """Fix invalid categorical values"""
        print("\n[2/6] Fixing categorical values...")

        fixed_count = 0

        # Fix education
        if 'education_level' in self.df.columns:
            mask = ~self.df['education_level'].isin(self.VALID_EDUCATION)
            fixed_count += mask.sum()
            self.df.loc[mask, 'education_level'] = 'Bachelor'

        # Fix learning style
        if 'learning_style' in self.df.columns:
            mask = ~self.df['learning_style'].isin(self.VALID_LEARNING_STYLES)
            fixed_count += mask.sum()
            self.df.loc[mask, 'learning_style'] = 'mixed'

        # Fix motivation
        if 'motivation_type' in self.df.columns:
            mask = ~self.df['motivation_type'].isin(self.VALID_MOTIVATION)
            fixed_count += mask.sum()
            self.df.loc[mask, 'motivation_type'] = 'mixed'

        # Fix employment
        if 'employment_status' in self.df.columns:
            mask = ~self.df['employment_status'].isin(self.VALID_EMPLOYMENT)
            fixed_count += mask.sum()
            self.df.loc[mask, 'employment_status'] = 'Employed'

        # Fix difficulty target
        if 'recommended_difficulty' in self.df.columns:
            mask = ~self.df['recommended_difficulty'].isin(self.VALID_DIFFICULTY)
            fixed_count += mask.sum()
            self.df.loc[mask, 'recommended_difficulty'] = 'Intermediate'

        print(f"Fixed {fixed_count} categorical value issues")

    def clip_outliers(self):
        """Clip numeric outliers"""
        print("\n[3/6] Clipping outliers...")

        ranges = {
            'age': (10, 100),
            'ability_score': (0, 100),
            'learning_speed': (0, 10),
            'time_available_hours': (0, 168),
            'years_of_experience': (0, 80),
            'num_completed_courses': (0, 500),
            'gpa': (0, 4),
            'motivation_level': (0, 100),
            'prerequisite_mastery': (0, 100),
            'previous_success_rate': (0, 1),
        }

        clipped_count = 0
        for col, (min_val, max_val) in ranges.items():
            if col in self.df.columns:
                # Convert to numeric, coercing errors to NaN
                self.df[col] = pd.to_numeric(self.df[col], errors='coerce')
                # Fill any conversion errors with mean
                if self.df[col].isnull().sum() > 0:
                    self.df[col] = self.df[col].fillna(self.df[col].mean())
                self.df[col] = self.df[col].clip(min_val, max_val)
                clipped_count += 1

        print(f"Clipped {clipped_count} numeric ranges")

    def validate_class_distribution(self):
        """Validate and report class distribution"""
        print("\n[4/6] Validating class distribution...")

        if 'recommended_difficulty' in self.df.columns:
            dist = self.df['recommended_difficulty'].value_counts()
            total = len(self.df)
            print(f"Class distribution:")
            for cls, count in dist.items():
                print(f"  {cls}: {count} ({count/total*100:.1f}%)")

    def remove_duplicates(self):
        """Remove duplicate records"""
        print("\n[5/6] Removing duplicates...")

        initial = len(self.df)
        self.df = self.df.drop_duplicates().reset_index(drop=True)
        print(f"Removed {initial - len(self.df)} duplicate rows")

    def clean_dataset(self, input_path, output_path, use_training_stats=False):
        """Clean a single dataset (train or eval)"""
        initial = self.load_data(input_path)

        self.handle_missing_values(use_training_stats=use_training_stats)
        self.fix_categorical_values()
        self.clip_outliers()
        self.validate_class_distribution()
        self.remove_duplicates()

        # Save
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        self.df.to_csv(output_path, index=False)

        retention = len(self.df) / initial * 100
        print(f"\n Dataset cleaning complete!")
        print(f"   Initial: {initial} rows")
        print(f"   Final: {len(self.df)} rows")
        print(f"   Data retention: {retention:.1f}%")
        print(f"   Saved: {output_path}")

        return len(self.df)

    def clean(self, train_input_path, eval_input_path, train_output, eval_output):
        """Clean training and evaluation datasets separately (NO DATA LEAKAGE)

        Process flow:
        1. Load and clean training data
        2. Compute statistics from training data
        3. Load and clean evaluation data using training statistics
        """
        print("\n" + "="*70)
        print("PROCESSING TRAINING DATA")
        print("="*70)

        # Clean training data
        self.df = None
        self.training_stats = {}
        self.clean_dataset(train_input_path, train_output, use_training_stats=False)
        self.compute_statistics()  # Compute stats after cleaning training

        print("\n" + "="*70)
        print("PROCESSING EVALUATION DATA (using training statistics)")
        print("="*70)

        # Clean evaluation data using training statistics
        self.df = None
        self.clean_dataset(eval_input_path, eval_output, use_training_stats=True)


if __name__ == "__main__":
    cleaner = DifficultyDataCleaner()
    cleaner.clean(
        train_input_path="data/raw/difficulty_training_raw.csv",
        eval_input_path="data/raw/difficulty_eval_raw.csv",
        train_output="data/processed/difficulty_train_clean.csv",
        eval_output="data/processed/difficulty_eval_clean.csv"
    )
