"""
Train Difficulty Prediction Model (RandomForest)
Multi-class classification for 3 difficulty levels
"""

import pandas as pd
import numpy as np
import pickle
from pathlib import Path
from sklearn.preprocessing import StandardScaler, LabelEncoder, OneHotEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score
from sklearn.metrics import accuracy_score, classification_report
import warnings

warnings.filterwarnings('ignore')


class DifficultyModelTrainer:
    """Train difficulty prediction model"""

    def __init__(self):
        self.numeric_scaler = StandardScaler()
        self.label_encoder = LabelEncoder()
        self.categorical_encoders = {}
        self.model = RandomForestClassifier(n_estimators=100, max_depth=20, random_state=42, n_jobs=-1)

    def load_data(self, train_path, eval_path):
        """Load training and evaluation data"""
        print("Loading training data...")
        self.df_train = pd.read_csv(train_path)
        self.df_eval = pd.read_csv(eval_path)
        print(f"Training samples: {len(self.df_train)}")
        print(f"Eval samples: {len(self.df_eval)}")

    def prepare_features(self, df, fit=False):
        """Prepare numeric and categorical features"""
        # Numeric features - using available columns
        numeric_cols = ['age', 'current_ability_score', 'learning_speed_factor', 'time_to_complete_typical_course_hours',
                       'motivation_level', 'learning_consistency', 'goal_alignment', 'career_urgency',
                       'previous_attempts_on_similar', 'avg_score_on_similar_topics', 'success_rate_on_similar_topics',
                       'topic_complexity_rating', 'required_prerequisites_count', 'prerequisites_mastery_level',
                       'estimated_hours_to_master', 'available_time_weeks']

        # Filter to columns that exist
        numeric_cols = [col for col in numeric_cols if col in df.columns]

        # Convert to numeric and fill
        numeric_df = df[numeric_cols].copy()
        for col in numeric_cols:
            numeric_df[col] = pd.to_numeric(numeric_df[col], errors='coerce')

        # Fill NaN values
        for col in numeric_cols:
            col_mean = numeric_df[col].mean()
            if pd.isna(col_mean):
                col_mean = 0
            numeric_df[col] = numeric_df[col].fillna(col_mean)

        numeric_data = numeric_df.values

        if fit:
            numeric_features = self.numeric_scaler.fit_transform(numeric_data)
        else:
            numeric_features = self.numeric_scaler.transform(numeric_data)

        # Categorical features - use available categorical columns
        categorical_cols = ['education_level', 'learning_style', 'employment_status']

        categorical_features_list = []
        for col in categorical_cols:
            if col in df.columns:
                col_data = df[col].fillna('unknown').astype(str).values.reshape(-1, 1)

                if fit:
                    encoder = OneHotEncoder(sparse_output=False, handle_unknown='ignore')
                    encoded = encoder.fit_transform(col_data)
                    self.categorical_encoders[col] = encoder
                else:
                    encoded = self.categorical_encoders[col].transform(col_data)

                categorical_features_list.append(encoded)

        if categorical_features_list:
            categorical_features = np.hstack(categorical_features_list)
            # Combine
            X = np.hstack([numeric_features, categorical_features])
        else:
            X = numeric_features

        return X

    def prepare_targets(self, df, fit=False):
        """Prepare target variable"""
        # Use the actual target column name
        target_col = 'recommended_difficulty_level' if 'recommended_difficulty_level' in df.columns else 'recommended_difficulty'
        y_raw = df[target_col].values

        if fit:
            y = self.label_encoder.fit_transform(y_raw)
        else:
            y = self.label_encoder.transform(y_raw)

        return y

    def train(self):
        """Train the model"""
        print("\nPreparing training features...")
        X_train = self.prepare_features(self.df_train, fit=True)
        y_train = self.prepare_targets(self.df_train, fit=True)

        print(f"Features shape: {X_train.shape}")
        print(f"Classes: {self.label_encoder.classes_}")

        print("\nTraining model...")
        self.model.fit(X_train, y_train)

        # Training evaluation
        print("\nEvaluating on training set...")
        y_pred = self.model.predict(X_train)
        train_acc = accuracy_score(y_train, y_pred)
        print(f"Training Accuracy: {train_acc:.4f}")

        # Cross-validation
        print("\nCross-validation...")
        cv_scores = cross_val_score(self.model, X_train, y_train, cv=5)
        print(f"CV Scores: {cv_scores}")
        print(f"CV Mean: {cv_scores.mean():.4f} (+/- {cv_scores.std():.4f})")

        # Eval set evaluation
        print("\nEvaluating on eval set...")
        X_eval = self.prepare_features(self.df_eval, fit=False)
        y_eval = self.prepare_targets(self.df_eval, fit=False)
        y_eval_pred = self.model.predict(X_eval)
        eval_acc = accuracy_score(y_eval, y_eval_pred)
        print(f"Eval Accuracy: {eval_acc:.4f}")
        print("\nClassification Report:")
        print(classification_report(y_eval, y_eval_pred, target_names=self.label_encoder.classes_))

    def save(self, model_dir):
        """Save model artifacts"""
        Path(model_dir).mkdir(parents=True, exist_ok=True)

        print(f"\nSaving artifacts to {model_dir}...")
        pickle.dump(self.model, open(f"{model_dir}/difficulty_model.pkl", "wb"))
        pickle.dump(self.numeric_scaler, open(f"{model_dir}/difficulty_scaler.pkl", "wb"))
        pickle.dump(self.label_encoder, open(f"{model_dir}/difficulty_label_encoder.pkl", "wb"))
        pickle.dump(self.categorical_encoders, open(f"{model_dir}/difficulty_categorical_encoders.pkl", "wb"))

        print(" Artifacts saved successfully")


if __name__ == "__main__":
    trainer = DifficultyModelTrainer()

    # Paths
    train_path = "data/processed/difficulty_train_clean.csv"
    eval_path = "data/processed/difficulty_eval_clean.csv"
    model_dir = "ml/model"

    # Train
    trainer.load_data(train_path, eval_path)
    trainer.train()
    trainer.save(model_dir)
