"""
Train Gap Detection Model (OneVsRest + LinearSVC)
Multi-label classification for 12 learning gap categories
"""

import pandas as pd
import numpy as np
import json
import pickle
from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import StandardScaler, MultiLabelBinarizer
from sklearn.multiclass import OneVsRestClassifier
from sklearn.svm import LinearSVC
from sklearn.metrics import accuracy_score, hamming_loss
import ast
import warnings

warnings.filterwarnings('ignore')


class GapModelTrainer:
    """Train gap detection model"""

    def __init__(self):
        self.vectorizer = TfidfVectorizer(max_features=5000, ngram_range=(1, 2))
        self.scaler = StandardScaler()
        self.mlb = MultiLabelBinarizer()
        self.model = OneVsRestClassifier(LinearSVC(random_state=42, max_iter=2000))
        self.gap_labels = []

    def load_data(self, train_path, eval_path):
        """Load training and evaluation data"""
        print("Loading training data...")
        self.df_train = pd.read_csv(train_path)
        self.df_eval = pd.read_csv(eval_path)
        print(f"Training samples: {len(self.df_train)}")
        print(f"Eval samples: {len(self.df_eval)}")

    def prepare_features(self, df, fit=False):
        """Prepare text and numeric features"""
        # Text features: TF-IDF from available text columns
        text_data = (df['primary_domain'].fillna('') + ' ' +
                    df['learning_style'].fillna('') + ' ' +
                    df['data_source'].fillna('')).astype(str)

        if fit:
            text_features = self.vectorizer.fit_transform(text_data)
        else:
            text_features = self.vectorizer.transform(text_data)

        # Numeric features - using available numeric columns
        numeric_cols = ['age', 'current_proficiency_score', 'hours_available_per_week', 'avg_completion_rate',
                       'motivation_level', 'current_gpa', 'course_dropout_rate',
                       'years_in_education', 'total_courses_completed',
                       'concept_understanding_score', 'practical_application_score', 'problem_solving_ability',
                       'goal_clarity_score', 'assessment_confidence', 'target_timeline_months']

        # Filter to only columns that exist
        numeric_cols = [col for col in numeric_cols if col in df.columns]

        # Convert all numeric columns to numeric type, coercing errors to NaN
        numeric_df = df[numeric_cols].copy()
        for col in numeric_cols:
            numeric_df[col] = pd.to_numeric(numeric_df[col], errors='coerce')

        # Fill NaN values with column means
        for col in numeric_cols:
            col_mean = numeric_df[col].mean()
            if pd.isna(col_mean):
                col_mean = 0  # Default to 0 if all values are NaN
            numeric_df[col] = numeric_df[col].fillna(col_mean)

        numeric_data = numeric_df.values

        if fit:
            numeric_features = self.scaler.fit_transform(numeric_data)
        else:
            numeric_features = self.scaler.transform(numeric_data)

        # Combine
        X = np.hstack([text_features.toarray(), numeric_features])
        return X

    def prepare_targets(self, df, fit=False):
        """Prepare multi-label targets"""
        def parse_gaps(gap_str):
            try:
                if isinstance(gap_str, str):
                    try:
                        gaps = json.loads(gap_str)
                    except:
                        gaps = ast.literal_eval(gap_str)
                else:
                    gaps = gap_str
                return gaps if isinstance(gaps, list) else []
            except:
                return []

        gaps_list = df['identified_gaps'].apply(parse_gaps).tolist()

        if fit:
            y = self.mlb.fit_transform(gaps_list)
            self.gap_labels = self.mlb.classes_.tolist()
        else:
            y = self.mlb.transform(gaps_list)

        return y

    def train(self):
        """Train the model"""
        print("\nPreparing training features...")
        X_train = self.prepare_features(self.df_train, fit=True)
        y_train = self.prepare_targets(self.df_train, fit=True)

        print(f"Features shape: {X_train.shape}")
        print(f"Targets shape: {y_train.shape}")
        print(f"Gap labels: {self.gap_labels}")

        print("\nTraining model...")
        self.model.fit(X_train, y_train)

        # Evaluate
        print("\nEvaluating on training set...")
        y_pred = self.model.predict(X_train)
        acc = accuracy_score(y_train, y_pred)
        hl = hamming_loss(y_train, y_pred)
        print(f"Accuracy: {acc:.3f}")
        print(f"Hamming Loss: {hl:.3f}")

        print("\nEvaluating on eval set...")
        X_eval = self.prepare_features(self.df_eval, fit=False)
        y_eval = self.prepare_targets(self.df_eval, fit=False)
        y_eval_pred = self.model.predict(X_eval)
        eval_acc = accuracy_score(y_eval, y_eval_pred)
        eval_hl = hamming_loss(y_eval, y_eval_pred)
        print(f"Eval Accuracy: {eval_acc:.3f}")
        print(f"Eval Hamming Loss: {eval_hl:.3f}")

    def save(self, model_dir):
        """Save model artifacts"""
        Path(model_dir).mkdir(parents=True, exist_ok=True)

        print(f"\nSaving artifacts to {model_dir}...")
        pickle.dump(self.model, open(f"{model_dir}/gap_model.pkl", "wb"))
        pickle.dump(self.vectorizer, open(f"{model_dir}/gap_vectorizer.pkl", "wb"))
        pickle.dump(self.mlb, open(f"{model_dir}/gap_mlb.pkl", "wb"))
        pickle.dump(self.scaler, open(f"{model_dir}/gap_scaler.pkl", "wb"))

        with open(f"{model_dir}/gap_labels.json", "w") as f:
            json.dump(self.gap_labels, f)

        print(" Artifacts saved successfully")


if __name__ == "__main__":
    trainer = GapModelTrainer()

    # Paths
    train_path = "data/processed/gap_train_clean.csv"
    eval_path = "data/processed/gap_eval_clean.csv"
    model_dir = "ml/model"

    # Train
    trainer.load_data(train_path, eval_path)
    trainer.train()
    trainer.save(model_dir)
