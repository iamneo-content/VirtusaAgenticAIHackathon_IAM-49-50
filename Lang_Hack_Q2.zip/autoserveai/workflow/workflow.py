from __future__ import annotations

from config import AppSettings
from graphs import BatchWorkflowGraph, SingleTicketGraph, SingleTicketResult
from state import Metrics, WorkflowState


def run_workflow_stateful(settings: AppSettings, run_id: str) -> WorkflowState:
    """Execute the batch graph and return full state (tickets, preds, metrics)."""
    graph = BatchWorkflowGraph(settings)
    return graph.run_stateful(run_id)


def run_workflow(settings: AppSettings, run_id: str) -> Metrics:
    """Execute the batch graph and return metrics only."""
    state = run_workflow_stateful(settings, run_id)
    return state.metrics or Metrics(
        sentiment_acc=0.0,
        sentiment_f1_macro=0.0,
        intent_f1_macro=0.0,
        intent_f1_per_class={},
        rouge_l=0.0,
        overall_score=0.0,
    )


__all__ = [
    "BatchWorkflowGraph",
    "SingleTicketGraph",
    "SingleTicketResult",
    "run_workflow",
    "run_workflow_stateful",
]
