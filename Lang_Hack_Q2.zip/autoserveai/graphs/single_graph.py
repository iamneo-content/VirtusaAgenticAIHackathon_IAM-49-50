from __future__ import annotations

import os
from concurrent.futures import ThreadPoolExecutor
from typing import Dict, List, Optional

from loguru import logger
from pydantic import BaseModel, ConfigDict, Field

from config import AppSettings
from nodes import (
    clean_rows,
    draft_deep,
    draft_fast,
    judge_drafts,
    load_rows,
    map_embeddings,
    reclassify_low_conf,
    reduce_clusters,
    redact_outputs,
    route_low_conf,
    run_intent,
    run_sentiment,
    summarize_by_cluster,
)
from state import IntentPred, ReclassPred, SentimentPred, TicketRow


class SingleTicketResult(BaseModel):
    model_config = ConfigDict(extra="ignore")

    ticket: TicketRow
    cleaned_ticket: TicketRow
    sentiment: SentimentPred
    intent: IntentPred
    reclass: Optional[ReclassPred] = None
    cluster_id: int
    cluster_context: List[TicketRow] = Field(default_factory=list)
    fast_draft: str
    deep_draft: str
    judged_draft: str
    safe_draft: str
    summary: str


class SingleTicketGraph:
    """Interactive graph: one ticket end-to-end with drafting, judging, and summarizing."""

    def __init__(self, settings: AppSettings) -> None:
        self.settings = settings
        self._inject_api_keys()

    def run(self, ticket_id: str) -> SingleTicketResult:
        logger.info("LOAD_SINGLE")
        rows = load_rows(self.settings.input_csv)
        ticket_map = {row.ticket_id: row for row in rows}
        if ticket_id not in ticket_map:
            raise ValueError(f"Ticket id {ticket_id} not found in {self.settings.input_csv}")

        logger.info("CLEAN_SINGLE")
        cleaned_rows = clean_rows(rows)
        cleaned_map = {row.ticket_id: row for row in cleaned_rows}
        target_row = cleaned_map[ticket_id]

        logger.info("SENTIMENT_SVM || INTENT_LR")
        with ThreadPoolExecutor(max_workers=2) as executor:
            sentiment_future = executor.submit(run_sentiment, [target_row])
            intent_future = executor.submit(run_intent, [target_row])
            sentiment_preds = sentiment_future.result()
            intent_preds = intent_future.result()

        sentiment_pred = sentiment_preds[0]
        intent_pred = intent_preds[0]

        logger.info("LOWCONF_ROUTER")
        decision = route_low_conf(sentiment_preds, intent_preds, self.settings.confidence_threshold)

        logger.info("RECLASS_LLM condition")
        reclass_pred: Optional[ReclassPred] = None
        if decision.low_conf_ticket_ids:
            reclass_preds = reclassify_low_conf([target_row], decision)
            if reclass_preds:
                reclass_pred = reclass_preds[0]

        logger.info("FETCH_CONTEXT (embeddings + cluster)")
        embeddings = map_embeddings(cleaned_rows)
        clusters = reduce_clusters(embeddings, self.settings.cluster_k)
        cluster_id = clusters.get(ticket_id, -1)
        context_rows = [
            row for row in cleaned_rows if clusters.get(row.ticket_id) == cluster_id and row.ticket_id != ticket_id
        ][:3]

        label = reclass_pred.label if reclass_pred else intent_pred.label
        label_conf = reclass_pred.confidence if reclass_pred else intent_pred.confidence
        intent_final = IntentPred(ticket_id=intent_pred.ticket_id, label=label, confidence=label_conf)
        intent_map: Dict[str, str] = {ticket_id: label}

        logger.info("DRAFT_LLM (fast + deep)")
        fast_drafts = draft_fast([target_row], intent_map)
        deep_drafts = draft_deep([target_row], intent_map)

        logger.info("JUDGE")
        judged = judge_drafts(fast_drafts, deep_drafts, {"prefer_depth": True})
        judged_text = judged.get(ticket_id, "")

        logger.info("SUMMARY_LLM")
        summary_rows = [target_row] + context_rows
        summary_clusters = {row.ticket_id: clusters.get(row.ticket_id, cluster_id) for row in summary_rows}
        summaries = summarize_by_cluster(summary_rows, summary_clusters, judged)
        summary_text = summaries.get(cluster_id, "")

        logger.info("SAFETY_GUARD")
        safe_drafts = redact_outputs(judged)
        safe_text = safe_drafts.get(ticket_id, judged_text)

        return SingleTicketResult(
            ticket=ticket_map[ticket_id],
            cleaned_ticket=target_row,
            sentiment=sentiment_pred,
            intent=intent_final,
            reclass=reclass_pred,
            cluster_id=cluster_id,
            cluster_context=context_rows,
            fast_draft=fast_drafts.get(ticket_id, ""),
            deep_draft=deep_drafts.get(ticket_id, ""),
            judged_draft=judged_text,
            safe_draft=safe_text,
            summary=summary_text,
        )

    def _inject_api_keys(self) -> None:
        """Ensure LLM API keys are available to agent constructors that read environment variables."""
        if self.settings.fast_api_key:
            os.environ["FAST_API_KEY"] = self.settings.fast_api_key
        if self.settings.deep_api_key:
            os.environ["DEEP_API_KEY"] = self.settings.deep_api_key
        if self.settings.reclass_api_key:
            os.environ["RECLASS_API_KEY"] = self.settings.reclass_api_key
        os.environ["LIVE_LLM"] = str(self.settings.live_llm)
        os.environ["SUMMARY_LIVE_LLM"] = str(self.settings.summary_live_llm)
        os.environ["LLM_DELAY_SECONDS"] = str(self.settings.llm_delay_seconds)


__all__ = ["SingleTicketGraph", "SingleTicketResult"]
