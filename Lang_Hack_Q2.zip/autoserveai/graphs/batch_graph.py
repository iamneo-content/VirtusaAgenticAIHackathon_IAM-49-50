from __future__ import annotations

import os
from concurrent.futures import ThreadPoolExecutor
from typing import Dict, List

from loguru import logger

from config import AppSettings
from nodes import (
    clean_rows,
    compute_metrics,
    load_rows,
    map_embeddings,
    reclassify_low_conf,
    reduce_clusters,
    route_low_conf,
    run_intent,
    run_sentiment,
    save_report,
)
from state import IntentPred, Metrics, ReclassPred, WorkflowState


class BatchWorkflowGraph:
    """Batch/evaluation graph: classification + clustering + metrics, no drafting."""

    def __init__(self, settings: AppSettings) -> None:
        # Force batch to use trained models only (no live LLM calls) for speed.
        self.settings = settings.model_copy(
            update={"live_llm": False, "summary_live_llm": False, "llm_delay_seconds": 0.0}
        )
        self._inject_api_keys()

    def run_stateful(self, run_id: str) -> WorkflowState:
        """Execute the batch graph and return the full state."""
        logger.info("LOAD")
        rows = load_rows(self.settings.input_csv)

        logger.info("CLEAN")
        cleaned_rows = clean_rows(rows)

        logger.info("SENTIMENT_SVM || INTENT_LR")
        with ThreadPoolExecutor(max_workers=2) as executor:
            sentiment_future = executor.submit(run_sentiment, cleaned_rows)
            intent_future = executor.submit(run_intent, cleaned_rows)
            sentiment_preds = sentiment_future.result()
            intent_preds = intent_future.result()

        logger.info("LOWCONF_ROUTER")
        decision = route_low_conf(sentiment_preds, intent_preds, self.settings.confidence_threshold)

        logger.info("RECLASS_LLM condition")
        reclass_preds: List[ReclassPred] = []
        if decision.low_conf_ticket_ids:
            reclass_preds = reclassify_low_conf(cleaned_rows, decision)

        logger.info("TOPIC_CLUSTER_MAP")
        embeddings = map_embeddings(cleaned_rows)

        logger.info("TOPIC_CLUSTER_REDUCE")
        clusters = reduce_clusters(embeddings, self.settings.cluster_k)

        logger.info("SCORE_METRICS")
        intent_map: Dict[str, str] = {pred.ticket_id: pred.label for pred in intent_preds}
        for reclass in reclass_preds:
            intent_map[reclass.ticket_id] = reclass.label
        intent_pred_list = [
            IntentPred(ticket_id=ticket_id, label=label, confidence=0.7) for ticket_id, label in intent_map.items()
        ]
        weights = {**self.settings.weights, "rouge_l": 0.0}
        norm = weights.get("sentiment", 0.0) + weights.get("intent", 0.0)
        if norm > 0:
            weights["sentiment"] = weights.get("sentiment", 0.0) / norm
            weights["intent"] = weights.get("intent", 0.0) / norm
        metrics = compute_metrics(
            {"sentiment": sentiment_preds, "intent": intent_pred_list, "weights": weights},
            self.settings.ground_truth_csv,
            {},
        )

        logger.info("REPORT_SAVE")
        save_report(metrics, run_id, self.settings.output_dir)

        return WorkflowState(
            rows=cleaned_rows,
            sentiment=sentiment_preds,
            intent=intent_pred_list,
            reclass=reclass_preds or None,
            clusters=clusters,
            drafts_best={},
            metrics=metrics,
        )

    def run(self, run_id: str) -> Metrics:
        """Execute the batch graph and return metrics only (CLI-friendly)."""
        state = self.run_stateful(run_id)
        return state.metrics or Metrics(
            sentiment_acc=0.0,
            sentiment_f1_macro=0.0,
            intent_f1_macro=0.0,
            intent_f1_per_class={},
            rouge_l=0.0,
            overall_score=0.0,
        )

    def _inject_api_keys(self) -> None:
        """Ensure LLM API keys are available to agent constructors that read environment variables."""
        if self.settings.fast_api_key:
            os.environ.setdefault("FAST_API_KEY", self.settings.fast_api_key)
        if self.settings.deep_api_key:
            os.environ.setdefault("DEEP_API_KEY", self.settings.deep_api_key)
        if self.settings.reclass_api_key:
            os.environ.setdefault("RECLASS_API_KEY", self.settings.reclass_api_key)
        os.environ.setdefault("LIVE_LLM", "False")
        os.environ.setdefault("SUMMARY_LIVE_LLM", "False")
        os.environ.setdefault("LLM_DELAY_SECONDS", "0")


__all__ = ["BatchWorkflowGraph"]
