from __future__ import annotations

import argparse
import sys

from config import AppSettings, setup_logging
from workflow import run_workflow


def main() -> int:
    parser = argparse.ArgumentParser(description="AutoServeAI — Agentic Customer Service Analyzer")
    parser.add_argument("--input", dest="input_csv", default="data/input/tickets.csv", help="Input tickets CSV path")
    parser.add_argument("--ground-truth", dest="ground_truth", default="eval/ground_truth.csv", help="Ground truth CSV path")
    parser.add_argument("--run-id", dest="run_id", required=True, help="Run identifier, e.g., 2025-11-A")
    args = parser.parse_args()

    settings = AppSettings(
        input_csv=args.input_csv,
        ground_truth_csv=args.ground_truth,
    )
    setup_logging(settings.log_level, "logs/app.log")
    metrics = run_workflow(settings, args.run_id)
    print(metrics.model_dump())
    return 0


if __name__ == "__main__":
    sys.exit(main())
