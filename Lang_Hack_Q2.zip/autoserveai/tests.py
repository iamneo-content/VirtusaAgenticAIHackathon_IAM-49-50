from __future__ import annotations
from pathlib import Path
from typing import Dict, List
import pandas as pd
import pytest

from agents import DraftDeepAgent, DraftFastAgent, IntentAgent, ReclassAgent, SentimentAgent
from config import AppSettings
from graphs import BatchWorkflowGraph
from ml.evaluation_metrics import macro_f1, rouge_l
from ml.training.train_intent_logreg import train_intent
from ml.training.train_sentiment_svm import train_sentiment
from nodes import (
    clean_rows,
    load_rows,
    map_embeddings,
    reduce_clusters,
    route_low_conf,
    run_intent,
    run_sentiment,
)
from state import TicketRow


def test_processed_files_exist() -> None:
    assert Path("processed/cleaned_sentiment_training.csv").exists()
    assert Path("processed/cleaned_intent_training.csv").exists()


def test_cleaned_sentiment_lowercase_and_nonempty() -> None:
    df = pd.read_csv("processed/cleaned_sentiment_training.csv")
    assert not df.empty
    assert {"customer_text", "sentiment_label"}.issubset(df.columns)
    assert df["customer_text"].notna().all()
    sample_text = df["customer_text"].iloc[0]
    assert sample_text == sample_text.lower()
    assert sample_text.strip() == sample_text


def test_cleaned_intent_lowercase_and_nonempty() -> None:
    df = pd.read_csv("processed/cleaned_intent_training.csv")
    assert not df.empty
    assert {"customer_text", "intent_label"}.issubset(df.columns)
    assert df["customer_text"].notna().all()
    sample_text = df["customer_text"].iloc[0]
    assert sample_text == sample_text.lower()
    assert sample_text.strip() == sample_text


# --- Training routines (temp outputs to avoid clobbering user files) ---


def test_train_sentiment_writes_models(tmp_path: Path) -> None:
    data = pd.DataFrame(
        {
            "customer_text": [
                "common good service",
                "common bad service",
                "common neutral service",
            ],
            "sentiment_label": ["positive", "negative", "neutral"],
        }
    )
    input_csv = tmp_path / "sentiment.csv"
    data.to_csv(input_csv, index=False)
    vec_out = tmp_path / "tfidf_sentiment.pkl"
    model_out = tmp_path / "sentiment_svm.pkl"
    train_sentiment(str(input_csv), str(vec_out), str(model_out))
    assert vec_out.exists()
    assert model_out.exists()


def test_train_intent_writes_models(tmp_path: Path) -> None:
    data = pd.DataFrame(
        {
            "customer_text": [
                "common need refund",
                "common cannot login",
                "common feature request",
                "common login issue",
            ],
            "intent_label": ["billing_issue", "account_access", "feature_request", "account_access"],
        }
    )
    input_csv = tmp_path / "intent.csv"
    data.to_csv(input_csv, index=False)
    vec_out = tmp_path / "tfidf_intent.pkl"
    model_out = tmp_path / "intent_lr.pkl"
    train_intent(str(input_csv), str(vec_out), str(model_out))
    assert vec_out.exists()
    assert model_out.exists()


def test_existing_models_present() -> None:
    model_dir = Path("ml/models")
    pkl_files = list(model_dir.glob("*.pkl"))
    assert pkl_files, "No trained model artefacts (.pkl) found in ml/models"


# --- Evaluation metrics ---


def test_macro_f1_returns_float() -> None:
    y_true = ["a", "b", "a"]
    y_pred = ["a", "a", "b"]
    score = macro_f1(y_true, y_pred)
    assert isinstance(score, float)
    assert 0.0 <= score <= 1.0


def test_rouge_l_basic() -> None:
    ref = "hello world"
    hyp = "hello brave world"
    score = rouge_l(hyp, ref)
    assert isinstance(score, float)
    assert 0.0 <= score <= 1.0


# --- Agents ---


def test_sentiment_agent_predicts_stub() -> None:
    rows = [TicketRow(ticket_id="t1", customer_text="great service", created_timestamp="2025-01-01")]
    preds = SentimentAgent().predict(rows)
    assert preds and preds[0].ticket_id == "t1"


def test_intent_agent_predicts_stub() -> None:
    rows = [TicketRow(ticket_id="t1", customer_text="refund please", created_timestamp="2025-01-01")]
    preds = IntentAgent().predict(rows)
    assert preds and preds[0].ticket_id == "t1"


def test_reclass_agent_stub() -> None:
    rows = [TicketRow(ticket_id="t1", customer_text="refund please", created_timestamp="2025-01-01")]
    preds = ReclassAgent(live_llm=False).predict(rows)
    assert preds and preds[0].ticket_id == "t1"


def test_draft_fast_requires_live_llm() -> None:
    agent = DraftFastAgent(live_llm=False)
    with pytest.raises(RuntimeError):
        agent.generate([], {})


def test_draft_deep_requires_live_llm() -> None:
    agent = DraftDeepAgent(live_llm=False)
    with pytest.raises(RuntimeError):
        agent.generate([], {})


# --- Nodes ---


def test_lowconf_router_filters() -> None:
    sent = [run_sentiment([TicketRow(ticket_id="t1", customer_text="ok", created_timestamp="2025-01-01")])][0]
    intent = [run_intent([TicketRow(ticket_id="t1", customer_text="ok", created_timestamp="2025-01-01")])][0]
    decision = route_low_conf(sent, intent, tau=0.9)
    assert "t1" in decision.low_conf_ticket_ids


def test_embeddings_and_clusters() -> None:
    rows = [
        TicketRow(ticket_id="t1", customer_text="hello", created_timestamp="2025-01-01"),
        TicketRow(ticket_id="t2", customer_text="world", created_timestamp="2025-01-01"),
    ]
    embeddings = map_embeddings(rows)
    assert set(embeddings.keys()) == {"t1", "t2"}
    clusters = reduce_clusters(embeddings, k=2)
    assert set(clusters.keys()) == {"t1", "t2"}


# --- Graph ---


def test_graph_construction_basic_shape(tmp_path: Path) -> None:
    input_csv = tmp_path / "tickets.csv"
    gt_csv = tmp_path / "gt.csv"
    pd.DataFrame(
        [
            {"ticket_id": "t1", "customer_text": "refund please", "created_timestamp": "2025-01-01 00:00:00"},
            {"ticket_id": "t2", "customer_text": "login issue", "created_timestamp": "2025-01-02 00:00:00"},
        ]
    ).to_csv(input_csv, index=False)
    pd.DataFrame(
        [
            {"ticket_id": "t1", "sentiment_label": "neutral", "intent_label": "billing_issue", "reference_response": ""},
            {"ticket_id": "t2", "sentiment_label": "neutral", "intent_label": "account_access", "reference_response": ""},
        ]
    ).to_csv(gt_csv, index=False)
    settings = AppSettings(
        input_csv=str(input_csv),
        ground_truth_csv=str(gt_csv),
        output_dir=str(tmp_path / "runs"),
        max_tickets=5,
    )
    graph = BatchWorkflowGraph(settings)
    state = graph.run_stateful(run_id="TEST")
    assert state is not None
    assert state.rows
    assert state.sentiment
    assert state.intent
    assert state.metrics is not None
