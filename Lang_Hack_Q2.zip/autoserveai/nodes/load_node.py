from __future__ import annotations

from typing import List

import pandas as pd

from state import TicketRow


def load_rows(csv_path: str) -> List[TicketRow]:
    """Load ticket rows from CSV into TicketRow models."""
    df = pd.read_csv(csv_path)
    rows: List[TicketRow] = []
    for _, rec in df.iterrows():
        language_value = None if pd.isna(rec.get("language_code")) else str(rec.get("language_code"))
        channel_value = None if pd.isna(rec.get("channel_source")) else str(rec.get("channel_source"))
        priority_value = None if pd.isna(rec.get("priority_level")) else str(rec.get("priority_level"))
        assigned_value = None if pd.isna(rec.get("assigned_team")) else str(rec.get("assigned_team"))
        rows.append(
            TicketRow(
                ticket_id=str(rec["ticket_id"]),
                customer_text=str(rec["customer_text"]),
                language_code=language_value,
                channel_source=channel_value,
                created_timestamp=str(rec["created_timestamp"]),
                priority_level=priority_value,
                assigned_team=assigned_value,
            )
        )
    return rows


__all__ = ["load_rows"]
