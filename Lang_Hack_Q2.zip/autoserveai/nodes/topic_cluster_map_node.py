from __future__ import annotations

from typing import Dict, List

import numpy as np

from state import TicketRow


def map_embeddings(rows: List[TicketRow]) -> Dict[str, List[float]]:
    """Convert ticket text into simple deterministic embeddings."""
    embeddings: Dict[str, List[float]] = {}
    for row in rows:
        chars = [ord(c) for c in row.customer_text[:6]]
        padded = chars + [0] * (6 - len(chars))
        vector = np.tanh(np.array(padded, dtype=float) / 100.0).tolist()
        embeddings[row.ticket_id] = vector
    return embeddings


__all__ = ["map_embeddings"]
