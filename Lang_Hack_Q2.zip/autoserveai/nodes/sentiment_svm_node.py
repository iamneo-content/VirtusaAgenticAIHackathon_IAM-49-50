from __future__ import annotations

from typing import List

from agents import SentimentAgent
from state import SentimentPred, TicketRow


def run_sentiment(rows: List[TicketRow]) -> List[SentimentPred]:
    """Run sentiment model."""
    agent = SentimentAgent()
    return agent.predict(rows)


__all__ = ["run_sentiment"]
