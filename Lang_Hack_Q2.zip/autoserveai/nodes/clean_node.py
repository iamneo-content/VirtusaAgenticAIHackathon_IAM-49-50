from __future__ import annotations

import re
from typing import List

from state import TicketRow


def clean_rows(rows: List[TicketRow]) -> List[TicketRow]:
    """Normalize text by trimming whitespace and collapsing spaces."""
    cleaned: List[TicketRow] = []
    for row in rows:
        text = re.sub(r"\s+", " ", row.customer_text).strip()
        cleaned.append(
            TicketRow(
                ticket_id=row.ticket_id,
                customer_text=text.lower(),
                language_code=row.language_code,
                channel_source=row.channel_source,
                created_timestamp=row.created_timestamp,
                priority_level=row.priority_level,
                assigned_team=row.assigned_team,
            )
        )
    return cleaned


__all__ = ["clean_rows"]
