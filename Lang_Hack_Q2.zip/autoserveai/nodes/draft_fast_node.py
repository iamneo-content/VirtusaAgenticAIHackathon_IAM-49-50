from __future__ import annotations

from typing import Dict, List

from agents import DraftFastAgent
from state import TicketRow


def draft_fast(rows: List[TicketRow], preds: Dict[str, str]) -> Dict[str, str]:
    """Generate concise drafts."""
    agent = DraftFastAgent()
    return agent.generate(rows, preds)


__all__ = ["draft_fast"]
