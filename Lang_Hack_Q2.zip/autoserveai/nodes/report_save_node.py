from __future__ import annotations

import json
from pathlib import Path
from typing import Dict

import pandas as pd

from state import Metrics


def save_report(metrics: Metrics, run_id: str, out_dir: str) -> Dict[str, str]:
    """Persist metrics to disk in CSV and JSON formats."""
    run_path = Path(out_dir) / run_id
    run_path.mkdir(parents=True, exist_ok=True)
    metrics_dict = metrics.model_dump()
    json_path = run_path / "report.json"
    csv_path = run_path / "metrics.csv"
    with json_path.open("w", encoding="utf-8") as f:
        json.dump(metrics_dict, f, indent=2)
    df = pd.DataFrame([metrics_dict])
    df.to_csv(csv_path, index=False)
    return {"json": str(json_path), "csv": str(csv_path)}


__all__ = ["save_report"]
