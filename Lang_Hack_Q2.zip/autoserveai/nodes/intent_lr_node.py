from __future__ import annotations

from typing import List

from agents import IntentAgent
from state import IntentPred, TicketRow


def run_intent(rows: List[TicketRow]) -> List[IntentPred]:
    """Run intent model."""
    agent = IntentAgent()
    return agent.predict(rows)


__all__ = ["run_intent"]
