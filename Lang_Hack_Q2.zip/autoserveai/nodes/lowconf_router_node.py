from __future__ import annotations

from typing import List

from state import IntentPred, RouteDecision, SentimentPred


def route_low_conf(sentiment: List[SentimentPred], intent: List[IntentPred], tau: float) -> RouteDecision:
    """Route tickets with any prediction confidence below tau."""
    low_conf_ticket_ids: List[str] = []
    sentiment_map = {pred.ticket_id: pred.confidence for pred in sentiment}
    intent_map = {pred.ticket_id: pred.confidence for pred in intent}
    for ticket_id, sent_conf in sentiment_map.items():
        intent_conf = intent_map.get(ticket_id, 0.0)
        if sent_conf < tau or intent_conf < tau:
            low_conf_ticket_ids.append(ticket_id)
    return RouteDecision(low_conf_ticket_ids=low_conf_ticket_ids)


__all__ = ["route_low_conf"]
