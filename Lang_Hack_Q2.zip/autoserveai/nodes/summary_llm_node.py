from __future__ import annotations

from typing import Dict, List

from agents import SummaryAgent
from state import TicketRow


def summarize_by_cluster(rows: List[TicketRow], clusters: Dict[str, int], drafts: Dict[str, str]) -> Dict[int, str]:
    """Summarize drafts by cluster."""
    agent = SummaryAgent()
    return agent.summarize(rows, clusters, drafts)


__all__ = ["summarize_by_cluster"]
