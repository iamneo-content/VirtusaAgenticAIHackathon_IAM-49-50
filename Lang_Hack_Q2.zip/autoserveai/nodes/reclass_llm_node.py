from __future__ import annotations

from typing import List

from agents import ReclassAgent
from state import ReclassPred, RouteDecision, TicketRow


def reclassify_low_conf(rows: List[TicketRow], decision: RouteDecision) -> List[ReclassPred]:
    """Reclassify low-confidence tickets via LLM stub."""
    if not decision.low_conf_ticket_ids:
        return []
    subset = [row for row in rows if row.ticket_id in decision.low_conf_ticket_ids]
    agent = ReclassAgent()
    return agent.predict(subset)


__all__ = ["reclassify_low_conf"]
