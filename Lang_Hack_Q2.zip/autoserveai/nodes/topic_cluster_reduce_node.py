from __future__ import annotations

from pathlib import Path
from typing import Dict, List

import joblib
import numpy as np
from sklearn.cluster import MiniBatchKMeans


def reduce_clusters(embeddings: Dict[str, List[float]], k: int) -> Dict[str, int]:
    """Assign cluster ids using MiniBatchKMeans."""
    ticket_ids = list(embeddings.keys())
    if not ticket_ids:
        return {}
    matrix = np.array([embeddings[t] for t in ticket_ids])
    cluster_count = max(1, min(k, len(ticket_ids)))
    model_path = Path("ml/models/kmeans.pkl")
    if model_path.exists():
        kmeans: MiniBatchKMeans = joblib.load(model_path)
    else:
        kmeans = MiniBatchKMeans(n_clusters=cluster_count, random_state=42, n_init=5)
        kmeans.fit(matrix)
        model_path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(kmeans, model_path)
    labels = kmeans.predict(matrix)
    return {ticket_ids[i]: int(labels[i]) for i in range(len(ticket_ids))}


__all__ = ["reduce_clusters"]
