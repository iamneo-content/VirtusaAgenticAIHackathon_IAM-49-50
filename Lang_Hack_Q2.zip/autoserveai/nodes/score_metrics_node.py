from __future__ import annotations

from typing import Dict, List

import pandas as pd

from ml.evaluation_metrics import macro_f1, per_class_f1, rouge_l
from state import IntentPred, Metrics, SentimentPred


def compute_metrics(preds: Dict, ground_truth_csv: str, drafts: Dict[str, str]) -> Metrics:
    """Compute evaluation metrics using predictions and ground truth file."""
    df = pd.read_csv(ground_truth_csv)
    sentiment_col = "sentiment_label"
    if "true_sentiment_label" in df.columns:
        sentiment_col = "true_sentiment_label"
    intent_col = "intent_label"
    if "true_intent_label" in df.columns:
        intent_col = "true_intent_label"
    gt_sentiment = df.set_index("ticket_id")[sentiment_col].to_dict()
    gt_intent = df.set_index("ticket_id")[intent_col].to_dict()
    gt_reference = df.set_index("ticket_id")["reference_response"].to_dict()

    sentiment_preds: List[SentimentPred] = preds.get("sentiment", [])
    intent_preds: List[IntentPred] = preds.get("intent", [])
    weights = preds.get("weights", {"sentiment": 0.3, "intent": 0.4, "rouge_l": 0.3})

    sent_map = {p.ticket_id: p.label for p in sentiment_preds}
    intent_map = {p.ticket_id: p.label for p in intent_preds}

    aligned_ticket_ids = [ticket_id for ticket_id in df["ticket_id"] if ticket_id in sent_map and ticket_id in intent_map]
    y_true_sent = [gt_sentiment[t] for t in aligned_ticket_ids]
    y_pred_sent = [sent_map[t] for t in aligned_ticket_ids]
    y_true_intent = [gt_intent[t] for t in aligned_ticket_ids]
    y_pred_intent = [intent_map[t] for t in aligned_ticket_ids]

    sentiment_acc = 0.0
    if aligned_ticket_ids:
        correct = sum(1 for i, t in enumerate(aligned_ticket_ids) if y_pred_sent[i] == y_true_sent[i])
        sentiment_acc = correct / len(aligned_ticket_ids)
    sentiment_f1_macro = macro_f1(y_true_sent, y_pred_sent) if aligned_ticket_ids else 0.0
    intent_f1_macro = macro_f1(y_true_intent, y_pred_intent) if aligned_ticket_ids else 0.0
    intent_f1_per = per_class_f1(y_true_intent, y_pred_intent) if aligned_ticket_ids else {}

    rouge_scores: List[float] = []
    for ticket_id in aligned_ticket_ids:
        reference = str(gt_reference.get(ticket_id, "") or "")
        draft = str(drafts.get(ticket_id, "") or "")
        rouge_scores.append(rouge_l(draft, reference))
    rouge_avg = sum(rouge_scores) / len(rouge_scores) if rouge_scores else 0.0

    overall = (
        weights.get("sentiment", 0.3) * sentiment_f1_macro
        + weights.get("intent", 0.4) * intent_f1_macro
        + weights.get("rouge_l", 0.3) * rouge_avg
    )

    return Metrics(
        sentiment_acc=float(sentiment_acc),
        sentiment_f1_macro=float(sentiment_f1_macro),
        intent_f1_macro=float(intent_f1_macro),
        intent_f1_per_class={k: float(v) for k, v in intent_f1_per.items()},
        rouge_l=float(rouge_avg),
        overall_score=float(overall),
    )


__all__ = ["compute_metrics"]
