from __future__ import annotations

from typing import Dict, List

from agents import DraftDeepAgent
from state import TicketRow


def draft_deep(rows: List[TicketRow], preds: Dict[str, str]) -> Dict[str, str]:
    """Generate deeper drafts."""
    agent = DraftDeepAgent()
    return agent.generate(rows, preds)


__all__ = ["draft_deep"]
