from __future__ import annotations

from typing import Dict

from agents import SafetyGuardAgent


def redact_outputs(drafts: Dict[str, str]) -> Dict[str, str]:
    """Apply safety redaction to drafts."""
    agent = SafetyGuardAgent()
    return agent.sanitize(drafts)


__all__ = ["redact_outputs"]
