from __future__ import annotations

from typing import Dict

from agents import JudgeAgent


def judge_drafts(fast: Dict[str, str], deep: Dict[str, str], rubric: Dict) -> Dict[str, str]:
    """Select best draft for each ticket."""
    agent = JudgeAgent()
    return agent.select(fast, deep, rubric)


__all__ = ["judge_drafts"]
