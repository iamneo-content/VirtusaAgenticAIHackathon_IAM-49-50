from __future__ import annotations

from typing import Dict, List

from rouge_score import rouge_scorer
from sklearn.metrics import f1_score


def macro_f1(y_true: List[str], y_pred: List[str]) -> float:
    """Compute macro F1 with zero_division handled."""
    return float(f1_score(y_true, y_pred, average="macro", zero_division=0.0))


def per_class_f1(y_true: List[str], y_pred: List[str]) -> Dict[str, float]:
    """Per-class F1 scores."""
    labels = sorted(set(y_true))
    scores: Dict[str, float] = {}
    for label in labels:
        true_binary = [1 if y == label else 0 for y in y_true]
        pred_binary = [1 if y == label else 0 for y in y_pred]
        scores[label] = float(f1_score(true_binary, pred_binary, zero_division=0.0))
    return scores


def rouge_l(hyp: str, ref: str) -> float:
    """ROUGE-Lsum between hypothesis and reference."""
    scorer = rouge_scorer.RougeScorer(["rougeLsum"], use_stemmer=True)
    score = scorer.score(ref, hyp)["rougeLsum"]
    return float(score.fmeasure)


__all__ = ["macro_f1", "per_class_f1", "rouge_l"]
