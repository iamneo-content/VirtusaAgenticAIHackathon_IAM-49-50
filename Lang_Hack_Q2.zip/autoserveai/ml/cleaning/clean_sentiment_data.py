from __future__ import annotations

from pathlib import Path

import pandas as pd


def clean_sentiment(raw_csv: str = "data/training_dataset/sentiment_training.csv", out_csv: str = "processed/cleaned_sentiment_training.csv") -> None:
    """Simple cleaning for sentiment training data."""
    df = pd.read_csv(raw_csv)
    df = df.dropna(subset=["customer_text", "sentiment_label"])
    df["customer_text"] = df["customer_text"].astype(str).str.replace(r"\s+", " ", regex=True).str.strip().str.lower()
    df = df.drop_duplicates(subset=["customer_text", "sentiment_label"])
    Path(out_csv).parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out_csv, index=False)


__all__ = ["clean_sentiment"]
