from __future__ import annotations

from pathlib import Path

import pandas as pd


def clean_intent(raw_csv: str = "data/training_dataset/intent_training.csv", out_csv: str = "processed/cleaned_intent_training.csv") -> None:
    """Simple cleaning for intent training data."""
    df = pd.read_csv(raw_csv)
    df = df.dropna(subset=["customer_text", "intent_label"])
    df["customer_text"] = df["customer_text"].astype(str).str.replace(r"\s+", " ", regex=True).str.strip().str.lower()
    df = df.drop_duplicates(subset=["customer_text", "intent_label"])
    Path(out_csv).parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out_csv, index=False)


__all__ = ["clean_intent"]
