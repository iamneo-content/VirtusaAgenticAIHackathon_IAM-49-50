from __future__ import annotations

from pathlib import Path

try:
    # Prefer package-relative import
    from .cleaning import clean_intent, clean_sentiment
except ImportError:
    # Fallback for direct script execution: python ml/data_cleaning.py
    import sys

    sys.path.append(str(Path(__file__).resolve().parents[1]))
    from ml.cleaning import clean_intent, clean_sentiment  # type: ignore


def run_all_cleaning(raw_dir: str, cleaned_dir: str) -> None:
    """Run both sentiment and intent cleaning steps into the cleaned_dir (e.g., processed/)."""
    Path(cleaned_dir).mkdir(parents=True, exist_ok=True)
    sentiment_in = str(Path(raw_dir) / "sentiment_training.csv")
    intent_in = str(Path(raw_dir) / "intent_training.csv")
    sentiment_out = str(Path(cleaned_dir) / "cleaned_sentiment_training.csv")
    intent_out = str(Path(cleaned_dir) / "cleaned_intent_training.csv")
    clean_sentiment(sentiment_in, sentiment_out)
    clean_intent(intent_in, intent_out)


__all__ = ["run_all_cleaning"]


if __name__ == "__main__":
    # Default CLI entrypoint for quick cleaning.
    default_raw = Path("data/training_dataset")
    default_out = Path("processed")
    run_all_cleaning(str(default_raw), str(default_out))
    print(f"Cleaned datasets written to {default_out}/cleaned_sentiment_training.csv and {default_out}/cleaned_intent_training.csv")
