from __future__ import annotations

import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
import joblib


def train_intent(in_csv: str = "processed/cleaned_intent_training.csv", vec_out: str = "ml/models/tfidf_intent.pkl", model_out: str = "ml/models/intent_lr.pkl") -> None:
    """Train intent Logistic Regression classifier."""
    df = pd.read_csv(in_csv)
    texts = df["customer_text"].astype(str).tolist()
    labels = df["intent_label"].astype(str).tolist()
    vectorizer = TfidfVectorizer(ngram_range=(1, 2), min_df=3)
    x = vectorizer.fit_transform(texts)
    model = LogisticRegression(max_iter=1000)
    model.fit(x, labels)
    joblib.dump(vectorizer, vec_out)
    joblib.dump(model, model_out)


if __name__ == "__main__":
    train_intent()
