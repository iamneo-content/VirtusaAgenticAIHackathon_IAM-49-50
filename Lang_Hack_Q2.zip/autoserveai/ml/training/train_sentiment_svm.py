from __future__ import annotations

from typing import Optional

import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import LinearSVC
import joblib


def train_sentiment(in_csv: str = "processed/cleaned_sentiment_training.csv", vec_out: str = "ml/models/tfidf_sentiment.pkl", model_out: str = "ml/models/sentiment_svm.pkl") -> None:
    """Train sentiment LinearSVC model."""
    df = pd.read_csv(in_csv)
    texts = df["customer_text"].astype(str).tolist()
    labels = df["sentiment_label"].astype(str).tolist()
    vectorizer = TfidfVectorizer(ngram_range=(1, 2), min_df=3)
    x = vectorizer.fit_transform(texts)
    model = LinearSVC()
    model.fit(x, labels)
    joblib.dump(vectorizer, vec_out)
    joblib.dump(model, model_out)


if __name__ == "__main__":
    train_sentiment()
