from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field


class TicketRow(BaseModel):
    model_config = ConfigDict(extra="ignore")

    ticket_id: str
    customer_text: str
    language_code: Optional[str] = None
    channel_source: Optional[str] = None
    created_timestamp: str
    priority_level: Optional[str] = None
    assigned_team: Optional[str] = None


class SentimentPred(BaseModel):
    model_config = ConfigDict(extra="ignore")

    ticket_id: str
    label: Literal["positive", "neutral", "negative"]
    confidence: float


class IntentPred(BaseModel):
    model_config = ConfigDict(extra="ignore")

    ticket_id: str
    label: str
    confidence: float


class ReclassPred(BaseModel):
    model_config = ConfigDict(extra="ignore")

    ticket_id: str
    label: str
    confidence: float


class RouteDecision(BaseModel):
    model_config = ConfigDict(extra="ignore")

    low_conf_ticket_ids: List[str] = Field(default_factory=list)


class Metrics(BaseModel):
    model_config = ConfigDict(extra="ignore")

    sentiment_acc: float
    sentiment_f1_macro: float
    intent_f1_macro: float
    intent_f1_per_class: Dict[str, float]
    rouge_l: float
    overall_score: float


class WorkflowState(BaseModel):
    model_config = ConfigDict(extra="ignore")

    rows: List[TicketRow]
    sentiment: List[SentimentPred]
    intent: List[IntentPred]
    reclass: Optional[List[ReclassPred]] = None
    clusters: Dict[str, int] = Field(default_factory=dict)
    drafts_best: Dict[str, str] = Field(default_factory=dict)
    metrics: Optional[Metrics] = None
