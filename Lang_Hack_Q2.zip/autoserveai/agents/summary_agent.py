from __future__ import annotations

import os
import time
from typing import Dict, List, Optional

import google.generativeai as genai
from google.api_core.exceptions import ResourceExhausted

from agents.base_agent import BaseAgent
from state import TicketRow


class SummaryAgent(BaseAgent):
    """Cluster-level summarizer using Gemini or deterministic stub."""

    def __init__(
        self,
        model_name: str = "gemini-2.0-flash",
        api_key: Optional[str] = None,
        live_llm: Optional[bool] = None,
        delay_seconds: Optional[float] = None,
        ) -> None:
        self.model_name = model_name
        self.api_key = api_key or os.getenv("DEEP_API_KEY")
        self.live_llm = True if live_llm is None else live_llm
        if delay_seconds is None:
            self.delay_seconds = float(os.getenv("LLM_DELAY_SECONDS", "0") or 0)
        else:
            self.delay_seconds = delay_seconds

    def summarize(self, rows: List[TicketRow], clusters: Dict[str, int], drafts: Dict[str, str]) -> Dict[int, str]:
        if not self.live_llm:
            raise RuntimeError("Live LLM must be enabled for summarization.")
        if not self.api_key:
            raise RuntimeError("DEEP_API_KEY is required for summarization.")
        genai.configure(api_key=self.api_key)
        model = genai.GenerativeModel(self.model_name)
        summaries: Dict[int, str] = {}
        grouped: Dict[int, List[str]] = {}
        for row in rows:
            cluster_id = clusters.get(row.ticket_id, -1)
            if cluster_id not in grouped:
                grouped[cluster_id] = []
            text = drafts.get(row.ticket_id, row.customer_text)
            grouped[cluster_id].append(text)
        for cluster_id, texts in grouped.items():
            combined = "\n\n".join(texts)
            prompt = (
                "Summarize the common themes across these ticket responses in 2-3 sentences. "
                "Provide a concise action-oriented summary.\n"
                f"cluster_id: {cluster_id}\n"
                f"drafts:\n{combined}\n"
            )
            if self.delay_seconds > 0:
                time.sleep(self.delay_seconds)
            try:
                response = model.generate_content(prompt, generation_config={"temperature": 0.3, "max_output_tokens": 120})
                summaries[cluster_id] = response.text or ""
            except ResourceExhausted:
                raise
        return summaries


__all__ = ["SummaryAgent"]
