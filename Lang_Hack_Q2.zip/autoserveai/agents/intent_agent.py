from __future__ import annotations

from pathlib import Path
from typing import List

import joblib
import numpy as np

from agents.base_agent import BaseAgent
from state import IntentPred, TicketRow


class IntentAgent(BaseAgent):
    """Intent classifier using Logistic Regression with TF-IDF, with deterministic fallback."""

    def __init__(
        self,
        model_path: str = "ml/models/intent_lr.pkl",
        vectorizer_path: str = "ml/models/tfidf_intent.pkl",
    ) -> None:
        self.model = None
        self.vectorizer = None
        if Path(model_path).exists() and Path(vectorizer_path).exists():
            self.model = joblib.load(model_path)
            self.vectorizer = joblib.load(vectorizer_path)

    def predict(self, rows: List[TicketRow]) -> List[IntentPred]:
        texts = [row.customer_text for row in rows]
        labels: List[str]
        confidences: List[float]
        if self.model is not None and self.vectorizer is not None:
            vectors = self.vectorizer.transform(texts)
            labels = [str(label) for label in self.model.predict(vectors)]
            if hasattr(self.model, "predict_proba"):
                proba = self.model.predict_proba(vectors)
                confidences = list(np.max(proba, axis=1))
            else:
                confidences = [0.65 for _ in texts]
        else:
            labels = []
            confidences = []
            for text in texts:
                lower = text.lower()
                if "refund" in lower or "charge" in lower:
                    labels.append("billing_issue")
                    confidences.append(0.64)
                elif "password" in lower or "login" in lower:
                    labels.append("account_access")
                    confidences.append(0.66)
                elif "feature" in lower or "how do i" in lower:
                    labels.append("product_question")
                    confidences.append(0.6)
                else:
                    labels.append("general_support")
                    confidences.append(0.55)
        predictions = []
        for idx, row in enumerate(rows):
            predictions.append(IntentPred(ticket_id=row.ticket_id, label=labels[idx], confidence=float(confidences[idx])))
        return predictions


__all__ = ["IntentAgent"]
