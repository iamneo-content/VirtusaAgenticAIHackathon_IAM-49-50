from __future__ import annotations

import json
import os
import time
from typing import List, Optional

import google.generativeai as genai

from agents.base_agent import BaseAgent
from state import ReclassPred, TicketRow


class ReclassAgent(BaseAgent):
    """Reclassification with optional Gemini live calls; falls back to deterministic stub."""

    def __init__(
        self,
        model_name: str = "gemini-2.0-flash",
        api_key: Optional[str] = None,
        live_llm: Optional[bool] = None,
        delay_seconds: Optional[float] = None,
    ) -> None:
        self.model_name = model_name
        self.api_key = api_key or os.getenv("RECLASS_API_KEY")
        if live_llm is None:
            env_flag = os.getenv("LIVE_LLM", "").lower() == "true"
            self.live_llm = env_flag
        else:
            self.live_llm = live_llm
        if delay_seconds is None:
            self.delay_seconds = float(os.getenv("LLM_DELAY_SECONDS", "0") or 0)
        else:
            self.delay_seconds = delay_seconds

    def predict(self, rows: List[TicketRow]) -> List[ReclassPred]:
        if not self.live_llm:
            return self._predict_stub(rows)
        if not self.api_key:
            raise RuntimeError("RECLASS_API_KEY is required for LLM reclassification.")
        genai.configure(api_key=self.api_key)
        model = genai.GenerativeModel(self.model_name)
        predictions: List[ReclassPred] = []
        for row in rows:
            prompt = (
                "Classify the customer ticket into a concise intent label. "
                "Respond ONLY in JSON with keys label and confidence (0-1).\n"
                f"ticket_id: {row.ticket_id}\ntext: {row.customer_text}\n"
            )
            if self.delay_seconds > 0:
                time.sleep(self.delay_seconds)
            response = model.generate_content(prompt, generation_config={"temperature": 0.2})
            label = "general_support"
            confidence = 0.65
            try:
                parsed = json.loads(response.text or "{}")
                if isinstance(parsed, dict):
                    label = str(parsed.get("label", label))
                    confidence = float(parsed.get("confidence", confidence))
            except Exception:
                label = (response.text or label).strip().split()[0]
            predictions.append(ReclassPred(ticket_id=row.ticket_id, label=label, confidence=confidence))
        return predictions

    def _predict_stub(self, rows: List[TicketRow]) -> List[ReclassPred]:
        predictions: List[ReclassPred] = []
        for row in rows:
            lower = row.customer_text.lower()
            if "refund" in lower:
                label = "billing_issue"
                confidence = 0.71
            elif "password" in lower or "login" in lower:
                label = "account_access"
                confidence = 0.7
            elif "feature" in lower or "request" in lower:
                label = "feature_request"
                confidence = 0.69
            elif "verify" in lower or "code" in lower:
                label = "verification_issue"
                confidence = 0.68
            else:
                label = "general_support"
                confidence = 0.65
            predictions.append(ReclassPred(ticket_id=row.ticket_id, label=label, confidence=confidence))
        return predictions


__all__ = ["ReclassAgent"]
