from __future__ import annotations

import os
import time
from typing import Dict, List, Optional

import google.generativeai as genai

from agents.base_agent import BaseAgent
from state import TicketRow


class DraftDeepAgent(BaseAgent):
    """Heavier drafting agent that can call Gemini or fall back to deterministic stub."""

    def __init__(
        self,
        model_name: str = "gemini-2.0-flash",
        api_key: Optional[str] = None,
        live_llm: Optional[bool] = None,
        delay_seconds: Optional[float] = None,
    ) -> None:
        self.model_name = model_name
        self.api_key = api_key or os.getenv("DEEP_API_KEY")
        self.live_llm = True if live_llm is None else live_llm
        if delay_seconds is None:
            self.delay_seconds = float(os.getenv("LLM_DELAY_SECONDS", "0") or 0)
        else:
            self.delay_seconds = delay_seconds

    def generate(self, rows: List[TicketRow], preds: Dict[str, str]) -> Dict[str, str]:
        if not self.live_llm:
            raise RuntimeError("Live LLM must be enabled for deep drafting.")
        if not self.api_key:
            raise RuntimeError("DEEP_API_KEY is required for deep drafting.")
        genai.configure(api_key=self.api_key)
        model = genai.GenerativeModel(self.model_name)
        drafts: Dict[str, str] = {}
        for row in rows:
            intent = preds.get(row.ticket_id, "general_support")
            prompt = (
                "Write a supportive, clear customer support reply (70-120 words). "
                "Include empathy, ownership, next steps, and a request for missing info. Avoid repetition.\n"
                f"ticket_id: {row.ticket_id}\nintent: {intent}\ncustomer: {row.customer_text}\n"
            )
            if self.delay_seconds > 0:
                time.sleep(self.delay_seconds)
            response = model.generate_content(prompt, generation_config={"temperature": 0.4, "max_output_tokens": 200})
            drafts[row.ticket_id] = response.text or ""
        return drafts


__all__ = ["DraftDeepAgent"]
