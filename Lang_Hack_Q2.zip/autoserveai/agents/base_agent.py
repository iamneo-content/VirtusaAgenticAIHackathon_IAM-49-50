from __future__ import annotations

from typing import Any


class BaseAgent:
    """Base interface for lightweight agents."""

    def run(self, payload: Any) -> Any:
        raise NotImplementedError("Subclasses must implement run().")


__all__ = ["BaseAgent"]
