from __future__ import annotations

from typing import Dict

from agents.base_agent import BaseAgent


class JudgeAgent(BaseAgent):
    """Deterministic judge selecting the stronger draft per ticket."""

    def select(self, fast: Dict[str, str], deep: Dict[str, str], rubric: Dict) -> Dict[str, str]:
        results: Dict[str, str] = {}
        prefer_depth = bool(rubric.get("prefer_depth", True))
        for ticket_id in fast:
            fast_text = fast[ticket_id]
            deep_text = deep.get(ticket_id, fast_text)
            if prefer_depth and len(deep_text) >= len(fast_text):
                results[ticket_id] = deep_text
            else:
                results[ticket_id] = fast_text
        return results


__all__ = ["JudgeAgent"]
