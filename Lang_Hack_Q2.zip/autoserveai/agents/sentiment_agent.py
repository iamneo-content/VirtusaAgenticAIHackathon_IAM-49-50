from __future__ import annotations

import math
from pathlib import Path
from typing import List, Optional

import joblib

from agents.base_agent import BaseAgent
from state import SentimentPred, TicketRow


class SentimentAgent(BaseAgent):
    """Sentiment classifier using LinearSVC with TF-IDF, with a heuristic fallback."""

    def __init__(
        self,
        model_path: str = "ml/models/sentiment_svm.pkl",
        vectorizer_path: str = "ml/models/tfidf_sentiment.pkl",
    ) -> None:
        self.model = None
        self.vectorizer = None
        if Path(model_path).exists() and Path(vectorizer_path).exists():
            self.model = joblib.load(model_path)
            self.vectorizer = joblib.load(vectorizer_path)

    def predict(self, rows: List[TicketRow]) -> List[SentimentPred]:
        texts = [row.customer_text for row in rows]
        labels: List[str]
        confidences: List[float]
        if self.model is not None and self.vectorizer is not None:
            vectors = self.vectorizer.transform(texts)
            labels = [str(label) for label in self.model.predict(vectors)]
            scores = self.model.decision_function(vectors)
            confidences = []
            for score in scores:
                if isinstance(score, float):
                    value = abs(score)
                else:
                    value = float(max(score))
                confidences.append(float(1.0 / (1.0 + math.exp(-value))))
        else:
            labels = []
            confidences = []
            for text in texts:
                lower = text.lower()
                if "thank" in lower or "great" in lower:
                    labels.append("positive")
                    confidences.append(0.7)
                elif "not" in lower or "bad" in lower or "angry" in lower:
                    labels.append("negative")
                    confidences.append(0.6)
                else:
                    labels.append("neutral")
                    confidences.append(0.55)
        predictions = []
        for idx, row in enumerate(rows):
            predictions.append(
                SentimentPred(ticket_id=row.ticket_id, label=labels[idx], confidence=confidences[idx])
            )
        return predictions


__all__ = ["SentimentAgent"]
