from __future__ import annotations

import re
from typing import Dict

from agents.base_agent import BaseAgent


class SafetyGuardAgent(BaseAgent):
    """Redacts emails and long digit sequences."""

    def sanitize(self, drafts: Dict[str, str]) -> Dict[str, str]:
        cleaned: Dict[str, str] = {}
        for ticket_id, text in drafts.items():
            redacted = re.sub(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+", "[REDACTED_EMAIL]", text)
            redacted = re.sub(r"\b\d{6,}\b", "[REDACTED_NUMBER]", redacted)
            cleaned[ticket_id] = redacted
        return cleaned


__all__ = ["SafetyGuardAgent"]
