from __future__ import annotations

from typing import Dict, Optional

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class AppSettings(BaseSettings):
    """Application settings loaded from environment variables or defaults."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        populate_by_name=True,
        extra="allow",
    )

    confidence_threshold: float = Field(default=0.65, alias="CONFIDENCE_THRESHOLD")
    cluster_k: int = Field(default=12, alias="CLUSTER_K")
    weights: Dict[str, float] = Field(
        default_factory=lambda: {"sentiment": 0.3, "intent": 0.4, "rouge_l": 0.3}
    )
    embedding_model: str = Field(default="text-embedding-3-small", alias="EMBEDDING_MODEL")
    fast_model: str = Field(default="gemini-2.0-flash", alias="FAST_MODEL")
    deep_model: str = Field(default="gemini-2.0-flash", alias="DEEP_MODEL")
    reclass_model: str = Field(default="gemini-2.0-flash", alias="RECLASS_MODEL")
    live_llm: bool = Field(default=True, alias="LIVE_LLM")
    summary_live_llm: bool = Field(default=True, alias="SUMMARY_LIVE_LLM")
    llm_delay_seconds: float = Field(default=0.0, alias="LLM_DELAY_SECONDS")
    max_tickets: int = Field(default=15, alias="MAX_TICKETS")
    input_csv: str = Field(default="data/input/tickets.csv", alias="INPUT_CSV")
    ground_truth_csv: str = Field(default="eval/ground_truth.csv", alias="GROUND_TRUTH_CSV")
    output_dir: str = Field(default="eval/runs", alias="OUTPUT_DIR")
    log_level: str = Field(default="INFO", alias="LOG_LEVEL")
    fast_api_key: Optional[str] = Field(default=None, alias="FAST_API_KEY")
    deep_api_key: Optional[str] = Field(default=None, alias="DEEP_API_KEY")
    reclass_api_key: Optional[str] = Field(default=None, alias="RECLASS_API_KEY")


__all__ = ["AppSettings"]
