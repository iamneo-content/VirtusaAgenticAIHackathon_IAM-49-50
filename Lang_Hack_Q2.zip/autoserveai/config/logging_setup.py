from __future__ import annotations

from pathlib import Path
from typing import Optional

from loguru import logger


def setup_logging(level: str, logfile: str) -> None:
    """Configure loguru logging with console and file sinks."""
    logger.remove()
    logger.add(lambda msg: print(msg, end=""), level=level.upper())
    log_path = Path(logfile)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    logger.add(log_path, level=level.upper(), enqueue=True, rotation="1 MB")


__all__ = ["setup_logging"]
