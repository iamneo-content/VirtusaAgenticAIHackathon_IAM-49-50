from __future__ import annotations

from typing import Optional

import pandas as pd
import streamlit as st

from config import AppSettings, setup_logging
from workflow import BatchWorkflowGraph, SingleTicketGraph, SingleTicketResult


st.set_page_config(page_title="AutoServeAI Demo", layout="wide", page_icon="🤖")

# Global style
st.markdown(
    """
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&display=swap');
        html, body, [class*="css"]  {
            font-family: 'Space Grotesk', sans-serif;
        }
        .gradient-banner {
            background: linear-gradient(135deg, #0f172a, #1e293b 60%, #0ea5e9);
            color: #f8fafc;
            padding: 28px 28px 22px 28px;
            border-radius: 18px;
            margin-bottom: 24px;
            box-shadow: 0 18px 38px rgba(0,0,0,0.18);
        }
        .pill {
            display: inline-flex;
            align-items: center;
            padding: 6px 12px;
            border-radius: 999px;
            background: rgba(255,255,255,0.12);
            color: #e2e8f0;
            font-size: 12px;
            letter-spacing: 0.6px;
            text-transform: uppercase;
            margin-bottom: 8px;
        }
        .metric-card {
            padding: 16px;
            border-radius: 16px;
            border: 1px solid #e2e8f0;
            background: #ffffff;
            box-shadow: 0 12px 24px rgba(15,23,42,0.06);
        }
        .metric-label {
            color: #475569;
            font-size: 13px;
        }
        .metric-value {
            font-size: 22px;
            font-weight: 700;
            color: #0f172a;
        }
        .section {
            padding: 18px;
            border-radius: 16px;
            border: 1px solid #e2e8f0;
            background: #f8fafc;
        }
        .run-button .stButton>button {
            width: 100%;
            background: linear-gradient(135deg, #0ea5e9, #6366f1);
            color: white;
            border: none;
            height: 44px;
            border-radius: 12px;
            font-weight: 700;
        }
    </style>
    """,
    unsafe_allow_html=True,
)


def render_header() -> None:
    st.markdown(
        """
        <div class="gradient-banner">
            <div class="pill">Dual pipelines · Batch + Single ticket</div>
            <h1 style="margin: 4px 0 8px 0;">AutoServeAI — Agentic Customer Service Analyzer</h1>
        </div>
        """,
        unsafe_allow_html=True,
    )


def main() -> None:
    settings = AppSettings()
    setup_logging(settings.log_level, "logs/app.log")

    render_header()

    if "single_ticket_result" not in st.session_state:
        st.session_state["single_ticket_result"] = None
    if "batch_metrics" not in st.session_state:
        st.session_state["batch_metrics"] = None

    batch_tab, single_tab = st.tabs(["Batch evaluation", "Single-ticket drafting"])

    # Batch tab
    with batch_tab:
        st.subheader("Batch metrics")
        col_left, col_right = st.columns([1, 2])
        with col_left:
            run_id = st.text_input("Run ID", value="2025-11-A", key="batch_run_id")
            input_path = st.text_input("Input CSV", value=settings.input_csv, key="batch_input")
            ground_truth_path = st.text_input(
                "Ground Truth CSV", value=settings.ground_truth_csv, key="batch_ground_truth"
            )
            threshold = st.slider(
                "Confidence Threshold",
                min_value=0.0,
                max_value=1.0,
                value=settings.confidence_threshold,
                step=0.05,
                key="batch_threshold",
            )
            cluster_k = st.number_input(
                "Cluster K", min_value=2, max_value=50, value=settings.cluster_k, step=1, key="batch_cluster_k"
            )
            run_batch = st.button("Run batch evaluation", type="primary", use_container_width=True)
        with col_right:
            if run_batch:
                custom_settings = AppSettings(
                    confidence_threshold=threshold,
                    cluster_k=cluster_k,
                    input_csv=input_path,
                    ground_truth_csv=ground_truth_path,
                    output_dir=settings.output_dir,
                    log_level=settings.log_level,
                    weights=settings.weights,
                    embedding_model=settings.embedding_model,
                    fast_model=settings.fast_model,
                    deep_model=settings.deep_model,
                    reclass_model=settings.reclass_model,
                    fast_api_key=settings.fast_api_key,
                    deep_api_key=settings.deep_api_key,
                    reclass_api_key=settings.reclass_api_key,
                    live_llm=True,
                    summary_live_llm=True,
                    llm_delay_seconds=0.0,
                )
                try:
                    graph = BatchWorkflowGraph(custom_settings)
                    state = graph.run_stateful(run_id)
                    st.session_state["batch_metrics"] = state.metrics.model_dump()
                    st.success(f"Batch run {run_id} complete.")
                except Exception as exc:  # noqa: BLE001
                    st.error(f"Batch run failed: {exc}")
                    st.session_state["batch_metrics"] = None

            if st.session_state.get("batch_metrics"):
                metrics = st.session_state["batch_metrics"]
                m_cols = st.columns(3)
                m_cols[0].markdown(
                    f"""<div class="metric-card"><div class="metric-label">Sentiment F1 (macro)</div>
                    <div class="metric-value">{metrics.get('sentiment_f1_macro', 0):.3f}</div></div>""",
                    unsafe_allow_html=True,
                )
                m_cols[1].markdown(
                    f"""<div class="metric-card"><div class="metric-label">Intent F1 (macro)</div>
                    <div class="metric-value">{metrics.get('intent_f1_macro', 0):.3f}</div></div>""",
                    unsafe_allow_html=True,
                )
                m_cols[2].markdown(
                    f"""<div class="metric-card"><div class="metric-label">Overall Score</div>
                    <div class="metric-value">{metrics.get('overall_score', 0):.3f}</div></div>""",
                    unsafe_allow_html=True,
                )
                st.markdown("#### Detailed metrics")
                st.table(
                    {
                        "Metric": [
                            "sentiment_acc",
                            "sentiment_f1_macro",
                            "intent_f1_macro",
                            "rouge_l",
                            "overall_score",
                        ],
                        "Value": [
                            f"{metrics.get('sentiment_acc', 0):.3f}",
                            f"{metrics.get('sentiment_f1_macro', 0):.3f}",
                            f"{metrics.get('intent_f1_macro', 0):.3f}",
                            f"{metrics.get('rouge_l', 0):.3f}",
                            f"{metrics.get('overall_score', 0):.3f}",
                        ],
                    }
                )
            else:
                st.info("Run the batch evaluation to see metrics.")

    # Single-ticket tab
    with single_tab:
        st.subheader("Single-ticket drafting")
        input_cols = st.columns([1.2, 1.2, 0.8, 0.8, 1])
        input_path = input_cols[0].text_input("Input CSV", value=settings.input_csv, key="single_input")
        ground_truth_path = input_cols[1].text_input(
            "Ground Truth CSV (optional)", value=settings.ground_truth_csv, key="single_ground_truth"
        )
        threshold = input_cols[2].slider(
            "Confidence τ",
            min_value=0.0,
            max_value=1.0,
            value=settings.confidence_threshold,
            step=0.05,
            key="single_threshold",
        )
        cluster_k = input_cols[3].number_input(
            "Cluster K", min_value=2, max_value=50, value=settings.cluster_k, step=1, key="single_cluster_k"
        )
        live_col, summary_col = st.columns([1, 1])
        live_llm = live_col.checkbox("Use live LLM calls", value=True, key="single_live_llm")
        summary_live_llm = summary_col.checkbox(
            "Use live summary LLM", value=True, key="single_summary_live_llm"
        )

        ticket_ids = []
        ticket_cache = {}
        load_error = None
        try:
            df = pd.read_csv(input_path)
            if "ticket_id" in df.columns:
                df["ticket_id"] = df["ticket_id"].astype(str)
                ticket_ids = df["ticket_id"].tolist()
                ticket_cache = df.set_index("ticket_id").to_dict(orient="index")
        except Exception as exc:  # noqa: BLE001
            load_error = str(exc)

        selector_col, run_col = st.columns([2, 1])
        selected_ticket = None
        if ticket_ids:
            default_idx = 0
            if st.session_state.get("selected_ticket_id") in ticket_ids:
                default_idx = ticket_ids.index(st.session_state["selected_ticket_id"])
            selected_ticket = selector_col.selectbox("Ticket ID", ticket_ids, index=default_idx)
        else:
            selector_col.warning(load_error or "No tickets found; check the CSV path and headers.")

        run_trigger = run_col.button(
            "Run single-ticket graph", type="primary", use_container_width=True, disabled=not selected_ticket
        )

        gt_cache = {}
        if ground_truth_path:
            try:
                gt_df = pd.read_csv(ground_truth_path)
                if "ticket_id" in gt_df.columns:
                    gt_cache = gt_df.set_index("ticket_id").to_dict()
            except Exception:  # noqa: BLE001
                gt_cache = {}

        preview_col, result_col = st.columns([1.1, 1.9])
        with preview_col:
            st.markdown("### Ticket preview")
            if selected_ticket and selected_ticket in ticket_cache:
                ticket_row = ticket_cache[selected_ticket]
                st.markdown(
                    f"**{selected_ticket}** · {ticket_row.get('channel_source', 'unknown')} · {ticket_row.get('created_timestamp', '')}"
                )
                st.write(ticket_row.get("customer_text", ""))
                st.caption(
                    f"Priority: {ticket_row.get('priority_level', 'n/a')} • Team: {ticket_row.get('assigned_team', 'n/a')}"
                )
            else:
                st.info("Select a ticket to inspect its text before running the graph.")

        if run_trigger and selected_ticket:
            custom_settings = AppSettings(
                confidence_threshold=threshold,
                cluster_k=cluster_k,
                input_csv=input_path,
                ground_truth_csv=ground_truth_path,
                output_dir=settings.output_dir,
                log_level=settings.log_level,
                weights=settings.weights,
                embedding_model=settings.embedding_model,
                fast_model=settings.fast_model,
                deep_model=settings.deep_model,
                reclass_model=settings.reclass_model,
                fast_api_key=settings.fast_api_key,
                deep_api_key=settings.deep_api_key,
                reclass_api_key=settings.reclass_api_key,
                live_llm=live_llm,
                summary_live_llm=summary_live_llm,
                llm_delay_seconds=settings.llm_delay_seconds,
            )
            try:
                graph = SingleTicketGraph(custom_settings)
                result = graph.run(selected_ticket)
                st.session_state["single_ticket_result"] = result
                st.session_state["selected_ticket_id"] = selected_ticket
            except Exception as exc:  # noqa: BLE001
                st.session_state["single_ticket_result"] = None
                st.error(f"Run failed: {exc}")

        result: Optional[SingleTicketResult] = st.session_state.get("single_ticket_result")
        if result:
            with result_col:
                st.success(f"Pipeline complete for ticket {result.ticket.ticket_id}")
                st.markdown("#### Final AI reply")
                st.write(result.safe_draft or "No draft generated.")

                st.markdown("#### Predictions")
                preds_cols = st.columns(3)
                preds_cols[0].markdown(
                    f"""<div class="metric-card"><div class="metric-label">Sentiment</div>
                    <div class="metric-value">{result.sentiment.label}</div>
                    <div style="color:#64748b;font-size:12px;">conf {result.sentiment.confidence:.2f}</div></div>""",
                    unsafe_allow_html=True,
                )
                preds_cols[1].markdown(
                    f"""<div class="metric-card"><div class="metric-label">Intent</div>
                    <div class="metric-value">{result.intent.label}</div>
                    <div style="color:#64748b;font-size:12px;">conf {result.intent.confidence:.2f}</div></div>""",
                    unsafe_allow_html=True,
                )
                preds_cols[2].markdown(
                    f"""<div class="metric-card"><div class="metric-label">Cluster</div>
                    <div class="metric-value">#{result.cluster_id}</div>
                    <div style="color:#64748b;font-size:12px;">reclass: {"yes" if result.reclass else "no"}</div></div>""",
                    unsafe_allow_html=True,
                )

                st.markdown("#### Cluster summary")
                st.info(result.summary or "No summary generated.")

                with st.expander("Trace & context", expanded=False):
                    st.markdown("**Draft trace (fast → deep → judge → safety)**")
                    st.write(result.fast_draft or "n/a")
                    st.write(result.deep_draft or "n/a")
                    st.write(result.judged_draft or "n/a")
                    st.write(result.safe_draft or "n/a")

                    st.markdown("**Context and clustering**")
                    st.markdown(f"Cluster ID: #{result.cluster_id}")
                    if result.cluster_context:
                        for ctx in result.cluster_context:
                            st.write(f"- {ctx.ticket_id}: {ctx.customer_text}")
                    else:
                        st.info("No neighboring tickets found for this cluster.")
        else:
            with result_col:
                st.info("Select a ticket, adjust settings, then run the single-ticket graph.")


if __name__ == "__main__":
    main()
