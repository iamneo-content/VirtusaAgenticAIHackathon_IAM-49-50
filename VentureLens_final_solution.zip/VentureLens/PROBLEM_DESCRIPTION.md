VENTURELENS: STARTUP VIABILITY & FUNDING ANALYSIS PLATFORM
================================================================

PROBLEM STATEMENT
=================================================================

VentureLens is an AI-powered startup analysis platform designed to evaluate startup viability and provide strategic funding recommendations. The system analyzes startups across multiple dimensions: financial health, team competitiveness, market opportunity, pitch effectiveness, risk assessment, and funding readiness.

Business Problem:
→ Investors need rapid, comprehensive, data-driven assessment of startup potential
→ Founders need actionable insights about strengths, weaknesses, and strategic direction
→ Current manual analysis is time-consuming, subjective, and inconsistent
→ Decision-making requires both quantitative metrics and qualitative insights

Solution Approach:
→ Combine Machine Learning (financial & team analysis) with Large Language Models (market, pitch, risk, funding)
→ Implement parallel processing for speed and sequential refinement for accuracy
→ Provide comprehensive 7-stage analysis pipeline
→ Deliver insights through user-friendly web interface


FILE STRUCTURE & ORGANIZATION
=================================================================

Root Level Files:
───────────────────
→ main.py: Streamlit web application entry point and user interface
→ graph.py: High-level orchestration functions coordinating workflow execution
→ state.py: Central state management using TypedDict with 90 fields
→ requirements.txt: Python package dependencies and versions
→ .env: API configuration and secret keys for Google Gemini


Directory: workflow/
───────────────────
→ workflow.py: LangGraph workflow builder and executor
  Purpose: Constructs 7-node state machine pipeline, defines edges, compiles graph


Directory: nodes/
───────────────────
→ form_parser_node.py: Input validation and normalization stage
→ financial_analyzer_node.py: ML-based financial viability scoring
→ team_assessor_node.py: ML-based team competitiveness evaluation
→ market_opportunity_node.py: LLM-based market analysis
→ pitch_quality_node.py: LLM-based pitch effectiveness evaluation
→ risk_evaluator_node.py: LLM-based multi-dimensional risk assessment
→ funding_recommender_node.py: LLM-based funding strategy recommendations
  Purpose: Each node processes state, calls agent, returns state updates


Directory: agents/
───────────────────
→ financial_analyzer_ml.py: Random Forest model for financial prediction
→ team_assessor_ml.py: Random Forest model for team competitiveness
→ market_opportunity_assessor_llm.py: Gemini LLM agent for market analysis
→ pitch_quality_analyzer_llm.py: Gemini LLM agent for pitch evaluation
→ risk_evaluator_llm.py: Gemini LLM agent for risk assessment
→ funding_recommender_llm.py: Gemini LLM agent for funding strategy
  Purpose: Core analysis implementations, ML predictions, and LLM prompting


Directory: utils/
───────────────────
→ gemini_client.py: Gemini API client with automatic key rotation
  Purpose: Handle LLM API calls, JSON parsing, response validation, error recovery


Directory: ml/
───────────────────
→ train_pipeline.py: Master orchestrator for entire ML training workflow
  Purpose: Coordinates data loading, cleaning, model training, and evaluation

Sub-directory: ml/train_model/
  → train_financial_viability.py: Trains financial prediction model
  → train_team_competitiveness.py: Trains team evaluation model
  Purpose: Model training with train-test split, feature scaling, metric calculation

Sub-directory: ml/data_cleaning/
  → clean_financial_data.py: Cleans financial training data
  → clean_team_data.py: Cleans team training data
  Purpose: Data preprocessing with duplicate removal, outlier detection, encoding

Sub-directory: ml/evaluation/
  → evaluate_models.py: Evaluates trained models on evaluation datasets
  Purpose: Calculate accuracy, precision, recall, F1 scores for both models

Sub-directory: ml/models/
  → financial_viability_model.pkl: Serialized financial prediction model
  → financial_viability_scaler.pkl: StandardScaler for feature normalization
  → financial_viability_label_encoder.pkl: Encoder for class labels
  → team_competitiveness_model.pkl: Serialized team evaluation model
  → team_competitiveness_scaler.pkl: StandardScaler for feature normalization
  → team_competitiveness_label_encoder.pkl: Encoder for class labels


Directory: data/
───────────────────
Sub-directory: data/input/
  → PROP-1.json through PROP-30.json: 30 startup profile JSON files
  Purpose: Input data for analysis and testing

Sub-directory: data/training_dataset/
  → financial_viability_training.csv: 19+ startup financial records
  → team_competitiveness_training.csv: 19+ startup team composition records
  Purpose: Raw training data for model development

Sub-directory: data/evaluation_dataset/
  → financial_viability_evaluation.csv: Evaluation data for financial model
  → team_competitiveness_evaluation.csv: Evaluation data for team model
  Purpose: Separate evaluation data to assess model performance

Sub-directory: data/processed/
  → financial_viability_cleaned.csv: Cleaned financial training data
  → team_competitiveness_cleaned.csv: Cleaned team training data
  Purpose: Pre-processed data ready for model training


PURPOSE OF KEY FILES
=================================================================

main.py (Streamlit Web Application)
───────────────────────────────────
Purpose: User interface for startup analysis
Responsibilities:
→ Load and display startup selection interface
→ Handle analysis workflow triggers
→ Render analysis results in tabs
→ Export results to JSON and CSV formats
→ Display model evaluation metrics

graph.py (Orchestration Layer)
───────────────────────────────────
Purpose: High-level API for startup analysis
Responsibilities:
→ Initialize state from input data
→ Build and invoke workflow
→ Extract summary from results
→ Provide clean interface between UI and workflow

state.py (State Management)
───────────────────────────────────
Purpose: Central state definition and initialization
Responsibilities:
→ Define StartupViabilityState TypedDict with 93 fields
→ Validate required input fields
→ Normalize text inputs
→ Track analysis progress through 7 stages

workflow/workflow.py (Workflow Engine)
───────────────────────────────────
Purpose: Define and compile LangGraph workflow
Responsibilities:
→ Create StateGraph with StartupViabilityState
→ Add 7 processing nodes
→ Define execution edges and dependencies
→ Compile workflow for execution

nodes/* (Processing Stages)
───────────────────────────────────
Purpose: Individual processing stages in analysis pipeline
Responsibilities:
→ Extract relevant data from state
→ Call appropriate agent function
→ Return state updates
→ Handle errors gracefully

agents/* (Analysis Implementations)
───────────────────────────────────
Purpose: Core analysis logic (ML and LLM-based)
Responsibilities:
→ Load and use ML models
→ Construct and submit LLM prompts
→ Parse and validate responses
→ Return structured analysis results

utils/gemini_client.py (LLM Integration)
───────────────────────────────────
Purpose: Interface to Google Gemini API
Responsibilities:
→ Manage API keys and rotation
→ Generate content using LLM
→ Parse JSON from LLM responses
→ Validate required fields
→ Handle quota errors and retries

ml/train_pipeline.py (Training Orchestration)
───────────────────────────────────
Purpose: Coordinate entire ML pipeline
Responsibilities:
→ Load raw training data
→ Execute data cleaning
→ Train models
→ Evaluate results
→ Save artifacts


CLASS STRUCTURE & METHOD DEFINITIONS
=================================================================

AGENT CLASSES
═════════════════════════════════════════════════════════════

agents/financial_analyzer_ml.py
───────────────────────────────────────────

Class: FinancialAnalyzerMLAgent
───────────────────────────────────────────────────────────────
Purpose: ML-based financial viability analysis using pre-trained RandomForest

Constructor: __init__(self, model_dir: string = "ml/models") → None
  Parameters:
    → model_dir: string = "ml/models": Path to directory containing trained ML models
  Logic:
    1. Initialize instance variables
    2. Set model directory path
    3. Call _load_model() to load trained model artifacts
  Returns: FinancialAnalyzerMLAgent instance

Private Method: _load_model(self) → None
  Logic:
    1. Load financial_viability_model.pkl from model_dir
    2. Load financial_viability_scaler.pkl for feature normalization
    3. Load financial_viability_label_encoder.pkl for class labels
    4. Store loaded artifacts in instance variables
  Returns: None

Public Method: analyze_financial_viability(self, startup_data: dictionary) → dictionary
  Parameters:
    → startup_data: dictionary: Input with 11 financial features
  Logic:
    1. Extract 11 features from startup_data (MRR, ARR, runway, burn, CAC, LTV, customers, growth, churn, business_stage, funding_round)
    2. Handle missing features with defaults (0)
    3. Normalize features using loaded scaler
    4. Predict class using RandomForest
    5. Get probability distribution using predict_proba
    6. Convert class index to label string
    7. Extract maximum probability as confidence
    8. Return predictions and confidence
  Returns: dictionary with keys:
    → viability_score: float (max probability × 100)
    → viability_class: string (High Risk, Medium Risk, Viable, Strong)
    → confidence: float (0-100)
    → probabilities: dict of all class probabilities


agents/team_assessor_ml.py
───────────────────────────────────────────

Class: TeamAssessorMLAgent
───────────────────────────────────────────────────────────────
Purpose: ML-based team competitiveness evaluation using pre-trained RandomForest

Constructor: __init__(self, model_dir: string = "ml/models") → None
  Parameters:
    → model_dir: string = "ml/models": Path to directory containing trained ML models
  Logic:
    1. Initialize instance variables
    2. Set model directory path
    3. Call _load_model() to load trained model artifacts
  Returns: TeamAssessorMLAgent instance

Private Method: _load_model(self) → None
  Logic:
    1. Load team_competitiveness_model.pkl from model_dir
    2. Load team_competitiveness_scaler.pkl for feature normalization
    3. Load team_competitiveness_label_encoder.pkl for class labels
    4. Store loaded artifacts in instance variables
  Returns: None

Public Method: assess_team_competitiveness(self, startup_data: dictionary) → dictionary
  Parameters:
    → startup_data: dictionary: Input with 11 team features
  Logic:
    1. Extract 11 features from startup_data (CEO exp, education, exits, team size, diversity, tenure, tech cofounders, etc.)
    2. Map education level string to numeric (High School=1, Bachelor=2, Master=3, PhD=4)
    3. Handle missing features with defaults
    4. Normalize features using loaded scaler
    5. Predict class using RandomForest
    6. Get probability distribution
    7. Convert class index to label string
    8. Extract maximum probability as confidence
    9. Return predictions and confidence
  Returns: dictionary with keys:
    → strength_score: float (max probability × 100)
    → strength_class: string (Weak, Emerging, Strong, Exceptional)
    → confidence: float (0-100)
    → probabilities: dict of all class probabilities


agents/market_opportunity_assessor_llm.py
───────────────────────────────────────────

Class: MarketOpportunityAssessorLLMAgent
───────────────────────────────────────────────────────────────
Purpose: LLM-based market opportunity assessment using Gemini API

Constructor: __init__(self, client: GeniniLLMClient) → None
  Parameters:
    → client: GeniniLLMClient: Gemini API client instance (required)
  Logic:
    1. Validate client is not None
    2. Store client reference
    3. Initialize instance
  Returns: MarketOpportunityAssessorLLMAgent instance
  Raises: ValueError if client is None

Public Method: assess_market_opportunity(self, startup_data: dictionary) → dictionary
  Parameters:
    → startup_data: dictionary: Input with product, problem, market data
  Logic:
    1. Extract product description, problem, industry from startup_data
    2. Construct market analysis prompt with:
      • Product description
      • Problem addressed
      • Industry
      • Target market size
      • TAM/SAM/SOM assessment
      • Competitive advantage
    3. Call self.client.generate_structured_json with prompt and required fields
    4. Required fields: market_opportunity_assessment, tam_validation, competitive_landscape, market_trends, market_growth_potential, market_timing, market_risks, market_opportunities
    5. LLM returns structured JSON response
    6. Extract market_growth_potential as market_opportunity_score
    7. Return parsed response
  Returns: dictionary with keys:
    → market_opportunity_assessment: string
    → tam_validation: dict {realistic_range, confidence, justification}
    → competitive_landscape: dict {key_competitors, positioning, advantages, threats}
    → market_trends: list of strings
    → market_growth_potential: float
    → market_timing: string
    → market_risks: list of strings
    → market_opportunities: list of strings


agents/pitch_quality_analyzer_llm.py
───────────────────────────────────────────

Class: PitchQualityAnalyzerLLMAgent
───────────────────────────────────────────────────────────────
Purpose: LLM-based pitch quality evaluation using Gemini API

Constructor: __init__(self, client: GeniniLLMClient) → None
  Parameters:
    → client: GeniniLLMClient: Gemini API client instance (required)
  Logic:
    1. Validate client is not None
    2. Store client reference
    3. Initialize instance
  Returns: PitchQualityAnalyzerLLMAgent instance
  Raises: ValueError if client is None

Public Method: analyze_pitch_quality(self, startup_data: dictionary) → dictionary
  Parameters:
    → startup_data: dictionary: Input with elevator pitch, product, problem
  Logic:
    1. Extract elevator_pitch, product_description, problem_addressed from startup_data
    2. Construct pitch evaluation prompt with:
      • Elevator pitch text
      • Product description
      • Problem addressed
    3. Call self.client.generate_structured_json with prompt and required fields
    4. Required fields: pitch_quality_score, pitch_clarity_assessment, pitch_strengths, pitch_weaknesses, pitch_recommendations, narrative_coherence_score, investor_ready_assessment, elevator_pitch_suggestions
    5. LLM returns structured JSON response
    6. Return parsed response
  Returns: dictionary with keys:
    → pitch_quality_score: float (0-100)
    → pitch_clarity_assessment: string
    → pitch_strengths: list of dicts {strength, impact_level}
    → pitch_weaknesses: list of dicts {weakness, impact_level}
    → pitch_recommendations: list of dicts {issue, recommendation}
    → narrative_coherence_score: float
    → investor_ready_assessment: string
    → elevator_pitch_suggestions: list of strings


agents/risk_evaluator_llm.py
───────────────────────────────────────────

Class: RiskEvaluatorLLMAgent
───────────────────────────────────────────────────────────────
Purpose: LLM-based multi-dimensional risk assessment using Gemini API

Constructor: __init__(self, client: GeniniLLMClient) → None
  Parameters:
    → client: GeniniLLMClient: Gemini API client instance (required)
  Logic:
    1. Validate client is not None
    2. Store client reference
    3. Initialize instance
  Returns: RiskEvaluatorLLMAgent instance
  Raises: ValueError if client is None

Public Method: evaluate_risks(self, startup_data: dictionary) → dictionary
  Parameters:
    → startup_data: dictionary: Input with stage, metrics, team, scores
  Logic:
    1. Extract business_stage, financial metrics (MRR, burn, runway) from startup_data
    2. Extract team info (size, CEO experience, tech cofounders)
    3. Extract previous analysis scores (financial, team, market)
    4. Construct risk assessment prompt with:
      • Business stage
      • Financial metrics
      • Team composition
      • Previous analysis scores
    5. Call self.client.generate_structured_json with prompt and required fields
    6. Required fields: overall_risk_rating, risk_dimensions, critical_risk_areas, risk_mitigation_strategies, risk_management_priorities
    7. Risk dimensions include: execution, market, financial, team, regulatory, technology, competitive
    8. LLM returns structured JSON response with 7 risk dimensions
    9. Return parsed response
  Returns: dictionary with keys:
    → overall_risk_rating: string (Critical/High/Medium/Low)
    → risk_dimensions: dict with 7 dimensions
    → critical_risk_areas: list of strings
    → risk_mitigation_strategies: dict {risk: [strategies]}
    → risk_management_priorities: list of dicts


agents/funding_recommender_llm.py
───────────────────────────────────────────

Class: FundingRecommenderLLMAgent
───────────────────────────────────────────────────────────────
Purpose: LLM-based funding strategy recommendation using Gemini API

Constructor: __init__(self, client: GeniniLLMClient) → None
  Parameters:
    → client: GeniniLLMClient: Gemini API client instance (required)
  Logic:
    1. Validate client is not None
    2. Store client reference
    3. Initialize instance
  Returns: FundingRecommenderLLMAgent instance
  Raises: ValueError if client is None

Public Method: generate_funding_recommendations(self, startup_data: dictionary) → dictionary
  Parameters:
    → startup_data: dictionary: Complete startup data with all scores
  Logic:
    1. Extract business_stage, current_funding_round from startup_data
    2. Extract financial data (total_raised, target_amount, MRR, growth, runway)
    3. Extract all previous analysis scores (financial, team, market, pitch, risk)
    4. Construct funding strategy prompt with:
      • Business stage and current round
      • Fundraising amounts
      • Key metrics
      • All previous scores
      • Risk rating
    5. Call self.client.generate_structured_json with prompt and required fields
    6. Required fields: funding_readiness_score, recommended_next_round, funding_readiness_assessment, funding_timeline, valuation_guidance, investor_targeting_strategy, pitch_improvements_for_investors, alternative_funding_options, go_market_timeline, key_milestones_for_funding, red_flags_to_address
    7. LLM returns structured JSON response with comprehensive funding strategy
    8. Return parsed response
  Returns: dictionary with keys:
    → funding_readiness_score: float (0-100)
    → recommended_funding_round: string
    → funding_readiness_assessment: string
    → funding_timeline: dict
    → valuation_guidance: dict
    → investor_targeting_strategy: dict
    → pitch_improvements_for_investors: list
    → alternative_funding_options: list
    → go_market_timeline: string
    → key_milestones_for_funding: list
    → red_flags_to_address: list


state.py
───────────────────

Class: StartupViabilityState (TypedDict)
───────────────────────────────────────
Purpose: Immutable data structure defining complete analysis state

Fields (90 total):
  INPUT FIELDS (35):
    → startup_name: Optional string
    → industry: Optional string (enum)
    → location: Optional string
    → founded_date: Optional string
    → business_stage: Optional string (enum)
    → current_funding_round: Optional string (enum)
    → product_description: Optional string
    → problem_addressed: Optional string
    → target_market_size: Optional float
    → tam_sam_som_assessment: Optional string (enum)
    → key_features: Optional list of strings
    → competitive_advantage: Optional string
    → mrr: Optional float (Monthly Recurring Revenue)
    → arr: Optional float (Annual Recurring Revenue)
    → runway_months: Optional float
    → monthly_burn_rate: Optional float
    → cac: Optional float (Customer Acquisition Cost)
    → ltv: Optional float (Customer Lifetime Value)
    → customer_count: Optional integer
    → revenue_growth_rate: Optional float
    → churn_rate: Optional float
    → ceo_name: Optional string
    → ceo_experience_years: Optional float
    → ceo_has_previous_exit: Optional boolean
    → ceo_education_level: Optional string (enum)
    → technical_cofounder_count: Optional integer
    → avg_tech_experience_years: Optional float
    → team_size: Optional integer
    → non_technical_roles_filled: Optional integer
    → members_with_startup_experience: Optional integer
    → industry_domain_expertise_years: Optional float
    → founder_diversity_score: Optional float (0-100)
    → team_tenure_together_years: Optional float
    → total_raised_to_date: Optional float
    → target_funding_amount: Optional float
    → elevator_pitch: Optional string

  PROCESSING STATE (11):
    → parsed_startup: Optional dict (normalized input)
    → validation_errors: List of strings
    → parsing_complete: Boolean
    → financial_analysis_complete: Boolean
    → team_analysis_complete: Boolean
    → market_analysis_complete: Boolean
    → pitch_analysis_complete: Boolean
    → risk_analysis_complete: Boolean
    → recommendations_complete: Boolean
    → error_occurred: Boolean
    → error_messages: List of strings

  ANALYSIS RESULTS (47):
    FINANCIAL (3):
      → financial_viability_score: Optional float (0-100)
      → financial_viability_class: Optional string
      → financial_confidence: Optional float (0-100)

    TEAM (3):
      → team_strength_score: Optional float (0-100)
      → team_strength_class: Optional string
      → team_confidence: Optional float (0-100)

    MARKET (7):
      → market_opportunity_assessment: Optional string
      → market_opportunity_score: Optional float
      → tam_validation: Optional dict
      → competitive_landscape: Optional dict
      → market_trends: Optional list
      → market_growth_potential: Optional float
      → market_risks: Optional list
      → market_opportunities: Optional list

    PITCH (7):
      → pitch_quality_score: Optional float (0-100)
      → pitch_clarity_assessment: Optional string
      → pitch_strengths: Optional list of dicts
      → pitch_weaknesses: Optional list of dicts
      → pitch_recommendations: Optional list of dicts
      → narrative_coherence_score: Optional float
      → investor_ready_assessment: Optional string

    RISK (5):
      → overall_risk_rating: Optional string
      → risk_dimensions: Optional dict (7 dimensions)
      → critical_risk_areas: Optional list
      → risk_mitigation_strategies: Optional dict
      → risk_management_priorities: Optional list

    FUNDING (10):
      → funding_readiness_score: Optional float
      → recommended_funding_round: Optional string
      → funding_readiness_assessment: Optional string
      → funding_timeline: Optional dict
      → valuation_guidance: Optional dict
      → investor_targeting_strategy: Optional dict
      → pitch_improvements_for_investors: Optional list
      → alternative_funding_options: Optional list
      → key_milestones_for_funding: Optional list
      → red_flags_to_address: Optional list


utils/gemini_client.py
───────────────────

Class: GeniniLLMClient
───────────────────────────────────────
Purpose: Interface to Google Gemini API with automatic key rotation

Important Methods:

Method: __init__(self, model: string = "gemini-2.0-flash-lite")
  Parameters:
    → model: string = "gemini-2.0-flash-lite": Model identifier
  Logic: Initialize client, load API keys, configure Gemini
  Returns: GeniniLLMClient instance

Method: generate_content(self, prompt: string, temperature: float = 0.7, max_tokens: integer = 1000, response_mime_type: optional string = None) → string
  Parameters:
    → prompt: string: Input prompt for LLM
    → temperature: float = 0.7: Sampling temperature (0-1)
    → max_tokens: integer = 1000: Maximum output tokens
    → response_mime_type: optional string = None: Response format type
  Logic:
    1. Prepare generation configuration with temperature and token limit
    2. If response_mime_type provided, add to configuration
    3. Call Gemini API with prompt and config
    4. Check response is not empty
    5. On quota error: rotate to next API key and retry
    6. On other errors: log and raise immediately
    7. Return response text
  Returns: string (generated text response)

Method: extract_json_from_response(self, response_text: string) → dictionary
  Parameters:
    → response_text: string: Raw LLM response
  Logic:
    1. Clean JSON text (remove markdown fences)
    2. Try direct JSON parsing
    3. If fails: search for first JSON object using regex
    4. Strip trailing commas from JSON
    5. Parse cleaned JSON
    6. Validate result is dictionary
    7. Return parsed JSON
  Returns: dictionary (parsed JSON object)

Method: validate_response_fields(self, response: dictionary, required_fields: list) → None
  Parameters:
    → response: dictionary: Response object to validate
    → required_fields: list: List of required field names
  Logic:
    1. Check each required field exists in response
    2. If any missing: raise error with list of missing fields
  Returns: None (raises exception if validation fails)

Method: generate_structured_json(self, prompt: string, required_fields: list, temperature: float = 0.7, max_tokens: integer = 1000) → dictionary
  Parameters:
    → prompt: string: Input prompt for LLM
    → required_fields: list: List of required fields in response
    → temperature: float = 0.7: Sampling temperature
    → max_tokens: integer = 1000: Maximum tokens
  Logic:
    1. Call generate_content with application/json response type
    2. Extract JSON from response text
    3. Validate all required fields present
    4. Return validated JSON
  Returns: dictionary (validated structured JSON)


OTHER MAIN FUNCTIONS & UTILITIES
=================================================================

graph.py
───────────────────

Function: analyze_startup(form_data: dictionary, llm_client = None) → dictionary
  Parameters:
    → form_data: dictionary: Input startup data from form submission
    → llm_client = None: Optional Gemini client instance
  Logic:
    1. Initialize state from form data
    2. Build workflow with optional LLM client
    3. Invoke workflow with initial state
    4. Return complete analysis result
  Returns: dictionary (complete state with all 93 analysis fields)

Function: get_startup_summary(result: dictionary) → dictionary
  Parameters:
    → result: dictionary: Complete analysis result
  Logic:
    1. Extract 12 key fields from full result
    2. Compose summary dictionary
    3. Provide executive summary view
  Returns: dictionary (12 key metrics: name, industry, scores, risks, recommendations)


workflow/workflow.py
───────────────────

Function: build_workflow(llm_client = None) → StateGraph
  Parameters:
    → llm_client = None: Optional Gemini client instance
  Logic:
    1. Create StateGraph with StartupViabilityState type
    2. Add 7 processing nodes as lambda functions
    3. Set form_parser as entry point
    4. Define sequential edges: form_parser → financial_analyzer, team_assessor
    5. Define merge edges: both → market_opportunity → pitch_quality → risk_evaluator → funding_recommender
    6. Set funding_recommender as exit point
    7. Compile workflow for execution
  Returns: StateGraph (compiled workflow ready for invocation)

Function: run_startup_analysis_workflow(form_data: dictionary, llm_client = None) → dictionary
  Parameters:
    → form_data: dictionary: Raw startup input data
    → llm_client = None: Optional LLM client instance
  Logic:
    1. Create initial state from form data
    2. Build workflow with llm_client
    3. Invoke workflow with initial state
    4. Return final result
  Returns: dictionary (complete analysis result)


nodes/form_parser_node.py
───────────────────

Function: form_parser_node(state: StartupViabilityState, client = None) → dictionary
  Parameters:
    → state: StartupViabilityState: Current pipeline state
    → client = None: Unused (for API consistency)
  Logic:
    1. Extract startup data from state
    2. Validate 17 required fields (name, industry, stage, etc.)
    3. Check field types and value ranges
    4. Validate enum values (industry, stage, round)
    5. Validate string lengths (elevator pitch 50-200 chars)
    6. Validate numeric ranges (team_size > 0, experience >= 0)
    7. Collect all validation errors
    8. Create parsed_startup dictionary from validated data
    9. Return state updates
  Returns: dictionary with keys:
    → parsed_startup: normalized input data
    → validation_errors: list of error messages
    → parsing_complete: boolean success flag
    → error_occurred: boolean for tracking


MAIN NODE FUNCTIONS (PROCESSING PIPELINE)
═════════════════════════════════════════════════════════════

nodes/form_parser_node.py
───────────────────

Function: form_parser_node(state: StartupViabilityState, client = None) → dictionary
  Parameters:
    → state: StartupViabilityState: Current pipeline state
    → client = None: Unused (for API consistency)
  Logic:
    1. Extract startup data from state
    2. Validate 17 required fields (name, industry, stage, etc.)
    3. Check field types and value ranges
    4. Validate enum values (industry, stage, round)
    5. Validate string lengths (elevator pitch 50-200 chars)
    6. Validate numeric ranges (team_size > 0, experience >= 0)
    7. Collect all validation errors
    8. Create parsed_startup dictionary from validated data
    9. Return state updates
  Returns: dictionary with keys:
    → parsed_startup: normalized input data
    → validation_errors: list of error messages
    → parsing_complete: boolean success flag
    → error_occurred: boolean for tracking


nodes/financial_analyzer_node.py
───────────────────

Function: financial_analyzer_node(state: StartupViabilityState, client = None) → dictionary
  Parameters:
    → state: StartupViabilityState: Current pipeline state
    → client = None: Unused (ML doesn't need LLM client)
  Logic:
    1. Extract parsed_startup from state
    2. Instantiate FinancialAnalyzerMLAgent with model_dir="ml/models"
    3. Call agent.analyze_financial_viability(startup_data)
    4. Receive financial prediction and confidence
    5. Map returned result fields to state
    6. Set financial_analysis_complete to True
    7. Return state updates
  Returns: dictionary with keys:
    → financial_viability_score: float 0-100
    → financial_viability_class: string (High Risk/Medium Risk/Viable/Strong)
    → financial_confidence: float 0-100
    → financial_analysis_complete: boolean


nodes/team_assessor_node.py
───────────────────

Function: team_assessor_node(state: StartupViabilityState, client = None) → dictionary
  Parameters:
    → state: StartupViabilityState: Current pipeline state
    → client = None: Unused (ML doesn't need LLM client)
  Logic:
    1. Extract parsed_startup from state
    2. Instantiate TeamAssessorMLAgent with model_dir="ml/models"
    3. Call agent.assess_team_competitiveness(startup_data)
    4. Receive team strength prediction and confidence
    5. Map returned result fields to state
    6. Set team_analysis_complete to True
    7. Return state updates
  Returns: dictionary with keys:
    → team_strength_score: float 0-100
    → team_strength_class: string (Weak/Emerging/Strong/Exceptional)
    → team_confidence: float 0-100
    → team_analysis_complete: boolean


nodes/market_opportunity_node.py
───────────────────

Function: market_opportunity_node(state: StartupViabilityState, client = None) → dictionary
  Parameters:
    → state: StartupViabilityState: Current pipeline state
    → client = None: Gemini LLM client instance (required)
  Logic:
    1. Extract parsed_startup from state
    2. Add financial_viability_score to startup_data
    3. Add team_strength_score to startup_data
    4. Instantiate MarketOpportunityAssessorLLMAgent with client
    5. Call agent.assess_market_opportunity(startup_data)
    6. LLM analyzes market opportunity and returns structured JSON
    7. Extract market_opportunity_score from results
    8. Map all returned fields to state
    9. Set market_analysis_complete to True
    10. Return state updates
  Returns: dictionary with keys:
    → market_opportunity_assessment: string
    → market_opportunity_score: float
    → tam_validation: dictionary (realistic_range, confidence, justification)
    → competitive_landscape: dictionary (competitors, positioning, advantages)
    → market_trends: list of strings
    → market_risks: list of strings
    → market_opportunities: list of strings
    → market_analysis_complete: boolean


nodes/pitch_quality_node.py
───────────────────

Function: pitch_quality_node(state: StartupViabilityState, client = None) → dictionary
  Parameters:
    → state: StartupViabilityState: Current pipeline state
    → client = None: Gemini LLM client instance (required)
  Logic:
    1. Extract parsed_startup from state
    2. Instantiate PitchQualityAnalyzerLLMAgent with client
    3. Call agent.analyze_pitch_quality(startup_data)
    4. LLM evaluates pitch quality and returns structured JSON
    5. Extract pitch_quality_score from results
    6. Map all returned fields to state
    7. Set pitch_analysis_complete to True
    8. Return state updates
  Returns: dictionary with keys:
    → pitch_quality_score: float 0-100
    → pitch_clarity_assessment: string
    → pitch_strengths: list of dicts {strength, impact_level}
    → pitch_weaknesses: list of dicts {weakness, impact_level}
    → pitch_recommendations: list of dicts {issue, recommendation}
    → narrative_coherence_score: float
    → investor_ready_assessment: string
    → elevator_pitch_suggestions: list of strings
    → pitch_analysis_complete: boolean


nodes/risk_evaluator_node.py
───────────────────

Function: risk_evaluator_node(state: StartupViabilityState, client = None) → dictionary
  Parameters:
    → state: StartupViabilityState: Current pipeline state
    → client = None: Gemini LLM client instance (required)
  Logic:
    1. Extract parsed_startup from state
    2. Add financial_viability_score to startup_data
    3. Add team_strength_score to startup_data
    4. Add market_opportunity_score to startup_data
    5. Instantiate RiskEvaluatorLLMAgent with client
    6. Call agent.evaluate_risks(startup_data)
    7. LLM assesses multi-dimensional risks and returns structured JSON
    8. Extract overall_risk_rating from results
    9. Map all returned fields to state
    10. Set risk_analysis_complete to True
    11. Return state updates
  Returns: dictionary with keys:
    → overall_risk_rating: string (Critical/High/Medium/Low)
    → risk_dimensions: dict with 7 risk categories
      • execution_risk: {score, assessment}
      • market_risk: {score, assessment}
      • financial_risk: {score, assessment}
      • team_risk: {score, assessment}
      • regulatory_risk: {score, assessment}
      • technology_risk: {score, assessment}
      • competitive_risk: {score, assessment}
    → critical_risk_areas: list of strings
    → risk_mitigation_strategies: dict {risk: [strategies]}
    → risk_management_priorities: list of dicts {rank, risk, priority}
    → risk_analysis_complete: boolean


nodes/funding_recommender_node.py
───────────────────

Function: funding_recommender_node(state: StartupViabilityState, client = None) → dictionary
  Parameters:
    → state: StartupViabilityState: Current pipeline state
    → client = None: Gemini LLM client instance (required)
  Logic:
    1. Extract parsed_startup from state
    2. Add all previous analysis scores to startup_data
    3. Add overall_risk_rating to startup_data
    4. Instantiate FundingRecommenderLLMAgent with client
    5. Call agent.generate_funding_recommendations(startup_data)
    6. LLM provides funding strategy and returns structured JSON
    7. Extract funding_readiness_score from results
    8. Map all returned fields to state
    9. Set recommendations_complete to True
    10. Return state updates
  Returns: dictionary with keys:
    → funding_readiness_score: float 0-100
    → recommended_funding_round: string (Seed/Series A/B/C)
    → funding_readiness_assessment: string
    → funding_timeline: dict {realistic_months, phase_breakdown}
    → valuation_guidance: dict {estimated_range, methodology, confidence}
    → investor_targeting_strategy: dict {investor_types, check_size, geographic_focus}
    → pitch_improvements_for_investors: list of dicts
    → alternative_funding_options: list of dicts {option, pros, cons}
    → go_market_timeline: string
    → key_milestones_for_funding: list of strings
    → red_flags_to_address: list of strings
    → recommendations_complete: boolean


ml/train_pipeline.py
───────────────────

Function: run_training_pipeline(data_dir: string = "data", processed_dir: string = "data/processed", model_dir: string = "ml/models") → dictionary
  Parameters:
    → data_dir: string = "data": Root data directory path
    → processed_dir: string = "data/processed": Cleaned data output directory
    → model_dir: string = "ml/models": Model save directory
  Logic:
    1. Load financial_viability_training.csv from data_dir/training_dataset
    2. Load team_competitiveness_training.csv from data_dir/training_dataset
    3. Call clean_financial_data with financial training data
    4. Call clean_team_data with team training data
    5. Call train_financial_viability_model with cleaned financial data
    6. Call train_team_competitiveness_model with cleaned team data
    7. Call evaluate_all_models with trained models
    8. Aggregate results from all steps
    9. Return comprehensive results dictionary
  Returns: dictionary with keys:
    → financial_cleaning: dict with cleaning statistics
    → team_cleaning: dict with cleaning statistics
    → financial_training: dict with model metrics
    → team_training: dict with model metrics
    → evaluation: dict with evaluation results
    → error: string (if any step failed)


ml/train_model/train_financial_viability.py
───────────────────

Function: train_financial_viability_model(df: pandas.DataFrame, model_save_dir: string = "ml/models", test_size: float = 0.2, random_state: integer = 42) → dictionary
  Parameters:
    → df: pandas.DataFrame: Cleaned training data
    → model_save_dir: string = "ml/models": Directory to save model
    → test_size: float = 0.2: Test set proportion (20%)
    → random_state: integer = 42: Random seed for reproducibility
  Logic:
    1. Extract 11 feature columns from dataframe
    2. Extract target column (Financial_Viability_Class)
    3. Fill missing values in features with 0
    4. Encode target labels to integers (High Risk=0, Medium Risk=1, Viable=2, Strong=3)
    5. Split data: 80% training, 20% testing
    6. Initialize StandardScaler
    7. Fit scaler on training features
    8. Transform both training and testing features
    9. Create RandomForestClassifier with 100 estimators, max_depth=10
    10. Train model on scaled training data
    11. Make predictions on training set
    12. Make predictions on testing set
    13. Calculate metrics: accuracy, precision, recall, F1-score, overfitting_gap
    14. Save model to model_save_dir/financial_viability_model.pkl
    15. Save scaler to model_save_dir/financial_viability_scaler.pkl
    16. Save encoder to model_save_dir/financial_viability_label_encoder.pkl
    17. Calculate feature importance
    18. Return comprehensive metrics dictionary
  Returns: dictionary with keys:
    → train_accuracy: float
    → test_accuracy: float
    → test_precision: float
    → test_recall: float
    → test_f1: float
    → overfitting_gap: float
    → feature_importance: dict {feature_name: importance}


ml/train_model/train_team_competitiveness.py
───────────────────

Function: train_team_competitiveness_model(df: pandas.DataFrame, model_save_dir: string = "ml/models", test_size: float = 0.2, random_state: integer = 42) → dictionary
  Parameters:
    → df: pandas.DataFrame: Cleaned training data
    → model_save_dir: string = "ml/models": Directory to save model
    → test_size: float = 0.2: Test set proportion
    → random_state: integer = 42: Random seed
  Logic:
    1. Extract 11 feature columns from dataframe (CEO experience, education, team size, etc.)
    2. Extract target column (Team_Strength_Class)
    3. Fill missing values with 0
    4. Encode target labels (Weak=0, Emerging=1, Strong=2, Exceptional=3)
    5. Split data: 80% training, 20% testing
    6. Initialize StandardScaler
    7. Fit scaler on training features
    8. Transform both sets
    9. Create RandomForestClassifier with 100 estimators, max_depth=10
    10. Train on scaled training data
    11. Predict on both sets
    12. Calculate metrics (accuracy, precision, recall, F1, gap)
    13. Save model, scaler, encoder
    14. Calculate feature importance
    15. Return metrics dictionary
  Returns: dictionary with keys:
    → train_accuracy: float
    → test_accuracy: float
    → test_precision: float
    → test_recall: float
    → test_f1: float
    → overfitting_gap: float
    → feature_importance: dict


ml/data_cleaning/clean_financial_data.py
───────────────────

Function: clean_financial_data(df: pandas.DataFrame, save_processed: boolean = False, output_dir: string = "data/processed") → tuple(pandas.DataFrame, dictionary)
  Parameters:
    → df: pandas.DataFrame: Raw financial training data
    → save_processed: boolean = FALSE: Whether to save cleaned data
    → output_dir: string = "data/processed": Output directory for cleaned data
  Logic:
    1. Drop duplicate rows
    2. For numeric columns (9 total):
      • Convert to float
      • Fill NaN with column median
    3. For categorical columns (2 total):
      • Fill NaN with column mode
      • Encode Business_Stage: Pre-Revenue=0, Early=1, Growth=2, Scale=3
      • Encode Funding_Round: Bootstrapped=0, Pre-Seed=1, Seed=2, Series A=3, Series B=4, Series C+=5
    4. Remove outliers using IQR method:
      • Calculate Q1 (25th percentile) and Q3 (75th percentile)
      • Calculate IQR = Q3 - Q1
      • Remove rows where value < Q1 - 3*IQR or value > Q3 + 3*IQR
    5. Filter rows: keep only valid target classes (High Risk, Medium Risk, Viable, Strong)
    6. If save_processed: save cleaned dataframe to output_dir/financial_viability_cleaned.csv
    7. Return cleaned dataframe and statistics
  Returns: tuple of:
    → pandas.DataFrame (cleaned data)
    → dictionary with keys:
      • original_rows: count before cleaning
      • cleaned_rows: count after cleaning
      • duplicates_removed: count of duplicate rows
      • rows_removed_pct: percentage removed
      • output_path: path if saved


ml/data_cleaning/clean_team_data.py
───────────────────

Function: clean_team_data(df: pandas.DataFrame, save_processed: boolean = FALSE, output_dir: string = "data/processed") → tuple(pandas.DataFrame, dictionary)
  Parameters:
    → df: pandas.DataFrame: Raw team training data
    → save_processed: boolean = FALSE: Whether to save cleaned data
    → output_dir: string = "data/processed": Output directory
  Logic:
    1. Drop duplicate rows
    2. For numeric columns (9 total):
      • Convert to float
      • Fill NaN with median
    3. For categorical columns (3 total):
      • Fill NaN with mode
      • Encode CEO_Education_Level: High School=1, Bachelor=2, Master=3, PhD=4
      • Encode CEO_Has_Previous_Exit: Yes=1, No=0
    4. Remove outliers using IQR method with 3x multiplier
    5. Filter rows: keep only valid target classes (Weak, Emerging, Strong, Exceptional)
    6. If save_processed: save to output_dir/team_competitiveness_cleaned.csv
    7. Return cleaned data and statistics
  Returns: tuple of:
    → pandas.DataFrame (cleaned data)
    → dictionary with cleaning statistics


ml/evaluation/evaluate_models.py
───────────────────

Function: evaluate_financial_model(model_dir: string = "ml/models", eval_data_path: string = "data/evaluation_dataset/financial_viability_evaluation.csv") → dictionary
  Parameters:
    → model_dir: string = "ml/models": Path to saved model files
    → eval_data_path: string: Path to evaluation CSV file
  Logic:
    1. Load financial_viability_model.pkl from model_dir
    2. Load financial_viability_scaler.pkl from model_dir
    3. Load financial_viability_label_encoder.pkl from model_dir
    4. Load evaluation CSV file
    5. Extract 11 feature columns (handle column name variations)
    6. Extract target column
    7. Encode categorical features (stage, round)
    8. Scale features using loaded scaler
    9. Make predictions on evaluation set
    10. Decode predicted labels
    11. Calculate accuracy, precision, recall, F1-score
    12. Return evaluation metrics
  Returns: dictionary with keys:
    → model: string "financial_viability"
    → accuracy: float
    → precision: float
    → recall: float
    → f1: float
    → samples: integer count
    → error: string (if failed)


Function: evaluate_team_model(model_dir: string = "ml/models", eval_data_path: string = "data/evaluation_dataset/team_competitiveness_evaluation.csv") → dictionary
  Parameters:
    → model_dir: string = "ml/models": Path to saved model files
    → eval_data_path: string: Path to evaluation CSV file
  Logic:
    1. Load team_competitiveness_model.pkl from model_dir
    2. Load team_competitiveness_scaler.pkl from model_dir
    3. Load team_competitiveness_label_encoder.pkl from model_dir
    4. Load evaluation CSV file
    5. Extract 11 feature columns
    6. Extract target column
    7. Map education levels and exit status
    8. Scale features using loaded scaler
    9. Make predictions
    10. Decode predicted labels
    11. Calculate accuracy, precision, recall, F1
    12. Return evaluation metrics
  Returns: dictionary with metrics


Function: evaluate_all_models(model_dir: string = "ml/models", eval_data_dir: string = "data/evaluation_dataset") → dictionary
  Parameters:
    → model_dir: string = "ml/models": Path to model directory
    → eval_data_dir: string = "data/evaluation_dataset": Path to evaluation data
  Logic:
    1. Call evaluate_financial_model with financial evaluation data path
    2. Call evaluate_team_model with team evaluation data path
    3. Add timestamp to results
    4. Return combined evaluation results
  Returns: dictionary with keys:
    → timestamp: ISO format datetime string
    → financial_evaluation: dict with financial model metrics
    → team_evaluation: dict with team model metrics


main.py (Streamlit Web Application)
───────────────────

Function: load_startup_files() → dictionary
  Parameters: None
  Logic:
    1. List all JSON files in data/input/ directory
    2. For each JSON file, parse startup_name from content
    3. Create mapping of startup_name → file_path
    4. Return dictionary
  Returns: dictionary {startup_name: file_path}


Function: load_startup(file_path) → dictionary
  Parameters:
    → file_path: Path to JSON file
  Logic:
    1. Open and read JSON file
    2. Parse JSON content
    3. Return parsed dictionary
  Returns: dictionary (startup data)


Function: render_header() → None
  Parameters: None
  Logic:
    1. Display page title in green
    2. Display subtitle
    3. Display divider line
  Returns: None


Function: render_sidebar() → Path
  Parameters: None
  Logic:
    1. Call load_startup_files to get startup list
    2. Create selectbox for startup selection
    3. Add "Run Model Evaluation" button
    4. Add about section with platform description
    5. Return selected startup file path
  Returns: Path (selected startup file path)


Function: render_startup_preview(startup_data: dictionary) → None
  Parameters:
    → startup_data: dictionary: Startup information
  Logic:
    1. Create expandable section
    2. Display startup name, industry, location, stage
    3. Display founding date
    4. Display funding information
  Returns: None


Function: render_overview_tab(result: dictionary) → None
  Parameters:
    → result: dictionary: Analysis result
  Logic:
    1. Display 4 key metric cards (financial, team, market, risk)
    2. Show funding recommendation section
    3. Display export buttons (JSON, CSV)
  Returns: None


Function: render_detailed_insights_tab(result: dictionary) → None
  Parameters:
    → result: dictionary: Analysis result
  Logic:
    1. Create expandable section for Financial Analysis
    2. Create expandable section for Team Assessment
    3. Create expandable section for Market Opportunity
    4. Create expandable section for Pitch Quality
    5. Create expandable section for Risk Assessment (with 7 dimensions)
    6. Create expandable section for Funding Strategy
  Returns: None


Function: render_model_evaluation_section(eval_results: dictionary) → None
  Parameters:
    → eval_results: dictionary: Model evaluation metrics
  Logic:
    1. Display financial model metrics (accuracy, precision, recall, F1)
    2. Display team model metrics (same metrics)
    3. Show raw JSON evaluation data in expander
  Returns: None


Function: main() → None
  Parameters: None
  Logic:
    1. Initialize session state variables (analysis_results, eval_results, flags)
    2. Call render_header to display title
    3. Call render_sidebar to get startup selection
    4. Load selected startup JSON
    5. Call render_startup_preview to show selected startup
    6. Create "Run Startup Analysis" button
    7. If button clicked:
       • Build Gemini LLM client
       • Call analyze_startup from graph.py
       • Store result in session state
    8. Create tabs: Overview, Detailed Insights
    9. If Overview tab active: call render_overview_tab
    10. If Detailed Insights tab active: call render_detailed_insights_tab
    11. If eval button clicked: call evaluate_all_models from ml/evaluation
    12. If eval results available: call render_model_evaluation_section
  Returns: None


UI DESIGN OVERVIEW
=================================================================

Page Layout:
───────────────────
Streamlit Wide Layout with Expanded Sidebar

Header Section:
→ Title: "VentureLens" (green styling, large font)
→ Subtitle: "Startup Viability & Funding Success Analysis"
→ Divider line

Sidebar:
→ Startup Selection: Dropdown with 30 startup options
→ Run Model Evaluation Button: Triggers model performance assessment
→ About Section: Platform description and features

Main Content Area:

Section 1: Startup Preview (Expandable)
→ Display selected startup basic info
→ Company name, industry, location, stage, founding date
→ Funding information

Section 2: Analysis Trigger
→ Large green "Run Startup Analysis" button
→ Full width button, primary styling

Section 3: Results Display (Tabs)

Tab 1: Overview
→ Key Metrics Section (4 cards):
  • Financial Viability Score (with class badge)
  • Team Strength Score (with class badge)
  • Market Opportunity Score
  • Overall Risk Rating
→ Funding Recommendation Section:
  • Recommended Funding Round
  • Funding Readiness Score
→ Export Section:
  • Download JSON Report button
  • Download CSV Report button

Tab 2: Detailed Insights
→ Financial Analysis (Expandable)
  • Score, Class, Confidence
  • Key metrics summary

→ Team Assessment (Expandable)
  • Score, Class, Confidence
  • Team composition summary

→ Market Opportunity (Expandable)
  • Market assessment text
  • TAM validation
  • Competitive landscape
  • Market trends
  • Growth potential

→ Pitch Quality (Expandable)
  • Pitch score and clarity
  • Strengths and weaknesses
  • Recommendations
  • Investor readiness

→ Risk Assessment (Expandable)
  • Overall risk rating
  • 7 Risk dimensions with scores
  • Critical risk areas
  • Mitigation strategies
  • Priority actions

→ Funding Strategy (Expandable)
  • Funding readiness score
  • Recommended round and timeline
  • Valuation guidance
  • Investor strategy
  • Key milestones
  • Red flags

Section 4: Model Evaluation (Optional)
→ Financial Model Metrics:
  • Accuracy, Precision, Recall, F1
  • Sample count
→ Team Model Metrics:
  • Same metrics as financial

Color Scheme:
→ Primary: Green (#2e7d32)
→ Scores: Color-coded by performance level
→ Background: Light gray
→ Text: Dark gray/black


EXECUTION WORKFLOW - FROM START TO FINISH
=================================================================

STEP 1: DATA PREPARATION & CLEANING
───────────────────────────────────
Command to clean financial data:
  python -c "from ml.data_cleaning.clean_financial_data import clean_financial_data; import pandas as pd; df = pd.read_csv('data/training_dataset/financial_viability_training.csv'); clean_financial_data(df, save_processed=True)"

Command to clean team data:
  python -c "from ml.data_cleaning.clean_team_data import clean_team_data; import pandas as pd; df = pd.read_csv('data/training_dataset/team_competitiveness_training.csv'); clean_team_data(df, save_processed=True)"

Expected Output:
→ data/processed/financial_viability_cleaned.csv (cleaned financial data)
→ data/processed/team_competitiveness_cleaned.csv (cleaned team data)
→ Console output showing rows removed and cleaning statistics


STEP 2: MODEL TRAINING
───────────────────────────────────
Command to train ML models:
  python -c "from ml.train_pipeline import run_training_pipeline; result = run_training_pipeline(); print(result)"

Alternative direct command:
  python ml/train_pipeline.py

Expected Output:
→ ml/models/financial_viability_model.pkl (trained RandomForest model)
→ ml/models/financial_viability_scaler.pkl (feature scaler)
→ ml/models/financial_viability_label_encoder.pkl (class encoder)
→ ml/models/team_competitiveness_model.pkl (trained RandomForest model)
→ ml/models/team_competitiveness_scaler.pkl (feature scaler)
→ ml/models/team_competitiveness_label_encoder.pkl (class encoder)
→ Console output:
  • Training statistics
  • Model metrics (accuracy, precision, recall, F1)
  • Overfitting gap
  • Feature importance


STEP 3: MODEL EVALUATION
───────────────────────────────────
Command to evaluate models:
  python -c "from ml.evaluation.evaluate_models import evaluate_all_models; result = evaluate_all_models(); print(result)"

Expected Output:
→ Console output with evaluation metrics:
  • Financial model: accuracy, precision, recall, F1, sample count
  • Team model: accuracy, precision, recall, F1, sample count


STEP 4: RUN STREAMLIT UI
───────────────────────────────────
Command to start web application:
  streamlit run main.py

Expected Output:
→ Browser opens to localhost:8501
→ Streamlit UI displayed with:
  • Header: "VentureLens" title
  • Sidebar: Startup selector dropdown
  • Main content: Startup preview section
  • "Run Startup Analysis" button


STEP 5: STARTUP ANALYSIS WORKFLOW
───────────────────────────────────
User Action: Select startup from dropdown and click "Run Startup Analysis"

Internal Workflow:
→ Load startup JSON from data/input/PROP-X.json
→ Initialize StartupViabilityState with 93 fields
→ Invoke LangGraph 7-node pipeline:
  1. form_parser_node: Validate input (output: parsing_complete flag)
  2. financial_analyzer_node: ML prediction (output: score, class, confidence)
  3. team_assessor_node: ML prediction (output: score, class, confidence)
  4. market_opportunity_node: LLM analysis (output: assessment, TAM, competitors, trends)
  5. pitch_quality_node: LLM evaluation (output: score, clarity, strengths, weaknesses)
  6. risk_evaluator_node: LLM assessment (output: rating, 7 dimensions, mitigation)
  7. funding_recommender_node: LLM strategy (output: round, readiness, valuation, milestones)
→ Aggregate results into final state dictionary

Expected Processing Time:
→ Form parsing: <1 second
→ ML analysis (parallel): ~2-3 seconds
→ LLM analysis (sequential): ~12-20 seconds
→ Total: ~15-25 seconds per analysis


STEP 6: RESULTS DISPLAY
───────────────────────────────────
UI displays results in two tabs:

Overview Tab Shows:
→ Financial Viability Score: 0-100 with class badge
→ Team Strength Score: 0-100 with class badge
→ Market Opportunity Score: 0-100
→ Overall Risk Rating: Critical/High/Medium/Low
→ Recommended Funding Round: Seed/Series A/B/C/etc
→ Funding Readiness Score: 0-100
→ Export buttons (JSON, CSV)

Detailed Insights Tab Shows:
→ Financial Analysis details
→ Team Assessment details
→ Market Opportunity details
→ Pitch Quality details
→ Risk Assessment with 7 dimensions
→ Funding Strategy details

Export Options:
→ JSON: Download complete 93-field analysis
→ CSV: Download flattened results for spreadsheet


STEP 7: MODEL EVALUATION (OPTIONAL)
───────────────────────────────────
User Action: Click "Run Model Evaluation" button in sidebar

Process:
→ Load financial_viability_model.pkl and evaluation data
→ Load team_competitiveness_model.pkl and evaluation data
→ Run predictions on evaluation dataset
→ Calculate metrics for both models
→ Display results in UI section

Expected Output:
→ Financial Model Metrics:
  • Accuracy: ~0.85-0.95
  • Precision: ~0.85-0.95
  • Recall: ~0.85-0.95
  • F1: ~0.85-0.95
  • Samples evaluated: count

→ Team Model Metrics:
  • Same metrics as financial model

Alternative Command Line:
  python -c "from ml.evaluation.evaluate_models import evaluate_all_models; print(evaluate_all_models())"


COMPLETE ENTRY POINT SUMMARY
=================================================================

For Data Scientists:
→ Training: python ml/train_pipeline.py
→ Evaluation: python -c "from ml.evaluation.evaluate_models import evaluate_all_models; evaluate_all_models()"

For Analysts:
→ Run UI: streamlit run main.py
→ Select startup
→ Click "Run Startup Analysis"
→ View results in Overview/Detailed tabs

For Developers:
→ Direct API usage:
  from graph import analyze_startup
  from utils.gemini_client import build_gemini_client
  result = analyze_startup(startup_data, build_gemini_client())

For Testing:
→ Run tests: python -m pytest tests.py -v
→ Test coverage: 24 test cases


EXPECTED OUTPUT - COMPLETE ANALYSIS RESULT
=================================================================

Output Structure: Dictionary with 93+ fields

SECTION 1: INPUT DATA (35 fields)
───────────────────
→ startup_name: "TechVenture AI"
→ industry: "SaaS"
→ location: "San Francisco, CA"
→ business_stage: "Growth"
→ mrr: 50000.0
→ arr: 600000.0
→ runway_months: 18.0
→ team_size: 15
→ ceo_experience_years: 12.0
... (30 more input fields)

SECTION 2: PROCESSING STATUS (10 fields)
───────────────────
→ parsing_complete: True
→ financial_analysis_complete: True
→ team_analysis_complete: True
→ market_analysis_complete: True
→ pitch_analysis_complete: True
→ risk_analysis_complete: True
→ recommendations_complete: True
→ error_occurred: False
→ error_messages: []

SECTION 3: FINANCIAL ANALYSIS (3 fields)
───────────────────
→ financial_viability_score: 78.5
→ financial_viability_class: "Viable"
→ financial_confidence: 85.2

SECTION 4: TEAM ASSESSMENT (3 fields)
───────────────────
→ team_strength_score: 82.1
→ team_strength_class: "Strong"
→ team_confidence: 88.5

SECTION 5: MARKET OPPORTUNITY (8 fields)
───────────────────
→ market_opportunity_score: 75.0
→ market_opportunity_assessment: "Strong market opportunity with growing demand in enterprise AI sector. TAM validates to $15-20B with 25% CAGR."
→ tam_validation: {
    "realistic_range": "$15B-$20B",
    "confidence": "High",
    "justification": "TAM based on enterprise spending on AI analytics"
  }
→ competitive_landscape: {
    "key_competitors": ["DataRobot", "H2O", "Palantir"],
    "competitive_positioning": "Differentiated through ease of use",
    "competitive_advantages": ["Faster implementation", "Better UX"],
    "competitive_threats": ["Well-funded competitors", "Integration complexity"]
  }
→ market_trends: ["AI adoption accelerating", "Enterprise shifting to cloud", "Need for real-time analytics"]
→ market_growth_potential: 75
→ market_timing: "optimal"
→ market_risks: ["Increasing competition", "Economic downturn risk", "Talent retention"]
→ market_opportunities: ["Expansion to adjacent verticals", "International expansion", "Strategic partnerships"]

SECTION 6: PITCH QUALITY (8 fields)
───────────────────
→ pitch_quality_score: 82.0
→ pitch_clarity_assessment: "Clear, compelling pitch with strong differentiation message"
→ pitch_strengths: [
    {"strength": "Strong value proposition", "impact_level": "High"},
    {"strength": "Clear competitive advantage", "impact_level": "High"},
    {"strength": "Experienced team highlighted", "impact_level": "Medium"}
  ]
→ pitch_weaknesses: [
    {"weakness": "Limited financial metrics shown", "impact_level": "Medium"},
    {"weakness": "Customer case studies missing", "impact_level": "Low"}
  ]
→ pitch_recommendations: [
    {"issue": "Customer proof points", "recommendation": "Include 2-3 customer success stories"},
    {"issue": "Financial projections", "recommendation": "Add 3-year revenue and profitability projections"}
  ]
→ narrative_coherence_score: 85.0
→ investor_ready_assessment: "mostly_ready"
→ elevator_pitch_suggestions: ["Emphasize market timing", "Quantify TAM opportunity", "Lead with team experience"]

SECTION 7: RISK ASSESSMENT (5 fields)
───────────────────
→ overall_risk_rating: "Medium"
→ risk_dimensions: {
    "execution_risk": {
      "score": 65,
      "assessment": "Moderate execution risk. Strong team but aggressive growth targets."
    },
    "market_risk": {
      "score": 50,
      "assessment": "Market risks manageable. Large TAM but increasing competition."
    },
    "financial_risk": {
      "score": 70,
      "assessment": "Burn rate elevated. 18-month runway requires revenue acceleration."
    },
    "team_risk": {
      "score": 45,
      "assessment": "Strong team with relevant experience. Low retention risk."
    },
    "regulatory_risk": {
      "score": 30,
      "assessment": "Low regulatory risk in current markets."
    },
    "technology_risk": {
      "score": 55,
      "assessment": "Proven technology stack. Some scalability concerns at current growth."
    },
    "competitive_risk": {
      "score": 60,
      "assessment": "Competitive landscape challenging. Multiple well-funded competitors."
    }
  }
→ critical_risk_areas: ["Burn rate management", "Market adoption rate", "Competitive differentiation"]
→ risk_mitigation_strategies: {
    "Burn rate management": ["Optimize go-to-market costs", "Accelerate enterprise sales cycle"],
    "Market adoption": ["Expand sales team", "Increase marketing investment"],
    "Competition": ["Strengthen product differentiation", "Build strategic partnerships"]
  }
→ risk_management_priorities: [
    {"rank": 1, "risk": "Burn rate", "priority": "Immediate"},
    {"rank": 2, "risk": "Revenue growth", "priority": "High"},
    {"rank": 3, "risk": "Competitive positioning", "priority": "High"}
  ]

SECTION 8: FUNDING RECOMMENDATIONS (11 fields)
───────────────────
→ funding_readiness_score: 78.5
→ recommended_funding_round: "Series A"
→ funding_readiness_assessment: "Ready for Series A. Strong team and market opportunity. Needs to demonstrate unit economics."
→ funding_timeline: {
    "realistic_months_to_funding": 3,
    "phase_breakdown": "Prepare materials (4 weeks), Pitch outreach (4 weeks), Due diligence (6 weeks)"
  }
→ valuation_guidance: {
    "estimated_range": "$50M-$75M",
    "methodology": "SaaS revenue multiple approach. 8-10x ARR given growth and market position",
    "confidence": "Medium"
  }
→ investor_targeting_strategy: {
    "investor_types": ["Growth VCs", "Enterprise software specialists", "Strategic investors"],
    "typical_check_size": "$10M-$25M",
    "geographic_focus": ["Silicon Valley", "New York", "Boston"],
    "sample_vcs": ["Sequoia", "Accel", "Bessemer"]
  }
→ pitch_improvements_for_investors: [
    {"focus_area": "Financial metrics", "improvement": "Show clear path to profitability"},
    {"focus_area": "Customer concentration", "improvement": "Reduce top 3 customer concentration below 30%"},
    {"focus_area": "Competitive moat", "improvement": "Deepen technical differentiation story"}
  ]
→ alternative_funding_options: [
    {
      "option": "Venture debt",
      "pros": ["No dilution", "Extends runway", "Builds credit history"],
      "cons": ["Must repay regardless of outcome", "Interest costs"]
    },
    {
      "option": "Strategic partnership",
      "pros": ["Market validation", "Revenue acceleration", "Potential exit opportunity"],
      "cons": ["Loss of control", "Dependency risk"]
    }
  ]
→ go_market_timeline: "18-24 months to market leadership position"
→ key_milestones_for_funding: [
    "Achieve $1M ARR (3 months)",
    "Add 5 enterprise customers (6 months)",
    "Expand team to 25 people (9 months)",
    "International expansion initiated (12 months)",
    "$3M ARR run rate (18 months)"
  ]
→ red_flags_to_address: [
    "High burn rate without clear path to profitability",
    "Concentration in single industry vertical",
    "Dependency on key technical founders",
    "Customer churn rate above 5% monthly"
  ]

ADDITIONAL OUTPUT FORMATS:

JSON Export Format:
→ All 93+ fields exported as JSON file
→ Filename: startup_name_analysis_timestamp.json
→ Download link in Overview tab

CSV Export Format:
→ Flattened rows with score values
→ One row per startup
→ Columns: startup_name, industry, financial_score, team_score, market_score, etc.
→ Filename: startup_analysis_export_timestamp.csv
→ Download link in Overview tab

Console/Log Output:
→ Processing status updates
→ Error messages (if any)
→ Processing time per stage
→ API call statistics


DATA QUALITY & VALIDATION
=================================================================

Input Validation Results:
→ All 17 required fields present: PASS
→ All field values within valid ranges: PASS
→ All enum fields match predefined values: PASS
→ No parsing errors: PASS

Model Prediction Confidence:
→ Financial model confidence: 85.2%
→ Team model confidence: 88.5%
→ Both above 80% confidence threshold: PASS

LLM Response Quality:
→ All required response fields present: PASS
→ No JSON parsing errors: PASS
→ Response completeness: 100%

Overall Analysis Status:
→ All 7 stages completed successfully
→ No errors encountered
→ Estimated accuracy: High (based on model confidence and LLM response quality)
