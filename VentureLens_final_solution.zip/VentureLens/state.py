#!/usr/bin/env python3
"""
StartupViabilityState - Central state management for 6-stage startup analysis pipeline
"""

from typing import TypedDict, List, Dict, Any, Optional
import re


class StartupViabilityState(TypedDict):
    startup_name: Optional[str]
    industry: Optional[str]
    founded_date: Optional[str]
    location: Optional[str]
    business_stage: Optional[str]
    current_funding_round: Optional[str]
    product_description: Optional[str]
    problem_addressed: Optional[str]
    target_market_size: Optional[float]
    tam_sam_som_assessment: Optional[str]
    key_features: Optional[List[str]]
    competitive_advantage: Optional[str]
    mrr: Optional[float]
    arr: Optional[float]
    runway_months: Optional[float]
    monthly_burn_rate: Optional[float]
    cac: Optional[float]
    ltv: Optional[float]
    customer_count: Optional[int]
    revenue_growth_rate: Optional[float]
    churn_rate: Optional[float]
    ceo_name: Optional[str]
    ceo_experience_years: Optional[float]
    ceo_has_previous_exit: Optional[bool]
    ceo_education_level: Optional[str]
    technical_cofounder_count: Optional[int]
    avg_tech_experience_years: Optional[float]
    team_size: Optional[int]
    non_technical_roles_filled: Optional[int]
    members_with_startup_experience: Optional[int]
    industry_domain_expertise_years: Optional[float]
    founder_diversity_score: Optional[float]
    team_tenure_together_years: Optional[float]
    total_raised_to_date: Optional[float]
    target_funding_amount: Optional[float]
    elevator_pitch: Optional[str]
    parsed_startup: Optional[Dict[str, Any]]
    validation_errors: List[str]
    parsing_complete: bool
    financial_viability_score: Optional[float]
    financial_viability_class: Optional[str]
    financial_confidence: Optional[float]
    financial_analysis_complete: bool
    team_strength_score: Optional[float]
    team_strength_class: Optional[str]
    team_confidence: Optional[float]
    team_analysis_complete: bool
    market_opportunity_assessment: Optional[str]
    market_opportunity_score: Optional[float]
    tam_validation: Optional[Dict[str, Any]]
    competitive_landscape: Optional[Dict[str, Any]]
    market_trends: Optional[List[str]]
    market_risks: Optional[List[str]]
    market_opportunities: Optional[List[str]]
    market_analysis_complete: bool
    pitch_quality_score: Optional[float]
    pitch_clarity_assessment: Optional[str]
    pitch_strengths: Optional[List[Dict[str, Any]]]
    pitch_weaknesses: Optional[List[Dict[str, Any]]]
    pitch_recommendations: Optional[List[Dict[str, Any]]]
    narrative_coherence_score: Optional[float]
    investor_ready_assessment: Optional[str]
    pitch_analysis_complete: bool
    overall_risk_rating: Optional[str]
    risk_dimensions: Optional[Dict[str, Any]]
    critical_risk_areas: Optional[List[str]]
    risk_mitigation_strategies: Optional[Dict[str, List[str]]]
    risk_management_priorities: Optional[List[Dict[str, Any]]]
    risk_analysis_complete: bool
    funding_readiness_score: Optional[float]
    recommended_funding_round: Optional[str]
    funding_readiness_assessment: Optional[str]
    funding_timeline: Optional[Dict[str, Any]]
    valuation_guidance: Optional[Dict[str, Any]]
    investor_targeting_strategy: Optional[Dict[str, Any]]
    pitch_improvements_for_investors: Optional[List[Dict[str, Any]]]
    alternative_funding_options: Optional[List[Dict[str, Any]]]
    key_milestones_for_funding: Optional[List[str]]
    red_flags_to_address: Optional[List[str]]
    recommendations_complete: bool
    error_occurred: bool
    error_messages: List[str]


def get_initial_state(form_data: Dict[str, Any]) -> StartupViabilityState:
    return StartupViabilityState(
        startup_name=form_data.get("startup_name"),
        industry=form_data.get("industry"),
        founded_date=form_data.get("founded_date"),
        location=form_data.get("location"),
        business_stage=form_data.get("business_stage"),
        current_funding_round=form_data.get("current_funding_round"),
        product_description=form_data.get("product_description"),
        problem_addressed=form_data.get("problem_addressed"),
        target_market_size=form_data.get("target_market_size"),
        tam_sam_som_assessment=form_data.get("tam_sam_som_assessment"),
        key_features=form_data.get("key_features", []),
        competitive_advantage=form_data.get("competitive_advantage"),
        mrr=form_data.get("mrr"),
        arr=form_data.get("arr"),
        runway_months=form_data.get("runway_months"),
        monthly_burn_rate=form_data.get("monthly_burn_rate"),
        cac=form_data.get("cac"),
        ltv=form_data.get("ltv"),
        customer_count=form_data.get("customer_count"),
        revenue_growth_rate=form_data.get("revenue_growth_rate"),
        churn_rate=form_data.get("churn_rate"),
        ceo_name=form_data.get("ceo_name"),
        ceo_experience_years=form_data.get("ceo_experience_years"),
        ceo_has_previous_exit=form_data.get("ceo_has_previous_exit"),
        ceo_education_level=form_data.get("ceo_education_level"),
        technical_cofounder_count=form_data.get("technical_cofounder_count"),
        avg_tech_experience_years=form_data.get("avg_tech_experience_years"),
        team_size=form_data.get("team_size"),
        non_technical_roles_filled=form_data.get("non_technical_roles_filled"),
        members_with_startup_experience=form_data.get("members_with_startup_experience"),
        industry_domain_expertise_years=form_data.get("industry_domain_expertise_years"),
        founder_diversity_score=form_data.get("founder_diversity_score"),
        team_tenure_together_years=form_data.get("team_tenure_together_years"),
        total_raised_to_date=form_data.get("total_raised_to_date"),
        target_funding_amount=form_data.get("target_funding_amount"),
        elevator_pitch=form_data.get("elevator_pitch"),
        parsed_startup=None,
        validation_errors=[],
        parsing_complete=False,
        financial_viability_score=None,
        financial_viability_class=None,
        financial_confidence=None,
        financial_analysis_complete=False,
        team_strength_score=None,
        team_strength_class=None,
        team_confidence=None,
        team_analysis_complete=False,
        market_opportunity_assessment=None,
        market_opportunity_score=None,
        tam_validation=None,
        competitive_landscape=None,
        market_trends=None,
        market_risks=None,
        market_opportunities=None,
        market_analysis_complete=False,
        pitch_quality_score=None,
        pitch_clarity_assessment=None,
        pitch_strengths=None,
        pitch_weaknesses=None,
        pitch_recommendations=None,
        narrative_coherence_score=None,
        investor_ready_assessment=None,
        pitch_analysis_complete=False,
        overall_risk_rating=None,
        risk_dimensions=None,
        critical_risk_areas=None,
        risk_mitigation_strategies=None,
        risk_management_priorities=None,
        risk_analysis_complete=False,
        funding_readiness_score=None,
        recommended_funding_round=None,
        funding_readiness_assessment=None,
        funding_timeline=None,
        valuation_guidance=None,
        investor_targeting_strategy=None,
        pitch_improvements_for_investors=None,
        alternative_funding_options=None,
        key_milestones_for_funding=None,
        red_flags_to_address=None,
        recommendations_complete=False,
        error_occurred=False,
        error_messages=[]
    )


def validate_state(state: StartupViabilityState) -> tuple[bool, List[str]]:
    errors = []

    if not state.get("startup_name"):
        errors.append("Startup name is required")
    if not state.get("industry"):
        errors.append("Industry is required")
    if not state.get("product_description"):
        errors.append("Product description is required")
    if not state.get("problem_addressed"):
        errors.append("Problem addressed is required")
    if state.get("team_size") and state["team_size"] < 1:
        errors.append("Team size must be at least 1")
    if state.get("ceo_experience_years") and state["ceo_experience_years"] < 0:
        errors.append("CEO experience cannot be negative")

    return (len(errors) == 0, errors)


def slugify(text: str) -> str:
    text = text.lower()
    text = re.sub(r'\s+', '_', text)
    text = re.sub(r'[^a-z0-9_]', '', text)
    text = text.strip('_')
    return text
