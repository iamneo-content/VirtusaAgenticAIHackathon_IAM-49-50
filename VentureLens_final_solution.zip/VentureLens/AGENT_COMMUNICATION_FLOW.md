# VentureLens Agent Communication Flow

```mermaid
graph TD
    Start([Startup Analysis Start]) --> FormParser[Form Parser Node<br/>Validates Input Data]

    FormParser -->|parsing_complete = True| ParallelCheck{Parse Successful?}
    FormParser -->|parsing_complete = False| ErrorState[Parsing Failed<br/>Return Errors]

    ParallelCheck -->|Yes| FinancialAgent["<b>FinancialAnalyzerMLAgent</b><br/>Instantiate & Analyze<br/>Financial Viability"]
    ParallelCheck -->|Yes| TeamAgent["<b>TeamAssessorMLAgent</b><br/>Instantiate & Assess<br/>Team Competitiveness"]
    ParallelCheck -->|No| ErrorState

    FinancialAgent -->|viability_score<br/>viability_class<br/>confidence| FinancialComplete[Financial Analysis<br/>Complete]
    TeamAgent -->|strength_score<br/>strength_class<br/>confidence| TeamComplete[Team Assessment<br/>Complete]

    FinancialComplete --> MergeScores["Merge Analysis Scores<br/>into State"]
    TeamComplete --> MergeScores

    MergeScores --> MarketAgent["<b>MarketOpportunityAssessorLLMAgent</b><br/>Instantiate with LLM Client<br/>Assess Market Opportunity<br/>(Uses: Financial + Team Scores)"]

    MarketAgent -->|market_opportunity_score<br/>tam_validation<br/>competitive_landscape<br/>market_trends| MarketComplete[Market Analysis<br/>Complete]

    MarketComplete --> PitchAgent["<b>PitchQualityAnalyzerLLMAgent</b><br/>Instantiate with LLM Client<br/>Analyze Pitch Quality<br/>(Uses: Previous Scores)"]

    PitchAgent -->|pitch_quality_score<br/>pitch_strengths<br/>pitch_weaknesses<br/>recommendations| PitchComplete[Pitch Analysis<br/>Complete]

    PitchComplete --> RiskAgent["<b>RiskEvaluatorLLMAgent</b><br/>Instantiate with LLM Client<br/>Evaluate Multi-Dimensional Risks<br/>(Uses: Financial + Team + Market)"]

    RiskAgent -->|overall_risk_rating<br/>risk_dimensions: 7 categories<br/>critical_risk_areas<br/>mitigation_strategies| RiskComplete[Risk Assessment<br/>Complete]

    RiskComplete --> FundingAgent["<b>FundingRecommenderLLMAgent</b><br/>Instantiate with LLM Client<br/>Generate Funding Strategy<br/>(Uses: ALL Previous Scores)"]

    FundingAgent -->|funding_readiness_score<br/>recommended_funding_round<br/>valuation_guidance<br/>investor_strategy<br/>key_milestones| FundingComplete[Funding Recommendations<br/>Complete]

    FundingComplete --> ValidateResults{All Analyses<br/>Successful?}

    ValidateResults -->|Yes| AggregateState[Aggregate All Results<br/>into Final State<br/>93+ Fields]
    ValidateResults -->|No| ErrorState

    AggregateState --> GenerateOutput["Generate Output:<br/>- Executive Summary<br/>- Detailed Insights<br/>- Export Formats"]

    ErrorState --> End([Analysis Complete<br/>with Errors])
    GenerateOutput --> End

    style Start fill:#e1f5ff,stroke:#01579b,stroke-width:2px
    style FormParser fill:#e3f2fd,stroke:#1565c0,stroke-width:2px

    style FinancialAgent fill:#f3e5f5,stroke:#6a1b9a,stroke-width:2px
    style TeamAgent fill:#f3e5f5,stroke:#6a1b9a,stroke-width:2px
    style FinancialComplete fill:#e1bee7,stroke:#4a148c,stroke-width:2px
    style TeamComplete fill:#e1bee7,stroke:#4a148c,stroke-width:2px

    style MarketAgent fill:#fff3e0,stroke:#e65100,stroke-width:2px
    style MarketComplete fill:#ffe0b2,stroke:#d84315,stroke-width:2px

    style PitchAgent fill:#fce4ec,stroke:#880e4f,stroke-width:2px
    style PitchComplete fill:#f8bbd0,stroke:#ad1457,stroke-width:2px

    style RiskAgent fill:#e8f5e9,stroke:#1b5e20,stroke-width:2px
    style RiskComplete fill:#c8e6c9,stroke:#2e7d32,stroke-width:2px

    style FundingAgent fill:#e0f2f1,stroke:#004d40,stroke-width:2px
    style FundingComplete fill:#b2dfdb,stroke:#00695c,stroke-width:2px

    style MergeScores fill:#f1f8e9,stroke:#558b2f,stroke-width:2px
    style AggregateState fill:#eceff1,stroke:#263238,stroke-width:2px
    style GenerateOutput fill:#eceff1,stroke:#263238,stroke-width:2px

    style ErrorState fill:#ffcdd2,stroke:#c62828,stroke-width:2px
    style End fill:#fce4ec,stroke:#880e4f,stroke-width:2px

    style ParallelCheck fill:#fff9c4,stroke:#f57f17,stroke-width:2px
    style ValidateResults fill:#fff9c4,stroke:#f57f17,stroke-width:2px
```

## Agent Communication Architecture

### Phase 1: Input Validation
- **Form Parser Node** validates 17 required input fields
- Creates normalized `parsed_startup` data structure
- Establishes baseline state with 93 fields

### Phase 2: Parallel ML Analysis (Concurrent Execution)
- **FinancialAnalyzerMLAgent**
  - Instantiated with model_dir="ml/models"
  - Predicts financial viability using RandomForest
  - Returns: viability_score, viability_class, confidence

- **TeamAssessorMLAgent**
  - Instantiated with model_dir="ml/models"
  - Predicts team competitiveness using RandomForest
  - Returns: strength_score, strength_class, confidence

### Phase 3: Sequential LLM-Based Analysis (State Threading)

1. **MarketOpportunityAssessorLLMAgent**
   - Input: parsed_startup + financial_score + team_score
   - Output: market opportunity assessment with TAM validation, competitive landscape, market trends

2. **PitchQualityAnalyzerLLMAgent**
   - Input: parsed_startup + all previous scores
   - Output: pitch quality score, strengths, weaknesses, investor readiness

3. **RiskEvaluatorLLMAgent**
   - Input: parsed_startup + financial + team + market scores
   - Output: overall_risk_rating, 7 risk dimensions, critical areas, mitigation strategies

4. **FundingRecommenderLLMAgent**
   - Input: parsed_startup + ALL previous analysis scores + risk rating
   - Output: funding readiness, recommended round, valuation guidance, investor strategy, milestones

### Phase 4: Results Aggregation & Output
- All results merged into final state (93+ fields)
- Executive summary extraction
- Multi-format export (JSON, CSV)

### Data Flow Characteristics

**State Threading**: Each node receives the complete state, processes it, and returns updates that are merged into the state for the next node.

**Score Propagation**: Each ML/LLM agent's output scores feed into subsequent agents' analysis:
```
Financial Score ─┐
                 ├─→ Market Analysis
Team Score ──────┘
                 ├─→ Risk Analysis
Market Score ────┤
                 ├─→ Funding Strategy
Pitch Score ─────┤
Risk Rating ─────┘
```

### Error Handling
- Each agent wrapped in try-catch block
- Graceful degradation on API failures
- All errors collected in state for user feedback

### Agent Classes Summary

| Agent | Type | Model | Input Features | Output Fields |
|-------|------|-------|---|---|
| FinancialAnalyzerMLAgent | ML | RandomForest | 11 financial metrics | 4 (score, class, confidence, probabilities) |
| TeamAssessorMLAgent | ML | RandomForest | 11 team metrics | 4 (score, class, confidence, probabilities) |
| MarketOpportunityAssessorLLMAgent | LLM | Gemini 2.0 Flash | Product, market, TAM data | 8 (assessment, validation, landscape, trends, etc.) |
| PitchQualityAnalyzerLLMAgent | LLM | Gemini 2.0 Flash | Elevator pitch, product, problem | 8 (quality_score, clarity, strengths, weaknesses, etc.) |
| RiskEvaluatorLLMAgent | LLM | Gemini 2.0 Flash | All financial/team/market data | 5 (overall_rating, 7 dimensions, critical_areas, strategies, priorities) |
| FundingRecommenderLLMAgent | LLM | Gemini 2.0 Flash | All analysis scores + risk | 11 (readiness, round, valuation, strategy, milestones, red_flags) |

