#!/usr/bin/env python3
"""
Workflow orchestration - High-level functions for startup viability analysis
"""

import json
import logging
from typing import Dict, Any
from state import get_initial_state
from workflow.workflow import build_workflow

logger = logging.getLogger(__name__)


def analyze_startup(form_data: Dict[str, Any], llm_client=None) -> Dict[str, Any]:
    try:
        initial_state = get_initial_state(form_data)
        workflow = build_workflow(llm_client)
        result = workflow.invoke(initial_state)
        return result
    except Exception as e:
        logger.error(f"Startup analysis failed: {str(e)}")
        raise


def get_startup_summary(result: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "startup_name": result.get("startup_name"),
        "industry": result.get("industry"),
        "location": result.get("location"),
        "business_stage": result.get("business_stage"),
        "viability_score": result.get("financial_viability_score"),
        "viability_class": result.get("financial_viability_class"),
        "team_score": result.get("team_strength_score"),
        "team_class": result.get("team_strength_class"),
        "market_score": result.get("market_opportunity_score"),
        "overall_risk": result.get("overall_risk_rating"),
        "recommended_round": result.get("recommended_funding_round"),
        "funding_readiness": result.get("funding_readiness_score"),
        "key_recommendations": result.get("pitch_improvements_for_investors", []),
        "critical_risks": result.get("critical_risk_areas", []),
        "next_steps": result.get("key_milestones_for_funding", [])
    }
