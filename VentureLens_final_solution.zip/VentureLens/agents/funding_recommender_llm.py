#!/usr/bin/env python3
"""
Funding Recommender - LLM Agent for strategic funding recommendations
"""

import json
import logging
from typing import Dict, Any

logger = logging.getLogger(__name__)


class FundingRecommenderLLMAgent:
    def __init__(self, client):
        if client is None:
            raise ValueError("LLM client is required for funding recommendations")
        self.client = client

    def generate_funding_recommendations(self, startup_data: Dict[str, Any]) -> Dict[str, Any]:
        prompt = f"""Recommend funding strategy:
Stage: {startup_data.get('business_stage', 'N/A')}, Round: {startup_data.get('current_funding_round', 'N/A')}
Raised: ${startup_data.get('total_raised_to_date', 0)}, Target: ${startup_data.get('target_funding_amount', 0)}
Metrics: MRR ${startup_data.get('mrr', 0)}, Growth {startup_data.get('revenue_growth_rate', 0)}%, Runway {startup_data.get('runway_months', 0)}m
Scores: Fin {startup_data.get('financial_viability_score', 0)}, Team {startup_data.get('team_strength_score', 0)}, Market {startup_data.get('market_opportunity_score', 0)}, Pitch {startup_data.get('pitch_quality_score', 0)}
Risk: {startup_data.get('overall_risk_rating', 'N/A')}

Return JSON:
{{
    "funding_readiness_score": 75,
    "recommended_next_round": "Seed/Series A/Series B",
    "funding_readiness_assessment": "Assessment text",
    "funding_timeline": {{"realistic_months_to_funding": 6, "phase_breakdown": "Timeline"}},
    "valuation_guidance": {{"estimated_range": "$10M-$15M", "methodology": "Method", "confidence": "High/Med/Low"}},
    "investor_targeting_strategy": {{"investor_types": ["T1"], "typical_check_size": "$500K-$2M", "geographic_focus": ["Region"], "sample_vcs": ["VC1"]}},
    "pitch_improvements_for_investors": [{{"focus_area": "Area", "improvement": "Improve X"}}],
    "alternative_funding_options": [{{"option": "O1", "pros": ["P1"], "cons": ["C1"]}}],
    "key_milestones_for_funding": ["M1", "M2"],
    "red_flags_to_address": ["Flag1"]
}}
Return only a valid JSON object with the exact fields above, using double quotes and no trailing commas."""

        required_fields = [
            "funding_readiness_score",
            "recommended_next_round",
            "funding_readiness_assessment",
            "funding_timeline",
            "valuation_guidance",
            "investor_targeting_strategy",
            "pitch_improvements_for_investors",
            "alternative_funding_options",
            "key_milestones_for_funding",
            "red_flags_to_address",
        ]
        return self.client.generate_structured_json(prompt, required_fields)
