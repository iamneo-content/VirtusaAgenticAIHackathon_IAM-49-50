#!/usr/bin/env python3
"""
Pitch Quality Analyzer - LLM Agent for evaluating pitch effectiveness
"""

import json
import logging
from typing import Dict, Any

logger = logging.getLogger(__name__)


class PitchQualityAnalyzerLLMAgent:
    def __init__(self, client):
        if client is None:
            raise ValueError("LLM client is required for pitch quality analysis")
        self.client = client

    def analyze_pitch_quality(self, startup_data: Dict[str, Any]) -> Dict[str, Any]:
        prompt = f"""Evaluate pitch quality:
Pitch: {startup_data.get('elevator_pitch', 'N/A')}
Product: {startup_data.get('product_description', 'N/A')}
Problem: {startup_data.get('problem_addressed', 'N/A')}

Return JSON:
{{
    "pitch_quality_score": 75,
    "pitch_clarity_assessment": "Clarity assessment",
    "pitch_strengths": [{{"strength": "S1", "impact_level": "High/Med/Low"}}],
    "pitch_weaknesses": [{{"weakness": "W1", "impact_level": "High/Med/Low"}}],
    "pitch_recommendations": [{{"issue": "I1", "recommendation": "Improve X"}}],
    "narrative_coherence_score": 80,
    "investor_ready_assessment": "needs_work/mostly_ready/investor_ready"
}}
Return only a JSON object with these exact fields, using double quotes and no trailing commas."""

        required_fields = [
            "pitch_quality_score",
            "pitch_clarity_assessment",
            "pitch_strengths",
            "pitch_weaknesses",
            "pitch_recommendations",
            "narrative_coherence_score",
            "investor_ready_assessment",
        ]
        return self.client.generate_structured_json(prompt, required_fields)
