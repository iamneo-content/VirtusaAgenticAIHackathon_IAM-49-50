#!/usr/bin/env python3
"""
Team Competitiveness Assessor - ML Agent for team capability prediction
"""

import pickle
import logging
from typing import Dict, Any
import numpy as np
from pathlib import Path

logger = logging.getLogger(__name__)

CLASS_NAMES = ["Weak", "Emerging", "Strong", "Exceptional"]
EDUCATION_MAP = {"High School": 1, "Bachelor's": 2, "Master's": 3, "PhD": 4}


class TeamAssessorMLAgent:
    def __init__(self, model_dir: str = "ml/models"):
        self.model_dir = model_dir
        self.model = None
        self.scaler = None
        self._load_model()

    def _load_model(self) -> None:
        model_path = Path(self.model_dir) / "team_competitiveness_model.pkl"
        scaler_path = Path(self.model_dir) / "team_competitiveness_scaler.pkl"

        if not model_path.exists() or not scaler_path.exists():
            raise ValueError(f"Model files not found in {self.model_dir}")

        with open(model_path, "rb") as f:
            self.model = pickle.load(f)
        with open(scaler_path, "rb") as f:
            self.scaler = pickle.load(f)

    def assess_team_competitiveness(self, startup_data: Dict[str, Any]) -> Dict[str, Any]:
        try:
            education_level = EDUCATION_MAP.get(startup_data.get("ceo_education_level", "Bachelor's"), 2)
            has_exit = 1 if startup_data.get("ceo_has_previous_exit") else 0

            features = [
                startup_data.get("ceo_experience_years", 0) or 0,
                has_exit,
                education_level,
                startup_data.get("technical_cofounder_count", 0) or 0,
                startup_data.get("avg_tech_experience_years", 0) or 0,
                startup_data.get("team_size", 1) or 1,
                startup_data.get("non_technical_roles_filled", 0) or 0,
                startup_data.get("members_with_startup_experience", 0) or 0,
                startup_data.get("industry_domain_expertise_years", 0) or 0,
                startup_data.get("founder_diversity_score", 50) or 50,
                startup_data.get("team_tenure_together_years", 1) or 1
            ]

            features_array = np.array(features).reshape(1, -1)
            features_scaled = self.scaler.transform(features_array)

            prediction = self.model.predict(features_scaled)[0]
            probabilities = self.model.predict_proba(features_scaled)[0]

            team_class = CLASS_NAMES[int(prediction)]
            confidence = float(np.max(probabilities)) * 100
            team_score = float(np.max(probabilities)) * 100

            return {
                "strength_score": team_score,
                "strength_class": team_class,
                "confidence": confidence,
                "probabilities": {CLASS_NAMES[i]: float(probabilities[i]) for i in range(len(CLASS_NAMES))}
            }

        except Exception as e:
            logger.error(f"Team assessment failed: {str(e)}")
            raise ValueError(f"Team competitiveness analysis error: {str(e)}")
