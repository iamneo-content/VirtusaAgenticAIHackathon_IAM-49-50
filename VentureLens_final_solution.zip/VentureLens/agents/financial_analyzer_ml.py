#!/usr/bin/env python3
"""
Financial Viability Analyzer - ML Agent for startup financial health prediction
"""

import pickle
import logging
from typing import Dict, Any
import numpy as np
from pathlib import Path

logger = logging.getLogger(__name__)

CLASS_NAMES = ["High Risk", "Medium Risk", "Viable", "Strong"]
BUSINESS_STAGE_MAP = {"Pre-Revenue": 0, "Early": 1, "Growth": 2, "Scale": 3}
FUNDING_ROUND_MAP = {"Bootstrapped": 0, "Pre-Seed": 1, "Seed": 2, "Series A": 3, "Series B": 4, "Series C+": 5}


class FinancialAnalyzerMLAgent:
    def __init__(self, model_dir: str = "ml/models"):
        self.model_dir = model_dir
        self.model = None
        self.scaler = None
        self._load_model()

    def _load_model(self) -> None:
        model_path = Path(self.model_dir) / "financial_viability_model.pkl"
        scaler_path = Path(self.model_dir) / "financial_viability_scaler.pkl"

        if not model_path.exists() or not scaler_path.exists():
            raise ValueError(f"Model files not found in {self.model_dir}")

        with open(model_path, "rb") as f:
            self.model = pickle.load(f)
        with open(scaler_path, "rb") as f:
            self.scaler = pickle.load(f)

    def analyze_financial_viability(self, startup_data: Dict[str, Any]) -> Dict[str, Any]:
        try:
            features = [
                startup_data.get("mrr", 0) or 0,
                startup_data.get("arr", 0) or 0,
                startup_data.get("runway_months", 0) or 0,
                startup_data.get("monthly_burn_rate", 0) or 0,
                startup_data.get("cac", 0) or 0,
                startup_data.get("ltv", 0) or 0,
                startup_data.get("customer_count", 0) or 0,
                startup_data.get("revenue_growth_rate", 0) or 0,
                startup_data.get("churn_rate", 0) or 0,
                BUSINESS_STAGE_MAP.get(startup_data.get("business_stage", "Early"), 1),
                FUNDING_ROUND_MAP.get(startup_data.get("current_funding_round", "Pre-Seed"), 2)
            ]

            features_array = np.array(features).reshape(1, -1)
            features_scaled = self.scaler.transform(features_array)

            prediction = self.model.predict(features_scaled)[0]
            probabilities = self.model.predict_proba(features_scaled)[0]

            viability_class = CLASS_NAMES[int(prediction)]
            confidence = float(np.max(probabilities)) * 100
            viability_score = float(np.max(probabilities)) * 100

            return {
                "viability_score": viability_score,
                "viability_class": viability_class,
                "confidence": confidence,
                "probabilities": {CLASS_NAMES[i]: float(probabilities[i]) for i in range(len(CLASS_NAMES))}
            }

        except Exception as e:
            logger.error(f"Financial analysis failed: {str(e)}")
            raise ValueError(f"Financial viability analysis error: {str(e)}")
