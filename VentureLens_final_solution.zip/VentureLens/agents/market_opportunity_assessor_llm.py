#!/usr/bin/env python3
"""
Market Opportunity Assessor - LLM Agent for market analysis and validation
"""

import json
import logging
from typing import Dict, Any

logger = logging.getLogger(__name__)


class MarketOpportunityAssessorLLMAgent:
    def __init__(self, client):
        if client is None:
            raise ValueError("LLM client is required for market opportunity analysis")
        self.client = client

    def assess_market_opportunity(self, startup_data: Dict[str, Any]) -> Dict[str, Any]:
        prompt = f"""Analyze market opportunity:
Product: {startup_data.get('product_description', 'N/A')}
Problem: {startup_data.get('problem_addressed', 'N/A')}
Industry: {startup_data.get('industry', 'N/A')}
Market Size: ${startup_data.get('target_market_size', 0):.0f}M
Assessment: {startup_data.get('tam_sam_som_assessment', 'N/A')}
Advantage: {startup_data.get('competitive_advantage', 'N/A')}

Return JSON:
{{
    "market_opportunity_assessment": "Analysis paragraph",
    "tam_validation": {{"realistic_range": "Range", "confidence": "High/Med/Low", "justification": "Why"}},
    "competitive_landscape": {{"key_competitors": ["C1"], "competitive_positioning": "Text", "competitive_advantages": ["A1"], "competitive_threats": ["T1"]}},
    "market_trends": ["T1", "T2"],
    "market_growth_potential": 75,
    "market_risks": ["R1"],
    "market_opportunities": ["O1"]
}}
Ensure the reply is ONLY a valid JSON object with double-quoted keys and no trailing commas."""

        required_fields = [
            "market_opportunity_assessment",
            "tam_validation",
            "competitive_landscape",
            "market_trends",
            "market_growth_potential",
            "market_risks",
            "market_opportunities",
        ]
        return self.client.generate_structured_json(prompt, required_fields)
