#!/usr/bin/env python3
"""
Risk Evaluator - LLM Agent for comprehensive multi-dimensional risk assessment
"""

import json
import logging
from typing import Dict, Any

logger = logging.getLogger(__name__)


class RiskEvaluatorLLMAgent:
    def __init__(self, client):
        if client is None:
            raise ValueError("LLM client is required for risk evaluation")
        self.client = client

    def evaluate_risks(self, startup_data: Dict[str, Any]) -> Dict[str, Any]:
        prompt = f"""Assess risks:
Stage: {startup_data.get('business_stage', 'N/A')}
Metrics: MRR ${startup_data.get('mrr', 0)}, Runway {startup_data.get('runway_months', 0)}m, Burn ${startup_data.get('monthly_burn_rate', 0)}
Team: {startup_data.get('team_size', 0)} (CEO {startup_data.get('ceo_experience_years', 0)}y, Tech {startup_data.get('technical_cofounder_count', 0)})
Scores: Financial {startup_data.get('financial_viability_score', 0)}, Team {startup_data.get('team_strength_score', 0)}, Market {startup_data.get('market_opportunity_score', 0)}

Return JSON:
{{
    "overall_risk_rating": "Critical/High/Medium/Low",
    "risk_dimensions": {{
        "execution_risk": {{"score": 65, "assessment": "Text"}},
        "market_risk": {{"score": 50, "assessment": "Text"}},
        "financial_risk": {{"score": 70, "assessment": "Text"}},
        "team_risk": {{"score": 45, "assessment": "Text"}},
        "regulatory_risk": {{"score": 30, "assessment": "Text"}},
        "technology_risk": {{"score": 55, "assessment": "Text"}},
        "competitive_risk": {{"score": 60, "assessment": "Text"}}
    }},
    "critical_risk_areas": ["Risk1", "Risk2"],
    "risk_mitigation_strategies": {{"Risk1": ["S1", "S2"]}},
    "risk_management_priorities": [{{"rank": 1, "risk": "Critical", "priority": "Immediate"}}]
}}
Return only a JSON object with the exact schema above, using double-quoted keys and no trailing commas."""

        required_fields = [
            "overall_risk_rating",
            "risk_dimensions",
            "critical_risk_areas",
            "risk_mitigation_strategies",
            "risk_management_priorities",
        ]
        return self.client.generate_structured_json(prompt, required_fields)
