#!/usr/bin/env python3
"""
VentureLens Test Suite
Comprehensive unit tests for startup viability analysis system
20+ focused test cases with mock LLM clients
"""

import pytest
import json
import sys
from pathlib import Path
from typing import Dict, Any, List
import numpy as np

# Add project to path
sys.path.insert(0, str(Path(__file__).parent))

from agents.financial_analyzer_ml import FinancialAnalyzerMLAgent
from agents.team_assessor_ml import TeamAssessorMLAgent
from agents.market_opportunity_assessor_llm import MarketOpportunityAssessorLLMAgent
from agents.pitch_quality_analyzer_llm import PitchQualityAnalyzerLLMAgent
from agents.risk_evaluator_llm import RiskEvaluatorLLMAgent
from agents.funding_recommender_llm import FundingRecommenderLLMAgent
from graph import analyze_startup, get_startup_summary
from ml.evaluation.evaluate_models import evaluate_all_models
from state import StartupViabilityState, get_initial_state, validate_state


# ============================================================================
# MOCK GEMINI CLIENT FOR TESTING LLM AGENTS WITHOUT API CALLS
# ============================================================================

class MockGeminiContent:
    """Mock Gemini content object"""
    def __init__(self, text: str):
        self.text = text


class MockGeminiResponse:
    """Mock Gemini response object"""
    def __init__(self, json_response: Dict[str, Any]):
        self.text = json.dumps(json_response)


class MockGeminiClient:
    """Mock Gemini API client for testing"""
    def __init__(self):
        self.call_count = 0
        self.default_responses = {
            "market_opportunity_assessment": "Strong market potential",
            "tam_validation": {"realistic_range": "$1B-$2B", "confidence": "High", "justification": "Growing market"},
            "competitive_landscape": {"key_competitors": ["Competitor A"], "competitive_positioning": "Differentiated"},
            "market_trends": ["AI adoption", "Digital transformation"],
            "market_growth_potential": 75,
            "market_timing": "optimal",
            "market_risks": ["Competition"],
            "market_opportunities": ["Market expansion"]
        }

    def generate_content(
        self,
        prompt: str,
        temperature: float = 0.7,
        max_tokens: int = 1000,
        response_mime_type: str = None
    ) -> str:
        """Mock generate_content method"""
        self.call_count += 1

        # Determine response based on prompt content
        # Check for more specific patterns first to avoid matching on partial keywords
        prompt_lower = prompt.lower()

        # Check for specific prompt patterns
        if prompt_lower.startswith("recommend funding") or "recommend funding" in prompt_lower:
            response = {
                "funding_readiness_score": 72,
                "recommended_next_round": "Series A",
                "funding_readiness_assessment": "Ready for Series A with strong metrics",
                "funding_timeline": {"realistic_months_to_funding": 6, "phase_breakdown": "6-8 months"},
                "valuation_guidance": {"estimated_range": "$10M-$15M", "methodology": "Revenue multiple", "confidence": "High"},
                "investor_targeting_strategy": {"investor_types": ["Growth VCs"], "typical_check_size": "$500K-$2M", "geographic_focus": ["Silicon Valley"], "sample_vcs": ["VC Name"]},
                "pitch_improvements_for_investors": [{"focus_area": "Traction", "improvement": "Show more user growth"}],
                "alternative_funding_options": [{"option": "Venture debt", "pros": ["No dilution"], "cons": ["Must repay"]}],
                "go_market_timeline": "12-18 months to market leadership",
                "key_milestones_for_funding": ["Product launch", "1M ARR", "Series B"],
                "red_flags_to_address": ["Team retention", "Market validation"]
            }
        elif prompt_lower.startswith("assess risks") or "assess risks" in prompt_lower:
            response = {
                "overall_risk_rating": "Medium",
                "risk_dimensions": {
                    "execution_risk": {"score": 65, "assessment": "Moderate execution risk"},
                    "market_risk": {"score": 50, "assessment": "Market risks manageable"},
                    "financial_risk": {"score": 70, "assessment": "Cash burn is significant"},
                    "team_risk": {"score": 45, "assessment": "Strong team capability"},
                    "regulatory_risk": {"score": 30, "assessment": "Low regulatory risk"},
                    "technology_risk": {"score": 55, "assessment": "Technology is proven"},
                    "competitive_risk": {"score": 60, "assessment": "Competitive landscape challenging"}
                },
                "critical_risk_areas": ["Burn rate", "Market adoption"],
                "risk_mitigation_strategies": {"Burn rate": ["Reduce expenses", "Accelerate revenue"]},
                "risk_management_priorities": [{"rank": 1, "risk": "Burn rate", "priority": "Immediate"}]
            }
        elif ("pitch" in prompt_lower or "evaluate pitch" in prompt_lower):
            response = {
                "pitch_quality_score": 82,
                "pitch_clarity_assessment": "Clear and compelling pitch",
                "pitch_strengths": [{"strength": "Strong vision", "impact_level": "High"}],
                "pitch_weaknesses": [{"weakness": "Limited detail", "impact_level": "Low"}],
                "pitch_recommendations": [{"issue": "Add metrics", "recommendation": "Include growth metrics"}],
                "narrative_coherence_score": 80,
                "investor_ready_assessment": "mostly_ready",
                "elevator_pitch_suggestions": ["Focus on traction", "Highlight team"]
            }
        elif ("market" in prompt_lower or "opportunity" in prompt_lower) and ("analyze" in prompt_lower or "assess" in prompt_lower):
            response = {
                "market_opportunity_assessment": "Strong market opportunity with growing demand",
                "tam_validation": {"realistic_range": "$1B-$2B", "confidence": "High", "justification": "Growing market"},
                "competitive_landscape": {"key_competitors": ["CompA"], "competitive_positioning": "Differentiated", "competitive_advantages": ["Tech"], "competitive_threats": ["New entrants"]},
                "market_trends": ["AI adoption", "Digital transformation"],
                "market_growth_potential": 75,
                "market_timing": "optimal",
                "market_risks": ["Competition"],
                "market_opportunities": ["Market expansion"]
            }
        else:
            response = self.default_responses

        return json.dumps(response)

    def extract_json_from_response(self, response_text: str) -> Dict[str, Any]:
        """Mock extract JSON from response"""
        return json.loads(response_text)

    def validate_response_fields(self, response: Dict[str, Any], required_fields: list) -> None:
        """Mock field validation"""
        missing = [f for f in required_fields if f not in response]
        if missing:
            raise ValueError(f"Missing fields: {missing}")

    def generate_structured_json(
        self,
        prompt: str,
        required_fields: list,
        temperature: float = 0.7,
        max_tokens: int = 1000
    ) -> Dict[str, Any]:
        """Mock structured JSON generation"""
        response_text = self.generate_content(prompt, temperature, max_tokens)
        result = self.extract_json_from_response(response_text)
        self.validate_response_fields(result, required_fields)
        return result


# ============================================================================
# SAMPLE TEST DATA - DIFFERENT STARTUP PROFILES
# ============================================================================

SAMPLE_STARTUP_STRONG = {
    "startup_name": "TechVenture AI",
    "industry": "SaaS",
    "location": "San Francisco, CA",
    "founded_date": "2022-03-15",
    "business_stage": "Growth",
    "current_funding_round": "Series A",
    "product_description": "AI-powered analytics platform for enterprises",
    "problem_addressed": "Complex data analysis is time-consuming and error-prone",
    "target_market_size": 50.0,
    "tam_sam_som_assessment": "Aggressive",
    "key_features": ["Real-time analytics", "ML-driven insights"],
    "competitive_advantage": "Proprietary algorithms and superior performance",
    "mrr": 50000.0,
    "arr": 600000.0,
    "runway_months": 18.0,
    "monthly_burn_rate": 80000.0,
    "cac": 5000.0,
    "ltv": 60000.0,
    "customer_count": 15,
    "revenue_growth_rate": 25.0,
    "churn_rate": 5.0,
    "ceo_name": "Jane Smith",
    "ceo_experience_years": 12.0,
    "ceo_has_previous_exit": True,
    "ceo_education_level": "Master's",
    "technical_cofounder_count": 2,
    "avg_tech_experience_years": 10.0,
    "team_size": 15,
    "non_technical_roles_filled": 5,
    "members_with_startup_experience": 8,
    "industry_domain_expertise_years": 20.0,
    "founder_diversity_score": 75.0,
    "team_tenure_together_years": 2.5,
    "total_raised_to_date": 2000000.0,
    "target_funding_amount": 5000000.0,
    "elevator_pitch": "AI-powered analytics platform that helps enterprises make data-driven decisions 10x faster"
}

SAMPLE_STARTUP_RISKY = {
    "startup_name": "StartupBeta",
    "industry": "FinTech",
    "location": "New York, NY",
    "founded_date": "2024-01-01",
    "business_stage": "Pre-Revenue",
    "current_funding_round": "Bootstrapped",
    "product_description": "Blockchain-based payment system",
    "problem_addressed": "International payments are expensive",
    "target_market_size": 100.0,
    "tam_sam_som_assessment": "Aggressive",
    "key_features": ["Blockchain", "Fast"],
    "competitive_advantage": "Lower fees than competitors",
    "mrr": 0.0,
    "arr": 0.0,
    "runway_months": 6.0,
    "monthly_burn_rate": 30000.0,
    "cac": 0.0,
    "ltv": 0.0,
    "customer_count": 0,
    "revenue_growth_rate": 0.0,
    "churn_rate": 0.0,
    "ceo_name": "John Doe",
    "ceo_experience_years": 2.0,
    "ceo_has_previous_exit": False,
    "ceo_education_level": "Bachelor's",
    "technical_cofounder_count": 1,
    "avg_tech_experience_years": 3.0,
    "team_size": 3,
    "non_technical_roles_filled": 0,
    "members_with_startup_experience": 1,
    "industry_domain_expertise_years": 2.0,
    "founder_diversity_score": 30.0,
    "team_tenure_together_years": 0.5,
    "total_raised_to_date": 100000.0,
    "target_funding_amount": 1000000.0,
    "elevator_pitch": "A blockchain payment system for international transfers"
}

SAMPLE_STARTUP_MODERATE = {
    "startup_name": "HealthTech Solutions",
    "industry": "HealthTech",
    "location": "Boston, MA",
    "founded_date": "2021-06-01",
    "business_stage": "Early",
    "current_funding_round": "Seed",
    "product_description": "Telemedicine platform for rural healthcare",
    "problem_addressed": "Healthcare access in rural areas is limited",
    "target_market_size": 30.0,
    "tam_sam_som_assessment": "Moderate",
    "key_features": ["Video consultations", "Record keeping"],
    "competitive_advantage": "Specialized for rural healthcare",
    "mrr": 15000.0,
    "arr": 180000.0,
    "runway_months": 12.0,
    "monthly_burn_rate": 50000.0,
    "cac": 3000.0,
    "ltv": 30000.0,
    "customer_count": 5,
    "revenue_growth_rate": 15.0,
    "churn_rate": 8.0,
    "ceo_name": "Dr. Sarah Johnson",
    "ceo_experience_years": 8.0,
    "ceo_has_previous_exit": False,
    "ceo_education_level": "Master's",
    "technical_cofounder_count": 1,
    "avg_tech_experience_years": 7.0,
    "team_size": 8,
    "non_technical_roles_filled": 3,
    "members_with_startup_experience": 3,
    "industry_domain_expertise_years": 15.0,
    "founder_diversity_score": 60.0,
    "team_tenure_together_years": 1.8,
    "total_raised_to_date": 500000.0,
    "target_funding_amount": 2000000.0,
    "elevator_pitch": "Telemedicine platform connecting rural patients with specialists"
}


# ============================================================================
# TEST 1: Test financial viability analysis
# ============================================================================
def test_financial_analyzer_strong_startup():
    """ML Agent Test: Financial analysis for strong startup"""
    agent = FinancialAnalyzerMLAgent(model_dir="ml/models")
    result = agent.analyze_financial_viability(SAMPLE_STARTUP_STRONG)

    assert "viability_score" in result
    assert "viability_class" in result
    assert "confidence" in result
    assert isinstance(result["viability_score"], (int, float))
    assert 0 <= result["viability_score"] <= 100
    assert result["viability_class"] in ["High Risk", "Medium Risk", "Viable", "Strong"]
    assert 0 <= result["confidence"] <= 100


# ============================================================================
# TEST 2: Test team assessment
# ============================================================================
def test_team_assessor_strong_team():
    """ML Agent Test: Team assessment for strong team"""
    agent = TeamAssessorMLAgent(model_dir="ml/models")
    result = agent.assess_team_competitiveness(SAMPLE_STARTUP_STRONG)

    assert "strength_score" in result
    assert "strength_class" in result
    assert "confidence" in result
    assert isinstance(result["strength_score"], (int, float))
    assert 0 <= result["strength_score"] <= 100
    assert result["strength_class"] in ["Weak", "Emerging", "Strong", "Exceptional"]


# ============================================================================
# TEST 3: Test market opportunity with mock LLM
# ============================================================================
def test_market_opportunity_mock():
    """Mock LLM Test: Market opportunity analysis"""
    mock_client = MockGeminiClient()
    agent = MarketOpportunityAssessorLLMAgent(client=mock_client)
    result = agent.assess_market_opportunity(SAMPLE_STARTUP_STRONG)

    assert "market_opportunity_assessment" in result
    assert "tam_validation" in result
    assert "competitive_landscape" in result
    assert "market_trends" in result
    assert "market_growth_potential" in result
    assert "market_timing" in result
    assert "market_risks" in result
    assert "market_opportunities" in result
    assert mock_client.call_count == 1


# ============================================================================
# TEST 4: Test pitch quality with mock LLM
# ============================================================================
def test_pitch_quality_mock():
    """Mock LLM Test: Pitch quality analysis"""
    mock_client = MockGeminiClient()
    agent = PitchQualityAnalyzerLLMAgent(client=mock_client)
    result = agent.analyze_pitch_quality(SAMPLE_STARTUP_STRONG)

    assert "pitch_quality_score" in result
    assert "pitch_clarity_assessment" in result
    assert "pitch_strengths" in result
    assert "pitch_weaknesses" in result
    assert "pitch_recommendations" in result
    assert "narrative_coherence_score" in result
    assert "investor_ready_assessment" in result
    assert "elevator_pitch_suggestions" in result
    assert mock_client.call_count == 1


# ============================================================================
# TEST 5: Test risk evaluation with mock LLM
# ============================================================================
def test_risk_evaluation_mock():
    """Mock LLM Test: Risk evaluation"""
    mock_client = MockGeminiClient()
    startup_data = SAMPLE_STARTUP_STRONG.copy()
    startup_data['financial_viability_score'] = 75
    startup_data['team_strength_score'] = 85
    startup_data['market_opportunity_score'] = 70

    agent = RiskEvaluatorLLMAgent(client=mock_client)
    result = agent.evaluate_risks(startup_data)

    assert "overall_risk_rating" in result
    assert "risk_dimensions" in result
    assert "critical_risk_areas" in result
    assert "risk_mitigation_strategies" in result
    assert "risk_management_priorities" in result
    assert result["overall_risk_rating"] in ["Critical", "High", "Medium", "Low"]
    assert mock_client.call_count == 1


# ============================================================================
# TEST 6: Test funding recommendations with mock LLM
# ============================================================================
def test_funding_recommendations_mock():
    """Mock LLM Test: Funding recommendations"""
    mock_client = MockGeminiClient()
    startup_data = SAMPLE_STARTUP_STRONG.copy()
    startup_data['financial_viability_score'] = 75
    startup_data['team_strength_score'] = 85
    startup_data['market_opportunity_score'] = 70
    startup_data['pitch_quality_score'] = 80
    startup_data['overall_risk_rating'] = "Medium"

    agent = FundingRecommenderLLMAgent(client=mock_client)
    result = agent.generate_funding_recommendations(startup_data)

    assert "funding_readiness_score" in result
    assert "recommended_next_round" in result
    assert "funding_readiness_assessment" in result
    assert "funding_timeline" in result
    assert "valuation_guidance" in result
    assert "investor_targeting_strategy" in result
    assert "alternative_funding_options" in result
    assert mock_client.call_count == 1


# ============================================================================
# TEST 7: Test initial state creation
# ============================================================================
def test_initial_state_creation():
    """State Test: Initial state creation for startup"""
    state = get_initial_state(SAMPLE_STARTUP_STRONG)

    # Check required fields exist (structure validation)
    assert "startup_name" in state
    assert "industry" in state
    assert "location" in state
    assert "founded_date" in state
    assert "business_stage" in state

    # Check status flags are properly initialized
    assert not state["parsing_complete"]
    assert not state["error_occurred"]


# ============================================================================
# TEST 8: Test state validation
# ============================================================================
def test_validate_state():
    """State Test: State validation"""
    state = get_initial_state(SAMPLE_STARTUP_STRONG)

    # State should be valid
    result = validate_state(state)
    assert result[0] is True or result is True


# ============================================================================
# TEST 9: Test financial analysis - strong vs risky startups
# ============================================================================
def test_financial_analysis_strong_vs_risky():
    """ML Agent Test: Financial scores for strong vs risky startups"""
    agent = FinancialAnalyzerMLAgent(model_dir="ml/models")
    result_strong = agent.analyze_financial_viability(SAMPLE_STARTUP_STRONG)
    result_risky = agent.analyze_financial_viability(SAMPLE_STARTUP_RISKY)

    assert result_strong["viability_score"] > 0
    assert result_risky["viability_score"] > 0
    assert isinstance(result_strong["viability_class"], str)
    assert isinstance(result_risky["viability_class"], str)


# ============================================================================
# TEST 10: Test team assessment - strong vs weak teams
# ============================================================================
def test_team_assessment_strong_vs_weak():
    """ML Agent Test: Team scores for strong vs weak teams"""
    agent = TeamAssessorMLAgent(model_dir="ml/models")
    result_strong = agent.assess_team_competitiveness(SAMPLE_STARTUP_STRONG)
    result_risky = agent.assess_team_competitiveness(SAMPLE_STARTUP_RISKY)

    assert result_strong["strength_score"] > 0
    assert result_risky["strength_score"] > 0
    assert isinstance(result_strong["strength_class"], str)
    assert isinstance(result_risky["strength_class"], str)


# ============================================================================
# TEST 11: Test complete startup analysis with mock LLM
# ============================================================================
def test_analyze_startup_complete():
    """Graph Test: Complete startup analysis with mock LLM"""
    mock_client = MockGeminiClient()
    result = analyze_startup(SAMPLE_STARTUP_STRONG, llm_client=mock_client)

    # Check required fields and status flags exist
    assert "startup_name" in result
    assert result["financial_analysis_complete"] is True
    assert result["team_analysis_complete"] is True
    assert "market_analysis_complete" in result
    assert "pitch_analysis_complete" in result
    assert "risk_analysis_complete" in result
    assert "recommendations_complete" in result

    # Check all analysis scores are present
    assert "financial_viability_score" in result
    assert "team_strength_score" in result
    assert "market_opportunity_score" in result
    assert "pitch_quality_score" in result
    assert "overall_risk_rating" in result


# ============================================================================
# TEST 12: Test startup summary extraction
# ============================================================================
def test_get_startup_summary():
    """Graph Test: Startup summary extraction"""
    mock_client = MockGeminiClient()
    result = analyze_startup(SAMPLE_STARTUP_STRONG, llm_client=mock_client)
    summary = get_startup_summary(result)

    # Check required summary fields exist
    assert "startup_name" in summary
    assert "industry" in summary
    assert "location" in summary
    assert "business_stage" in summary

    # Check analysis results are included in summary
    assert "viability_score" in summary
    assert "viability_class" in summary
    assert "team_score" in summary
    assert "team_class" in summary
    assert "market_score" in summary


# ============================================================================
# TEST 13: Test ML models exist
# ============================================================================
def test_ml_models_exist():
    """Data & Model Persistence Test: ML model files exist"""
    model_dir = Path(__file__).parent / "ml" / "models"

    # Check financial viability model
    financial_model = model_dir / "financial_viability_model.pkl"
    assert financial_model.exists(), f"Missing model: {financial_model}"
    assert financial_model.stat().st_size > 0, "Financial model is empty"

    # Check team competitiveness model
    team_model = model_dir / "team_competitiveness_model.pkl"
    assert team_model.exists(), f"Missing model: {team_model}"
    assert team_model.stat().st_size > 0, "Team model is empty"

    # Check scalers
    financial_scaler = model_dir / "financial_viability_scaler.pkl"
    assert financial_scaler.exists(), f"Missing scaler: {financial_scaler}"

    team_scaler = model_dir / "team_competitiveness_scaler.pkl"
    assert team_scaler.exists(), f"Missing scaler: {team_scaler}"


# ============================================================================
# TEST 14: Test cleaned datasets exist
# ============================================================================
def test_cleaned_datasets_exist():
    """Data & Model Persistence Test: Cleaned datasets exist"""
    processed_dir = Path(__file__).parent / "data" / "processed"

    # Check financial viability dataset
    financial_dataset = processed_dir / "financial_viability_cleaned.csv"
    assert financial_dataset.exists(), f"Missing dataset: {financial_dataset}"
    assert financial_dataset.stat().st_size > 0, "Financial dataset is empty"

    # Check team competitiveness dataset
    team_dataset = processed_dir / "team_competitiveness_cleaned.csv"
    assert team_dataset.exists(), f"Missing dataset: {team_dataset}"
    assert team_dataset.stat().st_size > 0, "Team dataset is empty"


# ============================================================================
# TEST 15: Test model evaluation
# ============================================================================
def test_model_evaluation():
    """Model Evaluation Test: Model metrics"""
    eval_results = evaluate_all_models()

    if eval_results and eval_results.get("financial_evaluation"):
        financial_eval = eval_results["financial_evaluation"]
        assert "accuracy" in financial_eval
        assert "precision" in financial_eval
        assert "recall" in financial_eval
        assert "f1" in financial_eval
        assert financial_eval["accuracy"] > 0

        team_eval = eval_results["team_evaluation"]
        assert "accuracy" in team_eval
        assert "precision" in team_eval
        assert team_eval["accuracy"] > 0


# ============================================================================
# TEST 16: Test market opportunity with multiple startups
# ============================================================================
def test_market_opportunity_multiple_startups():
    """Mock LLM Test: Market analysis for different startups"""
    mock_client = MockGeminiClient()

    agent = MarketOpportunityAssessorLLMAgent(client=mock_client)
    result_strong = agent.assess_market_opportunity(SAMPLE_STARTUP_STRONG)
    call_count_1 = mock_client.call_count

    result_moderate = agent.assess_market_opportunity(SAMPLE_STARTUP_MODERATE)
    call_count_2 = mock_client.call_count

    assert result_strong["market_growth_potential"] > 0
    assert result_moderate["market_growth_potential"] > 0
    assert call_count_2 > call_count_1  # LLM was called again


# ============================================================================
# TEST 17: Test pitch quality across different elevator pitches
# ============================================================================
def test_pitch_quality_multiple_pitches():
    """Mock LLM Test: Pitch quality for different pitches"""
    mock_client = MockGeminiClient()

    agent = PitchQualityAnalyzerLLMAgent(client=mock_client)
    result_strong = agent.analyze_pitch_quality(SAMPLE_STARTUP_STRONG)
    call_count_1 = mock_client.call_count

    result_risky = agent.analyze_pitch_quality(SAMPLE_STARTUP_RISKY)
    call_count_2 = mock_client.call_count

    assert "pitch_quality_score" in result_strong
    assert "pitch_quality_score" in result_risky
    assert call_count_2 > call_count_1


# ============================================================================
# TEST 18: Test risk evaluation across different risk profiles
# ============================================================================
def test_risk_evaluation_multiple_profiles():
    """Mock LLM Test: Risk assessment for different startup profiles"""
    mock_client = MockGeminiClient()

    startup_strong = SAMPLE_STARTUP_STRONG.copy()
    startup_strong.update({
        'financial_viability_score': 80,
        'team_strength_score': 85,
        'market_opportunity_score': 75
    })

    startup_risky = SAMPLE_STARTUP_RISKY.copy()
    startup_risky.update({
        'financial_viability_score': 30,
        'team_strength_score': 40,
        'market_opportunity_score': 50
    })

    agent = RiskEvaluatorLLMAgent(client=mock_client)
    result_strong = agent.evaluate_risks(startup_strong)
    result_risky = agent.evaluate_risks(startup_risky)

    assert result_strong["overall_risk_rating"] in ["Critical", "High", "Medium", "Low"]
    assert result_risky["overall_risk_rating"] in ["Critical", "High", "Medium", "Low"]


# ============================================================================
# TEST 19: Test funding readiness scores
# ============================================================================
def test_funding_readiness_scores():
    """Mock LLM Test: Funding readiness for different maturity levels"""
    mock_client = MockGeminiClient()

    startup_strong = SAMPLE_STARTUP_STRONG.copy()
    startup_strong.update({
        'financial_viability_score': 80,
        'team_strength_score': 85,
        'market_opportunity_score': 75,
        'pitch_quality_score': 85,
        'overall_risk_rating': "Medium"
    })

    startup_early = SAMPLE_STARTUP_RISKY.copy()
    startup_early.update({
        'financial_viability_score': 40,
        'team_strength_score': 50,
        'market_opportunity_score': 60,
        'pitch_quality_score': 65,
        'overall_risk_rating': "High"
    })

    agent = FundingRecommenderLLMAgent(client=mock_client)
    result_strong = agent.generate_funding_recommendations(startup_strong)
    result_early = agent.generate_funding_recommendations(startup_early)

    assert "funding_readiness_score" in result_strong
    assert "funding_readiness_score" in result_early
    assert "recommended_next_round" in result_strong
    assert "recommended_next_round" in result_early


# ============================================================================
# TEST 20: Test complete workflow with all agents
# ============================================================================
def test_complete_workflow_all_agents():
    """Integration Test: Complete workflow execution"""
    mock_client = MockGeminiClient()

    result = analyze_startup(SAMPLE_STARTUP_MODERATE, llm_client=mock_client)

    # Verify all analysis components completed
    assert result["parsing_complete"] is True
    assert result["financial_analysis_complete"] is True
    assert result["team_analysis_complete"] is True
    assert result["market_analysis_complete"] is True
    assert result["pitch_analysis_complete"] is True
    assert result["risk_analysis_complete"] is True
    assert result["recommendations_complete"] is True

    # Verify key outputs present
    assert "financial_viability_score" in result
    assert "team_strength_score" in result
    assert "market_opportunity_score" in result
    assert "pitch_quality_score" in result
    assert "overall_risk_rating" in result
    assert "funding_readiness_score" in result


# ============================================================================
# TEST 21: Test error handling with None LLM client
# ============================================================================
def test_market_opportunity_requires_llm():
    """Error Handling Test: Market opportunity requires LLM"""
    with pytest.raises(ValueError):
        MarketOpportunityAssessorLLMAgent(client=None)


def test_pitch_quality_requires_llm():
    """Error Handling Test: Pitch quality requires LLM"""
    with pytest.raises(ValueError):
        PitchQualityAnalyzerLLMAgent(client=None)


def test_risk_evaluation_requires_llm():
    """Error Handling Test: Risk evaluation requires LLM"""
    with pytest.raises(ValueError):
        RiskEvaluatorLLMAgent(client=None)


def test_funding_recommendations_requires_llm():
    """Error Handling Test: Funding recommendations require LLM"""
    with pytest.raises(ValueError):
        FundingRecommenderLLMAgent(client=None)


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
