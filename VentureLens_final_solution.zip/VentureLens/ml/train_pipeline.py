#!/usr/bin/env python3
"""
ML training pipeline orchestration
"""

from typing import Dict, Any
import pandas as pd
from pathlib import Path
import sys

# Allow running both as a module (`python -m ml.train_pipeline`)
# and as a script (`python ml/train_pipeline.py`) without changing layout
if __name__ == "__main__" and __package__ is None:
    sys.path.append(str(Path(__file__).resolve().parent.parent))

from ml.data_cleaning.clean_financial_data import clean_financial_data
from ml.data_cleaning.clean_team_data import clean_team_data
from ml.train_model.train_financial_viability import train_financial_viability_model
from ml.train_model.train_team_competitiveness import train_team_competitiveness_model
from ml.evaluation.evaluate_models import evaluate_all_models


def run_training_pipeline(data_dir: str = "data", processed_dir: str = "data/processed", model_dir: str = "ml/models") -> dict:
    results = {
        "financial_cleaning": {},
        "team_cleaning": {},
        "financial_training": {},
        "team_training": {},
        "evaluation": {}
    }

    try:
        financial_train_path = f"{data_dir}/training_dataset/financial_viability_training.csv"
        team_train_path = f"{data_dir}/training_dataset/team_competitiveness_training.csv"

        print("Loading datasets...")
        financial_df = pd.read_csv(financial_train_path)
        team_df = pd.read_csv(team_train_path)

        print("Cleaning financial data...")
        financial_df_clean, financial_stats = clean_financial_data(financial_df, save_processed=True, output_dir=processed_dir)
        results["financial_cleaning"] = financial_stats

        print("Cleaning team data...")
        team_df_clean, team_stats = clean_team_data(team_df, save_processed=True, output_dir=processed_dir)
        results["team_cleaning"] = team_stats

        print("Training financial viability model...")
        financial_metrics = train_financial_viability_model(financial_df_clean, model_save_dir=model_dir)
        results["financial_training"] = financial_metrics

        print("Training team competitiveness model...")
        team_metrics = train_team_competitiveness_model(team_df_clean, model_save_dir=model_dir)
        results["team_training"] = team_metrics

        print("Evaluating models...")
        eval_results = evaluate_all_models(model_dir=model_dir, eval_data_dir=f"{data_dir}/evaluation_dataset")
        results["evaluation"] = eval_results

        print("Training pipeline complete!")
        return results

    except Exception as e:
        results["error"] = str(e)
        print(f"Pipeline error: {str(e)}")
        return results


if __name__ == "__main__":
    results = run_training_pipeline()
    import json
    print(json.dumps(results, indent=2))
