#!/usr/bin/env python3
"""
Evaluate trained ML models
"""

from typing import Dict, Any
import pickle
import pandas as pd
from pathlib import Path
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from datetime import datetime


def evaluate_financial_model(model_dir: str = "ml/models", eval_data_path: str = "data/evaluation_dataset/financial_viability_evaluation.csv") -> dict:
    try:
        model_path = Path(model_dir) / "financial_viability_model.pkl"
        scaler_path = Path(model_dir) / "financial_viability_scaler.pkl"
        label_encoder_path = Path(model_dir) / "financial_viability_label_encoder.pkl"

        if not model_path.exists() or not scaler_path.exists():
            return {}

        with open(model_path, "rb") as f:
            model = pickle.load(f)
        with open(scaler_path, "rb") as f:
            scaler = pickle.load(f)
        with open(label_encoder_path, "rb") as f:
            label_encoder = pickle.load(f)

        eval_df = pd.read_csv(eval_data_path)

        rename_map = {
            "mrr_usd": "Monthly_Recurring_Revenue_USD",
            "arr_usd": "Annual_Recurring_Revenue_USD",
            "runway_months": "Runway_Months",
            "monthly_burn_rate_usd": "Monthly_Burn_Rate_USD",
            "cac_usd": "Customer_Acquisition_Cost_USD",
            "ltv_usd": "Customer_Lifetime_Value_USD",
            "customer_count": "Customer_Count",
            "revenue_growth_rate_pct": "Revenue_Growth_Rate_%",
            "customer_churn_rate_pct": "Customer_Churn_Rate_%",
            "business_stage": "Business_Stage",
            "funding_round_stage": "Funding_Round_Stage",
            "financial_viability_class": "Financial_Viability_Class"
        }
        eval_df = eval_df.rename(columns=rename_map)

        feature_cols = ['Monthly_Recurring_Revenue_USD', 'Annual_Recurring_Revenue_USD', 'Runway_Months',
                        'Monthly_Burn_Rate_USD', 'Customer_Acquisition_Cost_USD', 'Customer_Lifetime_Value_USD',
                        'Customer_Count', 'Revenue_Growth_Rate_%', 'Customer_Churn_Rate_%',
                        'Business_Stage', 'Funding_Round_Stage']

        stage_map = {'Pre-Revenue': 0, 'Early': 1, 'Growth': 2, 'Scale': 3}
        round_map = {'Bootstrapped': 0, 'Pre-Seed': 1, 'Seed': 2, 'Series A': 3, 'Series B': 4, 'Series C+': 5}

        eval_df['Business_Stage'] = eval_df['Business_Stage'].map(stage_map).fillna(0)
        eval_df['Funding_Round_Stage'] = eval_df['Funding_Round_Stage'].map(round_map).fillna(0)

        X_eval = eval_df[feature_cols].apply(pd.to_numeric, errors='coerce').fillna(0)
        y_eval = eval_df['Financial_Viability_Class']
        y_eval_encoded = label_encoder.transform(y_eval)

        X_eval_scaled = scaler.transform(X_eval)
        y_pred = model.predict(X_eval_scaled)

        accuracy = accuracy_score(y_eval_encoded, y_pred)
        precision = precision_score(y_eval_encoded, y_pred, average='weighted', zero_division=0)
        recall = recall_score(y_eval_encoded, y_pred, average='weighted', zero_division=0)
        f1 = f1_score(y_eval_encoded, y_pred, average='weighted', zero_division=0)

        return {
            "model": "financial_viability",
            "accuracy": accuracy,
            "precision": precision,
            "recall": recall,
            "f1": f1,
            "samples": len(eval_df)
        }

    except Exception as e:
        return {"error": str(e)}


def evaluate_team_model(model_dir: str = "ml/models", eval_data_path: str = "data/evaluation_dataset/team_competitiveness_evaluation.csv") -> dict:
    try:
        model_path = Path(model_dir) / "team_competitiveness_model.pkl"
        scaler_path = Path(model_dir) / "team_competitiveness_scaler.pkl"
        label_encoder_path = Path(model_dir) / "team_competitiveness_label_encoder.pkl"

        if not model_path.exists() or not scaler_path.exists():
            return {}

        with open(model_path, "rb") as f:
            model = pickle.load(f)
        with open(scaler_path, "rb") as f:
            scaler = pickle.load(f)
        with open(label_encoder_path, "rb") as f:
            label_encoder = pickle.load(f)

        eval_df = pd.read_csv(eval_data_path)

        feature_cols = ['CEO_Experience_Years', 'CEO_Has_Previous_Exit', 'CEO_Education_Level',
                        'Technical_Cofounder_Count', 'Avg_Tech_Experience_Years', 'Team_Size',
                        'Non_Technical_Roles_Filled', 'Members_With_Startup_Experience',
                        'Industry_Expertise_Years', 'Founder_Diversity_Score', 'Team_Tenure_Together_Years']

        eval_df['CEO_Has_Previous_Exit'] = eval_df['CEO_Has_Previous_Exit'].map({'Yes': 1, 'No': 0}).fillna(0)
        education_map = {"High School": 1, "Bachelor's": 2, "Master's": 3, "PhD": 4}
        eval_df['CEO_Education_Level'] = eval_df['CEO_Education_Level'].map(education_map).fillna(2)

        X_eval = eval_df[feature_cols].apply(pd.to_numeric, errors='coerce').fillna(0)
        y_eval = eval_df['Team_Strength_Class']
        y_eval_encoded = label_encoder.transform(y_eval)

        X_eval_scaled = scaler.transform(X_eval)
        y_pred = model.predict(X_eval_scaled)

        accuracy = accuracy_score(y_eval_encoded, y_pred)
        precision = precision_score(y_eval_encoded, y_pred, average='weighted', zero_division=0)
        recall = recall_score(y_eval_encoded, y_pred, average='weighted', zero_division=0)
        f1 = f1_score(y_eval_encoded, y_pred, average='weighted', zero_division=0)

        return {
            "model": "team_competitiveness",
            "accuracy": accuracy,
            "precision": precision,
            "recall": recall,
            "f1": f1,
            "samples": len(eval_df)
        }

    except Exception as e:
        return {"error": str(e)}


def evaluate_all_models(model_dir: str = "ml/models", eval_data_dir: str = "data/evaluation_dataset") -> dict:
    financial_eval = evaluate_financial_model(model_dir, f"{eval_data_dir}/financial_viability_evaluation.csv")
    team_eval = evaluate_team_model(model_dir, f"{eval_data_dir}/team_competitiveness_evaluation.csv")

    return {
        "timestamp": datetime.now().isoformat(),
        "financial_evaluation": financial_eval,
        "team_evaluation": team_eval
    }
