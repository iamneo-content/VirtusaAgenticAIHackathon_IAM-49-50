#!/usr/bin/env python3
"""
Train financial viability RandomForest model
"""

from typing import Dict, Any, Tuple
import pickle
import pandas as pd
from pathlib import Path
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score


def train_financial_viability_model(df: pd.DataFrame, model_save_dir: str = "ml/models", test_size: float = 0.2, random_state: int = 42) -> Dict[str, Any]:
    feature_cols = ['Monthly_Recurring_Revenue_USD', 'Annual_Recurring_Revenue_USD', 'Runway_Months',
                    'Monthly_Burn_Rate_USD', 'Customer_Acquisition_Cost_USD', 'Customer_Lifetime_Value_USD',
                    'Customer_Count', 'Revenue_Growth_Rate_%', 'Customer_Churn_Rate_%',
                    'Business_Stage', 'Funding_Round_Stage']

    X = df[feature_cols].fillna(0)
    y = df['Financial_Viability_Class']

    label_encoder = LabelEncoder()
    y_encoded = label_encoder.fit_transform(y)

    X_train, X_test, y_train, y_test = train_test_split(X, y_encoded, test_size=test_size, random_state=random_state)

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    model = RandomForestClassifier(n_estimators=100, max_depth=10, random_state=random_state, class_weight='balanced')
    model.fit(X_train_scaled, y_train)

    y_train_pred = model.predict(X_train_scaled)
    y_test_pred = model.predict(X_test_scaled)

    train_accuracy = accuracy_score(y_train, y_train_pred)
    test_accuracy = accuracy_score(y_test, y_test_pred)
    test_precision = precision_score(y_test, y_test_pred, average='weighted', zero_division=0)
    test_recall = recall_score(y_test, y_test_pred, average='weighted', zero_division=0)
    test_f1 = f1_score(y_test, y_test_pred, average='weighted', zero_division=0)

    Path(model_save_dir).mkdir(parents=True, exist_ok=True)

    with open(f"{model_save_dir}/financial_viability_model.pkl", "wb") as f:
        pickle.dump(model, f)

    with open(f"{model_save_dir}/financial_viability_scaler.pkl", "wb") as f:
        pickle.dump(scaler, f)

    with open(f"{model_save_dir}/financial_viability_label_encoder.pkl", "wb") as f:
        pickle.dump(label_encoder, f)

    metrics = {
        "train_accuracy": train_accuracy,
        "test_accuracy": test_accuracy,
        "test_precision": test_precision,
        "test_recall": test_recall,
        "test_f1": test_f1,
        "overfitting_gap": train_accuracy - test_accuracy,
        "feature_importance": dict(zip(feature_cols, model.feature_importances_))
    }

    return metrics
