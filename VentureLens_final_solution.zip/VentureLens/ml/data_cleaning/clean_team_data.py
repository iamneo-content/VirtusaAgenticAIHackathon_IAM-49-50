#!/usr/bin/env python3
"""
Clean team competitiveness training data
"""

from typing import Tuple, Dict, Any
import pandas as pd
from pathlib import Path


def clean_team_data(df: pd.DataFrame, save_processed: bool = False, output_dir: str = "data/processed") -> Tuple[pd.DataFrame, dict]:
    original_rows = len(df)

    df = df.drop_duplicates()
    duplicates_removed = original_rows - len(df)

    numeric_cols = ['CEO_Experience_Years', 'Technical_Cofounder_Count', 'Avg_Tech_Experience_Years',
                    'Team_Size', 'Non_Technical_Roles_Filled', 'Members_With_Startup_Experience',
                    'Industry_Expertise_Years', 'Founder_Diversity_Score', 'Team_Tenure_Together_Years']

    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')
            df[col].fillna(df[col].median(), inplace=True)

    education_map = {"High School": 1, "Bachelor's": 2, "Master's": 3, "PhD": 4}
    if 'CEO_Education_Level' in df.columns:
        df['CEO_Education_Level'] = df['CEO_Education_Level'].map(education_map)
        df['CEO_Education_Level'].fillna(2, inplace=True)

    if 'CEO_Has_Previous_Exit' in df.columns:
        df['CEO_Has_Previous_Exit'] = df['CEO_Has_Previous_Exit'].map({'Yes': 1, 'No': 0})
        df['CEO_Has_Previous_Exit'].fillna(0, inplace=True)

    for col in numeric_cols:
        if col in df.columns:
            Q1 = df[col].quantile(0.25)
            Q3 = df[col].quantile(0.75)
            IQR = Q3 - Q1
            lower_bound = Q1 - 3 * IQR
            upper_bound = Q3 + 3 * IQR
            df = df[(df[col] >= lower_bound) & (df[col] <= upper_bound)]

    valid_classes = ['Weak', 'Emerging', 'Strong', 'Exceptional']
    if 'Team_Strength_Class' in df.columns:
        df = df[df['Team_Strength_Class'].isin(valid_classes)]

    cleaned_rows = len(df)
    rows_removed_pct = ((original_rows - cleaned_rows) / original_rows) * 100

    output_path = None
    if save_processed:
        Path(output_dir).mkdir(parents=True, exist_ok=True)
        output_path = f"{output_dir}/team_competitiveness_cleaned.csv"
        df.to_csv(output_path, index=False)

    stats = {
        "original_rows": original_rows,
        "cleaned_rows": cleaned_rows,
        "duplicates_removed": duplicates_removed,
        "rows_removed_pct": rows_removed_pct,
        "output_path": output_path
    }

    return df, stats
