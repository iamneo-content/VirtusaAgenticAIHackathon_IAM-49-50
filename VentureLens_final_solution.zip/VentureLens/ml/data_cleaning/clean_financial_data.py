#!/usr/bin/env python3
"""
Clean financial viability training data
"""

from typing import Tuple, Dict, Any
import pandas as pd
from pathlib import Path


def clean_financial_data(df: pd.DataFrame, save_processed: bool = False, output_dir: str = "data/processed") -> Tuple[pd.DataFrame, dict]:
    original_rows = len(df)

    df = df.drop_duplicates()
    duplicates_removed = original_rows - len(df)

    numeric_cols = ['Monthly_Recurring_Revenue_USD', 'Annual_Recurring_Revenue_USD', 'Runway_Months',
                    'Monthly_Burn_Rate_USD', 'Customer_Acquisition_Cost_USD', 'Customer_Lifetime_Value_USD',
                    'Customer_Count', 'Revenue_Growth_Rate_%', 'Customer_Churn_Rate_%']

    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')
            df[col].fillna(df[col].median(), inplace=True)

    categorical_cols = ['Business_Stage', 'Funding_Round_Stage']
    for col in categorical_cols:
        if col in df.columns:
            df[col].fillna(df[col].mode()[0] if not df[col].mode().empty else 'Growth', inplace=True)

    stage_map = {'Pre-Revenue': 0, 'Early': 1, 'Growth': 2, 'Scale': 3}
    if 'Business_Stage' in df.columns:
        df['Business_Stage'] = df['Business_Stage'].map(stage_map)

    round_map = {'Bootstrapped': 0, 'Pre-Seed': 1, 'Seed': 2, 'Series A': 3, 'Series B': 4, 'Series C+': 5}
    if 'Funding_Round_Stage' in df.columns:
        df['Funding_Round_Stage'] = df['Funding_Round_Stage'].map(round_map)

    for col in numeric_cols:
        if col in df.columns:
            Q1 = df[col].quantile(0.25)
            Q3 = df[col].quantile(0.75)
            IQR = Q3 - Q1
            lower_bound = Q1 - 3 * IQR
            upper_bound = Q3 + 3 * IQR
            df = df[(df[col] >= lower_bound) & (df[col] <= upper_bound)]

    valid_classes = ['High Risk', 'Medium Risk', 'Viable', 'Strong']
    if 'Financial_Viability_Class' in df.columns:
        df = df[df['Financial_Viability_Class'].isin(valid_classes)]

    cleaned_rows = len(df)
    rows_removed_pct = ((original_rows - cleaned_rows) / original_rows) * 100

    output_path = None
    if save_processed:
        Path(output_dir).mkdir(parents=True, exist_ok=True)
        output_path = f"{output_dir}/financial_viability_cleaned.csv"
        df.to_csv(output_path, index=False)

    stats = {
        "original_rows": original_rows,
        "cleaned_rows": cleaned_rows,
        "duplicates_removed": duplicates_removed,
        "rows_removed_pct": rows_removed_pct,
        "output_path": output_path
    }

    return df, stats
