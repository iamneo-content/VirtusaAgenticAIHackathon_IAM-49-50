#!/usr/bin/env python3
"""
LangGraph workflow definition and execution for VentureLens

TODO: Implement complete 6-node workflow with LangGraph
REFERENCE: /Users/balamurale/Downloads/LangHackthon/InvestPulse/workflow/workflow.py
"""

from typing import Dict, Any, Optional
from langgraph.graph import StateGraph
from state import StartupViabilityState, get_initial_state
from nodes import (
    form_parser_node,
    financial_analyzer_node,
    team_assessor_node,
    market_opportunity_node,
    pitch_quality_node,
    risk_evaluator_node,
    funding_recommender_node
)


def build_workflow(llm_client=None) -> StateGraph:
    """Builds the complete LangGraph workflow with 7 nodes."""
    workflow = StateGraph(StartupViabilityState)

    workflow.add_node("form_parser", lambda state: form_parser_node(state, None))
    workflow.add_node("financial_analyzer", lambda state: financial_analyzer_node(state, None))
    workflow.add_node("team_assessor", lambda state: team_assessor_node(state, None))
    workflow.add_node("market_opportunity", lambda state: market_opportunity_node(state, llm_client))
    workflow.add_node("pitch_quality", lambda state: pitch_quality_node(state, llm_client))
    workflow.add_node("risk_evaluator", lambda state: risk_evaluator_node(state, llm_client))
    workflow.add_node("funding_recommender", lambda state: funding_recommender_node(state, llm_client))

    workflow.set_entry_point("form_parser")
    workflow.add_edge("form_parser", "financial_analyzer")
    workflow.add_edge("form_parser", "team_assessor")
    workflow.add_edge("financial_analyzer", "market_opportunity")
    workflow.add_edge("team_assessor", "market_opportunity")
    workflow.add_edge("market_opportunity", "pitch_quality")
    workflow.add_edge("pitch_quality", "risk_evaluator")
    workflow.add_edge("risk_evaluator", "funding_recommender")
    workflow.set_finish_point("funding_recommender")

    return workflow.compile()


def run_startup_analysis_workflow(form_data: Dict[str, Any], llm_client=None) -> Dict[str, Any]:
    """Executes the complete startup analysis workflow."""
    initial_state = get_initial_state(form_data)
    workflow = build_workflow(llm_client)
    result = workflow.invoke(initial_state)
    return result
