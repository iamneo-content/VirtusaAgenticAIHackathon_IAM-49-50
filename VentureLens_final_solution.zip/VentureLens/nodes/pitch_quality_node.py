#!/usr/bin/env python3
"""
Pitch Quality Node - LangGraph node wrapper for pitch analysis LLM
"""

from state import StartupViabilityState
from agents.pitch_quality_analyzer_llm import PitchQualityAnalyzerLLMAgent
from typing import Dict, Any


def pitch_quality_node(state: StartupViabilityState, client=None) -> dict:
    """Analyzes pitch quality using LLM agent."""
    try:
        startup_data = state.get('parsed_startup', {})
        agent = PitchQualityAnalyzerLLMAgent(client=client)
        result = agent.analyze_pitch_quality(startup_data)

        return {
            'pitch_quality_score': result.get('pitch_quality_score', 0),
            'pitch_clarity_assessment': result.get('pitch_clarity_assessment', ''),
            'pitch_strengths': result.get('pitch_strengths', []),
            'pitch_weaknesses': result.get('pitch_weaknesses', []),
            'pitch_recommendations': result.get('pitch_recommendations', []),
            'narrative_coherence_score': result.get('narrative_coherence_score', 0),
            'investor_ready_assessment': result.get('investor_ready_assessment', 'needs_work'),
            'pitch_analysis_complete': True
        }
    except Exception as e:
        raise ValueError(f"Pitch quality analysis failed: {str(e)}")
