#!/usr/bin/env python3
"""
Risk Evaluator Node - LangGraph node wrapper for risk assessment LLM
"""

from state import StartupViabilityState
from agents.risk_evaluator_llm import RiskEvaluatorLLMAgent
from typing import Dict, Any


def risk_evaluator_node(state: StartupViabilityState, client=None) -> dict:
    """Evaluates risks using LLM agent."""
    try:
        startup_data = state.get('parsed_startup', {})
        startup_data['financial_viability_score'] = state.get('financial_viability_score', 0)
        startup_data['team_strength_score'] = state.get('team_strength_score', 0)
        startup_data['market_opportunity_score'] = state.get('market_opportunity_score', 0)

        agent = RiskEvaluatorLLMAgent(client=client)
        result = agent.evaluate_risks(startup_data)

        return {
            'overall_risk_rating': result.get('overall_risk_rating', 'Medium'),
            'risk_dimensions': result.get('risk_dimensions', {}),
            'critical_risk_areas': result.get('critical_risk_areas', []),
            'risk_mitigation_strategies': result.get('risk_mitigation_strategies', {}),
            'risk_management_priorities': result.get('risk_management_priorities', []),
            'risk_analysis_complete': True
        }
    except Exception as e:
        raise ValueError(f"Risk evaluation failed: {str(e)}")
