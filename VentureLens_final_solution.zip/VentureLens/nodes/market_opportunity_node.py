#!/usr/bin/env python3
"""
Market Opportunity Node - LangGraph node wrapper for market analysis LLM
"""

from state import StartupViabilityState
from agents.market_opportunity_assessor_llm import MarketOpportunityAssessorLLMAgent
from typing import Dict, Any


def market_opportunity_node(state: StartupViabilityState, client=None) -> dict:
    """Analyzes market opportunity using LLM agent."""
    try:
        startup_data = state.get('parsed_startup', {})
        startup_data['financial_viability_score'] = state.get('financial_viability_score', 0)
        startup_data['team_strength_score'] = state.get('team_strength_score', 0)

        agent = MarketOpportunityAssessorLLMAgent(client=client)
        result = agent.assess_market_opportunity(startup_data)

        return {
            'market_opportunity_assessment': result.get('market_opportunity_assessment', ''),
            'tam_validation': result.get('tam_validation', {}),
            'competitive_landscape': result.get('competitive_landscape', {}),
            'market_trends': result.get('market_trends', []),
            'market_growth_potential': result.get('market_growth_potential', 0),
            'market_risks': result.get('market_risks', []),
            'market_opportunities': result.get('market_opportunities', []),
            'market_opportunity_score': result.get('market_growth_potential', 0),
            'market_analysis_complete': True
        }
    except Exception as e:
        raise ValueError(f"Market opportunity analysis failed: {str(e)}")
