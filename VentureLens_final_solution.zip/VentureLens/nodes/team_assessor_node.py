#!/usr/bin/env python3
"""
Team Assessor Node - LangGraph node wrapper for team ML analysis
"""

from state import StartupViabilityState
from agents.team_assessor_ml import TeamAssessorMLAgent
from typing import Dict, Any


def team_assessor_node(state: StartupViabilityState, client=None) -> dict:
    """Assesses team competitiveness using ML model."""
    try:
        startup_data = state.get('parsed_startup', {})
        agent = TeamAssessorMLAgent(model_dir="ml/models")
        result = agent.assess_team_competitiveness(startup_data)

        return {
            'team_strength_score': result.get('strength_score', 0),
            'team_strength_class': result.get('strength_class', 'Unknown'),
            'team_confidence': result.get('confidence', 0),
            'team_analysis_complete': True
        }
    except Exception as e:
        return {
            'team_strength_score': 0,
            'team_strength_class': 'Unknown',
            'team_confidence': 0,
            'team_analysis_complete': False,
            'validation_errors': [str(e)]
        }
