#!/usr/bin/env python3
"""
Form Parser Node - LangGraph node for form input validation and normalization

TODO: Implement LangGraph node function for form parsing
REFERENCE: /Users/balamurale/Downloads/LangHackthon/InvestPulse/nodes/property_parser_node.py
"""

from state import StartupViabilityState
from typing import Dict, Any


def form_parser_node(state: StartupViabilityState, client=None) -> dict:
    """Validates and normalizes form input data."""
    errors = []
    parsed_startup = {}

    required_fields = {
        'startup_name': (str, lambda x: len(x.strip()) > 0),
        'industry': (str, lambda x: x in ["SaaS", "FinTech", "HealthTech", "EdTech", "AgriTech", "RetailTech", "GreenTech", "AutoTech", "LogTech", "CyberSec"]),
        'location': (str, lambda x: len(x.strip()) > 0),
        'business_stage': (str, lambda x: x in ["Pre-Revenue", "Early", "Growth", "Scale"]),
        'current_funding_round': (str, lambda x: x in ["Bootstrapped", "Pre-Seed", "Seed", "Series A", "Series B", "Series C+"]),
        'product_description': (str, lambda x: len(x.strip()) > 0),
        'problem_addressed': (str, lambda x: len(x.strip()) > 0),
        'target_market_size': (float, lambda x: x > 0),
        'tam_sam_som_assessment': (str, lambda x: x in ["Conservative", "Moderate", "Aggressive"]),
        'competitive_advantage': (str, lambda x: len(x.strip()) > 0),
        'ceo_name': (str, lambda x: len(x.strip()) > 0),
        'ceo_experience_years': (float, lambda x: x >= 0),
        'team_size': (int, lambda x: x > 0),
        'current_funding_round': (str, lambda x: True),
        'target_funding_amount': (float, lambda x: x > 0),
        'elevator_pitch': (str, lambda x: 50 <= len(x.strip()) <= 200),
    }

    for field, (expected_type, validator) in required_fields.items():
        if field not in state or state[field] is None:
            if field == 'elevator_pitch':
                errors.append(f"{field} is required")
            continue

        value = state[field]
        try:
            if not validator(value):
                errors.append(f"{field} validation failed")
            else:
                parsed_startup[field] = value
        except:
            errors.append(f"{field} has invalid value")

    optional_fields = ['mrr', 'arr', 'runway_months', 'monthly_burn_rate', 'cac', 'ltv',
                      'customer_count', 'revenue_growth_rate', 'churn_rate',
                      'ceo_has_previous_exit', 'ceo_education_level', 'technical_cofounder_count',
                      'avg_tech_experience_years', 'non_technical_roles_filled',
                      'members_with_startup_experience', 'industry_domain_expertise_years',
                      'founder_diversity_score', 'team_tenure_together_years', 'total_raised_to_date']

    for field in optional_fields:
        if field in state and state[field] is not None:
            parsed_startup[field] = state[field]

    return {
        'parsed_startup': parsed_startup,
        'validation_errors': errors,
        'parsing_complete': len(errors) == 0,
        'error_occurred': len(errors) > 0
    }
