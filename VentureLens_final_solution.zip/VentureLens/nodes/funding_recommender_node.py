#!/usr/bin/env python3
"""
Funding Recommender Node - LangGraph node wrapper for funding strategy LLM
"""

from state import StartupViabilityState
from agents.funding_recommender_llm import FundingRecommenderLLMAgent
from typing import Dict, Any


def funding_recommender_node(state: StartupViabilityState, client=None) -> dict:
    """Generates funding recommendations using LLM agent."""
    try:
        startup_data = state.get('parsed_startup', {})
        startup_data['financial_viability_score'] = state.get('financial_viability_score', 0)
        startup_data['team_strength_score'] = state.get('team_strength_score', 0)
        startup_data['market_opportunity_score'] = state.get('market_opportunity_score', 0)
        startup_data['pitch_quality_score'] = state.get('pitch_quality_score', 0)
        startup_data['overall_risk_rating'] = state.get('overall_risk_rating', 'Medium')

        agent = FundingRecommenderLLMAgent(client=client)
        result = agent.generate_funding_recommendations(startup_data)

        return {
            'funding_readiness_score': result.get('funding_readiness_score', 0),
            'recommended_funding_round': result.get('recommended_next_round', 'Unknown'),
            'funding_readiness_assessment': result.get('funding_readiness_assessment', ''),
            'funding_timeline': result.get('funding_timeline', {}),
            'valuation_guidance': result.get('valuation_guidance', {}),
            'investor_targeting_strategy': result.get('investor_targeting_strategy', {}),
            'pitch_improvements_for_investors': result.get('pitch_improvements_for_investors', []),
            'alternative_funding_options': result.get('alternative_funding_options', []),
            'key_milestones_for_funding': result.get('key_milestones_for_funding', []),
            'red_flags_to_address': result.get('red_flags_to_address', []),
            'recommendations_complete': True
        }
    except Exception as e:
        raise ValueError(f"Funding recommendations failed: {str(e)}")
