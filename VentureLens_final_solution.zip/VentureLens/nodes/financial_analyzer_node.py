#!/usr/bin/env python3
"""
Financial Analyzer Node - LangGraph node wrapper for financial ML analysis
"""

from state import StartupViabilityState
from agents.financial_analyzer_ml import FinancialAnalyzerMLAgent
from typing import Dict, Any


def financial_analyzer_node(state: StartupViabilityState, client=None) -> dict:
    """Analyzes financial viability using ML model."""
    try:
        startup_data = state.get('parsed_startup', {})
        agent = FinancialAnalyzerMLAgent(model_dir="ml/models")
        result = agent.analyze_financial_viability(startup_data)

        return {
            'financial_viability_score': result.get('viability_score', 0),
            'financial_viability_class': result.get('viability_class', 'Unknown'),
            'financial_confidence': result.get('confidence', 0),
            'financial_analysis_complete': True
        }
    except Exception as e:
        return {
            'financial_viability_score': 0,
            'financial_viability_class': 'Unknown',
            'financial_confidence': 0,
            'financial_analysis_complete': False,
            'validation_errors': [str(e)]
        }
