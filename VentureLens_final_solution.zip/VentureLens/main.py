#!/usr/bin/env python3
"""
Streamlit web application UI for VentureLens startup analysis platform
Uses JSON input files for startup data
"""

import streamlit as st
import json
import os
import sys
from pathlib import Path
import pandas as pd
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from graph import analyze_startup, get_startup_summary
    from ml.evaluation.evaluate_models import evaluate_all_models
    from utils.gemini_client import build_gemini_client
except ImportError:
    pass

st.set_page_config(
    page_title="VentureLens",
    page_icon="chart_with_upwards_trend",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for professional styling
st.markdown("""
<style>
    .header-title {
        font-size: 2.5em;
        font-weight: bold;
        color: #2e7d32;
        margin-bottom: 0.5em;
    }
    .header-subtitle {
        font-size: 1.1em;
        color: #555;
        margin-bottom: 1.5em;
    }
    .metric-card {
        padding: 1.5em;
        border-radius: 0.5em;
        background-color: #f8f9fa;
        border-left: 4px solid #2e7d32;
    }
    .section-header {
        font-size: 1.3em;
        font-weight: bold;
        color: #2e7d32;
        margin-top: 1.5em;
        margin-bottom: 1em;
        border-bottom: 2px solid #2e7d32;
        padding-bottom: 0.5em;
    }
</style>
""", unsafe_allow_html=True)


def load_startup_files():
    """Load all startup JSON files from data/input directory"""
    input_dir = Path("data/input")
    if not input_dir.exists():
        return {}

    startups = {}
    for json_file in sorted(input_dir.glob("*.json")):
        try:
            with open(json_file, "r") as f:
                startup_data = json.load(f)
                startup_name = startup_data.get("startup_name", json_file.stem)
                startups[startup_name] = json_file
        except:
            pass

    return startups


def load_startup(file_path):
    """Load startup data from JSON file"""
    try:
        with open(file_path, "r") as f:
            return json.load(f)
    except:
        return None


def render_header():
    """Render application header"""
    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        st.markdown('<div class="header-title">VentureLens</div>', unsafe_allow_html=True)
        st.markdown('<div class="header-subtitle">Startup Viability & Funding Success Analysis</div>',
                   unsafe_allow_html=True)
    st.divider()


def render_sidebar():
    """Render sidebar with startup selection and controls"""
    with st.sidebar:
        st.header("Configuration")

        startups = load_startup_files()
        if not startups:
            st.warning("No startup files found in data/input/")
            return None

        selected_startup = st.selectbox(
            "Select Startup",
            options=list(startups.keys()),
            key="startup_selector"
        )

        st.divider()
        st.subheader("Tools")

        if st.button("Run Model Evaluation", use_container_width=True, type="secondary"):
            st.session_state.run_evaluation = True

        st.divider()
        st.subheader("About VentureLens")
        st.info("""
        VentureLens analyzes startup viability through:
        - Financial health assessment (ML)
        - Team capability evaluation (ML)
        - Market opportunity analysis (LLM)
        - Pitch quality assessment (LLM)
        - Comprehensive risk evaluation (LLM)
        - Strategic funding recommendations (LLM)
        """)

        return startups.get(selected_startup) if selected_startup else None


def render_startup_preview(startup_data):
    """Render startup details preview"""
    if not startup_data:
        return

    with st.expander("Startup Details", expanded=True):
        col1, col2, col3 = st.columns(3)

        with col1:
            st.write("**Startup Name**")
            st.write(startup_data.get('startup_name', 'N/A'))
            st.write("")
            st.write("**Industry**")
            st.write(startup_data.get('industry', 'N/A'))

        with col2:
            st.write("**Location**")
            st.write(startup_data.get('location', 'N/A'))
            st.write("")
            st.write("**Business Stage**")
            st.write(startup_data.get('business_stage', 'N/A'))

        with col3:
            st.write("**Funding Round**")
            st.write(startup_data.get('current_funding_round', 'N/A'))
            st.write("")
            st.write("**Founded**")
            st.write(startup_data.get('founded_date', 'N/A'))


def render_overview_tab(result):
    """Render analysis overview with key metrics"""
    st.markdown('<div class="section-header">Key Metrics</div>', unsafe_allow_html=True)

    col1, col2 = st.columns(2)

    with col1:
        financial_score = result.get("financial_viability_score", 0)
        st.metric(
            "Financial Viability Score",
            f"{financial_score:.0f}/100",
            f"{result.get('financial_viability_class', 'Unknown')}"
        )

        market_score = result.get("market_opportunity_score", 0)
        st.metric(
            "Market Opportunity Score",
            f"{market_score:.0f}/100"
        )

    with col2:
        team_score = result.get("team_strength_score", 0)
        st.metric(
            "Team Strength Score",
            f"{team_score:.0f}/100",
            f"{result.get('team_strength_class', 'Unknown')}"
        )

        risk_rating = result.get("overall_risk_rating", "Unknown")
        st.metric("Overall Risk Rating", risk_rating)

    st.divider()
    st.markdown('<div class="section-header">Funding Recommendation</div>', unsafe_allow_html=True)

    col1, col2 = st.columns(2)
    with col1:
        funding_round = result.get("recommended_funding_round", "Unknown")
        st.info(f"**Recommended Funding Round:** {funding_round}")

    with col2:
        funding_score = result.get("funding_readiness_score", 0)
        st.info(f"**Funding Readiness Score:** {funding_score:.0f}/100")


def render_detailed_insights_tab(result):
    """Render detailed insights with expandable sections"""
    st.markdown('<div class="section-header">Comprehensive Analysis</div>', unsafe_allow_html=True)

    with st.expander("Financial Analysis", expanded=False):
        st.write(f"**Class:** {result.get('financial_viability_class', 'N/A')}")
        st.write(f"**Score:** {result.get('financial_viability_score', 0):.0f}/100")
        if not result.get('financial_analysis_complete', False):
            errors = result.get('validation_errors', [])
            if errors:
                st.error("Financial analysis incomplete:")
                for err in errors:
                    st.write(f"- {err}")
            else:
                st.warning("Financial analysis could not be completed.")
        else:
            confidence = result.get('financial_confidence')
            if confidence is not None:
                st.write(f"**Confidence:** {confidence:.0%}")

    with st.expander("Team Assessment", expanded=False):
        st.write(f"**Class:** {result.get('team_strength_class', 'N/A')}")
        st.write(f"**Score:** {result.get('team_strength_score', 0):.0f}/100")

    with st.expander("Market Opportunity Analysis", expanded=False):
        st.write(result.get("market_opportunity_assessment", "N/A"))
        if result.get("market_opportunities"):
            st.write("**Opportunities:**")
            for opp in result.get("market_opportunities", []):
                st.write(f"- {opp}")

    with st.expander("Pitch Quality Assessment", expanded=False):
        st.write(f"**Quality Score:** {result.get('pitch_quality_score', 0):.0f}/100")
        st.write(f"**Assessment:** {result.get('pitch_clarity_assessment', 'N/A')}")
        if result.get("investor_ready_assessment"):
            st.write(f"**Investor Readiness:** {result.get('investor_ready_assessment')}")

    with st.expander("Risk Assessment", expanded=False):
        st.write(f"**Overall Rating:** {result.get('overall_risk_rating', 'N/A')}")
        risk_dims = result.get("risk_dimensions", {})
        if risk_dims:
            st.markdown("**Risk Breakdown**")
            for name, info in risk_dims.items():
                score = info.get("score", 0)
                assessment = info.get("assessment", "Not provided")
                st.markdown(f"- **{name.replace('_', ' ').title()}**: {score}/100")
                st.write(f"  {assessment}")

        critical_risks = result.get("critical_risk_areas", [])
        if critical_risks:
            st.markdown("**Critical Risk Areas**")
            for risk in critical_risks:
                st.write(f"- {risk}")

        mitigations = result.get("risk_mitigation_strategies", {})
        if mitigations:
            st.markdown("**Mitigation Strategies**")
            for risk, strategies in mitigations.items():
                st.write(f"- **{risk}**")
                for strat in strategies:
                    st.write(f"  - {strat}")

        priorities = result.get("risk_management_priorities", [])
        if priorities:
            st.markdown("**Risk Management Priorities**")
            for item in priorities:
                rank = item.get("rank", "")
                risk = item.get("risk", "")
                priority = item.get("priority", "")
                st.write(f"- {rank}: {risk} — {priority}")

    with st.expander("Funding Strategy", expanded=False):
        st.write(result.get("funding_readiness_assessment", "N/A"))
        if result.get("key_milestones_for_funding"):
            st.write("**Key Milestones:**")
            for milestone in result.get("key_milestones_for_funding", []):
                st.write(f"- {milestone}")


def render_model_evaluation_section(eval_results):
    """Render ML model evaluation metrics on the main page."""
    st.markdown('<div class="section-header">ML Model Evaluation</div>', unsafe_allow_html=True)
    st.markdown("Performance metrics of trained machine learning models")

    if not eval_results:
        st.info("Click 'Run Model Evaluation' in the sidebar to evaluate trained models.")
        return

    col1, col2 = st.columns(2)

    with col1:
        st.markdown('<div class="section-header">Financial Viability Model</div>', unsafe_allow_html=True)
        fin_eval = eval_results.get("financial_evaluation", {})
        if fin_eval and "error" not in fin_eval:
            st.metric("Accuracy", f"{fin_eval.get('accuracy', 0)*100:.2f}%")
            st.metric("Precision", f"{fin_eval.get('precision', 0)*100:.2f}%")
            st.metric("Recall", f"{fin_eval.get('recall', 0)*100:.2f}%")
            st.metric("F1 Score", f"{fin_eval.get('f1', 0)*100:.2f}%")
            st.metric("Test Samples", fin_eval.get('samples', 0))
        else:
            st.error(f"Error: {fin_eval.get('error', 'Unknown error')}")

    with col2:
        st.markdown('<div class="section-header">Team Competitiveness Model</div>', unsafe_allow_html=True)
        team_eval = eval_results.get("team_evaluation", {})
        if team_eval and "error" not in team_eval:
            st.metric("Accuracy", f"{team_eval.get('accuracy', 0)*100:.2f}%")
            st.metric("Precision", f"{team_eval.get('precision', 0)*100:.2f}%")
            st.metric("Recall", f"{team_eval.get('recall', 0)*100:.2f}%")
            st.metric("F1 Score", f"{team_eval.get('f1', 0)*100:.2f}%")
            st.metric("Test Samples", team_eval.get('samples', 0))
        else:
            st.error(f"Error: {team_eval.get('error', 'Unknown error')}")

    st.divider()
    with st.expander("View Raw Evaluation Data"):
        st.json(eval_results)


def main():
    """Main application logic"""
    if "analysis_results" not in st.session_state:
        st.session_state.analysis_results = None

    if "eval_results" not in st.session_state:
        st.session_state.eval_results = None

    if "run_analysis" not in st.session_state:
        st.session_state.run_analysis = False

    if "run_evaluation" not in st.session_state:
        st.session_state.run_evaluation = False

    render_header()
    startup_file = render_sidebar()

    if startup_file is None:
        st.warning("Please select a startup from the sidebar")
        return

    startup_data = load_startup(startup_file)
    if startup_data is None:
        st.error("Failed to load startup data")
        return

    render_startup_preview(startup_data)

    if st.button("Run Startup Analysis", use_container_width=True, type="primary"):
        st.session_state.run_analysis = True

    # Handle startup analysis
    if st.session_state.run_analysis:
        try:
            with st.spinner("Running comprehensive startup analysis..."):
                try:
                    llm_client = build_gemini_client()
                except Exception as e:
                    st.error(f"LLM client not configured: {e}")
                    st.session_state.run_analysis = False
                    return

                st.session_state.analysis_results = analyze_startup(startup_data, llm_client)
                st.success("Analysis complete!")
                st.session_state.run_analysis = False
        except Exception as e:
            st.error(f"Analysis failed: {str(e)}")
            st.session_state.run_analysis = False

    # Handle model evaluation trigger from sidebar
    if st.session_state.run_evaluation:
        try:
            with st.spinner("Evaluating models..."):
                eval_results = evaluate_all_models()
                st.session_state.eval_results = eval_results
                st.success("Model evaluation complete!")
        except Exception as e:
            st.error(f"Evaluation failed: {str(e)}")
        finally:
            st.session_state.run_evaluation = False

    # Create tabs for different views (without model evaluation)
    tab1, tab2 = st.tabs([
        "Overview",
        "Detailed Insights"
    ])

    with tab1:
        if st.session_state.analysis_results:
            render_overview_tab(st.session_state.analysis_results)

            st.divider()
            st.markdown('<div class="section-header">Export Analysis</div>', unsafe_allow_html=True)

            col1, col2 = st.columns(2)
            with col1:
                json_str = json.dumps(st.session_state.analysis_results, indent=2)
                st.download_button(
                    label="Download JSON Report",
                    data=json_str,
                    file_name=f"venturelens_{startup_data.get('startup_name', 'analysis')}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
                    mime="application/json",
                    use_container_width=True
                )

            with col2:
                df = pd.DataFrame([st.session_state.analysis_results])
                csv = df.to_csv(index=False)
                st.download_button(
                    label="Download CSV Report",
                    data=csv,
                    file_name=f"venturelens_{startup_data.get('startup_name', 'analysis')}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                    mime="text/csv",
                    use_container_width=True
                )
        else:
            st.info("Click 'Run Startup Analysis' to analyze the selected startup")

    with tab2:
        if st.session_state.analysis_results:
            render_detailed_insights_tab(st.session_state.analysis_results)
        else:
            st.info("Run analysis to view detailed insights")

    st.divider()
    render_model_evaluation_section(st.session_state.get("eval_results"))


if __name__ == "__main__":
    main()
