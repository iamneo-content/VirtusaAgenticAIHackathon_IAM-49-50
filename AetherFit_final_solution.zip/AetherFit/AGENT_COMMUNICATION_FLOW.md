AETHERFIT PROJECT: AGENT-TO-AGENT COMMUNICATION FLOW
====================================================

graph TD
    Start([User Input Form Submitted]) --> FPA[FormParserAgent<br/>Input Validation]

    FPA -->|Age,Height,Weight Valid<br/>BMI Calculated<br/>Categories Derived| FPASuccess{Parsing<br/>Complete?}
    FPA -->|Invalid Input<br/>Validation Failed| FPAFail[Validation Error<br/>Skip Assessment]

    FPASuccess -->|YES| NormState[State Updated:<br/>BMI, Age Category,<br/>BMI Category]
    FPASuccess -->|NO| FPAFail

    FPAFail --> End([Assessment Failed<br/>Display Errors])

    NormState --> INA[InputNormalizerLLMAgent<br/>Natural Language Processing]

    INA -->|Parse Fitness Experience<br/>Parse Health Conditions<br/>Parse Schedule| INASuccess{Normalization<br/>Complete?}
    INA -->|LLM Processing Failed| INAFail[Normalization Error<br/>Use Defaults]

    INASuccess -->|YES| NormalizedState[State Updated:<br/>Normalized Inputs<br/>Preferred Days/Times<br/>Severity Assessment]
    INAFail --> NormalizedState

    NormalizedState --|State Contains:<br/>Age, BMI,<br/>Fitness Level Encoded,<br/>Injury Risk Factors<br/>Preferred Schedule| ParallelSplit{Execute ML Models<br/>in Parallel}

    ParallelSplit -->|Branch 1| FSA[FitnessScorerMLAgent<br/>RandomForest Prediction]
    ParallelSplit -->|Branch 2| IAA[InjuryAssessorMLAgent<br/>RandomForest Prediction]

    FSA -->|Load 11 Features<br/>Encode Categoricals<br/>Scale Numerics<br/>Predict Class| FSASuccess{Fitness Prediction<br/>Complete?}
    FSA -->|Model Load Failed<br/>Prediction Error| FSAFail[Use Default<br/>Confidence = 0]

    FSASuccess -->|YES| FitnessOutput[Output:<br/>Fitness Level Class<br/>Confidence Score<br/>Fitness Analysis Complete]
    FSASuccess -->|NO| FSAFail
    FSAFail --> FitnessOutput

    IAA -->|Load 12 Features<br/>Encode Categoricals<br/>Calculate Risk Factors<br/>Predict Class| IAASuccess{Injury Prediction<br/>Complete?}
    IAA -->|Model Load Failed<br/>Prediction Error| IAFFail[Use Default<br/>Confidence = 0]

    IAASuccess -->|YES| InjuryOutput[Output:<br/>Injury Risk Class<br/>Confidence Score<br/>Risk Factors List<br/>Injury Assessment Complete]
    IAASuccess -->|NO| IAFFail
    IAFFail --> InjuryOutput

    FitnessOutput --> MergeMLState[LangGraph Merges<br/>Both Outputs into State]
    InjuryOutput --> MergeMLState

    MergeMLState --|State Now Contains:<br/>Fitness Level Class<br/>Injury Risk Class<br/>All Risk Factors<br/>User Constraints| WPA[WorkoutPlanGeneratorLLMAgent<br/>Personalized Workout Planning]

    WPA -->|Input: Fitness Level<br/>Injury Risk<br/>Available Hours<br/>Preferred Days/Times<br/>Health Conditions| WPASuccess{Workout Plan<br/>Generated?}
    WPA -->|LLM Request Failed<br/>JSON Parse Error| WPAFail[No Workout Plan<br/>Error Message Logged]

    WPASuccess -->|YES| WorkoutOutput[Output:<br/>Weekly Schedule<br/>Exercise Details<br/>Intensity Level<br/>Frequency<br/>Safety Notes<br/>Equipment List]
    WPASuccess -->|NO| WPAFail
    WPAFail --> WorkoutOutput

    WorkoutOutput --|State Now Contains:<br/>Workout Plan<br/>Weekly Schedule<br/>Intensity Level| NAA[NutritionPlanGeneratorLLMAgent<br/>Personalized Nutrition Planning]

    NAA -->|Input: Age<br/>Weight, Height<br/>Gender<br/>Fitness Level<br/>Workout Frequency<br/>Fitness Goal| NAASuccess{Nutrition Plan<br/>Generated?}
    NAA -->|LLM Request Failed<br/>Indian Foods<br/>Not Provided| NAAFail[No Nutrition Plan<br/>Use Generic]

    NAASuccess -->|YES| NutritionOutput[Output:<br/>Calorie Target<br/>Macro Targets<br/>Meal Suggestions<br/>Indian Food Options<br/>Hydration Guide<br/>Timing Guidance]
    NAASuccess -->|NO| NAAFail
    NAAFail --> NutritionOutput

    NutritionOutput --|State Now Contains:<br/>Nutrition Plan<br/>Daily Calorie Target<br/>Macro Targets<br/>Meal Suggestions| RLO[RecoveryLifestyleOptimizerLLMAgent<br/>Recovery & Lifestyle Planning]

    RLO -->|Input: Age<br/>Fitness Level<br/>Injury Risk<br/>Health Conditions<br/>Available Hours<br/>Preferred Days/Times<br/>Fitness Goal| RLOSuccess{Recovery Plan<br/>Generated?}
    RLO -->|LLM Request Failed<br/>Lifestyle Integration Error| RLOFail[No Recovery Plan<br/>Partial Strategy]

    RLOSuccess -->|YES| RecoveryOutput[Output:<br/>Sleep Recommendations<br/>Rest Activities<br/>Mobility Work<br/>Stress Management<br/>Recovery Techniques<br/>Deload Strategy<br/>Schedule Integration<br/>Habit Strategies<br/>Adherence Tips]
    RLOSuccess -->|NO| RLOFail
    RLOFail --> RecoveryOutput

    RecoveryOutput --> CompleteState[Final State Complete<br/>All 85 Fields Populated]

    CompleteState --> ResultsGeneration[Results Generation<br/>Extract by Category]

    ResultsGeneration --> UIDisplay[Display in 4 Tabs<br/>Overview<br/>Workout Plan<br/>Nutrition Plan<br/>Recovery & Lifestyle]

    UIDisplay --> End

    style Start fill:#e1f5ff,stroke:#01579b,stroke-width:3px
    style FPA fill:#bbdefb,stroke:#0d47a1,stroke-width:2px
    style FPASuccess fill:#90caf9,stroke:#1a237e,stroke-width:2px
    style FPAFail fill:#ffcdd2,stroke:#b71c1c,stroke-width:2px,stroke-dasharray: 5 5

    style NormState fill:#c8e6c9,stroke:#1b5e20,stroke-width:2px
    style INA fill:#ffe0b2,stroke:#e65100,stroke-width:2px
    style INASuccess fill:#ffcc80,stroke:#bf360c,stroke-width:2px
    style INAFail fill:#ffccbc,stroke:#d84315,stroke-width:2px,stroke-dasharray: 5 5

    style NormalizedState fill:#c8e6c9,stroke:#1b5e20,stroke-width:2px
    style ParallelSplit fill:#f8bbd0,stroke:#880e4f,stroke-width:3px

    style FSA fill:#d1c4e9,stroke:#311b92,stroke-width:2px
    style FSASuccess fill:#b39ddb,stroke:#512da8,stroke-width:2px
    style FSAFail fill:#ffcdd2,stroke:#b71c1c,stroke-width:2px,stroke-dasharray: 5 5
    style FitnessOutput fill:#ce93d8,stroke:#6a1b9a,stroke-width:2px

    style IAA fill:#d1c4e9,stroke:#311b92,stroke-width:2px
    style IAASuccess fill:#b39ddb,stroke:#512da8,stroke-width:2px
    style IAFFail fill:#ffcdd2,stroke:#b71c1c,stroke-width:2px,stroke-dasharray: 5 5
    style InjuryOutput fill:#ce93d8,stroke:#6a1b9a,stroke-width:2px

    style MergeMLState fill:#b2dfdb,stroke:#00695c,stroke-width:3px

    style WPA fill:#fff9c4,stroke:#f57f17,stroke-width:2px
    style WPASuccess fill:#ffe082,stroke:#f9a825,stroke-width:2px
    style WPAFail fill:#ffcdd2,stroke:#b71c1c,stroke-width:2px,stroke-dasharray: 5 5
    style WorkoutOutput fill:#ffcc80,stroke:#ef6c00,stroke-width:2px

    style NAA fill:#c8e6c9,stroke:#1b5e20,stroke-width:2px
    style NAASuccess fill:#a5d6a7,stroke:#2e7d32,stroke-width:2px
    style NAAFail fill:#ffcdd2,stroke:#b71c1c,stroke-width:2px,stroke-dasharray: 5 5
    style NutritionOutput fill:#81c784,stroke:#388e3c,stroke-width:2px

    style RLO fill:#e1bee7,stroke:#6a1b9a,stroke-width:2px
    style RLOSuccess fill:#ce93d8,stroke:#7b1fa2,stroke-width:2px
    style RLOFail fill:#ffcdd2,stroke:#b71c1c,stroke-width:2px,stroke-dasharray: 5 5
    style RecoveryOutput fill:#ba68c8,stroke:#8e24aa,stroke-width:2px

    style CompleteState fill:#b2dfdb,stroke:#00695c,stroke-width:3px
    style ResultsGeneration fill:#b2dfdb,stroke:#00695c,stroke-width:2px
    style UIDisplay fill:#a5d6a7,stroke:#2e7d32,stroke-width:2px
    style End fill:#fce4ec,stroke:#880e4f,stroke-width:3px

AGENT COMMUNICATION LEGEND
==========================

AGENT TYPES:
  BLUE Nodes    = Input Validation Agent (FormParserAgent)
  ORANGE Nodes  = NLP Agent (InputNormalizerLLMAgent)
  PURPLE Nodes  = ML Agents (FitnessScorerMLAgent, InjuryAssessorMLAgent)
  YELLOW Nodes  = LLM Planning Agent 1 (WorkoutPlanGeneratorLLMAgent)
  GREEN Nodes   = LLM Planning Agent 2 (NutritionPlanGeneratorLLMAgent)
  PURPLE Nodes  = LLM Planning Agent 3 (RecoveryLifestyleOptimizerLLMAgent)

COMMUNICATION TYPES:
  Solid Arrow   = Successful Data Flow
  Dashed Arrow  = Error/Fallback Path
  Diamond       = Decision Point / Conditional Logic

DATA FLOW SEQUENCE:
===================

PHASE 1: INPUT VALIDATION
  FormParserAgent receives raw user input
  Validates all fields against constraints
  Calculates derived metrics (BMI, age_category, bmi_category)
  Returns parsed_profile and validation_errors
  Proceeds only if parsing_complete = True

PHASE 2: NATURAL LANGUAGE PROCESSING
  InputNormalizerLLMAgent receives validated state
  Takes 3 string inputs: fitness_experience, health_conditions, available_hours_per_week
  Calls Google Gemini API to parse natural language
  Extracts structured data: experience_level, years_active, conditions_list,
                            severity, exercise_limitations, cleared_for_exercise,
                            estimated_hours, preferred_days, preferred_times
  Updates state with normalized_* fields

PHASE 3: PARALLEL MACHINE LEARNING PREDICTIONS
  Both agents execute simultaneously using thread-level parallelism

  FitnessScorerMLAgent:
    Receives: user profile with 11 features
    Loads: RandomForest model, StandardScaler, LabelEncoders from pickle
    Encodes categorical features (gender, experience, age_category, etc.)
    Scales numeric features (age, bmi, weight, available_hours, etc.)
    Predicts fitness_level_class using RandomForest
    Calculates confidence from prediction probabilities
    Returns: fitness_level_class, fitness_level_score, fitness_confidence

  InjuryAssessorMLAgent:
    Receives: user profile with 12 features
    Loads: RandomForest model, StandardScaler, LabelEncoders from pickle
    Encodes categorical features
    Scales numeric features
    Derives additional features: flexibility_score, strength_imbalance, training_frequency
    Predicts injury_risk_class using RandomForest
    Generates risk_factors list based on profile attributes
    Returns: injury_risk_class, injury_risk_score, confidence, injury_risk_factors

  StateGraph merges both outputs into unified state

PHASE 4: SEQUENTIAL WORKOUT PLANNING
  WorkoutPlanGeneratorLLMAgent receives merged state containing:
    - fitness_level_class (from fitness_scorer)
    - injury_risk_class (from injury_assessor)
    - available_hours_per_week (from input)
    - preferred_days, preferred_times (from input_normalizer)
    - health_conditions (from form)

  Constructs comprehensive prompt for Google Gemini including:
    User fitness level (determines exercise difficulty)
    Injury risk level (determines modifications needed)
    Available hours per week (determines session count and duration)
    Preferred days and times (determines schedule)
    Health conditions (determines exercises to avoid)

  LLM generates detailed weekly schedule respecting all constraints
  Returns: weekly_schedule (nested dict with day -> exercises list),
           workout_intensity_level, workout_duration_per_session,
           workout_frequency_per_week, progression_timeline, safety_notes,
           equipment_needed

PHASE 5: SEQUENTIAL NUTRITION PLANNING
  NutritionPlanGeneratorLLMAgent receives state containing:
    - age, weight_kg, height_cm (for calorie calculation)
    - fitness_level_class (for macro distribution)
    - workout_frequency_per_week (for activity multiplier)
    - fitness_goal (for macro ratios)

  Constructs prompt requesting nutrition plan with INDIAN FOOD OPTIONS
  LLM generates personalized nutrition including:
    Daily calorie target (using Harris-Benedict equation)
    Macro targets (protein, carbs, fat in grams)
    3-5 meal suggestions with Indian foods:
      Each meal includes: meal_name, foods_list, protein_g, carbs_g, fat_g, calories
    Hydration recommendation
    Pre/post-workout nutrition timing

  Returns: daily_calorie_target, macro_targets, meal_suggestions,
           hydration_recommendation, nutrition_timing_guidance

PHASE 6: SEQUENTIAL RECOVERY & LIFESTYLE PLANNING
  RecoveryLifestyleOptimizerLLMAgent receives complete state containing:
    - age, fitness_level_class, injury_risk_class (for risk assessment)
    - health_conditions (for special considerations)
    - available_hours_per_week, preferred_days, preferred_times (for schedule)
    - All previous outputs (for integrated planning)

  Constructs comprehensive prompt requesting recovery and lifestyle strategies
  LLM generates personalized recovery plan including:
    Sleep recommendations (hours, quality tips)
    Rest day activities
    Mobility work routines
    Stress management techniques
    Recovery techniques (foam rolling, massage, etc.)
    Deload strategy (periodization)
    Schedule integration (best days/times)
    Time management strategies
    Habit formation approaches
    Adherence and motivation tips

  Returns: All recovery_* and lifestyle_* fields

PHASE 7: RESULT COMPILATION & DISPLAY
  Final state contains all 85 fields populated
  UI extracts fields by category
  Displays in 4 tabs: Overview, Workout Plan, Nutrition Plan, Recovery & Lifestyle
  Optional: Generate and save complete assessment as JSON export


ERROR HANDLING IN COMMUNICATION:
================================

VALIDATION ERRORS (FormParserAgent):
  If input validation fails, assessment stops
  Error messages displayed to user
  User can revise inputs and resubmit

NORMALIZATION ERRORS (InputNormalizerLLMAgent):
  If LLM fails to parse natural language, uses defaults
  Workflow continues with generic normalized values
  User may need to re-enter in clearer format

ML PREDICTION ERRORS (Fitness & Injury Agents):
  If model fails to load or predict, uses default confidence = 0%
  Error logged but workflow continues
  Subsequent agents use None/default values for predictions

LLM GENERATION ERRORS (Workout/Nutrition/Recovery Agents):
  If API call fails, returns empty/default response
  Error message added to error_messages list
  UI displays "Personalized plan pending" message
  User can retry evaluation from sidebar

STATE MERGING ERRORS:
  LangGraph framework handles automatic state merging
  If conflicting updates occur, later value overwrites
  All error paths update completion flags to False


AGENT DEPENDENCIES:
===================

FormParserAgent:
  Dependencies: None (first in pipeline)
  Provides: BMI, age_category, bmi_category to all downstream agents

InputNormalizerLLMAgent:
  Dependencies: FormParserAgent (requires validated state)
  Requires: External Gemini API connection
  Provides: normalized_fitness_experience, normalized_health_conditions,
            normalized_schedule to all downstream agents

FitnessScorerMLAgent:
  Dependencies: FormParserAgent (for base metrics)
  Requires: fitness_level_model.pkl, fitness_level_scaler.pkl,
            fitness_level_encoder.pkl files
  Provides: fitness_level_class, fitness_confidence to WorkoutPlannerAgent,
            RecoveryOptimizerAgent

InjuryAssessorMLAgent:
  Dependencies: FormParserAgent (for base metrics)
  Requires: injury_risk_model.pkl, injury_risk_scaler.pkl,
            injury_risk_encoder.pkl files
  Provides: injury_risk_class, injury_risk_factors to WorkoutPlannerAgent,
            RecoveryOptimizerAgent

WorkoutPlanGeneratorLLMAgent:
  Dependencies: FitnessScorerMLAgent, InjuryAssessorMLAgent (fitness/injury levels),
                InputNormalizerLLMAgent (schedule preferences)
  Requires: External Gemini API connection
  Provides: weekly_schedule, workout_intensity_level, workout_frequency_per_week,
            equipment_needed to RecoveryOptimizerAgent

NutritionPlanGeneratorLLMAgent:
  Dependencies: FitnessScorerMLAgent (fitness_level_class)
  Requires: External Gemini API connection
  Provides: daily_calorie_target, meal_suggestions (no downstream dependencies)

RecoveryLifestyleOptimizerLLMAgent:
  Dependencies: All previous agents (comprehensive profile needed)
  Requires: External Gemini API connection
  Provides: Final recovery and lifestyle recommendations (end of pipeline)


COMMUNICATION PROTOCOL:
=======================

STATE AS MESSAGE MEDIUM:
  Agents communicate through shared FitnessAssessmentState
  No direct agent-to-agent method calls
  Updates propagated through StateGraph framework

DATA VALIDATION:
  Each agent validates received state data
  Missing required fields trigger error handling
  Type conversions handled within agents

ERROR PROPAGATION:
  Errors don't stop workflow, only set completion flags to False
  Error messages accumulated in error_messages list
  Downstream agents use None/default values when upstream fails

CONCURRENT COMMUNICATION:
  FitnessScorerMLAgent and InjuryAssessorMLAgent communicate in parallel
  StateGraph framework handles thread-safe state merging
  No blocking between parallel agents

SEQUENTIAL COMMUNICATION:
  All other agents communicate in strict order
  Each agent waits for upstream agent results before executing
  Ensures data dependencies are met

API COMMUNICATION:
  Three agents (InputNormalizer, WorkoutPlanner, Nutrition, Recovery)
  Call external Google Gemini API
  Use GeminiClient wrapper for key rotation and error handling
  Support up to 4 API keys with automatic rotation on quota exceeded

END OF AGENT COMMUNICATION FLOW DOCUMENTATION
===============================================
