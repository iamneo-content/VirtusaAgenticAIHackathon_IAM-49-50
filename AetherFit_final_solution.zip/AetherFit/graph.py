"""Main graph interface for fitness assessment."""

from datetime import datetime
from typing import Dict, Any
from uuid import uuid4
from workflow.workflow import build_fitness_assessment_graph, get_workflow_structure
from state import FitnessAssessmentState, get_initial_state


def assess_fitness(
    age: int,
    height_cm: float,
    weight_kg: float,
    gender: str,
    fitness_goal: str,
    fitness_experience: str,
    health_conditions: str,
    available_hours_per_week: str,
    client=None,
    user_name: str = None
) -> Dict[str, Any]:
    """
    Run complete fitness assessment workflow.

    This is the main entry point for the application. It executes the 7-node
    fitness assessment workflow and returns comprehensive plan.

    Args:
        age: User age in years
        height_cm: User height in centimeters
        weight_kg: User weight in kilograms
        gender: User gender (Male/Female/Other)
        fitness_goal: Fitness goal (Weight Loss/Muscle Building/Endurance/General Fitness)
        fitness_experience: Fitness experience as natural language string
        health_conditions: Health conditions as natural language string
        available_hours_per_week: Available hours per week as natural language string
        client: Gemini API client for LLM operations
        user_name: Optional user name

    Returns:
        Dictionary with complete fitness assessment results including:
        - User profile (input + derived metrics)
        - ML predictions (fitness level, injury risk)
        - LLM-generated plans (workout, nutrition, recovery/lifestyle)
        - System metadata
    """
    # Prepare form data
    form_data = {
        'age': age,
        'height_cm': height_cm,
        'weight_kg': weight_kg,
        'gender': gender,
        'fitness_goal': fitness_goal,
        'fitness_experience': fitness_experience,
        'health_conditions': health_conditions,
        'available_hours_per_week': available_hours_per_week,
        'user_name': user_name,
    }

    # Initialize state with form data
    state = get_initial_state(form_data)

    # Add system metadata
    state['plan_id'] = str(uuid4())
    state['analysis_timestamp'] = datetime.now().isoformat()

    # Build and run graph
    graph = build_fitness_assessment_graph(client)

    try:
        # Execute workflow
        final_state = graph.invoke(state)
        final_state['plan_generated'] = True
        return final_state

    except Exception as e:
        # Handle workflow execution errors
        state['error_occurred'] = True
        state['error_messages'].append(f"Workflow execution error: {str(e)}")
        state['plan_generated'] = False
        return state


def get_assessment_summary(assessment_result: Dict[str, Any]) -> Dict[str, Any]:
    """
    Extract summary from complete assessment result.

    Args:
        assessment_result: Result from assess_fitness()

    Returns:
        Dictionary with assessment summary
    """
    summary = {
        'user_profile': {
            'age': assessment_result.get('age'),
            'height_cm': assessment_result.get('height_cm'),
            'weight_kg': assessment_result.get('weight_kg'),
            'gender': assessment_result.get('gender'),
            'bmi': assessment_result.get('bmi'),
            'fitness_goal': assessment_result.get('fitness_goal'),
        },
        'derived_metrics': {
            'age_category': assessment_result.get('age_category'),
            'bmi_category': assessment_result.get('bmi_category'),
        },
        'assessments': {
            'fitness_level': {
                'class': assessment_result.get('fitness_level_class'),
                'score': assessment_result.get('fitness_level_score'),
                'confidence': assessment_result.get('fitness_confidence'),
            },
            'injury_risk': {
                'class': assessment_result.get('injury_risk_class'),
                'score': assessment_result.get('injury_risk_score'),
                'confidence': assessment_result.get('injury_confidence'),
                'factors': assessment_result.get('injury_risk_factors', []),
            },
        },
        'plans': {
            'workout': {
                'frequency_per_week': assessment_result.get('workout_frequency_per_week'),
                'intensity_level': assessment_result.get('workout_intensity_level'),
                'duration_per_session': assessment_result.get('workout_duration_per_session'),
                'equipment_needed': assessment_result.get('workout_equipment_needed', []),
                'analysis_complete': assessment_result.get('workout_analysis_complete', False),
            },
            'nutrition': {
                'daily_calorie_target': assessment_result.get('daily_calorie_target'),
                'macro_targets': assessment_result.get('macro_targets'),
                'analysis_complete': assessment_result.get('nutrition_analysis_complete', False),
            },
            'recovery_lifestyle': {
                'sleep_recommendations': assessment_result.get('sleep_recommendations'),
                'deload_strategy': assessment_result.get('deload_strategy'),
                'schedule_integration': assessment_result.get('schedule_integration'),
                'analysis_complete': assessment_result.get('recovery_lifestyle_analysis_complete', False),
            },
        },
        'system': {
            'plan_id': assessment_result.get('plan_id'),
            'timestamp': assessment_result.get('analysis_timestamp'),
            'plan_generated': assessment_result.get('plan_generated', False),
            'error_occurred': assessment_result.get('error_occurred', False),
            'error_messages': assessment_result.get('error_messages', []),
        }
    }
    return summary


def get_workout_plan_details(assessment_result: Dict[str, Any]) -> Dict[str, Any]:
    """Extract detailed workout plan from assessment result."""
    return {
        'weekly_schedule': assessment_result.get('weekly_schedule'),
        'intensity_level': assessment_result.get('workout_intensity_level'),
        'duration_per_session': assessment_result.get('workout_duration_per_session'),
        'frequency_per_week': assessment_result.get('workout_frequency_per_week'),
        'progression_timeline': assessment_result.get('workout_progression_timeline'),
        'safety_notes': assessment_result.get('workout_safety_notes', []),
        'equipment_needed': assessment_result.get('workout_equipment_needed', []),
    }


def get_nutrition_plan_details(assessment_result: Dict[str, Any]) -> Dict[str, Any]:
    """Extract detailed nutrition plan from assessment result."""
    return {
        'daily_calorie_target': assessment_result.get('daily_calorie_target'),
        'macro_targets': assessment_result.get('macro_targets'),
        'meal_suggestions': assessment_result.get('meal_suggestions', []),
        'hydration_recommendation': assessment_result.get('hydration_recommendation'),
        'nutrition_timing_guidance': assessment_result.get('nutrition_timing_guidance'),
    }


def get_recovery_lifestyle_details(assessment_result: Dict[str, Any]) -> Dict[str, Any]:
    """Extract detailed recovery and lifestyle plan from assessment result."""
    return {
        'sleep_recommendations': assessment_result.get('sleep_recommendations'),
        'rest_day_activities': assessment_result.get('rest_day_activities', []),
        'mobility_work': assessment_result.get('mobility_work', []),
        'stress_management_techniques': assessment_result.get('stress_management_techniques', []),
        'recovery_techniques': assessment_result.get('recovery_techniques', []),
        'deload_strategy': assessment_result.get('deload_strategy'),
        'schedule_integration': assessment_result.get('schedule_integration'),
        'time_management_tips': assessment_result.get('time_management_tips', []),
        'habit_formation_strategies': assessment_result.get('habit_formation_strategies', []),
        'adherence_tips': assessment_result.get('adherence_tips', []),
    }


def get_workflow_info() -> Dict[str, Any]:
    """Get information about the fitness assessment workflow."""
    return get_workflow_structure()
