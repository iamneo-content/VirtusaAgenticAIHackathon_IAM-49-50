===============================================================================
                    AETHERFIT PROJECT DOCUMENTATION
===============================================================================

SECTION 1: PROBLEM STATEMENT & PROJECT DESCRIPTION
===============================================================================

PROJECT TITLE: AetherFit - AI-Powered Personalized Fitness Assessment System

PROBLEM STATEMENT:
-----------------
Many individuals struggle to get accurate fitness assessments and personalized
workout/nutrition/recovery plans due to:

1. Lack of access to professional fitness coaches
2. One-size-fits-all fitness plans that don't account for individual needs
3. Difficulty in understanding natural language fitness goals and health conditions
4. Need for scientifically-backed injury risk assessment
5. Lack of culturally-appropriate (Indian) food suggestions in nutrition plans
6. Complex scheduling requirements that don't fit user availability

PROJECT OBJECTIVE:
------------------
Create an intelligent fitness assessment system that:

1. Validates user input data accurately
2. Parses natural language descriptions of fitness experience and health conditions
3. Predicts fitness level and injury risk using machine learning models
4. Generates personalized workout plans that respect user's schedule
5. Provides nutrition plans with Indian food choices
6. Offers recovery and lifestyle optimization strategies
7. Integrates all components into a unified web interface

TARGET USERS:
--------------
Individual fitness enthusiasts, students, professionals seeking personalized
fitness guidance without expensive coaching

KEY TECHNOLOGIES:
------------------
Machine Learning: RandomForest classifiers for fitness level and injury risk
Language Model: Google Gemini 2.5 Flash Lite for plan generation
Workflow Engine: LangGraph for multi-step orchestration
Web Framework: Streamlit for user interface
Data Processing: Pandas, NumPy, scikit-learn

===============================================================================
SECTION 2: PROJECT STRUCTURE & FILE ORGANIZATION
===============================================================================

PROJECT DIRECTORY HIERARCHY:
----------------------------

AetherFit/
├── agents/
│   ├── form_parser_agent.py
│   ├── input_normalizer_llm.py
│   ├── fitness_scorer_ml.py
│   ├── injury_assessor_ml.py
│   ├── workout_plan_generator_llm.py
│   ├── nutrition_plan_generator_llm.py
│   ├── recovery_lifestyle_optimizer_llm.py
│   └── __init__.py
│
├── nodes/
│   ├── form_parser_node.py
│   ├── input_normalizer_node.py
│   ├── fitness_scorer_node.py
│   ├── injury_assessor_node.py
│   ├── workout_planner_node.py
│   ├── nutrition_advisor_node.py
│   └── recovery_lifestyle_optimizer_node.py
│
├── workflow/
│   ├── workflow.py
│   └── __init__.py
│
├── utils/
│   ├── gemini_client.py
│   └── __init__.py
│
├── ml/
│   ├── models/
│   │   ├── fitness_level_model.pkl
│   │   ├── fitness_level_scaler.pkl
│   │   ├── fitness_level_encoder.pkl
│   │   ├── injury_risk_model.pkl
│   │   ├── injury_risk_scaler.pkl
│   │   └── injury_risk_encoder.pkl
│   │
│   ├── train_model/
│   │   ├── train_fitness_level.py
│   │   └── train_injury_risk.py
│   │
│   ├── data_cleaning/
│   │   ├── clean_fitness_data.py
│   │   └── clean_injury_data.py
│   │
│   └── evaluation/
│       └── evaluate_models.py
│
├── data/
│   ├── training_dataset/
│   │   ├── fitness_level_training.csv (30000 rows)
│   │   └── injury_risk_training.csv (30000 rows)
│   │
│   ├── evaluation_dataset/
│   │   ├── fitness_level_evaluation.csv (8000 rows)
│   │   └── injury_risk_evaluation.csv (8000 rows)
│   │
│   └── processed/
│       ├── fitness_level_training_cleaned.csv
│       └── injury_risk_training_cleaned.csv
│
├── main.py
├── graph.py
├── state.py
├── tests.py
├── .env.example
└── requirements.txt

===============================================================================
SECTION 3: FILE PURPOSES & DESCRIPTIONS
===============================================================================

ROOT LEVEL FILES
================

main.py
-------
PURPOSE: Streamlit web application entry point for user interface
DESCRIPTION: Provides interactive web interface with form input and multi-tab
display of assessment results including Overview, Workout Plan, Nutrition Plan,
and Recovery and Lifestyle sections. Also handles model evaluation display.

graph.py
--------
PURPOSE: Main entry point for fitness assessment workflow
DESCRIPTION: Defines assess_fitness() function that orchestrates the entire
7-node workflow pipeline. Initializes state, builds LangGraph, executes
workflow, and returns complete assessment results.

state.py
--------
PURPOSE: Central state management definition for entire workflow
DESCRIPTION: Defines FitnessAssessmentState TypedDict with 85 fields organized
in 9 categories (input, derived, normalized, ML outputs, LLM outputs, system).
Also provides get_initial_state() function to initialize state from form data.

tests.py
--------
PURPOSE: Comprehensive test suite for project validation
DESCRIPTION: Contains 19 test cases covering ML agents, LLM agents, state
management, and end-to-end workflow integration. Uses MockGeminiClient to
simulate LLM without API calls.

.env.example
-----------
PURPOSE: Environment configuration template
DESCRIPTION: Shows required environment variables including API keys
(GEMINI_API_KEY_1 through GEMINI_API_KEY_4) and model selection.

requirements.txt
----------------
PURPOSE: Python dependencies specification
DESCRIPTION: Lists all required packages with versions for installation.


AGENTS DIRECTORY (agents/)
===========================

form_parser_agent.py
--------------------
PURPOSE: Validate user form inputs and calculate derived metrics
DESCRIPTION: Validates age, height, weight, gender, fitness goal, and other
inputs against defined ranges and valid values. Calculates BMI and categorizes
age and BMI into meaningful groups.

CLASS: FormParserAgent
METHODS:
  - validate_and_parse(form_data) -> Dict[str, Any]

input_normalizer_llm.py
-----------------------
PURPOSE: Parse natural language fitness-related inputs using LLM
DESCRIPTION: Takes free-text descriptions of fitness experience, health
conditions, and schedule availability. Uses Google Gemini to extract structured
information with proper categories and assessments.

CLASS: InputNormalizerLLMAgent
CONSTRUCTOR: __init__(client=None)
METHODS:
  - normalize_inputs(fitness_experience, health_conditions, available_hours_per_week)
    -> Dict[str, Any]

fitness_scorer_ml.py
--------------------
PURPOSE: Predict fitness level using trained RandomForest model
DESCRIPTION: Loads pre-trained RandomForest classifier and uses it to classify
users into fitness levels (Beginner, Intermediate, Advanced, Athlete) based on
11 features including age, BMI, available hours, and categorical attributes.

CLASS: FitnessScorerMLAgent
CONSTRUCTOR: __init__(model_dir="ml/models")
METHODS:
  - predict_fitness_level(user_profile) -> Dict[str, Any]

injury_assessor_ml.py
---------------------
PURPOSE: Predict injury risk using trained RandomForest model
DESCRIPTION: Loads pre-trained RandomForest classifier to assess injury risk
in 4 categories (Low, Moderate, High, Very High Risk). Extracts 12 features
from user profile and generates risk factors list based on profile attributes.

CLASS: InjuryAssessorMLAgent
CONSTRUCTOR: __init__(model_dir="ml/models")
METHODS:
  - predict_injury_risk(user_profile) -> Dict[str, Any]

workout_plan_generator_llm.py
------------------------------
PURPOSE: Generate personalized workout plan using LLM
DESCRIPTION: Prompts Google Gemini to create detailed weekly workout schedules
that respect user's fitness level, injury risk, available hours, and preferred
workout days/times. Includes exercises with sets, reps, and rest periods.

CLASS: WorkoutPlanGeneratorLLMAgent
CONSTRUCTOR: __init__(client)
METHODS:
  - generate_workout_plan(profile) -> Dict[str, Any]

nutrition_plan_generator_llm.py
--------------------------------
PURPOSE: Generate personalized nutrition plan with Indian food options
DESCRIPTION: Prompts LLM to create nutrition plans with calorie targets,
macronutrient distributions, meal suggestions, hydration guidance, and
nutrition timing. Specifically includes Indian food staples like dal, rice,
roti, and curries.

CLASS: NutritionPlanGeneratorLLMAgent
CONSTRUCTOR: __init__(client)
METHODS:
  - generate_nutrition_plan(profile) -> Dict[str, Any]

recovery_lifestyle_optimizer_llm.py
------------------------------------
PURPOSE: Generate recovery and lifestyle integration strategies
DESCRIPTION: Prompts LLM to create comprehensive recovery plans including sleep
recommendations, rest day activities, mobility work, stress management, habit
formation strategies, and schedule integration based on user availability and
injury risk.

CLASS: RecoveryLifestyleOptimizerLLMAgent
CONSTRUCTOR: __init__(client)
METHODS:
  - generate_recovery_lifestyle_plan(profile) -> Dict[str, Any]


NODES DIRECTORY (nodes/)
=========================

form_parser_node.py
-------------------
PURPOSE: LangGraph node wrapper for FormParserAgent
DESCRIPTION: Node that integrates form validation into workflow. Receives
initial state with form data and returns validation results and derived metrics.

FUNCTION SIGNATURE:
form_parser_node(state: FitnessAssessmentState, client) -> Dict[str, Any]

input_normalizer_node.py
------------------------
PURPOSE: LangGraph node wrapper for InputNormalizerLLMAgent
DESCRIPTION: Node that processes natural language inputs through LLM. Extracts
normalized fitness experience, health conditions, and schedule information.

FUNCTION SIGNATURE:
input_normalizer_node(state: FitnessAssessmentState, client) -> Dict[str, Any]

fitness_scorer_node.py
----------------------
PURPOSE: LangGraph node wrapper for FitnessScorerMLAgent
DESCRIPTION: Node that runs fitness level prediction. Can execute in parallel
with injury_assessor_node. Receives normalized state and returns fitness
classification results.

FUNCTION SIGNATURE:
fitness_scorer_node(state: FitnessAssessmentState, client) -> Dict[str, Any]

injury_assessor_node.py
-----------------------
PURPOSE: LangGraph node wrapper for InjuryAssessorMLAgent
DESCRIPTION: Node that runs injury risk prediction. Executes in parallel with
fitness_scorer_node. Returns injury risk classification and risk factors.

FUNCTION SIGNATURE:
injury_assessor_node(state: FitnessAssessmentState, client) -> Dict[str, Any]

workout_planner_node.py
-----------------------
PURPOSE: LangGraph node wrapper for WorkoutPlanGeneratorLLMAgent
DESCRIPTION: Node that generates workout plan after ML predictions. Uses
fitness level, injury risk, available hours, and preferred days/times from
normalized state to create appropriate plan.

FUNCTION SIGNATURE:
workout_planner_node(state: FitnessAssessmentState, client) -> Dict[str, Any]

nutrition_advisor_node.py
-------------------------
PURPOSE: LangGraph node wrapper for NutritionPlanGeneratorLLMAgent
DESCRIPTION: Node that generates nutrition plan after workout plan is created.
Uses user profile and fitness level to create personalized nutrition guidance
with Indian food options.

FUNCTION SIGNATURE:
nutrition_advisor_node(state: FitnessAssessmentState, client) -> Dict[str, Any]

recovery_lifestyle_optimizer_node.py
-------------------------------------
PURPOSE: LangGraph node wrapper for RecoveryLifestyleOptimizerLLMAgent
DESCRIPTION: Final planning node that generates recovery and lifestyle
strategies. Uses all previous assessment results to create comprehensive
lifestyle integration plan.

FUNCTION SIGNATURE:
recovery_lifestyle_optimizer_node(state: FitnessAssessmentState, client)
-> Dict[str, Any]


WORKFLOW DIRECTORY (workflow/)
===============================

workflow.py
-----------
PURPOSE: LangGraph StateGraph definition and compilation
DESCRIPTION: Builds directed acyclic graph with 7 nodes and defines execution
flow. Sets entry point as form_parser, creates parallel execution for ML nodes,
and defines sequential execution for LLM planning nodes.

FUNCTION SIGNATURES:

build_fitness_assessment_graph(client=None) -> CompiledGraph
LOGIC: Creates StateGraph, registers all 7 nodes with lambdas, defines edges
for sequential and parallel execution, compiles and returns graph.
RETURNS: Compiled LangGraph ready for invocation

get_workflow_structure() -> Dict[str, Any]
LOGIC: Returns metadata dictionary describing workflow nodes and their types.
RETURNS: Dictionary with workflow name, description, and node information


UTILITIES DIRECTORY (utils/)
=============================

gemini_client.py
----------------
PURPOSE: Google Gemini API client with key rotation and JSON parsing
DESCRIPTION: Provides wrapper around Google Generative AI library with features
for API key rotation (supports up to 4 keys), JSON response parsing, Markdown
fence removal, and structured JSON generation with field validation.

FUNCTIONS:

_get_all_api_keys() -> List[str]
LOGIC: Checks Streamlit secrets and environment variables for all available
API keys. Returns deduplicated list of API keys.
RETURNS: List of API key strings

_get_first_api_key() -> Optional[str]
LOGIC: Returns first available API key from list of all keys.
RETURNS: First API key string or None

_clean_json_text(text: str) -> str
LOGIC: Removes Markdown code fence markers and trims whitespace from text.
RETURNS: Cleaned text string without fence markers

_strip_trailing_commas(text: str) -> str
LOGIC: Uses regex replacement to remove trailing commas before closing braces
and brackets to repair common JSON formatting issues.
RETURNS: JSON-repaired string

build_gemini_client() -> GeminiClient
LOGIC: Gets API key and model name from configuration, validates both are
available, configures genai library, returns initialized client.
RETURNS: Initialized GeminiClient instance

CLASS: GeminiClient
CONSTRUCTOR: __init__(model: str = "gemini-2.5-flash-lite")
LOGIC: Initializes with model name, loads all API keys, sets current key index
to 0, calls _initialize_client() to set up initial connection.

METHODS:

_initialize_client() -> None
LOGIC: Validates current key index is in bounds, gets current API key,
configures genai library with key, creates GenerativeModel instance.

_rotate_api_key() -> None
LOGIC: Increments current key index, validates bounds (raises if exhausted),
calls _initialize_client() to switch to next key.

generate_content(prompt: str, temperature: float = 0.7, max_tokens: int = 2000,
response_mime_type: Optional[str] = None) -> str
LOGIC: Attempts to generate content using current API key. If quota exceeded,
rotates to next key and retries up to number of available keys. Returns
response text.
RETURNS: Generated content string

extract_json_from_response(response_text: str) -> Dict[str, Any]
LOGIC: Cleans JSON text (removes fences), strips trailing commas, parses as
JSON. Returns empty dict on parse error.
RETURNS: Parsed JSON dictionary or empty dictionary on error

generate_structured_json(prompt: str, required_fields: list, temperature: float
= 0.7, max_tokens: int = 2000) -> Dict[str, Any]
LOGIC: Calls generate_content() to get response, extracts JSON, validates all
required_fields exist in response. Raises ValueError if fields missing.
RETURNS: Validated JSON dictionary with all required fields


MACHINE LEARNING DIRECTORY (ml/)
==================================

data_cleaning/clean_fitness_data.py
-----------------------------------
PURPOSE: Clean and preprocess fitness level training data
DESCRIPTION: Loads raw fitness training CSV, removes duplicates and missing
values, removes outliers using IQR method, validates categorical values, saves
cleaned data.

FUNCTION SIGNATURE:
clean_fitness_data(input_path: str, output_path: str) -> pandas.DataFrame
LOGIC: Load CSV, remove duplicate rows, fill missing numeric values with
median and categorical with mode, calculate IQR for each numeric column and
remove outliers, validate categorical value ranges, save to output path.
RETURNS: Pandas DataFrame with cleaned data

data_cleaning/clean_injury_data.py
----------------------------------
PURPOSE: Clean and preprocess injury risk training data
DESCRIPTION: Same cleaning pipeline as fitness data but for injury dataset.

FUNCTION SIGNATURE:
clean_injury_data(input_path: str, output_path: str) -> pandas.DataFrame
LOGIC: Same as clean_fitness_data but for injury risk target column.
RETURNS: Pandas DataFrame with cleaned data

train_model/train_fitness_level.py
----------------------------------
PURPOSE: Train RandomForest classifier for fitness level prediction
DESCRIPTION: Loads cleaned training data, encodes categorical features,
scales numeric features, trains RandomForest, evaluates metrics, saves model,
scaler, and encoder pickle files.

FUNCTION SIGNATURE:
train_fitness_level_model(training_data_path: str, model_dir: str = "ml/models")
-> Dict[str, Any]
LOGIC: Load CSV, separate features and target, apply LabelEncoder to
categorical columns, apply StandardScaler to numeric columns, train
RandomForestClassifier, calculate accuracy and per-class metrics on training
data, save three pickle files (model, scaler, encoder metadata).
RETURNS: Dictionary with model metrics including accuracy, precision, recall,
F1-score per class

train_model/train_injury_risk.py
--------------------------------
PURPOSE: Train RandomForest classifier for injury risk prediction
DESCRIPTION: Similar training pipeline to fitness model but for injury risk
with 4 classes and 12 features.

FUNCTION SIGNATURE:
train_injury_risk_model(training_data_path: str, model_dir: str = "ml/models")
-> Dict[str, Any]
LOGIC: Same as train_fitness_level_model but with injury risk target column
and different feature set.
RETURNS: Dictionary with model metrics

evaluation/evaluate_models.py
-----------------------------
PURPOSE: Evaluate trained models on evaluation datasets
DESCRIPTION: Loads trained models and evaluation data, makes predictions,
calculates comprehensive metrics including accuracy, per-class precision/recall/
F1, and confusion matrices.

FUNCTION SIGNATURES:

evaluate_fitness_level_model(eval_data_path: str, model_path: str,
scaler_path: str, encoder_path: str) -> dict
LOGIC: Load CSV, load model/scaler/encoder, extract features, encode and scale
identically to training, make predictions and get probabilities, calculate
accuracy and per-class metrics.
RETURNS: Dictionary with eval_accuracy, per-class metrics, confusion matrix,
and classification report

evaluate_injury_risk_model(eval_data_path: str, model_path: str,
scaler_path: str, encoder_path: str) -> dict
LOGIC: Same as evaluate_fitness_level_model but for injury risk model.
RETURNS: Dictionary with injury model evaluation metrics

evaluate_all_models(project_root: str = None) -> dict
LOGIC: Calls both evaluate_fitness_level_model and evaluate_injury_risk_model
with appropriate paths, combines results with timestamp.
RETURNS: Dictionary with timestamp and results from both model evaluations


STATE MANAGEMENT FILE (state.py)
================================

FitnessAssessmentState TypedDict
--------------------------------
PURPOSE: Central definition of all state fields for workflow
DESCRIPTION: TypedDict with 85 fields organized in 9 categories providing type
hints and documentation. All fields are Optional using total=False parameter.

CATEGORIES:

1. INPUT FIELDS (8 fields):
   - age, height_cm, weight_kg, gender, fitness_experience, health_conditions,
     fitness_goal, available_hours_per_week

2. DERIVED FIELDS (7 fields):
   - bmi, age_category, bmi_category, parsed_profile, validation_errors,
     parsing_complete, error_occurred

3. INPUT NORMALIZER OUTPUTS (3 fields):
   - normalized_fitness_experience, normalized_health_conditions,
     normalized_schedule

4. FITNESS LEVEL ML OUTPUTS (4 fields):
   - fitness_level_score, fitness_level_class, fitness_confidence,
     fitness_analysis_complete

5. INJURY RISK ML OUTPUTS (5 fields):
   - injury_risk_score, injury_risk_class, injury_confidence,
     injury_risk_factors, injury_assessment_complete

6. WORKOUT PLAN OUTPUTS (9 fields):
   - workout_plan, weekly_schedule, workout_intensity_level,
     workout_duration_per_session, workout_frequency_per_week,
     workout_progression_timeline, workout_safety_notes,
     workout_equipment_needed, workout_analysis_complete

7. NUTRITION PLAN OUTPUTS (7 fields):
   - nutrition_plan, daily_calorie_target, macro_targets, meal_suggestions,
     hydration_recommendation, nutrition_timing_guidance,
     nutrition_analysis_complete

8. RECOVERY LIFESTYLE OUTPUTS (11 fields):
   - sleep_recommendations, rest_day_activities, mobility_work,
     stress_management_techniques, recovery_techniques, deload_strategy,
     schedule_integration, time_management_tips, habit_formation_strategies,
     adherence_tips, recovery_lifestyle_analysis_complete

9. SYSTEM FIELDS (5 fields):
   - error_messages, analysis_timestamp, plan_generated, plan_id, user_name

FUNCTION:

get_initial_state(form_data: Dict[str, Any]) -> FitnessAssessmentState
LOGIC: Creates new FitnessAssessmentState dict by copying input fields from
form_data and initializing all output fields to None or empty based on type.
RETURNS: Initialized FitnessAssessmentState dictionary


===============================================================================
SECTION 4: WORKFLOW ARCHITECTURE & EXECUTION FLOW
===============================================================================

WORKFLOW NAME: 7-Node Fitness Assessment Pipeline

WORKFLOW EXECUTION SEQUENCE:
----------------------------

STAGE 1: INPUT VALIDATION
NODE: form_parser_node
AGENT: FormParserAgent
INPUT: User form data from state
PROCESSING: Validates age (18-100), height (100-250cm), weight (30-300kg),
validates gender against valid list, validates fitness goal against valid list,
validates all string fields are present, calculates BMI using formula
weight_kg / (height_cm/100)^2, categorizes age into groups (Young Adult, Adult,
Middle Aged, Senior), categorizes BMI into groups (Underweight, Normal,
Overweight, Obese)
OUTPUT: parsed_profile dict, validation_errors list, bmi float, age_category
string, bmi_category string, parsing_complete boolean, error_occurred boolean

STAGE 2: NATURAL LANGUAGE PARSING
NODE: input_normalizer_node
AGENT: InputNormalizerLLMAgent
INPUT: fitness_experience string, health_conditions string,
available_hours_per_week string from state
PROCESSING: Sends combined prompt to Google Gemini with all three natural
language inputs. LLM extracts and structures: experience level (enum),
years_active (integer), activity description (string) from fitness experience;
conditions list, severity assessment, exercise limitations, cleared_for_exercise
boolean from health conditions; estimated hours, preferred days, preferred times,
schedule constraints from availability
OUTPUT: normalized_fitness_experience dict, normalized_health_conditions dict,
normalized_schedule dict with extracted fields

STAGE 3A: FITNESS LEVEL PREDICTION (PARALLEL)
NODE: fitness_scorer_node
AGENT: FitnessScorerMLAgent
INPUT: User profile with 11 features from state
PROCESSING: Loads RandomForest model from pickle file, loads StandardScaler and
LabelEncoders. Extracts features: age, bmi, weight_kg, available_hours,
gender_encoded, experience_encoded, age_cat_encoded, goal_encoded,
bmi_cat_encoded, hours_cat_encoded, activity_score. Encodes categorical
features using loaded encoders. Scales numeric features. Makes prediction using
model. Gets prediction probabilities. Maps prediction index to class name.
Calculates confidence as max probability multiplied by 100.
OUTPUT: fitness_level_score float (0-100), fitness_level_class string
(Beginner/Intermediate/Advanced/Athlete), fitness_confidence float (0-100),
fitness_analysis_complete boolean

STAGE 3B: INJURY RISK PREDICTION (PARALLEL with Stage 3A)
NODE: injury_assessor_node
AGENT: InjuryAssessorMLAgent
INPUT: User profile with 12 features from state
PROCESSING: Similar to fitness scorer but with 12 features including age,
bmi, fitness_level_encoded, gender_encoded, experience_encoded, age_cat_encoded,
bmi_cat_encoded, has_health_conditions, previous_injury, flexibility_score,
strength_imbalance, training_frequency. Additionally generates risk_factors list
by checking conditions: if age > 50 add "Age over 50", if bmi > 30 add "Obesity",
if health_conditions exist add "Existing health conditions", if injury mentioned
add "Previous injury history"
OUTPUT: injury_risk_score float (0-100), injury_risk_class string (Low Risk/
Moderate Risk/High Risk/Very High Risk), injury_confidence float (0-100),
injury_risk_factors list of strings, injury_assessment_complete boolean

STAGE 4: WORKOUT PLANNING
NODE: workout_planner_node
AGENT: WorkoutPlanGeneratorLLMAgent
INPUT: fitness_level_class, injury_risk_class, fitness_goal, available_hours_per_week,
preferred_days, preferred_times, health_conditions from state
PROCESSING: Sends comprehensive prompt to Gemini including all user attributes.
LLM generates weekly schedule respecting: fitness level (exercise difficulty),
injury risk (modifications), available hours (session count and duration),
preferred days and times (when to schedule). For each day generates list of
exercises with: name, sets (integer), reps (string like "10-12"), rest period
(string like "60 seconds"). Also generates: intensity level, session duration,
frequency per week, progression timeline, safety notes, equipment needed
OUTPUT: workout_plan dict, weekly_schedule nested dict (day -> list of exercises),
workout_intensity_level string, workout_duration_per_session int (minutes),
workout_frequency_per_week int, workout_progression_timeline string,
workout_safety_notes list, workout_equipment_needed list,
workout_analysis_complete boolean

STAGE 5: NUTRITION PLANNING
NODE: nutrition_advisor_node
AGENT: NutritionPlanGeneratorLLMAgent
INPUT: age, weight_kg, height_cm, goal, fitness_level_class, workout_frequency
from state
PROCESSING: Sends prompt to Gemini requesting nutrition plan with Indian food
options. LLM calculates daily calorie target using Harris-Benedict equation,
applies activity multiplier based on workout frequency. Generates macronutrient
targets (protein in grams, carbs in grams, fat in grams). Creates 3-5 meal
suggestions each with: meal_name, foods list (e.g. "Idli with Sambar"),
protein_g, carbs_g, fat_g, calories. Provides hydration recommendation and
nutrition timing guidance for pre/post workout
OUTPUT: nutrition_plan dict, daily_calorie_target int, macro_targets dict
(protein_g, carbs_g, fat_g), meal_suggestions list of dicts, hydration_recommendation
string, nutrition_timing_guidance string, nutrition_analysis_complete boolean

STAGE 6: RECOVERY AND LIFESTYLE OPTIMIZATION
NODE: recovery_lifestyle_optimizer_node
AGENT: RecoveryLifestyleOptimizerLLMAgent
INPUT: age, fitness_level_class, injury_risk_class, health_conditions, fitness_goal,
available_hours_per_week, preferred_days, preferred_times from state
PROCESSING: Sends comprehensive prompt to Gemini requesting recovery strategies.
LLM generates: sleep hours and quality tips, rest day activity suggestions,
mobility work and stretching routines, stress management techniques, recovery
techniques (ice baths, massage, etc.), deload strategy (when to reduce intensity),
schedule integration (best days/times for workouts), time management tips for
fitting fitness into available hours, habit formation strategies, adherence tips
OUTPUT: sleep_recommendations dict, rest_day_activities list, mobility_work list,
stress_management_techniques list, recovery_techniques list, deload_strategy string,
schedule_integration dict, time_management_tips list, habit_formation_strategies list,
adherence_tips list, recovery_lifestyle_analysis_complete boolean

STAGE 7: WORKFLOW END
Execution completes, final state returned to caller


PARALLEL EXECUTION DETAILS:
---------------------------
Stages 3A and 3B (fitness_scorer_node and injury_assessor_node) execute
simultaneously. LangGraph framework handles parallel execution and state merging.
When both nodes complete, their results are merged into single state before
proceeding to Stage 4.


STATE FLOW VISUALIZATION:
--------------------------
INITIAL STATE (from form)
    |
    v (DOWN)
form_parser processes
    |
    v (DOWN)
VALIDATED STATE
    |
    v (DOWN)
input_normalizer processes
    |
    v (DOWN)
NORMALIZED STATE
    |
    v (DOWN/SPLIT)
    +----> fitness_scorer (PARALLEL)
    |
    +----> injury_assessor (PARALLEL)
    |
    v (MERGE)
ML PREDICTIONS STATE
    |
    v (DOWN)
workout_planner processes
    |
    v (DOWN)
WORKOUT PLAN STATE
    |
    v (DOWN)
nutrition_advisor processes
    |
    v (DOWN)
NUTRITION PLAN STATE
    |
    v (DOWN)
recovery_optimizer processes
    |
    v (DOWN)
FINAL COMPLETE STATE (all 85 fields populated)


===============================================================================
SECTION 5: USER INTERFACE DESIGN
===============================================================================

FRAMEWORK: Streamlit Web Application

LAYOUT STRUCTURE:
-----------------

NAVIGATION LAYOUT:
Left Sidebar (fixed width ~250px):
  - Application title "AetherFit"
  - Form input section
  - "Generate Assessment" button
  - "Tools" subsection
    - "Run Model Evaluation" button
  - Model evaluation results display

Main Content Area (remaining width):
  - Multi-tab interface (4 tabs)
  - Results display
  - Export functionality


FORM INPUT SECTION (Left Sidebar):
----------------------------------

1. Text Input: Your Name
   Type: text_input
   Placeholder: User's name
   Optional field

2. Age Slider
   Type: slider
   Range: 18-100 years
   Default: 30
   Step: 1

3. Height Number Input
   Type: number_input
   Range: 100-250 cm
   Default: 170
   Format: Float with 1 decimal

4. Weight Number Input
   Type: number_input
   Range: 30-300 kg
   Default: 70
   Format: Float with 1 decimal

5. Gender Dropdown
   Type: selectbox
   Options: Male, Female, Other
   Default: Male

6. Fitness Goal Dropdown
   Type: selectbox
   Options: Weight Loss, Muscle Building, Endurance/Cardio, General Fitness
   Default: General Fitness

7. Fitness Experience Text Area
   Type: text_area
   Placeholder: Describe your fitness background
   Required field

8. Health Conditions Text Area
   Type: text_area
   Placeholder: Any health conditions or injuries
   Optional field

9. Available Hours Per Week Input
   Type: text_input
   Placeholder: e.g., "3-4 hours" or "I am free after 8pm every night for 1 hour"
   Required field

10. Generate Assessment Button
    Type: button
    Action: Validates inputs, initializes client, calls assess_fitness(),
            displays results in tabs


MAIN CONTENT TABS:
------------------

TAB 1: OVERVIEW
Layout: Cards and metrics grid
Contents:
  - FITNESS LEVEL CARD (left column)
    - Metric: Fitness Level Classification
    - Display: Fitness class name
    - Confidence: Percentage with precision

  - INJURY RISK CARD (middle column)
    - Metric: Injury Risk Assessment
    - Display: Risk class name
    - Confidence: Percentage with precision

  - BMI CARD (right column)
    - Metric: Body Mass Index
    - Display: BMI value with one decimal
    - Category: BMI category name

  PERSONAL INFORMATION SECTION
  - 4-column grid:
    - Age (years)
    - Gender (Male/Female/Other)
    - Height (cm)
    - Weight (kg)

  - Primary Goal line: Shows fitness goal

  ASSESSMENT DETAILS SECTION
  - Left column: Risk Factors Identified
    - Bulleted list of factors or "No significant risk factors"
  - Right column: Fitness Profile
    - Fitness Level
    - Age Category
    - BMI Category


TAB 2: WORKOUT PLAN
Layout: Metrics row, schedule expandables, equipment/safety sections
Contents:
  - TOP METRICS (4-column grid)
    - Weekly Frequency (sessions)
    - Intensity Level (Light/Moderate/Vigorous)
    - Session Duration (minutes)
    - Progression Period (weeks)

  WEEKLY EXERCISE SCHEDULE
  - 7 expandable sections (one per day)
  - Each day expandable shows:
    - Exercise name (bold heading)
    - 3-column sub-grid:
      - Sets (integer)
      - Reps (string like "10-12")
      - Rest (string like "60 seconds")
    - Multiple exercises per day listed

  EQUIPMENT REQUIRED
  - Bulleted list of equipment names or "Bodyweight only"

  SAFETY NOTES
  - Bulleted list of precautions and modifications


TAB 3: NUTRITION PLAN
Layout: Metrics cards, meal suggestions expandables, guidance sections
Contents:
  - TOP METRICS (3-column grid)
    - Daily Calorie Target (kcal)
    - Hydration Guide (text description)
    - Macronutrient Targets:
      - Protein (grams)
      - Carbs (grams)
      - Fat (grams)

  DAILY MEAL SUGGESTIONS
  - Multiple expandable sections (one per meal)
  - Each meal expandable shows:
    - Meal name (Breakfast, Lunch, etc.)
    - Foods list (bulleted)
    - 4-column sub-grid:
      - Protein (grams)
      - Carbs (grams)
      - Fat (grams)
      - Calories (kcal)

  NUTRITION TIMING
  - Text section with pre-workout and post-workout guidance


TAB 4: RECOVERY & LIFESTYLE
Layout: Multiple sections with bullets and expandables
Contents:
  SLEEP RECOMMENDATIONS
  - Hours per night (metric)
  - Sleep quality tips (bulleted list)

  REST DAY ACTIVITIES
  - Bulleted list of active recovery options

  MOBILITY WORK
  - Bulleted list of stretching/mobility routines

  STRESS MANAGEMENT TECHNIQUES
  - Bulleted list of techniques

  RECOVERY TECHNIQUES
  - Bulleted list (ice baths, massage, etc.)

  DELOAD STRATEGY
  - Text description of when/how to reduce intensity

  SCHEDULE INTEGRATION
  - Best workout days (list)
  - Best workout times (list)
  - Weekly schedule tips (text)

  TIME MANAGEMENT TIPS
  - Bulleted list of strategies

  HABIT FORMATION STRATEGIES
  - Bulleted list of techniques

  ADHERENCE TIPS
  - Bulleted list of motivation strategies


TOOLS SECTION (Left Sidebar):
-----------------------------

Model Evaluation Button
  - Type: button
  - Triggers: evaluate_all_models()
  - Shows spinner with "Running model evaluation..."
  - Displays results in dedicated section

Model Evaluation Results Display
  - Shows evaluation metrics if available
  - Two-column layout:
    - Left column: Fitness Level Model
      - Accuracy percentage
      - Per-class metrics (Precision, Recall, F1-score)
    - Right column: Injury Risk Model
      - Accuracy percentage
      - Per-class metrics (Precision, Recall, F1-score)


COLOR SCHEME:
--------------
Primary: Blue (metrics, buttons)
Success: Green (positive assessments)
Warning: Yellow (moderate risk/caution)
Danger: Red (high risk)
Background: Light gray/white
Text: Dark gray/black


RESPONSIVE DESIGN:
-------------------
Desktop: Full layout with all columns visible
Tablet: Adjusted spacing, stack when necessary
Mobile: Single column, stacked sections


===============================================================================
SECTION 6: DATA FLOW & PROCESSING PIPELINE
===============================================================================

DATA FLOW FROM INPUT TO OUTPUT:
-------------------------------

USER INPUTS (HTML FORM)
  |
  v
STREAMLIT FORM INPUT (String/Integer)
  |
  v
PYTHON TYPE CONVERSION (int, float, str)
  |
  v
FORM DATA DICTIONARY (Dict[str, Any])
  |
  v
get_initial_state() creates FitnessAssessmentState
  |
  v
graph.invoke(state) starts workflow execution
  |
  v
WORKFLOW EXECUTION (7 nodes sequentially + 2 in parallel)
  Each node processes state and returns updates
  StateGraph merges updates back into state
  |
  v
FINAL STATE with all 85 fields populated
  |
  v
Main.py extracts relevant fields by category
  |
  v
STREAMLIT DISPLAYS formatted results in tabs


PROCESSING PIPELINE DETAILS:
-----------------------------

STAGE 1: INPUT FORM DATA PROCESSING
Input: User fills HTML form in Streamlit
Processing: Streamlit collects form values as Python types
Output: Form data dict with keys: age (int), height_cm (float), weight_kg (float),
        gender (str), fitness_goal (str), fitness_experience (str),
        health_conditions (str), available_hours_per_week (str), user_name (str)

STAGE 2: STATE INITIALIZATION
Input: Form data dict
Processing: get_initial_state() creates FitnessAssessmentState TypedDict with
           all input fields populated from form data, all output fields set to
           None/empty, system fields initialized
Output: FitnessAssessmentState ready for workflow

STAGE 3: FORM VALIDATION PROCESSING
Input: State with form data
Processing: FormParserAgent validates ranges and values, calculates BMI,
           categorizes age and BMI
Output: State updated with: bmi (float), age_category (str), bmi_category (str),
        parsed_profile (dict), validation_errors (list),
        parsing_complete (bool), error_occurred (bool)

STAGE 4: NATURAL LANGUAGE NORMALIZATION
Input: Three string fields (fitness_experience, health_conditions,
       available_hours_per_week)
Processing: InputNormalizerLLMAgent sends to Google Gemini API, LLM parses
           natural language and structures responses
Output: State updated with: normalized_fitness_experience (dict),
        normalized_health_conditions (dict), normalized_schedule (dict)
        including extracted: experience_level, years_active, activity_description,
        conditions list, severity, exercise_limitations, cleared_for_exercise,
        estimated_hours_per_week, preferred_days, preferred_times

STAGE 5A: MACHINE LEARNING PREDICTION (FITNESS)
Input: 11 features extracted from state (age, bmi, weight_kg, available_hours,
       gender_encoded, experience_encoded, age_cat_encoded, goal_encoded,
       bmi_cat_encoded, hours_cat_encoded, activity_score)
Processing: FitnessScorerMLAgent loads RandomForest model, scaler, encoders.
           Encodes categoricals, scales numerics, makes prediction, gets
           probabilities, maps to class name
Output: State updated with: fitness_level_score (float 0-100),
        fitness_level_class (str: Beginner/Intermediate/Advanced/Athlete),
        fitness_confidence (float 0-100), fitness_analysis_complete (bool)

STAGE 5B: MACHINE LEARNING PREDICTION (INJURY)
Input: 12 features extracted from state
Processing: InjuryAssessorMLAgent loads RandomForest model and preprocessors.
           Similar encoding/scaling/prediction as fitness model. Additionally
           generates risk_factors list based on profile conditions
Output: State updated with: injury_risk_score (float 0-100),
        injury_risk_class (str: Low Risk/Moderate Risk/High Risk/Very High Risk),
        injury_confidence (float 0-100), injury_risk_factors (list of strings),
        injury_assessment_complete (bool)

STAGE 6: WORKOUT PLANNING
Input: User profile dict with fitness_level_class, injury_risk_class,
       available_hours_per_week, preferred_days, preferred_times, fitness_goal,
       health_conditions
Processing: WorkoutPlanGeneratorLLMAgent sends comprehensive prompt to Gemini.
           LLM respects all constraints (fitness level, injury risk, hours,
           preferred schedule). Generates weekly schedule as dict with days as
           keys and exercise lists as values. Each exercise has name, sets,
           reps, rest properties. Also generates intensity, duration, frequency,
           progression timeline, safety notes, equipment list
Output: State updated with: workout_plan (dict), weekly_schedule (nested dict),
        workout_intensity_level (str), workout_duration_per_session (int),
        workout_frequency_per_week (int), workout_progression_timeline (str),
        workout_safety_notes (list), workout_equipment_needed (list),
        workout_analysis_complete (bool)

STAGE 7: NUTRITION PLANNING
Input: User profile dict with age, weight_kg, height_cm, fitness_level_class,
       workout_frequency_per_week, fitness_goal
Processing: NutritionPlanGeneratorLLMAgent sends prompt explicitly requesting
           Indian food options. LLM calculates calorie target, generates macro
           targets, creates 3-5 meals each with name, foods list, and macro
           breakdown. Provides hydration and nutrition timing guidance
Output: State updated with: nutrition_plan (dict), daily_calorie_target (int),
        macro_targets (dict: protein_g/carbs_g/fat_g), meal_suggestions (list
        of dicts), hydration_recommendation (str), nutrition_timing_guidance (str),
        nutrition_analysis_complete (bool)

STAGE 8: RECOVERY & LIFESTYLE PLANNING
Input: User profile dict with age, fitness_level_class, injury_risk_class,
       health_conditions, available_hours_per_week, preferred_days,
       preferred_times
Processing: RecoveryLifestyleOptimizerLLMAgent sends comprehensive prompt to
           Gemini requesting recovery and lifestyle strategies. LLM generates
           sleep recommendations, rest activities, mobility work, stress
           management, recovery techniques, deload strategy, schedule integration,
           time management tips, habit formation strategies, adherence tips
Output: State updated with: sleep_recommendations (dict), rest_day_activities
        (list), mobility_work (list), stress_management_techniques (list),
        recovery_techniques (list), deload_strategy (str), schedule_integration
        (dict), time_management_tips (list), habit_formation_strategies (list),
        adherence_tips (list), recovery_lifestyle_analysis_complete (bool)

STAGE 9: UI DISPLAY
Input: Final state with all 85 fields
Processing: main.py extracts relevant fields and formats for display. Different
           tabs access different state fields. Metrics formatted with precision.
           Lists displayed as bullets. Nested dicts formatted into sub-sections
Output: HTML/Streamlit rendered UI with 4 tabs showing structured assessment


===============================================================================
SECTION 7: COMPLETE EXECUTION FLOW - FROM START TO OUTPUT
===============================================================================

STEP 1: ENVIRONMENT SETUP
Command: source venv/bin/activate (on macOS/Linux) or venv\\Scripts\\activate (Windows)
Action: Activate Python virtual environment
Output: Terminal prompt shows (venv) indicator

STEP 2: INSTALL DEPENDENCIES
Command: pip install -r requirements.txt
Action: Installs all required packages from requirements.txt
Output: Console shows installation progress and completion message
Packages: streamlit, pandas, numpy, scikit-learn, google-generativeai,
          langgraph, python-dotenv, pytest

STEP 3: CONFIGURE API KEYS
Action: Create .env file in project root directory
Command: cp .env.example .env
Content:
  GEMINI_API_KEY_1=your_api_key_here
  GEMINI_API_KEY_2=
  GEMINI_API_KEY_3=
  GEMINI_API_KEY_4=
  GEMINI_MODEL=gemini-2.5-flash-lite
Save: Save with actual API keys from Google Cloud Console
Output: .env file created with configuration

STEP 4: DATA PREPARATION (Optional - for training new models)

4.1 CLEAN TRAINING DATA
Command: python3 ml/train_model/train_fitness_level.py (runs cleaning internally)
Action: Runs data cleaning pipeline
Processing: Loads training CSV, removes duplicates, fills missing values,
           removes outliers, validates categories
Output: Cleaned CSV saved to data/processed/fitness_level_training_cleaned.csv

4.2 TRAIN ML MODELS
Command: python3 ml/train_model/train_fitness_level.py
Action: Trains RandomForest on cleaned data
Processing: Loads cleaned data, encodes categories, scales features, trains
           model, evaluates metrics, saves 3 pickle files
Output: Three files created in ml/models/:
        - fitness_level_model.pkl (RandomForest model)
        - fitness_level_scaler.pkl (StandardScaler)
        - fitness_level_encoder.pkl (Encoders and metadata)

Command: python3 ml/train_model/train_injury_risk.py
Action: Trains injury risk model similarly
Output: Three files created:
        - injury_risk_model.pkl
        - injury_risk_scaler.pkl
        - injury_risk_encoder.pkl

STEP 5: RUN TESTS (Optional - for validation)
Command: python3 -m pytest tests.py -v
Action: Runs comprehensive test suite
Processing: Executes 19 test cases covering agents, nodes, state management,
           workflow integration
Output: Console shows test results:
  tests.py::test_fitness_scorer_beginner PASSED
  tests.py::test_injury_assessor_high_risk PASSED
  ... (17 more test results)
  ==================== 19 passed in 2.5 seconds ====================

STEP 6: START WEB APPLICATION
Command: streamlit run main.py
Action: Launches Streamlit development server
Output: Console shows:
  You can now view your Streamlit app in your browser.
  Local URL: http://localhost:8501
  Network URL: http://192.168.x.x:8501

STEP 7: OPEN WEB BROWSER
Action: Navigate to http://localhost:8501
Output: AetherFit web interface loads in browser

STEP 8: USER INTERACTION - FORM INPUT
Action: User fills form with:
  - Name: "John Doe"
  - Age: 30
  - Height: 175 cm
  - Weight: 75 kg
  - Gender: "Male"
  - Fitness Goal: "Muscle Building"
  - Fitness Experience: "Been going to gym for 2 years, mainly lifting"
  - Health Conditions: "None"
  - Available Hours: "I can workout 5 days a week for 1 hour each"

STEP 9: API CLIENT INITIALIZATION
Action: User clicks "Generate Assessment" button
Processing: main.py calls build_gemini_client()
Processing: Function checks .env for API keys
Processing: Validates API keys exist
Processing: Configures Google Generative AI library
Processing: Creates GeminiClient instance
Output: Client ready for LLM operations

STEP 10: WORKFLOW EXECUTION - VALIDATION
Node: form_parser_node
Processing:
  - FormParserAgent validates all inputs
  - Calculates BMI = 75 / (1.75^2) = 24.5 (Normal weight)
  - Categorizes age as "Adult"
  - No errors found
Output: State updated with validation results

STEP 11: WORKFLOW EXECUTION - NORMALIZATION
Node: input_normalizer_node
Processing:
  - InputNormalizerLLMAgent sends prompt to Google Gemini:
    "FITNESS EXPERIENCE: Been going to gym for 2 years, mainly lifting...
    Extract: experience level, years active, activity description...
    etc."
  - Google Gemini responds with structured JSON
  - Response extracted and parsed
  - Results stored in state
Output: State updated with normalized inputs:
  normalized_fitness_experience:
    experience_level: "Intermediate"
    years_active: 2
    activity_description: "Gym training focusing on strength and muscle building"
  normalized_schedule:
    estimated_hours_per_week: 5.0
    preferred_days: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
    preferred_times: ["Evening"]

STEP 12: WORKFLOW EXECUTION - ML PREDICTION (PARALLEL)
Node 1: fitness_scorer_node
Processing:
  - FitnessScorerMLAgent loads model from ml/models/fitness_level_model.pkl
  - Extracts 11 features from user profile
  - Encodes categorical features
  - Scales numeric features
  - Makes prediction: RandomForest predicts class 2 (Advanced)
  - Gets probabilities: [0.05, 0.15, 0.65, 0.15] = confidence 65%
Output: State updated with:
  fitness_level_class: "Advanced"
  fitness_level_score: 65.0
  fitness_confidence: 65.0

Node 2: injury_assessor_node (runs simultaneously)
Processing:
  - InjuryAssessorMLAgent loads injury model
  - Extracts 12 features
  - Makes prediction: RandomForest predicts class 1 (Moderate Risk)
  - Gets probabilities: [0.35, 0.45, 0.15, 0.05] = confidence 45%
  - Generates risk factors:
    - "BMI in normal range - good baseline"
    - "Intermediate fitness experience"
Output: State updated with:
  injury_risk_class: "Moderate Risk"
  injury_risk_score: 45.0
  injury_confidence: 45.0
  injury_risk_factors: ["Limited gym experience duration", "Need proper form training"]

STEP 13: WORKFLOW EXECUTION - WORKOUT PLANNING
Node: workout_planner_node
Processing:
  - WorkoutPlanGeneratorLLMAgent sends prompt to Gemini:
    "Generate a personalized workout plan:
    User Profile:
    - Fitness Level: Advanced
    - Injury Risk Level: Moderate Risk
    - Primary Goal: Muscle Building
    - Available Time: 5.0 hours per week
    - Preferred Days: Monday-Friday
    - Preferred Times: Evening

    Requirements:
    1. Design weekly schedule for Advanced fitness level
    2. Account for Moderate Risk
    3. Fit into 5 hours per week (~1 hour per day)
    4. Schedule for Monday-Friday evenings
    ...etc"
  - Google Gemini responds with detailed workout plan
  - Response parsed into JSON
Output: State updated with complete workout plan containing:
  weekly_schedule:
    Monday: [
      {name: "Barbell Bench Press", sets: 4, reps: "6-8", rest: "2-3 minutes"},
      {name: "Incline Dumbbell Press", sets: 3, reps: "8-10", rest: "90 seconds"}
    ]
    Tuesday: [...]
    ... (Wednesday through Friday)
  workout_intensity_level: "Vigorous"
  workout_duration_per_session: 60
  workout_frequency_per_week: 5
  workout_progression_timeline: "8-12 weeks"
  workout_safety_notes: ["Use proper form to prevent shoulder injury"]
  workout_equipment_needed: ["Barbell", "Dumbbells", "Bench"]

STEP 14: WORKFLOW EXECUTION - NUTRITION PLANNING
Node: nutrition_advisor_node
Processing:
  - NutritionPlanGeneratorLLMAgent sends prompt to Gemini:
    "Generate personalized nutrition plan:
    User: 30-year-old Male, 75kg, 175cm, Advanced fitness, Muscle Building goal
    Workout: 5 sessions per week

    Requirements:
    1. Calculate daily calorie target
    2. Provide macronutrient targets
    3. Suggest meal options with INDIAN FOOD STAPLES
    4. Include pre/post-workout timing
    5. Hydration recommendations
    ...etc"
  - Google Gemini generates nutrition plan with Indian foods
  - Response parsed
Output: State updated with:
  daily_calorie_target: 2800
  macro_targets: {protein_g: 175, carbs_g: 350, fat_g: 93}
  meal_suggestions: [
    {
      meal_name: "Breakfast",
      foods: ["2 Idli with Sambar", "1 cup Green Chutney"],
      protein_g: 8,
      carbs_g: 45,
      fat_g: 3,
      calories: 220
    },
    {
      meal_name: "Mid-morning",
      foods: ["Greek Yogurt", "1 banana", "Almonds"],
      protein_g: 20,
      carbs_g: 40,
      fat_g: 8,
      calories: 280
    },
    {
      meal_name: "Lunch",
      foods: ["Chicken Tikka Masala", "1 cup Brown Rice", "Mixed Vegetables"],
      protein_g: 40,
      carbs_g: 65,
      fat_g: 15,
      calories: 650
    },
    ... (afternoon snack and dinner)
  ]
  hydration_recommendation: "3-4 liters daily with coconut water post-workout"
  nutrition_timing_guidance: "Eat carbs+protein 1 hour before workout, within 30 min after"

STEP 15: WORKFLOW EXECUTION - RECOVERY PLANNING
Node: recovery_lifestyle_optimizer_node
Processing:
  - RecoveryLifestyleOptimizerLLMAgent sends comprehensive prompt to Gemini
  - Requests recovery strategies considering:
    - Age 30, Advanced fitness, Moderate injury risk
    - 5 workouts per week needs proper recovery
    - Evening workouts affect sleep
  - Gemini generates recovery plan
Output: State updated with:
  sleep_recommendations: {
    hours_per_night: 8,
    sleep_quality_tips: ["Avoid heavy meals 3 hours before bed", "Keep room cool"]
  }
  rest_day_activities: ["Light yoga", "Walking", "Swimming"]
  mobility_work: ["Daily 10-min stretching", "Foam rolling on rest days"]
  stress_management_techniques: ["Meditation", "Breathing exercises"]
  recovery_techniques: ["Post-workout stretching", "Foam rolling", "Ice bath"]
  deload_strategy: "Every 4th week reduce volume by 40%, maintain intensity"
  schedule_integration: {
    best_days: ["Saturday", "Sunday"],
    best_times: ["Evening"],
    weekly_schedule_tips: "Monday-Friday intense training, weekend recovery focus"
  }
  time_management_tips: ["Pre-schedule workouts", "Meal prep on weekends"]
  habit_formation_strategies: ["Track workouts", "Find gym buddy"]
  adherence_tips: ["Celebrate milestones", "Join fitness community"]

STEP 16: FINAL STATE COMPLETE
Processing: All 85 state fields now populated with assessment results
Total Processing Time: ~10-15 seconds (depending on API latency)

STEP 17: UI RENDERING - TAB 1 (OVERVIEW)
Display:
  Top Section - Three Metrics Cards:
    LEFT CARD:
      Fitness Level Classification: Advanced
      Assessment Confidence: 65.0 percent

    MIDDLE CARD:
      Injury Risk Assessment: Moderate Risk
      Assessment Confidence: 45.0 percent

    RIGHT CARD:
      Body Mass Index: 24.5
      Normal

  Personal Information Section (4 columns):
    Age: 30 years
    Gender: Male
    Height: 175 cm
    Weight: 75 kg

  Primary Goal: Muscle Building

  Assessment Details:
    Risk Factors Identified:
      - Limited gym experience duration
      - Need proper form training
    Fitness Profile:
      - Fitness Level: Advanced
      - Age Category: Adult
      - BMI Category: Normal

STEP 18: UI RENDERING - TAB 2 (WORKOUT PLAN)
Display:
  Top Metrics (4 columns):
    Weekly Frequency: 5 sessions
    Intensity Level: Vigorous
    Session Duration: 60 min
    Progression Period: 8-12 weeks

  Weekly Exercise Schedule:
    Monday (expandable section):
      Exercise 1: Barbell Bench Press
        Sets: 4
        Reps: 6-8
        Rest: 2-3 minutes
      Exercise 2: Incline Dumbbell Press
        Sets: 3
        Reps: 8-10
        Rest: 90 seconds

    Tuesday through Friday (similar structure)

    Saturday and Sunday: Rest days

  Equipment Required:
    - Barbell
    - Dumbbells
    - Bench
    - Cable machine

  Safety Notes:
    - Use proper form to prevent shoulder injury
    - Warm up with 5 minutes cardio

STEP 19: UI RENDERING - TAB 3 (NUTRITION PLAN)
Display:
  Top Metrics (3 columns):
    Daily Calorie Target: 2800 kcal

    Macronutrient Targets:
      Protein: 175g
      Carbs: 350g
      Fat: 93g

  Hydration Guide:
    3-4 liters daily with coconut water post-workout

  Daily Meal Suggestions:
    Meal 1: Breakfast (expandable)
      Foods:
        - 2 Idli with Sambar
        - 1 cup Green Chutney
      Nutrition Grid:
        Protein: 8g    Carbs: 45g    Fat: 3g    Calories: 220

    Meal 2: Mid-morning (expandable)
      Foods:
        - Greek Yogurt
        - 1 banana
        - Almonds
      Nutrition Grid:
        Protein: 20g    Carbs: 40g    Fat: 8g    Calories: 280

    Meal 3: Lunch (expandable)
      Foods:
        - Chicken Tikka Masala
        - 1 cup Brown Rice
        - Mixed Vegetables
      Nutrition Grid:
        Protein: 40g    Carbs: 65g    Fat: 15g    Calories: 650

    ... (afternoon and evening meals)

  Nutrition Timing:
    Eat carbs and protein 1 hour before workout. Consume within 30 minutes after.

STEP 20: UI RENDERING - TAB 4 (RECOVERY & LIFESTYLE)
Display:
  Sleep Recommendations:
    Hours per night: 8
    Sleep quality tips:
      - Avoid heavy meals 3 hours before bed
      - Keep room cool
      - Maintain consistent sleep schedule

  Rest Day Activities:
    - Light yoga
    - Walking
    - Swimming

  Mobility Work:
    - Daily 10-minute stretching
    - Foam rolling on rest days

  Stress Management Techniques:
    - Meditation
    - Breathing exercises
    - Journaling

  Recovery Techniques:
    - Post-workout stretching
    - Foam rolling
    - Ice bath
    - Massage

  Deload Strategy:
    Every 4th week reduce volume by 40 percent, maintain intensity

  Schedule Integration:
    Best days: Saturday, Sunday
    Best times: Evening
    Weekly tips: Monday-Friday intense training, weekend recovery focus

  Time Management Tips:
    - Pre-schedule workouts in calendar
    - Meal prep on weekends
    - Batch similar activities together

  Habit Formation Strategies:
    - Track workouts daily
    - Find gym buddy for accountability
    - Set monthly goals
    - Celebrate milestones

  Adherence Tips:
    - Celebrate milestones
    - Join fitness community
    - Follow Instagram fitness accounts
    - Join online coaching groups


STEP 21: MODEL EVALUATION (Optional)
Action: User clicks "Run Model Evaluation" button in Tools section
Processing: main.py calls evaluate_all_models()
Processing: Function loads evaluation datasets, runs predictions, calculates metrics
Output: Model evaluation results displayed:

  FITNESS LEVEL MODEL EVALUATION:
    Overall Accuracy: 87.5 percent

    Class-wise Metrics:
      Beginner:
        Precision: 0.88    Recall: 0.85    F1-Score: 0.86
      Intermediate:
        Precision: 0.86    Recall: 0.87    F1-Score: 0.87
      Advanced:
        Precision: 0.89    Recall: 0.90    F1-Score: 0.89
      Athlete:
        Precision: 0.87    Recall: 0.86    F1-Score: 0.87

  INJURY RISK MODEL EVALUATION:
    Overall Accuracy: 81.2 percent

    Class-wise Metrics:
      Low Risk:
        Precision: 0.82    Recall: 0.80    F1-Score: 0.81
      Moderate Risk:
        Precision: 0.80    Recall: 0.82    F1-Score: 0.81
      High Risk:
        Precision: 0.81    Recall: 0.81    F1-Score: 0.81
      Very High Risk:
        Precision: 0.80    Recall: 0.82    F1-Score: 0.81


STEP 22: APPLICATION SHUTDOWN
Action: User closes browser or presses Ctrl+C in terminal
Command: Ctrl+C (in terminal where streamlit is running)
Output: Streamlit server shuts down, console returns to prompt


===============================================================================
SECTION 8: COMPLETE SYSTEM OUTPUT SUMMARY
===============================================================================

FINAL OUTPUT STRUCTURE:

The system produces comprehensive fitness assessment output containing:

SECTION A: USER PROFILE SUMMARY
  - Input validation status
  - Demographic data (age, gender, height, weight)
  - Derived metrics (BMI, age category, BMI category)
  - Parsed profile in structured format

SECTION B: ML ASSESSMENT RESULTS
  - Fitness level classification (4 classes)
  - Fitness confidence percentage (0-100)
  - Injury risk classification (4 classes)
  - Injury confidence percentage (0-100)
  - Identified risk factors (list)

SECTION C: WORKOUT PLAN
  - Weekly schedule with daily exercises
  - Exercise details (name, sets, reps, rest periods)
  - Workout intensity level
  - Session duration (minutes)
  - Workout frequency per week
  - Progression timeline
  - Required equipment
  - Safety notes and modifications

SECTION D: NUTRITION PLAN
  - Daily calorie target
  - Macronutrient targets (protein, carbs, fat in grams)
  - Multiple meal suggestions with:
    - Meal names
    - Food items (including Indian staples)
    - Macronutrient breakdown per meal
    - Calorie count per meal
  - Hydration recommendations
  - Nutrition timing guidelines (pre/post workout)

SECTION E: RECOVERY & LIFESTYLE PLAN
  - Sleep recommendations (hours, quality tips)
  - Rest day activity suggestions
  - Mobility work routines
  - Stress management techniques
  - Recovery techniques
  - Deload strategy and schedule
  - Workout schedule integration
  - Time management strategies
  - Habit formation approaches
  - Adherence and motivation tips

SECTION F: SYSTEM METADATA
  - Unique plan ID
  - Analysis timestamp
  - Processing status flags
  - Error messages (if any)
  - User name

OUTPUT FORMATS:

1. STREAMLIT WEB UI (Primary Output)
   - 4-tab interface with formatted display
   - Interactive elements (expandables, metrics cards)
   - Professional layout with proper spacing
   - Real-time display without page refresh

2. STATE DATA (Internal)
   - Complete FitnessAssessmentState TypedDict
   - Can be serialized to JSON for export
   - Contains raw and formatted data
   - Machine-readable format

3. EXPORTED JSON (Optional)
   - User can export assessment as JSON
   - Contains all 85 state fields
   - Timestamp for tracking
   - Can be stored for future reference

4. MODEL EVALUATION METRICS (Optional)
   - Accuracy percentages
   - Per-class precision, recall, F1-scores
   - Confusion matrices
   - Classification reports

SAMPLE OUTPUT STATISTICS:

Processing Metrics:
  - Total fields populated: 85
  - Input fields: 8
  - Calculated/derived fields: 7
  - ML prediction fields: 9
  - LLM-generated plan fields: 27
  - System metadata fields: 5
  - Unused/reserved fields: 19

Workflow Metrics:
  - Total nodes executed: 7
  - Nodes in parallel: 2 (fitness_scorer, injury_assessor)
  - Sequential nodes: 5
  - API calls made: 3 (input_normalizer, workout_planner, nutrition_advisor,
                        recovery_optimizer)
  - ML model predictions: 2
  - Average execution time: 10-15 seconds

Data Volume:
  - Average state size: ~15-20 KB (JSON serialized)
  - Largest field: weekly_schedule (exercise data)
  - Smallest fields: confidence percentages
  - Text fields: natural language descriptions and tips


===============================================================================
SECTION 9: ERROR HANDLING & VALIDATION
===============================================================================

INPUT VALIDATION ERRORS:
------------------------
Age validation:
  - Error if age < 18 or age > 100
  - Message: "Age must be between 18 and 100"

Height validation:
  - Error if height < 100 cm or height > 250 cm
  - Message: "Height must be between 100-250 cm"

Weight validation:
  - Error if weight < 30 kg or weight > 300 kg
  - Message: "Weight must be between 30-300 kg"

Gender validation:
  - Error if gender not in [Male, Female, Other]
  - Message: "Gender must be one of: Male, Female, Other"

Fitness goal validation:
  - Error if goal not in valid list
  - Message: "Goal must be one of: Weight Loss, Muscle Building, Endurance/Cardio, General Fitness"

Natural language fields:
  - Error if fitness_experience is empty or not string
  - Message: "Fitness experience description is required"
  - Error if health_conditions is empty or not string
  - Message: "Health conditions field is required"
  - Error if available_hours is empty or not string
  - Message: "Schedule/availability description is required"

API KEY ERRORS:
---------------
Missing API key:
  - Error if no API keys found in .env or environment
  - Message: "Gemini API key not found. Set GEMINI_API_KEY or GEMINI_API_KEY_1..4 in .env file"

Missing library:
  - Error if google-generativeai not installed
  - Message: "google-generativeai is not installed. Install with: pip install google-generativeai"

Quota exceeded:
  - Error if all API keys exhausted
  - Action: Automatically rotates to next key
  - Final error if all keys fail: "All API keys exhausted"

LLM RESPONSE ERRORS:
--------------------
Missing required fields:
  - Error if LLM response missing required fields
  - Message: "Missing fields: [field1, field2]"
  - Action: Catch exception, return partial results

JSON parsing error:
  - Error if response cannot be parsed as JSON
  - Action: Attempt to clean Markdown fences and retry
  - Fallback: Return empty dictionary

NODE EXECUTION ERRORS:
----------------------
All nodes catch exceptions and return:
  - Partial results with None values
  - Set completion flag to False
  - Add error message to error_messages list
  - Set error_occurred flag to True
  - Allow workflow to continue


===============================================================================
SECTION 10: SYSTEM REQUIREMENTS & DEPENDENCIES
===============================================================================

PYTHON VERSION:
  - Python 3.9 or higher

EXTERNAL DEPENDENCIES:
  - streamlit >= 1.28.0
  - pandas >= 1.5.0
  - numpy >= 1.23.0
  - scikit-learn >= 1.3.0
  - google-generativeai >= 0.3.0
  - langgraph >= 0.0.1
  - python-dotenv >= 1.0.0
  - pytest >= 7.4.0

HARDWARE REQUIREMENTS:
  - RAM: 2 GB minimum (4 GB recommended)
  - Disk space: 500 MB for dependencies and models
  - Network: Required for API calls to Google Gemini

EXTERNAL SERVICES:
  - Google Gemini API (requires API key and paid account)
  - Internet connection for LLM requests

OS COMPATIBILITY:
  - macOS (tested on 10.15+)
  - Linux (Ubuntu 18.04+)
  - Windows 10+ (with WSL recommended)


END OF PROJECT DOCUMENTATION
===============================================================================
