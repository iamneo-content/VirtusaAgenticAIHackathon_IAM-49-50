from typing import TypedDict, List, Dict, Any, Optional


class FitnessAssessmentState(TypedDict, total=False):
    """
    Central state management for fitness assessment workflow.
    Tracks all input data, normalized values, ML predictions, and LLM outputs.
    Total: ~85 fields across multiple categories.
    """

    # ==================== INPUT FIELDS (8 fields) ====================
    age: Optional[int]
    height_cm: Optional[float]
    weight_kg: Optional[float]
    gender: Optional[str]
    fitness_experience: Optional[str]
    health_conditions: Optional[str]
    fitness_goal: Optional[str]
    available_hours_per_week: Optional[str]

    # ==================== DERIVED/CALCULATED FIELDS (7 fields) ====================
    bmi: Optional[float]
    age_category: Optional[str]
    bmi_category: Optional[str]
    parsed_profile: Optional[Dict[str, Any]]
    validation_errors: List[str]
    parsing_complete: bool
    error_occurred: bool

    # ==================== INPUT NORMALIZER LLM OUTPUTS (3 fields) ====================
    normalized_fitness_experience: Optional[Dict[str, Any]]
    normalized_health_conditions: Optional[Dict[str, Any]]
    normalized_schedule: Optional[Dict[str, Any]]

    # ==================== FITNESS LEVEL ML OUTPUTS (4 fields) ====================
    fitness_level_score: Optional[float]
    fitness_level_class: Optional[str]
    fitness_confidence: Optional[float]
    fitness_analysis_complete: bool

    # ==================== INJURY RISK ML OUTPUTS (5 fields) ====================
    injury_risk_score: Optional[float]
    injury_risk_class: Optional[str]
    injury_confidence: Optional[float]
    injury_risk_factors: Optional[List[str]]
    injury_assessment_complete: bool

    # ==================== WORKOUT PLAN LLM OUTPUTS (9 fields) ====================
    workout_plan: Optional[Dict[str, Any]]
    weekly_schedule: Optional[Dict[str, Any]]
    workout_intensity_level: Optional[str]
    workout_duration_per_session: Optional[int]
    workout_frequency_per_week: Optional[int]
    workout_progression_timeline: Optional[str]
    workout_safety_notes: Optional[List[str]]
    workout_equipment_needed: Optional[List[str]]
    workout_analysis_complete: bool

    # ==================== NUTRITION PLAN LLM OUTPUTS (7 fields) ====================
    nutrition_plan: Optional[Dict[str, Any]]
    daily_calorie_target: Optional[int]
    macro_targets: Optional[Dict[str, int]]
    meal_suggestions: Optional[List[Dict]]
    hydration_recommendation: Optional[str]
    nutrition_timing_guidance: Optional[str]
    nutrition_analysis_complete: bool

    # ==================== RECOVERY & LIFESTYLE LLM OUTPUTS (11 fields) ====================
    # Recovery-related
    sleep_recommendations: Optional[Dict[str, Any]]
    rest_day_activities: Optional[List[str]]
    mobility_work: Optional[List[str]]
    stress_management_techniques: Optional[List[str]]
    recovery_techniques: Optional[List[str]]
    deload_strategy: Optional[str]

    # Lifestyle-related
    schedule_integration: Optional[Dict[str, Any]]
    time_management_tips: Optional[List[str]]
    habit_formation_strategies: Optional[List[str]]
    adherence_tips: Optional[List[str]]
    recovery_lifestyle_analysis_complete: bool

    # ==================== SYSTEM FIELDS (5 fields) ====================
    error_messages: List[str]
    analysis_timestamp: Optional[str]
    plan_generated: bool
    plan_id: Optional[str]
    user_name: Optional[str]


def get_initial_state(form_data: Dict[str, Any]) -> FitnessAssessmentState:
    """
    Initialize FitnessAssessmentState with form input data.
    All output fields start as None/empty.

    Args:
        form_data: Dictionary containing user input from form

    Returns:
        FitnessAssessmentState with initialized values
    """
    return {
        # Input fields
        "age": form_data.get("age"),
        "height_cm": form_data.get("height_cm"),
        "weight_kg": form_data.get("weight_kg"),
        "gender": form_data.get("gender"),
        "fitness_experience": form_data.get("fitness_experience"),
        "health_conditions": form_data.get("health_conditions"),
        "fitness_goal": form_data.get("fitness_goal"),
        "available_hours_per_week": form_data.get("available_hours_per_week"),

        # Derived fields (empty)
        "bmi": None,
        "age_category": None,
        "bmi_category": None,
        "parsed_profile": None,
        "validation_errors": [],
        "parsing_complete": False,
        "error_occurred": False,

        # Normalizer outputs
        "normalized_fitness_experience": None,
        "normalized_health_conditions": None,
        "normalized_schedule": None,

        # ML outputs
        "fitness_level_score": None,
        "fitness_level_class": None,
        "fitness_confidence": None,
        "fitness_analysis_complete": False,

        "injury_risk_score": None,
        "injury_risk_class": None,
        "injury_confidence": None,
        "injury_risk_factors": None,
        "injury_assessment_complete": False,

        # Workout outputs
        "workout_plan": None,
        "weekly_schedule": None,
        "workout_intensity_level": None,
        "workout_duration_per_session": None,
        "workout_frequency_per_week": None,
        "workout_progression_timeline": None,
        "workout_safety_notes": None,
        "workout_equipment_needed": None,
        "workout_analysis_complete": False,

        # Nutrition outputs
        "nutrition_plan": None,
        "daily_calorie_target": None,
        "macro_targets": None,
        "meal_suggestions": None,
        "hydration_recommendation": None,
        "nutrition_timing_guidance": None,
        "nutrition_analysis_complete": False,

        # Recovery & Lifestyle outputs
        "sleep_recommendations": None,
        "rest_day_activities": None,
        "mobility_work": None,
        "stress_management_techniques": None,
        "recovery_techniques": None,
        "deload_strategy": None,

        "schedule_integration": None,
        "time_management_tips": None,
        "habit_formation_strategies": None,
        "adherence_tips": None,
        "recovery_lifestyle_analysis_complete": False,

        # System fields
        "error_messages": [],
        "analysis_timestamp": None,
        "plan_generated": False,
        "plan_id": None,
        "user_name": form_data.get("user_name"),
    }
