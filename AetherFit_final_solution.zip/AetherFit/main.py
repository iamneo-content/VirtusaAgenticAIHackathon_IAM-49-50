"""Streamlit application for AetherFit fitness assessment."""

import streamlit as st
import json
from datetime import datetime
from graph import assess_fitness
from utils import build_gemini_client


def initialize_session_state():
    """Initialize Streamlit session state variables."""
    if 'assessment_result' not in st.session_state:
        st.session_state.assessment_result = None
    if 'client' not in st.session_state:
        st.session_state.client = None
    if 'eval_results' not in st.session_state:
        st.session_state.eval_results = None
    if 'run_evaluation' not in st.session_state:
        st.session_state.run_evaluation = False


def setup_api_client():
    """Setup Gemini API client."""
    if not st.session_state.client:
        try:
            st.session_state.client = build_gemini_client()
            return True
        except Exception as e:
            st.error(f"API client initialization failed: {str(e)}")
            return False
    return True


def display_overview_tab(assessment):
    """Display overview tab with assessment summary."""
    st.header("Assessment Summary")

    col1, col2, col3 = st.columns(3)

    with col1:
        fitness_level = assessment.get('fitness_level_class', 'N/A')
        st.metric("Fitness Level Classification", fitness_level)
        confidence = assessment.get('fitness_confidence')
        if confidence is not None:
            st.caption(f"Assessment Confidence: {confidence:.1f}%")
        else:
            st.caption("Assessment Confidence: Pending")

    with col2:
        injury_risk = assessment.get('injury_risk_class', 'N/A')
        st.metric("Injury Risk Assessment", injury_risk)
        confidence = assessment.get('injury_confidence')
        if confidence is not None:
            st.caption(f"Assessment Confidence: {confidence:.1f}%")
        else:
            st.caption("Assessment Confidence: Pending")

    with col3:
        bmi = assessment.get('bmi')
        bmi_category = assessment.get('bmi_category', 'N/A')
        if bmi is not None:
            st.metric("Body Mass Index", f"{bmi:.1f}", bmi_category)
        else:
            st.metric("Body Mass Index", "N/A", bmi_category)

    st.divider()

    st.subheader("Personal Information")
    col1, col2, col3, col4 = st.columns(4)

    with col1:
        st.write(f"**Age:** {assessment.get('age')} years")
    with col2:
        st.write(f"**Gender:** {assessment.get('gender')}")
    with col3:
        st.write(f"**Height:** {assessment.get('height_cm')} cm")
    with col4:
        st.write(f"**Weight:** {assessment.get('weight_kg')} kg")

    st.write(f"**Primary Goal:** {assessment.get('fitness_goal')}")

    st.divider()

    st.subheader("Assessment Details")
    col1, col2 = st.columns(2)

    with col1:
        st.write("**Risk Factors Identified:**")
        risk_factors = assessment.get('injury_risk_factors', [])
        if risk_factors:
            for factor in risk_factors:
                st.write(f"• {factor}")
        else:
            st.write("No significant risk factors identified")

    with col2:
        st.write("**Fitness Profile:**")
        st.write(f"- Fitness Level: {assessment.get('fitness_level_class')}")
        st.write(f"- Age Category: {assessment.get('age_category')}")
        st.write(f"- BMI Category: {assessment.get('bmi_category')}")


def display_workout_tab(assessment):
    """Display detailed workout plan."""
    st.header("Workout Plan")

    col1, col2, col3, col4 = st.columns(4)

    with col1:
        freq = assessment.get('workout_frequency_per_week')
        st.metric("Weekly Frequency", f"{freq if freq is not None else 'N/A'} sessions")
    with col2:
        st.metric("Intensity Level", assessment.get('workout_intensity_level', 'N/A'))
    with col3:
        duration = assessment.get('workout_duration_per_session')
        st.metric("Session Duration", f"{duration if duration is not None else 'N/A'} min")
    with col4:
        st.metric("Progression Period", assessment.get('workout_progression_timeline', 'N/A'))

    st.divider()

    st.subheader("Weekly Exercise Schedule")
    schedule = assessment.get('weekly_schedule', {})
    if schedule and isinstance(schedule, dict):
        for day, exercises in schedule.items():
            with st.expander(f"{day}"):
                if isinstance(exercises, list):
                    for i, exercise in enumerate(exercises, 1):
                        if isinstance(exercise, dict):
                            st.write(f"**Exercise {i}: {exercise.get('name', 'Exercise')}**")
                            col1, col2, col3 = st.columns(3)
                            with col1:
                                st.write(f"Sets: {exercise.get('sets', 'N/A')}")
                            with col2:
                                st.write(f"Reps: {exercise.get('reps', 'N/A')}")
                            with col3:
                                st.write(f"Rest: {exercise.get('rest', 'N/A')}")
                        else:
                            st.write(f"{i}. {exercise}")
                else:
                    st.write(str(exercises))
    else:
        st.info("Schedule details will be provided by the LLM")

    st.divider()

    col1, col2 = st.columns(2)

    with col1:
        st.subheader("Equipment Required")
        equipment = assessment.get('workout_equipment_needed', [])
        if equipment:
            for item in equipment:
                st.write(f"• {item}")
        else:
            st.write("Bodyweight exercises only")

    with col2:
        st.subheader("Safety Guidelines")
        safety_notes = assessment.get('workout_safety_notes', [])
        if safety_notes:
            for note in safety_notes:
                st.info(note)
        else:
            st.write("Follow standard form and breathing techniques")


def display_nutrition_tab(assessment):
    """Display detailed nutrition plan."""
    st.header("Nutrition Plan")

    col1, col2, col3 = st.columns(3)

    with col1:
        calories = assessment.get('daily_calorie_target')
        st.metric("Daily Calorie Target", f"{calories if calories is not None else 'N/A'} kcal")

    with col2:
        hydration = assessment.get('hydration_recommendation', 'N/A')
        st.write("**Hydration Guide:**")
        st.write(hydration if isinstance(hydration, str) else "Personalized recommendations provided")

    with col3:
        st.write("**Macronutrient Targets:**")
        macros = assessment.get('macro_targets', {})
        if macros:
            st.write(f"- Protein: {macros.get('protein_g', 'N/A')}g")
            st.write(f"- Carbs: {macros.get('carbs_g', 'N/A')}g")
            st.write(f"- Fat: {macros.get('fat_g', 'N/A')}g")

    st.divider()

    st.subheader("Daily Meal Suggestions")
    meals = assessment.get('meal_suggestions', [])
    if meals:
        for i, meal in enumerate(meals, 1):
            if isinstance(meal, dict):
                with st.expander(f"Meal {i}: {meal.get('meal_name', 'Meal')}"):
                    foods = meal.get('foods', [])
                    if foods:
                        st.write("**Foods:**")
                        for food in foods:
                            st.write(f"• {food}")

                    col1, col2, col3, col4 = st.columns(4)
                    with col1:
                        st.metric("Protein", f"{meal.get('protein_g', 'N/A')}g")
                    with col2:
                        st.metric("Carbs", f"{meal.get('carbs_g', 'N/A')}g")
                    with col3:
                        st.metric("Fat", f"{meal.get('fat_g', 'N/A')}g")
                    with col4:
                        st.metric("Calories", f"{meal.get('calories', 'N/A')} kcal")
            else:
                st.write(f"**Meal {i}:** {meal}")
    else:
        st.info("Personalized meal suggestions will be provided")

    st.divider()

    st.subheader("Nutrition Timing")
    timing = assessment.get('nutrition_timing_guidance', 'N/A')
    st.write(timing if isinstance(timing, str) else "Pre-workout and post-workout nutrition guidance provided")


def display_recovery_tab(assessment):
    """Display recovery and lifestyle optimization."""
    st.header("Recovery & Lifestyle Optimization")

    st.subheader("Sleep & Recovery Management")
    col1, col2 = st.columns(2)

    with col1:
        st.write("**Sleep Recommendations**")
        sleep = assessment.get('sleep_recommendations', {})
        if isinstance(sleep, dict):
            hours = sleep.get('hours_per_night', 'N/A')
            st.write(f"**Target:** {hours} hours per night")
            tips = sleep.get('sleep_quality_tips', [])
            if tips:
                st.write("**Quality Enhancement Tips:**")
                for tip in tips:
                    st.write(f"• {tip}")
        else:
            st.write("Sleep recommendations will be customized")

    with col2:
        st.write("**Rest Day Activities**")
        rest_activities = assessment.get('rest_day_activities', [])
        if rest_activities:
            for activity in rest_activities:
                st.write(f"• {activity}")
        else:
            st.write("Light, low-intensity activities recommended")

    st.divider()

    st.subheader("Mobility & Flexibility")
    col1, col2 = st.columns(2)

    with col1:
        st.write("**Mobility Routines**")
        mobility = assessment.get('mobility_work', [])
        if mobility:
            for routine in mobility:
                st.write(f"• {routine}")
        else:
            st.write("Daily stretching and mobility work recommended")

    with col2:
        st.write("**Stress Management**")
        stress_mgmt = assessment.get('stress_management_techniques', [])
        if stress_mgmt:
            for technique in stress_mgmt:
                st.write(f"• {technique}")
        else:
            st.write("Meditation and breathing exercises recommended")

    st.divider()

    st.subheader("Advanced Recovery Methods")
    recovery_tech = assessment.get('recovery_techniques', [])
    if recovery_tech:
        for technique in recovery_tech:
            st.write(f"• {technique}")
    else:
        st.write("Standard recovery methods including rest and hydration")

    st.divider()

    st.subheader("Deload Strategy")
    deload = assessment.get('deload_strategy', 'N/A')
    st.write(deload if isinstance(deload, str) else "Periodic deload weeks will be incorporated into your plan")

    st.divider()

    st.header("Lifestyle Integration")

    st.subheader("Schedule Integration")
    schedule = assessment.get('schedule_integration', {})
    if isinstance(schedule, dict):
        best_days = schedule.get('best_days', [])
        best_times = schedule.get('best_times', [])

        col1, col2 = st.columns(2)
        with col1:
            if best_days:
                st.write("**Optimal Workout Days:**")
                for day in best_days:
                    st.write(f"• {day}")
        with col2:
            if best_times:
                st.write("**Optimal Workout Times:**")
                for time in best_times:
                    st.write(f"• {time}")

        tips = schedule.get('weekly_schedule_tips', '')
        if tips:
            st.write("**Weekly Planning Tips:**")
            st.write(tips)
    else:
        st.write("Customized schedule recommendations will be provided")

    st.divider()

    col1, col2 = st.columns(2)

    with col1:
        st.write("**Time Management Strategies**")
        time_tips = assessment.get('time_management_tips', [])
        if time_tips:
            for tip in time_tips:
                st.write(f"• {tip}")
        else:
            st.write("Strategies for consistent workout scheduling will be provided")

    with col2:
        st.write("**Habit Formation Approach**")
        habits = assessment.get('habit_formation_strategies', [])
        if habits:
            for strategy in habits:
                st.write(f"• {strategy}")
        else:
            st.write("Evidence-based habit formation techniques will be applied")

    st.divider()

    st.subheader("Adherence & Motivation")
    adherence = assessment.get('adherence_tips', [])
    if adherence:
        for tip in adherence:
            st.write(f"• {tip}")
    else:
        st.write("Personalized motivation strategies will support your consistency")


def export_assessment(assessment):
    """Export assessment results as formatted JSON."""
    export_data = {
        'metadata': {
            'plan_id': assessment.get('plan_id'),
            'timestamp': assessment.get('analysis_timestamp'),
            'user_name': assessment.get('user_name', 'Anonymous'),
        },
        'assessment': assessment
    }

    return json.dumps(export_data, indent=2)


def display_model_evaluation_section(eval_results):
    """Display ML Model Evaluation metrics in the UI."""
    st.markdown("---")
    st.header("Model Evaluation Metrics")
    st.write("Performance metrics of trained machine learning models on evaluation datasets")

    if not eval_results or (not eval_results.get('fitness_evaluation') and not eval_results.get('injury_evaluation')):
        st.info("Click 'Run Model Evaluation' in the sidebar to evaluate trained models.")
        return

    col1, col2 = st.columns(2)

    # Fitness Level Model Evaluation
    with col1:
        st.subheader("Fitness Level Model")
        fitness_eval = eval_results.get('fitness_evaluation', {})

        if 'error' in fitness_eval:
            st.error(f"Evaluation Error: {fitness_eval['error']}")
        else:
            # Calculate average metrics across classes
            precision_values = list(fitness_eval.get('precision_per_class', {}).values())
            recall_values = list(fitness_eval.get('recall_per_class', {}).values())
            f1_values = list(fitness_eval.get('f1_per_class', {}).values())

            avg_precision = sum(precision_values) / len(precision_values) if precision_values else 0
            avg_recall = sum(recall_values) / len(recall_values) if recall_values else 0
            avg_f1 = sum(f1_values) / len(f1_values) if f1_values else 0

            col1a, col1b, col1c, col1d = st.columns(4)
            with col1a:
                st.metric("Accuracy", f"{fitness_eval.get('eval_accuracy', 0)*100:.2f}%")
            with col1b:
                st.metric("Precision", f"{avg_precision*100:.2f}%")
            with col1c:
                st.metric("Recall", f"{avg_recall*100:.2f}%")
            with col1d:
                st.metric("F1-Score", f"{avg_f1*100:.2f}%")

            st.write(f"**Test Samples:** {fitness_eval.get('total_samples', 'N/A')}")

            # Per-class details
            with st.expander("View Per-Class Metrics"):
                for cls in fitness_eval.get('classes', []):
                    st.write(f"**{cls}:**")
                    col_a, col_b, col_c = st.columns(3)
                    with col_a:
                        st.write(f"Precision: {fitness_eval.get('precision_per_class', {}).get(cls, 0)*100:.2f}%")
                    with col_b:
                        st.write(f"Recall: {fitness_eval.get('recall_per_class', {}).get(cls, 0)*100:.2f}%")
                    with col_c:
                        st.write(f"F1: {fitness_eval.get('f1_per_class', {}).get(cls, 0)*100:.2f}%")

    # Injury Risk Model Evaluation
    with col2:
        st.subheader("Injury Risk Model")
        injury_eval = eval_results.get('injury_evaluation', {})

        if 'error' in injury_eval:
            st.error(f"Evaluation Error: {injury_eval['error']}")
        else:
            # Calculate average metrics across classes
            precision_values = list(injury_eval.get('precision_per_class', {}).values())
            recall_values = list(injury_eval.get('recall_per_class', {}).values())
            f1_values = list(injury_eval.get('f1_per_class', {}).values())

            avg_precision = sum(precision_values) / len(precision_values) if precision_values else 0
            avg_recall = sum(recall_values) / len(recall_values) if recall_values else 0
            avg_f1 = sum(f1_values) / len(f1_values) if f1_values else 0

            col2a, col2b, col2c, col2d = st.columns(4)
            with col2a:
                st.metric("Accuracy", f"{injury_eval.get('eval_accuracy', 0)*100:.2f}%")
            with col2b:
                st.metric("Precision", f"{avg_precision*100:.2f}%")
            with col2c:
                st.metric("Recall", f"{avg_recall*100:.2f}%")
            with col2d:
                st.metric("F1-Score", f"{avg_f1*100:.2f}%")

            st.write(f"**Test Samples:** {injury_eval.get('total_samples', 'N/A')}")

            # Per-class details
            with st.expander("View Per-Class Metrics"):
                for cls in injury_eval.get('classes', []):
                    st.write(f"**{cls}:**")
                    col_a, col_b, col_c = st.columns(3)
                    with col_a:
                        st.write(f"Precision: {injury_eval.get('precision_per_class', {}).get(cls, 0)*100:.2f}%")
                    with col_b:
                        st.write(f"Recall: {injury_eval.get('recall_per_class', {}).get(cls, 0)*100:.2f}%")
                    with col_c:
                        st.write(f"F1: {injury_eval.get('f1_per_class', {}).get(cls, 0)*100:.2f}%")


def main():
    """Main Streamlit application."""
    st.set_page_config(
        page_title="AetherFit - Fitness Assessment",
        page_icon=None,
        layout="wide",
        initial_sidebar_state="expanded"
    )

    st.title("AetherFit - Personalized Fitness Assessment")
    st.write("Comprehensive fitness assessment and personalized plans for workout, nutrition, and recovery.")

    initialize_session_state()

    with st.sidebar:
        st.header("Application Information")
        st.write("""
        AetherFit provides:
        - Fitness level assessment using machine learning
        - Injury risk evaluation based on profile analysis
        - Personalized workout planning
        - Customized nutrition guidance
        - Recovery and lifestyle optimization strategies
        """)

        st.divider()

        st.header("Tools")
        if st.button("Run Model Evaluation", use_container_width=True):
            st.session_state.run_evaluation = True

        st.divider()
        st.header("Assessment Details")
        show_debug = st.checkbox("Show Assessment Metadata")

    if st.session_state.assessment_result is None:
        st.header("Fitness Assessment Form")

        user_name = st.text_input("Your Name (optional)", "")

        col1, col2 = st.columns(2)

        with col1:
            age = st.number_input(
                "Age",
                min_value=18,
                max_value=100,
                value=30,
                help="Your age in years"
            )
            height_cm = st.number_input(
                "Height (cm)",
                min_value=100.0,
                max_value=250.0,
                value=170.0,
                step=0.1,
                help="Your height in centimeters"
            )
            weight_kg = st.number_input(
                "Weight (kg)",
                min_value=30.0,
                max_value=300.0,
                value=70.0,
                step=0.1,
                help="Your weight in kilograms"
            )

        with col2:
            gender = st.selectbox(
                "Gender",
                ["Male", "Female", "Other"],
                help="Your gender"
            )
            fitness_goal = st.selectbox(
                "Fitness Goal",
                ["Weight Loss", "Muscle Building", "Endurance/Cardio", "General Fitness"],
                help="Your primary fitness goal"
            )

        st.divider()

        st.subheader("Additional Information (Describe in Your Own Words)")

        fitness_experience = st.text_area(
            "Fitness Experience",
            placeholder="Describe your fitness background, experience level, and any specific activities you enjoy",
            height=100,
            help="Provide details about your training history and experience"
        )

        health_conditions = st.text_area(
            "Health Conditions and Injuries",
            placeholder="Mention any medical conditions, injuries, physical limitations, or health concerns",
            height=100,
            help="Include current and past health issues that may affect exercise"
        )

        available_schedule = st.text_area(
            "Schedule and Availability",
            placeholder="Describe when you are typically available to exercise and any time constraints",
            height=100,
            help="Provide information about your weekly schedule and workout availability"
        )

        st.divider()

        col1, col2, col3 = st.columns([1, 1, 2])

        with col1:
            submit_button = st.button("Generate Assessment", type="primary", use_container_width=True)

        with col2:
            if st.button("Clear Form", use_container_width=True):
                st.rerun()

        if submit_button:
            if not fitness_experience or not health_conditions or not available_schedule:
                st.error("Please complete all text fields")
            elif not setup_api_client():
                st.error("API client setup failed. Check your GEMINI_API_KEY environment variable.")
            else:
                with st.spinner("Processing assessment... This may take a moment."):
                    try:
                        result = assess_fitness(
                            age=age,
                            height_cm=height_cm,
                            weight_kg=weight_kg,
                            gender=gender,
                            fitness_goal=fitness_goal,
                            fitness_experience=fitness_experience,
                            health_conditions=health_conditions,
                            available_hours_per_week=available_schedule,
                            client=st.session_state.client,
                            user_name=user_name if user_name else "Anonymous"
                        )

                        st.session_state.assessment_result = result

                        if result.get('error_occurred'):
                            st.warning("Assessment completed with some limitations")
                            for error in result.get('error_messages', []):
                                st.warning(f"• {error}")
                        else:
                            st.success("Assessment completed successfully")
                        st.rerun()

                    except Exception as e:
                        st.error(f"Assessment processing failed: {str(e)}")

    else:
        assessment = st.session_state.assessment_result

        col1, col2, col3 = st.columns([4, 1, 1])

        with col1:
            st.header(f"Assessment Results - {assessment.get('user_name', 'User')}")

        with col2:
            if st.button("New Assessment", use_container_width=True):
                st.session_state.assessment_result = None
                st.rerun()

        with col3:
            json_export = export_assessment(assessment)
            st.download_button(
                label="Download JSON",
                data=json_export,
                file_name=f"assessment_{assessment.get('plan_id', 'export')}.json",
                mime="application/json",
                use_container_width=True
            )

        st.divider()

        tab1, tab2, tab3, tab4 = st.tabs([
            "Overview",
            "Workout Plan",
            "Nutrition Plan",
            "Recovery & Lifestyle"
        ])

        with tab1:
            display_overview_tab(assessment)

        with tab2:
            display_workout_tab(assessment)

        with tab3:
            display_nutrition_tab(assessment)

        with tab4:
            display_recovery_tab(assessment)

        if show_debug:
            st.divider()
            with st.expander("Assessment Metadata"):
                col1, col2 = st.columns(2)
                with col1:
                    st.write(f"Plan ID: {assessment.get('plan_id')}")
                    st.write(f"Timestamp: {assessment.get('analysis_timestamp')}")
                with col2:
                    analysis_status = {
                        'Fitness Assessment': assessment.get('fitness_analysis_complete'),
                        'Injury Assessment': assessment.get('injury_assessment_complete'),
                        'Workout Plan': assessment.get('workout_analysis_complete'),
                        'Nutrition Plan': assessment.get('nutrition_analysis_complete'),
                        'Recovery Plan': assessment.get('recovery_lifestyle_analysis_complete'),
                    }
                    for key, value in analysis_status.items():
                        status = "Complete" if value else "Incomplete"
                        st.write(f"{key}: {status}")

    # Handle model evaluation
    if st.session_state.run_evaluation:
        try:
            from pathlib import Path
            from ml.evaluation.evaluate_models import evaluate_all_models

            with st.spinner("Evaluating models..."):
                project_root = str(Path(__file__).parent)
                eval_results = evaluate_all_models(project_root)
                st.session_state.eval_results = eval_results
                st.success("Model evaluation complete!")
        except Exception as e:
            st.error(f"Evaluation failed: {str(e)}")
        finally:
            st.session_state.run_evaluation = False

    # Display evaluation results
    if st.session_state.eval_results:
        display_model_evaluation_section(st.session_state.eval_results)


if __name__ == "__main__":
    main()
