from typing import Dict, Any

from agents.workout_plan_generator_llm import WorkoutPlanGeneratorLLMAgent
from state import FitnessAssessmentState


def workout_planner_node(state: FitnessAssessmentState, client) -> Dict[str, Any]:
    """
    Generate personalized workout plan using LLM.

    Args:
        state: Current FitnessAssessmentState
        client: LLM client (Gemini)

    Returns:
        Dictionary with workout plan details
    """
    try:
        agent = WorkoutPlanGeneratorLLMAgent(client=client)

        profile = {
            "fitness_level_class": state.get("fitness_level_class", "Intermediate"),
            "injury_risk_class": state.get("injury_risk_class", "Moderate Risk"),
            "fitness_goal": state.get("fitness_goal"),
            "available_hours_per_week": state.get("available_hours_per_week"),
            "health_conditions": state.get("health_conditions"),
            "gender": state.get("gender"),
            "age": state.get("age"),
        }

        # Add schedule preferences from normalized schedule if available
        normalized_schedule = state.get("normalized_schedule")
        if normalized_schedule:
            profile["preferred_days"] = normalized_schedule.get("preferred_days", [])
            profile["preferred_times"] = normalized_schedule.get("preferred_times", [])

        result = agent.generate_workout_plan(profile)

        return {
            "workout_plan": result,
            "weekly_schedule": result.get("weekly_schedule"),
            "workout_intensity_level": result.get("workout_intensity_level"),
            "workout_duration_per_session": result.get("workout_duration_per_session"),
            "workout_frequency_per_week": result.get("workout_frequency_per_week"),
            "workout_progression_timeline": result.get("workout_progression_timeline"),
            "workout_safety_notes": result.get("workout_safety_notes", []),
            "workout_equipment_needed": result.get("workout_equipment_needed", []),
            "workout_analysis_complete": True,
        }

    except Exception as e:
        print(f"Workout plan generation error: {str(e)}")
        return {
            "workout_plan": None,
            "weekly_schedule": None,
            "workout_intensity_level": None,
            "workout_duration_per_session": None,
            "workout_frequency_per_week": None,
            "workout_progression_timeline": None,
            "workout_safety_notes": [],
            "workout_equipment_needed": [],
            "workout_analysis_complete": False,
        }
