from typing import Dict, Any

from agents.nutrition_plan_generator_llm import NutritionPlanGeneratorLLMAgent
from state import FitnessAssessmentState


def nutrition_advisor_node(state: FitnessAssessmentState, client) -> Dict[str, Any]:
    """
    Generate personalized nutrition plan using LLM.

    Args:
        state: Current FitnessAssessmentState
        client: LLM client (Gemini)

    Returns:
        Dictionary with nutrition plan details
    """
    try:
        agent = NutritionPlanGeneratorLLMAgent(client=client)

        profile = {
            "age": state.get("age"),
            "weight_kg": state.get("weight_kg"),
            "height_cm": state.get("height_cm"),
            "gender": state.get("gender"),
            "fitness_goal": state.get("fitness_goal"),
            "fitness_level_class": state.get("fitness_level_class"),
            "bmi": state.get("bmi"),
            "workout_frequency_per_week": state.get("workout_frequency_per_week"),
        }

        result = agent.generate_nutrition_plan(profile)

        return {
            "nutrition_plan": result,
            "daily_calorie_target": result.get("daily_calorie_target"),
            "macro_targets": result.get("macro_targets"),
            "meal_suggestions": result.get("meal_suggestions", []),
            "hydration_recommendation": result.get("hydration_recommendation"),
            "nutrition_timing_guidance": result.get("nutrition_timing_guidance"),
            "nutrition_analysis_complete": True,
        }

    except Exception as e:
        print(f"Nutrition plan generation error: {str(e)}")
        return {
            "nutrition_plan": None,
            "daily_calorie_target": None,
            "macro_targets": None,
            "meal_suggestions": [],
            "hydration_recommendation": None,
            "nutrition_timing_guidance": None,
            "nutrition_analysis_complete": False,
        }
