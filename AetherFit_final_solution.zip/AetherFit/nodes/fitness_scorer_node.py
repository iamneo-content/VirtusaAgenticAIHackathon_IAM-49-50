from typing import Dict, Any

from agents.fitness_scorer_ml import FitnessScorerMLAgent
from state import FitnessAssessmentState


def fitness_scorer_node(state: FitnessAssessmentState, client=None) -> Dict[str, Any]:
    """
    Score fitness level using ML model.
    Predicts: Beginner, Intermediate, Advanced, Athlete

    Args:
        state: Current FitnessAssessmentState
        client: LLM client (not used in this node)

    Returns:
        Dictionary with fitness level predictions
    """
    try:
        agent = FitnessScorerMLAgent()

        user_profile = state.get("parsed_profile", {})
        if not user_profile:
            user_profile = {
                "age": state.get("age"),
                "bmi": state.get("bmi"),
                "weight_kg": state.get("weight_kg"),
                "gender": state.get("gender"),
                "fitness_goal": state.get("fitness_goal"),
                "age_category": state.get("age_category"),
                "bmi_category": state.get("bmi_category"),
            }

        # Add normalized experience level if available
        normalized_exp = state.get("normalized_fitness_experience")
        if normalized_exp:
            user_profile["fitness_experience_level"] = normalized_exp.get("experience_level", "Beginner")

        result = agent.predict_fitness_level(user_profile)

        return {
            "fitness_level_score": result["fitness_level_score"],
            "fitness_level_class": result["fitness_level_class"],
            "fitness_confidence": result["fitness_confidence"],
            "fitness_analysis_complete": True,
        }

    except Exception as e:
        print(f"Fitness scoring error: {str(e)}")
        return {
            "fitness_level_score": 0.0,
            "fitness_level_class": "Unknown",
            "fitness_confidence": 0.0,
            "fitness_analysis_complete": False,
        }
