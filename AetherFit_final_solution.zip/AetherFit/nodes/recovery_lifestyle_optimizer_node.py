from typing import Dict, Any

from agents.recovery_lifestyle_optimizer_llm import RecoveryLifestyleOptimizerLLMAgent
from state import FitnessAssessmentState


def recovery_lifestyle_optimizer_node(state: FitnessAssessmentState, client) -> Dict[str, Any]:
    """
    Generate recovery and lifestyle optimization plan using LLM.

    Args:
        state: Current FitnessAssessmentState
        client: LLM client (Gemini)

    Returns:
        Dictionary with recovery and lifestyle details
    """
    try:
        agent = RecoveryLifestyleOptimizerLLMAgent(client=client)

        profile = {
            "age": state.get("age"),
            "fitness_level_class": state.get("fitness_level_class"),
            "injury_risk_class": state.get("injury_risk_class"),
            "health_conditions": state.get("health_conditions"),
            "fitness_goal": state.get("fitness_goal"),
            "workout_frequency_per_week": state.get("workout_frequency_per_week"),
            "available_hours_per_week": state.get("available_hours_per_week"),
        }

        # Add normalized schedule if available
        normalized_schedule = state.get("normalized_schedule")
        if normalized_schedule:
            profile["preferred_days"] = normalized_schedule.get("preferred_days", [])
            profile["preferred_times"] = normalized_schedule.get("preferred_times", [])

        result = agent.generate_recovery_lifestyle_plan(profile)

        return {
            "sleep_recommendations": result.get("sleep_recommendations"),
            "rest_day_activities": result.get("rest_day_activities", []),
            "mobility_work": result.get("mobility_work", []),
            "stress_management_techniques": result.get("stress_management_techniques", []),
            "recovery_techniques": result.get("recovery_techniques", []),
            "deload_strategy": result.get("deload_strategy"),
            "schedule_integration": result.get("schedule_integration"),
            "time_management_tips": result.get("time_management_tips", []),
            "habit_formation_strategies": result.get("habit_formation_strategies", []),
            "adherence_tips": result.get("adherence_tips", []),
            "recovery_lifestyle_analysis_complete": True,
        }

    except Exception as e:
        print(f"Recovery/lifestyle optimization error: {str(e)}")
        return {
            "sleep_recommendations": None,
            "rest_day_activities": [],
            "mobility_work": [],
            "stress_management_techniques": [],
            "recovery_techniques": [],
            "deload_strategy": None,
            "schedule_integration": None,
            "time_management_tips": [],
            "habit_formation_strategies": [],
            "adherence_tips": [],
            "recovery_lifestyle_analysis_complete": False,
        }
