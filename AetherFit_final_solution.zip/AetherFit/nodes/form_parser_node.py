from typing import Dict, Any

from agents.form_parser_agent import FormParserAgent
from state import FitnessAssessmentState


def form_parser_node(state: FitnessAssessmentState, client=None) -> Dict[str, Any]:
    """
    Parse and validate form inputs.
    Calculates BMI and age/BMI categories.

    Args:
        state: Current FitnessAssessmentState
        client: LLM client (not used in this node)

    Returns:
        Dictionary with parsed profile and validation results
    """
    try:
        agent = FormParserAgent()

        form_data = {
            "age": state.get("age"),
            "height_cm": state.get("height_cm"),
            "weight_kg": state.get("weight_kg"),
            "gender": state.get("gender"),
            "fitness_goal": state.get("fitness_goal"),
            "fitness_experience": state.get("fitness_experience"),
            "health_conditions": state.get("health_conditions"),
            "available_hours_per_week": state.get("available_hours_per_week"),
        }

        result = agent.validate_and_parse(form_data)

        return {
            "parsed_profile": result["parsed_profile"],
            "bmi": result["bmi"],
            "age_category": result["age_category"],
            "bmi_category": result["bmi_category"],
            "validation_errors": result["validation_errors"],
            "parsing_complete": result["parsing_complete"],
            "error_occurred": result["error_occurred"],
        }

    except Exception as e:
        return {
            "parsed_profile": None,
            "bmi": None,
            "age_category": None,
            "bmi_category": None,
            "validation_errors": [f"Form parsing error: {str(e)}"],
            "parsing_complete": False,
            "error_occurred": True,
        }
