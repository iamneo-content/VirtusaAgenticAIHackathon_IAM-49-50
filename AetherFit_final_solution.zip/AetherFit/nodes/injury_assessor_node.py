from typing import Dict, Any

from agents.injury_assessor_ml import InjuryAssessorMLAgent
from state import FitnessAssessmentState


def injury_assessor_node(state: FitnessAssessmentState, client=None) -> Dict[str, Any]:
    """
    Assess injury risk using ML model.
    Predicts: Low Risk, Moderate Risk, High Risk, Very High Risk

    Args:
        state: Current FitnessAssessmentState
        client: LLM client (not used in this node)

    Returns:
        Dictionary with injury risk predictions
    """
    try:
        agent = InjuryAssessorMLAgent()

        user_profile = state.get("parsed_profile", {})
        if not user_profile:
            user_profile = {
                "age": state.get("age"),
                "bmi": state.get("bmi"),
                "gender": state.get("gender"),
                "fitness_goal": state.get("fitness_goal"),
                "age_category": state.get("age_category"),
                "bmi_category": state.get("bmi_category"),
                "health_conditions": state.get("health_conditions"),
            }

        # Add fitness level from previous node
        user_profile["fitness_level_class"] = state.get("fitness_level_class", "Intermediate")

        # Add normalized experience if available
        normalized_exp = state.get("normalized_fitness_experience")
        if normalized_exp:
            user_profile["fitness_experience_level"] = normalized_exp.get("experience_level", "Beginner")

        # Add available hours
        user_profile["available_hours_per_week"] = state.get("available_hours_per_week", 4)

        result = agent.predict_injury_risk(user_profile)

        return {
            "injury_risk_score": result["injury_risk_score"],
            "injury_risk_class": result["injury_risk_class"],
            "injury_confidence": result["injury_confidence"],
            "injury_risk_factors": result["injury_risk_factors"],
            "injury_assessment_complete": True,
        }

    except Exception as e:
        print(f"Injury assessment error: {str(e)}")
        return {
            "injury_risk_score": 0.0,
            "injury_risk_class": "Unknown",
            "injury_confidence": 0.0,
            "injury_risk_factors": [],
            "injury_assessment_complete": False,
        }
