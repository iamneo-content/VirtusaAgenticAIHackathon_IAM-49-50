from typing import Dict, Any

from agents.input_normalizer_llm import InputNormalizerLLMAgent
from state import FitnessAssessmentState


def input_normalizer_node(state: FitnessAssessmentState, client) -> Dict[str, Any]:
    """
    Normalize natural language inputs using LLM.
    Parses fitness_experience, health_conditions, and available_hours_per_week.

    Args:
        state: Current FitnessAssessmentState
        client: LLM client (Gemini)

    Returns:
        Dictionary with normalized input fields
    """
    try:
        agent = InputNormalizerLLMAgent(client=client)

        fitness_experience = state.get("fitness_experience", "")
        health_conditions = state.get("health_conditions", "")
        available_hours = state.get("available_hours_per_week", "")

        result = agent.normalize_inputs(fitness_experience, health_conditions, available_hours)

        return {
            "normalized_fitness_experience": result["normalized_fitness_experience"],
            "normalized_health_conditions": result["normalized_health_conditions"],
            "normalized_schedule": result["normalized_schedule"],
        }

    except Exception as e:
        print(f"Input normalization error: {str(e)}")
        return {
            "normalized_fitness_experience": None,
            "normalized_health_conditions": None,
            "normalized_schedule": None,
        }
