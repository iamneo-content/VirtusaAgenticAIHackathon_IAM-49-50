"""Evaluate trained ML models on evaluation datasets."""

import pandas as pd
import numpy as np
import pickle
from pathlib import Path
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import (
    classification_report, confusion_matrix, accuracy_score,
    precision_recall_fscore_support, roc_auc_score, roc_curve
)


def evaluate_fitness_level_model(
    eval_data_path: str,
    model_path: str,
    scaler_path: str,
    encoder_path: str
) -> dict:
    """
    Evaluate fitness level model on evaluation dataset.

    Args:
        eval_data_path: Path to evaluation CSV
        model_path: Path to trained model (.pkl)
        scaler_path: Path to StandardScaler (.pkl)
        encoder_path: Path to LabelEncoder (.pkl)

    Returns:
        Dictionary with evaluation metrics
    """
    # Load data
    df = pd.read_csv(eval_data_path)

    # Load model, scaler, and encoder
    with open(model_path, 'rb') as f:
        model = pickle.load(f)

    with open(scaler_path, 'rb') as f:
        scaler = pickle.load(f)

    with open(encoder_path, 'rb') as f:
        encoder_data = pickle.load(f)

    feature_columns = encoder_data['feature_columns']
    label_encoder_target = encoder_data['target_encoder']
    feature_encoders = encoder_data['feature_encoders']

    # Prepare data
    X = df[feature_columns].copy()
    y = df['Fitness_Level_Class'].copy()

    # Encode categorical features
    for col in feature_encoders.keys():
        X[col] = feature_encoders[col].transform(X[col])

    # Encode target
    y_encoded = label_encoder_target.transform(y)

    # Scale features
    X_scaled = scaler.transform(X)

    # Make predictions
    y_pred = model.predict(X_scaled)
    y_pred_proba = model.predict_proba(X_scaled)

    # Calculate metrics
    accuracy = accuracy_score(y_encoded, y_pred)
    class_report = classification_report(y_encoded, y_pred, output_dict=True)
    conf_matrix = confusion_matrix(y_encoded, y_pred)

    # Per-class metrics
    precision, recall, f1, support = precision_recall_fscore_support(
        y_encoded, y_pred, average=None, zero_division=0
    )

    results = {
        'model': 'Fitness Level Classifier',
        'eval_accuracy': accuracy,
        'total_samples': len(X),
        'classes': list(label_encoder_target.classes_),
        'class_counts': y.value_counts().to_dict(),
        'precision_per_class': dict(zip(label_encoder_target.classes_, precision)),
        'recall_per_class': dict(zip(label_encoder_target.classes_, recall)),
        'f1_per_class': dict(zip(label_encoder_target.classes_, f1)),
        'support_per_class': dict(zip(label_encoder_target.classes_, support)),
        'classification_report': class_report,
        'confusion_matrix': conf_matrix.tolist()
    }

    return results


def evaluate_injury_risk_model(
    eval_data_path: str,
    model_path: str,
    scaler_path: str,
    encoder_path: str
) -> dict:
    """
    Evaluate injury risk model on evaluation dataset.

    Args:
        eval_data_path: Path to evaluation CSV
        model_path: Path to trained model (.pkl)
        scaler_path: Path to StandardScaler (.pkl)
        encoder_path: Path to LabelEncoder (.pkl)

    Returns:
        Dictionary with evaluation metrics
    """
    # Load data
    df = pd.read_csv(eval_data_path)

    # Load model, scaler, and encoder
    with open(model_path, 'rb') as f:
        model = pickle.load(f)

    with open(scaler_path, 'rb') as f:
        scaler = pickle.load(f)

    with open(encoder_path, 'rb') as f:
        encoder_data = pickle.load(f)

    feature_columns = encoder_data['feature_columns']
    label_encoder_target = encoder_data['target_encoder']
    feature_encoders = encoder_data['feature_encoders']

    # Prepare data
    X = df[feature_columns].copy()
    y = df['Injury_Risk_Class'].copy()

    # Encode categorical features
    for col in feature_encoders.keys():
        X[col] = feature_encoders[col].transform(X[col])

    # Encode target
    y_encoded = label_encoder_target.transform(y)

    # Scale features
    X_scaled = scaler.transform(X)

    # Make predictions
    y_pred = model.predict(X_scaled)
    y_pred_proba = model.predict_proba(X_scaled)

    # Calculate metrics
    accuracy = accuracy_score(y_encoded, y_pred)
    class_report = classification_report(y_encoded, y_pred, output_dict=True)
    conf_matrix = confusion_matrix(y_encoded, y_pred)

    # Per-class metrics
    precision, recall, f1, support = precision_recall_fscore_support(
        y_encoded, y_pred, average=None, zero_division=0
    )

    results = {
        'model': 'Injury Risk Classifier',
        'eval_accuracy': accuracy,
        'total_samples': len(X),
        'classes': list(label_encoder_target.classes_),
        'class_counts': y.value_counts().to_dict(),
        'precision_per_class': dict(zip(label_encoder_target.classes_, precision)),
        'recall_per_class': dict(zip(label_encoder_target.classes_, recall)),
        'f1_per_class': dict(zip(label_encoder_target.classes_, f1)),
        'support_per_class': dict(zip(label_encoder_target.classes_, support)),
        'classification_report': class_report,
        'confusion_matrix': conf_matrix.tolist()
    }

    return results


def evaluate_all_models(
    project_root: str = None
) -> dict:
    """
    Evaluate all trained ML models on their respective evaluation datasets.

    Args:
        project_root: Root directory of AetherFit project (default: current working directory)

    Returns:
        Dictionary with evaluation results for both models
    """
    from datetime import datetime

    if project_root is None:
        project_root = str(Path.cwd())

    project_path = Path(project_root)

    # Define paths
    fitness_eval_data = project_path / "data" / "evaluation_dataset" / "fitness_level_evaluation.csv"
    injury_eval_data = project_path / "data" / "evaluation_dataset" / "injury_risk_evaluation.csv"

    models_dir = project_path / "ml" / "models"

    fitness_model_path = models_dir / "fitness_level_model.pkl"
    fitness_scaler_path = models_dir / "fitness_level_scaler.pkl"
    fitness_encoder_path = models_dir / "fitness_level_encoder.pkl"

    injury_model_path = models_dir / "injury_risk_model.pkl"
    injury_scaler_path = models_dir / "injury_risk_scaler.pkl"
    injury_encoder_path = models_dir / "injury_risk_encoder.pkl"

    results = {
        'timestamp': datetime.now().isoformat(),
        'fitness_evaluation': None,
        'injury_evaluation': None,
    }

    try:
        # Evaluate fitness level model
        results['fitness_evaluation'] = evaluate_fitness_level_model(
            str(fitness_eval_data),
            str(fitness_model_path),
            str(fitness_scaler_path),
            str(fitness_encoder_path)
        )
    except Exception as e:
        print(f"Fitness model evaluation error: {str(e)}")
        results['fitness_evaluation'] = {'error': str(e)}

    try:
        # Evaluate injury risk model
        results['injury_evaluation'] = evaluate_injury_risk_model(
            str(injury_eval_data),
            str(injury_model_path),
            str(injury_scaler_path),
            str(injury_encoder_path)
        )
    except Exception as e:
        print(f"Injury risk model evaluation error: {str(e)}")
        results['injury_evaluation'] = {'error': str(e)}

    return results
