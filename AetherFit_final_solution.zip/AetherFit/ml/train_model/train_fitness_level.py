"""Train fitness level classifier using RandomForest."""

import pandas as pd
import numpy as np
import pickle
from pathlib import Path
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score


def train_fitness_level_model(
    training_data_path: str,
    model_output_path: str,
    scaler_output_path: str,
    encoder_output_path: str
) -> dict:
    """
    Train fitness level RandomForest classifier.

    Args:
        training_data_path: Path to cleaned training CSV
        model_output_path: Path to save trained model (.pkl)
        scaler_output_path: Path to save StandardScaler (.pkl)
        encoder_output_path: Path to save LabelEncoder (.pkl)

    Returns:
        Dictionary with training results and metrics
    """
    # Load data
    df = pd.read_csv(training_data_path)

    # Define features and target
    feature_columns = [
        'Age', 'BMI', 'Weight_KG', 'Available_Hours_Per_Week',
        'Gender', 'Fitness_Experience', 'Age_Category', 'Fitness_Goal',
        'BMI_Category', 'Hours_Category', 'Activity_Score'
    ]

    X = df[feature_columns].copy()
    y = df['Fitness_Level_Class'].copy()

    # Encode categorical features
    label_encoders = {}
    categorical_cols = ['Gender', 'Fitness_Experience', 'Age_Category', 'Fitness_Goal', 'BMI_Category', 'Hours_Category']

    for col in categorical_cols:
        le = LabelEncoder()
        X[col] = le.fit_transform(X[col])
        label_encoders[col] = le

    # Encode target variable
    label_encoder_target = LabelEncoder()
    y_encoded = label_encoder_target.fit_transform(y)

    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y_encoded, test_size=0.2, random_state=42, stratify=y_encoded
    )

    # Scale features
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    # Train RandomForest model
    model = RandomForestClassifier(
        n_estimators=100,
        max_depth=10,
        min_samples_split=5,
        min_samples_leaf=2,
        random_state=42,
        class_weight='balanced',
        n_jobs=-1
    )
    model.fit(X_train_scaled, y_train)

    # Evaluate model
    y_pred = model.predict(X_test_scaled)
    accuracy = accuracy_score(y_test, y_pred)
    class_report = classification_report(y_test, y_pred, output_dict=True)

    # Save model, scaler, and encoder
    Path(model_output_path).parent.mkdir(parents=True, exist_ok=True)
    Path(scaler_output_path).parent.mkdir(parents=True, exist_ok=True)
    Path(encoder_output_path).parent.mkdir(parents=True, exist_ok=True)

    with open(model_output_path, 'wb') as f:
        pickle.dump(model, f)

    with open(scaler_output_path, 'wb') as f:
        pickle.dump(scaler, f)

    encoder_data = {
        'target_encoder': label_encoder_target,
        'feature_encoders': label_encoders,
        'feature_columns': feature_columns
    }
    with open(encoder_output_path, 'wb') as f:
        pickle.dump(encoder_data, f)

    # Feature importance
    feature_importance = dict(zip(feature_columns, model.feature_importances_))
    sorted_importance = sorted(feature_importance.items(), key=lambda x: x[1], reverse=True)

    results = {
        'model_accuracy': accuracy,
        'total_samples': len(X),
        'train_samples': len(X_train),
        'test_samples': len(X_test),
        'classes': list(label_encoder_target.classes_),
        'feature_importance': dict(sorted_importance),
        'classification_report': class_report,
        'confusion_matrix': confusion_matrix(y_test, y_pred).tolist()
    }

    return results
