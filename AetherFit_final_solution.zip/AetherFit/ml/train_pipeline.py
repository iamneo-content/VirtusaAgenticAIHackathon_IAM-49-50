"""Master orchestrator for ML training pipeline."""

import sys
from pathlib import Path

# Add project root to sys.path to ensure imports work in all scenarios
# (script execution, module import, and pytest)
project_root = str(Path(__file__).parent.parent)
if project_root not in sys.path:
    sys.path.insert(0, project_root)

# Try relative imports first (when imported as module), fall back to absolute
try:
    from .data_cleaning.clean_fitness_data import clean_fitness_data
    from .data_cleaning.clean_injury_data import clean_injury_data
    from .train_model.train_fitness_level import train_fitness_level_model
    from .train_model.train_injury_risk import train_injury_risk_model
    from .evaluation.evaluate_models import evaluate_fitness_level_model, evaluate_injury_risk_model
except ImportError:
    # Fall back to absolute imports when run as a script
    from ml.data_cleaning.clean_fitness_data import clean_fitness_data
    from ml.data_cleaning.clean_injury_data import clean_injury_data
    from ml.train_model.train_fitness_level import train_fitness_level_model
    from ml.train_model.train_injury_risk import train_injury_risk_model
    from ml.evaluation.evaluate_models import evaluate_fitness_level_model, evaluate_injury_risk_model


def run_training_pipeline(project_root: str = None) -> dict:
    """
    Execute complete ML training pipeline.

    Steps:
    1. Clean fitness level training data
    2. Clean injury risk training data
    3. Train fitness level model
    4. Train injury risk model
    5. Evaluate both models

    Args:
        project_root: Root directory of AetherFit project (default: current working directory)

    Returns:
        Dictionary with pipeline execution results
    """
    if project_root is None:
        project_root = str(Path.cwd())

    project_path = Path(project_root)

    # Define paths
    fitness_train_raw = project_path / "data" / "training_dataset" / "fitness_level_training.csv"
    injury_train_raw = project_path / "data" / "training_dataset" / "injury_risk_training.csv"
    fitness_eval_raw = project_path / "data" / "evaluation_dataset" / "fitness_level_evaluation.csv"
    injury_eval_raw = project_path / "data" / "evaluation_dataset" / "injury_risk_evaluation.csv"

    fitness_train_cleaned = project_path / "data" / "processed" / "fitness_level_training_cleaned.csv"
    injury_train_cleaned = project_path / "data" / "processed" / "injury_risk_training_cleaned.csv"

    models_dir = project_path / "ml" / "models"
    models_dir.mkdir(parents=True, exist_ok=True)

    fitness_model_path = models_dir / "fitness_level_model.pkl"
    fitness_scaler_path = models_dir / "fitness_level_scaler.pkl"
    fitness_encoder_path = models_dir / "fitness_level_encoder.pkl"

    injury_model_path = models_dir / "injury_risk_model.pkl"
    injury_scaler_path = models_dir / "injury_risk_scaler.pkl"
    injury_encoder_path = models_dir / "injury_risk_encoder.pkl"

    results = {}

    try:
        # Step 1: Clean fitness data
        print("\n" + "="*60)
        print("STEP 1: Cleaning Fitness Level Training Data")
        print("="*60)

        fitness_train_df = clean_fitness_data(
            str(fitness_train_raw),
            str(fitness_train_cleaned)
        )
        print(f"✓ Fitness training data cleaned")
        print(f"  Samples: {len(fitness_train_df)}")
        print(f"  Class distribution: {fitness_train_df['Fitness_Level_Class'].value_counts().to_dict()}")

        # Step 2: Clean injury data
        print("\n" + "="*60)
        print("STEP 2: Cleaning Injury Risk Training Data")
        print("="*60)

        injury_train_df = clean_injury_data(
            str(injury_train_raw),
            str(injury_train_cleaned)
        )
        print(f"✓ Injury risk training data cleaned")
        print(f"  Samples: {len(injury_train_df)}")
        print(f"  Class distribution: {injury_train_df['Injury_Risk_Class'].value_counts().to_dict()}")

        # Step 3: Train fitness level model
        print("\n" + "="*60)
        print("STEP 3: Training Fitness Level Model")
        print("="*60)

        fitness_train_results = train_fitness_level_model(
            str(fitness_train_cleaned),
            str(fitness_model_path),
            str(fitness_scaler_path),
            str(fitness_encoder_path)
        )
        print(f"✓ Fitness level model trained")
        print(f"  Accuracy: {fitness_train_results['model_accuracy']:.4f}")
        print(f"  Classes: {fitness_train_results['classes']}")
        print(f"  Model saved to: {fitness_model_path}")
        results['fitness_training'] = fitness_train_results

        # Step 4: Train injury risk model
        print("\n" + "="*60)
        print("STEP 4: Training Injury Risk Model")
        print("="*60)

        injury_train_results = train_injury_risk_model(
            str(injury_train_cleaned),
            str(injury_model_path),
            str(injury_scaler_path),
            str(injury_encoder_path)
        )
        print(f"✓ Injury risk model trained")
        print(f"  Accuracy: {injury_train_results['model_accuracy']:.4f}")
        print(f"  Classes: {injury_train_results['classes']}")
        print(f"  Model saved to: {injury_model_path}")
        results['injury_training'] = injury_train_results

        # Step 5: Evaluate fitness model
        print("\n" + "="*60)
        print("STEP 5: Evaluating Fitness Level Model")
        print("="*60)

        fitness_eval_results = evaluate_fitness_level_model(
            str(fitness_eval_raw),
            str(fitness_model_path),
            str(fitness_scaler_path),
            str(fitness_encoder_path)
        )
        print(f"✓ Fitness level model evaluated")
        print(f"  Evaluation Accuracy: {fitness_eval_results['eval_accuracy']:.4f}")
        print(f"  Total eval samples: {fitness_eval_results['total_samples']}")
        results['fitness_evaluation'] = fitness_eval_results

        # Step 6: Evaluate injury model
        print("\n" + "="*60)
        print("STEP 6: Evaluating Injury Risk Model")
        print("="*60)

        injury_eval_results = evaluate_injury_risk_model(
            str(injury_eval_raw),
            str(injury_model_path),
            str(injury_scaler_path),
            str(injury_encoder_path)
        )
        print(f"✓ Injury risk model evaluated")
        print(f"  Evaluation Accuracy: {injury_eval_results['eval_accuracy']:.4f}")
        print(f"  Total eval samples: {injury_eval_results['total_samples']}")
        results['injury_evaluation'] = injury_eval_results

        # Summary
        print("\n" + "="*60)
        print("PIPELINE EXECUTION SUMMARY")
        print("="*60)
        print(f"✓ Fitness Level Model")
        print(f"  Training Accuracy: {fitness_train_results['model_accuracy']:.4f}")
        print(f"  Evaluation Accuracy: {fitness_eval_results['eval_accuracy']:.4f}")
        print(f"\n✓ Injury Risk Model")
        print(f"  Training Accuracy: {injury_train_results['model_accuracy']:.4f}")
        print(f"  Evaluation Accuracy: {injury_eval_results['eval_accuracy']:.4f}")
        print(f"\n✓ All models saved to: {models_dir}")
        print("="*60)

        results['pipeline_status'] = 'success'
        return results

    except Exception as e:
        print(f"\n✗ Pipeline execution failed: {str(e)}")
        results['pipeline_status'] = 'failed'
        results['error'] = str(e)
        return results


if __name__ == "__main__":
    # Run from AetherFit root directory
    project_root = str(Path(__file__).parent.parent)
    results = run_training_pipeline(project_root)
    sys.exit(0 if results['pipeline_status'] == 'success' else 1)
