"""Data cleaning for injury risk training dataset."""

import pandas as pd
from pathlib import Path


def clean_injury_data(input_path: str, output_path: str = None) -> pd.DataFrame:
    """
    Clean injury risk training dataset.

    Args:
        input_path: Path to raw CSV file
        output_path: Path to save cleaned CSV (optional)

    Returns:
        Cleaned DataFrame
    """
    # Read raw data
    df = pd.read_csv(input_path)

    # Remove duplicates based on User_ID
    df = df.drop_duplicates(subset=['User_ID'], keep='first')

    # Handle missing values
    numeric_cols = [
        'Age', 'BMI', 'Flexibility_Score', 'Strength_Imbalance_Score',
        'Training_Frequency_Hours', 'Overtraining_Risk_Score', 'Has_Health_Conditions',
        'Previous_Injury'
    ]
    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')
            df[col].fillna(df[col].median(), inplace=True)

    # Remove outliers for numeric columns (using IQR method)
    for col in numeric_cols:
        if col in df.columns and col not in ['Has_Health_Conditions', 'Previous_Injury']:
            Q1 = df[col].quantile(0.25)
            Q3 = df[col].quantile(0.75)
            IQR = Q3 - Q1
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR
            df = df[(df[col] >= lower_bound) & (df[col] <= upper_bound)]

    # Validate categorical columns
    valid_genders = ['Male', 'Female', 'Other']
    df = df[df['Gender'].isin(valid_genders)]

    valid_fitness_levels = ['Beginner', 'Intermediate', 'Advanced', 'Athlete']
    df = df[df['Fitness_Level'].isin(valid_fitness_levels)]

    valid_fitness_experience = ['Never Exercised', 'Beginner', 'Some Experience', 'Advanced']
    df = df[df['Fitness_Experience'].isin(valid_fitness_experience)]

    valid_injury_risk = ['Low Risk', 'Moderate Risk', 'High Risk', 'Very High Risk']
    df = df[df['Injury_Risk_Class'].isin(valid_injury_risk)]

    # Validate binary columns (Has_Health_Conditions, Previous_Injury)
    for col in ['Has_Health_Conditions', 'Previous_Injury']:
        df[col] = df[col].astype(int)
        df = df[df[col].isin([0, 1])]

    # Reset index
    df = df.reset_index(drop=True)

    # Save cleaned data if output path provided
    if output_path:
        output_file = Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)
        df.to_csv(output_path, index=False)
        print(f"Cleaned injury risk data saved to {output_path}")

    return df
