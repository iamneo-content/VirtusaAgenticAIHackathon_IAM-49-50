"""Data cleaning for fitness level training dataset."""

import pandas as pd
from pathlib import Path


def clean_fitness_data(input_path: str, output_path: str = None) -> pd.DataFrame:
    """
    Clean fitness level training dataset.

    Args:
        input_path: Path to raw CSV file
        output_path: Path to save cleaned CSV (optional)

    Returns:
        Cleaned DataFrame
    """
    # Read raw data
    df = pd.read_csv(input_path)

    # Remove duplicates based on User_ID
    df = df.drop_duplicates(subset=['User_ID'], keep='first')

    # Handle missing values
    numeric_cols = ['Age', 'Height_CM', 'Weight_KG', 'BMI', 'Available_Hours_Per_Week', 'Activity_Score']
    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')
            df[col].fillna(df[col].median(), inplace=True)

    # Remove outliers for numeric columns (using IQR method)
    for col in numeric_cols:
        if col in df.columns:
            Q1 = df[col].quantile(0.25)
            Q3 = df[col].quantile(0.75)
            IQR = Q3 - Q1
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR
            df = df[(df[col] >= lower_bound) & (df[col] <= upper_bound)]

    # Validate categorical columns
    valid_genders = ['Male', 'Female', 'Other']
    df = df[df['Gender'].isin(valid_genders)]

    valid_fitness_levels = ['Beginner', 'Intermediate', 'Advanced', 'Athlete']
    df = df[df['Fitness_Level_Class'].isin(valid_fitness_levels)]

    valid_fitness_experience = ['Never Exercised', 'Beginner', 'Some Experience', 'Advanced']
    df = df[df['Fitness_Experience'].isin(valid_fitness_experience)]

    # Reset index
    df = df.reset_index(drop=True)

    # Save cleaned data if output path provided
    if output_path:
        output_file = Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)
        df.to_csv(output_path, index=False)
        print(f"Cleaned fitness data saved to {output_path}")

    return df
