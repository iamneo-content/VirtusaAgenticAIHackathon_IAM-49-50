"""Machine learning pipeline for fitness assessment system."""

from .train_pipeline import run_training_pipeline

__all__ = [
    "run_training_pipeline",
]
