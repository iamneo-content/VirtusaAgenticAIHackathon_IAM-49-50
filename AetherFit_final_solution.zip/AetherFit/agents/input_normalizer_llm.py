from typing import Dict, Any


class InputNormalizerLLMAgent:
    """Parse natural language inputs using LLM to extract structured information."""

    def __init__(self, client=None):
        """Initialize with LLM client."""
        if client is None:
            raise ValueError("LLM client is required")
        self.client = client

    def normalize_inputs(self, fitness_experience: str, health_conditions: str, available_hours_per_week: str) -> Dict[str, Any]:
        """
        Parse natural language inputs and extract structured information.

        Args:
            fitness_experience: Free text describing fitness background
            health_conditions: Free text describing health conditions/injuries
            available_hours_per_week: Free text describing schedule/availability

        Returns:
            Dictionary with normalized fields
        """
        prompt = f"""Parse the following user inputs and extract structured information. Handle ANY natural language format.

FITNESS EXPERIENCE: "{fitness_experience}"
- Extract: experience level (Never Exercised/Beginner/Intermediate/Advanced)
- Extract: approximate years active (estimate if not explicit, set to 0 if never exercised)
- Extract: any specific activities mentioned

HEALTH CONDITIONS: "{health_conditions}"
- Extract: list of all medical conditions/injuries mentioned
- Assess: severity (None/Mild/Moderate/Severe) based on description
- Identify: any exercise limitations or precautions
- Determine: if user is cleared for exercise

AVAILABILITY: "{available_hours_per_week}"
- Estimate: total hours per week available
- Extract: preferred days (Monday-Sunday, empty if not mentioned)
- Extract: preferred times (Morning/Afternoon/Evening/Night, empty if not mentioned)
- Note: any constraints

Return valid JSON:
{{
    "normalized_fitness_experience": {{
        "experience_level": "Never Exercised|Beginner|Intermediate|Advanced",
        "years_active": integer,
        "activity_description": "string"
    }},
    "normalized_health_conditions": {{
        "conditions": ["list of conditions"],
        "severity_assessment": "None|Mild|Moderate|Severe",
        "exercise_limitations": ["list of limitations"],
        "cleared_for_exercise": boolean
    }},
    "normalized_schedule": {{
        "estimated_hours_per_week": float,
        "preferred_days": ["list of days or empty"],
        "preferred_times": ["list of times or empty"],
        "schedule_constraints": "string or empty"
    }}
}}"""

        response = self.client.generate_structured_json(
            prompt,
            required_fields=[
                "normalized_fitness_experience",
                "normalized_health_conditions",
                "normalized_schedule"
            ]
        )

        return {
            "normalized_fitness_experience": response.get("normalized_fitness_experience"),
            "normalized_health_conditions": response.get("normalized_health_conditions"),
            "normalized_schedule": response.get("normalized_schedule"),
        }
