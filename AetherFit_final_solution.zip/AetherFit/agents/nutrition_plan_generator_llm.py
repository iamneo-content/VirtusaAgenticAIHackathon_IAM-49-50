from typing import Dict, Any


class NutritionPlanGeneratorLLMAgent:
    """Generate personalized nutrition plans using LLM."""

    def __init__(self, client):
        if client is None:
            raise ValueError("LLM client is required")
        self.client = client

    def generate_nutrition_plan(self, profile: Dict[str, Any]) -> Dict[str, Any]:
        """Generate customized nutrition plan."""
        age = profile.get("age", 30)
        weight_kg = profile.get("weight_kg", 70)
        height_cm = profile.get("height_cm", 170)
        gender = profile.get("gender", "Male")
        goal = profile.get("fitness_goal", "General Fitness")
        fitness_level = profile.get("fitness_level_class", "Intermediate")
        bmi = profile.get("bmi", 25)
        workout_frequency = profile.get("workout_frequency_per_week", 4)

        prompt = f"""Generate a personalized nutrition plan with these specifications:

USER PROFILE:
- Age: {age} years
- Gender: {gender}
- Height: {height_cm} cm
- Weight: {weight_kg} kg
- BMI: {bmi}
- Fitness Level: {fitness_level}
- Primary Goal: {goal}
- Workout Frequency: {workout_frequency} sessions/week

REQUIREMENTS:
1. Calculate daily calorie target using Harris-Benedict equation
2. Apply activity multiplier based on {workout_frequency} workouts per week
3. Provide macronutrient targets (protein, carbs, fat) in grams
4. Suggest 3-5 sample daily meals with Indian food options and macros
5. Include traditional Indian cuisine options (e.g., dal, rice, roti, curries, vegetables)
6. Provide pre- and post-workout nutrition timing
7. Include hydration recommendations
8. Consider {goal} when setting macros
9. Ensure meals are culturally appropriate with Indian food staples

Return valid JSON:
{{
    "daily_calorie_target": integer (kcal),
    "macro_targets": {{
        "protein_g": integer,
        "carbs_g": integer,
        "fat_g": integer
    }},
    "meal_suggestions": [
        {{
            "meal_name": "string",
            "foods": ["list of foods"],
            "protein_g": integer,
            "carbs_g": integer,
            "fat_g": integer,
            "calories": integer
        }}
    ],
    "hydration_recommendation": "string describing daily water intake",
    "nutrition_timing_guidance": "string about pre/post workout nutrition"
}}"""

        return self.client.generate_structured_json(
            prompt,
            required_fields=[
                "daily_calorie_target",
                "macro_targets",
                "meal_suggestions",
                "hydration_recommendation",
                "nutrition_timing_guidance",
            ]
        )
