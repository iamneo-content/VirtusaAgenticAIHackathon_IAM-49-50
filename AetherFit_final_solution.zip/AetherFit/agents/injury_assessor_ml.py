import pickle
import os
from typing import Dict, Any


class InjuryAssessorMLAgent:
    """Predicts injury risk using trained RandomForest model."""

    CLASS_NAMES = ["Low Risk", "Moderate Risk", "High Risk", "Very High Risk"]

    def __init__(self, model_dir: str = "ml/models"):
        """Load trained model and preprocessors from disk."""
        model_path = os.path.join(model_dir, "injury_risk_model.pkl")
        scaler_path = os.path.join(model_dir, "injury_risk_scaler.pkl")
        encoder_path = os.path.join(model_dir, "injury_risk_encoder.pkl")

        with open(model_path, "rb") as f:
            self.model = pickle.load(f)

        with open(scaler_path, "rb") as f:
            self.scaler = pickle.load(f)

        with open(encoder_path, "rb") as f:
            self.label_encoder = pickle.load(f)

    def predict_injury_risk(self, user_profile: Dict[str, Any]) -> Dict[str, Any]:
        """Predict injury risk from user profile."""
        age = float(user_profile.get("age", 30))
        bmi = float(user_profile.get("bmi", 25))
        fitness_level = user_profile.get("fitness_level_class", "Intermediate")
        fitness_level_encoded = {"Beginner": 0, "Intermediate": 1, "Advanced": 2, "Athlete": 3}.get(fitness_level, 1)

        gender = user_profile.get("gender", "Male")
        gender_encoded = {"Female": 0, "Male": 1, "Other": 2}.get(gender, 1)

        fitness_experience = user_profile.get("fitness_experience_level", "Beginner")
        experience_encoded = {"Never Exercised": 0, "Beginner": 1, "Some Experience": 2, "Advanced": 3}.get(fitness_experience, 1)

        age_category = user_profile.get("age_category", "Adult")
        age_cat_encoded = {"Young Adult": 0, "Adult": 1, "Middle Aged": 2, "Senior": 3}.get(age_category, 1)

        bmi_category = user_profile.get("bmi_category", "Normal")
        bmi_cat_encoded = {"Underweight": 0, "Normal": 1, "Overweight": 2, "Obese": 3}.get(bmi_category, 1)

        health_conditions = user_profile.get("health_conditions", "")
        has_health_conditions = 1.0 if health_conditions and health_conditions.lower() != "none" else 0.0
        previous_injury = 1.0 if "injury" in str(health_conditions).lower() else 0.0

        flexibility_score = max(30, 100 - (age * 0.5) - (max(0, bmi - 25) * 2))

        # Handle available_hours which might be a string from user input
        available_hours_raw = user_profile.get("available_hours_per_week", 4)
        if isinstance(available_hours_raw, str):
            try:
                available_hours = float(''.join(filter(lambda x: x.isdigit() or x == '.', available_hours_raw)))
            except (ValueError, IndexError):
                available_hours = 4  # Default if parsing fails
        else:
            available_hours = float(available_hours_raw)
        strength_imbalance = max(20, 70 - (fitness_level_encoded * 10) + (age * 0.3))
        training_frequency = available_hours if fitness_level_encoded > 1 else available_hours * 1.5

        features = [
            float(age),
            float(bmi),
            float(fitness_level_encoded),
            float(gender_encoded),
            float(experience_encoded),
            float(age_cat_encoded),
            float(bmi_cat_encoded),
            float(has_health_conditions),
            float(previous_injury),
            float(flexibility_score),
            float(strength_imbalance),
            float(training_frequency),
        ]

        scaled_features = self.scaler.transform([features])
        prediction = self.model.predict(scaled_features)[0]
        probabilities = self.model.predict_proba(scaled_features)[0]

        class_name = self.CLASS_NAMES[int(prediction)]
        confidence = float(max(probabilities) * 100)

        risk_factors = []
        if age > 50:
            risk_factors.append("Age over 50 - increased injury risk")
        if bmi > 30:
            risk_factors.append("Obesity - joint stress and reduced mobility")
        if health_conditions and health_conditions.lower() != "none":
            risk_factors.append(f"Existing health conditions: {health_conditions}")
        if "injury" in str(health_conditions).lower():
            risk_factors.append("Previous injury history")

        return {
            "injury_risk_score": confidence,
            "injury_risk_class": class_name,
            "injury_confidence": confidence,
            "injury_risk_factors": risk_factors,
        }
