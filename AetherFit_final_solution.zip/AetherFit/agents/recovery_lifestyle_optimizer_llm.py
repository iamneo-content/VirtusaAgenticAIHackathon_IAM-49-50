from typing import Dict, Any


class RecoveryLifestyleOptimizerLLMAgent:
    """Generate recovery and lifestyle integration plans using LLM."""

    def __init__(self, client):
        if client is None:
            raise ValueError("LLM client is required")
        self.client = client

    def generate_recovery_lifestyle_plan(self, profile: Dict[str, Any]) -> Dict[str, Any]:
        """Generate recovery and lifestyle integration plan."""
        age = profile.get("age", 30)
        fitness_level = profile.get("fitness_level_class", "Intermediate")
        injury_risk = profile.get("injury_risk_class", "Moderate Risk")
        health_conditions = profile.get("health_conditions", "None")
        goal = profile.get("fitness_goal", "General Fitness")
        workout_frequency = profile.get("workout_frequency_per_week", 4)
        available_hours = profile.get("available_hours_per_week", 4)
        preferred_days = profile.get("preferred_days", [])
        preferred_times = profile.get("preferred_times", [])

        prompt = f"""Generate a comprehensive recovery and lifestyle integration plan:

USER PROFILE:
- Age: {age}
- Fitness Level: {fitness_level}
- Injury Risk: {injury_risk}
- Health Conditions: {health_conditions}
- Primary Goal: {goal}
- Workout Frequency: {workout_frequency} sessions/week
- Available Time: {available_hours} hours/week
- Preferred Days: {preferred_days if preferred_days else "flexible"}
- Preferred Times: {preferred_times if preferred_times else "flexible"}

RECOVERY PROTOCOL:
1. Sleep recommendations (hours, quality tips)
2. Rest day activities (active recovery options)
3. Mobility work and stretching routines
4. Stress management techniques
5. Recovery techniques (foam rolling, massage, etc.)
6. Deload strategy (when/how to reduce intensity)
7. Injury prevention specific to {injury_risk}

LIFESTYLE INTEGRATION:
1. Schedule integration (best days/times to workout)
2. Time management strategies for {available_hours} hours/week
3. Habit formation techniques (frequency, consistency)
4. Adherence tips (staying motivated)
5. Solutions for obstacles (travel, busy weeks)
6. Minimal equipment alternatives
7. Realistic expectations for {goal}

Return valid JSON:
{{
    "sleep_recommendations": {{
        "hours_per_night": integer,
        "sleep_quality_tips": ["list of tips"]
    }},
    "rest_day_activities": ["list of active recovery options"],
    "mobility_work": ["list of stretching/mobility routines"],
    "stress_management_techniques": ["list of techniques"],
    "recovery_techniques": ["foam rolling", "massage", etc.],
    "deload_strategy": "string describing when/how to deload",
    "schedule_integration": {{
        "best_days": ["list of optimal days"],
        "best_times": ["list of optimal times"],
        "weekly_schedule_tips": "string"
    }},
    "time_management_tips": ["list of time management strategies"],
    "habit_formation_strategies": ["list of habit formation techniques"],
    "adherence_tips": ["list of adherence/motivation tips"]
}}"""

        return self.client.generate_structured_json(
            prompt,
            required_fields=[
                "sleep_recommendations",
                "rest_day_activities",
                "mobility_work",
                "stress_management_techniques",
                "recovery_techniques",
                "deload_strategy",
                "schedule_integration",
                "time_management_tips",
                "habit_formation_strategies",
                "adherence_tips",
            ]
        )
