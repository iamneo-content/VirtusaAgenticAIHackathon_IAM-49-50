from typing import Dict, Any


class WorkoutPlanGeneratorLLMAgent:
    """Generate personalized workout plans using LLM."""

    def __init__(self, client):
        if client is None:
            raise ValueError("LLM client is required")
        self.client = client

    def generate_workout_plan(self, profile: Dict[str, Any]) -> Dict[str, Any]:
        """Generate customized workout plan."""
        fitness_level = profile.get("fitness_level_class", "Intermediate")
        injury_risk = profile.get("injury_risk_class", "Moderate Risk")
        goal = profile.get("fitness_goal", "General Fitness")
        hours = profile.get("available_hours_per_week", 4)
        health_conditions = profile.get("health_conditions", "None")

        # Get schedule preferences from normalized schedule
        preferred_days = profile.get("preferred_days", [])
        preferred_times = profile.get("preferred_times", [])

        # Format schedule preferences for prompt
        days_text = ", ".join(preferred_days) if preferred_days else "flexible"
        times_text = ", ".join(preferred_times) if preferred_times else "flexible"

        prompt = f"""Generate a personalized workout plan with these specifications:

USER PROFILE:
- Fitness Level: {fitness_level}
- Injury Risk Level: {injury_risk}
- Primary Goal: {goal}
- Available Time: {hours} hours per week
- Preferred Days: {days_text}
- Preferred Times: {times_text}
- Health Conditions: {health_conditions}

REQUIREMENTS:
1. Design a weekly workout schedule appropriate for {fitness_level} fitness level
2. Account for {injury_risk} injury risk in exercise selection
3. Fit workouts into {hours} hours per week
4. Schedule workouts on preferred days ({days_text}) and times ({times_text})
5. Provide specific exercises with sets/reps/rest periods (e.g., "30-60 seconds" for rest)
6. Include warmup and cooldown routines
7. Provide safety modifications for {health_conditions}
8. Include 4-8 week progression strategy

Return valid JSON:
{{
    "weekly_schedule": {{
        "Monday": [{{"name": "...", "sets": int, "reps": "...", "rest": "30-60 seconds"}}],
        ...
    }},
    "workout_intensity_level": "Light|Moderate|Vigorous",
    "workout_duration_per_session": integer (minutes),
    "workout_frequency_per_week": integer,
    "workout_progression_timeline": "4-6 weeks|8-12 weeks",
    "workout_safety_notes": ["list of safety considerations"],
    "workout_equipment_needed": ["list of equipment or empty if bodyweight only"]
}}"""

        return self.client.generate_structured_json(
            prompt,
            required_fields=[
                "weekly_schedule",
                "workout_intensity_level",
                "workout_duration_per_session",
                "workout_frequency_per_week",
                "workout_progression_timeline",
                "workout_safety_notes",
                "workout_equipment_needed",
            ]
        )
