import pickle
import os
from typing import Dict, Any


class FitnessScorerMLAgent:
    """Classifies fitness level using trained RandomForest model."""

    CLASS_NAMES = ["Beginner", "Intermediate", "Advanced", "Athlete"]

    def __init__(self, model_dir: str = "ml/models"):
        """Load trained model and preprocessors from disk."""
        model_path = os.path.join(model_dir, "fitness_level_model.pkl")
        scaler_path = os.path.join(model_dir, "fitness_level_scaler.pkl")
        encoder_path = os.path.join(model_dir, "fitness_level_encoder.pkl")

        with open(model_path, "rb") as f:
            self.model = pickle.load(f)

        with open(scaler_path, "rb") as f:
            self.scaler = pickle.load(f)

        with open(encoder_path, "rb") as f:
            self.label_encoder = pickle.load(f)

    def predict_fitness_level(self, user_profile: Dict[str, Any]) -> Dict[str, Any]:
        """Predict fitness level from user profile."""
        age = float(user_profile.get("age", 30))
        bmi = float(user_profile.get("bmi", 25))
        weight_kg = float(user_profile.get("weight_kg", 70))

        # Handle available_hours which might be a string from user input
        available_hours_raw = user_profile.get("available_hours_per_week", 4)
        if isinstance(available_hours_raw, str):
            try:
                available_hours = float(''.join(filter(lambda x: x.isdigit() or x == '.', available_hours_raw)))
            except (ValueError, IndexError):
                available_hours = 4  # Default if parsing fails
        else:
            available_hours = float(available_hours_raw)

        gender = user_profile.get("gender", "Male")
        gender_encoded = {"Female": 0, "Male": 1, "Other": 2}.get(gender, 1)

        fitness_experience = user_profile.get("fitness_experience_level", "Beginner")
        experience_encoded = {"Never Exercised": 0, "Beginner": 1, "Some Experience": 2, "Advanced": 3}.get(fitness_experience, 1)

        age_category = user_profile.get("age_category", "Adult")
        age_cat_encoded = {"Young Adult": 0, "Adult": 1, "Middle Aged": 2, "Senior": 3}.get(age_category, 1)

        fitness_goal = user_profile.get("fitness_goal", "General Fitness")
        goal_encoded = {"Weight Loss": 0, "Muscle Building": 1, "Endurance/Cardio": 2, "General Fitness": 3}.get(fitness_goal, 3)

        bmi_category = user_profile.get("bmi_category", "Normal")
        bmi_cat_encoded = {"Underweight": 0, "Normal": 1, "Overweight": 2, "Obese": 3}.get(bmi_category, 1)

        hours_category = user_profile.get("hours_category", "Moderate")
        hours_cat_encoded = {"Minimal": 0, "Moderate": 1, "High": 2}.get(hours_category, 1)

        base_score = available_hours * 10
        age_factor = max(0, (50 - abs(age - 40)) / 50) * 20
        bmi_factor = max(0, (25 - abs(bmi - 25)) / 25) * 15
        experience_factor = experience_encoded * 10
        activity_score = min(100, max(0, base_score + age_factor + bmi_factor + experience_factor))

        features = [
            float(age),
            float(bmi),
            float(weight_kg),
            float(available_hours),
            float(gender_encoded),
            float(experience_encoded),
            float(age_cat_encoded),
            float(goal_encoded),
            float(bmi_cat_encoded),
            float(hours_cat_encoded),
            float(activity_score),
        ]

        scaled_features = self.scaler.transform([features])
        prediction = self.model.predict(scaled_features)[0]
        probabilities = self.model.predict_proba(scaled_features)[0]

        class_name = self.CLASS_NAMES[int(prediction)]
        confidence = float(max(probabilities) * 100)

        return {
            "fitness_level_score": confidence,
            "fitness_level_class": class_name,
            "fitness_confidence": confidence,
        }
