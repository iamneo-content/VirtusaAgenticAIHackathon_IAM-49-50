from typing import Dict, List, Any


class FormParserAgent:
    """Validates user form inputs and calculates derived metrics."""

    VALID_GENDERS = ["Male", "Female", "Other"]
    VALID_FITNESS_GOALS = ["Weight Loss", "Muscle Building", "Endurance/Cardio", "General Fitness"]

    def __init__(self):
        pass

    def validate_and_parse(self, form_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Validate form inputs and calculate derived fields.

        Args:
            form_data: Dictionary containing user form inputs

        Returns:
            Dictionary with validation results and parsed data
        """
        errors: List[str] = []

        age = form_data.get("age")
        if age is None or not isinstance(age, (int, float)) or age < 18 or age > 100:
            errors.append("Age must be between 18 and 100")

        height_cm = form_data.get("height_cm")
        if height_cm is None or not isinstance(height_cm, (int, float)) or height_cm < 100 or height_cm > 250:
            errors.append("Height must be between 100-250 cm")

        weight_kg = form_data.get("weight_kg")
        if weight_kg is None or not isinstance(weight_kg, (int, float)) or weight_kg < 30 or weight_kg > 300:
            errors.append("Weight must be between 30-300 kg")

        gender = form_data.get("gender")
        if gender not in self.VALID_GENDERS:
            errors.append(f"Gender must be one of: {', '.join(self.VALID_GENDERS)}")

        fitness_goal = form_data.get("fitness_goal")
        if fitness_goal not in self.VALID_FITNESS_GOALS:
            errors.append(f"Goal must be one of: {', '.join(self.VALID_FITNESS_GOALS)}")

        fitness_experience = form_data.get("fitness_experience")
        if not fitness_experience or not isinstance(fitness_experience, str):
            errors.append("Fitness experience description is required")

        health_conditions = form_data.get("health_conditions")
        if health_conditions is None or not isinstance(health_conditions, str):
            errors.append("Health conditions field is required")

        available_hours = form_data.get("available_hours_per_week")
        if not available_hours or not isinstance(available_hours, str):
            errors.append("Schedule/availability description is required")

        parsed_profile = {
            "age": age,
            "height_cm": height_cm,
            "weight_kg": weight_kg,
            "gender": gender,
            "fitness_goal": fitness_goal,
            "fitness_experience": fitness_experience,
            "health_conditions": health_conditions,
            "available_hours_per_week": available_hours,
        }

        bmi = None
        age_category = None
        bmi_category = None

        if age is not None and height_cm is not None and weight_kg is not None:
            height_m = height_cm / 100
            bmi = round(weight_kg / (height_m ** 2), 1)

            if age < 30:
                age_category = "Young Adult"
            elif age < 45:
                age_category = "Adult"
            elif age < 60:
                age_category = "Middle Aged"
            else:
                age_category = "Senior"

            if bmi < 18.5:
                bmi_category = "Underweight"
            elif bmi < 25:
                bmi_category = "Normal"
            elif bmi < 30:
                bmi_category = "Overweight"
            else:
                bmi_category = "Obese"

            parsed_profile["bmi"] = bmi
            parsed_profile["age_category"] = age_category
            parsed_profile["bmi_category"] = bmi_category

        return {
            "parsed_profile": parsed_profile if not errors else None,
            "validation_errors": errors,
            "bmi": bmi,
            "age_category": age_category,
            "bmi_category": bmi_category,
            "parsing_complete": len(errors) == 0,
            "error_occurred": len(errors) > 0,
        }
