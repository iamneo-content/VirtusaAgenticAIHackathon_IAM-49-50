"""LangGraph workflow orchestration for fitness assessment."""

from langgraph.graph import StateGraph, END
from state import FitnessAssessmentState, get_initial_state
from nodes.form_parser_node import form_parser_node
from nodes.input_normalizer_node import input_normalizer_node
from nodes.fitness_scorer_node import fitness_scorer_node
from nodes.injury_assessor_node import injury_assessor_node
from nodes.workout_planner_node import workout_planner_node
from nodes.nutrition_advisor_node import nutrition_advisor_node
from nodes.recovery_lifestyle_optimizer_node import recovery_lifestyle_optimizer_node


def build_fitness_assessment_graph(client=None):
    """
    Build the fitness assessment workflow graph.

    7-node workflow:
    1. form_parser: Validate form inputs and calculate BMI
    2. input_normalizer: Parse natural language inputs (LLM)
    3. [fitness_scorer || injury_assessor]: ML models run in parallel
    4. workout_planner: Generate workout plan (LLM)
    5. nutrition_advisor: Generate nutrition plan (LLM)
    6. recovery_lifestyle_optimizer: Generate recovery & lifestyle plan (LLM)

    Args:
        client: Gemini API client for LLM operations

    Returns:
        Compiled StateGraph
    """
    # Create state graph
    graph = StateGraph(FitnessAssessmentState)

    # Add nodes
    graph.add_node("form_parser", lambda state: form_parser_node(state, client))
    graph.add_node("input_normalizer", lambda state: input_normalizer_node(state, client))
    graph.add_node("fitness_scorer", lambda state: fitness_scorer_node(state, client))
    graph.add_node("injury_assessor", lambda state: injury_assessor_node(state, client))
    graph.add_node("workout_planner", lambda state: workout_planner_node(state, client))
    graph.add_node("nutrition_advisor", lambda state: nutrition_advisor_node(state, client))
    graph.add_node("recovery_lifestyle_optimizer", lambda state: recovery_lifestyle_optimizer_node(state, client))

    # Set entry point
    graph.set_entry_point("form_parser")

    # Add edges
    # form_parser -> input_normalizer
    graph.add_edge("form_parser", "input_normalizer")

    # input_normalizer -> parallel: fitness_scorer and injury_assessor
    graph.add_edge("input_normalizer", "fitness_scorer")
    graph.add_edge("input_normalizer", "injury_assessor")

    # Both ML nodes merge before LLM nodes
    graph.add_edge("fitness_scorer", "workout_planner")
    graph.add_edge("injury_assessor", "workout_planner")

    # Sequential LLM processing
    graph.add_edge("workout_planner", "nutrition_advisor")
    graph.add_edge("nutrition_advisor", "recovery_lifestyle_optimizer")

    # End node
    graph.add_edge("recovery_lifestyle_optimizer", END)

    # Compile graph
    return graph.compile()


def get_workflow_structure():
    """
    Get workflow structure information.

    Returns:
        Dictionary describing the workflow
    """
    return {
        'name': 'Fitness Assessment Workflow',
        'description': '7-node LangGraph-based fitness assessment system',
        'nodes': [
            {
                'name': 'form_parser',
                'type': 'validation',
                'description': 'Validate form inputs and calculate BMI'
            },
            {
                'name': 'input_normalizer',
                'type': 'llm',
                'description': 'Parse natural language inputs using LLM'
            },
            {
                'name': 'fitness_scorer',
                'type': 'ml',
                'description': 'Classify fitness level using RandomForest'
            },
            {
                'name': 'injury_assessor',
                'type': 'ml',
                'description': 'Assess injury risk using RandomForest (parallel with fitness_scorer)'
            },
            {
                'name': 'workout_planner',
                'type': 'llm',
                'description': 'Generate personalized workout plan using LLM'
            },
            {
                'name': 'nutrition_advisor',
                'type': 'llm',
                'description': 'Generate nutrition plan using LLM'
            },
            {
                'name': 'recovery_lifestyle_optimizer',
                'type': 'llm',
                'description': 'Generate recovery and lifestyle optimization plan using LLM'
            }
        ],
        'edges': [
            ('form_parser', 'input_normalizer'),
            ('input_normalizer', 'fitness_scorer'),
            ('input_normalizer', 'injury_assessor'),
            ('fitness_scorer', 'workout_planner'),
            ('injury_assessor', 'workout_planner'),
            ('workout_planner', 'nutrition_advisor'),
            ('nutrition_advisor', 'recovery_lifestyle_optimizer')
        ],
        'entry_point': 'form_parser',
        'exit_point': 'recovery_lifestyle_optimizer'
    }
