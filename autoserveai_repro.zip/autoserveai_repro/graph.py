"""LangGraph StateGraph definitions for AutoServeAI workflows."""

from langgraph.graph import StateGraph, END

from nodes.load_clean_node import load_clean_node
from nodes.sentiment_prediction_node import sentiment_node
from nodes.intent_prediction_node import intent_node
from nodes.routing_node import routing_node
from nodes.reclass_node import reclass_node
from nodes.clustering_node import clustering_node
from nodes.draft_fast_node import draft_fast_node
from nodes.draft_deep_node import draft_deep_node
from nodes.judge_node import judge_node
from nodes.summary_node import clustering_summary_node
from nodes.safety_node import safety_guard_node
from state import WorkflowState


def route_to_reclassify(state: WorkflowState):
    """Route to reclassify node if low-confidence tickets exist, else to cluster."""
    low_conf_ids = state.get("routing_decision", {}).get("all_low_conf_ids", [])
    if low_conf_ids:
        return "reclassify"
    else:
        return "cluster"


def get_batch_workflow_graph():
    """Build and return compiled batch workflow graph."""
    graph = StateGraph(WorkflowState)
    graph.add_node("load_clean", load_clean_node)
    graph.add_node("sentiment", sentiment_node)
    graph.add_node("intent", intent_node)
    graph.add_node("routing", routing_node)
    graph.add_node("reclassify", reclass_node)
    graph.add_node("cluster", clustering_node)

    graph.add_edge("load_clean", "sentiment")
    graph.add_edge("sentiment", "intent")
    graph.add_edge("intent", "routing")
    graph.add_conditional_edges(
        "routing",
        route_to_reclassify,
        {"reclassify": "reclassify", "cluster": "cluster"}
    )
    graph.add_edge("reclassify", "cluster")
    graph.add_edge("cluster", END)
    graph.set_entry_point("load_clean")

    return graph.compile()


def get_single_ticket_workflow_graph():
    """Build and return compiled single-ticket workflow graph."""
    graph = StateGraph(WorkflowState)
    graph.add_node("load_clean", load_clean_node)
    graph.add_node("sentiment", sentiment_node)
    graph.add_node("intent", intent_node)
    graph.add_node("routing", routing_node)
    graph.add_node("reclassify", reclass_node)
    graph.add_node("cluster", clustering_node)
    graph.add_node("draft_fast", draft_fast_node)
    graph.add_node("draft_deep", draft_deep_node)
    graph.add_node("judge", judge_node)
    graph.add_node("summary", clustering_summary_node)
    graph.add_node("safety", safety_guard_node)

    graph.add_edge("load_clean", "sentiment")
    graph.add_edge("sentiment", "intent")
    graph.add_edge("intent", "routing")
    graph.add_conditional_edges(
        "routing",
        route_to_reclassify,
        {"reclassify": "reclassify", "cluster": "cluster"}
    )
    graph.add_edge("reclassify", "cluster")
    graph.add_edge("cluster", "draft_fast")
    graph.add_edge("draft_fast", "draft_deep")
    graph.add_edge("draft_deep", "judge")
    graph.add_edge("judge", "summary")
    graph.add_edge("summary", "safety")
    graph.add_edge("safety", END)
    graph.set_entry_point("load_clean")

    return graph.compile()
