"""AutoServeAI - Agentic Customer Service Analyzer.

Streamlit UI with batch evaluation and single-ticket drafting workflows.
"""

import datetime
import os
from typing import Optional

import pandas as pd
import streamlit as st
from dotenv import load_dotenv

from workflow.workflow import run_batch_workflow, run_single_ticket_workflow
from nodes.load_clean_node import load_rows

# Load environment
load_dotenv()

st.set_page_config(page_title="AutoServeAI", layout="wide")

# Custom CSS
st.markdown(
    """
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&display=swap');
        html, body, [class*="css"] {
            font-family: 'Space Grotesk', sans-serif;
        }
        .gradient-banner {
            background: linear-gradient(135deg, #0f172a, #1e293b 60%, #0ea5e9);
            color: #f8fafc;
            padding: 28px;
            border-radius: 18px;
            margin-bottom: 24px;
            box-shadow: 0 18px 38px rgba(0,0,0,0.18);
        }
        .metric-card {
            padding: 16px;
            border-radius: 16px;
            border: 1px solid #e2e8f0;
            background: #ffffff;
            box-shadow: 0 12px 24px rgba(15,23,42,0.06);
        }
    </style>
    """,
    unsafe_allow_html=True,
)


def render_header():
    """Render header."""
    st.markdown(
        """
        <div class="gradient-banner">
            <h1 style="margin: 0;">AutoServeAI - Agentic Customer Service Analyzer</h1>
            <p style="margin: 8px 0 0 0; opacity: 0.9;">Batch + Single-ticket workflows</p>
        </div>
        """,
        unsafe_allow_html=True,
    )


def main():
    """Main entry point."""
    render_header()

    if "batch_result" not in st.session_state:
        st.session_state.batch_result = None
    if "batch_run_id" not in st.session_state:
        st.session_state.batch_run_id = None
    if "single_result" not in st.session_state:
        st.session_state.single_result = None
    if "eval_result" not in st.session_state:
        st.session_state.eval_result = None

    batch_tab, single_tab, eval_tab = st.tabs(["Batch Evaluation", "Single-Ticket Drafting", "Model Evaluation"])

    # BATCH TAB
    with batch_tab:
        st.subheader("Batch Evaluation")
        col_left, col_right = st.columns([1, 2])

        with col_left:
            input_path = st.text_input(
                "Input CSV",
                value=os.getenv("INPUT_CSV", "data/input/tickets.csv"),
                key="batch_input",
            )
            cluster_k = st.number_input(
                "Cluster K",
                min_value=2,
                max_value=50,
                value=int(os.getenv("CLUSTER_K", "12")),
                step=1,
                key="batch_cluster_k",
            )

            threshold = st.slider(
                "Confidence Threshold",
                min_value=0.0,
                max_value=1.0,
                value=float(os.getenv("CONFIDENCE_THRESHOLD", "0.65")),
                step=0.05,
                key="batch_threshold",
            )

            run_batch = st.button("Run Batch Evaluation", type="primary", width="stretch")

        with col_right:
            if run_batch:
                with st.spinner("Running batch workflow..."):
                    st.session_state.batch_run_id = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                    result = run_batch_workflow(input_path, st.session_state.batch_run_id, confidence_threshold=threshold, cluster_k=cluster_k)
                    st.session_state.batch_result = result

            if st.session_state.batch_result:
                result = st.session_state.batch_result
                if result.get("error"):
                    st.error(f"Error: {result.get('messages')}")
                else:
                    st.success(f"Batch complete! Processed {result.get('total_tickets', 0)} tickets")

                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric("Total Tickets", result.get("total_tickets", 0))
                    with col2:
                        st.metric("Sentiment Predictions", len(result.get("sentiment_predictions", [])))
                    with col3:
                        st.metric("Intent Predictions", len(result.get("intent_predictions", [])))

                    if result.get("reclass_predictions"):
                        st.metric("Reclassified (LLM)", len(result.get("reclass_predictions", [])))

                    # Display detailed results
                    st.markdown("---")
                    st.subheader("Detailed Results")

                    # Build results dataframe
                    results_data = []
                    sentiment_map = {p["ticket_id"]: p for p in result.get("sentiment_predictions", [])}
                    intent_map = {p["ticket_id"]: p for p in result.get("intent_predictions", [])}
                    reclass_map = {p["ticket_id"]: p for p in result.get("reclass_predictions", [])}
                    all_low_conf_ids = result.get("routing_decision", {}).get("all_low_conf_ids", [])
                    clusters_map = result.get("clusters", {})

                    for ticket_id in sorted(sentiment_map.keys()):
                        sentiment = sentiment_map.get(ticket_id, {})
                        intent = intent_map.get(ticket_id, {})
                        reclass = reclass_map.get(ticket_id, {})
                        status = "Reclassified" if ticket_id in reclass_map else ("Low Conf" if ticket_id in all_low_conf_ids else "OK")
                        cluster = clusters_map.get(ticket_id, "N/A")

                        results_data.append({
                            "Ticket ID": ticket_id,
                            "Sentiment": sentiment.get("label", "?"),
                            "Sentiment Conf": f"{sentiment.get('confidence', 0):.2f}",
                            "Intent": reclass.get("label") or intent.get("label", "?"),
                            "Intent Conf": f"{(reclass.get('confidence') or intent.get('confidence', 0)):.2f}",
                            "Status": status,
                            "Cluster": cluster,
                        })

                    if results_data:
                        df_results = pd.DataFrame(results_data)
                        st.dataframe(df_results, width="stretch", hide_index=True)

                        # Download option
                        csv = df_results.to_csv(index=False)
                        st.download_button(
                            label="Download Results CSV",
                            data=csv,
                            file_name=f"batch_results_{st.session_state.batch_run_id}.csv",
                            mime="text/csv",
                        )

    # SINGLE-TICKET TAB
    with single_tab:
        st.subheader("Single-Ticket Drafting")
        col_left, col_right = st.columns([1, 2])

        with col_left:
            input_path = st.text_input(
                "Input CSV",
                value=os.getenv("INPUT_CSV", "data/input/tickets.csv"),
                key="single_input",
            )

            try:
                tickets = load_rows(input_path)
                ticket_ids = [t.get("ticket_id", "") for t in tickets]
                selected_ticket = st.selectbox("Select Ticket", options=ticket_ids, key="single_ticket_select")
            except Exception as e:
                st.error(f"Failed to load CSV: {e}")
                selected_ticket = None

            threshold = st.slider(
                "Confidence Threshold",
                min_value=0.0,
                max_value=1.0,
                value=float(os.getenv("CONFIDENCE_THRESHOLD", "0.65")),
                step=0.05,
                key="single_threshold",
            )

            if selected_ticket and st.button("Analyze & Draft", type="primary", width="stretch"):
                with st.spinner("Analyzing ticket and generating drafts..."):
                    result = run_single_ticket_workflow(input_path, selected_ticket, confidence_threshold=threshold)
                    st.session_state.single_result = result

        with col_right:
            if st.session_state.single_result:
                result = st.session_state.single_result

                if result is None:
                    st.error("Error processing ticket")
                else:
                    # Drafts
                    draft_col1, draft_col2 = st.columns(2)
                    with draft_col1:
                        st.write("**Fast Draft** (60 words)")
                        st.info(result["fast_draft"])
                    with draft_col2:
                        st.write("**Deep Draft** (70-120 words)")
                        st.info(result["deep_draft"])

                    st.markdown("---")
                    st.write("**Return Final Response:**")
                    st.success(result["safe_draft"])

                    st.markdown("---")
                    st.subheader("Cluster Context - Similar Tickets")
                    st.write("Find similar tickets in the same cluster for insights:")

                    cluster_context = result.get("cluster_context", [])
                    if cluster_context:
                        for idx, ticket in enumerate(cluster_context, 1):
                            with st.expander(f"Similar Ticket {idx}: {ticket.get('ticket_id', 'N/A')}"):
                                st.write(ticket.get("customer_text", "No text available"))
                    else:
                        st.info("No similar tickets found in this cluster")

    # MODEL EVALUATION TAB
    with eval_tab:
        st.subheader("Model Evaluation")
        st.write("Evaluate trained models on test datasets")

        col_left, col_right = st.columns([1, 2])

        with col_left:
            if st.button("Run Model Evaluation", type="primary", width="stretch"):
                with st.spinner("Evaluating models..."):
                    from ml.evaluation.evaluate_models import evaluate_all_models
                    eval_dir = os.path.join(os.path.dirname(__file__), "data", "evaluation_dataset")
                    model_dir = os.path.join(os.path.dirname(__file__), "ml", "models")
                    results = evaluate_all_models(eval_dir, model_dir)
                    st.session_state.eval_result = results

        with col_right:
            if st.session_state.eval_result:
                results = st.session_state.eval_result

                if results.get("status") == "success":
                    models = results.get("models", {})

                    # Sentiment Model Evaluation
                    if "sentiment" in models:
                        sentiment = models["sentiment"]
                        if sentiment.get("status") == "success":
                            st.markdown("### Sentiment Model")
                            s_col1, s_col2, s_col3, s_col4 = st.columns(4)
                            with s_col1:
                                st.metric("Accuracy", f"{sentiment.get('accuracy', 0):.4f}")
                            with s_col2:
                                st.metric("F1-Score", f"{sentiment.get('f1_score', 0):.4f}")
                            with s_col3:
                                st.metric("Precision", f"{sentiment.get('precision', 0):.4f}")
                            with s_col4:
                                st.metric("Recall", f"{sentiment.get('recall', 0):.4f}")
                            st.caption(f"Evaluated on {sentiment.get('samples', 0)} samples")

                    # Intent Model Evaluation
                    if "intent" in models:
                        intent = models["intent"]
                        if intent.get("status") == "success":
                            st.markdown("### Intent Model")
                            i_col1, i_col2, i_col3, i_col4 = st.columns(4)
                            with i_col1:
                                st.metric("Accuracy", f"{intent.get('accuracy', 0):.4f}")
                            with i_col2:
                                st.metric("F1-Score", f"{intent.get('f1_score', 0):.4f}")
                            with i_col3:
                                st.metric("Precision", f"{intent.get('precision', 0):.4f}")
                            with i_col4:
                                st.metric("Recall", f"{intent.get('recall', 0):.4f}")
                            st.caption(f"Evaluated on {intent.get('samples', 0)} samples")

                    # Model Comparison
                    st.markdown("---")
                    st.markdown("### Model Comparison")
                    comparison_data = []
                    for model_name, model_results in models.items():
                        if model_results.get("status") == "success":
                            comparison_data.append({
                                "Model": model_name.capitalize(),
                                "Type": model_results.get("model_type", "Unknown"),
                                "Accuracy": f"{model_results.get('accuracy', 0):.4f}",
                                "F1-Score": f"{model_results.get('f1_score', 0):.4f}",
                                "Precision": f"{model_results.get('precision', 0):.4f}",
                                "Recall": f"{model_results.get('recall', 0):.4f}",
                            })
                    if comparison_data:
                        df_comparison = pd.DataFrame(comparison_data)
                        st.dataframe(df_comparison, width="stretch", hide_index=True)
                else:
                    st.error("Evaluation failed")


if __name__ == "__main__":
    main()
