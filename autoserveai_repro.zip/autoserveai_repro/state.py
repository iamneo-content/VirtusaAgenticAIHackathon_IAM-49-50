"""
State management for AutoServeAI workflows.
Defines the complete state structure for batch and single-ticket workflows using TypedDict.
"""

from typing import Any, Dict, List, Optional, TypedDict


class TicketRow(TypedDict, total=False):
    """A single customer service ticket from input CSV."""
    ticket_id: str
    customer_text: str
    sample_id: str  # For identifying duplicates


class SentimentPrediction(TypedDict):
    """Sentiment classification result."""
    ticket_id: str
    label: str  # "positive", "neutral", "negative"
    confidence: float  # 0.0 to 1.0


class IntentPrediction(TypedDict):
    """Intent classification result."""
    ticket_id: str
    label: str  # intent category
    confidence: float  # 0.0 to 1.0


class ReclassPrediction(TypedDict):
    """Reclassification result from LLM (for low-confidence predictions)."""
    ticket_id: str
    label: str
    confidence: float
    original_label: str  # The original low-confidence label
    original_confidence: float


class ClusteringResult(TypedDict):
    """Clustering result with ticket-to-cluster mapping."""
    clusters: Dict[str, int]  # ticket_id -> cluster_id


class RouteDecision(TypedDict):
    """Decision from low-confidence router."""
    low_conf_sentiment_ids: List[str]
    low_conf_intent_ids: List[str]
    all_low_conf_ids: List[str]


class WorkflowState(TypedDict, total=False):
    """
    Complete state for batch and single-ticket workflows.
    Flows through LangGraph nodes, with automatic state management and error handling.
    """
    # Metadata
    request_id: str
    ticket_id: str  # For single-ticket workflows

    # Error tracking
    error_occurred: bool
    error_messages: List[str]

    # Data
    rows: List[TicketRow]
    cleaned_rows: List[TicketRow]
    input_csv: str

    # Predictions (classification)
    sentiment_predictions: List[SentimentPrediction]
    intent_predictions: List[IntentPrediction]
    reclass_predictions: Optional[List[ReclassPrediction]]

    # Routing decision
    routing_decision: RouteDecision

    # Clustering
    clustering_result: ClusteringResult

    # Draft outputs (single-ticket workflow)
    fast_draft: str
    deep_draft: str
    judged_draft: str
    safe_draft: str
    cluster_summary: str

    # Configuration
    confidence_threshold: float
    cluster_k: int


class SingleTicketResult(TypedDict, total=False):
    """
    Result structure for single-ticket workflow.
    Contains all analysis and draft information for one ticket.
    """
    ticket: TicketRow
    cleaned_ticket: TicketRow
    sentiment: SentimentPrediction
    intent: IntentPrediction
    reclass: Optional[ReclassPrediction]
    cluster_id: int
    cluster_context: List[TicketRow]
    fast_draft: str
    deep_draft: str
    judged_draft: str
    safe_draft: str
    summary: str


__all__ = [
    "TicketRow",
    "SentimentPrediction",
    "IntentPrediction",
    "ReclassPrediction",
    "ClusteringResult",
    "RouteDecision",
    "WorkflowState",
    "SingleTicketResult",
]
