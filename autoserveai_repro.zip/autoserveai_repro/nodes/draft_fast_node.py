"""Draft fast node for generating concise customer service responses."""

from agents.draft_fast_llm_agent import DraftFastLLMAgent
from state import WorkflowState


def draft_fast_node(state: WorkflowState) -> WorkflowState:
    """Generate fast draft response (approx 60 words)."""
    try:
        ticket_id = state.get("ticket_id", "")
        if not ticket_id:
            return state

        agent = DraftFastLLMAgent()
        rows = state.get("cleaned_rows", [])
        ticket_rows = [r for r in rows if r.get("ticket_id") == ticket_id]

        if not ticket_rows:
            return state

        intent_map = {}
        for pred in state.get("intent_predictions", []):
            intent_map[pred["ticket_id"]] = pred["label"]
        for pred in state.get("reclass_predictions", []):
            intent_map[pred["ticket_id"]] = pred["label"]

        result = agent.generate_fast_draft(ticket_rows, intent_map)
        draft_text = result.get("result", {}).get(ticket_id, "")

        return {**state, "fast_draft": draft_text}
    except Exception:
        return state
