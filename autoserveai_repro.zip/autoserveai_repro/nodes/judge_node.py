"""Judge node for selecting the best draft response."""

from agents.judge_llm_agent import JudgeLLMAgent
from state import WorkflowState


def judge_node(state: WorkflowState) -> WorkflowState:
    """Judge and select the best draft based on LLM evaluation.

    The judge uses semantic evaluation to determine which draft better addresses
    the customer's issue, considering relevance, completeness, and tone.
    """
    try:
        ticket_id = state.get("ticket_id", "")
        if not ticket_id:
            return state

        cleaned_rows = state.get("cleaned_rows", [])
        ticket_row = next((r for r in cleaned_rows if r.get("ticket_id") == ticket_id), None)
        if not ticket_row:
            return state

        customer_text = ticket_row.get("customer_text", "")
        fast_draft = state.get("fast_draft", "")
        deep_draft = state.get("deep_draft", "")

        agent = JudgeLLMAgent()
        result = agent.evaluate_and_judge_drafts(ticket_id, customer_text, fast_draft, deep_draft)
        judged_draft = result.get("result", {}).get("selected_draft", deep_draft)

        return {**state, "judged_draft": judged_draft}
    except Exception:
        deep_draft = state.get("deep_draft", "")
        return {**state, "judged_draft": deep_draft}
