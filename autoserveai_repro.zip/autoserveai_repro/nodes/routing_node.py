"""Low-confidence routing node."""


from state import WorkflowState


def routing_node(state: WorkflowState) -> WorkflowState:
    """Route low-confidence predictions for reclassification."""
    try:
        threshold = state.get("confidence_threshold", 0.65)
        sentiment_preds = state.get("sentiment_predictions", [])
        intent_preds = state.get("intent_predictions", [])

        low_conf_sentiment = [p["ticket_id"] for p in sentiment_preds if p.get("confidence", 1.0) < threshold]
        low_conf_intent = [p["ticket_id"] for p in intent_preds if p.get("confidence", 1.0) < threshold]
        all_low_conf = list(set(low_conf_sentiment + low_conf_intent))

        state["routing_decision"] = {
            "low_conf_sentiment_ids": low_conf_sentiment,
            "low_conf_intent_ids": low_conf_intent,
            "all_low_conf_ids": all_low_conf,
        }

        return state
    except Exception as e:
        state["error_messages"].append(f"Routing node error: {e}")
        state["error_occurred"] = True
        return state
