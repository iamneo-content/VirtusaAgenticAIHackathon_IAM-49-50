"""Clustering node for semantic ticket grouping."""


from agents.clustering_agent import ClusteringAgent
from state import WorkflowState


def clustering_node(state: WorkflowState) -> WorkflowState:
    """Cluster tickets using semantic embeddings and K-means."""
    try:
        agent = ClusteringAgent(n_clusters=state.get("cluster_k", 12))
        rows = state.get("cleaned_rows", [])
        result = agent.cluster_tickets(rows)
        state["clustering_result"] = result.get("result", {})
        return state
    except Exception as e:
        state["error_messages"].append(f"Clustering node error: {e}")
        state["error_occurred"] = True
        return state
