"""Draft deep node for generating comprehensive customer service responses."""

from agents.draft_deep_llm_agent import DraftDeepLLMAgent
from state import WorkflowState


def draft_deep_node(state: WorkflowState) -> WorkflowState:
    """Generate deep draft response (70-120 words)."""
    try:
        ticket_id = state.get("ticket_id", "")
        if not ticket_id:
            return state

        agent = DraftDeepLLMAgent()
        rows = state.get("cleaned_rows", [])
        ticket_rows = [r for r in rows if r.get("ticket_id") == ticket_id]

        if not ticket_rows:
            return state

        intent_map = {}
        for pred in state.get("intent_predictions", []):
            intent_map[pred["ticket_id"]] = pred["label"]
        for pred in state.get("reclass_predictions", []):
            intent_map[pred["ticket_id"]] = pred["label"]

        result = agent.generate_deep_draft(ticket_rows, intent_map)
        draft_text = result.get("result", {}).get(ticket_id, "")

        return {**state, "deep_draft": draft_text}
    except Exception:
        return state
