"""Summary node for generating cluster insights."""

from agents.summary_llm_agent import SummaryLLMAgent
from state import WorkflowState


def clustering_summary_node(state: WorkflowState) -> WorkflowState:
    """Generate summary of the ticket's cluster.

    Provides context about related tickets in the same cluster,
    useful for understanding patterns and similar issues.
    """
    try:
        ticket_id = state.get("ticket_id", "")
        if not ticket_id:
            return state

        agent = SummaryLLMAgent()
        rows = state.get("cleaned_rows", [])
        clusters = state.get("clustering_result", {}).get("clusters", {})
        cluster_id = clusters.get(ticket_id, -1)

        cluster_tickets = [r for r in rows if clusters.get(r.get("ticket_id"), -1) == cluster_id]

        result = agent.generate_cluster_summary(cluster_tickets)
        summary_text = result.get("result", "")

        return {**state, "cluster_summary": summary_text}
    except Exception:
        return {**state, "cluster_summary": ""}
