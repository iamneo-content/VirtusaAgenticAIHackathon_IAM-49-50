"""Intent prediction node."""


from agents.intent_logreg_agent import IntentLogRegAgent
from state import WorkflowState


def intent_node(state: WorkflowState) -> WorkflowState:
    """Predict intent using LogisticRegression model."""
    try:
        agent = IntentLogRegAgent()
        rows = state.get("cleaned_rows", [])
        result = agent.predict_intent(rows)
        state["intent_predictions"] = result.get("result", [])
        return state
    except Exception as e:
        state["error_messages"].append(f"Intent node error: {e}")
        state["error_occurred"] = True
        return state
