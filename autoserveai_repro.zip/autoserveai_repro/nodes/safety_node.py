"""Safety node for redacting personally identifiable information."""

from agents.safety_guard_agent import SafetyGuardAgent
from state import WorkflowState


def safety_guard_node(state: WorkflowState) -> WorkflowState:
    """Redact personally identifiable information from judged draft.

    Removes patterns like:
    - Email addresses
    - Phone numbers
    - Credit card numbers
    - Social security numbers
    - Other sensitive data
    """
    try:
        judged_draft = state.get("judged_draft", "")
        if not judged_draft:
            return {**state, "safe_draft": judged_draft}

        result = SafetyGuardAgent.redact_pii(judged_draft)
        safe_draft = result.get("result", judged_draft)

        return {**state, "safe_draft": safe_draft}
    except Exception:
        judged_draft = state.get("judged_draft", "")
        return {**state, "safe_draft": judged_draft}
