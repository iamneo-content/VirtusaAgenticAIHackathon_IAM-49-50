"""Sentiment prediction node."""


from agents.sentiment_svm_agent import SentimentSVMAgent
from state import WorkflowState


def sentiment_node(state: WorkflowState) -> WorkflowState:
    """Predict sentiment using SVM model."""
    try:
        agent = SentimentSVMAgent()
        rows = state.get("cleaned_rows", [])
        result = agent.predict_sentiment(rows)
        state["sentiment_predictions"] = result.get("result", [])
        return state
    except Exception as e:
        state["error_messages"].append(f"Sentiment node error: {e}")
        state["error_occurred"] = True
        return state
