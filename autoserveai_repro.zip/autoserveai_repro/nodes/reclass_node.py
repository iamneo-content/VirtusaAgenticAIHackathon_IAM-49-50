"""Reclassification node for low-confidence predictions."""


from agents.reclass_llm_agent import ReclassLLMAgent
from state import WorkflowState


def reclass_node(state: WorkflowState) -> WorkflowState:
    """Reclassify low-confidence predictions using LLM."""
    try:
        low_conf_ids = state.get("routing_decision", {}).get("all_low_conf_ids", [])
        if not low_conf_ids:
            state["reclass_predictions"] = []
            return state

        agent = ReclassLLMAgent()
        rows = state.get("cleaned_rows", [])

        # Build original predictions map
        original_map = {}
        for pred in state.get("intent_predictions", []):
            original_map[pred["ticket_id"]] = pred["label"]

        result = agent.reclassify_predictions(rows, low_conf_ids, original_map)
        state["reclass_predictions"] = result.get("result", [])
        return state
    except Exception as e:
        state["error_messages"].append(f"Reclass node error: {e}")
        state["error_occurred"] = True
        return state
