"""Load and clean node."""

import csv
import re
from typing import Any, Dict, List

from state import TicketRow, WorkflowState


def load_rows(csv_path: str) -> List[TicketRow]:
    """Load tickets from CSV file."""
    rows = []
    try:
        with open(csv_path, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for i, row in enumerate(reader):
                rows.append({
                    "ticket_id": row.get("ticket_id", f"ticket_{i}"),
                    "customer_text": row.get("customer_text", ""),
                    "sample_id": row.get("sample_id", ""),
                })
    except Exception as e:
        pass
    return rows


def clean_text(text: str) -> str:
    """Normalize text."""
    text = text.lower()
    text = re.sub(r"\s+", " ", text)
    text = text.strip()
    return text


def load_clean_node(state: WorkflowState) -> WorkflowState:
    """Load and clean tickets."""
    try:
        csv_path = state.get("input_csv", "data/input/tickets.csv")
        rows = load_rows(csv_path)

        if not rows:
            state["error_messages"].append("No tickets loaded from CSV")
            state["error_occurred"] = True
            return state

        # Clean
        cleaned_rows = []
        for row in rows:
            cleaned_row = dict(row)
            cleaned_row["customer_text"] = clean_text(row.get("customer_text", ""))
            cleaned_rows.append(cleaned_row)

        state["rows"] = rows
        state["cleaned_rows"] = cleaned_rows
        return state
    except Exception as e:
        state["error_messages"].append(f"Load/clean node error: {e}")
        state["error_occurred"] = True
        return state
