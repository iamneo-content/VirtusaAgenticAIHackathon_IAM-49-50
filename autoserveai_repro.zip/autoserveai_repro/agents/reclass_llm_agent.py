"""LLM-based reclassification agent for low-confidence predictions."""

from typing import Any, Dict, List

from agents.base_llm_agent import BaseLLMAgent
from state import ReclassPrediction, TicketRow
from utils.gemini_client import GeminiClient


class ReclassLLMAgent(BaseLLMAgent):
    """Reclassifies low-confidence predictions using LLM."""

    def reclassify_predictions(
        self,
        rows: List[TicketRow],
        low_conf_ticket_ids: List[str],
        original_predictions: Dict[str, str],
    ) -> Dict[str, Any]:
        """
        Reclassify low-confidence tickets using Gemini.

        Args:
            rows: List of TicketRow objects
            low_conf_ticket_ids: IDs of tickets with low confidence
            original_predictions: Dict mapping ticket_id to original label

        Returns:
            {"result": List[ReclassPrediction], "status": "success"}
        """
        if not low_conf_ticket_ids:
            return {"result": [], "status": "success"}

        try:
            predictions = []

            for ticket_id in low_conf_ticket_ids:
                # Find the ticket
                ticket = next((r for r in rows if r.get("ticket_id") == ticket_id), None)
                if not ticket:
                    continue

                customer_text = ticket.get("customer_text", "")
                original_label = original_predictions.get(ticket_id, "unknown")

                prompt = f"""Analyze this customer service ticket and classify its intent category.
Original classification was: {original_label}

Customer message:
{customer_text}

Respond with JSON:
{{
    "label": "intent_category (e.g., billing, account_access, refund, general_support)",
    "confidence": 0.85,
    "reasoning": "brief explanation"
}}

Only valid JSON, no markdown."""

                try:
                    result = self.client.generate_structured_json(
                        prompt,
                        required_fields=["label", "confidence", "reasoning"],
                        temperature=0.2,
                        max_tokens=150,
                    )

                    predictions.append({
                        "ticket_id": ticket_id,
                        "label": result.get("label", original_label),
                        "confidence": float(result.get("confidence", 0.7)),
                        "original_label": original_label,
                        "original_confidence": 0.5,  # Placeholder
                    })
                except Exception as e:
                    predictions.append({
                        "ticket_id": ticket_id,
                        "label": original_label,
                        "confidence": 0.5,
                        "original_label": original_label,
                        "original_confidence": 0.5,
                    })

            return {"result": predictions, "status": "success"}
        except Exception as e:
            return {"result": [], "status": "error", "error": str(e)}
