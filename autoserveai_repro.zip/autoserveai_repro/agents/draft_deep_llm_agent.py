"""Deep draft generation agent using LLM."""

from typing import Any, Dict, List

from agents.base_llm_agent import BaseLLMAgent
from state import TicketRow


class DraftDeepLLMAgent(BaseLLMAgent):
    """Generates comprehensive customer service replies."""

    def generate_deep_draft(
        self,
        rows: List[TicketRow],
        intent_map: Dict[str, str],
    ) -> Dict[str, Any]:
        """
        Generate deep drafts for tickets.

        Args:
            rows: List of TicketRow objects
            intent_map: Dict mapping ticket_id to intent label

        Returns:
            {"result": Dict[str, str], "status": "success"} where result maps ticket_id to draft text
        """
        if not rows:
            return {"result": {}, "status": "success"}

        try:
            drafts = {}

            for row in rows:
                ticket_id = row.get("ticket_id", "")
                customer_text = row.get("customer_text", "")
                intent = intent_map.get(ticket_id, "general_support")

                prompt = f"""Write a supportive, clear customer support reply (70-120 words).
Include: empathy, acknowledgement of the issue, ownership, concrete next steps, and a request for any missing info if needed.

Ticket ID: {ticket_id}
Intent: {intent}
Customer message: {customer_text}

Reply:"""

                try:
                    response = self.client.generate_content(
                        prompt,
                        temperature=0.6,
                        max_tokens=200,
                    )
                    drafts[ticket_id] = response.strip() if response else ""
                except Exception as e:
                    raise

            return {"result": drafts, "status": "success"}
        except Exception as e:
            return {"result": {}, "status": "error", "error": str(e)}
