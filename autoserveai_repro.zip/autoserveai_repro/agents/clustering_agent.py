"""Clustering agent for ticket similarity grouping using TF-IDF."""

import os
import pickle
from typing import Any, Dict, List

from sklearn.cluster import KMeans
from sklearn.feature_extraction.text import TfidfVectorizer

from state import TicketRow


class ClusteringAgent:
    """Clusters similar tickets using K-means on TF-IDF vectors (lightweight alternative to semantic embeddings)."""

    def __init__(self, n_clusters: int = 12):
        """Initialize clustering agent."""
        self.n_clusters = n_clusters
        self.kmeans = None
        self.tfidf = TfidfVectorizer(max_features=500, ngram_range=(1, 2), min_df=1)
        model_dir = os.path.join(os.path.dirname(__file__), "..", "ml", "models")
        model_path = os.path.join(model_dir, "kmeans.pkl")
        if os.path.exists(model_path):
            self.kmeans = pickle.load(open(model_path, "rb"))

    def cluster_tickets(self, rows: List[TicketRow]) -> Dict[str, Any]:
        """
        Cluster tickets using K-means on TF-IDF vectors (no heavy embeddings model).

        Args:
            rows: List of TicketRow objects

        Returns:
            {"result": {"clusters": Dict[str, int]}, "status": "success"}
        """
        if not rows:
            return {"result": {"clusters": {}}, "status": "success"}

        try:
            # Extract text and convert to TF-IDF vectors
            texts = [row.get("customer_text", "") for row in rows]
            tfidf_matrix = self.tfidf.fit_transform(texts)
            tfidf_array = tfidf_matrix.toarray()

            if self.kmeans is None:
                self.kmeans = KMeans(n_clusters=min(self.n_clusters, len(rows)), random_state=42)
                self.kmeans.fit(tfidf_array)

            # Predict clusters
            cluster_labels = self.kmeans.predict(tfidf_array)

            # Map ticket_id to cluster
            clusters = {}
            for i, row in enumerate(rows):
                ticket_id = row.get("ticket_id", f"ticket_{i}")
                clusters[ticket_id] = int(cluster_labels[i])

            return {
                "result": {
                    "clusters": clusters
                },
                "status": "success"
            }
        except Exception as e:
        # Fallback: assign all to same cluster
            clusters = {row.get("ticket_id", f"ticket_{i}"): 0 for i, row in enumerate(rows)}
            return {
                "result": {
                    "clusters": clusters
                },
                "status": "success"
            }
