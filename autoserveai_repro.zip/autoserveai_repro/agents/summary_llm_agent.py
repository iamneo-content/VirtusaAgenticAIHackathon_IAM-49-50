"""Cluster summary generation agent using LLM."""

from typing import Any, Dict, List

from agents.base_llm_agent import BaseLLMAgent
from state import TicketRow


class SummaryLLMAgent(BaseLLMAgent):
    """Generates summaries of similar tickets in a cluster."""

    def generate_cluster_summary(
        self,
        cluster_tickets: List[TicketRow],
    ) -> Dict[str, Any]:
        """
        Generate a cluster-level summary.

        Args:
            cluster_tickets: List of similar tickets in the cluster

        Returns:
            {"result": str, "status": "success"} where result is the summary
        """
        if not cluster_tickets:
            return {"result": "", "status": "success"}

        try:
            # Format ticket summaries
            ticket_summaries = []
            for i, ticket in enumerate(cluster_tickets[:5], 1):  # Limit to 5 tickets
                text = ticket.get("customer_text", "")[:200]  # First 200 chars
                ticket_summaries.append(f"Ticket {i}: {text}...")

            tickets_text = "\n".join(ticket_summaries)

            prompt = f"""Analyze these customer service tickets that are similar to each other.
Provide a 2-3 sentence summary of the common issues and patterns you see.

Tickets:
{tickets_text}

Summary:"""

            response = self.client.generate_content(
                prompt,
                temperature=0.3,
                max_tokens=150,
            )

            return {"result": response.strip() if response else "", "status": "success"}
        except Exception as e:
            return {"result": "", "status": "error", "error": str(e)}
