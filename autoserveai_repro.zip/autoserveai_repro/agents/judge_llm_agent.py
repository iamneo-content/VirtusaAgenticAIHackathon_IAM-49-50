"""LLM-based draft judge agent - evaluates and selects best draft."""

from typing import Any, Dict

from agents.base_llm_agent import BaseLLMAgent


class JudgeLLMAgent(BaseLLMAgent):
    """Uses LLM to evaluate and select the best draft between fast and deep versions."""

    def evaluate_and_judge_drafts(
        self,
        ticket_id: str,
        customer_text: str,
        fast_draft: str,
        deep_draft: str,
    ) -> Dict[str, Any]:
        """
        Evaluate two drafts and select the better one.

        Args:
            ticket_id: ID of the ticket
            customer_text: Original customer message
            fast_draft: Concise draft (~60 words)
            deep_draft: Comprehensive draft (~70-120 words)

        Returns:
            {"result": {"selected_draft": str, "rationale": str}, "status": "success"}
        """
        try:
            prompt = f"""You are evaluating two customer service replies.
Customer message: {customer_text}

Option 1 (Fast/Concise):
{fast_draft}

Option 2 (Deep/Comprehensive):
{deep_draft}

Which reply is better for this customer? Consider: relevance, clarity, empathy, completeness, and customer satisfaction.

Respond with JSON:
{{
    "selected_option": 1 or 2,
    "rationale": "brief explanation of choice"
}}

Only valid JSON, no markdown."""

            result = self.client.generate_structured_json(
                prompt,
                required_fields=["selected_option", "rationale"],
                temperature=0.3,
                max_tokens=150,
            )

            selected = result.get("selected_option", 2)
            selected_draft = deep_draft if selected == 2 else fast_draft
            rationale = result.get("rationale", "")

            return {
                "result": {
                    "selected_draft": selected_draft,
                    "rationale": rationale,
                    "selected_option": selected
                },
                "status": "success"
            }
        except Exception as e:
        # Fallback: prefer deep draft if it's reasonable length
            return {
                "result": {
                    "selected_draft": deep_draft if len(deep_draft) > len(fast_draft) else fast_draft,
                    "rationale": "Fallback selection due to evaluation error",
                    "selected_option": 2 if len(deep_draft) > len(fast_draft) else 1
                },
                "status": "success"
            }
