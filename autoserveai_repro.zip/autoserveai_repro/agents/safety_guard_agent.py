"""Safety guard agent for PII redaction."""

import re
from typing import Any, Dict


class SafetyGuardAgent:
    """Redacts personally identifiable information from text."""

    @staticmethod
    def redact_pii(text: str) -> Dict[str, Any]:
        """
        Redact emails and sensitive numbers from text.

        Args:
            text: Text to sanitize

        Returns:
            {"result": str, "status": "success"}
        """
        try:
            sanitized = text

            # Redact emails
            sanitized = re.sub(
                r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}",
                "[EMAIL]",
                sanitized
            )

            # Redact phone numbers (various formats)
            sanitized = re.sub(r"\b\d{3}[-.]?\d{3}[-.]?\d{4}\b", "[PHONE]", sanitized)

            # Redact 6+ digit sequences (potential sensitive numbers)
            sanitized = re.sub(r"\b\d{6,}\b", "[NUMBER]", sanitized)

            # Redact credit card patterns
            sanitized = re.sub(r"\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b", "[CARD]", sanitized)

            return {"result": sanitized, "status": "success"}
        except Exception as e:
            return {"result": text, "status": "error", "error": str(e)}
