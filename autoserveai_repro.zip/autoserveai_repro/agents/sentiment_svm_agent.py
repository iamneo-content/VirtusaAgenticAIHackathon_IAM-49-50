"""Sentiment classification agent using SVM."""

import os
import pickle
from typing import Any, Dict, List

import numpy as np

from state import TicketRow


class SentimentSVMAgent:
    """Predicts sentiment using pre-trained SVM model."""

    def __init__(self):
        """Load pre-trained SVM model and TF-IDF vectorizer."""
        model_dir = os.path.join(os.path.dirname(__file__), "..", "ml", "models")
        self.model = pickle.load(open(os.path.join(model_dir, "sentiment_svm.pkl"), "rb"))
        self.vectorizer = pickle.load(open(os.path.join(model_dir, "tfidf_sentiment.pkl"), "rb"))

    def predict_sentiment(self, rows: List[TicketRow]) -> Dict[str, Any]:
        """
        Predict sentiment using SVM model.

        Args:
            rows: List of TicketRow objects

        Returns:
            {"result": List[SentimentPrediction], "status": "success"}
        """
        if not rows:
            return {"result": [], "status": "success"}

        predictions = []
        texts = [row.get("customer_text", "") for row in rows]
        vectors = self.vectorizer.transform(texts)
        labels = self.model.predict(vectors)
        probas = self.model.decision_function(vectors)

        for i in range(len(rows)):
            ticket_id = rows[i].get("ticket_id", f"ticket_{i}")
            label = labels[i]
            prob_value = float(probas[i]) if isinstance(probas[i], (int, float, np.number)) else float(probas[i][0])
            confidence = float(1.0 / (1.0 + np.exp(-prob_value)))
            confidence = max(0.0, min(1.0, confidence))

            predictions.append({
                "ticket_id": ticket_id,
                "label": label,
                "confidence": confidence
            })

        return {"result": predictions, "status": "success"}
