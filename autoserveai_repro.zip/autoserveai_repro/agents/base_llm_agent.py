"""
Base class for all LLM-based agents in AutoServeAI.
Provides shared client management and consistent interface.
"""

from typing import Any, Dict, Optional
from utils.gemini_client import GeminiClient


class BaseLLMAgent:
    """
    Base class for all LLM-based agents.

    All LLM agents (reclassification, drafting, judging, summarization) inherit from this class.
    Provides:
    - Shared GeminiClient for API calls
    - Consistent error handling
    - Unified interface contract

    Subclasses should implement their specific logic and return dict with "result" and "status" keys.
    """

    def __init__(self, client: Optional[GeminiClient] = None):
        """
        Initialize LLM agent with Gemini client.

        Args:
            client: GeminiClient instance for API calls. If None, a new client is created.

        Raises:
            ImportError: If GeminiClient cannot be initialized without API keys.
        """
        if client is None:
            from utils.gemini_client import build_gemini_client
            client = build_gemini_client()

        if client is None:
            raise ValueError("LLM client is required for LLM agents")

        self.client = client
