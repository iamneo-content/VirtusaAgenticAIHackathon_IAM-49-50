"""Intent classification agent using LogisticRegression."""

import os
import pickle
from typing import Any, Dict, List

from state import TicketRow


class IntentLogRegAgent:
    """Predicts intent using pre-trained LogisticRegression model."""

    def __init__(self):
        """Load pre-trained LogReg model and TF-IDF vectorizer."""
        model_dir = os.path.join(os.path.dirname(__file__), "..", "ml", "models")
        self.model = pickle.load(open(os.path.join(model_dir, "intent_lr.pkl"), "rb"))
        self.vectorizer = pickle.load(open(os.path.join(model_dir, "tfidf_intent.pkl"), "rb"))

    def predict_intent(self, rows: List[TicketRow]) -> Dict[str, Any]:
        """
        Predict intent using LogisticRegression model.

        Args:
            rows: List of TicketRow objects

        Returns:
            {"result": List[IntentPrediction], "status": "success"}
        """
        if not rows:
            return {"result": [], "status": "success"}

        predictions = []
        texts = [row.get("customer_text", "") for row in rows]
        vectors = self.vectorizer.transform(texts)
        labels = self.model.predict(vectors)
        probas = self.model.predict_proba(vectors)

        for i in range(len(rows)):
            ticket_id = rows[i].get("ticket_id", f"ticket_{i}")
            label = labels[i]
            confidence = float(max(probas[i]))
            confidence = max(0.0, min(1.0, confidence))

            predictions.append({
                "ticket_id": ticket_id,
                "label": label,
                "confidence": confidence
            })

        return {"result": predictions, "status": "success"}
