"""Workflow orchestration for AutoServeAI.

Invokes LangGraph StateGraph definitions and provides orchestration functions.
"""

import os
from typing import Dict, Optional

import pandas as pd

from graph import get_batch_workflow_graph, get_single_ticket_workflow_graph
from state import SingleTicketResult, WorkflowState


def get_settings_from_env() -> Dict:
    """
    Load workflow settings from environment variables.

    Returns:
        Dict with configuration settings
    """
    from dotenv import load_dotenv

    load_dotenv()

    return {
        "confidence_threshold": float(os.getenv("CONFIDENCE_THRESHOLD", "0.65")),
        "cluster_k": int(os.getenv("CLUSTER_K", "12")),
        "embedding_model": os.getenv("EMBEDDING_MODEL", "all-MiniLM-L6-v2"),
        "input_csv": os.getenv("INPUT_CSV", "data/input/tickets.csv"),
        "ground_truth_csv": os.getenv("GROUND_TRUTH_CSV", "eval/ground_truth.csv"),
        "output_dir": os.getenv("OUTPUT_DIR", "eval/runs"),
        "log_level": os.getenv("LOG_LEVEL", "INFO"),
    }


def run_batch_workflow(input_csv: str, run_id: str, confidence_threshold: float = None, cluster_k: int = None) -> Dict:
    """
    Execute batch evaluation workflow via LangGraph.

    Invokes compiled batch workflow graph with initial state.

    Args:
        input_csv: Path to input CSV file
        run_id: Run identifier
        confidence_threshold: Confidence threshold for routing (optional)
        cluster_k: Number of clusters (optional)

    Returns:
        Dict with batch results
    """
    settings = get_settings_from_env()

    # Create initial state
    initial_state: WorkflowState = {
        "request_id": run_id,
        "error_occurred": False,
        "error_messages": [],
        "rows": [],
        "cleaned_rows": [],
        "sentiment_predictions": [],
        "intent_predictions": [],
        "reclass_predictions": [],
        "routing_decision": {},
        "clustering_result": {},
        "confidence_threshold": confidence_threshold if confidence_threshold is not None else settings["confidence_threshold"],
        "cluster_k": cluster_k if cluster_k is not None else settings["cluster_k"],
        "input_csv": input_csv,
    }

    # Invoke batch workflow graph
    graph = get_batch_workflow_graph()
    final_state = graph.invoke(initial_state)

    # Handle errors
    if final_state.get("error_occurred"):
        return {"error": True, "messages": final_state.get("error_messages")}

    # Return results
    return {
        "error": False,
        "total_tickets": len(final_state.get("rows", [])),
        "sentiment_predictions": final_state.get("sentiment_predictions", []),
        "intent_predictions": final_state.get("intent_predictions", []),
        "reclass_predictions": final_state.get("reclass_predictions", []),
        "routing_decision": final_state.get("routing_decision", {}),
        "clusters": final_state.get("clustering_result", {}).get("clusters", {}),
    }


def run_single_ticket_workflow(input_csv: str, ticket_id: str, confidence_threshold: float = None, cluster_k: int = None) -> Optional[SingleTicketResult]:
    """
    Execute single-ticket drafting workflow via LangGraph.

    Invokes compiled single-ticket workflow graph with initial state.

    Args:
        input_csv: Path to input CSV file
        ticket_id: Ticket ID to process
        confidence_threshold: Confidence threshold for routing (optional)
        cluster_k: Number of clusters (optional)

    Returns:
        SingleTicketResult or None on error
    """
    settings = get_settings_from_env()

    # Create initial state
    initial_state: WorkflowState = {
        "request_id": f"single_{ticket_id}",
        "ticket_id": ticket_id,
        "error_occurred": False,
        "error_messages": [],
        "rows": [],
        "cleaned_rows": [],
        "sentiment_predictions": [],
        "intent_predictions": [],
        "reclass_predictions": [],
        "routing_decision": {},
        "clustering_result": {},
        "confidence_threshold": confidence_threshold if confidence_threshold is not None else settings["confidence_threshold"],
        "cluster_k": cluster_k if cluster_k is not None else settings["cluster_k"],
        "input_csv": input_csv,
    }

    # Invoke single-ticket workflow graph
    graph = get_single_ticket_workflow_graph()
    final_state = graph.invoke(initial_state)

    # Handle errors
    if final_state.get("error_occurred"):
        return None

    # Extract data for result
    rows = final_state.get("rows", [])
    cleaned_rows = final_state.get("cleaned_rows", [])
    clusters = final_state.get("clustering_result", {}).get("clusters", {})

    ticket_row = next((r for r in rows if r.get("ticket_id") == ticket_id), None)
    cleaned_ticket_row = next((r for r in cleaned_rows if r.get("ticket_id") == ticket_id), None)

    if not ticket_row or not cleaned_ticket_row:
        return None

    # Get predictions
    sentiment_pred = next(
        (p for p in final_state.get("sentiment_predictions", []) if p["ticket_id"] == ticket_id),
        {"ticket_id": ticket_id, "label": "neutral", "confidence": 0.5},
    )

    intent_pred = next(
        (p for p in final_state.get("intent_predictions", []) if p["ticket_id"] == ticket_id),
        {"ticket_id": ticket_id, "label": "general_support", "confidence": 0.5},
    )

    reclass_pred = next(
        (p for p in final_state.get("reclass_predictions", []) if p["ticket_id"] == ticket_id),
        None,
    )

    # Get context
    cluster_id = clusters.get(ticket_id, -1)
    context_tickets = [
        r for r in cleaned_rows
        if clusters.get(r.get("ticket_id"), -1) == cluster_id and r.get("ticket_id") != ticket_id
    ][:3]

    # Return result
    return {
        "ticket": ticket_row,
        "cleaned_ticket": cleaned_ticket_row,
        "sentiment": sentiment_pred,
        "intent": intent_pred,
        "reclass": reclass_pred,
        "cluster_id": cluster_id,
        "cluster_context": context_tickets,
        "fast_draft": final_state.get("fast_draft", ""),
        "deep_draft": final_state.get("deep_draft", ""),
        "judged_draft": final_state.get("judged_draft", ""),
        "safe_draft": final_state.get("safe_draft", ""),
        "summary": final_state.get("cluster_summary", ""),
    }


