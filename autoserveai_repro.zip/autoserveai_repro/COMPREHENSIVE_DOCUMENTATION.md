AUTOSERVEAI - AGENTIC CUSTOMER SERVICE ANALYZER
==================================================

SECTION 1: PROBLEM DESCRIPTION AND FILE STRUCTURE
==================================================

1.1 PROBLEM STATEMENT
---------------------

The AutoServeAI system addresses the complexity of managing and responding to customer service tickets at scale. Organizations process customer support tickets stored in data/input/tickets.csv and require:

+ Automated categorization of customer issues by sentiment and intent
+ Consistent response quality across high-volume ticket streams
+ Pattern identification across similar customer problems
+ Automatic detection of low-confidence predictions requiring expert review
+ Generation of contextually appropriate responses with varying tones
+ Ensuring no sensitive customer information leaks before response delivery

Critical File and Directory References:

Input Data Location:
+ data/input/tickets.csv: Source CSV file containing raw customer support tickets to be processed
  Required CSV Columns:
  - ticket_id: Unique identifier for each ticket (string)
  - customer_text: Customer message or issue description (string)
  - sample_id: Optional sample identifier for tracking duplicate patterns (string)

Processed Data Output Location:
+ data/processed/cleaned_sentiment_data.csv: Output from sentiment cleaning stage
+ data/processed/cleaned_intent_data.csv: Output from intent cleaning stage
+ data/processed/ directory: Complete repository of all processed and intermediate data files

Model Storage Location:
+ ml/models/sentiment_svm.pkl: Trained sentiment SVM model artifact
+ ml/models/tfidf_sentiment.pkl: Sentiment feature vectorizer for text transformation
+ ml/models/intent_lr.pkl: Trained intent LogisticRegression model artifact
+ ml/models/tfidf_intent.pkl: Intent feature vectorizer for text transformation
+ ml/models/kmeans.pkl: K-means clustering model for grouping similar tickets
+ ml/models/ directory: Complete repository of all trained model files

Evaluation Data Location:
+ data/evaluation_dataset/: Test data used for model performance assessment

Raw Training Data Location:
+ data/raw/training_data/: Original unprocessed training datasets

1.2 PROBLEM DOMAIN AND WORKFLOW ARCHITECTURE
---------------------------------------------

Two Distinct Processing Workflows:

BATCH PROCESSING WORKFLOW:
Purpose: Process large volumes of tickets to extract insights and categorize issues
Input: CSV file from data/input/ directory containing multiple tickets
Output: Predictions, classifications, cluster assignments, and flagged low-confidence cases
Use Case: End-of-day analysis, bulk ticket categorization, pattern identification

SINGLE-TICKET WORKFLOW:
Purpose: Analyze individual tickets and generate multiple response options
Input: Specific ticket selected from CSV in data/input/
Output: Complete analysis with four response drafts, cluster context, and final PII-redacted response
Use Case: Real-time agent assistance, interactive ticket analysis

1.3 COMPLETE FILE STRUCTURE WITH VERIFICATION
-----------------------------------------------

VERIFIED PROJECT DIRECTORY STRUCTURE:

autoserveai_repro/
|
+-- agents/
|   +-- base_llm_agent.py
|   +-- sentiment_svm_agent.py
|   +-- intent_logreg_agent.py
|   +-- clustering_agent.py
|   +-- reclass_llm_agent.py
|   +-- draft_fast_llm_agent.py
|   +-- draft_deep_llm_agent.py
|   +-- judge_llm_agent.py
|   +-- summary_llm_agent.py
|   +-- safety_guard_agent.py
|
+-- nodes/ (11 modules)
|   +-- load_clean_node.py
|   +-- sentiment_prediction_node.py
|   +-- intent_prediction_node.py
|   +-- routing_node.py
|   +-- reclass_node.py
|   +-- clustering_node.py
|   +-- draft_fast_node.py
|   +-- draft_deep_node.py
|   +-- judge_node.py
|   +-- summary_node.py
|   +-- safety_node.py
|
+-- workflow/
|   +-- workflow.py
|
+-- ml/
|   +-- data_cleaning/
|   |   +-- clean_sentiment_data.py
|   |   +-- clean_intent_data.py
|   +-- train_model/
|   |   +-- train_sentiment_model.py
|   |   +-- train_intent_model.py
|   +-- evaluation/
|   |   +-- evaluate_models.py
|   +-- models/ (model artifact directory)
|   |   +-- sentiment_classifier.pkl
|   |   +-- tfidf_sentiment.pkl
|   |   +-- intent_classifier.pkl
|   |   +-- tfidf_intent.pkl
|   |   +-- clustering_model.pkl
|   +-- train_pipeline.py
|
+-- utils/ (pre-loaded, not part of implementation)
|   +-- gemini_client.py
|
+-- data/ (data storage)
|   +-- input/
|   |   +-- tickets.csv (source data for processing)
|   +-- processed/ (output from cleaning stages)
|   |   +-- cleaned_sentiment_data.csv
|   |   +-- cleaned_intent_data.csv
|   +-- evaluation_dataset/ (test data for evaluation)
|   +-- raw/ (raw training data)
|
+-- state.py (state management)
+-- graph.py (workflow orchestration)
+-- main.py (streamlit UI)
+-- tests.py (test suite)
+-- .env (configuration)
+-- installation.txt (dependencies)


SECTION 2: PURPOSE OF FILES AND DIRECTORY STRUCTURE
====================================================

CORE SYSTEM LAYERS
------------------

STATE MANAGEMENT LAYER: state.py
Purpose: Defines complete TypedDict contracts for data structures flowing through entire system
Responsibilities: Type safety, state immutability contracts, data structure definitions
Contains: 8 major TypedDict definitions plus configuration parameters

GRAPH ORCHESTRATION LAYER: graph.py
Purpose: Compiles LangGraph StateGraph objects for both batch and single-ticket workflows
Responsibilities: Workflow DAG construction, conditional routing logic, node sequencing
Contains: Graph compilation functions, routing decision logic, conditional branching

AGENT LAYER: agents/ directory 
Purpose: Encapsulate specialized intelligence as stateless callable objects
Responsibilities: Prediction generation, LLM interactions, data transformations
Structure: Mix of LLM-based agents (inherit from BaseLLMAgent) and ML-based agents

NODE LAYER: nodes/ directory 
Purpose: Transform state sequentially through workflow pipeline
Responsibilities: Node-specific state mutations, agent invocations, error handling
Structure: All nodes follow signature: WorkflowState becomes WorkflowState

WORKFLOW ORCHESTRATION LAYER: workflow/workflow.py
Purpose: High-level entry points for batch and single-ticket processing
Responsibilities: State initialization, graph invocation, result extraction
Contains: Two main execution functions with configuration management

MACHINE LEARNING PIPELINE: ml/ directory 
Purpose: Complete ML lifecycle including data cleaning, model training, evaluation
Responsibilities: Data preparation, model training and serialization, performance assessment
Contains: Three pipeline stages coordinated by train_pipeline.py
Output Locations: Models saved to ml/models/, processed data to data/processed/

USER INTERFACE LAYER: main.py
Purpose: Streamlit web application providing interactive access to all workflows
Responsibilities: UI rendering, user input collection, result visualization
Contains: Three tabs for batch evaluation, single-ticket analysis, model evaluation

TESTING LAYER: tests.py
Purpose: Comprehensive test suite verifying system functionality
Responsibilities: Component testing, integration testing, data quality verification
Contains: 14 test cases covering all major components

UTILITY LAYER: utils/ directory (pre-loaded)
Status: Pre-loaded utilities not part of implementation scope
Contains: gemini_client.py providing LLM API abstraction
Usage: Use as-is without modification

SECTION 3: DETAILED CORE MODULES EXPLANATION
=============================================

===MODULE: state.py===
Classification: State Management Module (TypedDict definitions)
Purpose: Defines all data contracts and state structures for entire workflow system

TypedDict 1: TicketRow
Purpose: Represents single customer support ticket data unit
Fields:
+ ticket_id: String uniquely identifying this ticket
+ customer_text: String containing customer message and issue description
+ sample_id: String identifier for tracking sample origin and batch

TypedDict 2: SentimentPrediction
Purpose: Represents sentiment classification result from ML classifier
Fields:
+ ticket_id: String reference to source ticket
+ label: String value from set: positive, negative, neutral
+ confidence: Float between 0.0 and 1.0 indicating prediction certainty

TypedDict 3: IntentPrediction
Purpose: Represents intent classification result from ML classifier
Fields:
+ ticket_id: String reference to source ticket
+ label: String value from 12 intent categories
+ confidence: Float between 0.0 and 1.0 indicating prediction certainty

TypedDict 4: ReclassPrediction
Purpose: Represents language model-based reclassification with audit trail
Fields:
+ ticket_id: String reference to source ticket
+ label: String new classification from language model
+ confidence: Float between 0.0 and 1.0 for language model reclassification
+ original_label: String original classifier-based classification
+ original_confidence: Float original classifier confidence score

TypedDict 5: ClusteringResult
Purpose: Represents semantic similarity groupings of tickets
Fields:
+ clusters: Dictionary mapping string ticket_id to integer cluster_id

TypedDict 6: RouteDecision
Purpose: Identifies tickets requiring optional reclassification based on confidence
Fields:
+ low_conf_sentiment_ids: List of string ticket_ids with sentiment confidence below threshold
+ low_conf_intent_ids: List of string ticket_ids with intent confidence below threshold
+ all_low_conf_ids: List of string ticket_ids with either sentiment or intent below threshold (union)

TypedDict 7: WorkflowState
Purpose: Central mutable state passed through all workflow nodes
Key Fields:
+ request_id: Unique execution identifier string
+ ticket_id: Target ticket identifier string (empty for batch mode, specified for single-ticket)
+ error_occurred: Boolean flag indicating workflow errors
+ error_messages: List of error message strings for debugging
+ rows: List of TicketRow objects from CSV loading (raw data)
+ cleaned_rows: List of TicketRow objects after text cleaning
+ sentiment_predictions: List of SentimentPrediction objects
+ intent_predictions: List of IntentPrediction objects
+ reclass_predictions: List of ReclassPrediction objects
+ routing_decision: RouteDecision object containing low-confidence identifiers
+ clustering_result: ClusteringResult object mapping tickets to clusters
+ confidence_threshold: Float configuration value (default 0.65)
+ cluster_k: Integer configuration value (default 12, range 2-50)
+ input_csv: File path string to input CSV data
+ Additional single-ticket fields: fast_draft, deep_draft, judged_draft, safe_draft, cluster_summary

TypedDict 8: SingleTicketResult
Purpose: Return structure for single-ticket workflow containing complete analysis
Fields:
+ ticket: TicketRow object containing original ticket data
+ cleaned_ticket: TicketRow object containing cleaned ticket data
+ sentiment: SentimentPrediction object with label and confidence for sentiment
+ intent: IntentPrediction object with label and confidence for primary intent
+ reclass: ReclassPrediction object with LLM reclassification or None if no reclassification occurred
+ cluster_id: Assigned cluster number integer
+ cluster_context: List of TicketRow objects for similar tickets in same cluster
+ fast_draft: Concise response option string (approx 60 words)
+ deep_draft: Comprehensive response option string (70-120 words)
+ judged_draft: Language model-selected best response string
+ safe_draft: Final response after PII redaction string
+ summary: Summary of similar issues in the cluster string

===MODULE: graph.py===
Classification: Graph Orchestration Module (function-based)
Purpose: Compiles and manages LangGraph StateGraph workflows

Key Function 1: route_to_reclassify(state: WorkflowState) returns string
Parameters:
+ state: Current workflow state
  - What: State containing routing decision with low-confidence identifiers
  - From Where: Called by LangGraph conditional_edges during workflow execution
  - DataType: WorkflowState TypedDict object

Logic Explanation:
+ Checks if state.routing_decision.all_low_conf_ids list is empty
+ If list is empty (no low-confidence predictions):
  * Returns string value "cluster"
  * Routes workflow to clustering_node
+ If list contains low-confidence ticket identifiers:
  * Returns string value "reclassify"
  * Routes workflow to reclass_node for language model reclassification
+ Single return value determines which node executes next

Return DataType: String
+ "reclassify": Routes to reclassification node
+ "cluster": Routes directly to clustering node

Key Function 2: get_batch_workflow_graph() returns compiled StateGraph
Parameters: None

Logic Explanation:
+ Creates new StateGraph with WorkflowState as state type
+ Adds all shared nodes: load_clean, sentiment, intent, routing
+ Adds reclass_node with conditional execution
+ Adds clustering_node (always executes)
+ Configures conditional_edges between routing_node and next node
  * Uses route_to_reclassify function to determine path
+ Sets start node to load_clean_node
+ Sets end node to clustering_node
+ Compiles graph for execution

Return DataType: Compiled StateGraph
+ Ready for invocation with initial WorkflowState
+ Executes batch processing path only
+ Returns final WorkflowState containing all predictions and clusters

Key Function 3: get_single_ticket_workflow_graph() returns compiled StateGraph
Parameters: None

Logic Explanation:
+ Creates new StateGraph with WorkflowState as state type
+ Adds all shared nodes: load_clean, sentiment, intent, routing
+ Adds reclass_node with conditional execution
+ Adds clustering_node
+ Adds single-ticket specific nodes:
  * draft_fast_node (generates concise response)
  * draft_deep_node (generates comprehensive response)
  * judge_node (selects best response)
  * summary_node (provides cluster context)
  * safety_node (redacts PII from final response)
+ Configures conditional_edges between routing_node and reclassify/clustering path
+ Sets start node to load_clean_node
+ Sets end node to safety_node (final PII redaction)
+ Compiles graph for execution

Return DataType: Compiled StateGraph
+ Ready for invocation with single-ticket target
+ Executes complete single-ticket processing path
+ Returns final WorkflowState with all analysis and four draft versions

Workflow Path Diagrams:

BATCH PATH:
load_clean -> sentiment -> intent -> routing -> [IF low_conf: reclassify OR cluster] -> cluster -> END

SINGLE-TICKET PATH:
load_clean -> sentiment -> intent -> routing -> [IF low_conf: reclassify OR cluster] -> cluster -> draft_fast -> draft_deep -> judge -> summary -> safety -> END

SECTION 4: DETAILED AGENT MODULES EXPLANATION
==============================================

===MODULE 1: base_llm_agent.py===
Classification: Base Class Module
Purpose: Provides foundation for all LLM-based agents with shared client management

Class: BaseLLMAgent
Purpose: Abstract base class establishing inheritance contract
Inheritance: Standalone base class
Dependencies: GeminiClient from utils (pre-loaded)

Constructor Method: __init__(client: Optional[GeminiClient])
Parameters:
+ client: Optional parameter
  - What: Pre-initialized API client for language model operations
  - From Where: Passed from calling code during agent instantiation or None
  - DataType: Client object instance or None value

Logic Explanation:
+ Accepts client as optional parameter
+ If client is None: Internally calls build_gemini_client() to construct new client
+ After construction attempt: Validates client is not None
+ If client remains None: Raises ValueError indicating client initialization failure
+ Stores validated client as self.client instance variable
+ All subclasses inherit access to self.client for language model operations

Return DataType: None (constructor)

Instance Variables Created:
+ self.client: Stores client instance for subclass method usage

===MODULE 2: sentiment_svm_agent.py===
Classification: Machine Learning Agent Module
Purpose: Classifies customer sentiment using pre-trained classification model

Class: SentimentSVMAgent
Purpose: Performs sentiment analysis on customer text
Inheritance: Standalone class
Dependencies: scikit-learn, pickle, pathlib

Constructor Method: __init__()
Parameters: None required

Logic Explanation:
+ Sets base directory path to ml/models/
+ Attempts to load pre-trained SVM classifier model from ml/models/sentiment_svm.pkl
+ Attempts to load feature vectorizer from ml/models/tfidf_sentiment.pkl
+ On successful load: Stores both in instance variables
+ On file missing or deserialization error: Captures error details and stores None values
+ Initialization continues even if models unavailable (graceful degradation)

Instance Variables Created:
+ self.model: Classifier model object or None
+ self.vectorizer: Feature vectorizer object or None
+ self.error_message: String containing error details if load failed

Key Method: predict_sentiment(rows: List[TicketRow]) returns Dictionary
Parameters:
+ rows: List of TicketRow objects
  - What: Collection of customer support tickets
  - From Where: Passed from load_clean_node through workflow state
  - DataType: List of TicketRow TypedDict objects

Logic Explanation:
+ Extracts customer_text field from each TicketRow
+ Transforms texts through self.vectorizer to obtain feature representations
+ Uses self.model to generate predictions for each text
+ Converts model outputs to confidence scores normalized between 0.0 and 1.0
+ Determines predicted sentiment label from model output
+ Maps numeric model outputs to semantic labels: positive, negative, or neutral
+ Creates SentimentPrediction object for each ticket with label and confidence
+ Collects all predictions into list

Return DataType: Dictionary
+ "result": List of SentimentPrediction dictionaries
+ "status": String value "success" if completed or "error" if model unavailable

Error Handling Strategy:
+ If models not loaded during initialization: Returns empty predictions list with status error
+ If vectorization fails on specific text: Skips that ticket and continues
+ System continues operating with partial results

===MODULE 3: intent_logreg_agent.py===
Classification: Machine Learning Agent Module
Purpose: Classifies customer issues into one of twelve predefined categories

Class: IntentLogRegAgent
Purpose: Performs intent prediction on customer messages
Inheritance: Standalone class
Dependencies: scikit-learn, pickle, pathlib

Constructor Method: __init__()
Parameters: None required

Logic Explanation:
+ Sets base directory path to ml/models/
+ Attempts to load pre-trained LogisticRegression classifier from ml/models/intent_lr.pkl
+ Attempts to load feature vectorizer from ml/models/tfidf_intent.pkl
+ Stores models on successful load or None on failure
+ Captures and stores error information

Instance Variables Created:
+ self.model: Classifier object or None
+ self.vectorizer: Feature vectorizer object or None
+ self.error_message: Error details string

Key Method: predict_intent(rows: List[TicketRow]) returns Dictionary
Parameters:
+ rows: List of TicketRow objects
  - What: Collection of customer support tickets for intent categorization
  - From Where: Passed from sentiment_node through workflow state
  - DataType: List of TicketRow TypedDict objects

Logic Explanation:
+ Extracts customer_text from each TicketRow
+ Transforms texts through self.vectorizer to obtain feature representations
+ Uses self.model to generate prediction probabilities for each text
+ Extracts probability values for all predicted classes
+ Selects class with maximum probability as predicted intent
+ Uses maximum probability value as confidence score
+ Maps numeric class indices to intent category strings
+ Creates IntentPrediction object with category label and confidence
+ Collects all predictions

Return DataType: Dictionary
+ "result": List of IntentPrediction dictionaries
+ "status": String value "success" or "error"

Intent Categories Supported (12 total):
+ technical_problem, billing_issue, order_issue, account_help, feature_request, refund_request, login_issue, subscription_change, verification_issue, api_access, sso_support, data_export

===MODULE 4: clustering_agent.py===
Classification: Machine Learning Agent Module
Purpose: Groups similar tickets together for contextual analysis

Class: ClusteringAgent
Purpose: Performs semantic clustering of customer tickets
Inheritance: Standalone class
Dependencies: scikit-learn, pickle, pathlib

Constructor Method: __init__(n_clusters: int = 12)
Parameters:
+ n_clusters: Integer specifying desired number of clusters
  - What: Number of groups to partition tickets into
  - From Where: Passed from state.cluster_k or UI configuration
  - DataType: Integer between 2 and 50
  - Default Value: 12

Logic Explanation:
+ Stores n_clusters parameter for clustering configuration
+ Initializes feature vectorizer with specific parameters (500 features, 1-2 character n-grams)
+ Attempts to load pre-trained K-means clustering model from ml/models/kmeans.pkl
+ If pre-trained model exists: Sets self.model to loaded object
+ If pre-trained model missing: Sets self.model to None indicating need for training
+ Vectorizer is always available regardless of model availability

Instance Variables Created:
+ self.model: Clustering model object or None
+ self.vectorizer: Feature vectorizer object
+ self.n_clusters: Stored cluster count value

Key Method: cluster_tickets(rows: List[TicketRow]) returns Dictionary
Parameters:
+ rows: List of TicketRow objects
  - What: All customer tickets requiring cluster assignment
  - From Where: Passed from routing_node through workflow state
  - DataType: List of TicketRow TypedDict objects

Logic Explanation:
+ Extracts customer_text from each TicketRow
+ Fits feature vectorizer on entire text collection and transforms to numerical feature space
+ Checks if self.model is None:
  * If None: Creates new clustering model with n_clusters parameter and fits on vectorized data
  * If exists: Uses existing model to predict cluster assignments
+ Generates cluster assignment for each ticket (ticket_id maps to cluster_id)
+ Creates mapping dictionary with ticket_id as key and cluster_id as value
+ Returns mapping within standard response structure

Return DataType: Dictionary
+ "result": Nested dictionary with "clusters" key containing {ticket_id: cluster_id} mapping
+ "status": String value "success" or "error"

Error Handling Strategy:
+ If clustering fails: Gracefully assigns all tickets to cluster 0
+ Returns cluster mapping even in error state using fallback approach
+ Prevents workflow interruption

===MODULE 5: reclass_llm_agent.py===
Classification: LLM-based Agent Module
Purpose: Uses language model to upgrade low-confidence predictions with reasoning

Class: ReclassLLMAgent
Purpose: Performs intelligent reclassification of uncertain predictions
Inheritance: Inherits from BaseLLMAgent
Dependencies: self.client from parent class

Constructor Method: __init__(client: Optional[GeminiClient])
Parameters:
+ client: Optional client parameter
  - What: Pre-initialized API client
  - From Where: Passed from reclass_node
  - DataType: Client object or None

Key Method: reclassify_predictions(rows: List[TicketRow], low_conf_ticket_ids: List[string], original_predictions: List[IntentPrediction]) returns Dictionary
Parameters:
+ rows: List of all TicketRow objects
  - What: Complete collection of customer tickets
  - From Where: Passed from reclass_node via workflow state
  - DataType: List of TicketRow TypedDict objects
+ low_conf_ticket_ids: List of ticket identifiers
  - What: Specific ticket IDs identified as having low confidence
  - From Where: From state.routing_decision.all_low_conf_ids
  - DataType: List of string values
+ original_predictions: List of IntentPrediction objects
  - What: Original classifier predictions
  - From Where: From state.intent_predictions
  - DataType: List of IntentPrediction TypedDict objects

Logic Explanation:
For each ticket_id in low_conf_ticket_ids:
+ Locates matching TicketRow in rows collection
+ Finds corresponding IntentPrediction from original_predictions
+ Extracts customer_text and original classification label
+ Constructs language model prompt incorporating:
  * Customer issue text
  * Original classifier label
  * Original confidence score
  * Request for language model to provide alternative classification with reasoning
+ Calls self.client.generate_structured_json() with prompt and requirements
+ Parses structured JSON response from language model
+ Creates ReclassPrediction object containing both original and new classifications
+ Fallback on language model error:
  * Uses original label unchanged
  * Sets confidence to 0.5 (neutral uncertainty)
  * Uses generic reasoning message
+ Accumulates all reclassifications

Return DataType: Dictionary
+ "result": List of ReclassPrediction dictionaries with original and upgraded values
+ "status": String value "success" or "error"

===MODULE 6: draft_fast_llm_agent.py===
Classification: LLM-based Agent Module
Purpose: Generates concise customer response options approximately 60 words

Class: DraftFastLLMAgent
Purpose: Creates brief response drafts
Inheritance: Inherits from BaseLLMAgent
Dependencies: self.client from parent class

Key Method: generate_fast_draft(rows: List[TicketRow], intent_map: Dictionary) returns Dictionary
Parameters:
+ rows: List of TicketRow objects (filtered to target ticket)
  - What: Single customer ticket requiring response
  - From Where: Filtered from state.cleaned_rows by draft_fast_node
  - DataType: List containing single TicketRow
+ intent_map: Dictionary mapping identifiers to intent labels
  - What: Pre-computed intent classifications
  - From Where: Built in draft_fast_node from predictions
  - DataType: Dictionary mapping string ticket_id to string intent_label

Logic Explanation:
+ Extracts target ticket from rows list
+ Retrieves customer_text and intent_label using intent_map
+ Constructs language model prompt requesting:
  * Brief professional acknowledgement of issue
  * Direct solution recommendation
  * Word limit approximately 60 words
+ Calls self.client.generate_content() with prompt configuration
+ Extracts generated text from language model response
+ Wraps result in standard response dictionary

Return DataType: Dictionary
+ "result": Dictionary mapping ticket_id to generated draft_text (string)
+ "status": String value "success" or "error"

Error Handling Strategy:
+ On language model failure: Returns empty string for draft_text
+ Allows workflow continuation for judge node to handle

===MODULE 7: draft_deep_llm_agent.py===
Classification: LLM-based Agent Module
Purpose: Generates comprehensive customer response options 70-120 words with empathy

Class: DraftDeepLLMAgent
Purpose: Creates detailed response drafts
Inheritance: Inherits from BaseLLMAgent
Dependencies: self.client from parent class

Key Method: generate_deep_draft(rows: List[TicketRow], intent_map: Dictionary) returns Dictionary
Parameters: Identical to generate_fast_draft()

Logic Explanation:
+ Extracts target ticket information
+ Constructs language model prompt requesting:
  * Sincere empathy and acknowledgement of customer frustration
  * Multiple solution approaches
  * Clear action steps and timeline
  * Reassurance and support messaging
  * Word limit 70-120 words
+ Calls self.client.generate_content() with prompt configuration
+ Extracts generated text

Return DataType: Dictionary
+ "result": Dictionary mapping ticket_id to generated draft_text (string)
+ "status": String value "success" or "error"

===MODULE 8: judge_llm_agent.py===
Classification: LLM-based Agent Module
Purpose: Compares two response drafts and automatically selects the most appropriate

Class: JudgeLLMAgent
Purpose: Performs intelligent draft evaluation and selection
Inheritance: Inherits from BaseLLMAgent
Dependencies: self.client from parent class

Key Method: evaluate_and_judge_drafts(ticket_id: string, customer_text: string, fast_draft: string, deep_draft: string) returns Dictionary
Parameters:
+ ticket_id: String identifier
  - What: Unique ticket identifier for reference
  - From Where: From target ticket in workflow state
  - DataType: String
+ customer_text: String containing issue description
  - What: Original customer message providing context
  - From Where: From target TicketRow in state.cleaned_rows
  - DataType: String
+ fast_draft: String containing response option 1
  - What: Brief response generated by DraftFastLLMAgent
  - From Where: From state.fast_draft
  - DataType: String
+ deep_draft: String containing response option 2
  - What: Comprehensive response generated by DraftDeepLLMAgent
  - From Where: From state.deep_draft
  - DataType: String

Logic Explanation:
+ Constructs language model prompt providing:
  * Original customer issue text for context
  * Fast draft option (labeled as Option 1)
  * Deep draft option (labeled as Option 2)
  * Evaluation criteria list:
    - Relevance to specific issue
    - Clarity of communication
    - Empathy expression
    - Completeness of solution
    - Customer satisfaction likelihood
+ Calls self.client.generate_structured_json() with evaluation requirements
+ Parses returned JSON containing selection and reasoning
+ Fallback on language model error:
  * Defaults to selecting option 2 (deep_draft) as safer choice
  * Uses pre-written default rationale
+ Creates result dictionary with selected draft text and reasoning

Return DataType: Dictionary
+ "result": Nested dictionary containing:
  - "selected_draft": Full text of chosen response
  - "selected_option": Integer 1 or 2
  - "rationale": String explanation of selection
+ "status": String value "success" or "error"

===MODULE 9: summary_llm_agent.py===
Classification: LLM-based Agent Module
Purpose: Summarizes patterns in similar tickets within same cluster

Class: SummaryLLMAgent
Purpose: Creates contextual summaries of cluster patterns
Inheritance: Inherits from BaseLLMAgent
Dependencies: self.client from parent class

Key Method: generate_cluster_summary(cluster_tickets: List[TicketRow]) returns Dictionary
Parameters:
+ cluster_tickets: List of TicketRow objects
  - What: Similar tickets from same cluster as target
  - From Where: Extracted from state.clustering_result by summary_node
  - DataType: List of TicketRow TypedDict objects (up to 5 tickets)

Logic Explanation:
+ Extracts customer_text from each ticket in cluster_tickets
+ Limits extraction to first 200 characters per ticket (context bounding)
+ Limits processing to maximum 5 tickets (context management)
+ Constructs language model prompt providing:
  * Customer texts from similar tickets
  * Request to identify 2-3 sentence summary of common problem patterns
+ Calls self.client.generate_content() with summary prompt
+ Extracts generated summary text

Return DataType: Dictionary
+ "result": String containing summary of common patterns
+ "status": String value "success" or "error"

Error Handling Strategy:
+ On language model failure: Returns generic default message
+ Allows workflow continuation

===MODULE 10: safety_guard_agent.py===
Classification: Utility Agent Module
Purpose: Removes personally identifiable information from responses

Class: SafetyGuardAgent
Purpose: Performs PII redaction
Inheritance: Standalone class
Dependencies: Regular expression module (re)

Static Method: redact_pii(text: string) returns Dictionary
Parameters:
+ text: String containing response to analyze
  - What: Final response text requiring PII removal
  - From Where: From state.judged_draft by safety_node
  - DataType: String

Logic Explanation:
+ Applies regex pattern matching to identify PII categories:
  * Email addresses: Replaced with [EMAIL]
  * Phone numbers: Replaced with [PHONE]
  * Credit card patterns: Replaced with [CARD]
  * Social security numbers: Replaced with [SENSITIVE]
  * Six-plus digit sequences: Replaced with [NUMBER]
+ Executes pattern replacements sequentially
+ Returns fully redacted text with PII tokens

Return DataType: Dictionary
+ "result": String containing PII-redacted response text
+ "status": String value "success" or "error"

Critical Purpose:
+ Final security checkpoint ensuring no customer data leakage
+ Required before any response delivery to customer

SECTION 5: DETAILED NODE MODULES EXPLANATION
=============================================

NODE FUNCTION PATTERNS:
All node functions follow the standard workflow pattern:
Input: WorkflowState parameter (current execution state)
Processing: State-specific transformations and agent invocations
Output: Modified WorkflowState returned to next node
Error Handling: Error flags and messages stored in state

===NODE 1: load_clean_node.py===
Classification: Function-based Module (no classes)
Purpose: Reads CSV file and normalizes customer ticket text

Key Functions:

FUNCTION: load_rows(csv_path: string) returns List[TicketRow]
Parameters:
+ csv_path: File path string to CSV file
  - What: Location of input data file
  - From Where: Passed from state.input_csv or UI configuration
  - DataType: String file path

Logic Explanation:
+ Opens CSV file using DictReader for flexible column handling
+ Iterates through each row in CSV
+ Creates TicketRow object with: ticket_id, customer_text, sample_id
+ Handles missing columns with default values
+ Closes file handle

Return DataType: List[TicketRow]
+ Returns list of TicketRow dictionaries
+ Returns empty list if file not found

FUNCTION: clean_text(text: string) returns string
Parameters:
+ text: Raw customer message requiring normalization
  - What: Text requiring standardization
  - From Where: From TicketRow.customer_text
  - DataType: String

Logic Explanation:
+ Converts entire text to lowercase
+ Removes leading and trailing whitespace
+ Normalizes interior whitespace
+ Removes special formatting characters

Return DataType: String
+ Returns normalized text

NODE FUNCTION: load_clean_node(state: WorkflowState) returns WorkflowState
Parameters:
+ state: Current workflow execution state
  - What: Current state containing configuration
  - From Where: LangGraph StateGraph invocation
  - DataType: WorkflowState TypedDict

Logic Explanation:
+ Accesses state.input_csv to determine source file
+ Calls load_rows(state.input_csv) to read and parse CSV
+ Stores raw rows in state.rows
+ For each row: calls clean_text() to normalize
+ Stores cleaned rows in state.cleaned_rows
+ Sets state.error_occurred based on success/failure
+ On file not found: sets appropriate error flags
+ Returns modified state

Return DataType: WorkflowState
+ Modified state with populated rows and cleaned_rows

===NODE 2: sentiment_prediction_node.py===
Classification: Function-based Module
Purpose: Applies sentiment classification to all cleaned tickets

NODE FUNCTION: sentiment_node(state: WorkflowState) returns WorkflowState
Parameters:
+ state: Workflow state from load_clean_node
  - What: State containing cleaned ticket data
  - From Where: LangGraph StateGraph
  - DataType: WorkflowState

Logic Explanation:
+ Creates SentimentSVMAgent() instance
+ Calls agent.predict_sentiment(state.cleaned_rows)
+ Receives list of SentimentPrediction objects
+ Updates state.sentiment_predictions with predictions
+ On agent error: sets error flags and empty predictions list
+ Returns modified state

Return DataType: WorkflowState
+ State with sentiment_predictions populated

===NODE 3: intent_prediction_node.py===
Classification: Function-based Module
Purpose: Applies intent classification to all cleaned tickets

NODE FUNCTION: intent_node(state: WorkflowState) returns WorkflowState
Parameters:
+ state: Workflow state from sentiment_node
  - What: State with sentiment predictions
  - From Where: LangGraph StateGraph
  - DataType: WorkflowState

Logic Explanation:
+ Creates IntentLogRegAgent() instance
+ Calls agent.predict_intent(state.cleaned_rows)
+ Updates state.intent_predictions
+ On error: sets error flags and empty predictions
+ Returns modified state

Return DataType: WorkflowState
+ State with intent_predictions populated

===NODE 4: routing_node.py===
Classification: Function-based Module
Purpose: Identifies tickets with low-confidence predictions

NODE FUNCTION: routing_node(state: WorkflowState) returns WorkflowState
Parameters:
+ state: Workflow state from intent_node
  - What: State with both sentiment and intent predictions
  - From Where: LangGraph StateGraph
  - DataType: WorkflowState

Logic Explanation:
+ Initializes three lists for tracking low-confidence predictions
+ Iterates through state.sentiment_predictions checking confidence vs threshold
+ Iterates through state.intent_predictions checking confidence vs threshold
+ Identifies tickets below state.confidence_threshold
+ Creates RouteDecision object with identified low-confidence ticket identifiers
+ Updates state.routing_decision
+ Returns modified state

Return DataType: WorkflowState
+ State with routing_decision populated

===NODE 5: reclass_node.py===
Classification: Function-based Module
Purpose: Executes optional language model-based reclassification

NODE FUNCTION: reclass_node(state: WorkflowState) returns WorkflowState
Parameters:
+ state: Workflow state from routing_node
  - What: State with routing decision
  - From Where: LangGraph StateGraph
  - DataType: WorkflowState

Logic Explanation:
+ Checks if low-confidence predictions exist
+ If empty: returns state unchanged with empty reclass_predictions
+ If contains identifiers:
  * Creates ReclassLLMAgent(client)
  * Calls agent.reclassify_predictions()
  * Updates state.reclass_predictions
+ On agent error: fails silently, returns state with empty reclass_predictions
+ Returns modified state

Return DataType: WorkflowState
+ State with reclass_predictions populated

===NODE 6: clustering_node.py===
Classification: Function-based Module
Purpose: Groups similar tickets for contextual analysis

NODE FUNCTION: clustering_node(state: WorkflowState) returns WorkflowState
Parameters:
+ state: Workflow state from reclass_node
  - What: State with all predictions
  - From Where: LangGraph StateGraph
  - DataType: WorkflowState

Logic Explanation:
+ Creates ClusteringAgent(n_clusters=state.cluster_k)
+ Calls agent.cluster_tickets(state.cleaned_rows)
+ Updates state.clustering_result with cluster mapping
+ Returns modified state

Return DataType: WorkflowState
+ State with clustering_result populated

===NODE 7: draft_fast_node.py===
Classification: Function-based Module
Purpose: Generates concise response option for single-ticket workflow

NODE FUNCTION: draft_fast_node(state: WorkflowState) returns WorkflowState
Parameters:
+ state: Workflow state from clustering_node
  - What: State containing all classifications
  - From Where: LangGraph StateGraph
  - DataType: WorkflowState

Conditional Execution:
+ Only executes when state.ticket_id is not empty string
+ Skips execution in batch mode (ticket_id empty)

Logic Explanation:
+ Filters rows to target ticket
+ Builds intent_map preferring reclassifications
+ Creates DraftFastLLMAgent(client)
+ Calls agent.generate_fast_draft()
+ Updates state.fast_draft
+ Returns modified state

Return DataType: WorkflowState
+ State with fast_draft populated

===NODE 8: draft_deep_node.py===
Classification: Function-based Module
Purpose: Generates comprehensive response option for single-ticket workflow

NODE FUNCTION: draft_deep_node(state: WorkflowState) returns WorkflowState
Parameters:
+ state: Workflow state from clustering_node
  - What: State containing all classifications
  - From Where: LangGraph StateGraph
  - DataType: WorkflowState

Conditional Execution: Only in single-ticket mode

Logic Explanation:
+ Filters rows to target ticket
+ Builds intent_map
+ Creates DraftDeepLLMAgent(client)
+ Calls agent.generate_deep_draft()
+ Updates state.deep_draft
+ Returns modified state

Return DataType: WorkflowState
+ State with deep_draft populated

===NODE 9: judge_node.py===
Classification: Function-based Module
Purpose: Evaluates and selects best response option

NODE FUNCTION: judge_node(state: WorkflowState) returns WorkflowState
Parameters:
+ state: Workflow state from draft_deep_node
  - What: State with both draft options
  - From Where: LangGraph StateGraph
  - DataType: WorkflowState

Conditional Execution: Only in single-ticket mode

Logic Explanation:
+ Finds target ticket in cleaned_rows
+ Extracts customer_text
+ Creates JudgeLLMAgent(client)
+ Calls agent.evaluate_and_judge_drafts()
+ Updates state.judged_draft with selected response
+ Returns modified state

Return DataType: WorkflowState
+ State with judged_draft populated

===NODE 10: summary_node.py===
Classification: Function-based Module
Purpose: Provides context from similar tickets in cluster

NODE FUNCTION: clustering_summary_node(state: WorkflowState) returns WorkflowState
Parameters:
+ state: Workflow state from judge_node
  - What: State with judgments complete
  - From Where: LangGraph StateGraph
  - DataType: WorkflowState

Conditional Execution: Only in single-ticket mode

Logic Explanation:
+ Finds target ticket cluster_id
+ Collects up to 5 similar cluster members
+ Creates SummaryLLMAgent(client)
+ Calls agent.generate_cluster_summary()
+ Updates state.cluster_summary and state.cluster_context
+ Returns modified state

Return DataType: WorkflowState
+ State with cluster_summary and cluster_context populated

===NODE 11: safety_node.py===
Classification: Function-based Module
Purpose: Final PII redaction before response delivery

NODE FUNCTION: safety_guard_node(state: WorkflowState) returns WorkflowState
Parameters:
+ state: Workflow state from summary_node
  - What: State with complete analysis
  - From Where: LangGraph StateGraph
  - DataType: WorkflowState

Conditional Execution: Only in single-ticket mode as final step

Logic Explanation:
+ Extracts state.judged_draft
+ Calls SafetyGuardAgent.redact_pii()
+ Updates state.safe_draft
+ Returns modified state

Return DataType: WorkflowState
+ State with safe_draft populated (final response)

SECTION 6: WORKFLOW ORCHESTRATION MODULE
=========================================

===WORKFLOW MODULE: workflow.py===
Classification: Orchestration Module (function-based, no classes)
Purpose: High-level entry points for batch and single-ticket workflows

Key Functions:

FUNCTION 1: run_batch_workflow(input_csv: string, run_id: string, confidence_threshold: Optional[float], cluster_k: Optional[int]) returns Dictionary
Parameters:
+ input_csv: File path string to CSV file
  - What: Source data location from data/input/
  - From Where: UI input or configuration
  - DataType: String file path
+ run_id: Unique execution identifier
  - What: Identifier for this workflow execution
  - From Where: Generated from current timestamp or UI provided
  - DataType: String
+ confidence_threshold: Optional float value
  - What: Minimum acceptable prediction confidence
  - From Where: UI slider or environment configuration
  - DataType: Float between 0.0 and 1.0 or None
+ cluster_k: Optional integer value
  - What: Number of clusters for grouping
  - From Where: UI slider or environment configuration
  - DataType: Integer between 2 and 50 or None

Logic Flow:
+ Creates initial WorkflowState with batch configuration
+ Sets ticket_id to empty string (batch mode indicator)
+ Sets input_csv and configuration parameters
+ Initializes all prediction lists and result dictionaries to empty
+ Retrieves compiled batch workflow graph via get_batch_workflow_graph()
+ Executes workflow: final_state = graph.invoke(initial_state)
+ Checks final_state.error_occurred flag to determine success/failure
+ Extracts relevant results from final state

Return DataType: Dictionary
+ "error": Boolean indicating whether workflow encountered critical errors
+ "total_tickets": Integer count of tickets processed
+ "sentiment_predictions": List of all sentiment results
+ "intent_predictions": List of all intent results
+ "reclass_predictions": List of reclassified results (empty if none)
+ "routing_decision": Contains low-confidence identifiers
+ "clusters": Cluster assignments for all tickets
+ "messages": String containing any error messages

FUNCTION 2: run_single_ticket_workflow(input_csv: string, ticket_id: string, confidence_threshold: Optional[float], cluster_k: Optional[int]) returns Optional[SingleTicketResult]
Parameters:
+ input_csv: File path string to CSV file
  - What: Source data location
  - From Where: UI input or configuration
  - DataType: String file path
+ ticket_id: String identifier of target ticket
  - What: Specific ticket to analyze
  - From Where: UI ticket selector
  - DataType: String
+ confidence_threshold: Optional float value
  - What: Minimum acceptable prediction confidence
  - From Where: UI slider or environment configuration
  - DataType: Float between 0.0 and 1.0 or None
+ cluster_k: Optional integer value
  - What: Number of clusters configuration
  - From Where: UI slider or environment configuration
  - DataType: Integer between 2 and 50 or None

Logic Flow:
+ Creates initial WorkflowState with single-ticket configuration
+ Sets ticket_id to specified identifier (single-ticket mode indicator)
+ Sets all configuration parameters
+ Initializes data structures for predictions and results
+ Retrieves compiled single-ticket workflow graph
+ Executes full workflow: final_state = graph.invoke(initial_state)
+ Locates target ticket in final_state.cleaned_rows by matching ticket_id
+ If target ticket not found: returns None (error handling)
+ Extracts from final state: ticket data, sentiment prediction, intent prediction, reclassification (if occurred), cluster assignment
+ Retrieves context: cluster identifier, up to five similar tickets, cluster summary
+ Builds SingleTicketResult object containing all analysis components

Return DataType: Optional[SingleTicketResult]
If successful: SingleTicketResult containing:
+ ticket_id, customer_text
+ sentiment_label, sentiment_confidence
+ intent_label, intent_confidence
+ reclass_label, reclass_confidence (if reclassified)
+ cluster_id
+ fast_draft, deep_draft, judged_draft, safe_draft (four response options)
+ cluster_summary
+ cluster_context (list of similar tickets)

If error: Returns None

SECTION 7: MACHINE LEARNING PIPELINE MODULES
=============================================

===MODULE: clean_sentiment_data.py===
Classification: Data Cleaning Function Module
Purpose: Prepares raw sentiment training data for model training

Input Requirements:
+ CSV must contain columns: customer_text, sentiment_label, sample_id
+ sentiment_label must be one of: positive, negative, neutral
+ Duplicates marked with DUP_ prefix in sample_id are removed

Key Function: clean_sentiment_dataset(csv_path: string) returns DataFrame
Parameters:
+ csv_path: File path string to raw sentiment training CSV
  - What: Location of unprocessed training data
  - From Where: Passed from train_pipeline or direct call
  - DataType: String file path

Logic Flow:
+ Reads CSV file using pandas
+ Removes rows with null values in sentiment_label or customer_text columns
+ Filters out duplicate rows marked with DUP_ prefix in sample_id
+ Validates that labels contain only positive, negative, or neutral values
+ Removes rows with invalid labels
+ Reduces excess punctuation
+ Normalizes whitespace
+ Removes text entries shorter than 3 characters
+ Returns cleaned DataFrame

Return DataType: DataFrame
+ Returns cleaned sentiment training data ready for model training

Output Location: data/processed/cleaned_sentiment_data.csv

===MODULE: clean_intent_data.py===
Classification: Data Cleaning Function Module
Purpose: Prepares raw intent training data for model training

Input Requirements:
+ CSV must contain columns: customer_text, intent_label, sample_id
+ intent_label must be one of: technical_problem, billing_issue, order_issue, account_help, feature_request, refund_request, login_issue, subscription_change, verification_issue, api_access, sso_support, data_export
+ Duplicates marked with DUP_ prefix in sample_id are removed

Key Function: clean_intent_dataset(csv_path: string) returns DataFrame
Parameters:
+ csv_path: File path string to raw intent training CSV
  - What: Location of unprocessed intent training data
  - From Where: Passed from train_pipeline
  - DataType: String file path

Logic Flow:
+ Reads CSV file using pandas
+ Removes rows with null values in intent_label or customer_text columns
+ Removes duplicate rows marked with DUP_ prefix in sample_id
+ Validates intent labels against 12 valid categories
+ Removes rows with invalid labels
+ Reduces excess punctuation
+ Normalizes whitespace
+ Removes short text entries
+ Returns cleaned DataFrame

Return DataType: DataFrame
+ Returns cleaned intent training data ready for model training

Output Location: data/processed/cleaned_intent_data.csv

Valid Intent Categories: technical_problem, billing_issue, order_issue, account_help, feature_request, refund_request, login_issue, subscription_change, verification_issue, api_access, sso_support, data_export

===MODULE: train_sentiment_model.py===
Classification: Model Training Function Module
Purpose: Trains classifier model for sentiment classification

Key Function: train_sentiment_model(training_csv: string, output_dir: string) returns Dictionary
Parameters:
+ training_csv: File path string to cleaned sentiment training data
  - What: Input training dataset
  - From Where: Output from clean_sentiment_data.py
  - DataType: String file path
+ output_dir: Directory path where trained model files should be saved
  - What: Destination for model artifacts
  - From Where: Typically ml/models/
  - DataType: String directory path

Logic Flow:
+ Loads training CSV and cleans data
+ Splits data into training (80%) and test (20%) sets using stratified split
+ Creates feature vectorizer with 5000 features, 1-2 character grams
+ Fits vectorizer on training text
+ Trains classifier on vectorized training data
+ Saves trained classifier to output_dir as sentiment_classifier.pkl
+ Saves fitted vectorizer to output_dir as tfidf_sentiment.pkl
+ Evaluates on test set calculating performance metrics
+ Returns metrics dictionary

Return DataType: Dictionary
+ "train_accuracy": Float accuracy on training set
+ "test_accuracy": Float accuracy on test set
+ "f1_score": Float F1-score on test set

Output Files:
+ ml/models/sentiment_classifier.pkl
+ ml/models/tfidf_sentiment.pkl

===MODULE: train_intent_model.py===
Classification: Model Training Function Module
Purpose: Trains classifier model for intent classification

Key Function: train_intent_model(training_csv: string, output_dir: string) returns Dictionary
Parameters:
+ training_csv: File path string to cleaned intent training data
  - What: Input training dataset
  - From Where: Output from clean_intent_data.py
  - DataType: String file path
+ output_dir: Directory path for model artifacts
  - What: Destination directory
  - From Where: Typically ml/models/
  - DataType: String directory path

Logic Flow:
+ Loads training CSV and cleans data
+ Splits data into training (80%) and test (20%) sets using stratified split
+ Creates feature vectorizer with 5000 features
+ Fits vectorizer on training text
+ Trains classifier on vectorized data
+ Saves trained classifier to output_dir as intent_classifier.pkl
+ Saves fitted vectorizer to output_dir as tfidf_intent.pkl
+ Evaluates on test set
+ Returns metrics dictionary

Return DataType: Dictionary
+ "train_accuracy": Float accuracy on training set
+ "test_accuracy": Float accuracy on test set
+ "f1_score": Float F1-score on test set

Output Files:
+ ml/models/intent_classifier.pkl
+ ml/models/tfidf_intent.pkl

===MODULE: evaluate_models.py===
Classification: Model Evaluation Function Module
Purpose: Evaluates trained models on unseen test datasets

Key Function: evaluate_all_models(evaluation_dir: string, model_dir: string) returns Dictionary
Parameters:
+ evaluation_dir: Directory path containing test data files
  - What: Location of evaluation datasets
  - From Where: data/evaluation_dataset/
  - DataType: String directory path
+ model_dir: Directory path containing trained model pickle files
  - What: Location of trained models
  - From Where: ml/models/
  - DataType: String directory path

Logic Flow:
+ Loads trained sentiment classifier and vectorizer from model_dir
+ Loads trained intent classifier and vectorizer from model_dir
+ Loads test datasets from evaluation_dir
+ Transforms test texts using loaded vectorizers
+ Generates predictions using loaded classifiers
+ Calculates performance metrics: accuracy, precision, recall, F1-score
+ Combines results into single dictionary
+ Returns overall evaluation results

Return DataType: Dictionary
+ Contains results for both sentiment and intent models
+ Each model contains: status, model_type, samples, accuracy, precision, recall, f1_score

===MODULE: train_pipeline.py===
Classification: Pipeline Orchestration Function Module
Purpose: Orchestrates entire machine learning workflow

Key Function: run_full_pipeline(training_dir: string, evaluation_dir: string, output_dir: string, processed_dir: Optional[string]) returns Dictionary
Parameters:
+ training_dir: Directory path with raw training data
  - What: Location of unprocessed training datasets
  - From Where: data/raw/training_data/
  - DataType: String directory path
+ evaluation_dir: Directory path with test data
  - What: Location of evaluation datasets
  - From Where: data/evaluation_dataset/
  - DataType: String directory path
+ output_dir: Directory path for model artifacts
  - What: Destination for trained models
  - From Where: ml/models/
  - DataType: String directory path
+ processed_dir: Optional directory path for processed data
  - What: Destination for cleaned data
  - From Where: data/processed/
  - DataType: Optional string directory path

Logic Flow:

STAGE 1 - DATA CLEANING:
+ Loads sentiment raw training data from training_dir
+ Calls clean_sentiment_dataset()
+ Saves cleaned data to processed_dir if specified
+ Loads intent raw training data
+ Calls clean_intent_dataset()
+ Saves cleaned data to processed_dir if specified

STAGE 2 - MODEL TRAINING:
+ Calls train_sentiment_model() with cleaned sentiment data
+ Saves sentiment model files to output_dir
+ Calls train_intent_model() with cleaned intent data
+ Saves intent model files to output_dir
+ Stores training metrics

STAGE 3 - MODEL EVALUATION:
+ Calls evaluate_all_models()
+ Compares test performance against training performance
+ Detects overfitting or underfitting scenarios

FINAL STEP - RESULTS AGGREGATION:
+ Combines all metrics into unified results structure
+ Returns complete pipeline execution report

Return DataType: Dictionary
+ "status": "success" or "error"
+ "data_cleaning": Cleaning stage results
+ "model_training": Training metrics for both models
+ "model_evaluation": Evaluation metrics for both models
+ "summary": Overall pipeline status message

Output Files and Directories:
+ data/processed/cleaned_sentiment_data.csv
+ data/processed/cleaned_intent_data.csv
+ ml/models/sentiment_classifier.pkl
+ ml/models/tfidf_sentiment.pkl
+ ml/models/intent_classifier.pkl
+ ml/models/tfidf_intent.pkl
+ ml/models/clustering_model.pkl

SECTION 8: USER INTERFACE AND MAIN MODULE
==========================================

===MODULE: main.py===
Classification: Streamlit Web Application Module
Purpose: Provides interactive web-based interface for all workflows

Application Entry Point:
+ main() function executed when streamlit run main.py launched
+ Initializes page configuration
+ Loads custom CSS styling
+ Creates three-tab interface

Page Configuration:
+ Page title: "AutoServeAI"
+ Layout: wide (full-width columns for better organization)

TAB 1: BATCH EVALUATION

Purpose: Process large volumes of tickets from data/input/tickets.csv

Left Column Controls:
+ Input CSV text field (default: data/input/tickets.csv)
+ Cluster K slider (range 2-50, default 12)
+ Confidence Threshold slider (range 0.0-1.0, default 0.65)
+ Run button (primary blue style)

Right Column Results Display:
+ Success or error message display
+ Metrics cards showing:
  * Total Tickets Processed (count)
  * Sentiment Predictions Count
  * Intent Predictions Count
  * Reclassified Count (if any)
+ Detailed results table with columns:
  * Ticket ID
  * Sentiment
  * Sentiment Confidence
  * Intent
  * Intent Confidence
  * Status (OK, Low Conf, Reclassified)
  * Cluster Assignment
+ CSV download button for exporting results

Data Flow in Batch Tab:
+ User provides CSV path, cluster K, threshold configuration
+ Clicks "Run Batch Evaluation" button
+ Calls run_batch_workflow() with provided parameters
+ Workflow executes all batch processing nodes
+ Results displayed in interactive table format
+ User can download results as CSV file

TAB 2: SINGLE-TICKET DRAFTING

Purpose: Analyze individual tickets and generate multiple response options

Left Column Controls:
+ Input CSV text field (default: data/input/tickets.csv)
+ Ticket selector dropdown (populated from CSV loading)
+ Confidence Threshold slider (0.0-1.0 range)
+ Analyze & Draft button (primary style)

Right Column Results Display:
+ Fast Draft section (blue info box):
  * Title: "Fast Draft (60 words)"
  * Concise response option
+ Deep Draft section (blue info box):
  * Title: "Deep Draft (70-120 words)"
  * Comprehensive response option
+ Final Response section (green success box):
  * Title: "Return Final Response"
  * PII-redacted safe_draft (ready for customer)
+ Cluster Context section:
  * Title: "Cluster Context - Similar Tickets"
  * Expandable items showing similar tickets
  * Each expander displays ticket ID and customer text

Data Flow in Single-Ticket Tab:
+ User selects CSV file and target ticket
+ Clicks "Analyze & Draft" button
+ Calls run_single_ticket_workflow() with parameters
+ Workflow executes complete single-ticket processing path
+ All analysis and drafts displayed
+ Similar tickets shown in expandable sections

TAB 3: MODEL EVALUATION

Purpose: Assess trained model performance on test datasets

Left Column Controls:
+ Run Model Evaluation button (primary style)

Right Column Results Display:
+ Sentiment Model Metrics section (if available):
  * Accuracy value
  * F1-Score value
  * Precision value
  * Recall value
  * Sample count indicator
+ Intent Model Metrics section (if available):
  * Same four metrics as sentiment model
+ Model Comparison Table:
  * Columns: Model, Type, Accuracy, F1-Score, Precision, Recall
  * Rows: One per evaluated model
  * Supports sorting and filtering

Data Flow in Evaluation Tab:
+ User clicks "Run Model Evaluation" button
+ System loads models from ml/models/
+ System loads test data from data/evaluation_dataset/
+ Calls evaluate_all_models()
+ Results compiled and displayed in metrics format

SECTION 9: EXECUTION FLOW AND ENTRY POINTS
===========================================

STAGE 1: DATA PREPARATION AND MODEL TRAINING

Entry Point: Manual ML Pipeline Execution (Initial Setup)
Command: python ml/train_pipeline.py

Execution Flow:
+ Calls run_full_pipeline() with directory paths:
  * training_dir: data/raw/training_data/
  * evaluation_dir: data/evaluation_dataset/
  * output_dir: ml/models/

STEP 1 - Data Cleaning:
+ Loads sentiment raw training data from data/raw/training_data/
+ Calls clean_sentiment_dataset()
+ Saves cleaned data to data/processed/cleaned_sentiment_data.csv
+ Loads intent raw training data
+ Calls clean_intent_dataset()
+ Saves cleaned data to data/processed/cleaned_intent_data.csv

STEP 2 - Model Training:
+ Calls train_sentiment_model()
+ Generates and saves ml/models/sentiment_classifier.pkl
+ Generates and saves ml/models/tfidf_sentiment.pkl
+ Calls train_intent_model()
+ Generates and saves ml/models/intent_classifier.pkl
+ Generates and saves ml/models/tfidf_intent.pkl

STEP 3 - Model Evaluation:
+ Calls evaluate_all_models()
+ Tests models on data/evaluation_dataset/
+ Returns accuracy, precision, recall metrics

Files Created:
data/processed/
+ cleaned_sentiment_data.csv
+ cleaned_intent_data.csv

ml/models/
+ sentiment_classifier.pkl
+ tfidf_sentiment.pkl
+ intent_classifier.pkl
+ tfidf_intent.pkl
+ clustering_model.pkl

STAGE 2: BATCH WORKFLOW EXECUTION

Entry Point: Batch Processing via UI or Programmatic Call
Command (Programmatic): from workflow.workflow import run_batch_workflow
result = run_batch_workflow("data/input/tickets.csv", "batch_001", 0.65, 12)

Execution Flow:
+ Creates WorkflowState with batch configuration
+ Loads compiled batch workflow graph
+ Node 1 - load_clean_node: Reads CSV from data/input/tickets.csv, cleans text
+ Node 2 - sentiment_node: Applies sentiment classification
+ Node 3 - intent_node: Applies intent classification
+ Node 4 - routing_node: Identifies low-confidence predictions
+ Conditional: If low-confidence exist:
  * Node 5 - reclass_node: LLM reclassification
  * Proceeds to clustering_node
+ Else: Skips reclass_node
+ Node 6 - clustering_node: Groups tickets into clusters
+ Workflow completes

Return Structure: Dictionary with predictions and cluster assignments

STAGE 3: SINGLE-TICKET WORKFLOW EXECUTION

Entry Point: Single-Ticket Analysis via UI or Programmatic Call
Command (Programmatic): from workflow.workflow import run_single_ticket_workflow
result = run_single_ticket_workflow("data/input/tickets.csv", "T001", 0.65, 12)

Execution Flow:
+ Creates WorkflowState with single-ticket configuration
+ Ticket ID specified: "T001"
+ Loads compiled single-ticket workflow graph
+ Shared Nodes (1-6): Same as batch processing
+ Single-Ticket Specific Nodes:
  * Node 7 - draft_fast_node: Generates concise response
  * Node 8 - draft_deep_node: Generates comprehensive response
  * Node 9 - judge_node: Selects best response option
  * Node 10 - summary_node: Summarizes similar tickets
  * Node 11 - safety_node: Redacts PII from final response
+ Workflow completes

Return Structure: SingleTicketResult with complete analysis and four response options

STAGE 4: STREAMLIT UI EXECUTION

Entry Point: Launch Streamlit Application
Command: streamlit run main.py

Application Start:
+ Streamlit framework initializes
+ main() function executes
+ Page configuration applied
+ Custom styling loaded
+ Three tabs rendered
+ Application listening on http://localhost:8501

User Interaction in Batch Tab:
1. User navigates to "Batch Evaluation" tab
2. User enters CSV path (defaults to data/input/tickets.csv)
3. User adjusts cluster K slider
4. User adjusts confidence threshold slider
5. User clicks "Run Batch Evaluation" button
6. Button click triggers:
   + Generates unique run_id from timestamp
   + Calls run_batch_workflow()
   + Displays processing spinner
   + Stores result in session state
7. Results rendered:
   + Success message with ticket count
   + Metrics cards display
   + Results table with all predictions
   + CSV download button

User Interaction in Single-Ticket Tab:
1. User navigates to "Single-Ticket Drafting" tab
2. User enters CSV path
3. CSV loads and ticket dropdown populated
4. User selects target ticket from dropdown
5. User adjusts confidence threshold
6. User clicks "Analyze & Draft" button
7. System execution:
   + Calls run_single_ticket_workflow()
   + Displays processing spinner
8. Results rendered:
   + Fast draft (blue box)
   + Deep draft (blue box)
   + Final response (green box, PII-redacted)
   + Similar tickets expandable section

SECTION 10: OUTPUT AND RESULTS
===============================

OUTPUT FROM BATCH WORKFLOW

Result Dictionary Structure:
+ "error": Boolean indicating critical errors
+ "total_tickets": Integer count processed
+ "sentiment_predictions": List of predictions with labels and confidence
+ "intent_predictions": List of predictions with labels and confidence
+ "reclass_predictions": List (empty if no reclassification)
+ "routing_decision": Decision object with low-confidence identifiers
+ "clusters": Cluster mappings {ticket_id: cluster_id}

Batch CSV Export Format:
Columns: Ticket ID, Sentiment, Sentiment Conf, Intent, Intent Conf, Status, Cluster
Status Values: "OK" (above threshold), "Low Conf" (below threshold), "Reclassified" (LLM-upgraded)

OUTPUT FROM SINGLE-TICKET WORKFLOW

Result Structure: SingleTicketResult
+ "ticket_id": String identifier
+ "customer_text": Original customer message
+ "sentiment_label": Predicted sentiment value
+ "sentiment_confidence": Sentiment confidence score
+ "intent_label": Predicted intent category
+ "intent_confidence": Intent confidence score
+ "reclass_label": LLM reclassified intent (or None)
+ "reclass_confidence": Reclassification confidence (or None)
+ "cluster_id": Assigned cluster number
+ "fast_draft": Concise response option
+ "deep_draft": Comprehensive response option
+ "judged_draft": LLM-selected response
+ "safe_draft": Final PII-redacted response
+ "cluster_summary": Summary of similar issues
+ "cluster_context": List of similar tickets with details

Display Format in Streamlit:
+ Fast Draft: Blue info box with 60-word response
+ Deep Draft: Blue info box with 70-120 word response
+ Final Response: Green success box with safe_draft
+ Similar Tickets: Expandable list showing related issues

OUTPUT FROM MODEL EVALUATION

Result Dictionary:
+ "status": "success" or "error"
+ "models": Dictionary containing results for each model
  - "sentiment": Sentiment model metrics
    * status, model_type, samples, accuracy, f1_score, precision, recall
  - "intent": Intent model metrics
    * status, model_type, samples, accuracy, f1_score, precision, recall

Metrics Displayed in UI:
Sentiment Model Metrics:
+ Accuracy: Float value
+ F1-Score: Float value
+ Precision: Float value
+ Recall: Float value
+ Sample count

Intent Model Metrics:
+ Same four metrics as sentiment

Model Comparison Table:
Columns: Model, Type, Accuracy, F1-Score, Precision, Recall
Rows: One per evaluated model

===== END OF COMPREHENSIVE DOCUMENTATION =====
