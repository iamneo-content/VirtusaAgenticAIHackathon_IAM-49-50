"""Data cleaning for sentiment training dataset."""

import pandas as pd
import numpy as np
import re


def clean_sentiment_dataset(csv_path: str) -> pd.DataFrame:
    """Clean sentiment training dataset.

    Steps:
    1. Load CSV
    2. Remove rows with missing sentiment labels or empty text
    3. Remove duplicate rows (DUP_ prefix indicates duplicates)
    4. Validate label values (must be: positive, negative, neutral)
    5. Remove extra punctuation sequences (!!!, ???, etc.)
    6. Normalize whitespace (multiple spaces → single space)
    7. Remove very short texts (< 3 characters)

    Args:
        csv_path: Path to raw sentiment training CSV

    Returns:
        Cleaned DataFrame
    """
    df = pd.read_csv(csv_path)

    # Remove rows with missing labels
    df = df.dropna(subset=['sentiment_label'])

    # Remove rows with empty or whitespace-only customer_text
    df = df[df['customer_text'].notna()]
    df = df[df['customer_text'].str.strip().str.len() > 0]

    # Remove duplicate rows based on sample_id (DUP_ prefix indicates duplicates)
    df = df[~df['sample_id'].str.startswith('DUP_')]

    # Validate labels
    valid_labels = {'positive', 'negative', 'neutral'}
    df = df[df['sentiment_label'].isin(valid_labels)]

    # Clean text: remove extra punctuation, normalize whitespace
    df['customer_text'] = df['customer_text'].apply(
        lambda text: re.sub(r'\s+', ' ', re.sub(r'([!?.])\1{2,}', r'\1', str(text).strip()))
    )

    # Remove very short texts
    df = df[df['customer_text'].str.len() >= 3]

    # Reset index
    df = df.reset_index(drop=True)

    return df
