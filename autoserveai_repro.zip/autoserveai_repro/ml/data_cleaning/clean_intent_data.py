"""Data cleaning for intent training dataset."""

import pandas as pd
import numpy as np
import re


def clean_intent_dataset(csv_path: str) -> pd.DataFrame:
    """Clean intent training dataset.

    Steps:
    1. Load CSV
    2. Remove rows with missing intent labels or empty text
    3. Remove duplicate rows (DUP_ prefix indicates duplicates)
    4. Validate label values (supported intent categories)
    5. Remove extra punctuation sequences (!!!, ???, etc.)
    6. Normalize whitespace (multiple spaces → single space)
    7. Remove very short texts (< 3 characters)

    Args:
        csv_path: Path to raw intent training CSV

    Returns:
        Cleaned DataFrame
    """
    df = pd.read_csv(csv_path)

    # Remove rows with missing labels
    df = df.dropna(subset=['intent_label'])

    # Remove rows with empty or whitespace-only customer_text
    df = df[df['customer_text'].notna()]
    df = df[df['customer_text'].str.strip().str.len() > 0]

    # Remove duplicate rows based on sample_id (DUP_ prefix indicates duplicates)
    df = df[~df['sample_id'].str.startswith('DUP_')]

    # Valid intent labels (12 categories)
    valid_labels = {
        'technical_problem', 'billing_issue', 'order_issue', 'account_help',
        'feature_request', 'refund_request', 'login_issue', 'subscription_change',
        'verification_issue', 'api_access', 'sso_support', 'data_export'
    }
    df = df[df['intent_label'].isin(valid_labels)]

    # Clean text: remove extra punctuation, normalize whitespace
    df['customer_text'] = df['customer_text'].apply(
        lambda text: re.sub(r'\s+', ' ', re.sub(r'([!?.])\1{2,}', r'\1', str(text).strip()))
    )

    # Remove very short texts
    df = df[df['customer_text'].str.len() >= 3]

    # Reset index
    df = df.reset_index(drop=True)

    return df
