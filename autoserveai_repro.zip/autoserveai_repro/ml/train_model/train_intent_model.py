"""Intent classification model training using LogisticRegression."""

import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, classification_report
import pickle
import os


def train_intent_model(training_csv: str, output_dir: str) -> dict:
    """Train LogisticRegression intent classification model.

    Args:
        training_csv: Path to cleaned intent training CSV
        output_dir: Directory to save model files (.pkl)

    Returns:
        Dictionary with training metrics
    """
    # Load training data
    df = pd.read_csv(training_csv)

    # Prepare features and labels
    X = df['customer_text'].fillna('')
    y = df['intent_label']

    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    # TF-IDF vectorization
    tfidf = TfidfVectorizer(max_features=5000, ngram_range=(1, 2), min_df=2)
    X_train_tfidf = tfidf.fit_transform(X_train)
    X_test_tfidf = tfidf.transform(X_test)

    # Train LogisticRegression model
    model = LogisticRegression(
        max_iter=1000,
        random_state=42,
        solver='lbfgs'
    )
    model.fit(X_train_tfidf, y_train)

    # Evaluate
    y_pred_train = model.predict(X_train_tfidf)
    y_pred_test = model.predict(X_test_tfidf)

    train_accuracy = accuracy_score(y_train, y_pred_train)
    test_accuracy = accuracy_score(y_test, y_pred_test)
    f1 = f1_score(y_test, y_pred_test, average='weighted')

    # Save model and vectorizer
    os.makedirs(output_dir, exist_ok=True)
    with open(os.path.join(output_dir, 'intent_lr.pkl'), 'wb') as f:
        pickle.dump(model, f)
    with open(os.path.join(output_dir, 'tfidf_intent.pkl'), 'wb') as f:
        pickle.dump(tfidf, f)

    metrics = {
        "status": "success",
        "train_accuracy": float(train_accuracy),
        "test_accuracy": float(test_accuracy),
        "f1_score": float(f1),
        "accuracy": float(test_accuracy)
    }

    return metrics
