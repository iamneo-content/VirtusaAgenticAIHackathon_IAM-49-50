"""Model evaluation on test datasets."""

import pandas as pd
import os
import pickle
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score


def evaluate_all_models(evaluation_dir: str, model_dir: str) -> dict:
    """Evaluate both sentiment and intent models.

    Args:
        evaluation_dir: Directory containing evaluation CSV files
        model_dir: Directory containing trained model files

    Returns:
        Dictionary with evaluation results for both models
    """
    results = {
        "status": "success",
        "models": {}
    }

    # Evaluate Sentiment Model
    try:
        sentiment_eval_csv = os.path.join(evaluation_dir, 'sentiment_evaluation.csv')
        if os.path.exists(sentiment_eval_csv):
            sentiment_results = _evaluate_sentiment_model(
                sentiment_eval_csv,
                model_dir
            )
            results["models"]["sentiment"] = sentiment_results
        else:
            results["models"]["sentiment"] = {"status": "skipped", "reason": "evaluation file not found"}
    except Exception as e:
        results["models"]["sentiment"] = {"status": "failed", "error": str(e)}

    # Evaluate Intent Model
    try:
        intent_eval_csv = os.path.join(evaluation_dir, 'intent_evaluation.csv')
        if os.path.exists(intent_eval_csv):
            intent_results = _evaluate_intent_model(
                intent_eval_csv,
                model_dir
            )
            results["models"]["intent"] = intent_results
        else:
            results["models"]["intent"] = {"status": "skipped", "reason": "evaluation file not found"}
    except Exception as e:
        results["models"]["intent"] = {"status": "failed", "error": str(e)}

    return results


def _evaluate_sentiment_model(eval_csv: str, model_dir: str) -> dict:
    """Evaluate sentiment SVM model."""
    df = pd.read_csv(eval_csv)

    # Load model and vectorizer
    with open(os.path.join(model_dir, 'sentiment_svm.pkl'), 'rb') as f:
        model = pickle.load(f)
    with open(os.path.join(model_dir, 'tfidf_sentiment.pkl'), 'rb') as f:
        tfidf = pickle.load(f)

    # Prepare test data
    X = df['customer_text'].fillna('')
    y_true = df['true_sentiment_label']

    # Transform and predict
    X_tfidf = tfidf.transform(X)
    y_pred = model.predict(X_tfidf)

    # Calculate metrics
    accuracy = accuracy_score(y_true, y_pred)
    f1 = f1_score(y_true, y_pred, average='weighted')
    precision = precision_score(y_true, y_pred, average='weighted', zero_division=0)
    recall = recall_score(y_true, y_pred, average='weighted', zero_division=0)

    return {
        "status": "success",
        "model_type": "SVM",
        "samples": len(df),
        "accuracy": float(accuracy),
        "f1_score": float(f1),
        "precision": float(precision),
        "recall": float(recall)
    }


def _evaluate_intent_model(eval_csv: str, model_dir: str) -> dict:
    """Evaluate intent LogisticRegression model."""
    df = pd.read_csv(eval_csv)

    # Load model and vectorizer
    with open(os.path.join(model_dir, 'intent_lr.pkl'), 'rb') as f:
        model = pickle.load(f)
    with open(os.path.join(model_dir, 'tfidf_intent.pkl'), 'rb') as f:
        tfidf = pickle.load(f)

    # Prepare test data
    X = df['customer_text'].fillna('')
    y_true = df['true_intent_label']

    # Transform and predict
    X_tfidf = tfidf.transform(X)
    y_pred = model.predict(X_tfidf)

    # Calculate metrics
    accuracy = accuracy_score(y_true, y_pred)
    f1 = f1_score(y_true, y_pred, average='weighted')
    precision = precision_score(y_true, y_pred, average='weighted', zero_division=0)
    recall = recall_score(y_true, y_pred, average='weighted', zero_division=0)

    return {
        "status": "success",
        "model_type": "LogisticRegression",
        "samples": len(df),
        "accuracy": float(accuracy),
        "f1_score": float(f1),
        "precision": float(precision),
        "recall": float(recall)
    }
