"""ML module for AutoServeAI."""
