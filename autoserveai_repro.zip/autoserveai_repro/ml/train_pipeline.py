"""ML training pipeline orchestrator for sentiment and intent models."""

from train_model import train_sentiment_model, train_intent_model
from evaluation import evaluate_all_models
from data_cleaning import clean_sentiment_dataset, clean_intent_dataset
import os


def run_full_pipeline(
    training_dir: str,
    evaluation_dir: str,
    output_dir: str,
    processed_dir: str = None
) -> dict:
    """Run complete ML training pipeline.

    Steps:
    1. Clean training datasets (remove NaN, duplicates, invalid entries)
    2. Train both ML models (Sentiment SVM + Intent LogisticRegression)
    3. Evaluate models on evaluation datasets
    4. Save results and metrics

    Args:
        training_dir: Directory containing raw training CSV files
        evaluation_dir: Directory containing evaluation CSV files
        output_dir: Directory to save trained models (.pkl files)
        processed_dir: Optional directory to save cleaned training data

    Returns:
        Dictionary with pipeline results and metrics
    """
    results = {
        "status": "started",
        "steps": {}
    }

    os.makedirs(output_dir, exist_ok=True)
    if processed_dir:
        os.makedirs(processed_dir, exist_ok=True)

    print("\n=== STEP 1: DATA CLEANING ===")
    try:
        sentiment_raw = f"{training_dir}/sentiment_training.csv"
        sentiment_clean = clean_sentiment_dataset(sentiment_raw)
        if processed_dir:
            sentiment_clean.to_csv(f"{processed_dir}/sentiment_training_clean.csv", index=False)
        print(f"✓ Sentiment training data cleaned: {len(sentiment_clean)} samples")
        results["steps"]["cleaning_sentiment"] = {"status": "success", "samples": len(sentiment_clean)}
    except Exception as e:
        print(f"✗ Sentiment data cleaning failed: {str(e)}")
        results["steps"]["cleaning_sentiment"] = {"status": "failed", "error": str(e)}
        return results

    try:
        intent_raw = f"{training_dir}/intent_training.csv"
        intent_clean = clean_intent_dataset(intent_raw)
        if processed_dir:
            intent_clean.to_csv(f"{processed_dir}/intent_training_clean.csv", index=False)
        print(f"✓ Intent training data cleaned: {len(intent_clean)} samples")
        results["steps"]["cleaning_intent"] = {"status": "success", "samples": len(intent_clean)}
    except Exception as e:
        print(f"✗ Intent data cleaning failed: {str(e)}")
        results["steps"]["cleaning_intent"] = {"status": "failed", "error": str(e)}
        return results

    print("\n=== STEP 2: MODEL TRAINING ===")
    try:
        sentiment_metrics = train_sentiment_model(
            f"{processed_dir or training_dir}/sentiment_training_clean.csv",
            output_dir
        )
        print(f"✓ Sentiment SVM model trained")
        print(f"  Accuracy: {sentiment_metrics.get('accuracy', 'N/A')}")
        print(f"  F1-Score: {sentiment_metrics.get('f1_score', 'N/A')}")
        results["steps"]["training_sentiment"] = sentiment_metrics
    except Exception as e:
        print(f"✗ Sentiment model training failed: {str(e)}")
        results["steps"]["training_sentiment"] = {"status": "failed", "error": str(e)}
        return results

    try:
        intent_metrics = train_intent_model(
            f"{processed_dir or training_dir}/intent_training_clean.csv",
            output_dir
        )
        print(f"✓ Intent LogisticRegression model trained")
        print(f"  Accuracy: {intent_metrics.get('accuracy', 'N/A')}")
        print(f"  F1-Score: {intent_metrics.get('f1_score', 'N/A')}")
        results["steps"]["training_intent"] = intent_metrics
    except Exception as e:
        print(f"✗ Intent model training failed: {str(e)}")
        results["steps"]["training_intent"] = {"status": "failed", "error": str(e)}
        return results

    print("\n=== STEP 3: MODEL EVALUATION ===")
    try:
        eval_results = evaluate_all_models(evaluation_dir, output_dir)
        print(f"✓ Model evaluation completed")
        for model_name, metrics in eval_results.get("models", {}).items():
            if metrics.get("status") == "success":
                print(f"  {model_name}:")
                print(f"    Accuracy: {metrics.get('accuracy', 'N/A')}")
                print(f"    F1-Score: {metrics.get('f1_score', 'N/A')}")
        results["steps"]["evaluation"] = eval_results
    except Exception as e:
        print(f"✗ Model evaluation failed: {str(e)}")
        results["steps"]["evaluation"] = {"status": "failed", "error": str(e)}
        return results

    print("\n=== PIPELINE COMPLETE ===")
    results["status"] = "success"
    return results


if __name__ == "__main__":
    import os
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    training_data_dir = os.path.join(base_dir, "data/training_dataset")
    evaluation_data_dir = os.path.join(base_dir, "data/evaluation_dataset")
    model_output_dir = os.path.join(base_dir, "ml/models")
    processed_data_dir = os.path.join(base_dir, "data/processed")

    pipeline_results = run_full_pipeline(
        training_dir=training_data_dir,
        evaluation_dir=evaluation_data_dir,
        output_dir=model_output_dir,
        processed_dir=processed_data_dir
    )

    print("\n=== FINAL RESULTS ===")
    print(f"Pipeline Status: {pipeline_results['status']}")
    for step, details in pipeline_results['steps'].items():
        print(f"{step}: {details.get('status', 'unknown')}")
