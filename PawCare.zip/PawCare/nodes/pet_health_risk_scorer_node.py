"""Pet Health Risk Scorer Node - ML predictions."""

from state import PetCareState
from agents.pet_health_risk_scorer_ml import PetHealthRiskScorerMLAgent


def pet_health_risk_scorer_node(state: PetCareState) -> PetCareState:
    """Predict pet health risk score using ML model."""
    try:
        agent = PetHealthRiskScorerMLAgent()

        extracted_profile = state.get("extracted_profile", {})

        if not extracted_profile:
            state["error_messages"].append("No extracted profile found for health risk scoring")
            state["error_occurred"] = True
            return state

        result = agent.predict_health_risk(extracted_profile)
        state["health_risk_score"] = result.get("health_risk_score", 0.0)
        return state
    except Exception as e:
        state["error_messages"].append(f"Pet health risk scorer error: {str(e)}")
        state["error_occurred"] = True
        return state
