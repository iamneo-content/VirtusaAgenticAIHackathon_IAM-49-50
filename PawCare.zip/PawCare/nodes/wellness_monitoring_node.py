"""Wellness Monitoring Node - CRITICAL path."""

from state import PetCareState
from agents.wellness_monitoring_llm import WellnessMonitoringLLMAgent


def wellness_monitoring_node(state: PetCareState, client) -> PetCareState:
    """Generate wellness monitoring plan."""
    try:
        agent = WellnessMonitoringLLMAgent(client)
        profile = {
            "pet_species": state.get("pet_species", ""),
            "age_years": state.get("age_years", 0),
            "known_conditions": state.get("known_conditions", []),
        }
        ml_results = {
            "health_risk_score": state.get("health_risk_score", 0.0),
        }
        result = agent.generate_monitoring_plan(profile, ml_results)
        state["wellness_monitoring_output"] = result.get("wellness_monitoring", {})
        return state
    except Exception as e:
        state["error_messages"].append(f"Wellness monitoring error: {str(e)}")
        state["error_occurred"] = True
        return state
