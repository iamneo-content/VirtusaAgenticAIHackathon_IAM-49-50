"""Output Aggregator Node - Aggregates outputs based on path taken."""

from state import PetCareState


def output_aggregator_node(state: PetCareState) -> PetCareState:
    """Aggregate outputs based on care path."""
    path = state.get("path_taken", "UNKNOWN")

    if path == "CRITICAL_CARE_PATH":
        aggregated = {
            "path": path,
            "health_risk_analysis": state.get("health_risk_analysis_output", {}),
            "emergency_preparedness": state.get("emergency_prep_output", {}),
            "nutrition_plan": state.get("nutrition_critical_output", {}),
            "behavioral_coaching": state.get("behavioral_coaching_output", {}),
            "wellness_monitoring": state.get("wellness_monitoring_output", {}),
        }
    elif path == "PREVENTIVE_CARE_PATH":
        aggregated = {
            "path": path,
            "health_assessment": state.get("health_assessment_output", {}),
            "nutrition_guide": state.get("nutrition_preventive_output", {}),
            "wellness_tracking": state.get("wellness_tracking_output", {}),
        }
    else:  # WELLNESS_PATH
        aggregated = {
            "path": path,
            "wellness_optimization": state.get("wellness_optimization_output", {}),
            "nutrition_enhancement": state.get("nutrition_wellness_output", {}),
            "lifestyle_enrichment": state.get("lifestyle_enrichment_output", {}),
        }

    state["aggregated_output"] = aggregated
    state["processing_complete"] = True
    return state
