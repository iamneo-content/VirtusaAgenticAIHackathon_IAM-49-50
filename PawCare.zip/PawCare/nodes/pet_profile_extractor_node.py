"""Pet Profile Extractor Node - extracts structured pet profile from free text."""

from typing import Dict, Any
from state import PetCareState
from agents.pet_profile_extractor_llm import PetProfileExtractorLLMAgent


def pet_profile_extractor_node(state: PetCareState, client) -> PetCareState:
    """Extract structured pet profile using LLM."""
    try:
        agent = PetProfileExtractorLLMAgent(client)
        raw_inputs = {
            "about_pet": state.get("about_pet", ""),
            "daily_routine": state.get("daily_routine", ""),
            "health_concerns": state.get("health_concerns", ""),
        }
        result = agent.extract_pet_profile(raw_inputs)
        if result.get("status") == "success":
            profile = result.get("extracted_profile", {})
            state["extracted_profile"] = profile
            state["profile_extraction_complete"] = True
            state["pet_species"] = profile.get("pet_species", "")
            state["breed"] = profile.get("breed", "")
            state["age_years"] = profile.get("age_years", 0)
            state["weight_status"] = profile.get("weight_status", "")
            state["sex"] = profile.get("sex", "")
            state["known_conditions"] = profile.get("known_conditions", [])
            state["past_surgeries"] = profile.get("past_surgeries", [])
            state["allergies_known"] = profile.get("allergies_known", [])
            state["medications_current"] = profile.get("medications_current", [])
            state["living_situation"] = profile.get("living_situation", "")
            state["exercise_level"] = profile.get("exercise_level", "")
            state["diet_type"] = profile.get("diet_type", "")
            state["diet_quality"] = profile.get("diet_quality", "")
            state["behavioral_issues"] = profile.get("behavioral_issues", [])
            state["owner_experience"] = profile.get("owner_experience", "")
            state["vet_access"] = profile.get("vet_access", "")
            state["owner_commitment"] = profile.get("owner_commitment", "")
        else:
            state["error_messages"].append("Pet profile extraction failed")
            state["error_occurred"] = True
        return state
    except Exception as e:
        state["error_messages"].append(f"Pet profile extractor node error: {str(e)}")
        state["error_occurred"] = True
        return state
