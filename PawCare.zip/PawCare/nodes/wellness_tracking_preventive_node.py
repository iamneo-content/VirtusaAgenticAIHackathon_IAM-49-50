"""Wellness Tracking Preventive Node - PREVENTIVE path."""

from state import PetCareState
from agents.wellness_tracking_preventive_llm import WellnessTrackingPreventiveLLMAgent


def wellness_tracking_preventive_node(state: PetCareState, client) -> PetCareState:
    """Generate preventive wellness tracking plan."""
    try:
        agent = WellnessTrackingPreventiveLLMAgent(client)
        profile = {
            "pet_species": state.get("pet_species", ""),
            "age_years": state.get("age_years", 0),
            "exercise_level": state.get("exercise_level", ""),
        }
        ml_results = {
            "health_risk_score": state.get("health_risk_score", 0.0),
        }
        result = agent.generate_tracking_plan(profile, ml_results)
        state["wellness_tracking_output"] = result.get("wellness_tracking", {})
        return state
    except Exception as e:
        state["error_messages"].append(f"Wellness tracking error: {str(e)}")
        state["error_occurred"] = True
        return state
