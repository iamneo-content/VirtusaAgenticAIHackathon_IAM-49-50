"""Emergency Preparedness Node - CRITICAL path."""

from state import PetCareState
from agents.emergency_preparedness_llm import EmergencyPreparednessLLMAgent


def emergency_preparedness_node(state: PetCareState, client) -> PetCareState:
    """Generate emergency preparedness plan."""
    try:
        agent = EmergencyPreparednessLLMAgent(client)
        profile = {
            "pet_species": state.get("pet_species", ""),
            "breed": state.get("breed", ""),
            "age_years": state.get("age_years", 0),
            "known_conditions": state.get("known_conditions", []),
            "vet_access": state.get("vet_access", ""),
        }
        health_analysis = state.get("health_risk_analysis_output", {})
        result = agent.generate_emergency_plan(profile, health_analysis)
        state["emergency_prep_output"] = result.get("emergency_preparedness", {})
        return state
    except Exception as e:
        state["error_messages"].append(f"Emergency preparedness error: {str(e)}")
        state["error_occurred"] = True
        return state
