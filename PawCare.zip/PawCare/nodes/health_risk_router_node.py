"""Health Risk Router Node - pure logic node for path routing."""

from state import PetCareState


def health_risk_router_node(state: PetCareState) -> PetCareState:
    """Route to CRITICAL/PREVENTIVE/WELLNESS path based on health risk score.

    Uses simple thresholding on health risk score since training data is balanced
    across all three path categories.

    Routing Decision:
    - CRITICAL_CARE_PATH: health_risk > 0.6 (high-risk pets)
    - PREVENTIVE_CARE_PATH: 0.3 < health_risk ≤ 0.6 (moderate risk)
    - WELLNESS_PATH: health_risk ≤ 0.3 (low-risk pets)
    """
    health_risk = state.get("health_risk_score", 0.5)

    if health_risk > 0.6:
        state["path_taken"] = "CRITICAL_CARE_PATH"
    elif health_risk > 0.3:
        state["path_taken"] = "PREVENTIVE_CARE_PATH"
    else:
        state["path_taken"] = "WELLNESS_PATH"

    return state
