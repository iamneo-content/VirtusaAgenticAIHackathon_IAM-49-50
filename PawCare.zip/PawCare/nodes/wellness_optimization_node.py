"""Wellness Optimization Node - WELLNESS path."""

from state import PetCareState
from agents.wellness_optimization_llm import WellnessOptimizationLLMAgent


def wellness_optimization_node(state: PetCareState, client) -> PetCareState:
    """Generate wellness optimization plan."""
    try:
        agent = WellnessOptimizationLLMAgent(client)
        profile = {
            "pet_species": state.get("pet_species", ""),
            "age_years": state.get("age_years", 0),
            "exercise_level": state.get("exercise_level", ""),
            "living_situation": state.get("living_situation", ""),
        }
        ml_results = {
            "health_risk_score": state.get("health_risk_score", 0.0),
        }
        result = agent.generate_optimization_plan(profile, ml_results)
        state["wellness_optimization_output"] = result.get("wellness_optimization", {})
        return state
    except Exception as e:
        state["error_messages"].append(f"Wellness optimization error: {str(e)}")
        state["error_occurred"] = True
        return state
