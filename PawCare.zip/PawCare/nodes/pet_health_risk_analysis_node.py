"""Pet Health Risk Analysis Node - CRITICAL path."""

from state import PetCareState
from agents.pet_health_risk_analysis_llm import PetHealthRiskAnalysisLLMAgent


def pet_health_risk_analysis_node(state: PetCareState, client) -> PetCareState:
    """Generate health risk analysis."""
    try:
        agent = PetHealthRiskAnalysisLLMAgent(client)
        profile = {
            "pet_species": state.get("pet_species", ""),
            "breed": state.get("breed", ""),
            "age_years": state.get("age_years", 0),
            "known_conditions": state.get("known_conditions", []),
            "allergies_known": state.get("allergies_known", []),
        }
        ml_results = {
            "health_risk_score": state.get("health_risk_score", 0.0),
            "care_capability_score": state.get("care_capability_score", 0.0),
        }
        result = agent.generate_risk_analysis(profile, ml_results)
        state["health_risk_analysis_output"] = result.get("health_risk_analysis", {})
        return state
    except Exception as e:
        state["error_messages"].append(f"Pet health risk analysis error: {str(e)}")
        state["error_occurred"] = True
        return state
