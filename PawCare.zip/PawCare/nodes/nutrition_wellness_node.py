"""Nutrition Wellness Node - WELLNESS path."""

from state import PetCareState
from agents.nutrition_wellness_llm import NutritionWellnessLLMAgent


def nutrition_wellness_node(state: PetCareState, client) -> PetCareState:
    """Generate nutrition wellness enhancement."""
    try:
        agent = NutritionWellnessLLMAgent(client)
        profile = {
            "pet_species": state.get("pet_species", ""),
            "age_years": state.get("age_years", 0),
            "diet_type": state.get("diet_type", ""),
        }
        ml_results = {
            "health_risk_score": state.get("health_risk_score", 0.0),
        }
        result = agent.generate_nutrition_enhancement(profile, ml_results)
        state["nutrition_wellness_output"] = result.get("nutrition_enhancement", {})
        return state
    except Exception as e:
        state["error_messages"].append(f"Nutrition wellness error: {str(e)}")
        state["error_occurred"] = True
        return state
