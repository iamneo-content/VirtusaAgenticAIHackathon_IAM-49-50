"""Behavioral Coaching Node - CRITICAL path."""

from state import PetCareState
from agents.behavioral_coaching_llm import BehavioralCoachingLLMAgent


def behavioral_coaching_node(state: PetCareState, client) -> PetCareState:
    """Generate behavioral coaching plan."""
    try:
        agent = BehavioralCoachingLLMAgent(client)
        profile = {
            "pet_species": state.get("pet_species", ""),
            "breed": state.get("breed", ""),
            "behavioral_issues": state.get("behavioral_issues", []),
            "known_conditions": state.get("known_conditions", []),
        }
        result = agent.generate_behavior_coaching(profile)
        state["behavioral_coaching_output"] = result.get("behavioral_coaching", {})
        return state
    except Exception as e:
        state["error_messages"].append(f"Behavioral coaching error: {str(e)}")
        state["error_occurred"] = True
        return state
