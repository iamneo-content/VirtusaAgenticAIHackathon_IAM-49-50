"""Health Assessment Preventive Node - PREVENTIVE path."""

from state import PetCareState
from agents.health_assessment_preventive_llm import HealthAssessmentPreventiveLLMAgent


def health_assessment_preventive_node(state: PetCareState, client) -> PetCareState:
    """Generate preventive health assessment."""
    try:
        agent = HealthAssessmentPreventiveLLMAgent(client)
        profile = {
            "pet_species": state.get("pet_species", ""),
            "breed": state.get("breed", ""),
            "age_years": state.get("age_years", 0),
            "known_conditions": state.get("known_conditions", []),
        }
        ml_results = {
            "health_risk_score": state.get("health_risk_score", 0.0),
        }
        result = agent.generate_health_assessment(profile, ml_results)
        state["health_assessment_output"] = result.get("health_assessment", {})
        return state
    except Exception as e:
        state["error_messages"].append(f"Health assessment error: {str(e)}")
        state["error_occurred"] = True
        return state
