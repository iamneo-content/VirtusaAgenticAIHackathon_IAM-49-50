"""Input Validator Node - validates raw user inputs."""

from typing import Dict, Any
from state import PetCareState
from agents.input_validator_agent import InputValidatorAgent


def input_validator_node(state: PetCareState) -> PetCareState:
    """
    Validate all 3 input text fields.

    Args:
        state: Current PetCareState

    Returns:
        Updated state with validation results
    """
    try:
        agent = InputValidatorAgent()

        raw_inputs = {
            "about_pet": state.get("about_pet", ""),
            "daily_routine": state.get("daily_routine", ""),
            "health_concerns": state.get("health_concerns", ""),
        }

        result = agent.validate_inputs(raw_inputs)

        state["validation_errors"] = result.get("validation_errors", [])
        state["parsing_complete"] = result.get("is_valid", False)

        if not result.get("is_valid", False):
            state["error_occurred"] = True
            state["error_messages"].extend(result.get("validation_errors", []))

        return state

    except Exception as e:
        state["error_messages"].append(f"Input validator node error: {str(e)}")
        state["error_occurred"] = True
        return state
