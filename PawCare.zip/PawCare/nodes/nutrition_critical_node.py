"""Nutrition Critical Node - CRITICAL path."""

from state import PetCareState
from agents.nutrition_critical_llm import NutritionCriticalLLMAgent


def nutrition_critical_node(state: PetCareState, client) -> PetCareState:
    """Generate nutrition optimization plan."""
    try:
        agent = NutritionCriticalLLMAgent(client)
        profile = {
            "pet_species": state.get("pet_species", ""),
            "weight_status": state.get("weight_status", ""),
            "diet_type": state.get("diet_type", ""),
            "known_conditions": state.get("known_conditions", []),
            "allergies_known": state.get("allergies_known", []),
        }
        result = agent.generate_nutrition_plan(profile)
        state["nutrition_critical_output"] = result.get("nutrition_plan", {})
        return state
    except Exception as e:
        state["error_messages"].append(f"Nutrition critical error: {str(e)}")
        state["error_occurred"] = True
        return state
