"""Owner Care Capability Node - ML predictions."""

from state import PetCareState
from agents.owner_care_capability_ml import OwnerCareCapabilityMLAgent


def owner_care_capability_node(state: PetCareState) -> PetCareState:
    """Predict owner care capability using ML model."""
    try:
        agent = OwnerCareCapabilityMLAgent()

        extracted_profile = state.get("extracted_profile", {})

        if not extracted_profile:
            state["error_messages"].append("No extracted profile found for care capability scoring")
            state["error_occurred"] = True
            return state

        result = agent.predict_capability(extracted_profile)
        state["care_capability_score"] = result.get("care_capability_score", 0.0)
        return state
    except Exception as e:
        state["error_messages"].append(f"Owner care capability error: {str(e)}")
        state["error_occurred"] = True
        return state
