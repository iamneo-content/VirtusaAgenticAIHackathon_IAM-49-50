"""Lifestyle Enrichment Node - WELLNESS path."""

from state import PetCareState
from agents.lifestyle_enrichment_llm import LifestyleEnrichmentLLMAgent


def lifestyle_enrichment_node(state: PetCareState, client) -> PetCareState:
    """Generate lifestyle enrichment plan."""
    try:
        agent = LifestyleEnrichmentLLMAgent(client)
        profile = {
            "pet_species": state.get("pet_species", ""),
            "age_years": state.get("age_years", 0),
            "living_situation": state.get("living_situation", ""),
            "exercise_level": state.get("exercise_level", ""),
        }
        ml_results = {
            "health_risk_score": state.get("health_risk_score", 0.0),
        }
        result = agent.generate_enrichment_plan(profile, ml_results)
        state["lifestyle_enrichment_output"] = result.get("lifestyle_enrichment", {})
        return state
    except Exception as e:
        state["error_messages"].append(f"Lifestyle enrichment error: {str(e)}")
        state["error_occurred"] = True
        return state
