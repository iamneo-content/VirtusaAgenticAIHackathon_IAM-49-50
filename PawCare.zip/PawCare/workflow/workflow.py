"""Workflow metadata and routing utilities for PawCare+.

Note: Main workflow orchestration is in graph.py
This module provides additional metadata utilities that complement graph.py
"""

from typing import Dict, Any


def get_routing_logic() -> Dict[str, Any]:
    """Get the routing logic rules for path selection.

    Returns:
        Dictionary describing routing thresholds and paths
    """
    return {
        "routing_field": "health_risk_score",
        "routing_type": "conditional_edges",
        "paths": {
            "CRITICAL_CARE_PATH": {
                "description": "Critical health issues requiring immediate comprehensive intervention",
                "condition": "health_risk_score > 0.6",
                "execution_strategy": "sequential_with_all_agents",
                "token_budget": 5000,
                "nodes_count": 11,
            },
            "PREVENTIVE_CARE_PATH": {
                "description": "Moderate health risks requiring preventive measures",
                "condition": "0.3 <= health_risk_score <= 0.6",
                "execution_strategy": "sequential_optimized",
                "token_budget": 2000,
                "nodes_count": 6,
            },
            "WELLNESS_PATH": {
                "description": "Healthy pet with focus on wellness optimization",
                "condition": "health_risk_score < 0.3",
                "execution_strategy": "sequential_fast",
                "token_budget": 1500,
                "nodes_count": 6,
            },
        },
    }


def get_parallel_execution_info() -> Dict[str, Any]:
    """Get information about parallel execution opportunities.

    Returns:
        Dictionary describing which nodes can run in parallel
    """
    return {
        "parallel_stages": [
            {
                "stage": "ML Prediction",
                "nodes": ["pet_health_risk_scorer", "owner_care_capability"],
                "dependencies": ["health_risk_router"],
                "description": "Both ML models run in parallel, results merged before routing",
            },
        ],
        "sequential_stages": [
            "Input validation and profile extraction",
            "ML prediction (parallel internally)",
            "Path routing",
            "Path-specific LLM agent execution",
            "Output aggregation",
        ],
    }


def get_token_budget_info() -> Dict[str, Any]:
    """Get token budget breakdown for different paths.

    Returns:
        Dictionary with token estimates per agent
    """
    return {
        "total_tokens_per_path": {
            "CRITICAL_CARE_PATH": 5000,
            "PREVENTIVE_CARE_PATH": 2000,
            "WELLNESS_PATH": 1500,
        },
        "tokens_per_agent": {
            "profile_extractor": 300,
            "health_risk_analysis": 1000,
            "emergency_preparedness": 1200,
            "nutrition_critical": 1200,
            "behavioral_coaching": 1000,
            "wellness_monitoring": 1000,
            "health_assessment": 400,
            "nutrition_preventive": 600,
            "wellness_tracking": 400,
            "wellness_optimization": 400,
            "nutrition_wellness": 500,
            "lifestyle_enrichment": 400,
        },
        "ml_tokens": 300,
    }


def get_execution_strategy() -> Dict[str, Any]:
    """Get information about workflow execution strategy.

    Returns:
        Dictionary describing how the workflow executes
    """
    return {
        "execution_model": "stateful_graph_execution",
        "state_management": "TypedDict with 44 fields",
        "error_handling": "per_node_try_catch_with_aggregation",
        "client_pattern": "dependency_injection_via_lambda",
        "compilation_strategy": "lazy_compilation_per_request",
        "invocation_method": "graph.invoke(state)",
    }
