"""Streamlit UI for PawCare+ pet health guidance system."""

import streamlit as st
import json
from datetime import datetime
from graph import assess_pet_health, get_pet_health_summary
from state import get_initial_state
from ml.evaluation import evaluate_all_models
import os


def initialize_session_state():
    """Initialize Streamlit session state."""
    if "assessment_result" not in st.session_state:
        st.session_state.assessment_result = None
    if "eval_results" not in st.session_state:
        st.session_state.eval_results = None
    if "run_evaluation" not in st.session_state:
        st.session_state.run_evaluation = False
    if "show_clarification" not in st.session_state:
        st.session_state.show_clarification = False
    if "user_clarification" not in st.session_state:
        st.session_state.user_clarification = {}


def export_assessment(assessment):
    """Export assessment results as formatted JSON."""
    export_data = {
        'metadata': {
            'request_id': assessment.get('request_id'),
            'timestamp': assessment.get('analysis_timestamp'),
        },
        'assessment': assessment
    }
    return json.dumps(export_data, indent=2)


def display_overview_tab(result):
    """Display overview tab with assessment summary."""
    st.header("Assessment Summary")

    col1, col2, col3 = st.columns(3)

    with col1:
        health_risk = result.get('health_risk_score', 0)
        st.metric("Health Risk Score", f"{health_risk:.1%}", delta=f"{health_risk*100:.0f}/100")

    with col2:
        care_capability = result.get('care_capability_score', 0)
        st.metric("Care Capability Score", f"{care_capability:.0f}/100")

    with col3:
        path = result.get("path_taken", "UNKNOWN").replace("_", " ")
        st.metric("Care Path", path)

    st.divider()

    # Path assessment
    path_info = {
        "CRITICAL_CARE_PATH": {"label": "Critical Care Required", "desc": "Immediate comprehensive intervention and monitoring needed"},
        "PREVENTIVE_CARE_PATH": {"label": "Preventive Care Focus", "desc": "Proactive measures to prevent health deterioration"},
        "WELLNESS_PATH": {"label": "Wellness Optimization", "desc": "Healthy pet with focus on lifestyle enhancement"}
    }

    path_key = result.get("path_taken", "UNKNOWN")
    info = path_info.get(path_key, {"label": "Unknown", "desc": ""})

    st.subheader("Pet Health Status")
    st.write(f"**{info['label']}** - {info['desc']}")

    st.divider()

    st.subheader("Assessment Details")
    aggregated = result.get("aggregated_output", {})

    col1, col2 = st.columns(2)

    with col1:
        st.write("**Health Assessment**")
        health_analysis = aggregated.get("health_risk_analysis", {})
        if health_analysis:
            st.write(health_analysis.get("honest_risk_assessment", "No assessment available"))
        else:
            st.write("Assessment will be provided in detailed sections")

    with col2:
        st.write("**Key Metrics**")
        st.write(f"- Health Risk Score: {health_risk:.1%}")
        st.write(f"- Care Capability: {care_capability:.0f}/100")
        st.write(f"- Care Path: {path_key.replace('_', ' ')}")


def display_guidance_tab(result):
    """Display guidance tab with detailed health guidance plan."""
    st.header("Pet Health Guidance")

    path = result.get("path_taken", "UNKNOWN")
    aggregated = result.get("aggregated_output", {})

    if path == "CRITICAL_CARE_PATH":
        st.subheader("Comprehensive Critical Care Guidance")

        # Health Risk Analysis
        with st.container(border=True):
            st.subheader("Health Risk Analysis")
            health_analysis = aggregated.get("health_risk_analysis", {})
            if health_analysis:
                # Display all relevant fields
                if health_analysis.get("honest_risk_assessment"):
                    st.write(f"**Assessment:** {health_analysis.get('honest_risk_assessment')}")

                if health_analysis.get("critical_risk_factors"):
                    st.write("**Critical Risk Factors:**")
                    factors = health_analysis.get("critical_risk_factors", [])
                    if isinstance(factors, list):
                        for factor in factors:
                            st.write(f"• {factor}")
                    else:
                        st.write(factors)

                if health_analysis.get("warning_signs"):
                    st.write("**Warning Signs to Monitor:**")
                    signs = health_analysis.get("warning_signs", [])
                    if isinstance(signs, list):
                        for sign in signs:
                            st.write(f"• {sign}")
                    else:
                        st.write(signs)

                if health_analysis.get("urgency_timeline"):
                    st.write(f"**Urgency Timeline:** {health_analysis.get('urgency_timeline')}")

                if health_analysis.get("recommended_actions"):
                    st.write("**Recommended Actions:**")
                    actions = health_analysis.get("recommended_actions", [])
                    if isinstance(actions, list):
                        for action in actions:
                            st.write(f"• {action}")
                    else:
                        st.write(actions)
            else:
                st.info("Health risk analysis will be generated")

        st.divider()

        # Emergency Preparedness
        with st.container(border=True):
            st.subheader("Emergency Preparedness")
            emergency = aggregated.get("emergency_preparedness", {})
            if emergency:
                if emergency.get("emergency_overview"):
                    st.write(f"**Overview:** {emergency.get('emergency_overview')}")

                if emergency.get("emergency_contacts"):
                    st.write("**Emergency Contacts:**")
                    contacts = emergency.get("emergency_contacts", [])
                    if isinstance(contacts, list):
                        for contact in contacts:
                            st.write(f"• {contact}")
                    else:
                        st.write(contacts)

                if emergency.get("first_aid_supplies"):
                    st.write("**First Aid Supplies Needed:**")
                    supplies = emergency.get("first_aid_supplies", [])
                    if isinstance(supplies, list):
                        col1, col2 = st.columns(2)
                        for i, supply in enumerate(supplies):
                            if i % 2 == 0:
                                with col1:
                                    st.write(f"• {supply}")
                            else:
                                with col2:
                                    st.write(f"• {supply}")
                    else:
                        st.write(supplies)

                if emergency.get("crisis_procedures"):
                    st.write("**Crisis Procedures:**")
                    procedures = emergency.get("crisis_procedures", [])
                    if isinstance(procedures, list):
                        for proc in procedures:
                            st.write(f"• {proc}")
                    else:
                        st.write(procedures)

                if emergency.get("when_to_call_vet"):
                    st.write("**When to Call Veterinarian:**")
                    st.write(emergency.get("when_to_call_vet"))
            else:
                st.info("Emergency preparedness plan will be generated")

        st.divider()

        # Nutrition Plan
        with st.container(border=True):
            st.subheader("Nutrition Critical Plan")
            nutrition = aggregated.get("nutrition_plan", {})
            if nutrition:
                if nutrition.get("nutrition_overview"):
                    st.write(f"**Overview:** {nutrition.get('nutrition_overview')}")

                if nutrition.get("recommended_diet"):
                    st.write("**Recommended Diet:**")
                    diet = nutrition.get("recommended_diet", "")
                    if isinstance(diet, list):
                        for item in diet:
                            st.write(f"• {item}")
                    else:
                        st.write(diet)

                if nutrition.get("feeding_schedule"):
                    st.write("**Feeding Schedule:**")
                    schedule = nutrition.get("feeding_schedule", "")
                    if isinstance(schedule, list):
                        for item in schedule:
                            st.write(f"• {item}")
                    else:
                        st.write(schedule)

                if nutrition.get("foods_to_avoid"):
                    st.write("**Foods to Avoid:**")
                    foods = nutrition.get("foods_to_avoid", [])
                    if isinstance(foods, list):
                        for food in foods:
                            st.write(f"• {food}")
                    else:
                        st.write(foods)

                if nutrition.get("supplements"):
                    st.write("**Recommended Supplements:**")
                    supplements = nutrition.get("supplements", [])
                    if isinstance(supplements, list):
                        for supplement in supplements:
                            st.write(f"• {supplement}")
                    else:
                        st.write(supplements)

                if nutrition.get("portion_guidance"):
                    st.write(f"**Portion Guidance:** {nutrition.get('portion_guidance')}")
            else:
                st.info("Nutrition plan will be generated")

        st.divider()

        # Behavioral Coaching
        with st.container(border=True):
            st.subheader("Behavioral Coaching")
            behavior = aggregated.get("behavioral_coaching", {})
            if behavior:
                if behavior.get("behavior_assessment"):
                    st.write("**Behavior Assessment:**")
                    assessment = behavior.get("behavior_assessment", "")
                    if isinstance(assessment, list):
                        for item in assessment:
                            st.write(f"• {item}")
                    else:
                        st.write(assessment)

                if behavior.get("training_strategies"):
                    st.write("**Training Strategies:**")
                    strategies = behavior.get("training_strategies", [])
                    if isinstance(strategies, list):
                        for strategy in strategies:
                            st.write(f"• {strategy}")
                    else:
                        st.write(strategies)

                if behavior.get("anxiety_management"):
                    st.write("**Anxiety Management:**")
                    anxiety = behavior.get("anxiety_management", "")
                    if isinstance(anxiety, list):
                        for item in anxiety:
                            st.write(f"• {item}")
                    else:
                        st.write(anxiety)

                if behavior.get("positive_reinforcement"):
                    st.write("**Positive Reinforcement:**")
                    reinforcement = behavior.get("positive_reinforcement", "")
                    if isinstance(reinforcement, list):
                        for item in reinforcement:
                            st.write(f"• {item}")
                    else:
                        st.write(reinforcement)
            else:
                st.info("Behavioral coaching will be generated")

        st.divider()

        # Wellness Monitoring
        with st.container(border=True):
            st.subheader("Wellness Monitoring Plan")
            wellness = aggregated.get("wellness_monitoring", {})
            if wellness:
                if wellness.get("monitoring_overview"):
                    st.write(f"**Overview:** {wellness.get('monitoring_overview')}")

                if wellness.get("daily_monitoring"):
                    st.write("**Daily Monitoring:**")
                    daily = wellness.get("daily_monitoring", "")
                    if isinstance(daily, list):
                        for item in daily:
                            st.write(f"• {item}")
                    else:
                        st.write(daily)

                if wellness.get("weekly_assessment"):
                    st.write("**Weekly Assessment:**")
                    weekly = wellness.get("weekly_assessment", "")
                    if isinstance(weekly, list):
                        for item in weekly:
                            st.write(f"• {item}")
                    else:
                        st.write(weekly)

                if wellness.get("vet_visit_schedule"):
                    st.write("**Vet Visit Schedule:**")
                    schedule = wellness.get("vet_visit_schedule", "")
                    if isinstance(schedule, list):
                        for item in schedule:
                            st.write(f"• {item}")
                    else:
                        st.write(schedule)

                if wellness.get("health_metrics_to_track"):
                    st.write("**Health Metrics to Track:**")
                    metrics = wellness.get("health_metrics_to_track", [])
                    if isinstance(metrics, list):
                        for metric in metrics:
                            st.write(f"• {metric}")
                    else:
                        st.write(metrics)

                if wellness.get("red_flags"):
                    st.write("**Red Flags to Watch:**")
                    flags = wellness.get("red_flags", [])
                    if isinstance(flags, list):
                        for flag in flags:
                            st.write(f"• {flag}")
                    else:
                        st.write(flags)
            else:
                st.info("Wellness monitoring plan will be generated")

    elif path == "PREVENTIVE_CARE_PATH":
        st.subheader("Preventive Care Guidance")

        # Health Assessment
        with st.container(border=True):
            st.subheader("Health Assessment")
            health_assess = aggregated.get("health_assessment", {})
            if health_assess:
                st.write(f"**Assessment:** {health_assess.get('preventive_assessment', '')}")

                if health_assess.get("key_health_areas"):
                    st.write("**Key Health Areas to Monitor:**")
                    for area in health_assess.get("key_health_areas", []):
                        st.write(f"• {area}")

                if health_assess.get("recommended_checkups"):
                    st.write(f"**Checkup Schedule:** {health_assess.get('recommended_checkups')}")

                if health_assess.get("prevention_strategies"):
                    st.write("**Prevention Strategies:**")
                    for strategy in health_assess.get("prevention_strategies", []):
                        st.write(f"• {strategy}")
            else:
                st.info("Health assessment will be generated")

        st.divider()

        # Nutrition Guide
        with st.container(border=True):
            st.subheader("Nutrition Guide")
            nutrition = aggregated.get("nutrition_preventive", {})
            if nutrition:
                st.write(f"**Overview:** {nutrition.get('nutrition_overview', '')}")

                if nutrition.get("recommended_diet"):
                    st.write(f"**Diet Recommendations:** {nutrition.get('recommended_diet')}")

                if nutrition.get("portion_guidance"):
                    st.write(f"**Portion Guidance:** {nutrition.get('portion_guidance')}")

                if nutrition.get("healthy_treats"):
                    st.write("**Healthy Treat Options:**")
                    col1, col2 = st.columns(2)
                    treats = nutrition.get("healthy_treats", [])
                    for i, treat in enumerate(treats):
                        if i % 2 == 0:
                            with col1:
                                st.write(f"• {treat}")
                        else:
                            with col2:
                                st.write(f"• {treat}")
            else:
                st.info("Nutrition guide will be generated")

        st.divider()

        # Wellness Tracking
        with st.container(border=True):
            st.subheader("Wellness Tracking Plan")
            wellness = aggregated.get("wellness_tracking", {})
            if wellness:
                st.write(f"**Overview:** {wellness.get('tracking_overview', '')}")

                if wellness.get("monthly_checklist"):
                    st.write("**Monthly Wellness Checklist:**")
                    for item in wellness.get("monthly_checklist", []):
                        st.write(f"• {item}")

                if wellness.get("wellness_goals"):
                    st.write("**Wellness Goals:**")
                    for goal in wellness.get("wellness_goals", []):
                        st.write(f"• {goal}")

                if wellness.get("early_warning_signs"):
                    st.write("**Early Warning Signs to Watch:**")
                    for sign in wellness.get("early_warning_signs", []):
                        st.write(f"• {sign}")
            else:
                st.info("Wellness tracking plan will be generated")

    else:  # WELLNESS_PATH
        st.subheader("Wellness Optimization Guide")

        # Wellness Optimization
        with st.container(border=True):
            st.subheader("Wellness Optimization")
            wellness_opt = aggregated.get("wellness_optimization", {})
            if wellness_opt:
                st.write(f"**Overview:** {wellness_opt.get('optimization_overview', '')}")

                if wellness_opt.get("wellness_enhancements"):
                    st.write("**Wellness Enhancements:**")
                    for enhancement in wellness_opt.get("wellness_enhancements", []):
                        st.write(f"• {enhancement}")

                if wellness_opt.get("activity_suggestions"):
                    st.write("**Activity Suggestions:**")
                    for activity in wellness_opt.get("activity_suggestions", []):
                        st.write(f"• {activity}")

                if wellness_opt.get("bonding_activities"):
                    st.write("**Bonding Activities:**")
                    for activity in wellness_opt.get("bonding_activities", []):
                        st.write(f"• {activity}")
            else:
                st.info("Wellness optimization will be generated")

        st.divider()

        # Nutrition Enhancement
        with st.container(border=True):
            st.subheader("Nutrition Enhancement")
            nutrition_well = aggregated.get("nutrition_wellness", {})
            if nutrition_well:
                st.write(f"**Overview:** {nutrition_well.get('nutrition_overview', '')}")

                if nutrition_well.get("enhancement_tips"):
                    st.write("**Enhancement Tips:**")
                    for tip in nutrition_well.get("enhancement_tips", []):
                        st.write(f"• {tip}")

                if nutrition_well.get("variety_suggestions"):
                    st.write(f"**Diet Variety:** {nutrition_well.get('variety_suggestions')}")

                if nutrition_well.get("supplement_options"):
                    st.write("**Optional Supplements:**")
                    for supp in nutrition_well.get("supplement_options", []):
                        st.write(f"• {supp}")
            else:
                st.info("Nutrition enhancement will be generated")

        st.divider()

        # Lifestyle Enrichment
        with st.container(border=True):
            st.subheader("Lifestyle Enrichment")
            lifestyle = aggregated.get("lifestyle_enrichment", {})
            if lifestyle:
                st.write(f"**Overview:** {lifestyle.get('enrichment_overview', '')}")

                if lifestyle.get("mental_stimulation"):
                    st.write("**Mental Stimulation Activities:**")
                    for activity in lifestyle.get("mental_stimulation", []):
                        st.write(f"• {activity}")

                if lifestyle.get("social_opportunities"):
                    st.write("**Social Opportunities:**")
                    for opp in lifestyle.get("social_opportunities", []):
                        st.write(f"• {opp}")

                if lifestyle.get("environmental_enrichment"):
                    st.write("**Environmental Enrichment:**")
                    for tip in lifestyle.get("environmental_enrichment", []):
                        st.write(f"• {tip}")
            else:
                st.info("Lifestyle enrichment will be generated")


def display_health_analysis_tab(result):
    """Display detailed health analysis and monitoring."""
    st.header("Health Analysis & Monitoring")

    path = result.get("path_taken", "UNKNOWN")
    aggregated = result.get("aggregated_output", {})

    # Pet Profile Information
    with st.container(border=True):
        st.subheader("Pet Profile Information")
        col1, col2, col3 = st.columns(3)

        with col1:
            st.write(f"**Species:** {result.get('pet_species', 'N/A')}")
            st.write(f"**Breed:** {result.get('breed', 'N/A')}")
            st.write(f"**Age:** {result.get('age_years', 'N/A')} years")

        with col2:
            st.write(f"**Weight Status:** {result.get('weight_status', 'N/A')}")
            st.write(f"**Sex:** {result.get('sex', 'N/A')}")
            st.write(f"**Living Situation:** {result.get('living_situation', 'N/A')}")

        with col3:
            st.write(f"**Exercise Level:** {result.get('exercise_level', 'N/A')}")
            st.write(f"**Diet Type:** {result.get('diet_type', 'N/A')}")
            conditions = result.get('known_conditions', [])
            if isinstance(conditions, list) and conditions:
                st.write(f"**Known Conditions:** {', '.join(conditions)}")

    st.divider()

    # Health Metrics
    with st.container(border=True):
        st.subheader("Health Assessment Metrics")
        col1, col2 = st.columns(2)

        with col1:
            health_risk = result.get('health_risk_score', 0)
            st.metric("Health Risk Score", f"{health_risk:.1%}")

            risk_level = "Critical" if health_risk > 0.6 else "Moderate" if health_risk > 0.3 else "Low"
            st.write(f"**Risk Level:** {risk_level}")

        with col2:
            care_capability = result.get('care_capability_score', 0)
            st.metric("Owner Care Capability", f"{care_capability:.0f}/100")

            capability_level = "Strong" if care_capability > 75 else "Adequate" if care_capability > 50 else "Limited"
            st.write(f"**Capability Level:** {capability_level}")

    st.divider()

    # Path-specific Analysis
    if path == "CRITICAL_CARE_PATH":
        with st.container(border=True):
            st.subheader("Critical Care Monitoring Dashboard")

            health = aggregated.get("health_risk_analysis", {})
            emergency = aggregated.get("emergency_preparedness", {})
            wellness = aggregated.get("wellness_monitoring", {})

            col1, col2 = st.columns(2)

            with col1:
                st.write("**Immediate Actions Required:**")
                if health.get("critical_risk_factors"):
                    st.write("- Address critical risk factors urgently")
                if emergency.get("emergency_contacts"):
                    st.write("- Establish emergency contact protocol")
                st.write("- Schedule veterinary consultation")

            with col2:
                st.write("**Monitoring Schedule:**")
                if wellness.get("daily_monitoring"):
                    st.write("- Daily monitoring protocol active")
                if wellness.get("vet_visit_schedule"):
                    st.write("- Follow professional vet schedule")
                st.write("- Track all health metrics regularly")


def display_model_evaluation_section(eval_results):
    """Display ML Model Evaluation metrics in the UI."""
    st.markdown("---")
    st.header("Model Evaluation Metrics")
    st.write("Performance metrics of trained machine learning models on evaluation datasets")

    if not eval_results or not eval_results.get('models'):
        st.info("Click 'Run Model Evaluation' in the sidebar to evaluate trained models.")
        return

    col1, col2 = st.columns(2)

    models = eval_results.get('models', {})

    # Pet Health Risk Model Evaluation
    with col1:
        st.subheader("Pet Health Risk Scorer Model")
        health_risk_eval = models.get('health_risk', {})

        if health_risk_eval.get('status') == 'success':
            col1a, col1b, col1c, col1d = st.columns(4)
            with col1a:
                st.metric("Test Samples", health_risk_eval.get("test_samples", "N/A"))
            with col1b:
                st.metric("R² Score", f"{health_risk_eval.get('r2_score', 0):.4f}")
            with col1c:
                st.metric("MAE", f"{health_risk_eval.get('mae', 0):.4f}")
            with col1d:
                st.metric("RMSE", f"{health_risk_eval.get('rmse', 0):.4f}")
        else:
            st.info("Health risk model evaluation not available")

    # Owner Care Capability Model Evaluation
    with col2:
        st.subheader("Owner Care Capability Model")
        care_capability_eval = models.get('care_capability', {})

        if care_capability_eval.get('status') == 'success':
            col2a, col2b, col2c, col2d = st.columns(4)
            with col2a:
                st.metric("Test Samples", care_capability_eval.get("test_samples", "N/A"))
            with col2b:
                st.metric("R² Score", f"{care_capability_eval.get('r2_score', 0):.4f}")
            with col2c:
                st.metric("MAE", f"{care_capability_eval.get('mae', 0):.4f}")
            with col2d:
                st.metric("RMSE", f"{care_capability_eval.get('rmse', 0):.4f}")
        else:
            st.info("Care capability model evaluation not available")


def main():
    """Main Streamlit application."""
    st.set_page_config(
        page_title="PawCare+ - Pet Health Guidance",
        page_icon=None,
        layout="wide",
        initial_sidebar_state="expanded"
    )

    st.title("PawCare+ - Pet Health & Care Guidance System")
    st.write("AI-powered pet health guidance and personalized care planning based on your pet's profile, health history, and lifestyle.")

    initialize_session_state()

    with st.sidebar:
        st.header("About PawCare+")
        st.write("""
        PawCare+ provides:
        - Pet health risk assessment using machine learning
        - Owner care capability analysis
        - Personalized health guidance and care planning
        - Emergency preparedness planning
        - Nutrition and behavioral recommendations
        - Wellness monitoring strategies
        """)

        st.divider()

        st.header("Tools")
        if st.button("Run Model Evaluation", use_container_width=True):
            st.session_state.run_evaluation = True

    if st.session_state.assessment_result is None:
        st.header("Pet Health Assessment Form")
        st.write("Please provide information about your pet's health, daily routine, and current concerns.")

        col1, col2 = st.columns(2)

        with col1:
            about_pet = st.text_area(
                "About Your Pet",
                placeholder="Describe your pet - breed, age, health history, personality, etc.",
                height=120,
                help="Provide details about your pet's species, breed, age, and any known health conditions"
            )

        with col2:
            daily_routine = st.text_area(
                "Daily Routine & Living Situation",
                placeholder="Exercise, diet, living environment, behavioral patterns, owner experience, etc.",
                height=120,
                help="Describe your pet's daily schedule, exercise routine, and living conditions"
            )

        health_concerns = st.text_area(
            "Current Health Concerns",
            placeholder="Current symptoms, behavioral issues, dietary concerns, vet visits, medications, etc.",
            height=120,
            help="Describe any current health issues or concerns you have about your pet"
        )

        st.divider()

        col1, col2, col3 = st.columns([1, 1, 2])

        with col1:
            submit_button = st.button("Generate Assessment", type="primary", use_container_width=True)

        with col2:
            if st.button("Clear Form", use_container_width=True):
                st.rerun()

        if submit_button:
            if not all([about_pet, daily_routine, health_concerns]):
                st.error("Please fill in all fields to proceed")
            else:
                form_data = {
                    "about_pet": about_pet,
                    "daily_routine": daily_routine,
                    "health_concerns": health_concerns,
                }

                with st.spinner("Analyzing your pet's health profile and generating personalized guidance..."):
                    try:
                        result = assess_pet_health(form_data=form_data)

                        if result.get("error_occurred"):
                            st.error("Assessment encountered errors:")
                            for error in result.get("error_messages", []):
                                st.error(f"• {error}")
                        else:
                            # Check if we need user clarification
                            if result.get("awaiting_user_input", False):
                                # Show clarifying questions before full results
                                st.session_state.assessment_result = result
                                st.session_state.show_clarification = True
                                st.rerun()
                            else:
                                st.session_state.assessment_result = result
                                st.success("Assessment completed successfully!")
                                st.rerun()

                    except Exception as e:
                        st.error(f"Assessment processing failed: {str(e)}")

    else:
        assessment = st.session_state.assessment_result

        col1, col2, col3 = st.columns([4, 1, 1])

        with col1:
            st.header("Assessment Results")

        with col2:
            if st.button("New Assessment", use_container_width=True):
                st.session_state.assessment_result = None
                st.rerun()

        with col3:
            json_export = export_assessment(assessment)
            st.download_button(
                label="Download JSON",
                data=json_export,
                file_name=f"pet_health_assessment_{assessment.get('request_id', 'export')}.json",
                mime="application/json",
                use_container_width=True
            )

        st.divider()

        tab1, tab2, tab3, tab4 = st.tabs([
            "Overview",
            "Health Guidance",
            "Detailed Analysis",
            "Summary"
        ])

        with tab1:
            display_overview_tab(assessment)

        with tab2:
            display_guidance_tab(assessment)

        with tab3:
            display_health_analysis_tab(assessment)

        with tab4:
            st.header("Complete Assessment Summary")
            summary = get_pet_health_summary(assessment)

            # Pet Profile
            with st.container(border=True):
                st.subheader("Pet Profile")
                profile = summary.get("pet_profile", {})
                col1, col2 = st.columns(2)
                with col1:
                    st.write(f"**Species:** {profile.get('species', 'N/A')}")
                    st.write(f"**Breed:** {profile.get('breed', 'N/A')}")
                    st.write(f"**Age:** {profile.get('age_years', 'N/A')} years")
                with col2:
                    st.write(f"**Weight Status:** {profile.get('weight_status', 'N/A')}")
                    conditions = profile.get('known_conditions', [])
                    if conditions:
                        st.write(f"**Conditions:** {', '.join(conditions)}")

            st.divider()

            # Health Assessment
            with st.container(border=True):
                st.subheader("Health Assessment")
                health = summary.get("health_assessment", {})
                col1, col2 = st.columns(2)
                with col1:
                    st.metric("Health Risk Score", f"{health.get('health_risk_score', 0):.1%}")
                with col2:
                    st.metric("Care Capability Score", f"{health.get('care_capability_score', 0):.0f}/100")

            st.divider()

            # Path Analysis
            with st.container(border=True):
                st.subheader("Care Path Analysis")
                path_info = summary.get("path_analysis", {})
                st.write(f"**Path:** {path_info.get('path_taken', 'Unknown')}")
                st.write(f"**Urgency Level:** {path_info.get('urgency_level', 'Unknown')}")

            st.divider()

            # System Info
            with st.container(border=True):
                st.subheader("Assessment Information")
                sys_info = summary.get("system", {})
                col1, col2 = st.columns(2)
                with col1:
                    st.write(f"**Request ID:** {sys_info.get('request_id', 'N/A')}")
                with col2:
                    st.write(f"**Timestamp:** {sys_info.get('timestamp', 'N/A')}")

    # Handle model evaluation
    if st.session_state.run_evaluation:
        try:
            model_dir = "./ml/models"
            evaluation_dir = "./data/evaluation_dataset"

            if not os.path.exists(model_dir):
                st.error(f"Models directory not found: {model_dir}")
            elif not os.path.exists(evaluation_dir):
                st.error(f"Evaluation directory not found: {evaluation_dir}")
            else:
                with st.spinner("Evaluating models..."):
                    results = evaluate_all_models(evaluation_dir, model_dir)
                    st.session_state.eval_results = results
                    st.success("Model evaluation completed!")
        except Exception as e:
            st.error(f"Evaluation failed: {str(e)}")
        finally:
            st.session_state.run_evaluation = False

    # Display evaluation results
    if st.session_state.eval_results:
        display_model_evaluation_section(st.session_state.eval_results)


if __name__ == "__main__":
    main()
