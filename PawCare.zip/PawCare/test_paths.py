#!/usr/bin/env python3
"""Test all three care paths in PawCare+."""

from graph import assess_pet_health
import json

print("=" * 80)
print("PAWCARE+ PATH VERIFICATION TEST")
print("=" * 80)

# Test Case 1: CRITICAL PATH (High-risk pet)
print("\n1. TESTING CRITICAL_CARE_PATH (High-risk pet)")
print("-" * 80)
critical_input = {
    "about_pet": "12-year-old German Shepherd with diabetes, kidney disease, and arthritis. Overweight at 95lbs. Had two seizures last month. Very lethargic.",
    "daily_routine": "Mostly stays indoors. Can barely walk. No exercise. Owner works full time.",
    "health_concerns": "Urgent: Frequent urination, increased thirst. Rear leg paralysis developing. Kidney issues."
}

print("Processing CRITICAL case...")
try:
    critical_result = assess_pet_health(critical_input)
    path_taken = critical_result.get("path_taken", "UNKNOWN")
    health_risk = critical_result.get("health_risk_score", 0)

    print(f"✓ Path Taken: {path_taken}")
    print(f"✓ Health Risk Score: {health_risk:.2%}")
    print(f"✓ Processing Complete: {critical_result.get('processing_complete', False)}")
    print(f"✓ Errors: {critical_result.get('error_occurred', False)}")

    if critical_result.get('error_occurred'):
        for err in critical_result.get('error_messages', []):
            print(f"  ✗ {err}")

    outputs = ["health_risk_analysis_output", "emergency_prep_output", "nutrition_critical_output", "behavioral_coaching_output", "wellness_monitoring_output"]
    print("\n  Path-specific outputs:")
    for out in outputs:
        has_data = bool(critical_result.get(out, {}))
        print(f"    {'✓' if has_data else '✗'} {out}")
except Exception as e:
    print(f"✗ CRITICAL PATH FAILED: {str(e)}")
    import traceback
    traceback.print_exc()

# Test Case 2: PREVENTIVE PATH
print("\n\n2. TESTING PREVENTIVE_CARE_PATH (Moderate-risk pet)")
print("-" * 80)
preventive_input = {
    "about_pet": "5-year-old Golden Retriever, slightly overweight. Generally healthy but prone to ear infections. Mild hip dysplasia.",
    "daily_routine": "1-2 walks daily, plays fetch occasionally. Regular social interactions.",
    "health_concerns": "Minor recurring ear infections. Some stiffness after exercise. Needs dental cleaning soon."
}

print("Processing PREVENTIVE case...")
try:
    preventive_result = assess_pet_health(preventive_input)
    path_taken = preventive_result.get("path_taken", "UNKNOWN")
    health_risk = preventive_result.get("health_risk_score", 0)

    print(f"✓ Path Taken: {path_taken}")
    print(f"✓ Health Risk Score: {health_risk:.2%}")
    print(f"✓ Processing Complete: {preventive_result.get('processing_complete', False)}")
    print(f"✓ Errors: {preventive_result.get('error_occurred', False)}")

    if preventive_result.get('error_occurred'):
        for err in preventive_result.get('error_messages', []):
            print(f"  ✗ {err}")

    outputs = ["health_assessment_output", "nutrition_preventive_output", "wellness_tracking_output"]
    print("\n  Path-specific outputs:")
    for out in outputs:
        has_data = bool(preventive_result.get(out, {}))
        print(f"    {'✓' if has_data else '✗'} {out}")
except Exception as e:
    print(f"✗ PREVENTIVE PATH FAILED: {str(e)}")
    import traceback
    traceback.print_exc()

# Test Case 3: WELLNESS PATH
print("\n\n3. TESTING WELLNESS_PATH (Low-risk healthy pet)")
print("-" * 80)
wellness_input = {
    "about_pet": "2-year-old Bengal cat, perfect health. No medical issues. Active and playful.",
    "daily_routine": "Indoor cat. Plays 2-3 hours daily. Good sleep schedule. Mental enrichment activities.",
    "health_concerns": "No health concerns. Want to maintain optimal wellness."
}

print("Processing WELLNESS case...")
try:
    wellness_result = assess_pet_health(wellness_input)
    path_taken = wellness_result.get("path_taken", "UNKNOWN")
    health_risk = wellness_result.get("health_risk_score", 0)

    print(f"✓ Path Taken: {path_taken}")
    print(f"✓ Health Risk Score: {health_risk:.2%}")
    print(f"✓ Processing Complete: {wellness_result.get('processing_complete', False)}")
    print(f"✓ Errors: {wellness_result.get('error_occurred', False)}")

    if wellness_result.get('error_occurred'):
        for err in wellness_result.get('error_messages', []):
            print(f"  ✗ {err}")

    outputs = ["wellness_optimization_output", "nutrition_wellness_output", "lifestyle_enrichment_output"]
    print("\n  Path-specific outputs:")
    for out in outputs:
        has_data = bool(wellness_result.get(out, {}))
        print(f"    {'✓' if has_data else '✗'} {out}")
except Exception as e:
    print(f"✗ WELLNESS PATH FAILED: {str(e)}")
    import traceback
    traceback.print_exc()

print("\n" + "=" * 80)
print("TEST COMPLETE")
print("=" * 80)
