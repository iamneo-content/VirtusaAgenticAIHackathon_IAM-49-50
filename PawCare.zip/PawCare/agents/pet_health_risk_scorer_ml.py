"""Pet Health Risk Scorer ML Agent - predicts health risk score (0-1)."""

import pickle
import os
from typing import Dict, Any
import warnings
warnings.filterwarnings('ignore')

# CRITICAL: Set scikit-learn thread control to avoid deadlocks in parallel execution
os.environ['SCIKIT_LEARN_ASSUME_FINITE'] = 'True'
os.environ['SKLEARN_THREADING_CONTROL'] = 'true'


class PetHealthRiskScorerMLAgent:
    """Predicts pet health risk score using trained ML model."""

    def __init__(self):
        """Load pre-trained model, scaler, and encoder."""
        # Set n_jobs=1 for thread-safe execution and disable threading
        import sklearn
        sklearn.set_config(assume_finite=True, working_memory=128)

        model_dir = os.path.join(
            os.path.dirname(__file__), "..", "ml", "models"
        )

        self.model = pickle.load(
            open(os.path.join(model_dir, "pet_health_risk_model.pkl"), "rb")
        )
        # Ensure model doesn't use parallel processing
        if hasattr(self.model, 'n_jobs'):
            self.model.n_jobs = 1

        self.scaler = pickle.load(
            open(os.path.join(model_dir, "pet_health_risk_scaler.pkl"), "rb")
        )
        self.encoder = pickle.load(
            open(os.path.join(model_dir, "pet_health_risk_encoder.pkl"), "rb")
        )

    def predict_health_risk(self, profile: Dict[str, Any]) -> Dict[str, Any]:
        """
        Predict pet health risk score.

        Args:
            profile: Extracted pet profile containing:
                - pet_species: str
                - breed: str
                - age_years: int
                - weight_status: str
                - known_conditions_count: int (derived)
                - allergies_count: int (derived)
                - living_situation: str
                - exercise_level: str

        Returns:
            Dictionary with:
            - health_risk_score: float (0-1)
            - status: "success"

        Raises:
            Exception: If prediction fails or model files missing
        """
        species = profile.get("pet_species", "")
        breed = profile.get("breed", "")
        age = profile.get("age_years", 5)
        weight = profile.get("weight_status", "")
        living = profile.get("living_situation", "")
        exercise = profile.get("exercise_level", "")

        # Count conditions and allergies
        conditions_count = len(profile.get("known_conditions", []))
        allergies_count = len(profile.get("allergies_known", []))

        # Encode categorical features using the saved encoders
        # Handle unseen labels by using the most common class (first in encoder.classes_)
        try:
            encoded_species = self.encoder["pet_species"].transform([species])[0]
        except ValueError:
            encoded_species = self.encoder["pet_species"].transform([self.encoder["pet_species"].classes_[0]])[0]

        try:
            encoded_weight = self.encoder["weight_status"].transform([weight])[0]
        except ValueError:
            encoded_weight = self.encoder["weight_status"].transform([self.encoder["weight_status"].classes_[0]])[0]

        try:
            encoded_living = self.encoder["living_situation"].transform([living])[0]
        except ValueError:
            encoded_living = self.encoder["living_situation"].transform([self.encoder["living_situation"].classes_[0]])[0]

        try:
            encoded_exercise = self.encoder["exercise_level"].transform([exercise])[0]
        except ValueError:
            encoded_exercise = self.encoder["exercise_level"].transform([self.encoder["exercise_level"].classes_[0]])[0]

        # Build features list with only extracted profile fields
        features = [
            [
                encoded_species,
                encoded_weight,
                encoded_living,
                encoded_exercise,
                age,
                conditions_count,
                allergies_count,
            ]
        ]

        features_scaled = self.scaler.transform(features)

        health_risk_score = float(self.model.predict(features_scaled)[0])
        health_risk_score = max(0.0, min(1.0, health_risk_score))

        return {
            "health_risk_score": health_risk_score,
            "status": "success",
        }
