"""Emergency Preparedness LLM Agent - CRITICAL path emergency planning."""

from typing import Dict, Any
from agents.base_llm_agent import BaseLLMAgent


class EmergencyPreparednessLLMAgent(BaseLLMAgent):
    """Generates emergency preparedness plan for high-risk pets."""

    def generate_emergency_plan(
        self, profile: Dict[str, Any], health_analysis: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Generate comprehensive emergency preparedness plan.

        Args:
            profile: Extracted pet profile
            health_analysis: Health risk analysis output

        Returns:
            Dictionary with emergency plan and status
        """
        species = profile.get("pet_species", "")
        breed = profile.get("breed", "")
        age = profile.get("age_years", 0)
        conditions = ", ".join(profile.get("known_conditions", []))
        vet_access = profile.get("vet_access", "")

        prompt = f"""
Create a comprehensive emergency preparedness plan for this pet.

PET PROFILE:
Species: {species}
Breed: {breed}
Age: {age} years
Known Conditions: {conditions if conditions else 'None mentioned'}
Vet Access: {vet_access}

Return valid JSON:
{{
    "emergency_contacts": {{
        "primary_vet": "name and phone",
        "emergency_vet": "24hr clinic name and phone",
        "specialist": "relevant specialist if applicable",
        "poison_control": "emergency number"
    }},
    "first_aid_supplies": ["item 1", "item 2", "item 3", "item 4", "item 5"],
    "crisis_procedures": {{
        "severe_signs": "what constitutes emergency and what to do",
        "at_home_stabilization": "first aid steps while getting to vet",
        "transport_method": "safest way to transport pet in emergency"
    }},
    "evacuation_plan": "plan for evacuating if needed with pet",
    "medical_history_prep": "how to prepare medical history for emergency vet",
    "financial_prep": "budget estimate for emergencies and savings recommendation"
}}

Requirements:
1. Provide real contact information categories (owner will fill in specifics)
2. First aid supplies should be specific and actionable (5 items)
3. Crisis procedures must be clear and actionable
4. Evacuation plan must include pet carrier, supplies, travel route
5. Return only valid JSON
"""

        result = self.client.generate_structured_json(
            prompt,
            required_fields=[
                "emergency_contacts",
                "first_aid_supplies",
                "crisis_procedures",
                "evacuation_plan",
                "medical_history_prep",
                "financial_prep",
            ],
            temperature=0.5,
            max_tokens=1200,
        )

        return {
            "emergency_preparedness": result,
            "status": "success",
        }
