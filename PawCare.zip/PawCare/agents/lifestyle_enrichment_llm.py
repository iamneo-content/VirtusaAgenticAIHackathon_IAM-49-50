"""Lifestyle Enrichment LLM Agent - WELLNESS path enrichment activities."""

from typing import Dict, Any
from agents.base_llm_agent import BaseLLMAgent


class LifestyleEnrichmentLLMAgent(BaseLLMAgent):
    """Generates lifestyle enrichment plan for healthy pets."""

    def generate_enrichment_plan(
        self, profile: Dict[str, Any], ml_results: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Generate lifestyle enrichment plan.

        Args:
            profile: Extracted pet profile
            ml_results: ML prediction results

        Returns:
            Dictionary with enrichment plan content and status
        """
        species = profile.get("pet_species", "")
        age = profile.get("age_years", 0)
        living_situation = profile.get("living_situation", "")
        exercise_level = profile.get("exercise_level", "")

        prompt = f"""You are a pet enrichment specialist. For this pet, provide enrichment ideas in JSON format ONLY.

Pet: {species}, Age: {age} years, Living: {living_situation}, Exercise: {exercise_level}

Generate this exact JSON structure (fill in the values):
{{
  "enrichment_overview": "2-sentence overview here",
  "mental_stimulation": ["activity 1", "activity 2", "activity 3"],
  "social_opportunities": ["opportunity 1", "opportunity 2"],
  "environmental_enrichment": ["tip 1", "tip 2"]
}}

Return ONLY the JSON, nothing else."""

        result = self.client.generate_structured_json(
            prompt,
            required_fields=[
                "enrichment_overview",
                "mental_stimulation",
                "social_opportunities",
                "environmental_enrichment",
            ],
            temperature=0.6,
            max_tokens=350,
        )

        return {
            "lifestyle_enrichment": result,
            "status": "success",
        }
