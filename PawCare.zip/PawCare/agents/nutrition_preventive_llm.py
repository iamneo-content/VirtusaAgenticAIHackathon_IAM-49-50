"""Nutrition Preventive LLM Agent - PREVENTIVE path nutrition guidance."""

from typing import Dict, Any
from agents.base_llm_agent import BaseLLMAgent


class NutritionPreventiveLLMAgent(BaseLLMAgent):
    """Generates preventive nutrition guide for moderate-risk pets."""

    def generate_nutrition_guide(
        self, profile: Dict[str, Any], ml_results: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Generate preventive nutrition guidance.

        Args:
            profile: Extracted pet profile
            ml_results: ML prediction results

        Returns:
            Dictionary with nutrition guide content and status
        """
        species = profile.get("pet_species", "")
        age = profile.get("age_years", 0)
        weight_status = profile.get("weight_status", "")
        diet_type = profile.get("diet_type", "")

        prompt = f"""You are a pet nutrition specialist. Provide nutrition guidance in JSON format ONLY.

Pet: {species}, Age: {age} years
Weight Status: {weight_status}
Current Diet: {diet_type}

Generate this exact JSON structure (fill in the values):
{{
  "nutrition_overview": "2-3 sentence overview here",
  "recommended_diet": "diet recommendations here",
  "portion_guidance": "portion advice based on age and weight",
  "healthy_treats": ["treat 1", "treat 2", "treat 3"]
}}

Return ONLY the JSON, nothing else."""

        result = self.client.generate_structured_json(
            prompt,
            required_fields=[
                "nutrition_overview",
                "recommended_diet",
                "portion_guidance",
                "healthy_treats",
            ],
            temperature=0.4,
            max_tokens=350,
        )

        return {
            "nutrition_guide": result,
            "status": "success",
        }
