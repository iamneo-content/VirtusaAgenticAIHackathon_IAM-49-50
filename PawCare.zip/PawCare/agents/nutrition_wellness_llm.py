"""Nutrition Wellness LLM Agent - WELLNESS path nutrition enhancement."""

from typing import Dict, Any
from agents.base_llm_agent import BaseLLMAgent


class NutritionWellnessLLMAgent(BaseLLMAgent):
    """Generates nutrition enhancement for healthy pets."""

    def generate_nutrition_enhancement(
        self, profile: Dict[str, Any], ml_results: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Generate nutrition enhancement plan.

        Args:
            profile: Extracted pet profile
            ml_results: ML prediction results

        Returns:
            Dictionary with nutrition enhancement content and status
        """
        species = profile.get("pet_species", "")
        age = profile.get("age_years", 0)
        diet_type = profile.get("diet_type", "")

        prompt = f"""You are a pet nutrition expert. For this pet, provide nutrition enhancement in JSON format ONLY.

Pet: {species}, Age: {age} years, Current Diet: {diet_type}

Generate this exact JSON structure (fill in the values):
{{
  "nutrition_overview": "2-sentence overview here",
  "enhancement_tips": ["tip 1", "tip 2", "tip 3"],
  "variety_suggestions": "suggestions for diet variety here",
  "supplement_options": ["supplement 1", "supplement 2"]
}}

Return ONLY the JSON, nothing else."""

        result = self.client.generate_structured_json(
            prompt,
            required_fields=[
                "nutrition_overview",
                "enhancement_tips",
                "variety_suggestions",
                "supplement_options",
            ],
            temperature=0.5,
            max_tokens=350,
        )

        return {
            "nutrition_enhancement": result,
            "status": "success",
        }
