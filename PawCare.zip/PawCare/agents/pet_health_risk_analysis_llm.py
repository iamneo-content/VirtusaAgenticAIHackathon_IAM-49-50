"""Pet Health Risk Analysis LLM Agent - CRITICAL path deep analysis."""

from typing import Dict, Any
from agents.base_llm_agent import BaseLLMAgent


class PetHealthRiskAnalysisLLMAgent(BaseLLMAgent):
    """Generates comprehensive health risk analysis for high-risk pets."""

    def generate_risk_analysis(
        self, profile: Dict[str, Any], ml_results: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Generate deep health risk analysis.

        Args:
            profile: Extracted pet profile
            ml_results: ML prediction results (health_risk_score, care_capability_score)

        Returns:
            Dictionary with risk analysis content and status
        """
        health_risk = ml_results.get("health_risk_score", 0)
        species = profile.get("pet_species", "")
        age = profile.get("age_years", 0)
        breed = profile.get("breed", "")
        conditions = ", ".join(profile.get("known_conditions", []))

        prompt = f"""
Provide comprehensive health risk analysis for this pet.

PET PROFILE:
Species: {species}
Breed: {breed}
Age: {age} years
Known Conditions: {conditions if conditions else 'None mentioned'}
Health Risk Score: {health_risk:.2f} (0-1 scale, where 1.0 = critical risk)

Return valid JSON:
{{
    "honest_risk_assessment": "detailed paragraph assessing health risks",
    "critical_risk_factors": ["risk 1", "risk 2", "risk 3", "risk 4"],
    "success_probability": "description of health management success likelihood",
    "warning_signs": ["sign 1 to watch", "sign 2 to watch", "sign 3 to watch"],
    "urgency_timeline": "description of timeline for intervention if needed"
}}

Requirements:
1. Be honest about health risks
2. Critical risk factors must be specific and real (4 items)
3. Success probability should reference the risk score
4. Warning signs must be actionable (what owner should observe daily)
5. Urgency timeline should indicate immediate/short-term/long-term actions
6. Return only valid JSON
"""

        result = self.client.generate_structured_json(
            prompt,
            required_fields=[
                "honest_risk_assessment",
                "critical_risk_factors",
                "success_probability",
                "warning_signs",
                "urgency_timeline",
            ],
            temperature=0.5,
            max_tokens=1000,
        )

        return {
            "health_risk_analysis": result,
            "status": "success",
        }
