"""Nutrition Optimization Critical Path LLM Agent - CRITICAL path nutrition analysis."""

from typing import Dict, Any
from agents.base_llm_agent import BaseLLMAgent


class NutritionCriticalLLMAgent(BaseLLMAgent):
    """Generates detailed nutrition optimization for high-risk pets."""

    def generate_nutrition_plan(
        self, profile: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Generate comprehensive nutrition plan for critical health situations.

        Args:
            profile: Extracted pet profile

        Returns:
            Dictionary with nutrition plan and status
        """
        species = profile.get("pet_species", "")
        weight_status = profile.get("weight_status", "")
        diet_type = profile.get("diet_type", "")
        conditions = ", ".join(profile.get("known_conditions", []))
        allergies = ", ".join(profile.get("allergies_known", []))

        prompt = f"""
Create detailed nutrition optimization plan for this pet.

PET PROFILE:
Species: {species}
Weight Status: {weight_status}
Current Diet: {diet_type}
Known Conditions: {conditions if conditions else 'None'}
Allergies: {allergies if allergies else 'None known'}

Return valid JSON:
{{
    "recommended_diet": "specific diet recommendation with explanation",
    "feeding_schedule": "recommended feeding frequency and portions",
    "supplements": ["supplement 1 with reason", "supplement 2 with reason"],
    "foods_to_avoid": ["food 1", "food 2", "food 3"],
    "weight_management": "weight goal if applicable and realistic timeline",
    "transition_plan": "how to transition to new diet safely",
    "meal_prep_examples": ["example meal 1", "example meal 2"]
}}

Requirements:
1. Diet recommendation must be specific and explain why for this pet
2. Feeding schedule should include portion estimates
3. Supplements must have clear health reasons
4. Foods to avoid should be specific
5. Weight management should be realistic (1lb per month for dogs, 0.25lb for cats)
6. Transition plan should take 7-10 days
7. Return only valid JSON
"""

        result = self.client.generate_structured_json(
            prompt,
            required_fields=[
                "recommended_diet",
                "feeding_schedule",
                "supplements",
                "foods_to_avoid",
                "weight_management",
                "transition_plan",
                "meal_prep_examples",
            ],
            temperature=0.5,
            max_tokens=1200,
        )

        return {
            "nutrition_plan": result,
            "status": "success",
        }
