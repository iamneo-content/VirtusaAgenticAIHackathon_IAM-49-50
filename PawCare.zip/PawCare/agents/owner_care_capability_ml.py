"""Owner Care Capability ML Agent - predicts owner capability (0-100)."""

import pickle
import os
from typing import Dict, Any
import warnings
warnings.filterwarnings('ignore')

# CRITICAL: Set scikit-learn thread control to avoid deadlocks in parallel execution
os.environ['SCIKIT_LEARN_ASSUME_FINITE'] = 'True'
os.environ['SKLEARN_THREADING_CONTROL'] = 'true'


class OwnerCareCapabilityMLAgent:
    """Predicts owner care capability using trained ML model."""

    def __init__(self):
        """Load pre-trained model, scaler, and encoder."""
        # Set n_jobs=1 for thread-safe execution and disable threading
        import sklearn
        sklearn.set_config(assume_finite=True, working_memory=128)

        model_dir = os.path.join(
            os.path.dirname(__file__), "..", "ml", "models"
        )

        self.model = pickle.load(
            open(os.path.join(model_dir, "owner_care_capability_model.pkl"), "rb")
        )
        # Ensure model doesn't use parallel processing
        if hasattr(self.model, 'n_jobs'):
            self.model.n_jobs = 1

        self.scaler = pickle.load(
            open(os.path.join(model_dir, "owner_care_capability_scaler.pkl"), "rb")
        )
        self.encoder = pickle.load(
            open(os.path.join(model_dir, "owner_care_capability_encoder.pkl"), "rb")
        )

    def predict_capability(self, profile: Dict[str, Any]) -> Dict[str, Any]:
        """
        Predict owner care capability score.

        Args:
            profile: Extracted pet profile containing:
                - owner_experience: str
                - vet_access: str
                - owner_commitment: str

        Returns:
            Dictionary with:
            - care_capability_score: float (0-100)
            - status: "success"

        Raises:
            Exception: If prediction fails or model files missing
        """
        experience = profile.get("owner_experience", "")
        vet_access = profile.get("vet_access", "")
        commitment = profile.get("owner_commitment", "")

        # Encode categorical features
        try:
            encoded_experience = self.encoder["owner_experience"].transform([experience])[0]
        except ValueError:
            encoded_experience = self.encoder["owner_experience"].transform([self.encoder["owner_experience"].classes_[0]])[0]

        try:
            encoded_vet = self.encoder["vet_access"].transform([vet_access])[0]
        except ValueError:
            encoded_vet = self.encoder["vet_access"].transform([self.encoder["vet_access"].classes_[0]])[0]

        try:
            encoded_commitment = self.encoder["owner_commitment"].transform([commitment])[0]
        except ValueError:
            encoded_commitment = self.encoder["owner_commitment"].transform([self.encoder["owner_commitment"].classes_[0]])[0]

        # Build features list
        features = [
            [
                encoded_experience,
                encoded_vet,
                encoded_commitment,
            ]
        ]

        features_scaled = self.scaler.transform(features)

        care_capability_score = float(self.model.predict(features_scaled)[0])
        care_capability_score = max(0.0, min(100.0, care_capability_score))

        return {
            "care_capability_score": care_capability_score,
            "status": "success",
        }
