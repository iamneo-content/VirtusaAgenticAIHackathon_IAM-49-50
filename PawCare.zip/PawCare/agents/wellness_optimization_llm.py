"""Wellness Optimization LLM Agent - WELLNESS path optimization guidance."""

from typing import Dict, Any
from agents.base_llm_agent import BaseLLMAgent


class WellnessOptimizationLLMAgent(BaseLLMAgent):
    """Generates wellness optimization plan for healthy pets."""

    def generate_optimization_plan(
        self, profile: Dict[str, Any], ml_results: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Generate wellness optimization plan.

        Args:
            profile: Extracted pet profile
            ml_results: ML prediction results (health_risk_score < 0.3)

        Returns:
            Dictionary with optimization plan content and status
        """
        species = profile.get("pet_species", "")
        age = profile.get("age_years", 0)
        exercise_level = profile.get("exercise_level", "")
        living_situation = profile.get("living_situation", "")

        prompt = f"""You are a pet wellness advisor. For this pet, provide recommendations in JSON format ONLY.

Pet: {species}, Age: {age} years, Living: {living_situation}, Exercise: {exercise_level}

Generate this exact JSON structure (fill in the values):
{{
  "optimization_overview": "2-sentence overview here",
  "wellness_enhancements": ["enhancement 1", "enhancement 2", "enhancement 3"],
  "activity_suggestions": ["activity 1", "activity 2"],
  "bonding_activities": ["activity 1", "activity 2"]
}}

Return ONLY the JSON, nothing else."""

        result = self.client.generate_structured_json(
            prompt,
            required_fields=[
                "optimization_overview",
                "wellness_enhancements",
                "activity_suggestions",
                "bonding_activities",
            ],
            temperature=0.5,
            max_tokens=350,
        )

        return {
            "wellness_optimization": result,
            "status": "success",
        }
