"""Wellness Tracking Preventive LLM Agent - PREVENTIVE path tracking plan."""

from typing import Dict, Any
from agents.base_llm_agent import BaseLLMAgent


class WellnessTrackingPreventiveLLMAgent(BaseLLMAgent):
    """Generates preventive wellness tracking plan for moderate-risk pets."""

    def generate_tracking_plan(
        self, profile: Dict[str, Any], ml_results: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Generate preventive wellness tracking plan.

        Args:
            profile: Extracted pet profile
            ml_results: ML prediction results (health_risk_score)

        Returns:
            Dictionary with tracking plan content and status
        """
        health_risk = ml_results.get("health_risk_score", 0)
        species = profile.get("pet_species", "")
        exercise_level = profile.get("exercise_level", "")
        age = profile.get("age_years", 0)

        prompt = f"""You are a pet wellness coordinator. Provide wellness tracking plan in JSON format ONLY.

Pet: {species}, Age: {age} years
Exercise Level: {exercise_level}
Health Risk Score: {health_risk:.2f}

Generate this exact JSON structure (fill in the values):
{{
  "tracking_overview": "2-sentence overview here",
  "monthly_checklist": ["item 1", "item 2", "item 3"],
  "wellness_goals": ["goal 1", "goal 2"],
  "early_warning_signs": ["sign 1", "sign 2"]
}}

Return ONLY the JSON, nothing else."""

        result = self.client.generate_structured_json(
            prompt,
            required_fields=[
                "tracking_overview",
                "monthly_checklist",
                "wellness_goals",
                "early_warning_signs",
            ],
            temperature=0.4,
            max_tokens=300,
        )

        return {
            "wellness_tracking": result,
            "status": "success",
        }
