"""Wellness Monitoring LLM Agent - CRITICAL path monitoring plan."""

from typing import Dict, Any
from agents.base_llm_agent import BaseLLMAgent


class WellnessMonitoringLLMAgent(BaseLLMAgent):
    """Generates wellness monitoring plan for high-risk pets."""

    def generate_monitoring_plan(
        self, profile: Dict[str, Any], ml_results: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Generate comprehensive wellness monitoring plan.

        Args:
            profile: Extracted pet profile
            ml_results: ML prediction results

        Returns:
            Dictionary with monitoring plan and status
        """
        species = profile.get("pet_species", "")
        age = profile.get("age_years", 0)
        health_risk = ml_results.get("health_risk_score", 0)
        conditions = ", ".join(profile.get("known_conditions", []))

        prompt = f"""
Create wellness monitoring plan for this pet.

PET PROFILE:
Species: {species}
Age: {age} years
Health Risk Score: {health_risk:.2f} (0-1 scale)
Known Conditions: {conditions if conditions else 'None'}

Return valid JSON:
{{
    "daily_monitoring": ["metric 1 to check daily", "metric 2", "metric 3"],
    "weekly_assessment": ["assessment 1", "assessment 2"],
    "monthly_detailed_check": ["detailed check 1", "detailed check 2"],
    "vet_visit_schedule": "recommended vet visit frequency",
    "health_tracking_method": "how to document and track health metrics",
    "red_flags": ["immediate vet visit trigger 1", "trigger 2", "trigger 3"],
    "progress_milestone": "measurable milestones to track improvement",
    "long_term_timeline": "6-month and 12-month health goals"
}}

Requirements:
1. Daily monitoring should be owner-observable metrics (not invasive)
2. Weekly assessments should take 5-10 minutes
3. Monthly detailed checks should be more thorough
4. Vet visit schedule should be specific (every 3 months, every 6 months, etc)
5. Tracking method should be simple (spreadsheet, app, notes)
6. Red flags must be clear indicators requiring immediate vet care
7. Progress milestones should be realistic and measurable
8. Return only valid JSON
"""

        result = self.client.generate_structured_json(
            prompt,
            required_fields=[
                "daily_monitoring",
                "weekly_assessment",
                "monthly_detailed_check",
                "vet_visit_schedule",
                "health_tracking_method",
                "red_flags",
                "progress_milestone",
                "long_term_timeline",
            ],
            temperature=0.5,
            max_tokens=1000,
        )

        return {
            "wellness_monitoring": result,
            "status": "success",
        }
