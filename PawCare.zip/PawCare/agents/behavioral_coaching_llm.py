"""Behavioral Coaching LLM Agent - CRITICAL path behavior analysis."""

from typing import Dict, Any
from agents.base_llm_agent import BaseLLMAgent


class BehavioralCoachingLLMAgent(BaseLLMAgent):
    """Generates behavioral coaching for high-risk pets with behavior issues."""

    def generate_behavior_coaching(
        self, profile: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Generate comprehensive behavioral coaching plan.

        Args:
            profile: Extracted pet profile

        Returns:
            Dictionary with behavior coaching and status
        """
        species = profile.get("pet_species", "")
        breed = profile.get("breed", "")
        behavioral_issues = ", ".join(profile.get("behavioral_issues", []))
        conditions = ", ".join(profile.get("known_conditions", []))

        prompt = f"""
Create behavioral coaching plan for this pet.

PET PROFILE:
Species: {species}
Breed: {breed}
Behavioral Issues: {behavioral_issues if behavioral_issues else 'None mentioned'}
Health Conditions: {conditions if conditions else 'None'}

Return valid JSON:
{{
    "behavior_assessment": "analysis of behavioral issues and their likely causes",
    "training_strategies": ["strategy 1", "strategy 2", "strategy 3"],
    "anxiety_management": "specific anxiety management techniques if applicable",
    "training_timeline": "realistic timeline for behavior improvement",
    "when_professional": "indicators that professional trainer/behaviorist needed",
    "positive_reinforcement_plan": "rewards and motivation strategies",
    "common_triggers": ["trigger 1", "trigger 2", "trigger 3"]
}}

Requirements:
1. Behavior assessment should connect to health conditions if relevant
2. Training strategies must be specific and humane (no punishment)
3. Anxiety management should include calming techniques
4. Timeline should be realistic (weeks to months, not days)
5. Professional help indicators should be clear and honest
6. Positive reinforcement must be specific to pet's preferences
7. Return only valid JSON
"""

        result = self.client.generate_structured_json(
            prompt,
            required_fields=[
                "behavior_assessment",
                "training_strategies",
                "anxiety_management",
                "training_timeline",
                "when_professional",
                "positive_reinforcement_plan",
                "common_triggers",
            ],
            temperature=0.6,
            max_tokens=1000,
        )

        return {
            "behavioral_coaching": result,
            "status": "success",
        }
