"""Pet Profile Extractor LLM Agent - extracts structured pet profile from free text."""

from typing import Dict, Any
from agents.base_llm_agent import BaseLLMAgent


class PetProfileExtractorLLMAgent(BaseLLMAgent):
    """Extracts structured pet profile information from 3 free-text input fields using LLM."""

    def extract_pet_profile(self, raw_inputs: Dict[str, str]) -> Dict[str, Any]:
        """
        Extract comprehensive pet profile from free-text inputs using Gemini LLM.

        Args:
            raw_inputs: Dictionary with 3 text fields:
                - about_pet
                - daily_routine
                - health_concerns

        Returns:
            Dictionary with:
            - extracted_profile: Dictionary containing 15+ profile fields
            - status: "success" if extraction succeeds
        """
        prompt = f"""
Extract comprehensive pet health profile from user inputs. MUST extract ALL required fields with actual values.

USER INPUTS:
About Pet: {raw_inputs.get('about_pet', '')}
Daily Routine: {raw_inputs.get('daily_routine', '')}
Health Concerns: {raw_inputs.get('health_concerns', '')}

CRITICAL: Extract these fields with actual computed values (NEVER leave as empty unless explicitly impossible):

{{
    "pet_species": "species (dog, cat, rabbit, bird, etc)",
    "breed": "specific breed or mix (e.g., 'Golden Retriever', 'mixed breed')",
    "age_years": integer age in years,
    "weight_status": "overweight/normal/underweight based on context",
    "sex": "male/female/unknown",
    "known_conditions": ["list of health conditions mentioned"],
    "past_surgeries": ["list of surgeries if mentioned"],
    "allergies_known": ["list of known allergies"],
    "medications_current": ["list of current medications if mentioned"],
    "living_situation": "apartment/house/farm/other",
    "exercise_level": "sedentary/moderate/high based on routine described",
    "diet_type": "kibble/raw/mixed/homemade/prescription",
    "diet_quality": "poor/average/good/premium based on description",
    "behavioral_issues": ["list of behavioral issues mentioned"],
    "owner_experience": "novice/experienced/expert based on context",
    "vet_access": "regular/emergency_only/limited/none",
    "owner_commitment": "casual/dedicated/obsessive based on tone and detail"
}}

EXTRACTION RULES:
- MUST extract actual values from text
- If information not explicitly stated, INFER from context
- Arrays must have at least 1 item if applicable (can be empty list if truly none)
- owner_experience: Infer from how they describe pet care knowledge
- vet_access: Infer from mentions of vet visits, urgency of concerns
- owner_commitment: Infer from detail level, willingness to invest time
- Temperature is low (0.3) so be deterministic, not random

Return ONLY valid JSON, no markdown, no explanation, no codeblocks.
"""

        result = self.client.generate_structured_json(
            prompt,
            required_fields=[
                "pet_species",
                "breed",
                "age_years",
                "weight_status",
                "sex",
                "known_conditions",
                "past_surgeries",
                "allergies_known",
                "medications_current",
                "living_situation",
                "exercise_level",
                "diet_type",
                "diet_quality",
                "behavioral_issues",
                "owner_experience",
                "vet_access",
                "owner_commitment",
            ],
            temperature=0.3,
            max_tokens=900,
        )

        return {
            "extracted_profile": result,
            "status": "success",
        }
