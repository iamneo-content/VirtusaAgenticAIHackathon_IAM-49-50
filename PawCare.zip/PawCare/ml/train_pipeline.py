"""ML training pipeline orchestrator."""

from data_cleaning import clean_health_risk_dataset, clean_care_capability_dataset
from train_model import train_health_risk_model, train_care_capability_model
from evaluation import evaluate_all_models
import os


def run_full_pipeline(
    training_dir: str,
    evaluation_dir: str,
    output_dir: str,
    processed_dir: str = None
) -> dict:
    """Run complete ML training pipeline.

    Steps:
    1. Clean training datasets (remove NaN, duplicates)
    2. Train both ML models
    3. Evaluate models on clean evaluation data
    4. Save results

    Args:
        training_dir: Directory containing raw training CSV files
        evaluation_dir: Directory containing evaluation CSV files
        output_dir: Directory to save trained models (.pkl files)
        processed_dir: Optional directory to save cleaned training data

    Returns:
        Dictionary with pipeline results
    """
    results = {
        "status": "started",
        "steps": {}
    }

    os.makedirs(output_dir, exist_ok=True)
    if processed_dir:
        os.makedirs(processed_dir, exist_ok=True)

    print("\n=== STEP 1: DATA CLEANING ===")
    try:
        health_risk_raw = f"{training_dir}/pet_health_risk_training.csv"
        health_risk_clean = clean_health_risk_dataset(health_risk_raw)
        if processed_dir:
            health_risk_clean.to_csv(f"{processed_dir}/pet_health_risk_clean.csv", index=False)
        print(f"✓ Pet health risk data cleaned: {len(health_risk_clean)} samples")
        results["steps"]["cleaning_health_risk"] = {"status": "success", "samples": len(health_risk_clean)}
    except Exception as e:
        print(f"✗ Pet health risk cleaning failed: {str(e)}")
        results["steps"]["cleaning_health_risk"] = {"status": "failed", "error": str(e)}
        return results

    try:
        care_capability_raw = f"{training_dir}/owner_care_capability_training.csv"
        care_capability_clean = clean_care_capability_dataset(care_capability_raw)
        if processed_dir:
            care_capability_clean.to_csv(f"{processed_dir}/owner_care_capability_clean.csv", index=False)
        print(f"✓ Owner care capability data cleaned: {len(care_capability_clean)} samples")
        results["steps"]["cleaning_care_capability"] = {"status": "success", "samples": len(care_capability_clean)}
    except Exception as e:
        print(f"✗ Owner care capability cleaning failed: {str(e)}")
        results["steps"]["cleaning_care_capability"] = {"status": "failed", "error": str(e)}
        return results

    print("\n=== STEP 2: MODEL TRAINING ===")
    try:
        health_risk_metrics = train_health_risk_model(f"{processed_dir or training_dir}/pet_health_risk_clean.csv", output_dir)
        print(f"✓ Pet health risk model trained")
        print(f"  Train R²: {health_risk_metrics['train_r2']:.4f}")
        print(f"  Test R²: {health_risk_metrics['test_r2']:.4f}")
        results["steps"]["training_health_risk"] = health_risk_metrics
    except Exception as e:
        print(f"✗ Pet health risk training failed: {str(e)}")
        results["steps"]["training_health_risk"] = {"status": "failed", "error": str(e)}
        return results

    try:
        care_capability_metrics = train_care_capability_model(f"{processed_dir or training_dir}/owner_care_capability_clean.csv", output_dir)
        print(f"✓ Owner care capability model trained")
        print(f"  Train R²: {care_capability_metrics['train_r2']:.4f}")
        print(f"  Test R²: {care_capability_metrics['test_r2']:.4f}")
        results["steps"]["training_care_capability"] = care_capability_metrics
    except Exception as e:
        print(f"✗ Owner care capability training failed: {str(e)}")
        results["steps"]["training_care_capability"] = {"status": "failed", "error": str(e)}
        return results

    print("\n=== STEP 3: MODEL EVALUATION ===")
    try:
        eval_results = evaluate_all_models(evaluation_dir, output_dir)
        print(f"✓ Model evaluation completed")
        for model_name, metrics in eval_results["models"].items():
            if metrics.get("status") == "success":
                print(f"  {model_name}:")
                print(f"    MAE: {metrics['mae']:.4f}")
                print(f"    RMSE: {metrics['rmse']:.4f}")
                print(f"    R²: {metrics['r2_score']:.4f}")
        results["steps"]["evaluation"] = eval_results
    except Exception as e:
        print(f"✗ Model evaluation failed: {str(e)}")
        results["steps"]["evaluation"] = {"status": "failed", "error": str(e)}
        return results

    print("\n=== PIPELINE COMPLETE ===")
    results["status"] = "success"
    return results


if __name__ == "__main__":
    import os
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    training_data_dir = os.path.join(base_dir, "data/training_dataset")
    evaluation_data_dir = os.path.join(base_dir, "data/evaluation_dataset")
    model_output_dir = os.path.join(base_dir, "ml/models")
    processed_data_dir = os.path.join(base_dir, "data/processed")

    pipeline_results = run_full_pipeline(
        training_dir=training_data_dir,
        evaluation_dir=evaluation_data_dir,
        output_dir=model_output_dir,
        processed_dir=processed_data_dir
    )

    print("\n=== FINAL RESULTS ===")
    print(f"Pipeline Status: {pipeline_results['status']}")
    for step, details in pipeline_results['steps'].items():
        print(f"{step}: {details.get('status', 'unknown')}")
