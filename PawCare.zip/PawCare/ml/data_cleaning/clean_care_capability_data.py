"""Data cleaning for owner care capability training dataset."""

import pandas as pd
import numpy as np


def clean_care_capability_dataset(input_file: str) -> pd.DataFrame:
    """Clean owner care capability training dataset.

    Handles noise types:
    - Missing values (NaN) → REMOVE rows with NaN
    - Categorical typos/invalid values → standardize to valid values
    - Out-of-range values → clip to valid bounds
    - Maintain class balance after cleaning

    Strategy: Remove NaN rows, standardize valid categories, preserve balance

    Args:
        input_file: Path to raw owner_care_capability_training.csv

    Returns:
        Cleaned DataFrame ready for model training (class balanced)
    """
    df = pd.read_csv(input_file)
    original_rows = len(df)

    # Step 1: Remove rows with ANY NaN/null values
    df = df.dropna()
    rows_after_dropna = len(df)

    # Step 2: Standardize categorical values to valid categories
    valid_experience = ['novice', 'intermediate', 'advanced', 'expert']
    if 'owner_experience' in df.columns:
        df['owner_experience'] = df['owner_experience'].str.lower()
        # Keep only valid experience values
        df = df[df['owner_experience'].isin(valid_experience)]

    valid_vet_access = ['limited', 'regular', 'good', 'excellent']
    if 'vet_access' in df.columns:
        df['vet_access'] = df['vet_access'].str.lower()
        # Keep only valid vet access values
        df = df[df['vet_access'].isin(valid_vet_access)]

    valid_commitment = ['low', 'moderate', 'high', 'very high']
    if 'owner_commitment' in df.columns:
        df['owner_commitment'] = df['owner_commitment'].str.lower()
        # Keep only valid commitment values
        df = df[df['owner_commitment'].isin(valid_commitment)]

    # Step 3: Validate range constraints for target variable
    if 'care_capability_score' in df.columns:
        # Keep only scores in valid range [0, 100]
        df = df[(df['care_capability_score'] >= 0.0) & (df['care_capability_score'] <= 100.0)]

    df = df.reset_index(drop=True)

    # Print statistics
    rows_after_cleaning = len(df)
    print(f"  Rows removed (NaN): {original_rows - rows_after_dropna}")
    print(f"  Rows removed (invalid categories): {rows_after_dropna - rows_after_cleaning}")
    print(f"  Final data retention: {rows_after_cleaning} / {original_rows} rows ({100*rows_after_cleaning/original_rows:.1f}%)")

    return df
