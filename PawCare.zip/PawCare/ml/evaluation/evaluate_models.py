"""Evaluate trained ML models on evaluation datasets."""

import pickle
import pandas as pd
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import numpy as np


def evaluate_health_risk_model(evaluation_file: str, model_dir: str) -> dict:
    """Evaluate pet health risk model on clean evaluation data.

    Args:
        evaluation_file: Path to evaluation dataset CSV
        model_dir: Directory containing saved model artifacts

    Returns:
        Dictionary with evaluation metrics
    """
    df = pd.read_csv(evaluation_file)

    with open(f"{model_dir}/pet_health_risk_model.pkl", "rb") as f:
        model = pickle.load(f)
    with open(f"{model_dir}/pet_health_risk_scaler.pkl", "rb") as f:
        scaler = pickle.load(f)
    with open(f"{model_dir}/pet_health_risk_encoder.pkl", "rb") as f:
        label_encoders = pickle.load(f)

    categorical_cols = ['pet_species', 'weight_status', 'living_situation', 'exercise_level']
    numerical_cols = ['age_years', 'conditions_count', 'allergies_count']

    available_numerical = [col for col in numerical_cols if col in df.columns]
    available_categorical = [col for col in categorical_cols if col in df.columns]

    encoded_data = df.copy()
    for col in available_categorical:
        if col in label_encoders:
            encoded_data[col] = label_encoders[col].transform(df[col].astype(str))

    X = encoded_data[available_categorical + available_numerical]
    y = encoded_data['health_risk_score']

    X_scaled = scaler.transform(X)
    y_pred = model.predict(X_scaled)

    mse = mean_squared_error(y, y_pred)
    mae = mean_absolute_error(y, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y, y_pred)

    return {
        "status": "success",
        "model": "pet_health_risk",
        "test_samples": len(y),
        "mse": mse,
        "mae": mae,
        "rmse": rmse,
        "r2_score": r2,
    }


def evaluate_care_capability_model(evaluation_file: str, model_dir: str) -> dict:
    """Evaluate owner care capability model on clean evaluation data.

    Args:
        evaluation_file: Path to evaluation dataset CSV
        model_dir: Directory containing saved model artifacts

    Returns:
        Dictionary with evaluation metrics
    """
    df = pd.read_csv(evaluation_file)

    with open(f"{model_dir}/owner_care_capability_model.pkl", "rb") as f:
        model = pickle.load(f)
    with open(f"{model_dir}/owner_care_capability_scaler.pkl", "rb") as f:
        scaler = pickle.load(f)
    with open(f"{model_dir}/owner_care_capability_encoder.pkl", "rb") as f:
        label_encoders = pickle.load(f)

    categorical_cols = list(label_encoders.keys())

    available_categorical = [col for col in categorical_cols if col in df.columns]

    encoded_data = df.copy()
    for col in available_categorical:
        if col in label_encoders:
            encoded_data[col] = label_encoders[col].transform(df[col].astype(str))

    X = encoded_data[available_categorical]
    y = encoded_data['care_capability_score']

    X_scaled = scaler.transform(X)
    y_pred = model.predict(X_scaled)

    mse = mean_squared_error(y, y_pred)
    mae = mean_absolute_error(y, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y, y_pred)

    return {
        "status": "success",
        "model": "owner_care_capability",
        "test_samples": len(y),
        "mse": mse,
        "mae": mae,
        "rmse": rmse,
        "r2_score": r2,
    }


def evaluate_all_models(evaluation_dir: str, model_dir: str) -> dict:
    """Evaluate all trained models.

    Args:
        evaluation_dir: Directory containing evaluation CSV files
        model_dir: Directory containing saved model artifacts

    Returns:
        Dictionary with all evaluation results
    """
    results = {
        "status": "success",
        "models": {}
    }

    health_risk_file = f"{evaluation_dir}/pet_health_risk_evaluation.csv"
    care_capability_file = f"{evaluation_dir}/owner_care_capability_evaluation.csv"

    try:
        health_risk_metrics = evaluate_health_risk_model(health_risk_file, model_dir)
        results["models"]["health_risk"] = health_risk_metrics
    except Exception as e:
        results["models"]["health_risk"] = {"status": "failed", "error": str(e)}

    try:
        care_capability_metrics = evaluate_care_capability_model(care_capability_file, model_dir)
        results["models"]["care_capability"] = care_capability_metrics
    except Exception as e:
        results["models"]["care_capability"] = {"status": "failed", "error": str(e)}

    return results
