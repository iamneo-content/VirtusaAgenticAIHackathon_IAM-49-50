"""Train owner care capability ML model."""

import pickle
import pandas as pd
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split


def train_care_capability_model(training_file: str, output_dir: str) -> dict:
    """Train owner care capability model.

    Uses only fields that are extracted from user input via PetProfileExtractorLLMAgent.

    Args:
        training_file: Path to cleaned training data CSV
        output_dir: Directory to save model artifacts (.pkl files)

    Returns:
        Dictionary with training metrics
    """
    df = pd.read_csv(training_file)

    # Only use fields that PetProfileExtractorLLMAgent actually extracts
    categorical_cols = ['owner_experience', 'vet_access', 'owner_commitment']

    available_categorical = [col for col in categorical_cols if col in df.columns]

    label_encoders = {}
    encoded_data = df.copy()

    for col in available_categorical:
        le = LabelEncoder()
        encoded_data[col] = le.fit_transform(df[col].astype(str))
        label_encoders[col] = le

    X = encoded_data[available_categorical]
    y = encoded_data['care_capability_score']

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    model = RandomForestRegressor(
        n_estimators=100,
        max_depth=10,
        random_state=42,
        verbose=0
    )
    model.fit(X_train_scaled, y_train)

    train_score = model.score(X_train_scaled, y_train)
    test_score = model.score(X_test_scaled, y_test)

    with open(f"{output_dir}/owner_care_capability_model.pkl", "wb") as f:
        pickle.dump(model, f)

    with open(f"{output_dir}/owner_care_capability_scaler.pkl", "wb") as f:
        pickle.dump(scaler, f)

    with open(f"{output_dir}/owner_care_capability_encoder.pkl", "wb") as f:
        pickle.dump(label_encoders, f)

    return {
        "status": "success",
        "train_r2": train_score,
        "test_r2": test_score,
        "model_type": "RandomForestRegressor",
        "n_features": X.shape[1],
        "training_samples": len(X_train),
        "test_samples": len(X_test),
    }
