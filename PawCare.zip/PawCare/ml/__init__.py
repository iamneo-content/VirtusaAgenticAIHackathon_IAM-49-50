"""PawCare+ ML pipeline module."""

__all__ = []
