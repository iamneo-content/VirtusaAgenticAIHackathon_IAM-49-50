PAWCARE+ PET HEALTH GUIDANCE SYSTEM
===================================

COMPREHENSIVE PROJECT DOCUMENTATION

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


SECTION 1: PROBLEM DESCRIPTION
===============================

1.1 PROBLEM STATEMENT
_____________________

Pet owners face significant challenges in understanding their pet's health status and making informed care decisions. Current solutions either provide generic guidance or require multiple veterinary consultations, which are expensive and time-consuming. There is a critical gap between veterinary expertise and accessible pet health guidance for general pet owners.

Pet owners lack:
1. Personalized health risk assessment based on individual pet profiles
2. Context-aware guidance tailored to their specific situation
3. Emergency preparedness planning for their pet's unique health risks
4. Actionable nutrition and behavioral recommendations
5. Proactive wellness monitoring strategies

1.2 PROPOSED SOLUTION
_____________________

PawCare+ is an AI-powered pet health guidance system that combines machine learning predictions with large language model expertise to provide personalized, comprehensive pet health assessment and care planning.

The system addresses the problem through:

1. Profile Extraction: Uses advanced LLM to extract 17 structured health and lifestyle attributes from natural language descriptions
2. Risk Assessment: Employs trained machine learning models to predict health risk (0-1 scale) and care capability (0-100 scale)
3. Intelligent Routing: Routes pets to appropriate care pathways based on predicted health risk
4. Specialized Guidance: Delivers path-specific recommendations for critical care, preventive care, or wellness optimization
5. Comprehensive Planning: Generates detailed guidance across 5+ domains: emergency prep, nutrition, behavioral coaching, wellness monitoring, and lifestyle enrichment

1.3 KEY OBJECTIVES
__________________

1. Provide accurate pet health risk assessment using ML models trained on 30,000 synthetic records
2. Generate personalized guidance using state-of-the-art language models (Gemini)
3. Deliver different care pathways based on individual pet risk profiles
4. Enable pet owners to make informed decisions about pet care
5. Support emergency preparedness and proactive wellness management
6. Maintain system reliability through API key rotation and graceful error handling

1.4 TARGET USERS
________________

1. Pet owners seeking personalized health guidance
2. First-time pet owners needing comprehensive orientation
3. Owners of pets with health concerns requiring specialized care planning
4. Users wanting proactive wellness monitoring strategies


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


SECTION 2: PROJECT FILE STRUCTURE
==================================

PawCare/
├── main.py                                  (Streamlit UI Application Entry Point)
├── graph.py                                 (LangGraph Orchestration Engine)
├── state.py                                 (State Management and TypedDict Definition)
│
├── agents/                                  (16 Agent Modules - Processing Logic)
│   ├── __init__.py                         (Package Initialization)
│   ├── base_llm_agent.py                   (Base Class for LLM Agents)
│   ├── input_validator_agent.py            (Input Validation Logic)
│   ├── pet_profile_extractor_llm.py        (LLM-based Profile Extraction)
│   ├── pet_health_risk_scorer_ml.py        (ML Health Risk Prediction)
│   ├── owner_care_capability_ml.py         (ML Care Capability Prediction)
│   ├── pet_health_risk_analysis_llm.py     (CRITICAL Path - Health Analysis)
│   ├── emergency_preparedness_llm.py       (CRITICAL Path - Emergency Planning)
│   ├── nutrition_critical_llm.py           (CRITICAL Path - Critical Nutrition)
│   ├── behavioral_coaching_llm.py          (CRITICAL Path - Behavior Guidance)
│   ├── wellness_monitoring_llm.py          (CRITICAL Path - Monitoring Plan)
│   ├── health_assessment_preventive_llm.py (PREVENTIVE Path - Health Assessment)
│   ├── nutrition_preventive_llm.py         (PREVENTIVE Path - Nutrition Guide)
│   ├── wellness_tracking_preventive_llm.py (PREVENTIVE Path - Wellness Tracking)
│   ├── wellness_optimization_llm.py        (WELLNESS Path - Optimization)
│   ├── nutrition_wellness_llm.py           (WELLNESS Path - Nutrition Enhancement)
│   └── lifestyle_enrichment_llm.py         (WELLNESS Path - Enrichment)
│
├── nodes/                                   (17 Execution Nodes - Graph Integration)
│   ├── __init__.py                         (Package Initialization)
│   ├── input_validator_node.py             (Input Validation Node)
│   ├── pet_profile_extractor_node.py       (Profile Extraction Node)
│   ├── pet_health_risk_scorer_node.py      (ML Health Risk Node)
│   ├── owner_care_capability_node.py       (ML Care Capability Node)
│   ├── health_risk_router_node.py          (Routing Decision Node)
│   ├── pet_health_risk_analysis_node.py    (CRITICAL - Risk Analysis Node)
│   ├── emergency_preparedness_node.py      (CRITICAL - Emergency Prep Node)
│   ├── nutrition_critical_node.py          (CRITICAL - Nutrition Node)
│   ├── behavioral_coaching_node.py         (CRITICAL - Behavior Node)
│   ├── wellness_monitoring_node.py         (CRITICAL - Monitoring Node)
│   ├── health_assessment_preventive_node.py (PREVENTIVE - Assessment Node)
│   ├── nutrition_preventive_node.py        (PREVENTIVE - Nutrition Node)
│   ├── wellness_tracking_preventive_node.py (PREVENTIVE - Tracking Node)
│   ├── wellness_optimization_node.py       (WELLNESS - Optimization Node)
│   ├── nutrition_wellness_node.py          (WELLNESS - Nutrition Node)
│   ├── lifestyle_enrichment_node.py        (WELLNESS - Enrichment Node)
│   └── output_aggregator_node.py           (Final Output Aggregation)
│
├── ml/                                      (Machine Learning Pipeline)
│   ├── __init__.py                         (Package Initialization)
│   ├── train_pipeline.py                   (ML Pipeline Orchestrator)
│   ├── data_cleaning/                      (Data Cleaning Modules)
│   │   ├── __init__.py                     (Package Initialization)
│   │   ├── clean_health_risk_data.py       (Health Risk Data Cleaning)
│   │   └── clean_care_capability_data.py   (Care Capability Data Cleaning)
│   ├── train_model/                        (Model Training Modules)
│   │   ├── __init__.py                     (Package Initialization)
│   │   ├── train_health_risk_model.py      (Health Risk Model Training)
│   │   └── train_care_capability_model.py  (Care Capability Model Training)
│   ├── evaluation/                         (Model Evaluation)
│   │   ├── __init__.py                     (Package Initialization)
│   │   └── evaluate_models.py              (Model Evaluation and Metrics)
│   └── models/                             (Trained Model Artifacts)
│       ├── pet_health_risk_model.pkl       (Trained Health Risk Model)
│       ├── pet_health_risk_scaler.pkl      (Scaler for Health Risk)
│       ├── pet_health_risk_encoder.pkl     (Encoder for Health Risk)
│       ├── owner_care_capability_model.pkl (Trained Capability Model)
│       ├── owner_care_capability_scaler.pkl (Scaler for Capability)
│       └── owner_care_capability_encoder.pkl (Encoder for Capability)
│
├── utils/                                   (Utility Modules)
│   ├── __init__.py                         (Package Initialization)
│   └── gemini_client.py                    (Gemini API Client)
│
├── workflow/                                (Workflow Metadata)
│   ├── __init__.py                         (Package Initialization)
│   └── workflow.py                         (Routing Logic and Metadata)
│
├── data/                                    (Data Storage)
│   ├── training_dataset/                   (Raw Training Data)
│   │   ├── pet_health_risk_training.csv    (Health Risk Training Data)
│   │   └── owner_care_capability_training.csv (Capability Training Data)
│   ├── evaluation_dataset/                 (Evaluation Data)
│   │   ├── pet_health_risk_evaluation.csv  (Health Risk Evaluation Data)
│   │   └── owner_care_capability_evaluation.csv (Capability Evaluation Data)
│   └── processed/                          (Cleaned Data Output)
│       ├── pet_health_risk_clean.csv       (Cleaned Health Risk Data)
│       └── owner_care_capability_clean.csv (Cleaned Capability Data)
│
├── .env                                     (Environment Configuration)
├── installation.txt                         (Dependencies List)
└── PROJECT_DOCUMENTATION.md                 (This Document)


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


SECTION 3: PURPOSE OF KEY FILES
================================

3.1 CORE APPLICATION FILES
__________________________

main.py
-------
Purpose: Streamlit web application entry point providing user interface for pet health assessment
Responsibilities:
1. Initialize session state management for multi-step workflows
2. Display assessment form with three text input fields
3. Accept user input about pet, daily routine, and health concerns
4. Invoke assessment workflow via assess_pet_health() function
5. Display results in four organized tabs (Overview, Guidance, Analysis, Summary)
6. Handle model evaluation trigger and display ML metrics
7. Provide JSON export functionality for assessment results
Usage: Run as: streamlit run main.py

graph.py
--------
Purpose: LangGraph state machine orchestration engine
Responsibilities:
1. Define complete workflow as directed acyclic graph
2. Build StateGraph with 17 nodes representing workflow stages
3. Create conditional routing based on health risk score
4. Establish three distinct execution paths (Critical, Preventive, Wellness)
5. Inject Gemini client into LLM nodes via lambda functions
6. Manage state transitions through the entire workflow
7. Execute graph and return final assessment state
Key Functions: build_petcare_graph(), assess_pet_health(), get_pet_health_summary()

state.py
--------
Purpose: Define complete state schema using TypedDict with reducer annotations
Responsibilities:
1. Define 44 state fields covering all workflow data
2. Implement custom reducers for state field merging (keep_first, set_true, add)
3. Initialize empty state with default values via get_initial_state()
4. Track system metadata, user inputs, extracted profile, ML predictions, and outputs
5. Manage path decision and path-specific outputs
Structure: PetCareState TypedDict with two utility functions

3.2 AGENT MODULES (agents/ directory)
_____________________________________

Purpose: Encapsulate processing logic for each workflow stage

Agent Classification:
A. Input Validation (1 agent, no client needed)
B. Profile Extraction (1 agent, LLM-based)
C. ML Prediction (2 agents, trained models)
D. Critical Path (5 agents, LLM-based guidance)
E. Preventive Path (3 agents, LLM-based guidance)
F. Wellness Path (3 agents, LLM-based guidance)

3.3 NODE MODULES (nodes/ directory)
___________________________________

Purpose: Integrate agents into LangGraph workflow
Structure: Each node receives state, calls corresponding agent, updates state, returns updated state
Pattern: Consistent try-except error handling that accumulates errors in state
Execution: 17 nodes execute in sequence or conditionally based on routing

3.4 ML PIPELINE MODULES (ml/ directory)
_______________________________________

Purpose: Complete machine learning pipeline from data to predictions
Structure:
1. Data Generation: Create 30,000 synthetic records with realistic distributions
2. Data Cleaning: Handle missing values, categorical standardization, outlier removal
3. Model Training: Train regressor for health risk prediction, regressor for care capability
4. Model Evaluation: Assess model performance on evaluation datasets
5. Model Artifacts: Store trained models (pet_health_risk_model.pkl, owner_care_capability_model.pkl), scalers, and encoders as pickle files

3.5 UTILITY MODULES (utils/ directory)
______________________________________

gemini_client.py
Purpose: Unified interface for Gemini API with advanced features
Responsibilities:
1. Support both old (google-generativeai) and new (google-genai) APIs
2. Load API keys from environment variables or Streamlit secrets
3. Implement automatic API key rotation on quota exceeded
4. Generate content with configurable temperature and max tokens
5. Parse JSON responses with multi-strategy error recovery
6. Validate response fields against required fields list
7. Handle both new and old API response formats

3.6 WORKFLOW MODULE (workflow/ directory)
_________________________________________

workflow.py
Purpose: Provide metadata and routing information for workflow execution
Responsibilities:
1. Define routing thresholds and path conditions
2. Document execution strategies per path
3. Provide token budget information per agent
4. Describe parallel execution opportunities
5. Supply execution strategy metadata

3.7 DATA MODULES (data/ directory)
__________________________________

Purpose: Store training, evaluation, and processed datasets
Structure:
1. training_dataset/: Raw CSV files for model training
2. evaluation_dataset/: CSV files for model evaluation
3. processed/: Cleaned data output from cleaning pipeline


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


SECTION 4: MODULE-BY-MODULE DETAILED EXPLANATION
=================================================

4.1 STATE MANAGEMENT MODULE (state.py)
______________________________________

PETCARESTATE CLASS
__________________

Type: TypedDict with custom reducer annotations
Purpose: Define complete state schema with 44 fields tracking workflow progress

Class Structure:
The class uses Python TypedDict which provides type hints for dictionary-like state management. Each field uses Annotated type hints with reducer functions that control how field values merge when multiple nodes update the same field.

Fields Categorized:

1. System Metadata (5 fields)
   - request_id: String UUID for request tracking
   - analysis_timestamp: ISO format timestamp of analysis
   - error_occurred: Boolean flag indicating any node error
   - error_messages: List accumulating all error messages
   - processing_complete: Boolean indicating workflow completion

2. User Inputs (3 fields)
   - about_pet: User's free-text description of pet characteristics
   - daily_routine: User's description of pet's daily activities and environment
   - health_concerns: User's description of current health issues and concerns

3. Validation Fields (2 fields)
   - validation_errors: List of validation error messages
   - parsing_complete: Boolean indicating input validation completion

4. Extracted Profile (15 fields)
   - extracted_profile: Complete dictionary of extracted profile
   - profile_extraction_complete: Boolean indicating extraction success
   - pet_species: Extracted species (dog, cat, rabbit, bird, etc)
   - breed: Extracted breed or mix
   - age_years: Extracted age as integer
   - weight_status: Extracted status (underweight, normal, overweight, obese)
   - sex: Extracted gender (male, female, unknown)
   - known_conditions: List of health conditions
   - past_surgeries: List of previous surgeries
   - allergies_known: List of known allergies
   - medications_current: List of current medications
   - living_situation: Extracted living environment (apartment, house, farm, outdoor)
   - exercise_level: Extracted activity level (sedentary to very active)
   - diet_type: Extracted diet category (kibble, raw, mixed, homemade, prescription)
   - diet_quality: Extracted diet quality (poor, average, good, premium)
   - behavioral_issues: List of behavioral concerns
   - owner_experience: Owner's experience level (novice, experienced, expert)
   - vet_access: Availability of veterinary care (regular, emergency only, limited, none)
   - owner_commitment: Owner's dedication level (casual, dedicated, obsessive)

5. ML Prediction Fields (2 fields)
   - health_risk_score: Float between 0 and 1 from health risk model
   - care_capability_score: Float between 0 and 100 from capability model

6. Routing Field (1 field)
   - path_taken: String indicating care path (CRITICAL_CARE_PATH, PREVENTIVE_CARE_PATH, WELLNESS_PATH)

7. Path-Specific Output Fields (12 fields)
   Critical Path outputs:
   - health_risk_analysis_output: Dictionary with risk analysis
   - emergency_prep_output: Dictionary with emergency planning
   - nutrition_critical_output: Dictionary with nutrition guidance
   - behavioral_coaching_output: Dictionary with behavior guidance
   - wellness_monitoring_output: Dictionary with monitoring plan

   Preventive Path outputs:
   - health_assessment_output: Dictionary with health assessment
   - nutrition_preventive_output: Dictionary with nutrition guide
   - wellness_tracking_output: Dictionary with tracking plan

   Wellness Path outputs:
   - wellness_optimization_output: Dictionary with optimization plan
   - nutrition_wellness_output: Dictionary with nutrition enhancement
   - lifestyle_enrichment_output: Dictionary with enrichment plan

8. Final Output Field (1 field)
   - aggregated_output: Complete dictionary combining path-specific outputs

Reducer Functions:
1. keep_first(existing, new): Returns existing value if present, ignores updates
   Use case: prevent overwriting of immutable fields like request_id

2. set_true(existing, new): Returns True if either value is True (OR logic)
   Use case: error flags that should remain True once set

3. add (from operator module): Concatenates lists
   Use case: accumulate error messages from multiple nodes

GET_INITIAL_STATE FUNCTION
__________________________

Purpose: Create and initialize complete state dictionary from form data
Parameters:
- form_data: Dictionary containing user input fields and metadata

Logic Flow:
1. Receives form_data with about_pet, daily_routine, health_concerns
2. Extracts or generates request_id (UUID) and timestamp if provided
3. Creates new PetCareState dictionary with all 44 fields
4. Sets user input fields from form_data
5. Initializes all other fields to empty values (empty lists, empty dicts, 0 floats, False booleans)
6. Returns initialized state ready for workflow execution

Return Type: Dictionary (PetCareState) with all 44 fields initialized


4.2 GEMINI CLIENT MODULE (utils/gemini_client.py)
_________________________________________________

GEMINICLIENT CLASS
__________________

Type: Custom client wrapper class
Purpose: Provide unified interface to Gemini API with robustness features

Class Attributes:
- model: String name of Gemini model (default: gemini-2.5-flash-lite)
- api_keys: List of available API keys for rotation
- current_key_index: Integer index of currently active key
- client: Active Gemini client instance
- model_instance: Reference to generation method

Constructor __init__(model)
__________________________

Parameters:
- model: Optional string specifying model name

Logic:
1. Accept optional model parameter (defaults to gemini-2.5-flash-lite)
2. Call _get_all_api_keys() to retrieve all available API keys from environment/secrets
3. Initialize current_key_index to 0
4. Call _initialize_client() to set up first client instance

Return: Initialized GeminiClient instance

Method: _initialize_client()
___________________________

Purpose: Set up Gemini client with current API key
Parameters: None

Logic:
1. Check if current_key_index is within valid bounds
2. Retrieve current API key from api_keys list at current_key_index
3. Detect API version (new vs old)
4. If new API (google-genai v0.4+):
   a. Create Client with api_key parameter
   b. Store reference to models.generate_content method
5. If old API (google-generativeai):
   a. Call genai.configure() with api_key
   b. Create GenerativeModel instance with model name
   c. Store reference to client.generate_content method
6. Log initialization message

Return: None (modifies self.client and self.model_instance)

Method: _rotate_api_key()
________________________

Purpose: Rotate to next available API key when quota exceeded
Parameters: None

Logic:
1. Increment current_key_index by 1
2. Check if index exceeds list bounds
3. If exceeded, raise ValueError indicating all keys exhausted
4. If valid, call _initialize_client() to set up new client
5. Log rotation message

Return: None (modifies self.client and self.current_key_index)

Method: generate_content(prompt, temperature, max_tokens, response_mime_type)
___________________________________________________________________________

Purpose: Generate content from Gemini with automatic key rotation on quota exceeded
Parameters:
- prompt: String containing the prompt for LLM
- temperature: Float between 0 and 1 controlling randomness (0=deterministic, 1=creative)
- max_tokens: Integer maximum output tokens
- response_mime_type: Optional MIME type for structured output

Logic:
1. Set max_retries equal to number of available API keys
2. Initialize attempt counter to 0
3. Loop while attempts less than max_retries:
   a. Build generation_config dictionary with temperature and max_output_tokens
   b. Check API version (new vs old)
   c. If new API:
      - Call self.client.models.generate_content() with model, contents (prompt), config
      - Extract response.text from response
   d. If old API:
      - Call self.client.generate_content() with prompt and generation_config
      - Extract response.text from response
   e. If response_text is empty, raise ValueError
   f. Return response_text
   g. If exception occurs, check if quota-related (contains 429, quota, rate limit, exceeded)
   h. If quota-related:
      - Log warning
      - Increment attempt counter
      - If attempts remaining, call _rotate_api_key() and continue loop
      - Otherwise raise ValueError with all keys exhausted message
   i. If not quota-related, log error and raise immediately

Return: String containing generated content from LLM

Method: extract_json_from_response(response_text)
________________________________________________

Purpose: Parse JSON from LLM response with multi-strategy error recovery
Parameters:
- response_text: String containing potential JSON in various formats

Logic:
1. Clean response text:
   a. Strip whitespace
   b. Remove markdown code fences (remove lines with triple backticks)
2. Generate candidate strings for parsing (original cleaned + extracted first JSON object)
3. For each candidate string:
   a. Try standard JSON parsing after trailing comma removal
   b. If JSONDecodeError occurs, try unterminated string repair
   c. Try parsing again after repair
   d. If still fails, extract all nested JSON objects and try parsing innermost
   e. If any candidate succeeds and parses to dictionary, return result
4. If all candidates fail, raise ValueError with last error

Return: Dictionary containing parsed JSON, raises ValueError if parsing fails

Method: validate_response_fields(response, required_fields)
__________________________________________________________

Purpose: Verify response contains all required fields
Parameters:
- response: Dictionary to validate
- required_fields: List of required field names

Logic:
1. Create list of missing_fields by checking each required field in response dictionary
2. If missing_fields list is not empty, raise ValueError listing missing fields
3. Otherwise return successfully

Return: None if validation passes, raises ValueError if fields missing

Method: generate_structured_json(prompt, required_fields, temperature, max_tokens)
________________________________________________________________________________

Purpose: Generate and validate JSON response with specified required fields
Parameters:
- prompt: String prompt for LLM
- required_fields: List of required field names in response
- temperature: Float controlling randomness
- max_tokens: Integer maximum output tokens

Logic:
1. Call generate_content() with prompt, temperature, max_tokens
2. Call extract_json_from_response() on returned text
3. Call validate_response_fields() on extracted JSON
4. Return parsed and validated JSON dictionary

Return: Dictionary containing valid JSON with all required fields

Module-Level Functions:
_______________________

_get_all_api_keys()
Purpose: Retrieve all available API keys from multiple sources
Logic:
1. Initialize empty keys list
2. Try to import streamlit and check secrets for GEMINI_API_KEY_1 through GEMINI_API_KEY_4
3. Check environment variables for GEMINI_API_KEY
4. Check environment variables for GEMINI_API_KEY_1 through GEMINI_API_KEY_4
5. Avoid duplicates by checking if key already in list
6. Return complete list of unique keys

Return: List of API key strings

_get_first_api_key()
Purpose: Get single API key for backwards compatibility
Logic:
1. Call _get_all_api_keys()
2. Return first key from list or None if empty

Return: String API key or None

_clean_json_text(text)
Purpose: Remove markdown formatting from JSON text
Logic:
1. Strip leading/trailing whitespace
2. Remove triple backtick markdown fences with json label
3. Remove remaining triple backticks
4. Return cleaned text

Return: String with markdown removed

_strip_trailing_commas(text)
Purpose: Repair JSON with trailing commas before closing braces
Logic:
1. Repeatedly replace pattern of comma followed by closing brace/bracket with just closing character
2. Continue looping until no more matches found
3. Return repaired text

Return: String with trailing commas removed

_repair_unterminated_strings(text)
Purpose: Repair JSON with unterminated strings
Logic:
1. Remove markdown code blocks
2. Extract first valid JSON object using regex
3. Return extracted JSON or original if extraction fails

Return: String containing repaired JSON

build_gemini_client()
Purpose: Factory function to create configured GeminiClient
Logic:
1. Get first available API key
2. Get model name from environment (defaults to gemini-2.5-flash-lite)
3. Validate API key exists, raise error if missing
4. Validate genai library imported, raise error if missing
5. If old API, call configure() with key
6. Create and return GeminiClient instance

Return: GeminiClient instance or raises ValueError/ImportError


4.3 AGENT MODULES (agents/ directory)
_____________________________________

BASE LLM AGENT CLASS
____________________

Location: agents/base_llm_agent.py
Type: Parent class for all LLM-based agents
Purpose: Provide shared client management for LLM agents

Class Attributes:
- client: GeminiClient instance for API calls

Constructor __init__(client)
__________________________

Parameters:
- client: GeminiClient instance

Logic:
1. Validate client is not None
2. Store client as instance attribute
3. Raise ValueError if client is None

Return: Initialized BaseLLMAgent instance

Purpose: All subclasses (11 agents) inherit from this base class and only need to implement specific generation methods


INPUT VALIDATOR AGENT CLASS
____________________________

Location: agents/input_validator_agent.py
Type: Simple validation class without inheritance
Purpose: Validate user input text fields

Class Attributes:
- MIN_LENGTH: Constant integer 10 (minimum characters required)
- MAX_LENGTH: Constant integer 3000 (maximum characters allowed)

Method: validate_inputs(raw_inputs)
_________________________________

Parameters:
- raw_inputs: Dictionary with keys about_pet, daily_routine, health_concerns

Logic:
1. Initialize empty validation_errors list
2. Define required fields list with 3 field names
3. For each field:
   a. Get field value from dictionary and strip whitespace
   b. Check if empty, append error if missing
   c. Check length against MIN_LENGTH, append error if too short
   d. Check length against MAX_LENGTH, append error if too long
4. Determine is_valid boolean (True if no validation_errors)
5. Return dictionary with validation_errors list, is_valid boolean, and status string

Return Type: Dictionary with keys:
- validation_errors: List of error message strings
- is_valid: Boolean indicating if validation passed
- status: String "success"


PET PROFILE EXTRACTOR LLM AGENT
_______________________________

Location: agents/pet_profile_extractor_llm.py
Type: Class inheriting from BaseLLMAgent
Purpose: Extract 17 structured profile fields from 3 free-text inputs using LLM

Class Inheritance:
- Inherits from BaseLLMAgent (gets self.client)

Method: extract_pet_profile(raw_inputs)
_____________________________________

Parameters:
- raw_inputs: Dictionary with about_pet, daily_routine, health_concerns strings

Logic:
1. Create prompt instructing LLM to extract 17 specific profile fields
2. Define required_fields list with 17 field names
3. Call self.client.generate_structured_json():
   - Pass prompt with explicit field definitions and extraction rules
   - Pass required_fields for validation
   - Set temperature to 0.3 for deterministic output
   - Set max_tokens to 900
4. Return dictionary containing extracted_profile dictionary and status

Extracted Fields:
1. pet_species: Species type (dog, cat, rabbit, bird, etc)
2. breed: Specific breed or mix
3. age_years: Age as integer
4. weight_status: Weight category
5. sex: Gender
6. known_conditions: List of health conditions
7. past_surgeries: List of surgeries
8. allergies_known: List of allergies
9. medications_current: List of medications
10. living_situation: Environment type
11. exercise_level: Activity level
12. diet_type: Diet category
13. diet_quality: Diet quality rating
14. behavioral_issues: List of behaviors
15. owner_experience: Owner expertise level
16. vet_access: Veterinary access availability
17. owner_commitment: Owner dedication level

Return Type: Dictionary with keys:
- extracted_profile: Dictionary containing all 17 extracted fields
- status: String "success"


PET HEALTH RISK SCORER ML AGENT
_______________________________

Location: agents/pet_health_risk_scorer_ml.py
Type: ML inference class (no LLM inheritance)
Purpose: Predict pet health risk score (0-1) using trained model

Class Attributes:
- model: Loaded regressor model from pickle
- scaler: Loaded StandardScaler for feature scaling from pickle
- encoder: Dictionary of LabelEncoders for categorical features from pickle

Constructor __init__()
____________________

Parameters: None

Logic:
1. Configure scikit-learn for thread-safe execution
2. Construct path to ml/models directory relative to agent file
3. Load three pickle artifacts:
   a. pet_health_risk_model.pkl containing trained regressor
   b. pet_health_risk_scaler.pkl containing StandardScaler
   c. pet_health_risk_encoder.pkl containing dictionary of LabelEncoders
4. Set model n_jobs to 1 to disable parallel execution
5. Set sklearn configuration for finite data assumption

Return: Initialized agent with loaded models

Method: predict_health_risk(profile)
__________________________________

Parameters:
- profile: Dictionary containing extracted pet profile

Logic:
1. Extract feature values from profile:
   - pet_species: categorical
   - breed: (not used in model)
   - age_years: numerical
   - weight_status: categorical
   - living_situation: categorical
   - exercise_level: categorical
   - known_conditions list length: numerical
   - allergies_known list length: numerical

2. Encode categorical features:
   - For each categorical: try transform with encoder
   - If ValueError (unseen label), use most common class (first in encoder.classes_)

3. Build feature array with 7 values:
   [encoded_species, encoded_weight, encoded_living, encoded_exercise, age, conditions_count, allergies_count]

4. Scale features using loaded scaler
5. Predict using model
6. Clip result to valid range [0.0, 1.0]
7. Return dictionary with health_risk_score float and status string

Return Type: Dictionary with keys:
- health_risk_score: Float between 0.0 and 1.0
- status: String "success"


OWNER CARE CAPABILITY ML AGENT
______________________________

Location: agents/owner_care_capability_ml.py
Type: ML inference class
Purpose: Predict owner care capability (0-100) using trained model

Class Attributes:
- model: Loaded regressor from pickle
- scaler: Loaded StandardScaler from pickle
- encoder: Dictionary of LabelEncoders from pickle

Constructor __init__()
____________________

Parameters: None

Logic:
1. Configure scikit-learn for thread safety
2. Construct path to models directory
3. Load three artifacts:
   a. owner_care_capability_model.pkl with regressor
   b. owner_care_capability_scaler.pkl with StandardScaler
   c. owner_care_capability_encoder.pkl with LabelEncoders
4. Set model n_jobs to 1
5. Configure sklearn

Return: Initialized agent with loaded models

Method: predict_capability(profile)
_________________________________

Parameters:
- profile: Dictionary with extracted profile

Logic:
1. Extract three features from profile:
   - owner_experience: categorical
   - vet_access: categorical
   - owner_commitment: categorical

2. Encode categorical features with error handling:
   - For unseen labels, fallback to most common class

3. Build feature array [encoded_experience, encoded_vet, encoded_commitment]
4. Scale features
5. Predict using model
6. Clip to valid range [0.0, 100.0]
7. Return dictionary

Return Type: Dictionary with keys:
- care_capability_score: Float between 0.0 and 100.0
- status: String "success"


CRITICAL PATH: PET HEALTH RISK ANALYSIS LLM AGENT
__________________________________________________

Location: agents/pet_health_risk_analysis_llm.py
Type: Class inheriting from BaseLLMAgent
Purpose: Generate comprehensive health risk analysis for high-risk pets

Method: generate_risk_analysis(profile, ml_results)
_________________________________________________

Parameters:
- profile: Extracted pet profile dictionary
- ml_results: Dictionary containing health_risk_score and care_capability_score

Logic:
1. Extract key information from profile and results
2. Create prompt instructing LLM to analyze health risks
3. Include in prompt:
   - Pet species, breed, age
   - Known conditions
   - Health risk score value
4. Request 5 specific output fields in JSON format
5. Call generate_structured_json with temperature 0.5 and max_tokens 1000
6. Return dictionary containing health_risk_analysis and status

Generated Output Fields:
- honest_risk_assessment: Detailed paragraph about health risks
- critical_risk_factors: List of 4 critical risk factors
- success_probability: Description of management success likelihood
- warning_signs: List of 3+ signs to monitor
- urgency_timeline: Timeline for required interventions

Return Type: Dictionary with keys:
- health_risk_analysis: Dictionary with 5 fields above
- status: String "success"


CRITICAL PATH: EMERGENCY PREPAREDNESS LLM AGENT
______________________________________________

Location: agents/emergency_preparedness_llm.py
Type: Class inheriting from BaseLLMAgent
Purpose: Generate emergency preparedness plan for high-risk pets

Method: generate_emergency_plan(profile, health_analysis)
_______________________________________________________

Parameters:
- profile: Extracted pet profile
- health_analysis: Output from health risk analysis agent

Logic:
1. Extract health risk details from inputs
2. Create prompt for emergency planning
3. Include pet-specific information and identified risks
4. Request JSON with emergency planning components
5. Call generate_structured_json with temperature 0.5 and max_tokens 1200
6. Return dictionary with emergency plan

Generated Output Fields:
- emergency_overview: Brief overview of emergency preparedness
- emergency_contacts: List of emergency contact instructions
- first_aid_supplies: List of 5+ supplies to keep on hand
- crisis_procedures: List of procedures for specific emergencies
- when_to_call_vet: Guidelines for veterinary emergency timing
- evacuation_plan: Instructions for emergency evacuation
- medical_history_prep: Instructions for preparing medical records
- financial_prep: Budget recommendations for emergency fund

Return Type: Dictionary with keys:
- emergency_preparedness: Dictionary with 8 fields
- status: String "success"


CRITICAL PATH: NUTRITION CRITICAL LLM AGENT
___________________________________________

Location: agents/nutrition_critical_llm.py
Type: Class inheriting from BaseLLMAgent
Purpose: Generate critical nutrition plan for high-risk pets

Method: generate_nutrition_plan(profile)
______________________________________

Parameters:
- profile: Extracted pet profile

Logic:
1. Create prompt about nutrition requirements
2. Include pet species, age, known conditions, dietary constraints
3. Request JSON with nutrition planning components
4. Call generate_structured_json with temperature 0.5 and max_tokens 1200
5. Return dictionary with nutrition plan

Generated Output Fields:
- nutrition_overview: Overview of nutritional strategy
- recommended_diet: Specific diet recommendations
- feeding_schedule: Feeding schedule and frequency
- supplements: Recommended supplements
- foods_to_avoid: List of foods to avoid
- weight_management: Weight management strategy if needed
- transition_plan: Plan for transitioning to new diet
- meal_prep_examples: Example meal preparations

Return Type: Dictionary with keys:
- nutrition_critical: Dictionary with 7+ fields
- status: String "success"


CRITICAL PATH: BEHAVIORAL COACHING LLM AGENT
____________________________________________

Location: agents/behavioral_coaching_llm.py
Type: Class inheriting from BaseLLMAgent
Purpose: Generate behavioral coaching for high-risk pets

Method: generate_behavior_coaching(profile)
_________________________________________

Parameters:
- profile: Extracted pet profile

Logic:
1. Create prompt about behavioral management
2. Include pet's behavioral issues and experience level
3. Request JSON with behavioral guidance
4. Call generate_structured_json with temperature 0.6 and max_tokens 1000
5. Return dictionary

Generated Output Fields:
- behavior_assessment: Assessment of behavioral issues
- training_strategies: List of training strategies
- anxiety_management: Anxiety management techniques
- training_timeline: Timeline for behavioral improvement
- when_professional: When to consult professional trainer
- positive_reinforcement_plan: Positive reinforcement strategy
- common_triggers: Common behavioral triggers and mitigation

Return Type: Dictionary with keys:
- behavioral_coaching: Dictionary with 7+ fields
- status: String "success"


CRITICAL PATH: WELLNESS MONITORING LLM AGENT
____________________________________________

Location: agents/wellness_monitoring_llm.py
Type: Class inheriting from BaseLLMAgent
Purpose: Generate wellness monitoring plan for high-risk pets

Method: generate_monitoring_plan(profile, ml_results)
___________________________________________________

Parameters:
- profile: Extracted pet profile
- ml_results: ML prediction scores

Logic:
1. Create prompt about daily, weekly, monthly monitoring
2. Include health risk factors and current conditions
3. Request JSON with monitoring components
4. Call generate_structured_json with temperature 0.5 and max_tokens 1000
5. Return dictionary

Generated Output Fields:
- monitoring_overview: Overview of monitoring strategy
- daily_monitoring: Daily monitoring checklist
- weekly_assessment: Weekly assessment tasks
- monthly_detailed_check: Monthly comprehensive check
- vet_visit_schedule: Recommended veterinary visit schedule
- health_tracking_method: Method for tracking health metrics
- red_flags: Red flags requiring immediate vet attention
- progress_milestone: Milestones for tracking improvement
- long_term_timeline: Long-term monitoring timeline

Return Type: Dictionary with keys:
- wellness_monitoring: Dictionary with 8+ fields
- status: String "success"


PREVENTIVE PATH: HEALTH ASSESSMENT PREVENTIVE LLM AGENT
_______________________________________________________

Location: agents/health_assessment_preventive_llm.py
Type: Class inheriting from BaseLLMAgent
Purpose: Generate preventive health assessment for moderate-risk pets

Method: generate_health_assessment(profile, ml_results)
_____________________________________________________

Parameters:
- profile: Extracted pet profile
- ml_results: ML predictions

Logic:
1. Create prompt about preventive health measures
2. Include pet profile and moderate health risk factors
3. Request JSON with preventive assessment
4. Call generate_structured_json with temperature 0.4 and max_tokens 400
5. Return dictionary

Generated Output Fields:
- preventive_assessment: Assessment of preventive needs
- key_health_areas: Key areas to monitor proactively
- recommended_checkups: Recommended checkup schedule
- prevention_strategies: Specific prevention strategies

Return Type: Dictionary with keys:
- health_assessment: Dictionary with 4 fields
- status: String "success"


PREVENTIVE PATH: NUTRITION PREVENTIVE LLM AGENT
_______________________________________________

Location: agents/nutrition_preventive_llm.py
Type: Class inheriting from BaseLLMAgent
Purpose: Generate preventive nutrition guide

Method: generate_nutrition_guide(profile, ml_results)
___________________________________________________

Parameters:
- profile: Extracted pet profile
- ml_results: ML predictions

Logic:
1. Create prompt about preventive nutrition
2. Request JSON with nutrition components
3. Call generate_structured_json with temperature 0.4 and max_tokens 350

Generated Output Fields:
- nutrition_overview: Overview of nutritional approach
- recommended_diet: Diet recommendations
- portion_guidance: Portion size guidance
- healthy_treats: List of healthy treat options

Return Type: Dictionary with keys:
- nutrition_preventive: Dictionary with 4 fields
- status: String "success"


PREVENTIVE PATH: WELLNESS TRACKING PREVENTIVE LLM AGENT
______________________________________________________

Location: agents/wellness_tracking_preventive_llm.py
Type: Class inheriting from BaseLLMAgent
Purpose: Generate preventive wellness tracking plan

Method: generate_tracking_plan(profile, ml_results)
_________________________________________________

Parameters:
- profile: Extracted pet profile
- ml_results: ML predictions

Logic:
1. Create prompt about proactive wellness tracking
2. Request JSON with tracking components
3. Call generate_structured_json with temperature 0.4 and max_tokens 300

Generated Output Fields:
- tracking_overview: Overview of tracking strategy
- monthly_checklist: Monthly wellness checklist
- wellness_goals: Proactive wellness goals
- early_warning_signs: Early warning signs to watch

Return Type: Dictionary with keys:
- wellness_tracking: Dictionary with 4 fields
- status: String "success"


WELLNESS PATH: WELLNESS OPTIMIZATION LLM AGENT
_____________________________________________

Location: agents/wellness_optimization_llm.py
Type: Class inheriting from BaseLLMAgent
Purpose: Generate wellness optimization for healthy pets

Method: generate_optimization_plan(profile, ml_results)
_____________________________________________________

Parameters:
- profile: Extracted pet profile
- ml_results: ML predictions

Logic:
1. Create prompt about enhancing wellness for healthy pets
2. Request JSON with optimization components
3. Call generate_structured_json with temperature 0.5 and max_tokens 350

Generated Output Fields:
- optimization_overview: Overview of wellness optimization
- wellness_enhancements: Suggested enhancements
- activity_suggestions: Physical activity suggestions
- bonding_activities: Bonding activities

Return Type: Dictionary with keys:
- wellness_optimization: Dictionary with 4 fields
- status: String "success"


WELLNESS PATH: NUTRITION WELLNESS LLM AGENT
___________________________________________

Location: agents/nutrition_wellness_llm.py
Type: Class inheriting from BaseLLMAgent
Purpose: Generate nutrition enhancement for wellness

Method: generate_nutrition_enhancement(profile, ml_results)
_________________________________________________________

Parameters:
- profile: Extracted pet profile
- ml_results: ML predictions

Logic:
1. Create prompt about nutrition enhancement
2. Request JSON with enhancement components
3. Call generate_structured_json with temperature 0.5 and max_tokens 350

Generated Output Fields:
- nutrition_overview: Current nutrition overview
- enhancement_tips: Enhancement tips
- variety_suggestions: Diet variety suggestions
- supplement_options: Optional supplement options

Return Type: Dictionary with keys:
- nutrition_wellness: Dictionary with 4 fields
- status: String "success"


WELLNESS PATH: LIFESTYLE ENRICHMENT LLM AGENT
_____________________________________________

Location: agents/lifestyle_enrichment_llm.py
Type: Class inheriting from BaseLLMAgent
Purpose: Generate lifestyle enrichment for wellness

Method: generate_enrichment_plan(profile, ml_results)
___________________________________________________

Parameters:
- profile: Extracted pet profile
- ml_results: ML predictions

Logic:
1. Create prompt about lifestyle enrichment
2. Request JSON with enrichment components
3. Call generate_structured_json with temperature 0.6 and max_tokens 350

Generated Output Fields:
- enrichment_overview: Enrichment overview
- mental_stimulation: Mental stimulation activities
- social_opportunities: Social interaction opportunities
- environmental_enrichment: Environmental enrichment suggestions

Return Type: Dictionary with keys:
- lifestyle_enrichment: Dictionary with 4 fields
- status: String "success"


4.4 NODE MODULES (nodes/ directory)
__________________________________

All node modules follow consistent pattern:

Pattern Structure:
- Function signature: node_name(state, client=None) -> PetCareState
- All nodes receive PetCareState as parameter
- LLM nodes receive client via default parameter
- All nodes include try-except error handling
- All nodes return modified PetCareState

INPUT VALIDATOR NODE
____________________

Location: nodes/input_validator_node.py
Type: Pure function node
Purpose: Execute input validation as workflow step

Function: input_validator_node(state)
____________________________________

Parameters:
- state: Current PetCareState

Logic:
1. Try block:
   a. Create InputValidatorAgent instance
   b. Extract about_pet, daily_routine, health_concerns from state
   c. Call agent.validate_inputs() with extracted fields
   d. Update state with validation_errors from result
   e. Set parsing_complete boolean
   f. If validation failed, set error_occurred and append errors
   g. Return updated state
2. Except block:
   a. Append error message to error_messages
   b. Set error_occurred to True
   c. Return state

Return Type: PetCareState with validation results


PET PROFILE EXTRACTOR NODE
__________________________

Location: nodes/pet_profile_extractor_node.py
Type: Function node with client parameter
Purpose: Execute profile extraction as workflow step

Function: pet_profile_extractor_node(state, client)
_________________________________________________

Parameters:
- state: Current PetCareState
- client: GeminiClient instance

Logic:
1. Try block:
   a. Create PetProfileExtractorLLMAgent with client
   b. Extract input fields from state
   c. Call agent.extract_pet_profile()
   d. If status success:
      - Extract profile dictionary from result
      - Store extracted_profile in state
      - Flatten 17 profile fields into state
      - Set profile_extraction_complete to True
   e. Otherwise set error flags
   f. Return state
2. Except block:
   a. Append error message
   b. Set error_occurred
   c. Return state

Return Type: PetCareState with extracted profile


PET HEALTH RISK SCORER NODE
___________________________

Location: nodes/pet_health_risk_scorer_node.py
Type: Function node without client parameter
Purpose: Execute ML health risk prediction

Function: pet_health_risk_scorer_node(state)
__________________________________________

Parameters:
- state: Current PetCareState

Logic:
1. Try block:
   a. Create PetHealthRiskScorerMLAgent
   b. Check if extracted_profile exists in state
   c. Call agent.predict_health_risk() with profile
   d. Extract health_risk_score from result
   e. Store in state
   f. Return state
2. Except block:
   a. Append error message
   b. Set error_occurred
   c. Return state

Return Type: PetCareState with health_risk_score


OWNER CARE CAPABILITY NODE
__________________________

Location: nodes/owner_care_capability_node.py
Type: Function node without client parameter
Purpose: Execute ML care capability prediction

Function: owner_care_capability_node(state)
_________________________________________

Parameters:
- state: Current PetCareState

Logic:
1. Try block:
   a. Create OwnerCareCapabilityMLAgent
   b. Extract profile from state
   c. Call agent.predict_capability() with profile
   d. Extract care_capability_score from result
   e. Store in state
   f. Return state
2. Except block:
   a. Append error message
   b. Set error_occurred
   c. Return state

Return Type: PetCareState with care_capability_score


HEALTH RISK ROUTER NODE
_______________________

Location: nodes/health_risk_router_node.py
Type: Pure logic function node
Purpose: Route to appropriate care path based on health risk score

Function: health_risk_router_node(state)
______________________________________

Parameters:
- state: Current PetCareState

Logic:
1. Extract health_risk_score from state (default 0.5)
2. Compare against thresholds:
   a. If > 0.6: Set path_taken to CRITICAL_CARE_PATH
   b. Else if > 0.3: Set path_taken to PREVENTIVE_CARE_PATH
   c. Else: Set path_taken to WELLNESS_PATH
3. Return modified state

Return Type: PetCareState with path_taken set


CRITICAL PATH: PET HEALTH RISK ANALYSIS NODE
___________________________________________

Location: nodes/pet_health_risk_analysis_node.py
Type: Function node with client parameter
Purpose: Execute health risk analysis as workflow step

Function: pet_health_risk_analysis_node(state, client)
____________________________________________________

Parameters:
- state: Current PetCareState
- client: GeminiClient instance

Logic:
1. Try block:
   a. Create PetHealthRiskAnalysisLLMAgent with client
   b. Extract profile and ML results from state
   c. Call agent.generate_risk_analysis()
   d. Extract analysis dictionary from result
   e. Store in state health_risk_analysis_output field
   f. Return state
2. Except block:
   a. Append error message
   b. Set error_occurred
   c. Return state

Return Type: PetCareState with health_risk_analysis_output


CRITICAL PATH: EMERGENCY PREPAREDNESS NODE
__________________________________________

Location: nodes/emergency_preparedness_node.py
Type: Function node with client parameter
Purpose: Execute emergency preparedness planning as workflow step

Function: emergency_preparedness_node(state, client)
__________________________________________________

Parameters:
- state: Current PetCareState
- client: GeminiClient instance

Logic:
1. Try block:
   a. Create EmergencyPreparednessLLMAgent with client
   b. Extract profile and health analysis from state
   c. Call agent.generate_emergency_plan()
   d. Extract emergency plan dictionary from result
   e. Store in state emergency_prep_output field
   f. Return state
2. Except block:
   a. Append error message
   b. Set error_occurred
   c. Return state

Return Type: PetCareState with emergency_prep_output


CRITICAL PATH: NUTRITION CRITICAL NODE
_____________________________________

Location: nodes/nutrition_critical_node.py
Type: Function node with client parameter
Purpose: Execute critical nutrition planning as workflow step

Function: nutrition_critical_node(state, client)
______________________________________________

Parameters:
- state: Current PetCareState
- client: GeminiClient instance

Logic:
1. Try block:
   a. Create NutritionCriticalLLMAgent with client
   b. Extract profile from state
   c. Call agent.generate_nutrition_plan()
   d. Extract nutrition plan dictionary from result
   e. Store in state nutrition_critical_output field
   f. Return state
2. Except block:
   a. Append error message
   b. Set error_occurred
   c. Return state

Return Type: PetCareState with nutrition_critical_output


CRITICAL PATH: BEHAVIORAL COACHING NODE
______________________________________

Location: nodes/behavioral_coaching_node.py
Type: Function node with client parameter
Purpose: Execute behavioral coaching planning as workflow step

Function: behavioral_coaching_node(state, client)
_______________________________________________

Parameters:
- state: Current PetCareState
- client: GeminiClient instance

Logic:
1. Try block:
   a. Create BehavioralCoachingLLMAgent with client
   b. Extract profile from state
   c. Call agent.generate_behavior_coaching()
   d. Extract coaching dictionary from result
   e. Store in state behavioral_coaching_output field
   f. Return state
2. Except block:
   a. Append error message
   b. Set error_occurred
   c. Return state

Return Type: PetCareState with behavioral_coaching_output


CRITICAL PATH: WELLNESS MONITORING NODE
______________________________________

Location: nodes/wellness_monitoring_node.py
Type: Function node with client parameter
Purpose: Execute wellness monitoring planning as workflow step

Function: wellness_monitoring_node(state, client)
_______________________________________________

Parameters:
- state: Current PetCareState
- client: GeminiClient instance

Logic:
1. Try block:
   a. Create WellnessMonitoringLLMAgent with client
   b. Extract profile and ML results from state
   c. Call agent.generate_monitoring_plan()
   d. Extract monitoring plan dictionary from result
   e. Store in state wellness_monitoring_output field
   f. Return state
2. Except block:
   a. Append error message
   b. Set error_occurred
   c. Return state

Return Type: PetCareState with wellness_monitoring_output


PREVENTIVE PATH: HEALTH ASSESSMENT PREVENTIVE NODE
_________________________________________________

Location: nodes/health_assessment_preventive_node.py
Type: Function node with client parameter
Purpose: Execute preventive health assessment as workflow step

Function: health_assessment_preventive_node(state, client)
_________________________________________________________

Parameters:
- state: Current PetCareState
- client: GeminiClient instance

Logic:
1. Try block:
   a. Create HealthAssessmentPreventiveLLMAgent with client
   b. Extract profile and ML results from state
   c. Call agent.generate_health_assessment()
   d. Extract assessment dictionary from result
   e. Store in state health_assessment_output field
   f. Return state
2. Except block:
   a. Append error message
   b. Set error_occurred
   c. Return state

Return Type: PetCareState with health_assessment_output


PREVENTIVE PATH: NUTRITION PREVENTIVE NODE
__________________________________________

Location: nodes/nutrition_preventive_node.py
Type: Function node with client parameter
Purpose: Execute preventive nutrition planning as workflow step

Function: nutrition_preventive_node(state, client)
_________________________________________________

Parameters:
- state: Current PetCareState
- client: GeminiClient instance

Logic:
1. Try block:
   a. Create NutritionPreventiveLLMAgent with client
   b. Extract profile and ML results from state
   c. Call agent.generate_nutrition_guide()
   d. Extract nutrition guide dictionary from result
   e. Store in state nutrition_preventive_output field
   f. Return state
2. Except block:
   a. Append error message
   b. Set error_occurred
   c. Return state

Return Type: PetCareState with nutrition_preventive_output


PREVENTIVE PATH: WELLNESS TRACKING PREVENTIVE NODE
_________________________________________________

Location: nodes/wellness_tracking_preventive_node.py
Type: Function node with client parameter
Purpose: Execute preventive wellness tracking planning as workflow step

Function: wellness_tracking_preventive_node(state, client)
_________________________________________________________

Parameters:
- state: Current PetCareState
- client: GeminiClient instance

Logic:
1. Try block:
   a. Create WellnessTrackingPreventiveLLMAgent with client
   b. Extract profile and ML results from state
   c. Call agent.generate_tracking_plan()
   d. Extract tracking plan dictionary from result
   e. Store in state wellness_tracking_output field
   f. Return state
2. Except block:
   a. Append error message
   b. Set error_occurred
   c. Return state

Return Type: PetCareState with wellness_tracking_output


WELLNESS PATH: WELLNESS OPTIMIZATION NODE
_________________________________________

Location: nodes/wellness_optimization_node.py
Type: Function node with client parameter
Purpose: Execute wellness optimization planning as workflow step

Function: wellness_optimization_node(state, client)
__________________________________________________

Parameters:
- state: Current PetCareState
- client: GeminiClient instance

Logic:
1. Try block:
   a. Create WellnessOptimizationLLMAgent with client
   b. Extract profile and ML results from state
   c. Call agent.generate_optimization_plan()
   d. Extract optimization plan dictionary from result
   e. Store in state wellness_optimization_output field
   f. Return state
2. Except block:
   a. Append error message
   b. Set error_occurred
   c. Return state

Return Type: PetCareState with wellness_optimization_output


WELLNESS PATH: NUTRITION WELLNESS NODE
_____________________________________

Location: nodes/nutrition_wellness_node.py
Type: Function node with client parameter
Purpose: Execute wellness nutrition enhancement as workflow step

Function: nutrition_wellness_node(state, client)
______________________________________________

Parameters:
- state: Current PetCareState
- client: GeminiClient instance

Logic:
1. Try block:
   a. Create NutritionWellnessLLMAgent with client
   b. Extract profile and ML results from state
   c. Call agent.generate_nutrition_enhancement()
   d. Extract nutrition enhancement dictionary from result
   e. Store in state nutrition_wellness_output field
   f. Return state
2. Except block:
   a. Append error message
   b. Set error_occurred
   c. Return state

Return Type: PetCareState with nutrition_wellness_output


WELLNESS PATH: LIFESTYLE ENRICHMENT NODE
_______________________________________

Location: nodes/lifestyle_enrichment_node.py
Type: Function node with client parameter
Purpose: Execute lifestyle enrichment planning as workflow step

Function: lifestyle_enrichment_node(state, client)
_________________________________________________

Parameters:
- state: Current PetCareState
- client: GeminiClient instance

Logic:
1. Try block:
   a. Create LifestyleEnrichmentLLMAgent with client
   b. Extract profile and ML results from state
   c. Call agent.generate_enrichment_plan()
   d. Extract enrichment plan dictionary from result
   e. Store in state lifestyle_enrichment_output field
   f. Return state
2. Except block:
   a. Append error message
   b. Set error_occurred
   c. Return state

Return Type: PetCareState with lifestyle_enrichment_output


OUTPUT AGGREGATOR NODE
______________________

Location: nodes/output_aggregator_node.py
Type: Pure logic function node
Purpose: Aggregate all outputs based on care path

Function: output_aggregator_node(state)
_____________________________________

Parameters:
- state: Current PetCareState

Logic:
1. Extract path_taken from state
2. Create aggregated dictionary based on path:
   a. CRITICAL_CARE_PATH:
      - Include 5 critical path outputs
      - health_risk_analysis, emergency_preparedness, nutrition_plan, behavioral_coaching, wellness_monitoring
   b. PREVENTIVE_CARE_PATH:
      - Include 3 preventive path outputs
      - health_assessment, nutrition_guide, wellness_tracking
   c. WELLNESS_PATH:
      - Include 3 wellness path outputs
      - wellness_optimization, nutrition_enhancement, lifestyle_enrichment
3. Store aggregated dictionary in state
4. Set processing_complete to True
5. Return state

Return Type: PetCareState with aggregated_output


4.5 ML PIPELINE MODULES (ml/ directory)
_______________________________________

TRAIN PIPELINE ORCHESTRATOR
____________________________

Location: ml/train_pipeline.py
Type: Module with single orchestration function
Purpose: Orchestrate complete ML training pipeline

Function: run_full_pipeline(training_dir, evaluation_dir, output_dir, processed_dir)
________________________________________________________________________________

Parameters:
- training_dir: Path to directory containing raw training CSV files
- evaluation_dir: Path to directory containing evaluation CSV files
- output_dir: Path to save trained model pickle files
- processed_dir: Optional path to save cleaned data

Logic:
Step 1: Data Cleaning
1. Call clean_health_risk_dataset() on pet_health_risk_training.csv
2. Call clean_care_capability_dataset() on owner_care_capability_training.csv
3. Save cleaned data if processed_dir provided
4. Report status

Step 2: Model Training
1. Call train_health_risk_model() with cleaned health risk data
2. Call train_care_capability_model() with cleaned capability data
3. Models save pickle artifacts to output_dir
4. Capture training metrics

Step 3: Model Evaluation
1. Call evaluate_all_models() on evaluation datasets
2. Compute evaluation metrics (R-squared, MAE, RMSE)
3. Report results

4. Aggregate all results into results dictionary
5. Return complete results

Return Type: Dictionary with keys:
- status: String "started" or "success" or "failed"
- steps: Dictionary containing results for each pipeline step


HEALTH RISK DATA CLEANING
_________________________

Location: ml/data_cleaning/clean_health_risk_data.py
Type: Module with single cleaning function
Purpose: Clean pet health risk training dataset

Function: clean_health_risk_dataset(input_file)
______________________________________________

Parameters:
- input_file: Path to raw pet_health_risk_training.csv

Logic:
1. Load CSV into DataFrame
2. Standardize categorical values:
   a. Convert to lowercase
   b. Check against valid values list
   c. Replace invalid with mode (most common valid value)
   d. Process: pet_species, weight_status, living_situation, exercise_level
3. Remove rows with NaN in numerical columns:
   a. age_years, conditions_count, allergies_count, health_risk_score
4. Remove extreme outliers using 3xIQR method:
   a. Calculate Q1, Q3, IQR for age_years and conditions_count
   b. Remove rows outside (Q1 - 3×IQR) to (Q3 + 3×IQR) bounds
5. Clip range values to valid bounds:
   a. health_risk_score clipped to [0.0, 1.0]
6. Reset index
7. Return cleaned DataFrame

Return Type: Pandas DataFrame with cleaned data


CARE CAPABILITY DATA CLEANING
_____________________________

Location: ml/data_cleaning/clean_care_capability_data.py
Type: Module with single cleaning function
Purpose: Clean owner care capability training dataset

Function: clean_care_capability_dataset(input_file)
__________________________________________________

Parameters:
- input_file: Path to raw owner_care_capability_training.csv

Logic:
1. Load CSV into DataFrame
2. Remove rows with NaN values (complete case analysis)
3. Standardize categorical values:
   a. Convert to lowercase
   b. Replace invalid with mode
   c. Process: owner_experience, vet_access, owner_commitment
4. Validate care_capability_score in range [0, 100]
5. Clip values outside range
6. Reset index
7. Return cleaned DataFrame

Return Type: Pandas DataFrame with cleaned data


HEALTH RISK MODEL TRAINING
__________________________

Location: ml/train_model/train_health_risk_model.py
Type: Module with single training function
Purpose: Train regressor for health risk prediction

Function: train_health_risk_model(training_file, output_dir)
__________________________________________________________

Parameters:
- training_file: Path to cleaned training CSV (pet_health_risk_clean.csv)
- output_dir: Directory to save model artifacts

Logic:
1. Load cleaned training data from pet_health_risk_clean.csv
2. Define features:
   a. Categorical: pet_species, weight_status, living_situation, exercise_level
   b. Numerical: age_years, conditions_count, allergies_count
3. Encode categorical features using LabelEncoder
4. Build feature matrix X with 7 columns
5. Build target vector y from health_risk_score
6. Split into 80% train, 20% test
7. Scale features using StandardScaler
8. Create regressor with optimized hyperparameters for regression
9. Train model on scaled training data
10. Evaluate on both train and test sets
11. Save three artifacts:
    a. pet_health_risk_model.pkl containing trained regressor
    b. pet_health_risk_scaler.pkl containing StandardScaler
    c. pet_health_risk_encoder.pkl containing dictionary of LabelEncoders
12. Collect metrics and return

Return Type: Dictionary with keys:
- status: String "success"
- train_r2: Float R-squared on training data
- test_r2: Float R-squared on test data
- model_type: String "regressor"
- n_features: Integer number of features (7)
- training_samples: Integer count
- test_samples: Integer count


CARE CAPABILITY MODEL TRAINING
______________________________

Location: ml/train_model/train_care_capability_model.py
Type: Module with single training function
Purpose: Train regressor for care capability prediction

Function: train_care_capability_model(training_file, output_dir)
______________________________________________________________

Parameters:
- training_file: Path to cleaned training CSV (owner_care_capability_clean.csv)
- output_dir: Directory to save model artifacts

Logic:
1. Load cleaned training data from owner_care_capability_clean.csv
2. Define features:
   a. Categorical: owner_experience, vet_access, owner_commitment
   b. (Only 3 features for this model)
3. Encode categorical features using LabelEncoder
4. Build feature matrix X with 3 columns
5. Build target vector y from care_capability_score
6. Split into 80% train, 20% test
7. Scale features using StandardScaler
8. Create regressor with optimized hyperparameters for regression
9. Train model
10. Evaluate on both sets
11. Save three artifacts as pickle files:
    a. owner_care_capability_model.pkl containing trained regressor
    b. owner_care_capability_scaler.pkl containing StandardScaler
    c. owner_care_capability_encoder.pkl containing LabelEncoders
12. Return metrics dictionary

Return Type: Dictionary with keys:
- status: String "success"
- train_r2: Float R-squared
- test_r2: Float R-squared
- model_type: String "regressor"
- n_features: Integer (3)
- training_samples: Integer count
- test_samples: Integer count


MODEL EVALUATION
________________

Location: ml/evaluation/evaluate_models.py
Type: Module with evaluation functions
Purpose: Evaluate trained models on evaluation datasets

Function: evaluate_all_models(evaluation_dir, model_dir)
_____________________________________________________

Parameters:
- evaluation_dir: Path to evaluation CSV files
- model_dir: Path to saved model artifacts

Logic:
1. Load evaluation datasets
2. Load trained models and artifacts from pickle files
3. For each model:
   a. Load evaluation data
   b. Extract features (same as training)
   c. Scale features using trained scaler
   d. Generate predictions
   e. Calculate metrics:
      - Mean Squared Error (MSE)
      - Mean Absolute Error (MAE)
      - Root Mean Squared Error (RMSE)
      - R-squared Score
   f. Collect results
4. Return comprehensive evaluation results

Return Type: Dictionary with keys:
- models: Dictionary containing evaluation results for each model
  - health_risk: Dictionary with metrics
  - care_capability: Dictionary with metrics
Each model result contains:
  - status: String "success"
  - test_samples: Integer count
  - r2_score: Float R-squared
  - mae: Float mean absolute error
  - rmse: Float root mean squared error


4.6 WORKFLOW MODULE (workflow/ directory)
_________________________________________

WORKFLOW METADATA FUNCTIONS
____________________________

Location: workflow/workflow.py
Type: Module with metadata utility functions
Purpose: Provide workflow configuration and metadata

Function: get_routing_logic()
___________________________

Purpose: Define routing thresholds and path conditions

Logic:
1. Build dictionary describing routing rules
2. Include:
   a. routing_field: String "health_risk_score"
   b. routing_type: String "conditional_edges"
   c. paths: Dictionary with 3 path definitions
      Each path contains:
      - description: String explaining path purpose
      - condition: String with threshold condition
      - execution_strategy: String naming strategy
      - token_budget: Integer max tokens for path
      - nodes_count: Integer nodes in path

Return Type: Dictionary with routing configuration


Function: get_parallel_execution_info()
______________________________________

Purpose: Define which nodes can execute in parallel

Logic:
1. Build dictionary describing parallelization opportunities
2. Identify parallel_stages:
   a. ML Prediction stage
      - pet_health_risk_scorer and owner_care_capability run in parallel
      - Both depend on health_risk_router merge
3. List sequential_stages in order
4. Include descriptions

Return Type: Dictionary with parallelization info


Function: get_token_budget_info()
________________________________

Purpose: Define token budgets for different components

Logic:
1. Build dictionary with token estimates
2. Include:
   a. total_tokens_per_path: Budget per care path
   b. tokens_per_agent: Budget for each LLM agent
   c. ml_tokens: Budget for ML operations

Return Type: Dictionary with token budget breakdown


Function: get_execution_strategy()
________________________________

Purpose: Describe overall workflow execution approach

Logic:
1. Build dictionary with execution details
2. Include:
   a. execution_model: String describing model type
   b. state_management: String describing state handling
   c. error_handling: String describing error strategy
   d. client_pattern: String describing dependency injection
   e. compilation_strategy: String describing graph compilation
   f. invocation_method: String describing entry point

Return Type: Dictionary with execution strategy


4.7 GRAPH ORCHESTRATION MODULE (graph.py - Extended)
____________________________________________________

Function: build_petcare_graph(client)
____________________________________

Purpose: Build complete LangGraph state machine with all nodes and edges

Parameters:
- client: GeminiClient instance for LLM nodes

Logic:
1. Create StateGraph with PetCareState as schema
2. Add 17 nodes:
   a. input_validator: Direct function reference
   b. pet_profile_extractor: Lambda wrapping with client injection
   c. pet_health_risk_scorer: Direct reference
   d. owner_care_capability: Direct reference
   e. health_risk_router: Direct reference
   f. 11 path-specific agents: Lambda wrapped with client
   g. output_aggregator: Direct reference

3. Define edges (connections):
   a. Sequential edges for linear progression
   b. Parallel edges: ML nodes after profile extraction
   c. Conditional edges: Health risk router to 3 different starting nodes
   d. Path-specific sequences: 3-5 nodes per path
   e. Convergence: All paths to output_aggregator
   f. Final edge to END

4. Define conditional routing function:
   a. Routes based on path_taken field
   b. Returns string key for edge selection

5. Compile graph using compile() method
6. Return compiled, executable graph

Return Type: Compiled LangGraph.StateGraph ready for invocation


Function: assess_pet_health(form_data)
_____________________________________

Purpose: Main entry point for pet health assessment workflow

Parameters:
- form_data: Dictionary with about_pet, daily_routine, health_concerns

Logic:
1. Add metadata to form_data:
   a. Generate request_id using UUID4
   b. Add analysis_timestamp as ISO format
2. Call get_initial_state(form_data) to initialize state
3. Create GeminiClient instance
4. Build complete graph via build_petcare_graph()
5. Try block:
   a. Invoke graph with initial state: graph.invoke(state)
   b. Set processing_complete to True
   c. Return final state
6. Except block:
   a. Set error_occurred to True
   b. Append error message
   c. Set processing_complete to False
   d. Return state with errors

Return Type: Complete PetCareState dictionary with all results


Function: get_pet_health_summary(assessment_result)
_________________________________________________

Purpose: Extract and structure key findings from assessment

Parameters:
- assessment_result: Complete state dictionary from assessment

Logic:
1. Extract path_taken from result
2. Build summary dictionary with sections:
   a. pet_profile: Extracted profile fields (species, breed, age, weight, conditions)
   b. health_assessment: ML predictions (health_risk_score, care_capability_score)
   c. path_analysis: Care path and urgency level
   d. outputs: Path-specific outputs dictionary
      - Different structure based on path taken
   e. system: Metadata (request_id, timestamp, errors)
3. Return structured summary

Return Type: Dictionary with summary structure


4.8 STREAMLIT UI MODULE (main.py)
__________________________________

Module Purpose:
Web interface built with Streamlit framework providing:
1. User input form for pet health assessment
2. Results display in organized tabs
3. Session state management
4. Model evaluation trigger and display
5. JSON export functionality

Key Functions:

Function: initialize_session_state()
__________________________________

Purpose: Initialize Streamlit session state variables

Logic:
1. Check if assessment_result in session_state, create if missing
2. Check if eval_results in session_state, create if missing
3. Check if run_evaluation flag in session_state, create if missing
4. Check if show_clarification flag in session_state, create if missing
5. Check if user_clarification dict in session_state, create if missing

Return: None (modifies st.session_state)


Function: export_assessment(assessment)
______________________________________

Purpose: Format assessment results as JSON string for download

Parameters:
- assessment: Complete assessment result dictionary

Logic:
1. Create export_data dictionary with:
   a. metadata: request_id and timestamp
   b. assessment: complete assessment dictionary
2. Convert to JSON string with indentation
3. Return JSON string

Return Type: String containing formatted JSON


Function: display_overview_tab(result)
____________________________________

Purpose: Display overview tab with summary metrics

Logic:
1. Display three metric cards:
   a. Health Risk Score (percentage)
   b. Care Capability Score (0-100)
   c. Care Path (CRITICAL/PREVENTIVE/WELLNESS)
2. Display care path description
3. Display key findings and metrics
4. Show assessment details overview

Return: None (renders UI elements)


Function: display_guidance_tab(result)
____________________________________

Purpose: Display path-specific guidance based on care path

Logic:
1. Get path_taken from result
2. If CRITICAL_CARE_PATH:
   a. Display health risk analysis
   b. Display emergency preparedness
   c. Display nutrition plan
   d. Display behavioral coaching
   e. Display wellness monitoring
3. If PREVENTIVE_CARE_PATH:
   a. Display health assessment
   b. Display nutrition guide
   c. Display wellness tracking
4. If WELLNESS_PATH:
   a. Display wellness optimization
   b. Display nutrition enhancement
   c. Display lifestyle enrichment
5. Expand output dictionaries and display fields

Return: None (renders UI elements)


Function: display_health_analysis_tab(result)
___________________________________________

Purpose: Display pet profile and detailed health analysis

Logic:
1. Display extracted pet profile information in columns
2. Display health metrics (scores and risk levels)
3. Display path-specific analysis dashboard
4. Show immediate actions and monitoring schedule

Return: None (renders UI elements)


Function: display_model_evaluation_section(eval_results)
______________________________________________________

Purpose: Display ML model evaluation metrics

Logic:
1. Check if eval_results contains model metrics
2. Display health risk model metrics:
   a. Test samples count
   b. R-squared score
   c. Mean Absolute Error
   d. Root Mean Squared Error
3. Display care capability model metrics
4. Show formatted metrics in metric cards

Return: None (renders UI elements)


Function: main()
_______________

Purpose: Main Streamlit application entry point

Logic:
1. Configure page (title, layout, sidebar state)
2. Display page title and description
3. Initialize session state
4. Display sidebar with project info and tools
5. Check if assessment exists:
   a. If no: Display assessment form
      - Three text area inputs
      - Generate Assessment button
      - Clear Form button
      - Form submission logic
   b. If yes: Display results
      - New Assessment button
      - Download JSON button
      - Four result tabs (Overview, Guidance, Analysis, Summary)
6. Handle model evaluation:
   a. Load models from directories
   b. Run evaluation
   c. Display results
7. Rerun UI on state changes

Return: None (runs Streamlit application)


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


SECTION 5: UI DESIGN AND LAYOUT
================================

5.1 MAIN INTERFACE STRUCTURE
____________________________

Page Configuration:
- Title: "PawCare+ - Pet Health & Care Guidance System"
- Layout: Wide (full width)
- Sidebar: Expanded on load

5.2 SIDEBAR SECTION
___________________

Content:
1. Project Title: "About PawCare+"
2. Feature Description:
   - Pet health risk assessment using machine learning
   - Owner care capability analysis
   - Personalized health guidance and care planning
   - Emergency preparedness planning
   - Nutrition and behavioral recommendations
   - Wellness monitoring strategies
3. Divider Line
4. Tools Section:
   - Run Model Evaluation button

5.3 MAIN CONTENT AREA - FORM STATE
__________________________________

When no assessment completed:

Section: "Pet Health Assessment Form"
Subtitle: "Please provide information about your pet's health, daily routine, and current concerns."

Two-Column Layout:
Left Column:
- Text Area: "About Your Pet"
  - Placeholder: "Describe your pet - breed, age, health history, personality, etc."
  - Height: 120 pixels
  - Help: "Provide details about your pet's species, breed, age, and any known health conditions"

Right Column:
- Text Area: "Daily Routine & Living Situation"
  - Placeholder: "Exercise, diet, living environment, behavioral patterns, owner experience, etc."
  - Height: 120 pixels
  - Help: "Describe your pet's daily schedule, exercise routine, and living conditions"

Full Width:
- Text Area: "Current Health Concerns"
  - Placeholder: "Current symptoms, behavioral issues, dietary concerns, vet visits, medications, etc."
  - Height: 120 pixels
  - Help: "Describe any current health issues or concerns you have about your pet"

Divider Line

Three-Column Button Layout:
- Column 1: "Generate Assessment" (Primary button, full width)
- Column 2: "Clear Form" (Secondary button, full width)
- Column 3: Empty (for spacing)

5.4 MAIN CONTENT AREA - RESULTS STATE
_____________________________________

When assessment completed:

Top Controls:
- Three-Column Layout:
  - Column 1 (wider): "Assessment Results" heading
  - Column 2: "New Assessment" button
  - Column 3: "Download JSON" button (green, with download icon)

Divider Line

Four Tabs:

TAB 1: OVERVIEW
_______________

Three-Column Metric Display:
- Column 1: Health Risk Score (percentage format)
- Column 2: Care Capability Score (0-100 format)
- Column 3: Care Path (CRITICAL/PREVENTIVE/WELLNESS)

Divider Line

"Pet Health Status" Section:
- Display care path label and description

Divider Line

"Assessment Details" Section:
Two Columns:
- Left: Brief health assessment summary
- Right: Key metrics display with scores and path


TAB 2: HEALTH GUIDANCE
______________________

Dynamic Content Based on Path:

CRITICAL CARE PATH Content:

Bordered Container 1: "Health Risk Analysis"
- Honest Risk Assessment (paragraph)
- Critical Risk Factors (bulleted list)
- Warning Signs to Monitor (bulleted list)
- Urgency Timeline (text)
- Recommended Actions (bulleted list)

Divider Line

Bordered Container 2: "Emergency Preparedness"
- Overview (text)
- Emergency Contacts (list)
- First Aid Supplies Needed (two-column list)
- Crisis Procedures (list)
- When to Call Veterinarian (text)

Divider Line

Bordered Container 3: "Nutrition Critical Plan"
- Overview (text)
- Recommended Diet (list)
- Feeding Schedule (list)
- Foods to Avoid (list)
- Recommended Supplements (list)
- Portion Guidance (text)

Divider Line

Bordered Container 4: "Behavioral Coaching"
- Behavior Assessment (text or list)
- Training Strategies (list)
- Anxiety Management (text or list)
- Positive Reinforcement (text or list)

Divider Line

Bordered Container 5: "Wellness Monitoring Plan"
- Overview (text)
- Daily Monitoring (list)
- Weekly Assessment (list)
- Vet Visit Schedule (list)
- Health Metrics to Track (list)
- Red Flags to Watch (list)

PREVENTIVE CARE PATH Content:

Bordered Container 1: "Health Assessment"
- Preventive Assessment (text)
- Key Health Areas to Monitor (list)
- Recommended Checkups (text)
- Prevention Strategies (list)

Divider Line

Bordered Container 2: "Nutrition Guide"
- Nutrition Overview (text)
- Diet Recommendations (text)
- Portion Guidance (text)
- Healthy Treat Options (two-column list)

Divider Line

Bordered Container 3: "Wellness Tracking Plan"
- Tracking Overview (text)
- Monthly Wellness Checklist (list)
- Wellness Goals (list)
- Early Warning Signs to Watch (list)

WELLNESS PATH Content:

Bordered Container 1: "Wellness Optimization"
- Optimization Overview (text)
- Wellness Enhancements (list)
- Activity Suggestions (list)
- Bonding Activities (list)

Divider Line

Bordered Container 2: "Nutrition Enhancement"
- Nutrition Overview (text)
- Enhancement Tips (list)
- Diet Variety (text)
- Optional Supplements (list)

Divider Line

Bordered Container 3: "Lifestyle Enrichment"
- Enrichment Overview (text)
- Mental Stimulation Activities (list)
- Social Opportunities (list)
- Environmental Enrichment (list)


TAB 3: DETAILED ANALYSIS
________________________

Bordered Container 1: "Pet Profile Information"
Three Columns:
- Column 1: Species, Breed, Age
- Column 2: Weight Status, Sex, Living Situation
- Column 3: Exercise Level, Diet Type, Known Conditions

Divider Line

Bordered Container 2: "Health Assessment Metrics"
Two Columns:
- Column 1: Health Risk Score + Risk Level
- Column 2: Owner Care Capability + Capability Level

Divider Line

Path-Specific Monitoring Dashboard:
If CRITICAL PATH:
- Two columns showing Immediate Actions and Monitoring Schedule

Status displays for:
- Risk factors
- Emergency preparedness
- Monitoring protocols
- Vet scheduling


TAB 4: SUMMARY
______________

Bordered Container 1: "Pet Profile"
Two Columns:
- Species, Breed, Age (left)
- Weight Status, Conditions (right)

Divider Line

Bordered Container 2: "Health Assessment"
Two Column Metrics:
- Health Risk Score
- Care Capability Score

Divider Line

Bordered Container 3: "Care Path Analysis"
- Path Name (displayed)
- Urgency Level (displayed)

Divider Line

Bordered Container 4: "Assessment Information"
Two Columns:
- Request ID
- Timestamp

5.5 MODEL EVALUATION SECTION
____________________________

Display Section Title: "Model Evaluation Metrics"
Subtitle: "Performance metrics of trained machine learning models on evaluation datasets"

Two-Column Layout:

Left Column: "Pet Health Risk Scorer Model"
- Status check
- Four metric cards:
  a. Test Samples (count)
  b. R-squared Score (4 decimal places)
  c. Mean Absolute Error (4 decimal places)
  d. Root Mean Squared Error (4 decimal places)

Right Column: "Owner Care Capability Model"
- Same metric structure as health risk model

If models not available:
- Display info message with instructions to run evaluation


5.6 COLOR AND FORMATTING
________________________

Color Scheme:
- Primary: Blue (buttons, metrics)
- Success: Green (completion, download)
- Error: Red (error messages)
- Warning: Orange/Yellow (caution items)

Formatting:
- Bordered containers for logical grouping
- Divider lines for visual separation
- Column layouts for multi-item display
- Bulleted lists for multi-item text
- Metric cards for numerical values
- Tabbed interface for large content sections


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


SECTION 6: RUNNING COMMANDS AND EXECUTION FLOW
===============================================

6.1 SETUP AND INSTALLATION
__________________________

Step 1: Install Python Dependencies
Command: pip install -r installation.txt

Dependencies installed:
- streamlit: Web UI framework
- langgraph: Workflow orchestration
- langchain: LLM abstractions
- google-genai: Gemini API SDK (new or old version)
- scikit-learn: Machine learning models
- pandas: Data processing
- numpy: Numerical computing
- python-dotenv: Environment configuration
- joblib: Model serialization
- pydantic: Data validation


Step 2: Configure Environment Variables
Action: Create .env file in project root with:
- GEMINI_API_KEY: Primary API key
- GEMINI_API_KEY_1 through GEMINI_API_KEY_4: Backup keys (optional)
- GEMINI_MODEL: Model name (default: gemini-2.5-flash-lite)

Note: Alternative - Use Streamlit secrets in .streamlit/secrets.toml for cloud deployment


6.2 DATA PREPARATION PIPELINE
_____________________________

Note: Training and evaluation datasets are already provided in the project.

Step 1: Clean Training Data
Command: python -c "from ml.data_cleaning.clean_health_risk_data import clean_health_risk_dataset; df = clean_health_risk_dataset('data/training_dataset/pet_health_risk_training.csv'); print(f'Cleaned: {len(df)} rows')"

Or via pipeline (see Step 6):

Actions:
- Standardize categorical values to valid options
- Remove NaN values from numerical columns
- Remove extreme outliers (3xIQR method)
- Clip range values to valid bounds
- Preserve class balance

Similar for care capability data cleaning


6.3 MODEL TRAINING PIPELINE
____________________________

Method 1: Run Complete Pipeline

Command: python ml/train_pipeline.py

This orchestrates:

Step 1: Data Cleaning
- Cleans both health_risk and care_capability datasets
- Saves cleaned data to data/processed/

Step 2: Model Training
- Trains GradientBoostingRegressor for health risk
  - 100 estimators, 0.1 learning rate, max_depth 5
  - 7 features (species, weight, living, exercise, age, conditions, allergies)
  - Achieves R² ~0.85-0.90 on test data

- Trains RandomForestRegressor for care capability
  - 100 estimators
  - 3 features (experience, vet_access, commitment)
  - Achieves R² ~0.80-0.85 on test data

- Saves 6 pickle artifacts to ml/models/:
  - pet_health_risk_model.pkl
  - pet_health_risk_scaler.pkl
  - pet_health_risk_encoder.pkl
  - owner_care_capability_model.pkl
  - owner_care_capability_scaler.pkl
  - owner_care_capability_encoder.pkl

Step 3: Model Evaluation
- Evaluates both models on evaluation datasets
- Computes metrics: R², MAE, RMSE
- Reports performance

Output: Pipeline completion report with status and metrics


Method 2: Manual Step-by-Step

Command 2.1: Clean Health Risk Data
python ml/data_cleaning/clean_health_risk_data.py

Command 2.2: Clean Care Capability Data
python ml/data_cleaning/clean_care_capability_data.py

Command 2.3: Train Health Risk Model
python ml/train_model/train_health_risk_model.py

Command 2.4: Train Care Capability Model
python ml/train_model/train_care_capability_model.py

Command 2.5: Evaluate Models
python ml/evaluation/evaluate_models.py


6.4 APPLICATION STARTUP
_______________________

Command: streamlit run main.py

Actions:
1. Streamlit loads application
2. Initializes Streamlit runtime
3. Loads configuration from .streamlit/config.toml (if exists)
4. Starts local web server (default: localhost:8501)
5. Renders main.py
6. Displays application in browser

Output: Web application available at http://localhost:8501


6.5 USER WORKFLOW IN APPLICATION
_________________________________

Step 1: Form Submission
User Actions:
1. Enter text in "About Your Pet" field
2. Enter text in "Daily Routine & Living Situation" field
3. Enter text in "Current Health Concerns" field
4. Click "Generate Assessment" button

Backend Processing:
1. Validate input lengths (10-3000 characters)
2. Display loading spinner
3. Invoke assess_pet_health() from graph.py


Step 2: Assessment Execution Flow
Graph Execution Sequence:

1. input_validator_node
   - Validates 3 text fields
   - Returns validation status

2. pet_profile_extractor_node
   - Uses Gemini LLM to extract 17 profile fields
   - Temperature 0.3 (deterministic)
   - Max tokens 900

3. [PARALLEL EXECUTION]
   - pet_health_risk_scorer_node
     - Loads health risk model, scaler, encoder
     - Creates 7-feature array
     - Predicts health_risk_score (0-1)

   - owner_care_capability_node
     - Loads capability model, scaler, encoder
     - Creates 3-feature array
     - Predicts care_capability_score (0-100)

4. health_risk_router_node
   - Routes based on health_risk_score:
     > 0.6 = CRITICAL_CARE_PATH
     0.3-0.6 = PREVENTIVE_CARE_PATH
     < 0.3 = WELLNESS_PATH

5. [CONDITIONAL EXECUTION - CRITICAL CARE PATH]
   If health_risk_score > 0.6:
   a. pet_health_risk_analysis_node
      - Generates health risk analysis
      - 5 fields output
      - Temperature 0.5, max_tokens 1000

   b. emergency_preparedness_node
      - Generates emergency planning
      - 8 fields output
      - Temperature 0.5, max_tokens 1200

   c. nutrition_critical_node
      - Generates critical nutrition plan
      - 7+ fields output
      - Temperature 0.5, max_tokens 1200

   d. behavioral_coaching_node
      - Generates behavior guidance
      - 7+ fields output
      - Temperature 0.6, max_tokens 1000

   e. wellness_monitoring_node
      - Generates monitoring plan
      - 8+ fields output
      - Temperature 0.5, max_tokens 1000

6. [CONDITIONAL EXECUTION - PREVENTIVE CARE PATH]
   If 0.3 < health_risk_score <= 0.6:
   a. health_assessment_preventive_node
      - Generates preventive health assessment
      - 4 fields output
      - Temperature 0.4, max_tokens 400

   b. nutrition_preventive_node
      - Generates nutrition guide
      - 4 fields output
      - Temperature 0.4, max_tokens 350

   c. wellness_tracking_preventive_node
      - Generates tracking plan
      - 4 fields output
      - Temperature 0.4, max_tokens 300

7. [CONDITIONAL EXECUTION - WELLNESS PATH]
   If health_risk_score <= 0.3:
   a. wellness_optimization_node
      - Generates wellness optimization
      - 4 fields output
      - Temperature 0.5, max_tokens 350

   b. nutrition_wellness_node
      - Generates nutrition enhancement
      - 4 fields output
      - Temperature 0.5, max_tokens 350

   c. lifestyle_enrichment_node
      - Generates enrichment plan
      - 4 fields output
      - Temperature 0.6, max_tokens 350

8. output_aggregator_node
   - Combines all path outputs into aggregated_output
   - Sets processing_complete to True


Step 3: Results Display
Actions:
1. Display success message
2. Store result in session_state
3. Display four tabs with results
4. Enable "New Assessment" and "Download JSON" buttons


Step 4: Export Results
User Action: Click "Download JSON" button

Action:
1. Format assessment result as JSON
2. Generate filename with request_id
3. Browser downloads JSON file


Step 5: Model Evaluation (Optional)
User Action: Click "Run Model Evaluation" in sidebar

Actions:
1. Locate model artifacts in ml/models/
2. Locate evaluation data in data/evaluation_dataset/
3. Load models and evaluation data
4. Compute predictions and metrics
5. Display metrics in UI


6.6 EXECUTION ENTRY POINTS
__________________________

Main Application Entry Point:
File: main.py
Command: streamlit run main.py
Output: Web interface at localhost:8501

ML Pipeline Entry Point:
File: ml/train_pipeline.py
Command: python ml/train_pipeline.py
Output: Trained models in ml/models/

Assessment Workflow Entry Point:
File: graph.py, Function: assess_pet_health()
Called from: main.py UI button click
Output: Complete assessment result dictionary


6.7 ENVIRONMENT SETUP CHECKLIST
_______________________________

Prerequisites:
Requirement 1: Python 3.9 or higher installed
Requirement 2: pip package manager available
Requirement 3: Internet connection for API calls

Setup Steps:
Step 1: Clone or download project to local machine
Step 2: Navigate to project root directory
Step 3: Create virtual environment (recommended):
        python -m venv venv
        source venv/bin/activate (Linux/Mac)
        venv\Scripts\activate (Windows)
Step 4: Install dependencies: pip install -r installation.txt
Step 5: Create .env file with API keys
Step 6: Train models: python ml/train_pipeline.py
Step 7: Launch application: streamlit run main.py


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


SECTION 7: OUTPUT AND RESULTS
==============================

7.1 ASSESSMENT OUTPUT STRUCTURE
_______________________________

The complete assessment returns a PetCareState dictionary with following structure:

System Metadata Section:
- request_id: Unique UUID for the assessment
- analysis_timestamp: ISO format timestamp
- error_occurred: Boolean flag
- error_messages: List of error messages if any
- processing_complete: Boolean flag

Input Data Section:
- about_pet: Original user input
- daily_routine: Original user input
- health_concerns: Original user input

Extracted Profile Section:
- extracted_profile: Full dictionary with all 17 fields
- profile_extraction_complete: Boolean
- All 17 individual profile fields (pet_species, breed, age_years, etc)
- Flattened for easy access

ML Prediction Section:
- health_risk_score: Float 0.0 to 1.0 (higher = more risk)
- care_capability_score: Float 0.0 to 100.0 (higher = more capable)

Routing Decision Section:
- path_taken: String (CRITICAL_CARE_PATH, PREVENTIVE_CARE_PATH, or WELLNESS_PATH)

Output Sections (path-dependent):

If CRITICAL_CARE_PATH:
- health_risk_analysis_output: Dictionary with 5 fields
- emergency_prep_output: Dictionary with 8 fields
- nutrition_critical_output: Dictionary with 7+ fields
- behavioral_coaching_output: Dictionary with 7+ fields
- wellness_monitoring_output: Dictionary with 8+ fields

If PREVENTIVE_CARE_PATH:
- health_assessment_output: Dictionary with 4 fields
- nutrition_preventive_output: Dictionary with 4 fields
- wellness_tracking_output: Dictionary with 4 fields

If WELLNESS_PATH:
- wellness_optimization_output: Dictionary with 4 fields
- nutrition_wellness_output: Dictionary with 4 fields
- lifestyle_enrichment_output: Dictionary with 4 fields

Final Aggregation Section:
- aggregated_output: Dictionary combining path-specific outputs


7.2 CRITICAL CARE PATH OUTPUT EXAMPLE
_____________________________________

For high-risk pet (health_risk_score > 0.6):

health_risk_analysis_output contains:
1. honest_risk_assessment
   Example: "Your senior dog shows multiple age-related risk factors including arthritis, diabetes, and declining kidney function. Immediate veterinary intervention is strongly recommended."

2. critical_risk_factors
   Example list:
   - Progressive kidney disease requiring specialized diet
   - Arthritis causing mobility issues
   - Diabetes requiring insulin management
   - Obesity increasing surgical risk

3. success_probability
   Example: "With immediate intervention and lifestyle modifications, 65 percent recovery and improved quality of life is achievable. Regular monitoring increases success probability to 80 percent."

4. warning_signs
   Example list:
   - Increased thirst or urination (kidney disease indicators)
   - Lameness or pain during movement
   - Lethargy or behavioral changes

5. urgency_timeline
   Example: "Immediate: veterinary consultation within 48 hours. Short-term: dietary changes and pain management within one week. Long-term: ongoing monitoring and medication adjustments monthly."

emergency_preparedness_output contains:
1. emergency_contacts
   Example: Vet clinic number, emergency vet 24-hour number, poison control, insurance contact

2. first_aid_supplies
   Example: Bandages, antiseptic, pain medication, emergency blanket, ice packs, glucose tablets

3. crisis_procedures
   Example: Procedure for choking, difficulty breathing, seizure response, inability to stand

4. when_to_call_vet
   Example: Immediate call if severe pain, inability to urinate, bleeding, difficulty breathing

nutrition_critical_output contains recommendations for specialized diet addressing identified conditions

behavioral_coaching_output contains strategies for managing behavioral issues while managing health conditions

wellness_monitoring_output contains daily, weekly, monthly monitoring checklists


7.3 PREVENTIVE CARE PATH OUTPUT EXAMPLE
_______________________________________

For moderate-risk pet (0.3 < health_risk_score <= 0.6):

health_assessment_output contains:
1. preventive_assessment
   Example: "Your middle-aged dog shows some preventive care needs. Current weight and exercise level require attention to prevent future complications."

2. key_health_areas
   Example: Weight management, joint health, dental care, preventive vaccinations

3. recommended_checkups
   Example: Veterinary checkup every 6 months, dental cleaning annually, weight monitoring monthly

4. prevention_strategies
   Example: Increase exercise gradually, adjust diet for weight management, dental chews daily

nutrition_preventive_output contains moderate dietary adjustments to support preventive health

wellness_tracking_output contains monthly checklist for proactive health monitoring


7.4 WELLNESS PATH OUTPUT EXAMPLE
_______________________________

For low-risk pet (health_risk_score <= 0.3):

wellness_optimization_output contains:
1. optimization_overview
   Example: "Your healthy pet is in excellent condition. Focus on maintaining current health through enrichment and preventive care."

2. wellness_enhancements
   Example: Additional exercise variety, more social interaction, environmental enrichment

3. activity_suggestions
   Example: Hiking, swimming, agility training, interactive puzzle toys

4. bonding_activities
   Example: Daily play sessions, training sessions, outdoor adventures

nutrition_wellness_output contains suggestions for diet enhancement and variety

lifestyle_enrichment_output contains environmental enrichment and mental stimulation suggestions


7.5 JSON EXPORT FORMAT
_____________________

Downloaded JSON structure:

Root level:
- metadata object
  - request_id: Assessment tracking ID
  - timestamp: Analysis completion time

- assessment object
  - All 44 state fields as described above


7.6 UI DISPLAY OUTPUT
____________________

Tab 1 - Overview Display:
- Three metric cards with scores
- Care path description and urgency
- Brief assessment summary

Tab 2 - Health Guidance Display:
- Bordered containers for each output section
- Formatted lists and paragraphs
- Expandable sections for detailed information

Tab 3 - Detailed Analysis Display:
- Pet profile information table
- Health metrics with interpretations
- Path-specific monitoring dashboard

Tab 4 - Summary Display:
- Structured summary with all key information
- Assessment metadata and timestamp
- Request ID for tracking


7.7 ERROR OUTPUT HANDLING
_________________________

If errors occur during assessment:

Error Display:
- Error message banner displayed in red
- List of specific error messages
- Assessment continues despite individual node failures

Error Accumulation:
- Errors collected in error_messages list
- error_occurred flag set to True
- processing_complete flag set to False
- Assessment result returned with error information

Common Errors:
1. API Key Error: "Gemini API key not found" - Configure .env with valid key
2. Model File Error: "Model file not found" - Train models via pipeline
3. Input Validation Error: "Field too short/long" - Provide proper input length
4. API Quota Error: "Quota exceeded" - System rotates to backup key automatically
5. Model Prediction Error: "Unexpected feature shape" - Check ML model artifacts

User Action on Error:
- Read error message carefully
- Correct issue (API key, input length, missing files)
- Retry assessment


7.8 MODEL EVALUATION OUTPUT
___________________________

When "Run Model Evaluation" clicked:

Health Risk Model Metrics:
- Test Samples: Number of evaluation records used
- R-squared Score: Model accuracy (0-1, higher is better)
- Mean Absolute Error: Average prediction error
- Root Mean Squared Error: Standard deviation of errors

Example output:
Test Samples: 10000
R-squared Score: 0.8741
Mean Absolute Error: 0.0432
Root Mean Squared Error: 0.0589

Care Capability Model Metrics:
- Same metric structure
- Predicting 0-100 score instead of 0-1

Expected Performance:
- Both models typically achieve R² > 0.80
- MAE typically < 0.10 for health risk
- MAE typically < 15 for care capability


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

END OF DOCUMENTATION

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
