"""
PawCare+ State Definition - TypedDict for workflow state management.
"""

from typing import TypedDict, List, Dict, Any, Annotated
from datetime import datetime
from operator import add


def keep_first(existing, new):
    """Reducer that keeps the first value and ignores subsequent updates."""
    return existing if existing else new


def set_true(existing, new):
    """Reducer that sets value to True if either existing or new is True."""
    return existing or new


class PetCareState(TypedDict, total=False):
    """Complete state for PawCare+ pet health guidance workflow."""

    # System metadata
    request_id: Annotated[str, keep_first]
    analysis_timestamp: Annotated[str, keep_first]
    error_occurred: Annotated[bool, set_true]
    error_messages: Annotated[List[str], add]
    processing_complete: Annotated[bool, set_true]

    # User input - Raw text fields (3 questions)
    about_pet: Annotated[str, keep_first]
    daily_routine: Annotated[str, keep_first]
    health_concerns: Annotated[str, keep_first]

    # Input validation
    validation_errors: Annotated[List[str], add]
    parsing_complete: Annotated[bool, set_true]

    # Extracted pet profile from LLM (15+ fields)
    extracted_profile: Annotated[Dict[str, Any], keep_first]
    profile_extraction_complete: Annotated[bool, set_true]
    pet_species: Annotated[str, keep_first]
    breed: Annotated[str, keep_first]
    age_years: Annotated[int, keep_first]
    weight_status: Annotated[str, keep_first]
    sex: Annotated[str, keep_first]
    known_conditions: Annotated[List[str], keep_first]
    past_surgeries: Annotated[List[str], keep_first]
    allergies_known: Annotated[List[str], keep_first]
    medications_current: Annotated[List[str], keep_first]
    living_situation: Annotated[str, keep_first]
    exercise_level: Annotated[str, keep_first]
    diet_type: Annotated[str, keep_first]
    diet_quality: Annotated[str, keep_first]
    behavioral_issues: Annotated[List[str], keep_first]
    owner_experience: Annotated[str, keep_first]
    vet_access: Annotated[str, keep_first]
    owner_commitment: Annotated[str, keep_first]

    # ML Predictions - Health Risk Model
    health_risk_score: Annotated[float, keep_first]

    # ML Predictions - Care Capability Model
    care_capability_score: Annotated[float, keep_first]

    # Routing Decision
    path_taken: Annotated[str, keep_first]

    # CRITICAL PATH: Health Risk Analysis
    health_risk_analysis_output: Annotated[Dict[str, Any], keep_first]

    # CRITICAL PATH: Emergency Preparedness
    emergency_prep_output: Annotated[Dict[str, Any], keep_first]

    # CRITICAL PATH: Nutrition Optimization
    nutrition_critical_output: Annotated[Dict[str, Any], keep_first]

    # CRITICAL PATH: Behavioral Coaching
    behavioral_coaching_output: Annotated[Dict[str, Any], keep_first]

    # CRITICAL PATH: Wellness Monitoring
    wellness_monitoring_output: Annotated[Dict[str, Any], keep_first]

    # PREVENTIVE PATH: Health Assessment
    health_assessment_output: Annotated[Dict[str, Any], keep_first]

    # PREVENTIVE PATH: Nutrition Guide
    nutrition_preventive_output: Annotated[Dict[str, Any], keep_first]

    # PREVENTIVE PATH: Wellness Tracking
    wellness_tracking_output: Annotated[Dict[str, Any], keep_first]

    # WELLNESS PATH: Optimization
    wellness_optimization_output: Annotated[Dict[str, Any], keep_first]

    # WELLNESS PATH: Nutrition Enhancement
    nutrition_wellness_output: Annotated[Dict[str, Any], keep_first]

    # WELLNESS PATH: Lifestyle Enrichment
    lifestyle_enrichment_output: Annotated[Dict[str, Any], keep_first]

    # Final aggregated output
    aggregated_output: Annotated[Dict[str, Any], keep_first]



def get_initial_state(form_data: Dict[str, Any]) -> PetCareState:
    """
    Initialize state from form data.

    Args:
        form_data: Dictionary containing user input fields

    Returns:
        Initialized PetCareState dictionary
    """
    return {
        "request_id": form_data.get("request_id", ""),
        "analysis_timestamp": form_data.get("analysis_timestamp", datetime.now().isoformat()),
        "error_occurred": False,
        "error_messages": [],
        "processing_complete": False,
        "about_pet": form_data.get("about_pet", ""),
        "daily_routine": form_data.get("daily_routine", ""),
        "health_concerns": form_data.get("health_concerns", ""),
        "validation_errors": [],
        "parsing_complete": False,
        "extracted_profile": {},
        "profile_extraction_complete": False,
        "pet_species": "",
        "breed": "",
        "age_years": 0,
        "weight_status": "",
        "sex": "",
        "known_conditions": [],
        "past_surgeries": [],
        "allergies_known": [],
        "medications_current": [],
        "living_situation": "",
        "exercise_level": "",
        "diet_type": "",
        "diet_quality": "",
        "behavioral_issues": [],
        "owner_experience": "",
        "vet_access": "",
        "owner_commitment": "",
        "health_risk_score": 0.0,
        "care_capability_score": 0.0,
        "path_taken": "",
        "health_risk_analysis_output": {},
        "emergency_prep_output": {},
        "nutrition_critical_output": {},
        "behavioral_coaching_output": {},
        "wellness_monitoring_output": {},
        "health_assessment_output": {},
        "nutrition_preventive_output": {},
        "wellness_tracking_output": {},
        "wellness_optimization_output": {},
        "nutrition_wellness_output": {},
        "lifestyle_enrichment_output": {},
        "aggregated_output": {},
    }
