"""
Main graph interface for PawCare+ pet health guidance system.
Defines the complete StateGraph structure and orchestration.
"""

from datetime import datetime
from typing import Dict, Any
from uuid import uuid4

from langgraph.graph import StateGraph, START, END
from state import PetCareState, get_initial_state
from utils.gemini_client import GeminiClient
from nodes import (
    input_validator_node,
    pet_profile_extractor_node,
    pet_health_risk_scorer_node,
    owner_care_capability_node,
    health_risk_router_node,
    pet_health_risk_analysis_node,
    emergency_preparedness_node,
    nutrition_critical_node,
    behavioral_coaching_node,
    wellness_monitoring_node,
    health_assessment_preventive_node,
    nutrition_preventive_node,
    wellness_tracking_preventive_node,
    wellness_optimization_node,
    nutrition_wellness_node,
    lifestyle_enrichment_node,
    output_aggregator_node,
)


def build_petcare_graph(client):
    """Build and return the compiled PawCare+ LangGraph.

    Args:
        client: Gemini API client for LLM calls

    Returns:
        Compiled LangGraph StateGraph ready for invocation
    """
    graph = StateGraph(PetCareState)

    # Input validation node
    graph.add_node("input_validator", input_validator_node)

    # Profile extraction node
    graph.add_node("pet_profile_extractor", lambda state: pet_profile_extractor_node(state, client))

    # ML prediction nodes (parallel execution)
    graph.add_node("pet_health_risk_scorer", pet_health_risk_scorer_node)
    graph.add_node("owner_care_capability", owner_care_capability_node)

    # Routing node
    graph.add_node("health_risk_router", health_risk_router_node)

    # CRITICAL PATH nodes
    graph.add_node("pet_health_risk_analysis", lambda state: pet_health_risk_analysis_node(state, client))
    graph.add_node("emergency_preparedness", lambda state: emergency_preparedness_node(state, client))
    graph.add_node("nutrition_critical", lambda state: nutrition_critical_node(state, client))
    graph.add_node("behavioral_coaching", lambda state: behavioral_coaching_node(state, client))
    graph.add_node("wellness_monitoring", lambda state: wellness_monitoring_node(state, client))

    # PREVENTIVE PATH nodes
    graph.add_node("health_assessment_preventive", lambda state: health_assessment_preventive_node(state, client))
    graph.add_node("nutrition_preventive", lambda state: nutrition_preventive_node(state, client))
    graph.add_node("wellness_tracking_preventive", lambda state: wellness_tracking_preventive_node(state, client))

    # WELLNESS PATH nodes
    graph.add_node("wellness_optimization", lambda state: wellness_optimization_node(state, client))
    graph.add_node("nutrition_wellness", lambda state: nutrition_wellness_node(state, client))
    graph.add_node("lifestyle_enrichment", lambda state: lifestyle_enrichment_node(state, client))

    # Output aggregation node
    graph.add_node("output_aggregator", output_aggregator_node)

    # Define edges
    graph.add_edge(START, "input_validator")
    graph.add_edge("input_validator", "pet_profile_extractor")

    # After extraction, run both ML models in parallel
    graph.add_edge("pet_profile_extractor", "pet_health_risk_scorer")
    graph.add_edge("pet_profile_extractor", "owner_care_capability")

    # Both ML nodes merge before routing
    graph.add_edge("pet_health_risk_scorer", "health_risk_router")
    graph.add_edge("owner_care_capability", "health_risk_router")

    # Conditional routing based on health risk score
    def route_by_health_risk(state: PetCareState) -> str:
        """Route to CRITICAL, PREVENTIVE, or WELLNESS path based on health risk score."""
        path = state.get("path_taken", "WELLNESS_PATH")
        if path == "CRITICAL_CARE_PATH":
            return "critical_path"
        elif path == "PREVENTIVE_CARE_PATH":
            return "preventive_path"
        else:
            return "wellness_path"

    graph.add_conditional_edges(
        "health_risk_router",
        route_by_health_risk,
        {
            "critical_path": "pet_health_risk_analysis",
            "preventive_path": "health_assessment_preventive",
            "wellness_path": "wellness_optimization",
        },
    )

    # CRITICAL PATH edges (sequential)
    graph.add_edge("pet_health_risk_analysis", "emergency_preparedness")
    graph.add_edge("emergency_preparedness", "nutrition_critical")
    graph.add_edge("nutrition_critical", "behavioral_coaching")
    graph.add_edge("behavioral_coaching", "wellness_monitoring")
    graph.add_edge("wellness_monitoring", "output_aggregator")

    # PREVENTIVE PATH edges (sequential)
    graph.add_edge("health_assessment_preventive", "nutrition_preventive")
    graph.add_edge("nutrition_preventive", "wellness_tracking_preventive")
    graph.add_edge("wellness_tracking_preventive", "output_aggregator")

    # WELLNESS PATH edges (sequential)
    graph.add_edge("wellness_optimization", "nutrition_wellness")
    graph.add_edge("nutrition_wellness", "lifestyle_enrichment")
    graph.add_edge("lifestyle_enrichment", "output_aggregator")

    # Final edge
    graph.add_edge("output_aggregator", END)

    return graph.compile()


def assess_pet_health(form_data: Dict[str, str]) -> Dict[str, Any]:
    """
    Run complete PawCare+ pet health assessment workflow.

    This is the main entry point for the application. It executes the complete
    pet health guidance workflow and returns comprehensive assessment results.

    API key is automatically loaded from .env file via GeminiClient.

    Args:
        form_data: Dictionary with 3 free-text fields:
            - about_pet: Description of the pet (breed, age, health history, personality)
            - daily_routine: Pet's daily routine and living situation
            - health_concerns: Current health issues and concerns

    Returns:
        Dictionary with complete pet health assessment results including:
        - Pet profile (extracted from free text)
        - ML predictions (health risk, care capability)
        - Path determination (CRITICAL/PREVENTIVE/WELLNESS)
        - LLM-generated insights (health analysis, emergency prep, nutrition, etc)
        - Aggregated final output
        - System metadata
    """
    # Add metadata to form_data before state initialization to avoid concurrent updates
    form_data["request_id"] = str(uuid4())
    form_data["analysis_timestamp"] = datetime.now().isoformat()

    state = get_initial_state(form_data)

    client = GeminiClient()
    graph = build_petcare_graph(client)

    try:
        final_state = graph.invoke(state)
        final_state["processing_complete"] = True
        return final_state

    except Exception as e:
        state["error_occurred"] = True
        state["error_messages"].append(f"Workflow execution error: {str(e)}")
        state["processing_complete"] = False
        return state


def get_pet_health_summary(assessment_result: Dict[str, Any]) -> Dict[str, Any]:
    """
    Extract summary from complete assessment result.

    Args:
        assessment_result: Result from assess_pet_health()

    Returns:
        Dictionary with assessment summary
    """
    path_taken = assessment_result.get("path_taken", "UNKNOWN")

    summary = {
        "pet_profile": {
            "species": assessment_result.get("pet_species"),
            "breed": assessment_result.get("breed"),
            "age_years": assessment_result.get("age_years"),
            "weight_status": assessment_result.get("weight_status"),
            "known_conditions": assessment_result.get("known_conditions", []),
        },
        "health_assessment": {
            "health_risk_score": assessment_result.get("health_risk_score"),
            "care_capability_score": assessment_result.get("care_capability_score"),
        },
        "path_analysis": {
            "path_taken": path_taken,
            "urgency_level": "CRITICAL" if path_taken == "CRITICAL_CARE_PATH" else "MODERATE" if path_taken == "PREVENTIVE_CARE_PATH" else "LOW",
        },
        "outputs": {},
    }

    if path_taken == "CRITICAL_CARE_PATH":
        summary["outputs"] = {
            "health_risk_analysis": assessment_result.get("health_risk_analysis_output", {}),
            "emergency_preparedness": assessment_result.get("emergency_prep_output", {}),
            "nutrition_plan": assessment_result.get("nutrition_critical_output", {}),
            "behavioral_coaching": assessment_result.get("behavioral_coaching_output", {}),
            "wellness_monitoring": assessment_result.get("wellness_monitoring_output", {}),
        }
    elif path_taken == "PREVENTIVE_CARE_PATH":
        summary["outputs"] = {
            "health_assessment": assessment_result.get("health_assessment_output", {}),
            "nutrition_guide": assessment_result.get("nutrition_preventive_output", {}),
            "wellness_tracking": assessment_result.get("wellness_tracking_output", {}),
        }
    elif path_taken == "WELLNESS_PATH":
        summary["outputs"] = {
            "wellness_optimization": assessment_result.get("wellness_optimization_output", {}),
            "nutrition_enhancement": assessment_result.get("nutrition_wellness_output", {}),
            "lifestyle_enrichment": assessment_result.get("lifestyle_enrichment_output", {}),
        }

    summary["system"] = {
        "request_id": assessment_result.get("request_id"),
        "timestamp": assessment_result.get("analysis_timestamp"),
        "processing_complete": assessment_result.get("processing_complete"),
        "error_occurred": assessment_result.get("error_occurred", False),
        "error_messages": assessment_result.get("error_messages", []),
    }

    return summary

